(module
 (rec
  (type $call2 (func (param i64 (ref $type1) i64 i64 i64 i64 i64 i64 i64 i64 f64 f64) (result i64)))
  (type $type1 (struct (field i64)))
  (type $call0 (func (param i64 (ref $type1)) (result i64)))
  (type $type7 (struct))
  (type $type6 (struct))
  (type $type5 (struct))
  (type $type4 (struct (field (mut (ref $type2)))))
  (type $type3 (struct (field (mut (ref $type0)))))
  (type $type2 (struct (field (ref $call2))))
  (type $type0 (struct (field (ref $call0))))
 )
 (type $10 (func (param i64 i64) (result i64)))
 (type $11 (func (param i64 i64 i64 i64 i64 i64 i64 i64 i64 f64 f64) (result i64)))
 (type $12 (func (param i32)))
 (type $13 (func))
 (global $execution (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type0)) (ref.null none))
 (global $global4 (mut (ref null $type2)) (ref.null none))
 (global $global18 (mut (ref null $type0)) (ref.null none))
 (global $global21 (mut (ref null $type2)) (ref.null none))
 (global $global17 (mut (ref null $type3)) (ref.null none))
 (global $ready17 (mut i32) (i32.const 0))
 (global $global3 (mut (ref null $type4)) (ref.null none))
 (global $ready3 (mut i32) (i32.const 0))
 (global $global34 (mut (ref null $type5)) (ref.null none))
 (global $ready34 (mut i32) (i32.const 0))
 (global $global36 (mut (ref null $type6)) (ref.null none))
 (global $ready36 (mut i32) (i32.const 0))
 (global $global39 (mut (ref null $type7)) (ref.null none))
 (global $ready39 (mut i32) (i32.const 0))
 (export "tail_run" (func $export0))
 (export "wide_probe" (func $export1))
 (export "choose_valid" (func $export2))
 (export "main" (func $main))
 (func $function0 (type $call0) (param $0 i64) (param $1 (ref $type1)) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (struct.get $type1 0
     (local.get $1)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready3)
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call2
     (i64.sub
      (local.get $0)
      (i64.const 1)
     )
     (struct.new $type1
      (struct.get $type1 0
       (local.get $1)
      )
     )
     (i64.const 11)
     (i64.const 12)
     (i64.const 13)
     (i64.const 14)
     (i64.const 15)
     (i64.const 16)
     (i64.const 17)
     (i64.const 18)
     (f64.const 1.25)
     (f64.const 2.5)
     (struct.get $type2 0
      (struct.get $type4 0
       (global.get $global3)
      )
     )
    )
   )
  )
 )
 (func $function1 (type $call2) (param $0 i64) (param $1 (ref $type1)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i64) (param $6 i64) (param $7 i64) (param $8 i64) (param $9 i64) (param $10 f64) (param $11 f64) (result i64)
  (if
   (i64.eq
    (i64.add
     (local.get $2)
     (local.get $9)
    )
    (i64.const 29)
   )
   (then
    (if
     (i64.eq
      (i64.add
       (local.get $3)
       (local.get $8)
      )
      (i64.const 29)
     )
     (then
      (if
       (i64.eq
        (i64.add
         (local.get $4)
         (local.get $7)
        )
        (i64.const 29)
       )
       (then
        (if
         (i64.eq
          (i64.add
           (local.get $5)
           (local.get $6)
          )
          (i64.const 29)
         )
         (then
          (if
           (f64.eq
            (local.get $10)
            (f64.const 1.25)
           )
           (then
            (if
             (f64.eq
              (local.get $11)
              (f64.const 2.5)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready17)
               )
               (then
                (unreachable)
               )
              )
              (return_call_ref $call0
               (local.get $0)
               (local.get $1)
               (struct.get $type0 0
                (struct.get $type3 0
                 (global.get $global17)
                )
               )
              )
             )
             (else
              (unreachable)
             )
            )
            (unreachable)
           )
           (else
            (unreachable)
           )
          )
          (unreachable)
         )
         (else
          (unreachable)
         )
        )
        (unreachable)
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
     (else
      (unreachable)
     )
    )
    (unreachable)
   )
   (else
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function2 (type $call0) (param $0 i64) (param $1 (ref $type1)) (result i64)
  (unreachable)
 )
 (func $function3 (type $call2) (param $0 i64) (param $1 (ref $type1)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i64) (param $6 i64) (param $7 i64) (param $8 i64) (param $9 i64) (param $10 f64) (param $11 f64) (result i64)
  (unreachable)
 )
 (func $export0 (param $0 i64) (param $1 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready36)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global36)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready3)
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call2
     (i64.sub
      (local.get $0)
      (i64.const 1)
     )
     (struct.new $type1
      (local.get $1)
     )
     (i64.const 11)
     (i64.const 12)
     (i64.const 13)
     (i64.const 14)
     (i64.const 15)
     (i64.const 16)
     (i64.const 17)
     (i64.const 18)
     (f64.const 1.25)
     (f64.const 2.5)
     (struct.get $type2 0
      (struct.get $type4 0
       (global.get $global3)
      )
     )
    )
   )
  )
 )
 (func $export1 (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i64) (param $6 i64) (param $7 i64) (param $8 i64) (param $9 f64) (param $10 f64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready39)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global39)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global4)
   )
  )
  (return_call $function1
   (local.get $0)
   (struct.new $type1
    (i64.const 42)
   )
   (local.get $1)
   (local.get $2)
   (local.get $3)
   (local.get $4)
   (local.get $5)
   (local.get $6)
   (local.get $7)
   (local.get $8)
   (local.get $9)
   (local.get $10)
  )
 )
 (func $export2 (param $0 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready34)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global34)
   )
  )
  (struct.set $type3 0
   (global.get $global17)
   (ref.as_non_null
    (select (result (ref null $type0))
     (global.get $global0)
     (global.get $global18)
     (local.get $0)
    )
   )
  )
  (struct.set $type4 0
   (global.get $global3)
   (ref.as_non_null
    (select (result (ref null $type2))
     (global.get $global4)
     (global.get $global21)
     (local.get $0)
    )
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global0
   (struct.new $type0
    (ref.func $function0)
   )
  )
  (global.set $global4
   (struct.new $type2
    (ref.func $function1)
   )
  )
  (global.set $global18
   (struct.new $type0
    (ref.func $function2)
   )
  )
  (global.set $global21
   (struct.new $type2
    (ref.func $function3)
   )
  )
  (global.set $global17
   (struct.new $type3
    (ref.as_non_null
     (global.get $global0)
    )
   )
  )
  (global.set $ready17
   (i32.const 1)
  )
  (global.set $global3
   (struct.new $type4
    (ref.as_non_null
     (global.get $global4)
    )
   )
  )
  (global.set $ready3
   (i32.const 1)
  )
  (global.set $global34
   (struct.new_default $type5)
  )
  (global.set $ready34
   (i32.const 1)
  )
  (global.set $global36
   (struct.new_default $type6)
  )
  (global.set $ready36
   (i32.const 1)
  )
  (global.set $global39
   (struct.new_default $type7)
  )
  (global.set $ready39
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

