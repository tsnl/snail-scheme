#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
extern void native_host_init(int, char **);
extern void native_module_init(void);
extern int native_finish(int);
extern void guest_main(void) __asm__("wasm.main");
extern int64_t guest_tail(int64_t, int64_t) __asm__("wasm.tail_run");
int main(int argc, char **argv) {
    native_host_init(argc, argv);
    native_module_init();
    guest_main();
    assert(guest_tail(argc > 1 ? strtoll(argv[1], 0, 10) : 1000000, argc > 2 ? strtoll(argv[2], 0, 10) : 42) == 42);
    return native_finish(0);
}
