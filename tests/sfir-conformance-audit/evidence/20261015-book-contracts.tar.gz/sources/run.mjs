import '/tmp/snail-sfir-conformance-audit-20261015/tests/sfir-integration/run.mjs';
