This audit started at 875f11a6 and completed at 71e6cc09062731bc6570e989e33431b1042e4b82. It tests selected SFIR book contracts with executable examples; it does not establish complete language coverage. Numeric defaults, arithmetic overflow and performance measurement were outside this slice.

Three P2 conformance issues were found and fixed in separate commits:

| Commit | Failure | Correction |
| --- | --- | --- |
| 65cbba89 | Nested annotations hide enclosing qualified evidence. | Extend lexical assumptions with the inner declaration's requirements. |
| 66cebf32 | Unused concrete declared constraints prove themselves. | Discharge them against enclosing evidence after inference settles. |
| 71e6cc09 | Dynamic Any projection can generalize and hide an initialization trap. | Classify inferred values; checked projection stays monomorphic, static wrappers remain eligible. |

The final focused suite has 20 passing raw/optimized contracts. Host tests, 83 surface contracts, 14 existing polymorphism/alias cases, 20 existing class/qualified-overload cases and the existing recursive-group suite pass. The recursive-group suite includes 12 inference rejections and four executions on raw Wasm, optimized Wasm and native. New static annotation/injection and shared alias controls plus the unused monomorphic trap were executed natively with collection at every allocation.

The broader 21-case suite tests fixed/rest argument order and trap effects, Any identity for scalars, empty and nested containers, references, nominal and phantom datatypes, function domains/results/rest signatures, mutable aliases, the value restriction and instance coherence. Final corrected outcomes all pass. Representative Any/order cases also execute natively. A separate diamond imports the same instance through restricted reexports, observes its initializer once and projects a reexported nominal type through Any; it passes raw/optimized/native. An unused generic forward alias retains its initialization trap.

The final tail probe deliberately retains unknown function targets and wide argument values. Its optimized WAT contains alternating two- and twelve-argument return_call_ref operations, mixed I64/F64 arguments and a managed Ref with allocation in the tail caller. Raw Wasm, optimized Wasm and native pass 1,000,000 iterations. Native passes 10,000 with SNAIL_NATIVE_GC_INTERVAL=1. Native optimized guests are byte-identical to the optimized Wasm guests. Earlier tail probes were optimized into self-calls and are superseded for this claim.

index.json maps each assertion to raw command/output logs and records source hashes. sources/ contains standalone audit inputs; fixtures/ contains committed focused inputs. logs/ preserves earlier attempts, including explicit pre-fix failures and corrected fixture/harness mistakes. Final results are named by index.json, so earlier failed attempts must not be interpreted as unresolved compiler failures. Large native products remain in the original evidence directory; the bundle retains guest Wasm, command logs and build provenance.

Reproduce the focused suite from the committed tree with `python3 tests/sfir-conformance-audit/check.py --output /tmp/sfir-conformance-repeat`. Existing runners remain reusable: `scripts/test-sfir`, `scripts/test-sfir-integration`, and `python3 tests/sfir-recursion/check.py`. Standalone compile, execution and native commands are preserved verbatim in their JSON logs.
