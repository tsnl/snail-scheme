(module
 (type $0 (func (param f64) (result f64)))
 (type $type0 (struct))
 (type $2 (func (param i64 f64) (result f64)))
 (type $3 (func))
 (import "snail.library" "snail:math/atan" (func $foreign0 (param f64) (result f64)))
 (import "snail.library" "snail:math/cos" (func $foreign1 (param f64) (result f64)))
 (import "snail.library" "snail:math/sin" (func $foreign2 (param f64) (result f64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global106 (mut (ref null $type0)) (ref.null none))
 (global $ready106 (mut i32) (i32.const 0))
 (export "trigonometry" (func $export0))
 (export "main" (func $main))
 (func $export0 (param $0 i64) (param $1 f64) (result f64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready106)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (if (result f64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (call $foreign2
     (local.get $1)
    )
   )
   (else
    (if (result f64)
     (i64.eq
      (local.get $0)
      (i64.const 1)
     )
     (then
      (call $foreign1
       (local.get $1)
      )
     )
     (else
      (call $foreign0
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type0)
  )
  (global.set $ready106
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

