(module
 (rec
  (type $type181 (sub (struct (field i32))))
  (type $type24 (sub (struct (field i32))))
  (type $type32 (sub (struct (field i32))))
  (type $3 (func (param (ref $type18) i32 i32 i64) (result i32)))
  (type $call224 (func (param (ref $type18)) (result i32)))
  (type $type183 (sub $type181 (struct (field i32) (field (ref $type24)))))
  (type $type184 (sub $type181 (struct (field i32))))
  (type $call185 (func (param (ref $type18) i64) (result (ref $type181))))
  (type $call177 (func (param i32 i32 i32) (result (ref $type32))))
  (type $9 (func (param i32 i32 i32 i64 (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $10 (func (param (ref $type18) i32 i64 i32 i32 i64) (result i32)))
  (type $call169 (func (param (ref $type18)) (result i32)))
  (type $call145 (func (param (ref $type24)) (result (ref $type18))))
  (type $call144 (func (param (ref $type32)) (result (ref $type18))))
  (type $14 (func (param i32 i64 (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $15 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type18))))
  (type $call142 (func (param (ref $type32) (ref $type32)) (result i32)))
  (type $call141 (func (param (ref $type24) (ref $type24)) (result i32)))
  (type $call140 (func (param (ref $type32) (ref $type32)) (result i64)))
  (type $call133 (func (param (ref $type24)) (result (ref $type24))))
  (type $call139 (func (param (ref $type24) (ref $type24)) (result (ref $type24))))
  (type $call138 (func (param (ref $type32)) (result (ref $type32))))
  (type $call137 (func (param (ref $type32) (ref $type32)) (result (ref $type32))))
  (type $call132 (func (param (ref $type24)) (result i32)))
  (type $call131 (func (param (ref $type24)) (result (ref $type32))))
  (type $type31 (sub $type24 (struct (field i32) (field (ref $type32)) (field (ref $type32)))))
  (type $call130 (func (param (ref $type32) (ref $type32)) (result (ref $type24))))
  (type $call129 (func (param (ref $type32)) (result (ref $type27))))
  (type $type25 (sub $type24 (struct (field i32) (field i64))))
  (type $type30 (sub $type24 (struct (field i32) (field f64))))
  (type $type35 (sub $type32 (struct (field i32) (field f64))))
  (type $type26 (sub $type24 (struct (field i32) (field (ref $type27)))))
  (type $call126 (func (param (ref $type28)) (result (ref $type24))))
  (type $type34 (sub $type32 (struct (field i32) (field (ref $type27)))))
  (type $type33 (sub $type32 (struct (field i32) (field i64))))
  (type $call123 (func (param (ref $type27)) (result (ref $type32))))
  (type $36 (func (param i32 i32 f64 i64) (result (ref $type27))))
  (type $type27 (struct (field (ref $type28)) (field (ref $type28))))
  (type $call112 (func (param (ref $type28) (ref $type28)) (result (ref $type27))))
  (type $39 (func (param i32 i32 (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $call110 (func (param (ref $type28) (ref $type28)) (result f64)))
  (type $41 (func (param f64 i32 i32 i64 f64) (result f64)))
  (type $call107 (func (param i64) (result f64)))
  (type $43 (func (param i32 (ref $type29) f64 i32 i32 f64 i64) (result (ref $type28))))
  (type $44 (func (param i32 i32 f64 i64) (result i64)))
  (type $call105 (func (param f64) (result i64)))
  (type $46 (func (param i32 i32 (ref $type28) (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $type49 (struct))
  (type $call100 (func (param (ref $type28)) (result (ref $type18))))
  (type $call99 (func (param (ref $type18) i64 (ref null $type44)) (result i32)))
  (type $50 (func (param (ref $type18) i32 i32 i64 i64 i64) (result i32)))
  (type $51 (func (param i32 i32 (ref null $type44) i64) (result i64)))
  (type $call51 (func (param (ref null $type44)) (result i64)))
  (type $53 (func (param i32 i32 (ref $type29) (ref $type44)) (result (ref null $type44))))
  (type $type44 (struct (field i64) (field (ref null $type44))))
  (type $call97 (func (param (ref $type29)) (result (ref null $type44))))
  (type $call96 (func (param (ref $type18) i64) (result (ref $type28))))
  (type $call93 (func (param (ref $type18)) (result (ref $type28))))
  (type $58 (func (param (ref $type18) i32 i64 i32 i32 i64 (ref $type28)) (result (ref $type28))))
  (type $59 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $60 (func (param i64) (result i64)))
  (type $61 (func (param (ref $type18) i64 i32 i32 i64 i64) (result i64)))
  (type $call80 (func (param (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $type88 (struct (field (ref $type28)) (field (ref $type28))))
  (type $64 (func (param (ref $type28) (ref $type28)) (result (ref $type88))))
  (type $65 (func (param (ref $type29) (ref $type29) (ref $type29) i32 i32 i64) (result i32)))
  (type $66 (func (param (ref $type29) (ref $type29) (ref $type29)) (result i32)))
  (type $call83 (func (param (ref $type29) (ref $type29) i64) (result i64)))
  (type $68 (func (param (ref $type29) (ref $type29) i64 i64 i32 i32 i64 i64) (result i32)))
  (type $69 (func (param (ref $type29) (ref $type29) i64 i64 i64 i32 i32 i64 i64) (result i64)))
  (type $70 (func (param (ref $type29) (ref $type29) i64 i32 i32 i64 i64) (result i64)))
  (type $71 (func (param (ref $type29) (ref $type29)) (result i64)))
  (type $72 (func (param (ref $type29) i64 i64 (ref $type29) i32 i32 i64 i64) (result (ref $type29))))
  (type $73 (func (param (ref $type29) (ref $type29) (ref $type29) i32 i32 i64) (result (ref $type29))))
  (type $call78 (func (param (ref $type29) (ref $type29)) (result (ref $type29))))
  (type $75 (func (param (ref $type29) (ref $type29) i64 i64 i64 i32 i32 i64 i64) (result i32)))
  (type $call81 (func (param (ref $type29) (ref $type29) i64 i64) (result i32)))
  (type $77 (func (param (ref $type28) (ref $type28)) (result (ref $type28))))
  (type $78 (func (param (ref $type29) (ref $type29) i64 (ref $type29) i32 i32 i64 i64) (result (ref $type29))))
  (type $call76 (func (param (ref $type28) (ref $type28)) (result i64)))
  (type $80 (func (param (ref $type29) (ref $type29) i32 i32 i64) (result i64)))
  (type $81 (func (param (ref $type29) i32 i64 i32 i32 i64 i64) (result i64)))
  (type $82 (func (param i32 (ref $type29) i32 i32 i64 i64) (result (ref $type28))))
  (type $call73 (func (param i64) (result (ref $type28))))
  (type $84 (func (param i32 i32 i64 i64) (result i64)))
  (type $call72 (func (param i64) (result i64)))
  (type $call70 (func (param (ref $type28)) (result i32)))
  (type $87 (func (param i32 (ref $type29)) (result (ref $type28))))
  (type $call52 (func (param (ref $type29)) (result (ref $type29))))
  (type $89 (func (param (ref $type29) i32 i32 i64) (result i64)))
  (type $call68 (func (param (ref $type29)) (result i64)))
  (type $91 (func (param (ref $type29) i64 i64)))
  (type $type29 (array (mut i32)))
  (type $call65 (func (param (ref $type29) i64) (result i64)))
  (type $94 (func (param (ref $type18) (ref $type18) i32 i32 i64) (result i32)))
  (type $call63 (func (param (ref $type18) (ref null $type61) i64) (result i32)))
  (type $96 (func (param i32 i32 (ref null $type61) i64) (result i64)))
  (type $type61 (struct (field (ref $type18)) (field (ref null $type61))))
  (type $98 (func (param (ref $type61)) (result (ref $type18))))
  (type $99 (func (param (ref $type18) i32 i32 (ref null $type49) i64) (result (ref $type18))))
  (type $100 (func (param (ref $type18) i64 (ref $type18) i64)))
  (type $101 (func (param (ref $type18) i32) (result (ref $type19))))
  (type $type20 (array (mut (ref null $type19))))
  (type $103 (func (param i32) (result (ref $type18))))
  (type $type0 (struct))
  (type $type231 (struct))
  (type $type230 (struct))
  (type $type229 (struct))
  (type $type228 (struct))
  (type $type227 (struct))
  (type $type226 (struct))
  (type $type224 (struct))
  (type $type180 (struct))
  (type $type176 (struct))
  (type $type169 (struct))
  (type $type143 (struct))
  (type $type136 (struct))
  (type $type135 (struct))
  (type $type5 (struct))
  (type $type118 (struct))
  (type $type117 (struct))
  (type $type109 (struct))
  (type $type108 (struct))
  (type $type107 (struct))
  (type $type106 (struct))
  (type $type105 (struct))
  (type $type51 (struct))
  (type $type97 (struct))
  (type $type95 (struct))
  (type $type94 (struct))
  (type $type92 (struct))
  (type $type91 (struct))
  (type $type90 (struct))
  (type $type87 (struct))
  (type $type86 (struct))
  (type $type85 (struct))
  (type $type84 (struct))
  (type $type79 (struct))
  (type $type68 (struct))
  (type $type62 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type48 (struct))
  (type $type175 (struct))
  (type $type145 (struct))
  (type $type144 (struct))
  (type $type142 (struct))
  (type $type133 (struct))
  (type $type139 (struct))
  (type $type138 (struct))
  (type $type134 (struct))
  (type $type125 (struct))
  (type $type120 (struct))
  (type $type111 (struct))
  (type $type72 (struct))
  (type $type93 (struct))
  (type $type78 (struct))
  (type $type141 (struct))
  (type $type122 (struct))
  (type $type116 (struct))
  (type $type113 (struct))
  (type $type96 (struct))
  (type $type75 (struct))
  (type $type74 (struct))
  (type $type64 (struct))
  (type $type82 (struct))
  (type $type60 (struct))
  (type $type225 (struct))
  (type $type186 (struct))
  (type $type178 (struct))
  (type $type177 (struct))
  (type $type126 (struct))
  (type $type98 (struct))
  (type $type179 (struct))
  (type $type185 (struct))
  (type $type104 (struct))
  (type $type119 (struct))
  (type $type115 (struct))
  (type $type101 (struct))
  (type $type100 (struct))
  (type $type99 (struct))
  (type $type81 (struct))
  (type $type140 (struct))
  (type $type132 (struct))
  (type $type130 (struct))
  (type $type63 (struct))
  (type $type114 (struct))
  (type $type112 (struct))
  (type $type89 (struct))
  (type $type83 (struct))
  (type $type137 (struct))
  (type $type124 (struct))
  (type $type71 (struct))
  (type $type123 (struct))
  (type $type54 (struct))
  (type $type67 (struct))
  (type $type80 (struct))
  (type $type69 (struct))
  (type $type131 (struct))
  (type $type128 (struct))
  (type $type121 (struct))
  (type $type77 (struct))
  (type $type129 (struct))
  (type $type28 (struct (field i32) (field (ref $type29))))
  (type $type110 (struct))
  (type $type127 (struct))
  (type $type52 (struct))
  (type $type76 (struct))
  (type $type66 (struct))
  (type $type73 (struct))
  (type $type70 (struct))
  (type $type65 (struct))
  (type $type182 (sub $type181 (struct (field i32))))
  (type $type18 (struct (field i32) (field i32) (field (ref $type19)) (field (ref null $type20))))
  (type $type19 (array (mut i32)))
 )
 (type $215 (func (param i32 i32) (result i32)))
 (type $216 (func (param f64) (result f64)))
 (type $217 (func (param i32) (result i32)))
 (type $218 (func (param i32)))
 (type $219 (func (param i32 i32) (result i64)))
 (type $220 (func (param (ref $type18) i32 i64 i32 i32 i64 (ref $type28)) (result (ref $type28))))
 (type $221 (func (param f64 f64) (result i32)))
 (type $222 (func (param f64) (result i32)))
 (type $223 (func (result i32)))
 (type $224 (func (param i32 i32)))
 (type $225 (func (param i32 i32 i32) (result i32)))
 (type $226 (func (param i32 i32 i32 i32) (result i32)))
 (type $227 (func (param i32 i32) (result f64)))
 (type $228 (func (param i32) (result i64)))
 (type $229 (func (param i32 i64) (result i32)))
 (type $230 (func (param i64 f64) (result f64)))
 (type $231 (func))
 (import "snail.library" "snail:math/cos" (func $foreign0 (param f64) (result f64)))
 (import "snail.library" "snail:math/sin" (func $foreign1 (param f64) (result f64)))
 (import "snail.library" "snail:datum/real-equivalent" (func $foreign2 (param f64 f64) (result i32)))
 (import "snail.library" "snail:datum/real-text" (func $foreign3 (param f64) (result i32)))
 (import "snail.library" "snail:datum/token-text-length" (func $foreign4 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-text-character" (func $foreign5 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:datum/token-open" (func $foreign7 (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign8 (param i32 i32)))
 (import "snail.library" "snail:datum/number-text-length" (func $foreign15 (param i32 i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-text-character" (func $foreign16 (param i32 i32 i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-radix" (func $foreign17 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-scale" (func $foreign18 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign19 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign20 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign21 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/error-length" (func $foreign22 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign23 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse-radix" (func $foreign24 (param i32 i32) (result i32)))
 (import "oracle" "argument_length" (func $foreign26 (param i32) (result i64)))
 (import "oracle" "argument_character" (func $foreign27 (param i32 i64) (result i32)))
 (import "oracle" "emit_character" (func $foreign28 (param i32)))
 (global $global109 (mut (ref null $type65)) (ref.null none))
 (global $global130 (mut (ref null $type70)) (ref.null none))
 (global $global141 (mut (ref null $type73)) (ref.null none))
 (global $global112 (mut (ref null $type66)) (ref.null none))
 (global $global167 (mut (ref null $type76)) (ref.null none))
 (global $global122 (mut (ref null $type52)) (ref.null none))
 (global $global618 (mut (ref null $type127)) (ref.null none))
 (global $global507 (mut (ref null $type110)) (ref.null none))
 (global $global108 (mut (ref null $type28)) (ref.null none))
 (global $global636 (mut (ref null $type129)) (ref.null none))
 (global $global171 (mut (ref null $type77)) (ref.null none))
 (global $global598 (mut (ref null $type121)) (ref.null none))
 (global $global630 (mut (ref null $type128)) (ref.null none))
 (global $global674 (mut (ref null $type131)) (ref.null none))
 (global $global126 (mut (ref null $type69)) (ref.null none))
 (global $global236 (mut (ref null $type80)) (ref.null none))
 (global $global650 (mut (ref null $type131)) (ref.null none))
 (global $global116 (mut (ref null $type67)) (ref.null none))
 (global $global658 (mut (ref null $type131)) (ref.null none))
 (global $global61 (mut (ref null $type54)) (ref.null none))
 (global $global606 (mut (ref null $type123)) (ref.null none))
 (global $global134 (mut (ref null $type71)) (ref.null none))
 (global $global608 (mut (ref null $type124)) (ref.null none))
 (global $global744 (mut (ref null $type137)) (ref.null none))
 (global $global248 (mut (ref null $type83)) (ref.null none))
 (global $global316 (mut (ref null $type89)) (ref.null none))
 (global $global539 (mut (ref null $type28)) (ref.null none))
 (global $global540 (mut (ref null $type112)) (ref.null none))
 (global $global551 (mut (ref null $type114)) (ref.null none))
 (global $global624 (mut (ref null $type127)) (ref.null none))
 (global $global96 (mut (ref null $type63)) (ref.null none))
 (global $ready96 (mut i32) (i32.const 0))
 (global $global642 (mut (ref null $type130)) (ref.null none))
 (global $global666 (mut (ref null $type132)) (ref.null none))
 (global $global779 (mut (ref null $type140)) (ref.null none))
 (global $global219 (mut (ref null $type81)) (ref.null none))
 (global $global289 (mut (ref null $type83)) (ref.null none))
 (global $global325 (mut (ref null $type80)) (ref.null none))
 (global $global406 (mut (ref null $type99)) (ref.null none))
 (global $global411 (mut (ref null $type100)) (ref.null none))
 (global $global421 (mut (ref null $type80)) (ref.null none))
 (global $global430 (mut (ref null $type101)) (ref.null none))
 (global $global549 (mut (ref null $type114)) (ref.null none))
 (global $global555 (mut (ref null $type115)) (ref.null none))
 (global $global578 (mut (ref null $type119)) (ref.null none))
 (global $global688 (mut (ref null $type104)) (ref.null none))
 (global $global1086 (mut (ref null $type185)) (ref.null none))
 (global $global1435 (mut (ref null $type179)) (ref.null none))
 (global $global132 (mut (ref null $type71)) (ref.null none))
 (global $global397 (mut (ref null $type98)) (ref.null none))
 (global $ready406 (mut i32) (i32.const 0))
 (global $global616 (mut (ref null $type126)) (ref.null none))
 (global $global690 (mut (ref null $type127)) (ref.null none))
 (global $global732 (mut (ref null $type137)) (ref.null none))
 (global $global1062 (mut (ref null $type177)) (ref.null none))
 (global $global1068 (mut (ref null $type178)) (ref.null none))
 (global $global1092 (mut (ref null $type186)) (ref.null none))
 (global $global1445 (mut (ref null $type225)) (ref.null none))
 (global $global88 (mut (ref null $type60)) (ref.null none))
 (global $global211 (mut (ref null $type80)) (ref.null none))
 (global $global239 (mut (ref null $type82)) (ref.null none))
 (global $global477 (mut (ref null $type73)) (ref.null none))
 (global $global704 (mut (ref null $type132)) (ref.null none))
 (global $global741 (mut (ref null $type137)) (ref.null none))
 (global $execution (mut i32) (i32.const 0))
 (global $global101 (mut (ref null $type64)) (ref.null none))
 (global $global149 (mut (ref null $type74)) (ref.null none))
 (global $global158 (mut (ref null $type75)) (ref.null none))
 (global $global186 (mut (ref null $type65)) (ref.null none))
 (global $global322 (mut (ref null $type80)) (ref.null none))
 (global $global371 (mut (ref null $type96)) (ref.null none))
 (global $global547 (mut (ref null $type113)) (ref.null none))
 (global $global559 (mut (ref null $type116)) (ref.null none))
 (global $global600 (mut (ref null $type122)) (ref.null none))
 (global $global702 (mut (ref null $type132)) (ref.null none))
 (global $global747 (mut (ref null $type137)) (ref.null none))
 (global $global824 (mut (ref null $type141)) (ref.null none))
 (global $string0 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 47)
  )
  (ref.null none)
 ))
 (global $global198 (mut (ref null $type78)) (ref.null none))
 (global $global353 (mut (ref null $type93)) (ref.null none))
 (global $global433 (mut (ref null $type72)) (ref.null none))
 (global $global473 (mut (ref null $type74)) (ref.null none))
 (global $global511 (mut (ref null $type111)) (ref.null none))
 (global $global553 (mut (ref null $type114)) (ref.null none))
 (global $global557 (mut (ref null $type115)) (ref.null none))
 (global $global593 (mut (ref null $type120)) (ref.null none))
 (global $global614 (mut (ref null $type125)) (ref.null none))
 (global $global680 (mut (ref null $type134)) (ref.null none))
 (global $global708 (mut (ref null $type132)) (ref.null none))
 (global $global735 (mut (ref null $type138)) (ref.null none))
 (global $global750 (mut (ref null $type139)) (ref.null none))
 (global $global753 (mut (ref null $type133)) (ref.null none))
 (global $global765 (mut (ref null $type139)) (ref.null none))
 (global $global773 (mut (ref null $type127)) (ref.null none))
 (global $global784 (mut (ref null $type141)) (ref.null none))
 (global $global790 (mut (ref null $type141)) (ref.null none))
 (global $global809 (mut (ref null $type142)) (ref.null none))
 (global $global872 (mut (ref null $type144)) (ref.null none))
 (global $global878 (mut (ref null $type145)) (ref.null none))
 (global $global1045 (mut (ref null $type175)) (ref.null none))
 (global $global68 (mut (ref null $type48)) (ref.null none))
 (global $global383 (mut (ref null $type52)) (ref.null none))
 (global $global63 (mut (ref null $type55)) (ref.null none))
 (global $global65 (mut (ref null $type56)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global91 (mut (ref null $type62)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type68)) (ref.null none))
 (global $global136 (mut (ref null $type72)) (ref.null none))
 (global $global174 (mut (ref null $type77)) (ref.null none))
 (global $global177 (mut (ref null $type77)) (ref.null none))
 (global $global183 (mut (ref null $type77)) (ref.null none))
 (global $global189 (mut (ref null $type78)) (ref.null none))
 (global $global207 (mut (ref null $type79)) (ref.null none))
 (global $global230 (mut (ref null $type78)) (ref.null none))
 (global $global256 (mut (ref null $type83)) (ref.null none))
 (global $global268 (mut (ref null $type84)) (ref.null none))
 (global $global280 (mut (ref null $type85)) (ref.null none))
 (global $global294 (mut (ref null $type86)) (ref.null none))
 (global $global300 (mut (ref null $type87)) (ref.null none))
 (global $global309 (mut (ref null $type89)) (ref.null none))
 (global $global328 (mut (ref null $type90)) (ref.null none))
 (global $global336 (mut (ref null $type91)) (ref.null none))
 (global $global342 (mut (ref null $type92)) (ref.null none))
 (global $global358 (mut (ref null $type94)) (ref.null none))
 (global $global363 (mut (ref null $type95)) (ref.null none))
 (global $global377 (mut (ref null $type97)) (ref.null none))
 (global $global387 (mut (ref null $type72)) (ref.null none))
 (global $global392 (mut (ref null $type51)) (ref.null none))
 (global $global417 (mut (ref null $type71)) (ref.null none))
 (global $global454 (mut (ref null $type104)) (ref.null none))
 (global $global456 (mut (ref null $type105)) (ref.null none))
 (global $global461 (mut (ref null $type106)) (ref.null none))
 (global $global479 (mut (ref null $type107)) (ref.null none))
 (global $global486 (mut (ref null $type108)) (ref.null none))
 (global $global490 (mut (ref null $type76)) (ref.null none))
 (global $global497 (mut (ref null $type109)) (ref.null none))
 (global $global502 (mut (ref null $type110)) (ref.null none))
 (global $global513 (mut (ref null $type70)) (ref.null none))
 (global $global515 (mut (ref null $type80)) (ref.null none))
 (global $global562 (mut (ref null $type116)) (ref.null none))
 (global $global565 (mut (ref null $type116)) (ref.null none))
 (global $global568 (mut (ref null $type116)) (ref.null none))
 (global $global571 (mut (ref null $type117)) (ref.null none))
 (global $global575 (mut (ref null $type118)) (ref.null none))
 (global $global603 (mut (ref null $type5)) (ref.null none))
 (global $global645 (mut (ref null $type130)) (ref.null none))
 (global $global676 (mut (ref null $type133)) (ref.null none))
 (global $global678 (mut (ref null $type133)) (ref.null none))
 (global $global682 (mut (ref null $type135)) (ref.null none))
 (global $global684 (mut (ref null $type136)) (ref.null none))
 (global $global696 (mut (ref null $type127)) (ref.null none))
 (global $global706 (mut (ref null $type132)) (ref.null none))
 (global $global710 (mut (ref null $type132)) (ref.null none))
 (global $global714 (mut (ref null $type133)) (ref.null none))
 (global $global716 (mut (ref null $type133)) (ref.null none))
 (global $global718 (mut (ref null $type133)) (ref.null none))
 (global $global724 (mut (ref null $type133)) (ref.null none))
 (global $global728 (mut (ref null $type133)) (ref.null none))
 (global $global755 (mut (ref null $type139)) (ref.null none))
 (global $global758 (mut (ref null $type139)) (ref.null none))
 (global $global787 (mut (ref null $type141)) (ref.null none))
 (global $global793 (mut (ref null $type141)) (ref.null none))
 (global $global797 (mut (ref null $type141)) (ref.null none))
 (global $global803 (mut (ref null $type133)) (ref.null none))
 (global $global851 (mut (ref null $type72)) (ref.null none))
 (global $global856 (mut (ref null $type54)) (ref.null none))
 (global $global865 (mut (ref null $type143)) (ref.null none))
 (global $global883 (mut (ref null $type5)) (ref.null none))
 (global $ready883 (mut i32) (i32.const 0))
 (global $global1021 (mut (ref null $type169)) (ref.null none))
 (global $global1053 (mut (ref null $type176)) (ref.null none))
 (global $global1072 (mut (ref null $type179)) (ref.null none))
 (global $global1078 (mut (ref null $type180)) (ref.null none))
 (global $global1083 (mut (ref null $type180)) (ref.null none))
 (global $global1441 (mut (ref null $type224)) (ref.null none))
 (global $global1471 (mut (ref null $type226)) (ref.null none))
 (global $global1475 (mut (ref null $type227)) (ref.null none))
 (global $global1450 (mut (ref null $type228)) (ref.null none))
 (global $global1459 (mut (ref null $type229)) (ref.null none))
 (global $global1466 (mut (ref null $type230)) (ref.null none))
 (global $global1463 (mut (ref null $type231)) (ref.null none))
 (global $global1455 (mut (ref null $type107)) (ref.null none))
 (global $global1452 (mut (ref null $type0)) (ref.null none))
 (global $ready1452 (mut i32) (i32.const 0))
 (global $string1 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 45)
   (i32.const 49)
   (i32.const 47)
   (i32.const 50)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 43)
  )
  (ref.null none)
 ))
 (global $string4 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 0)
  (array.new_fixed $type19 0)
  (ref.null none)
 ))
 (global $string5 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 105)
  )
  (ref.null none)
 ))
 (global $string6 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 57)
   (i32.const 50)
   (i32.const 50)
   (i32.const 51)
   (i32.const 51)
   (i32.const 55)
   (i32.const 50)
   (i32.const 48)
   (i32.const 51)
   (i32.const 54)
   (i32.const 56)
   (i32.const 53)
   (i32.const 52)
   (i32.const 55)
   (i32.const 55)
   (i32.const 53)
   (i32.const 56)
   (i32.const 48)
   (i32.const 56)
  )
  (ref.null none)
 ))
 (global $empty182 (ref $type182) (struct.new $type182
  (i32.const 0)
 ))
 (export "probe" (func $export0))
 (export "main" (func $main))
 (func $string-new (type $103) (param $0 i32) (result (ref $type18))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type20))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type20
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type20
      (local.get $5)
      (local.get $2)
      (array.new_default $type19
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type18
   (i32.const 1)
   (local.get $0)
   (array.new_default $type19
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-block (type $101) (param $0 (ref $type18)) (param $1 i32) (result (ref $type19))
  (if (result (ref $type19))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type18 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type20
      (struct.get $type18 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy (type $100) (param $0 (ref $type18)) (param $1 i64) (param $2 (ref $type18)) (param $3 i64)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ne
     (local.get $1)
     (i64.const 0)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (local.get $3)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $4
     (local.get $7)
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $6
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $4)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $6)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $4
           (i32.sub
            (local.get $4)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $4)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $4)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $8
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $9
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (loop $label1
     (if
      (local.get $9)
      (then
       (local.set $4
        (select
         (local.get $9)
         (local.tee $4
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $5
              (i32.and
               (local.get $8)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $4
            (i32.sub
             (i32.const 8192)
             (local.tee $7
              (i32.and
               (local.get $10)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.gt_u
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i32.gt_u
          (local.get $4)
          (local.get $9)
         )
        )
       )
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $8)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $5)
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $10)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $10)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $7)
        (local.get $4)
       )
       (local.set $8
        (i32.add
         (local.get $4)
         (local.get $8)
        )
       )
       (local.set $10
        (i32.add
         (local.get $4)
         (local.get $10)
        )
       )
       (local.set $9
        (i32.sub
         (local.get $9)
         (local.get $4)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function30 (type $99) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 (ref null $type49)) (param $4 i64) (result (ref $type18))
  (local $5 i32)
  (if (result (ref $type18))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (local.get $3)
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $5)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $5)
      (i32.const 8191)
     )
     (i32.const 48)
    )
    (drop
     (ref.as_non_null
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function30
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (ref.null none)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function35 (type $98) (param $0 (ref $type61)) (result (ref $type18))
  (local $1 (ref null $type61))
  (local $2 (ref null $type61))
  (local $3 (ref null $type61))
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 i64)
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready91)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global91)
   )
  )
  (local.set $6
   (if (result i64)
    (i64.gt_u
     (local.tee $6
      (i64.extend_i32_u
       (struct.get $type18 1
        (struct.get $type61 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type61 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $6)
      )
      (else
       (local.set $3
        (struct.get $type61 1
         (local.get $1)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $6
          (i64.add
           (i64.extend_i32_u
            (struct.get $type18 1
             (struct.get $type61 0
              (local.get $1)
             )
            )
           )
           (local.get $6)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (local.get $6)
          )
          (else
           (local.set $2
            (struct.get $type61 1
             (local.get $3)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $6
              (i64.add
               (i64.extend_i32_u
                (struct.get $type18 1
                 (struct.get $type61 0
                  (local.get $3)
                 )
                )
               )
               (local.get $6)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $1
                (struct.get $type61 1
                 (local.get $2)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $6
                  (i64.add
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (struct.get $type61 0
                      (local.get $2)
                     )
                    )
                   )
                   (local.get $6)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $2
                    (struct.get $type61 1
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.tee $6
                      (i64.add
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (struct.get $type61 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.get $6)
                      )
                     )
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $1
                        (struct.get $type61 1
                         (local.get $2)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.tee $6
                          (i64.add
                           (i64.extend_i32_u
                            (struct.get $type18 1
                             (struct.get $type61 0
                              (local.get $2)
                             )
                            )
                           )
                           (local.get $6)
                          )
                         )
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $2
                            (struct.get $type61 1
                             (local.get $1)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.tee $6
                              (i64.add
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (struct.get $type61 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (local.get $6)
                              )
                             )
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (local.get $6)
                              )
                              (else
                               (local.set $1
                                (struct.get $type61 1
                                 (local.get $2)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.tee $6
                                  (i64.add
                                   (i64.extend_i32_u
                                    (struct.get $type18 1
                                     (struct.get $type61 0
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (local.get $6)
                                  )
                                 )
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (local.get $6)
                                  )
                                  (else
                                   (local.set $2
                                    (struct.get $type61 1
                                     (local.get $1)
                                    )
                                   )
                                   (if (result i64)
                                    (i64.gt_s
                                     (local.tee $6
                                      (i64.add
                                       (i64.extend_i32_u
                                        (struct.get $type18 1
                                         (struct.get $type61 0
                                          (local.get $1)
                                         )
                                        )
                                       )
                                       (local.get $6)
                                      )
                                     )
                                     (i64.const 4294967294)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.get $2)
                                      )
                                      (then
                                       (local.get $6)
                                      )
                                      (else
                                       (local.set $1
                                        (struct.get $type61 1
                                         (local.get $2)
                                        )
                                       )
                                       (if (result i64)
                                        (i64.gt_s
                                         (local.tee $6
                                          (i64.add
                                           (i64.extend_i32_u
                                            (struct.get $type18 1
                                             (struct.get $type61 0
                                              (local.get $2)
                                             )
                                            )
                                           )
                                           (local.get $6)
                                          )
                                         )
                                         (i64.const 4294967294)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                        (else
                                         (if (result i64)
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                          (then
                                           (local.get $6)
                                          )
                                          (else
                                           (local.set $2
                                            (struct.get $type61 1
                                             (local.get $1)
                                            )
                                           )
                                           (if (result i64)
                                            (i64.gt_s
                                             (local.tee $6
                                              (i64.add
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (struct.get $type61 0
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                               (local.get $6)
                                              )
                                             )
                                             (i64.const 4294967294)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                            (else
                                             (if (result i64)
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                              (then
                                               (local.get $6)
                                              )
                                              (else
                                               (local.set $1
                                                (struct.get $type61 1
                                                 (local.get $2)
                                                )
                                               )
                                               (if (result i64)
                                                (i64.gt_s
                                                 (local.tee $6
                                                  (i64.add
                                                   (i64.extend_i32_u
                                                    (struct.get $type18 1
                                                     (struct.get $type61 0
                                                      (local.get $2)
                                                     )
                                                    )
                                                   )
                                                   (local.get $6)
                                                  )
                                                 )
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                                (else
                                                 (if (result i64)
                                                  (ref.is_null
                                                   (local.get $1)
                                                  )
                                                  (then
                                                   (local.get $6)
                                                  )
                                                  (else
                                                   (local.set $2
                                                    (struct.get $type61 1
                                                     (local.get $1)
                                                    )
                                                   )
                                                   (if (result i64)
                                                    (i64.gt_s
                                                     (local.tee $6
                                                      (i64.add
                                                       (i64.extend_i32_u
                                                        (struct.get $type18 1
                                                         (struct.get $type61 0
                                                          (local.get $1)
                                                         )
                                                        )
                                                       )
                                                       (local.get $6)
                                                      )
                                                     )
                                                     (i64.const 4294967294)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                    (else
                                                     (if (result i64)
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                      (then
                                                       (local.get $6)
                                                      )
                                                      (else
                                                       (local.set $1
                                                        (struct.get $type61 1
                                                         (local.get $2)
                                                        )
                                                       )
                                                       (if (result i64)
                                                        (i64.gt_s
                                                         (local.tee $6
                                                          (i64.add
                                                           (i64.extend_i32_u
                                                            (struct.get $type18 1
                                                             (struct.get $type61 0
                                                              (local.get $2)
                                                             )
                                                            )
                                                           )
                                                           (local.get $6)
                                                          )
                                                         )
                                                         (i64.const 4294967294)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                        (else
                                                         (if (result i64)
                                                          (ref.is_null
                                                           (local.get $1)
                                                          )
                                                          (then
                                                           (local.get $6)
                                                          )
                                                          (else
                                                           (local.set $2
                                                            (struct.get $type61 1
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (if (result i64)
                                                            (i64.gt_s
                                                             (local.tee $6
                                                              (i64.add
                                                               (i64.extend_i32_u
                                                                (struct.get $type18 1
                                                                 (struct.get $type61 0
                                                                  (local.get $1)
                                                                 )
                                                                )
                                                               )
                                                               (local.get $6)
                                                              )
                                                             )
                                                             (i64.const 4294967294)
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                            (else
                                                             (if (result i64)
                                                              (ref.is_null
                                                               (local.get $2)
                                                              )
                                                              (then
                                                               (local.get $6)
                                                              )
                                                              (else
                                                               (local.set $1
                                                                (struct.get $type61 1
                                                                 (local.get $2)
                                                                )
                                                               )
                                                               (if (result i64)
                                                                (i64.gt_s
                                                                 (local.tee $6
                                                                  (i64.add
                                                                   (i64.extend_i32_u
                                                                    (struct.get $type18 1
                                                                     (struct.get $type61 0
                                                                      (local.get $2)
                                                                     )
                                                                    )
                                                                   )
                                                                   (local.get $6)
                                                                  )
                                                                 )
                                                                 (i64.const 4294967294)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                                (else
                                                                 (if (result i64)
                                                                  (ref.is_null
                                                                   (local.get $1)
                                                                  )
                                                                  (then
                                                                   (local.get $6)
                                                                  )
                                                                  (else
                                                                   (local.set $2
                                                                    (struct.get $type61 1
                                                                     (local.get $1)
                                                                    )
                                                                   )
                                                                   (if (result i64)
                                                                    (i64.gt_s
                                                                     (local.tee $6
                                                                      (i64.add
                                                                       (i64.extend_i32_u
                                                                        (struct.get $type18 1
                                                                         (struct.get $type61 0
                                                                          (local.get $1)
                                                                         )
                                                                        )
                                                                       )
                                                                       (local.get $6)
                                                                      )
                                                                     )
                                                                     (i64.const 4294967294)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                    (else
                                                                     (if (result i64)
                                                                      (ref.is_null
                                                                       (local.get $2)
                                                                      )
                                                                      (then
                                                                       (local.get $6)
                                                                      )
                                                                      (else
                                                                       (local.set $1
                                                                        (struct.get $type61 1
                                                                         (local.get $2)
                                                                        )
                                                                       )
                                                                       (if (result i64)
                                                                        (i64.gt_s
                                                                         (local.tee $6
                                                                          (i64.add
                                                                           (i64.extend_i32_u
                                                                            (struct.get $type18 1
                                                                             (struct.get $type61 0
                                                                              (local.get $2)
                                                                             )
                                                                            )
                                                                           )
                                                                           (local.get $6)
                                                                          )
                                                                         )
                                                                         (i64.const 4294967294)
                                                                        )
                                                                        (then
                                                                         (unreachable)
                                                                        )
                                                                        (else
                                                                         (if (result i64)
                                                                          (ref.is_null
                                                                           (local.get $1)
                                                                          )
                                                                          (then
                                                                           (local.get $6)
                                                                          )
                                                                          (else
                                                                           (call $function37
                                                                            (i32.const 0)
                                                                            (i32.const 1)
                                                                            (struct.get $type61 1
                                                                             (local.get $1)
                                                                            )
                                                                            (i64.add
                                                                             (i64.extend_i32_u
                                                                              (struct.get $type18 1
                                                                               (struct.get $type61 0
                                                                                (local.get $1)
                                                                               )
                                                                              )
                                                                             )
                                                                             (local.get $6)
                                                                            )
                                                                           )
                                                                          )
                                                                         )
                                                                        )
                                                                       )
                                                                      )
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call $string-new
    (i32.wrap_i64
     (local.get $6)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready96)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global96)
   )
  )
  (call $string-copy
   (local.get $5)
   (i64.const 0)
   (local.tee $4
    (struct.get $type61 0
     (local.get $0)
    )
   )
   (local.tee $7
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $4)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready96)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global96)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.tee $1
      (struct.get $type61 1
       (local.get $0)
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (call $string-copy
      (local.get $5)
      (local.get $7)
      (local.tee $4
       (struct.get $type61 0
        (local.get $1)
       )
      )
      (local.tee $6
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $4)
        )
       )
      )
     )
     (local.set $1
      (struct.get $type61 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready96)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global96)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $string-copy
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $6)
          (local.get $7)
         )
        )
        (local.tee $4
         (struct.get $type61 0
          (local.get $1)
         )
        )
        (local.tee $6
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $4)
          )
         )
        )
       )
       (local.set $1
        (struct.get $type61 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready96)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global96)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $string-copy
          (local.get $5)
          (local.tee $7
           (i64.add
            (local.get $6)
            (local.get $7)
           )
          )
          (local.tee $4
           (struct.get $type61 0
            (local.get $1)
           )
          )
          (local.tee $6
           (i64.extend_i32_u
            (struct.get $type18 1
             (local.get $4)
            )
           )
          )
         )
         (local.set $1
          (struct.get $type61 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready96)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global96)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $string-copy
            (local.get $5)
            (local.tee $7
             (i64.add
              (local.get $6)
              (local.get $7)
             )
            )
            (local.tee $4
             (struct.get $type61 0
              (local.get $1)
             )
            )
            (local.tee $6
             (i64.extend_i32_u
              (struct.get $type18 1
               (local.get $4)
              )
             )
            )
           )
           (local.set $1
            (struct.get $type61 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready96)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global96)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $string-copy
              (local.get $5)
              (local.tee $7
               (i64.add
                (local.get $6)
                (local.get $7)
               )
              )
              (local.tee $4
               (struct.get $type61 0
                (local.get $1)
               )
              )
              (local.tee $6
               (i64.extend_i32_u
                (struct.get $type18 1
                 (local.get $4)
                )
               )
              )
             )
             (local.set $1
              (struct.get $type61 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready96)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global96)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $string-copy
                (local.get $5)
                (local.tee $7
                 (i64.add
                  (local.get $6)
                  (local.get $7)
                 )
                )
                (local.tee $4
                 (struct.get $type61 0
                  (local.get $1)
                 )
                )
                (local.tee $6
                 (i64.extend_i32_u
                  (struct.get $type18 1
                   (local.get $4)
                  )
                 )
                )
               )
               (local.set $1
                (struct.get $type61 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready96)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global96)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $string-copy
                  (local.get $5)
                  (local.tee $7
                   (i64.add
                    (local.get $6)
                    (local.get $7)
                   )
                  )
                  (local.tee $4
                   (struct.get $type61 0
                    (local.get $1)
                   )
                  )
                  (local.tee $6
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (local.set $1
                  (struct.get $type61 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready96)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global96)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $string-copy
                    (local.get $5)
                    (local.tee $7
                     (i64.add
                      (local.get $6)
                      (local.get $7)
                     )
                    )
                    (local.tee $4
                     (struct.get $type61 0
                      (local.get $1)
                     )
                    )
                    (local.tee $6
                     (i64.extend_i32_u
                      (struct.get $type18 1
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (local.set $1
                    (struct.get $type61 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready96)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global96)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $string-copy
                      (local.get $5)
                      (local.tee $7
                       (i64.add
                        (local.get $6)
                        (local.get $7)
                       )
                      )
                      (local.tee $4
                       (struct.get $type61 0
                        (local.get $1)
                       )
                      )
                      (local.tee $6
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.set $1
                      (struct.get $type61 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready96)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global96)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $string-copy
                        (local.get $5)
                        (local.tee $7
                         (i64.add
                          (local.get $6)
                          (local.get $7)
                         )
                        )
                        (local.tee $4
                         (struct.get $type61 0
                          (local.get $1)
                         )
                        )
                        (local.tee $6
                         (i64.extend_i32_u
                          (struct.get $type18 1
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (local.set $1
                        (struct.get $type61 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready96)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global96)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $1)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (call $string-copy
                          (local.get $5)
                          (local.tee $7
                           (i64.add
                            (local.get $6)
                            (local.get $7)
                           )
                          )
                          (local.tee $4
                           (struct.get $type61 0
                            (local.get $1)
                           )
                          )
                          (local.tee $6
                           (i64.extend_i32_u
                            (struct.get $type18 1
                             (local.get $4)
                            )
                           )
                          )
                         )
                         (local.set $1
                          (struct.get $type61 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready96)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global96)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (call $string-copy
                            (local.get $5)
                            (local.tee $7
                             (i64.add
                              (local.get $6)
                              (local.get $7)
                             )
                            )
                            (local.tee $4
                             (struct.get $type61 0
                              (local.get $1)
                             )
                            )
                            (local.tee $6
                             (i64.extend_i32_u
                              (struct.get $type18 1
                               (local.get $4)
                              )
                             )
                            )
                           )
                           (local.set $1
                            (struct.get $type61 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready96)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global96)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (call $string-copy
                              (local.get $5)
                              (local.tee $7
                               (i64.add
                                (local.get $6)
                                (local.get $7)
                               )
                              )
                              (local.tee $4
                               (struct.get $type61 0
                                (local.get $1)
                               )
                              )
                              (local.tee $6
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (local.set $1
                              (struct.get $type61 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready96)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global96)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $1)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (call $string-copy
                                (local.get $5)
                                (local.tee $7
                                 (i64.add
                                  (local.get $6)
                                  (local.get $7)
                                 )
                                )
                                (local.tee $4
                                 (struct.get $type61 0
                                  (local.get $1)
                                 )
                                )
                                (local.tee $6
                                 (i64.extend_i32_u
                                  (struct.get $type18 1
                                   (local.get $4)
                                  )
                                 )
                                )
                               )
                               (local.set $1
                                (struct.get $type61 1
                                 (local.get $1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready96)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global96)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $1)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (call $string-copy
                                  (local.get $5)
                                  (local.tee $7
                                   (i64.add
                                    (local.get $6)
                                    (local.get $7)
                                   )
                                  )
                                  (local.tee $4
                                   (struct.get $type61 0
                                    (local.get $1)
                                   )
                                  )
                                  (local.tee $6
                                   (i64.extend_i32_u
                                    (struct.get $type18 1
                                     (local.get $4)
                                    )
                                   )
                                  )
                                 )
                                 (local.set $1
                                  (struct.get $type61 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready96)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global96)
                                  )
                                 )
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (call $string-copy
                                    (local.get $5)
                                    (local.tee $7
                                     (i64.add
                                      (local.get $6)
                                      (local.get $7)
                                     )
                                    )
                                    (local.tee $4
                                     (struct.get $type61 0
                                      (local.get $1)
                                     )
                                    )
                                    (local.tee $6
                                     (i64.extend_i32_u
                                      (struct.get $type18 1
                                       (local.get $4)
                                      )
                                     )
                                    )
                                   )
                                   (local.set $1
                                    (struct.get $type61 1
                                     (local.get $1)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready96)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global96)
                                    )
                                   )
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (call $string-copy
                                      (local.get $5)
                                      (local.tee $7
                                       (i64.add
                                        (local.get $6)
                                        (local.get $7)
                                       )
                                      )
                                      (local.tee $4
                                       (struct.get $type61 0
                                        (local.get $1)
                                       )
                                      )
                                      (local.tee $6
                                       (i64.extend_i32_u
                                        (struct.get $type18 1
                                         (local.get $4)
                                        )
                                       )
                                      )
                                     )
                                     (local.set $1
                                      (struct.get $type61 1
                                       (local.get $1)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready96)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global96)
                                      )
                                     )
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $1)
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (call $string-copy
                                        (local.get $5)
                                        (local.tee $7
                                         (i64.add
                                          (local.get $6)
                                          (local.get $7)
                                         )
                                        )
                                        (local.tee $4
                                         (struct.get $type61 0
                                          (local.get $1)
                                         )
                                        )
                                        (local.tee $6
                                         (i64.extend_i32_u
                                          (struct.get $type18 1
                                           (local.get $4)
                                          )
                                         )
                                        )
                                       )
                                       (local.set $1
                                        (struct.get $type61 1
                                         (local.get $1)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready96)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global96)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $1)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (call $string-copy
                                          (local.get $5)
                                          (local.tee $7
                                           (i64.add
                                            (local.get $6)
                                            (local.get $7)
                                           )
                                          )
                                          (local.tee $4
                                           (struct.get $type61 0
                                            (local.get $1)
                                           )
                                          )
                                          (local.tee $6
                                           (i64.extend_i32_u
                                            (struct.get $type18 1
                                             (local.get $4)
                                            )
                                           )
                                          )
                                         )
                                         (local.set $1
                                          (struct.get $type61 1
                                           (local.get $1)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready96)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global96)
                                          )
                                         )
                                         (call $function38
                                          (local.get $5)
                                          (local.get $1)
                                          (i64.add
                                           (local.get $6)
                                           (local.get $7)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $5)
 )
 (func $function37 (type $96) (param $0 i32) (param $1 i32) (param $2 (ref null $type61)) (param $3 i64) (result i64)
  (local $4 (ref null $type61))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $4
       (struct.get $type61 1
        (local.get $2)
       )
      )
      (local.set $5
       (i64.extend_i32_u
        (struct.get $type18 1
         (struct.get $type61 0
          (local.get $2)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (i64.add
        (local.get $3)
        (local.get $5)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call63) (param $0 (ref $type18)) (param $1 (ref null $type61)) (param $2 i64) (result i32)
  (local $3 (ref $type18))
  (local $4 i64)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $3
      (struct.get $type61 0
       (local.get $1)
      )
     )
     (local.tee $4
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $3)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type61 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready96)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global96)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function40 (type $94) (param $0 (ref $type18)) (param $1 (ref $type18)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $4)
   )
   (then
    (i32.const 1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $1)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $1)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call65) (param $0 (ref $type29)) (param $1 i64) (result i64)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_s
   (array.get $type29
    (local.get $0)
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
 )
 (func $function42 (type $91) (param $0 (ref $type29)) (param $1 i64) (param $2 i64)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type29
   (local.get $0)
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.wrap_i64
    (local.get $2)
   )
  )
 )
 (func $function44 (type $call68) (param $0 (ref $type29)) (result i64)
  (local $1 i64)
  (local $2 i64)
  (if (result i64)
   (if (result i32)
    (i64.eqz
     (local.tee $1
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (if
      (i64.gt_u
       (local.tee $2
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.ne
      (i64.extend_i32_s
       (array.get $type29
        (local.get $0)
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (i64.const 0)
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if (result i64)
     (if (result i32)
      (i64.eqz
       (local.tee $1
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global109)
        )
       )
       (if
        (i64.gt_u
         (local.tee $2
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i64.ne
        (i64.extend_i32_s
         (array.get $type29
          (local.get $0)
          (i32.wrap_i64
           (local.get $2)
          )
         )
        )
        (i64.const 0)
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (if (result i64)
       (if (result i32)
        (i64.eqz
         (local.tee $1
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
        )
        (then
         (i32.const 1)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global109)
          )
         )
         (if
          (i64.gt_u
           (local.tee $2
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i64.ne
          (i64.extend_i32_s
           (array.get $type29
            (local.get $0)
            (i32.wrap_i64
             (local.get $2)
            )
           )
          )
          (i64.const 0)
         )
        )
       )
       (then
        (local.get $1)
       )
       (else
        (if (result i64)
         (if (result i32)
          (i64.eqz
           (local.tee $1
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
          )
          (then
           (i32.const 1)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global109)
            )
           )
           (if
            (i64.gt_u
             (local.tee $2
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i64.ne
            (i64.extend_i32_s
             (array.get $type29
              (local.get $0)
              (i32.wrap_i64
               (local.get $2)
              )
             )
            )
            (i64.const 0)
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (if (result i64)
           (if (result i32)
            (i64.eqz
             (local.tee $1
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
            )
            (then
             (i32.const 1)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global109)
              )
             )
             (if
              (i64.gt_u
               (local.tee $2
                (i64.sub
                 (local.get $1)
                 (i64.const 1)
                )
               )
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (i64.ne
              (i64.extend_i32_s
               (array.get $type29
                (local.get $0)
                (i32.wrap_i64
                 (local.get $2)
                )
               )
              )
              (i64.const 0)
             )
            )
           )
           (then
            (local.get $1)
           )
           (else
            (if (result i64)
             (if (result i32)
              (i64.eqz
               (local.tee $1
                (i64.sub
                 (local.get $1)
                 (i64.const 1)
                )
               )
              )
              (then
               (i32.const 1)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global109)
                )
               )
               (if
                (i64.gt_u
                 (local.tee $2
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (i64.ne
                (i64.extend_i32_s
                 (array.get $type29
                  (local.get $0)
                  (i32.wrap_i64
                   (local.get $2)
                  )
                 )
                )
                (i64.const 0)
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (if (result i64)
               (if (result i32)
                (i64.eqz
                 (local.tee $1
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (i32.const 1)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global109)
                  )
                 )
                 (if
                  (i64.gt_u
                   (local.tee $2
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (i64.ne
                  (i64.extend_i32_s
                   (array.get $type29
                    (local.get $0)
                    (i32.wrap_i64
                     (local.get $2)
                    )
                   )
                  )
                  (i64.const 0)
                 )
                )
               )
               (then
                (local.get $1)
               )
               (else
                (if (result i64)
                 (if (result i32)
                  (i64.eqz
                   (local.tee $1
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (i32.const 1)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global109)
                    )
                   )
                   (if
                    (i64.gt_u
                     (local.tee $2
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                     (i64.const 4294967295)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (i64.ne
                    (i64.extend_i32_s
                     (array.get $type29
                      (local.get $0)
                      (i32.wrap_i64
                       (local.get $2)
                      )
                     )
                    )
                    (i64.const 0)
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (if (result i64)
                   (if (result i32)
                    (i64.eqz
                     (local.tee $1
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (i32.const 1)
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global109)
                      )
                     )
                     (if
                      (i64.gt_u
                       (local.tee $2
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                       (i64.const 4294967295)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (i64.ne
                      (i64.extend_i32_s
                       (array.get $type29
                        (local.get $0)
                        (i32.wrap_i64
                         (local.get $2)
                        )
                       )
                      )
                      (i64.const 0)
                     )
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (if (result i64)
                     (if (result i32)
                      (i64.eqz
                       (local.tee $1
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (i32.const 1)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global109)
                        )
                       )
                       (if
                        (i64.gt_u
                         (local.tee $2
                          (i64.sub
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                         (i64.const 4294967295)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (i64.ne
                        (i64.extend_i32_s
                         (array.get $type29
                          (local.get $0)
                          (i32.wrap_i64
                           (local.get $2)
                          )
                         )
                        )
                        (i64.const 0)
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (if (result i64)
                       (if (result i32)
                        (i64.eqz
                         (local.tee $1
                          (i64.sub
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (i32.const 1)
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global109)
                          )
                         )
                         (if
                          (i64.gt_u
                           (local.tee $2
                            (i64.sub
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                           (i64.const 4294967295)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (i64.ne
                          (i64.extend_i32_s
                           (array.get $type29
                            (local.get $0)
                            (i32.wrap_i64
                             (local.get $2)
                            )
                           )
                          )
                          (i64.const 0)
                         )
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (if (result i64)
                         (if (result i32)
                          (i64.eqz
                           (local.tee $1
                            (i64.sub
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (i32.const 1)
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global109)
                            )
                           )
                           (if
                            (i64.gt_u
                             (local.tee $2
                              (i64.sub
                               (local.get $1)
                               (i64.const 1)
                              )
                             )
                             (i64.const 4294967295)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (i64.ne
                            (i64.extend_i32_s
                             (array.get $type29
                              (local.get $0)
                              (i32.wrap_i64
                               (local.get $2)
                              )
                             )
                            )
                            (i64.const 0)
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (if (result i64)
                           (if (result i32)
                            (i64.eqz
                             (local.tee $1
                              (i64.sub
                               (local.get $1)
                               (i64.const 1)
                              )
                             )
                            )
                            (then
                             (i32.const 1)
                            )
                            (else
                             (drop
                              (ref.as_non_null
                               (global.get $global109)
                              )
                             )
                             (if
                              (i64.gt_u
                               (local.tee $2
                                (i64.sub
                                 (local.get $1)
                                 (i64.const 1)
                                )
                               )
                               (i64.const 4294967295)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (i64.ne
                              (i64.extend_i32_s
                               (array.get $type29
                                (local.get $0)
                                (i32.wrap_i64
                                 (local.get $2)
                                )
                               )
                              )
                              (i64.const 0)
                             )
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (if (result i64)
                             (if (result i32)
                              (i64.eqz
                               (local.tee $1
                                (i64.sub
                                 (local.get $1)
                                 (i64.const 1)
                                )
                               )
                              )
                              (then
                               (i32.const 1)
                              )
                              (else
                               (drop
                                (ref.as_non_null
                                 (global.get $global109)
                                )
                               )
                               (if
                                (i64.gt_u
                                 (local.tee $2
                                  (i64.sub
                                   (local.get $1)
                                   (i64.const 1)
                                  )
                                 )
                                 (i64.const 4294967295)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (i64.ne
                                (i64.extend_i32_s
                                 (array.get $type29
                                  (local.get $0)
                                  (i32.wrap_i64
                                   (local.get $2)
                                  )
                                 )
                                )
                                (i64.const 0)
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (if (result i64)
                               (if (result i32)
                                (i64.eqz
                                 (local.tee $1
                                  (i64.sub
                                   (local.get $1)
                                   (i64.const 1)
                                  )
                                 )
                                )
                                (then
                                 (i32.const 1)
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global109)
                                  )
                                 )
                                 (if
                                  (i64.gt_u
                                   (local.tee $2
                                    (i64.sub
                                     (local.get $1)
                                     (i64.const 1)
                                    )
                                   )
                                   (i64.const 4294967295)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (i64.ne
                                  (i64.extend_i32_s
                                   (array.get $type29
                                    (local.get $0)
                                    (i32.wrap_i64
                                     (local.get $2)
                                    )
                                   )
                                  )
                                  (i64.const 0)
                                 )
                                )
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (if (result i64)
                                 (if (result i32)
                                  (i64.eqz
                                   (local.tee $1
                                    (i64.sub
                                     (local.get $1)
                                     (i64.const 1)
                                    )
                                   )
                                  )
                                  (then
                                   (i32.const 1)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global109)
                                    )
                                   )
                                   (if
                                    (i64.gt_u
                                     (local.tee $2
                                      (i64.sub
                                       (local.get $1)
                                       (i64.const 1)
                                      )
                                     )
                                     (i64.const 4294967295)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (i64.ne
                                    (i64.extend_i32_s
                                     (array.get $type29
                                      (local.get $0)
                                      (i32.wrap_i64
                                       (local.get $2)
                                      )
                                     )
                                    )
                                    (i64.const 0)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (if (result i64)
                                   (if (result i32)
                                    (i64.eqz
                                     (local.tee $1
                                      (i64.sub
                                       (local.get $1)
                                       (i64.const 1)
                                      )
                                     )
                                    )
                                    (then
                                     (i32.const 1)
                                    )
                                    (else
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global109)
                                      )
                                     )
                                     (if
                                      (i64.gt_u
                                       (local.tee $2
                                        (i64.sub
                                         (local.get $1)
                                         (i64.const 1)
                                        )
                                       )
                                       (i64.const 4294967295)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (i64.ne
                                      (i64.extend_i32_s
                                       (array.get $type29
                                        (local.get $0)
                                        (i32.wrap_i64
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (if (result i64)
                                     (if (result i32)
                                      (i64.eqz
                                       (local.tee $1
                                        (i64.sub
                                         (local.get $1)
                                         (i64.const 1)
                                        )
                                       )
                                      )
                                      (then
                                       (i32.const 1)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global109)
                                        )
                                       )
                                       (if
                                        (i64.gt_u
                                         (local.tee $2
                                          (i64.sub
                                           (local.get $1)
                                           (i64.const 1)
                                          )
                                         )
                                         (i64.const 4294967295)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (i64.ne
                                        (i64.extend_i32_s
                                         (array.get $type29
                                          (local.get $0)
                                          (i32.wrap_i64
                                           (local.get $2)
                                          )
                                         )
                                        )
                                        (i64.const 0)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (if (result i64)
                                       (if (result i32)
                                        (i64.eqz
                                         (local.tee $1
                                          (i64.sub
                                           (local.get $1)
                                           (i64.const 1)
                                          )
                                         )
                                        )
                                        (then
                                         (i32.const 1)
                                        )
                                        (else
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global109)
                                          )
                                         )
                                         (if
                                          (i64.gt_u
                                           (local.tee $2
                                            (i64.sub
                                             (local.get $1)
                                             (i64.const 1)
                                            )
                                           )
                                           (i64.const 4294967295)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (i64.ne
                                          (i64.extend_i32_s
                                           (array.get $type29
                                            (local.get $0)
                                            (i32.wrap_i64
                                             (local.get $2)
                                            )
                                           )
                                          )
                                          (i64.const 0)
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (if (result i64)
                                         (if (result i32)
                                          (i64.eqz
                                           (local.tee $1
                                            (i64.sub
                                             (local.get $1)
                                             (i64.const 1)
                                            )
                                           )
                                          )
                                          (then
                                           (i32.const 1)
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global109)
                                            )
                                           )
                                           (i64.ne
                                            (call $function41
                                             (local.get $0)
                                             (i64.sub
                                              (local.get $1)
                                              (i64.const 1)
                                             )
                                            )
                                            (i64.const 0)
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (return_call $function45
                                           (local.get $0)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.sub
                                            (local.get $1)
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function45 (type $89) (param $0 (ref $type29)) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (if (result i64)
   (if (result i32)
    (i64.eqz
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (i64.ne
      (call $function41
       (local.get $0)
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function46 (type $call52) (param $0 (ref $type29)) (result (ref $type29))
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if (result (ref $type29))
   (i64.eq
    (local.tee $1
     (call $function44
      (local.get $0)
     )
    )
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type29 $type29
     (local.tee $3
      (array.new_default $type29
       (local.tee $2
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (i32.const 0)
     (local.get $0)
     (i32.const 0)
     (local.get $2)
    )
    (local.get $3)
   )
  )
 )
 (func $function47 (type $87) (param $0 i32) (param $1 (ref $type29)) (result (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (if (result (ref $type28))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.tee $1
       (call $function46
        (local.get $1)
       )
      )
     )
    )
   )
   (then
    (ref.as_non_null
     (global.get $global108)
    )
   )
   (else
    (struct.new $type28
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function48 (type $call70) (param $0 (ref $type28)) (result i32)
  (i64.eqz
   (i64.extend_i32_u
    (array.len
     (struct.get $type28 1
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function51 (type $call72) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 1073741824)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 1073741824)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 1073741824)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 1073741824)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 1073741824)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 1073741824)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 1073741824)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 1073741824)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 1073741824)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 1073741824)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 1073741824)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 1073741824)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 1073741824)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (if (result i64)
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 1073741824)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 15)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 1073741824)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 16)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 1073741824)
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 17)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 1073741824)
                                         )
                                        )
                                       )
                                       (then
                                        (i64.const 18)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                          )
                                         )
                                         (then
                                          (i64.const 19)
                                         )
                                         (else
                                          (return_call $function52
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function52 (type $84) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 1073741824)
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function53 (type $call73) (param $0 i64) (result (ref $type28))
  (local $1 (ref $type29))
  (local $2 (ref $type29))
  (local $3 i32)
  (local $4 i64)
  (local $5 i64)
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (local.set $5
   (call $function51
    (local.tee $4
     (select
      (i64.sub
       (i64.const 0)
       (local.get $0)
      )
      (local.get $0)
      (i64.gt_s
       (local.get $0)
       (i64.const 0)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i64.gt_u
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
  )
  (local.set $1
   (array.new_default $type29
    (i32.wrap_i64
     (local.get $5)
    )
   )
  )
  (if (result (ref $type28))
   (i64.eqz
    (local.get $4)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function46
          (local.get $1)
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type28
       (local.get $3)
       (local.get $2)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (array.set $type29
     (local.get $1)
     (i32.const 0)
     (i32.wrap_i64
      (i64.sub
       (i64.const 0)
       (i64.rem_s
        (local.get $4)
        (i64.const 1073741824)
       )
      )
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $4)
        (i64.const 1073741824)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global126)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global122)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function46
            (local.get $1)
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type28
         (local.get $3)
         (local.get $2)
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global112)
       )
      )
      (array.set $type29
       (local.get $1)
       (i32.const 1)
       (i32.wrap_i64
        (i64.sub
         (i64.const 0)
         (i64.rem_s
          (local.get $0)
          (i64.const 1073741824)
         )
        )
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 1073741824)
         )
        )
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global126)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global122)
         )
        )
        (if (result (ref $type28))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (local.tee $2
             (call $function46
              (local.get $1)
             )
            )
           )
          )
         )
         (then
          (ref.as_non_null
           (global.get $global108)
          )
         )
         (else
          (struct.new $type28
           (local.get $3)
           (local.get $2)
          )
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global112)
         )
        )
        (array.set $type29
         (local.get $1)
         (i32.const 2)
         (i32.wrap_i64
          (i64.sub
           (i64.const 0)
           (i64.rem_s
            (local.get $0)
            (i64.const 1073741824)
           )
          )
         )
        )
        (if (result (ref $type28))
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 1073741824)
           )
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global126)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global122)
           )
          )
          (if (result (ref $type28))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (local.tee $2
               (call $function46
                (local.get $1)
               )
              )
             )
            )
           )
           (then
            (ref.as_non_null
             (global.get $global108)
            )
           )
           (else
            (struct.new $type28
             (local.get $3)
             (local.get $2)
            )
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global112)
           )
          )
          (array.set $type29
           (local.get $1)
           (i32.const 3)
           (i32.wrap_i64
            (i64.sub
             (i64.const 0)
             (i64.rem_s
              (local.get $0)
              (i64.const 1073741824)
             )
            )
           )
          )
          (if (result (ref $type28))
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 1073741824)
             )
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global126)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global122)
             )
            )
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function46
                  (local.get $1)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global108)
              )
             )
             (else
              (struct.new $type28
               (local.get $3)
               (local.get $2)
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global112)
             )
            )
            (array.set $type29
             (local.get $1)
             (i32.const 4)
             (i32.wrap_i64
              (i64.sub
               (i64.const 0)
               (i64.rem_s
                (local.get $0)
                (i64.const 1073741824)
               )
              )
             )
            )
            (if (result (ref $type28))
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 1073741824)
               )
              )
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global126)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global122)
               )
              )
              (if (result (ref $type28))
               (i64.eqz
                (i64.extend_i32_u
                 (array.len
                  (local.tee $2
                   (call $function46
                    (local.get $1)
                   )
                  )
                 )
                )
               )
               (then
                (ref.as_non_null
                 (global.get $global108)
                )
               )
               (else
                (struct.new $type28
                 (local.get $3)
                 (local.get $2)
                )
               )
              )
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global112)
               )
              )
              (array.set $type29
               (local.get $1)
               (i32.const 5)
               (i32.wrap_i64
                (i64.sub
                 (i64.const 0)
                 (i64.rem_s
                  (local.get $0)
                  (i64.const 1073741824)
                 )
                )
               )
              )
              (if (result (ref $type28))
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 1073741824)
                 )
                )
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global126)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global122)
                 )
                )
                (if (result (ref $type28))
                 (i64.eqz
                  (i64.extend_i32_u
                   (array.len
                    (local.tee $2
                     (call $function46
                      (local.get $1)
                     )
                    )
                   )
                  )
                 )
                 (then
                  (ref.as_non_null
                   (global.get $global108)
                  )
                 )
                 (else
                  (struct.new $type28
                   (local.get $3)
                   (local.get $2)
                  )
                 )
                )
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global112)
                 )
                )
                (array.set $type29
                 (local.get $1)
                 (i32.const 6)
                 (i32.wrap_i64
                  (i64.sub
                   (i64.const 0)
                   (i64.rem_s
                    (local.get $0)
                    (i64.const 1073741824)
                   )
                  )
                 )
                )
                (if (result (ref $type28))
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 1073741824)
                   )
                  )
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global126)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global122)
                   )
                  )
                  (if (result (ref $type28))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (local.tee $2
                       (call $function46
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                   (then
                    (ref.as_non_null
                     (global.get $global108)
                    )
                   )
                   (else
                    (struct.new $type28
                     (local.get $3)
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global112)
                   )
                  )
                  (array.set $type29
                   (local.get $1)
                   (i32.const 7)
                   (i32.wrap_i64
                    (i64.sub
                     (i64.const 0)
                     (i64.rem_s
                      (local.get $0)
                      (i64.const 1073741824)
                     )
                    )
                   )
                  )
                  (if (result (ref $type28))
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 1073741824)
                     )
                    )
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global126)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global122)
                     )
                    )
                    (if (result (ref $type28))
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (local.tee $2
                         (call $function46
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                     (then
                      (ref.as_non_null
                       (global.get $global108)
                      )
                     )
                     (else
                      (struct.new $type28
                       (local.get $3)
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global112)
                     )
                    )
                    (array.set $type29
                     (local.get $1)
                     (i32.const 8)
                     (i32.wrap_i64
                      (i64.sub
                       (i64.const 0)
                       (i64.rem_s
                        (local.get $0)
                        (i64.const 1073741824)
                       )
                      )
                     )
                    )
                    (if (result (ref $type28))
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 1073741824)
                       )
                      )
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global126)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global122)
                       )
                      )
                      (if (result (ref $type28))
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (local.tee $2
                           (call $function46
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (then
                        (ref.as_non_null
                         (global.get $global108)
                        )
                       )
                       (else
                        (struct.new $type28
                         (local.get $3)
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global112)
                       )
                      )
                      (array.set $type29
                       (local.get $1)
                       (i32.const 9)
                       (i32.wrap_i64
                        (i64.sub
                         (i64.const 0)
                         (i64.rem_s
                          (local.get $0)
                          (i64.const 1073741824)
                         )
                        )
                       )
                      )
                      (if (result (ref $type28))
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 1073741824)
                         )
                        )
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global126)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global122)
                         )
                        )
                        (if (result (ref $type28))
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (local.tee $2
                             (call $function46
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                         (then
                          (ref.as_non_null
                           (global.get $global108)
                          )
                         )
                         (else
                          (struct.new $type28
                           (local.get $3)
                           (local.get $2)
                          )
                         )
                        )
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global112)
                         )
                        )
                        (array.set $type29
                         (local.get $1)
                         (i32.const 10)
                         (i32.wrap_i64
                          (i64.sub
                           (i64.const 0)
                           (i64.rem_s
                            (local.get $0)
                            (i64.const 1073741824)
                           )
                          )
                         )
                        )
                        (if (result (ref $type28))
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 1073741824)
                           )
                          )
                         )
                         (then
                          (drop
                           (ref.as_non_null
                            (global.get $global126)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global122)
                           )
                          )
                          (if (result (ref $type28))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (local.tee $2
                               (call $function46
                                (local.get $1)
                               )
                              )
                             )
                            )
                           )
                           (then
                            (ref.as_non_null
                             (global.get $global108)
                            )
                           )
                           (else
                            (struct.new $type28
                             (local.get $3)
                             (local.get $2)
                            )
                           )
                          )
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global112)
                           )
                          )
                          (array.set $type29
                           (local.get $1)
                           (i32.const 11)
                           (i32.wrap_i64
                            (i64.sub
                             (i64.const 0)
                             (i64.rem_s
                              (local.get $0)
                              (i64.const 1073741824)
                             )
                            )
                           )
                          )
                          (if (result (ref $type28))
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 1073741824)
                             )
                            )
                           )
                           (then
                            (drop
                             (ref.as_non_null
                              (global.get $global126)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global122)
                             )
                            )
                            (if (result (ref $type28))
                             (i64.eqz
                              (i64.extend_i32_u
                               (array.len
                                (local.tee $2
                                 (call $function46
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                             )
                             (then
                              (ref.as_non_null
                               (global.get $global108)
                              )
                             )
                             (else
                              (struct.new $type28
                               (local.get $3)
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global112)
                             )
                            )
                            (array.set $type29
                             (local.get $1)
                             (i32.const 12)
                             (i32.wrap_i64
                              (i64.sub
                               (i64.const 0)
                               (i64.rem_s
                                (local.get $0)
                                (i64.const 1073741824)
                               )
                              )
                             )
                            )
                            (if (result (ref $type28))
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 1073741824)
                               )
                              )
                             )
                             (then
                              (drop
                               (ref.as_non_null
                                (global.get $global126)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global122)
                               )
                              )
                              (if (result (ref $type28))
                               (i64.eqz
                                (i64.extend_i32_u
                                 (array.len
                                  (local.tee $2
                                   (call $function46
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                               (then
                                (ref.as_non_null
                                 (global.get $global108)
                                )
                               )
                               (else
                                (struct.new $type28
                                 (local.get $3)
                                 (local.get $2)
                                )
                               )
                              )
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global112)
                               )
                              )
                              (array.set $type29
                               (local.get $1)
                               (i32.const 13)
                               (i32.wrap_i64
                                (i64.sub
                                 (i64.const 0)
                                 (i64.rem_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                )
                               )
                              )
                              (if (result (ref $type28))
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                )
                               )
                               (then
                                (drop
                                 (ref.as_non_null
                                  (global.get $global126)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global122)
                                 )
                                )
                                (if (result (ref $type28))
                                 (i64.eqz
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.tee $2
                                     (call $function46
                                      (local.get $1)
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (ref.as_non_null
                                   (global.get $global108)
                                  )
                                 )
                                 (else
                                  (struct.new $type28
                                   (local.get $3)
                                   (local.get $2)
                                  )
                                 )
                                )
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global112)
                                 )
                                )
                                (array.set $type29
                                 (local.get $1)
                                 (i32.const 14)
                                 (i32.wrap_i64
                                  (i64.sub
                                   (i64.const 0)
                                   (i64.rem_s
                                    (local.get $0)
                                    (i64.const 1073741824)
                                   )
                                  )
                                 )
                                )
                                (if (result (ref $type28))
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 1073741824)
                                   )
                                  )
                                 )
                                 (then
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global126)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global122)
                                   )
                                  )
                                  (if (result (ref $type28))
                                   (i64.eqz
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.tee $2
                                       (call $function46
                                        (local.get $1)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (ref.as_non_null
                                     (global.get $global108)
                                    )
                                   )
                                   (else
                                    (struct.new $type28
                                     (local.get $3)
                                     (local.get $2)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global112)
                                   )
                                  )
                                  (array.set $type29
                                   (local.get $1)
                                   (i32.const 15)
                                   (i32.wrap_i64
                                    (i64.sub
                                     (i64.const 0)
                                     (i64.rem_s
                                      (local.get $0)
                                      (i64.const 1073741824)
                                     )
                                    )
                                   )
                                  )
                                  (if (result (ref $type28))
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 1073741824)
                                     )
                                    )
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global126)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global122)
                                     )
                                    )
                                    (if (result (ref $type28))
                                     (i64.eqz
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.tee $2
                                         (call $function46
                                          (local.get $1)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (ref.as_non_null
                                       (global.get $global108)
                                      )
                                     )
                                     (else
                                      (struct.new $type28
                                       (local.get $3)
                                       (local.get $2)
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global112)
                                     )
                                    )
                                    (array.set $type29
                                     (local.get $1)
                                     (i32.const 16)
                                     (i32.wrap_i64
                                      (i64.sub
                                       (i64.const 0)
                                       (i64.rem_s
                                        (local.get $0)
                                        (i64.const 1073741824)
                                       )
                                      )
                                     )
                                    )
                                    (if (result (ref $type28))
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 1073741824)
                                       )
                                      )
                                     )
                                     (then
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global126)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global122)
                                       )
                                      )
                                      (if (result (ref $type28))
                                       (i64.eqz
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.tee $2
                                           (call $function46
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (then
                                        (ref.as_non_null
                                         (global.get $global108)
                                        )
                                       )
                                       (else
                                        (struct.new $type28
                                         (local.get $3)
                                         (local.get $2)
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global112)
                                       )
                                      )
                                      (array.set $type29
                                       (local.get $1)
                                       (i32.const 17)
                                       (i32.wrap_i64
                                        (i64.sub
                                         (i64.const 0)
                                         (i64.rem_s
                                          (local.get $0)
                                          (i64.const 1073741824)
                                         )
                                        )
                                       )
                                      )
                                      (if (result (ref $type28))
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 1073741824)
                                         )
                                        )
                                       )
                                       (then
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global126)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global122)
                                         )
                                        )
                                        (if (result (ref $type28))
                                         (i64.eqz
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.tee $2
                                             (call $function46
                                              (local.get $1)
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (then
                                          (ref.as_non_null
                                           (global.get $global108)
                                          )
                                         )
                                         (else
                                          (struct.new $type28
                                           (local.get $3)
                                           (local.get $2)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global112)
                                         )
                                        )
                                        (array.set $type29
                                         (local.get $1)
                                         (i32.const 18)
                                         (i32.wrap_i64
                                          (i64.sub
                                           (i64.const 0)
                                           (i64.rem_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                          )
                                         )
                                        )
                                        (if
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                          )
                                         )
                                         (then
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global126)
                                           )
                                          )
                                          (return_call $function47
                                           (local.get $3)
                                           (local.get $1)
                                          )
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global112)
                                           )
                                          )
                                          (call $function42
                                           (local.get $1)
                                           (i64.const 19)
                                           (i64.sub
                                            (i64.const 0)
                                            (i64.rem_s
                                             (local.get $0)
                                             (i64.const 1073741824)
                                            )
                                           )
                                          )
                                          (return_call $function54
                                           (local.get $3)
                                           (local.get $1)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                        (unreachable)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function54 (type $82) (param $0 i32) (param $1 (ref $type29)) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result (ref $type28))
  (if
   (i64.eqz
    (local.get $4)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (return_call $function47
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (call $function42
     (local.get $1)
     (local.get $5)
     (i64.sub
      (i64.const 0)
      (i64.rem_s
       (local.get $4)
       (i64.const 1073741824)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.div_s
      (local.get $4)
      (i64.const 1073741824)
     )
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function56 (type $81) (param $0 (ref $type29)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i64)
  (local $7 i64)
  (if (result i64)
   (i64.eqz
    (local.get $5)
   )
   (then
    (select
     (local.get $6)
     (i64.sub
      (i64.const 0)
      (local.get $6)
     )
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (i64.div_s
       (i64.add
        (local.tee $7
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $7)
           )
          )
         )
        )
        (local.get $2)
       )
       (i64.const 1073741824)
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function56
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
       (i64.sub
        (i64.shl
         (local.get $6)
         (i64.const 30)
        )
        (local.get $7)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function58 (type $80) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i32) (param $3 i32) (param $4 i64) (result i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (if (result i64)
   (i64.eqz
    (local.get $4)
   )
   (then
    (i64.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.sub
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (i64.lt_s
      (local.tee $5
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (local.tee $7
          (i32.wrap_i64
           (local.get $5)
          )
         )
        )
       )
      )
      (local.tee $6
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (local.get $7)
        )
       )
      )
     )
     (then
      (i64.const -1)
     )
     (else
      (if (result i64)
       (i64.gt_s
        (local.get $5)
        (local.get $6)
       )
       (then
        (i64.const 1)
       )
       (else
        (if
         (i32.eqz
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function58
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function59 (type $call76) (param $0 (ref $type28)) (param $1 (ref $type28)) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (if (result i64)
   (i64.eq
    (i64.extend_i32_u
     (i32.ne
      (local.tee $4
       (struct.get $type28 0
        (local.get $0)
       )
      )
      (i32.const 0)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (struct.get $type28 0
       (local.get $1)
      )
      (i32.const 0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (select
     (i64.sub
      (i64.const 0)
      (local.tee $2
       (if (result i64)
        (i64.lt_s
         (local.tee $2
          (i64.extend_i32_u
           (array.len
            (local.tee $5
             (struct.get $type28 1
              (local.get $0)
             )
            )
           )
          )
         )
         (local.tee $3
          (i64.extend_i32_u
           (array.len
            (local.tee $6
             (struct.get $type28 1
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (if (result i64)
          (i64.gt_s
           (local.get $2)
           (local.get $3)
          )
          (then
           (i64.const 1)
          )
          (else
           (call $function58
            (local.get $5)
            (local.get $6)
            (i32.const 0)
            (i32.const 1)
            (local.get $2)
           )
          )
         )
        )
       )
      )
     )
     (local.get $2)
     (local.get $4)
    )
   )
   (else
    (select
     (i64.const -1)
     (i64.const 1)
     (struct.get $type28 0
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function67 (type $78) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 (ref $type29)) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result (ref $type29))
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $3)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global186)
     )
    )
    (local.set $7
     (i64.add
      (local.get $7)
      (i64.add
       (if (result i64)
        (i64.gt_s
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (local.get $6)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global109)
          )
         )
         (if
          (i64.gt_u
           (local.get $6)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
        (else
         (i64.const 0)
        )
       )
       (if (result i64)
        (i64.gt_s
         (i64.extend_i32_u
          (array.len
           (local.get $1)
          )
         )
         (local.get $6)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global109)
          )
         )
         (if
          (i64.gt_u
           (local.get $6)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i64.extend_i32_s
          (array.get $type29
           (local.get $1)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
        (else
         (i64.const 0)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $3)
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (i64.rem_s
       (local.get $7)
       (i64.const 1073741824)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $7)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function69 (type $78) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 (ref $type29)) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result (ref $type29))
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global186)
     )
    )
    (local.set $7
     (i64.sub
      (i64.sub
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
       (if (result i64)
        (i64.gt_s
         (i64.extend_i32_u
          (array.len
           (local.get $1)
          )
         )
         (local.get $6)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global109)
          )
         )
         (if
          (i64.gt_u
           (local.get $6)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i64.extend_i32_s
          (array.get $type29
           (local.get $1)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
        (else
         (i64.const 0)
        )
       )
      )
      (local.get $7)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $3)
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (select
       (i64.add
        (local.get $7)
        (i64.const 1073741824)
       )
       (local.get $7)
       (i64.lt_s
        (local.get $7)
        (i64.const 0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function69
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (i64.extend_i32_u
      (i64.lt_s
       (local.get $7)
       (i64.const 0)
      )
     )
    )
   )
  )
 )
 (func $function71 (type $77) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (local $scratch (ref $type29))
  (local $scratch_8 (ref $type29))
  (local $scratch_9 (ref $type29))
  (local.set $2
   (struct.get $type28 1
    (local.get $0)
   )
  )
  (local.set $3
   (struct.get $type28 1
    (local.get $1)
   )
  )
  (if (result (ref $type28))
   (select
    (local.tee $6
     (struct.get $type28 0
      (local.get $1)
     )
    )
    (i32.eqz
     (local.get $6)
    )
    (local.tee $6
     (struct.get $type28 0
      (local.get $0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global189)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function46
          (block (result (ref $type29))
           (local.set $scratch
            (call $function67
             (local.get $2)
             (local.get $3)
             (local.tee $4
              (select
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (local.tee $5
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.gt_s
                (local.get $4)
                (local.get $5)
               )
              )
             )
             (block (result (ref (exact $type29)))
              (if
               (i64.gt_u
                (local.tee $4
                 (i64.add
                  (local.get $4)
                  (i64.const 1)
                 )
                )
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (array.new_default $type29
               (i32.wrap_i64
                (local.get $4)
               )
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type28
       (local.get $6)
       (local.get $2)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (local.set $6
     (struct.get $type28 0
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if (result (ref $type28))
     (i64.lt_s
      (if (result i64)
       (i64.lt_s
        (local.tee $4
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (local.tee $5
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (if (result i64)
         (i64.gt_s
          (local.get $4)
          (local.get $5)
         )
         (then
          (i64.const 1)
         )
         (else
          (call $function58
           (local.get $2)
           (local.get $3)
           (i32.const 0)
           (i32.const 1)
           (local.get $4)
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global198)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global116)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function46
            (block (result (ref $type29))
             (local.set $scratch_8
              (call $function69
               (local.get $3)
               (local.get $2)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (block (result (ref (exact $type29)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch_8)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type28
         (i32.eqz
          (local.get $6)
         )
         (local.get $2)
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global198)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global116)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function46
            (block (result (ref $type29))
             (local.set $scratch_9
              (call $function69
               (local.get $2)
               (local.get $3)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (block (result (ref (exact $type29)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch_9)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type28
         (local.get $6)
         (local.get $2)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function73 (type $call81) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (result i32)
  (return_call $function74
   (local.get $0)
   (local.get $1)
   (local.get $2)
   (local.get $3)
   (i64.extend_i32_u
    (array.len
     (local.get $1)
    )
   )
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $function74 (type $75) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i64) (param $8 i64) (result i32)
  (local $9 i64)
  (local $10 i64)
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $7)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.add
        (local.get $2)
        (local.get $4)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $9
       (i64.add
        (local.get $2)
        (local.get $7)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.rem_s
      (local.tee $8
       (i64.add
        (local.get $8)
        (i64.add
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $9)
           )
          )
         )
         (i64.mul
          (local.get $3)
          (i64.extend_i32_s
           (array.get $type29
            (local.get $1)
            (i32.wrap_i64
             (local.get $7)
            )
           )
          )
         )
        )
       )
      )
      (i64.const 1073741824)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $9)
     )
     (i32.wrap_i64
      (local.get $10)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (i64.add
      (local.get $7)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $8)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function75 (type $call78) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type29))
  (local $2 (ref $type29))
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i64.gt_u
    (local.tee $3
     (i64.add
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.extend_i32_u
       (array.len
        (local.get $1)
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (array.new_default $type29
    (i32.wrap_i64
     (local.get $3)
    )
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global219)
     )
    )
    (drop
     (call $function74
      (local.get $2)
      (local.get $1)
      (i64.const 0)
      (i64.extend_i32_s
       (array.get $type29
        (local.get $0)
        (i32.const 0)
       )
      )
      (i64.extend_i32_u
       (array.len
        (local.get $1)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
    )
    (if (result (ref $type29))
     (i64.eq
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (then
      (local.get $2)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global109)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global219)
       )
      )
      (drop
       (call $function74
        (local.get $2)
        (local.get $1)
        (i64.const 1)
        (i64.extend_i32_s
         (array.get $type29
          (local.get $0)
          (i32.const 1)
         )
        )
        (i64.extend_i32_u
         (array.len
          (local.get $1)
         )
        )
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
        (i64.const 0)
       )
      )
      (if (result (ref $type29))
       (i64.eq
        (i64.extend_i32_u
         (array.len
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (then
        (local.get $2)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global109)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global219)
         )
        )
        (drop
         (call $function74
          (local.get $2)
          (local.get $1)
          (i64.const 2)
          (i64.extend_i32_s
           (array.get $type29
            (local.get $0)
            (i32.const 2)
           )
          )
          (i64.extend_i32_u
           (array.len
            (local.get $1)
           )
          )
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
          (i64.const 0)
         )
        )
        (if (result (ref $type29))
         (i64.eq
          (i64.extend_i32_u
           (array.len
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (then
          (local.get $2)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global109)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global219)
           )
          )
          (drop
           (call $function74
            (local.get $2)
            (local.get $1)
            (i64.const 3)
            (i64.extend_i32_s
             (array.get $type29
              (local.get $0)
              (i32.const 3)
             )
            )
            (i64.extend_i32_u
             (array.len
              (local.get $1)
             )
            )
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
            (i64.const 0)
           )
          )
          (if (result (ref $type29))
           (i64.eq
            (i64.extend_i32_u
             (array.len
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (then
            (local.get $2)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global109)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global219)
             )
            )
            (drop
             (call $function74
              (local.get $2)
              (local.get $1)
              (i64.const 4)
              (i64.extend_i32_s
               (array.get $type29
                (local.get $0)
                (i32.const 4)
               )
              )
              (i64.extend_i32_u
               (array.len
                (local.get $1)
               )
              )
              (i32.const 0)
              (i32.const 1)
              (i64.const 0)
              (i64.const 0)
             )
            )
            (if (result (ref $type29))
             (i64.eq
              (i64.extend_i32_u
               (array.len
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (then
              (local.get $2)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global109)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global219)
               )
              )
              (drop
               (call $function74
                (local.get $2)
                (local.get $1)
                (i64.const 5)
                (i64.extend_i32_s
                 (array.get $type29
                  (local.get $0)
                  (i32.const 5)
                 )
                )
                (i64.extend_i32_u
                 (array.len
                  (local.get $1)
                 )
                )
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
                (i64.const 0)
               )
              )
              (if (result (ref $type29))
               (i64.eq
                (i64.extend_i32_u
                 (array.len
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (then
                (local.get $2)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global109)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global219)
                 )
                )
                (drop
                 (call $function74
                  (local.get $2)
                  (local.get $1)
                  (i64.const 6)
                  (i64.extend_i32_s
                   (array.get $type29
                    (local.get $0)
                    (i32.const 6)
                   )
                  )
                  (i64.extend_i32_u
                   (array.len
                    (local.get $1)
                   )
                  )
                  (i32.const 0)
                  (i32.const 1)
                  (i64.const 0)
                  (i64.const 0)
                 )
                )
                (if (result (ref $type29))
                 (i64.eq
                  (i64.extend_i32_u
                   (array.len
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global109)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global219)
                   )
                  )
                  (drop
                   (call $function74
                    (local.get $2)
                    (local.get $1)
                    (i64.const 7)
                    (i64.extend_i32_s
                     (array.get $type29
                      (local.get $0)
                      (i32.const 7)
                     )
                    )
                    (i64.extend_i32_u
                     (array.len
                      (local.get $1)
                     )
                    )
                    (i32.const 0)
                    (i32.const 1)
                    (i64.const 0)
                    (i64.const 0)
                   )
                  )
                  (if (result (ref $type29))
                   (i64.eq
                    (i64.extend_i32_u
                     (array.len
                      (local.get $0)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global109)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global219)
                     )
                    )
                    (drop
                     (call $function74
                      (local.get $2)
                      (local.get $1)
                      (i64.const 8)
                      (i64.extend_i32_s
                       (array.get $type29
                        (local.get $0)
                        (i32.const 8)
                       )
                      )
                      (i64.extend_i32_u
                       (array.len
                        (local.get $1)
                       )
                      )
                      (i32.const 0)
                      (i32.const 1)
                      (i64.const 0)
                      (i64.const 0)
                     )
                    )
                    (if (result (ref $type29))
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $0)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (local.get $2)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global109)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global219)
                       )
                      )
                      (drop
                       (call $function74
                        (local.get $2)
                        (local.get $1)
                        (i64.const 9)
                        (i64.extend_i32_s
                         (array.get $type29
                          (local.get $0)
                          (i32.const 9)
                         )
                        )
                        (i64.extend_i32_u
                         (array.len
                          (local.get $1)
                         )
                        )
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 0)
                        (i64.const 0)
                       )
                      )
                      (if (result (ref $type29))
                       (i64.eq
                        (i64.extend_i32_u
                         (array.len
                          (local.get $0)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (local.get $2)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global109)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global219)
                         )
                        )
                        (drop
                         (call $function74
                          (local.get $2)
                          (local.get $1)
                          (i64.const 10)
                          (i64.extend_i32_s
                           (array.get $type29
                            (local.get $0)
                            (i32.const 10)
                           )
                          )
                          (i64.extend_i32_u
                           (array.len
                            (local.get $1)
                           )
                          )
                          (i32.const 0)
                          (i32.const 1)
                          (i64.const 0)
                          (i64.const 0)
                         )
                        )
                        (if (result (ref $type29))
                         (i64.eq
                          (i64.extend_i32_u
                           (array.len
                            (local.get $0)
                           )
                          )
                          (i64.const 11)
                         )
                         (then
                          (local.get $2)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global109)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global219)
                           )
                          )
                          (drop
                           (call $function74
                            (local.get $2)
                            (local.get $1)
                            (i64.const 11)
                            (i64.extend_i32_s
                             (array.get $type29
                              (local.get $0)
                              (i32.const 11)
                             )
                            )
                            (i64.extend_i32_u
                             (array.len
                              (local.get $1)
                             )
                            )
                            (i32.const 0)
                            (i32.const 1)
                            (i64.const 0)
                            (i64.const 0)
                           )
                          )
                          (if (result (ref $type29))
                           (i64.eq
                            (i64.extend_i32_u
                             (array.len
                              (local.get $0)
                             )
                            )
                            (i64.const 12)
                           )
                           (then
                            (local.get $2)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global109)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global219)
                             )
                            )
                            (drop
                             (call $function74
                              (local.get $2)
                              (local.get $1)
                              (i64.const 12)
                              (i64.extend_i32_s
                               (array.get $type29
                                (local.get $0)
                                (i32.const 12)
                               )
                              )
                              (i64.extend_i32_u
                               (array.len
                                (local.get $1)
                               )
                              )
                              (i32.const 0)
                              (i32.const 1)
                              (i64.const 0)
                              (i64.const 0)
                             )
                            )
                            (if (result (ref $type29))
                             (i64.eq
                              (i64.extend_i32_u
                               (array.len
                                (local.get $0)
                               )
                              )
                              (i64.const 13)
                             )
                             (then
                              (local.get $2)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global109)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global219)
                               )
                              )
                              (drop
                               (call $function74
                                (local.get $2)
                                (local.get $1)
                                (i64.const 13)
                                (i64.extend_i32_s
                                 (array.get $type29
                                  (local.get $0)
                                  (i32.const 13)
                                 )
                                )
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $1)
                                 )
                                )
                                (i32.const 0)
                                (i32.const 1)
                                (i64.const 0)
                                (i64.const 0)
                               )
                              )
                              (if (result (ref $type29))
                               (i64.eq
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $0)
                                 )
                                )
                                (i64.const 14)
                               )
                               (then
                                (local.get $2)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global109)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global219)
                                 )
                                )
                                (drop
                                 (call $function74
                                  (local.get $2)
                                  (local.get $1)
                                  (i64.const 14)
                                  (i64.extend_i32_s
                                   (array.get $type29
                                    (local.get $0)
                                    (i32.const 14)
                                   )
                                  )
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $1)
                                   )
                                  )
                                  (i32.const 0)
                                  (i32.const 1)
                                  (i64.const 0)
                                  (i64.const 0)
                                 )
                                )
                                (if (result (ref $type29))
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 15)
                                 )
                                 (then
                                  (local.get $2)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global109)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global219)
                                   )
                                  )
                                  (drop
                                   (call $function74
                                    (local.get $2)
                                    (local.get $1)
                                    (i64.const 15)
                                    (i64.extend_i32_s
                                     (array.get $type29
                                      (local.get $0)
                                      (i32.const 15)
                                     )
                                    )
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $1)
                                     )
                                    )
                                    (i32.const 0)
                                    (i32.const 1)
                                    (i64.const 0)
                                    (i64.const 0)
                                   )
                                  )
                                  (if (result (ref $type29))
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 16)
                                   )
                                   (then
                                    (local.get $2)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global109)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global219)
                                     )
                                    )
                                    (drop
                                     (call $function74
                                      (local.get $2)
                                      (local.get $1)
                                      (i64.const 16)
                                      (i64.extend_i32_s
                                       (array.get $type29
                                        (local.get $0)
                                        (i32.const 16)
                                       )
                                      )
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.get $1)
                                       )
                                      )
                                      (i32.const 0)
                                      (i32.const 1)
                                      (i64.const 0)
                                      (i64.const 0)
                                     )
                                    )
                                    (if (result (ref $type29))
                                     (i64.eq
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 17)
                                     )
                                     (then
                                      (local.get $2)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global109)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global219)
                                       )
                                      )
                                      (drop
                                       (call $function74
                                        (local.get $2)
                                        (local.get $1)
                                        (i64.const 17)
                                        (i64.extend_i32_s
                                         (array.get $type29
                                          (local.get $0)
                                          (i32.const 17)
                                         )
                                        )
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.get $1)
                                         )
                                        )
                                        (i32.const 0)
                                        (i32.const 1)
                                        (i64.const 0)
                                        (i64.const 0)
                                       )
                                      )
                                      (if (result (ref $type29))
                                       (i64.eq
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 18)
                                       )
                                       (then
                                        (local.get $2)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global109)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global219)
                                         )
                                        )
                                        (drop
                                         (call $function74
                                          (local.get $2)
                                          (local.get $1)
                                          (i64.const 18)
                                          (i64.extend_i32_s
                                           (array.get $type29
                                            (local.get $0)
                                            (i32.const 18)
                                           )
                                          )
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.get $1)
                                           )
                                          )
                                          (i32.const 0)
                                          (i32.const 1)
                                          (i64.const 0)
                                          (i64.const 0)
                                         )
                                        )
                                        (if (result (ref $type29))
                                         (i64.eq
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 19)
                                         )
                                         (then
                                          (local.get $2)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global109)
                                           )
                                          )
                                          (local.set $3
                                           (call $function41
                                            (local.get $0)
                                            (i64.const 19)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global219)
                                           )
                                          )
                                          (drop
                                           (call $function73
                                            (local.get $2)
                                            (local.get $1)
                                            (i64.const 19)
                                            (local.get $3)
                                           )
                                          )
                                          (return_call $function76
                                           (local.get $0)
                                           (local.get $1)
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function76 (type $73) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 (ref $type29)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type29))
  (local $6 i64)
  (if (result (ref $type29))
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.set $6
     (call $function41
      (local.get $0)
      (local.get $5)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global219)
     )
    )
    (drop
     (call $function73
      (local.get $2)
      (local.get $1)
      (local.get $5)
      (local.get $6)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function76
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function77 (type $77) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type29))
  (local $3 i32)
  (local $scratch (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type28))
   (if (result i32)
    (i64.eqz
     (i64.extend_i32_u
      (array.len
       (struct.get $type28 1
        (local.get $0)
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global130)
      )
     )
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (ref.as_non_null
     (global.get $global108)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global230)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function46
          (block (result (ref $type29))
           (local.set $scratch
            (call $function75
             (struct.get $type28 1
              (local.get $0)
             )
             (struct.get $type28 1
              (local.get $1)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (local.set $3
            (select
             (i32.eqz
              (local.tee $3
               (struct.get $type28 0
                (local.get $1)
               )
              )
             )
             (local.get $3)
             (struct.get $type28 0
              (local.get $0)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type28
       (local.get $3)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function79 (type $72) (param $0 (ref $type29)) (param $1 i64) (param $2 i64) (param $3 (ref $type29)) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result (ref $type29))
  (local $8 i64)
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $3)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (i64.rem_s
      (local.tee $7
       (i64.add
        (local.get $7)
        (i64.mul
         (local.get $1)
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
       )
      )
      (i64.const 1073741824)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $3)
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function79
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $7)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function80 (type $71) (param $0 (ref $type29)) (param $1 (ref $type29)) (result i64)
  (return_call $function81
   (local.get $0)
   (local.get $1)
   (i64.const 1000000000)
   (i32.const 0)
   (i32.const 1)
   (i64.extend_i32_u
    (array.len
     (local.get $1)
    )
   )
   (i64.const 0)
  )
 )
 (func $function81 (type $70) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i64)
  (local $7 i64)
  (local $8 i64)
  (if (result i64)
   (i64.eqz
    (local.get $5)
   )
   (then
    (local.get $6)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (i64.div_s
      (local.tee $6
       (i64.add
        (i64.extend_i32_s
         (array.get $type29
          (local.get $1)
          (i32.wrap_i64
           (local.get $7)
          )
         )
        )
        (i64.shl
         (local.get $6)
         (i64.const 30)
        )
       )
      )
      (local.get $2)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (local.set $6
     (i64.rem_s
      (local.get $6)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function83 (type $69) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i64) (param $8 i64) (result i64)
  (local $9 i64)
  (local $10 i64)
  (if (result i64)
   (if (result i32)
    (i64.lt_s
     (local.get $8)
     (i64.const 1073741824)
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (if
      (i64.gt_u
       (local.tee $9
        (i64.sub
         (i64.add
          (local.get $2)
          (local.get $3)
         )
         (i64.const 2)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.gt_u
       (local.tee $10
        (i64.sub
         (local.get $3)
         (i64.const 2)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.lt_s
      (i64.add
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $9)
         )
        )
       )
       (i64.shl
        (local.get $8)
        (i64.const 30)
       )
      )
      (i64.mul
       (local.get $7)
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $10)
         )
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function83
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (i64.sub
      (local.get $7)
      (i64.const 1)
     )
     (i64.add
      (local.get $4)
      (local.get $8)
     )
    )
   )
   (else
    (local.get $7)
   )
  )
 )
 (func $function85 (type $75) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i64) (param $8 i64) (result i32)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $7)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (i64.add
        (local.get $2)
        (local.get $4)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.lt_s
       (local.tee $3
        (i64.sub
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
         (local.get $8)
        )
       )
       (i64.const -1)
      )
      (then
       (i32.const 1)
      )
      (else
       (i64.gt_s
        (local.get $3)
        (i64.const 0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $3
     (select
      (i64.add
       (local.get $3)
       (i64.const 1073741824)
      )
      (local.get $3)
      (local.tee $5
       (i64.lt_s
        (local.get $3)
        (i64.const 0)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.add
        (local.get $2)
        (local.get $4)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.get $5)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.add
      (local.get $8)
      (i64.mul
       (local.get $3)
       (i64.extend_i32_s
        (array.get $type29
         (local.get $1)
         (i32.wrap_i64
          (local.get $7)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.add
        (local.get $2)
        (local.get $7)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (select
      (i64.add
       (local.tee $9
        (i64.sub
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
         (i64.and
          (local.get $10)
          (i64.const 1073741823)
         )
        )
       )
       (i64.const 1073741824)
      )
      (local.get $9)
      (i64.lt_s
       (local.get $9)
       (i64.const 0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $11)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function85
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (i64.add
      (local.get $7)
      (i64.const 1)
     )
     (i64.add
      (i64.extend_i32_u
       (i64.lt_s
        (local.get $9)
        (i64.const 0)
       )
      )
      (i64.shr_u
       (local.get $10)
       (i64.const 30)
      )
     )
    )
   )
  )
 )
 (func $function87 (type $68) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result i32)
  (local $8 i64)
  (local $9 i64)
  (if (result i32)
   (i64.eq
    (local.get $3)
    (local.get $6)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.add
        (local.get $2)
        (local.get $3)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.rem_s
      (i64.add
       (local.get $7)
       (i64.extend_i32_s
        (array.get $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1073741824)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.add
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (i64.rem_s
      (local.tee $7
       (i64.add
        (local.get $7)
        (i64.add
         (i64.extend_i32_s
          (array.get $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
         (i64.extend_i32_s
          (array.get $type29
           (local.get $1)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
       )
      )
      (i64.const 1073741824)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $7)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function88 (type $call83) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (drop
   (ref.as_non_null
    (global.get $global256)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (if
   (i64.gt_u
    (local.tee $4
     (i64.sub
      (local.tee $3
       (i64.extend_i32_u
        (array.len
         (local.get $1)
        )
       )
      )
      (i64.const 1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (local.set $3
   (call $function83
    (local.get $0)
    (local.get $1)
    (local.get $2)
    (local.get $3)
    (local.tee $4
     (i64.extend_i32_s
      (array.get $type29
       (local.get $1)
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (i32.const 0)
    (i32.const 1)
    (block (result i64)
     (if
      (i64.gt_u
       (local.tee $3
        (i64.add
         (local.get $2)
         (local.get $3)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (if
      (i64.gt_u
       (local.tee $5
        (i64.sub
         (local.get $3)
         (i64.const 1)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.ge_s
       (local.tee $3
        (i64.div_s
         (local.tee $5
          (i64.add
           (i64.extend_i32_s
            (array.get $type29
             (local.get $0)
             (i32.wrap_i64
              (local.get $5)
             )
            )
           )
           (i64.shl
            (i64.extend_i32_s
             (array.get $type29
              (local.get $0)
              (i32.wrap_i64
               (local.get $3)
              )
             )
            )
            (i64.const 30)
           )
          )
         )
         (local.get $4)
        )
       )
       (i64.const 1073741824)
      )
      (then
       (local.set $3
        (i64.const 1073741823)
       )
      )
     )
     (local.get $3)
    )
    (i64.sub
     (local.get $5)
     (i64.mul
      (local.get $3)
      (local.get $4)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global268)
   )
  )
  (if (result i64)
   (call $function85
    (local.get $0)
    (local.get $1)
    (local.get $2)
    (local.get $3)
    (local.tee $4
     (i64.extend_i32_u
      (array.len
       (local.get $1)
      )
     )
    )
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (drop
     (call $function87
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
    )
    (i64.sub
     (local.get $3)
     (i64.const 1)
    )
   )
   (else
    (local.get $3)
   )
  )
 )
 (func $function89 (type $66) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 (ref $type29)) (result i32)
  (local $3 i64)
  (local $4 i64)
  (if (result i32)
   (i64.eqz
    (local.tee $3
     (i64.extend_i32_u
      (array.len
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global289)
     )
    )
    (local.set $4
     (call $function88
      (local.get $1)
      (local.get $2)
      (local.tee $3
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $0)
     (i32.wrap_i64
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (if (result i32)
     (i64.eqz
      (local.get $3)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global289)
       )
      )
      (local.set $4
       (call $function88
        (local.get $1)
        (local.get $2)
        (local.tee $3
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global112)
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type29
       (local.get $0)
       (i32.wrap_i64
        (local.get $3)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
      (if (result i32)
       (i64.eqz
        (local.get $3)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global289)
         )
        )
        (local.set $4
         (call $function88
          (local.get $1)
          (local.get $2)
          (local.tee $3
           (i64.sub
            (local.get $3)
            (i64.const 1)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global112)
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type29
         (local.get $0)
         (i32.wrap_i64
          (local.get $3)
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
        (if (result i32)
         (i64.eqz
          (local.get $3)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global289)
           )
          )
          (local.set $4
           (call $function88
            (local.get $1)
            (local.get $2)
            (local.tee $3
             (i64.sub
              (local.get $3)
              (i64.const 1)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global112)
           )
          )
          (if
           (i64.gt_u
            (local.get $3)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (array.set $type29
           (local.get $0)
           (i32.wrap_i64
            (local.get $3)
           )
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (if (result i32)
           (i64.eqz
            (local.get $3)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global289)
             )
            )
            (local.set $4
             (call $function88
              (local.get $1)
              (local.get $2)
              (local.tee $3
               (i64.sub
                (local.get $3)
                (i64.const 1)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global112)
             )
            )
            (if
             (i64.gt_u
              (local.get $3)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (array.set $type29
             (local.get $0)
             (i32.wrap_i64
              (local.get $3)
             )
             (i32.wrap_i64
              (local.get $4)
             )
            )
            (if (result i32)
             (i64.eqz
              (local.get $3)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global289)
               )
              )
              (local.set $4
               (call $function88
                (local.get $1)
                (local.get $2)
                (local.tee $3
                 (i64.sub
                  (local.get $3)
                  (i64.const 1)
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global112)
               )
              )
              (if
               (i64.gt_u
                (local.get $3)
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (array.set $type29
               (local.get $0)
               (i32.wrap_i64
                (local.get $3)
               )
               (i32.wrap_i64
                (local.get $4)
               )
              )
              (if (result i32)
               (i64.eqz
                (local.get $3)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global289)
                 )
                )
                (local.set $4
                 (call $function88
                  (local.get $1)
                  (local.get $2)
                  (local.tee $3
                   (i64.sub
                    (local.get $3)
                    (i64.const 1)
                   )
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global112)
                 )
                )
                (if
                 (i64.gt_u
                  (local.get $3)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.set $type29
                 (local.get $0)
                 (i32.wrap_i64
                  (local.get $3)
                 )
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
                (if (result i32)
                 (i64.eqz
                  (local.get $3)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global289)
                   )
                  )
                  (local.set $4
                   (call $function88
                    (local.get $1)
                    (local.get $2)
                    (local.tee $3
                     (i64.sub
                      (local.get $3)
                      (i64.const 1)
                     )
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global112)
                   )
                  )
                  (if
                   (i64.gt_u
                    (local.get $3)
                    (i64.const 4294967295)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (array.set $type29
                   (local.get $0)
                   (i32.wrap_i64
                    (local.get $3)
                   )
                   (i32.wrap_i64
                    (local.get $4)
                   )
                  )
                  (if (result i32)
                   (i64.eqz
                    (local.get $3)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global289)
                     )
                    )
                    (local.set $4
                     (call $function88
                      (local.get $1)
                      (local.get $2)
                      (local.tee $3
                       (i64.sub
                        (local.get $3)
                        (i64.const 1)
                       )
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global112)
                     )
                    )
                    (if
                     (i64.gt_u
                      (local.get $3)
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (array.set $type29
                     (local.get $0)
                     (i32.wrap_i64
                      (local.get $3)
                     )
                     (i32.wrap_i64
                      (local.get $4)
                     )
                    )
                    (if (result i32)
                     (i64.eqz
                      (local.get $3)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global289)
                       )
                      )
                      (local.set $4
                       (call $function88
                        (local.get $1)
                        (local.get $2)
                        (local.tee $3
                         (i64.sub
                          (local.get $3)
                          (i64.const 1)
                         )
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global112)
                       )
                      )
                      (if
                       (i64.gt_u
                        (local.get $3)
                        (i64.const 4294967295)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (array.set $type29
                       (local.get $0)
                       (i32.wrap_i64
                        (local.get $3)
                       )
                       (i32.wrap_i64
                        (local.get $4)
                       )
                      )
                      (if (result i32)
                       (i64.eqz
                        (local.get $3)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global289)
                         )
                        )
                        (local.set $4
                         (call $function88
                          (local.get $1)
                          (local.get $2)
                          (local.tee $3
                           (i64.sub
                            (local.get $3)
                            (i64.const 1)
                           )
                          )
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global112)
                         )
                        )
                        (if
                         (i64.gt_u
                          (local.get $3)
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (array.set $type29
                         (local.get $0)
                         (i32.wrap_i64
                          (local.get $3)
                         )
                         (i32.wrap_i64
                          (local.get $4)
                         )
                        )
                        (if (result i32)
                         (i64.eqz
                          (local.get $3)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global289)
                           )
                          )
                          (local.set $4
                           (call $function88
                            (local.get $1)
                            (local.get $2)
                            (local.tee $3
                             (i64.sub
                              (local.get $3)
                              (i64.const 1)
                             )
                            )
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global112)
                           )
                          )
                          (if
                           (i64.gt_u
                            (local.get $3)
                            (i64.const 4294967295)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (array.set $type29
                           (local.get $0)
                           (i32.wrap_i64
                            (local.get $3)
                           )
                           (i32.wrap_i64
                            (local.get $4)
                           )
                          )
                          (if (result i32)
                           (i64.eqz
                            (local.get $3)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global289)
                             )
                            )
                            (local.set $4
                             (call $function88
                              (local.get $1)
                              (local.get $2)
                              (local.tee $3
                               (i64.sub
                                (local.get $3)
                                (i64.const 1)
                               )
                              )
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global112)
                             )
                            )
                            (if
                             (i64.gt_u
                              (local.get $3)
                              (i64.const 4294967295)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (array.set $type29
                             (local.get $0)
                             (i32.wrap_i64
                              (local.get $3)
                             )
                             (i32.wrap_i64
                              (local.get $4)
                             )
                            )
                            (if (result i32)
                             (i64.eqz
                              (local.get $3)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global289)
                               )
                              )
                              (local.set $4
                               (call $function88
                                (local.get $1)
                                (local.get $2)
                                (local.tee $3
                                 (i64.sub
                                  (local.get $3)
                                  (i64.const 1)
                                 )
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global112)
                               )
                              )
                              (if
                               (i64.gt_u
                                (local.get $3)
                                (i64.const 4294967295)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (array.set $type29
                               (local.get $0)
                               (i32.wrap_i64
                                (local.get $3)
                               )
                               (i32.wrap_i64
                                (local.get $4)
                               )
                              )
                              (if (result i32)
                               (i64.eqz
                                (local.get $3)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global289)
                                 )
                                )
                                (local.set $4
                                 (call $function88
                                  (local.get $1)
                                  (local.get $2)
                                  (local.tee $3
                                   (i64.sub
                                    (local.get $3)
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global112)
                                 )
                                )
                                (if
                                 (i64.gt_u
                                  (local.get $3)
                                  (i64.const 4294967295)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (array.set $type29
                                 (local.get $0)
                                 (i32.wrap_i64
                                  (local.get $3)
                                 )
                                 (i32.wrap_i64
                                  (local.get $4)
                                 )
                                )
                                (if (result i32)
                                 (i64.eqz
                                  (local.get $3)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global289)
                                   )
                                  )
                                  (local.set $4
                                   (call $function88
                                    (local.get $1)
                                    (local.get $2)
                                    (local.tee $3
                                     (i64.sub
                                      (local.get $3)
                                      (i64.const 1)
                                     )
                                    )
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global112)
                                   )
                                  )
                                  (if
                                   (i64.gt_u
                                    (local.get $3)
                                    (i64.const 4294967295)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (array.set $type29
                                   (local.get $0)
                                   (i32.wrap_i64
                                    (local.get $3)
                                   )
                                   (i32.wrap_i64
                                    (local.get $4)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eqz
                                    (local.get $3)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global289)
                                     )
                                    )
                                    (local.set $4
                                     (call $function88
                                      (local.get $1)
                                      (local.get $2)
                                      (local.tee $3
                                       (i64.sub
                                        (local.get $3)
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global112)
                                     )
                                    )
                                    (if
                                     (i64.gt_u
                                      (local.get $3)
                                      (i64.const 4294967295)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (array.set $type29
                                     (local.get $0)
                                     (i32.wrap_i64
                                      (local.get $3)
                                     )
                                     (i32.wrap_i64
                                      (local.get $4)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eqz
                                      (local.get $3)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global289)
                                       )
                                      )
                                      (local.set $4
                                       (call $function88
                                        (local.get $1)
                                        (local.get $2)
                                        (local.tee $3
                                         (i64.sub
                                          (local.get $3)
                                          (i64.const 1)
                                         )
                                        )
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global112)
                                       )
                                      )
                                      (if
                                       (i64.gt_u
                                        (local.get $3)
                                        (i64.const 4294967295)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (array.set $type29
                                       (local.get $0)
                                       (i32.wrap_i64
                                        (local.get $3)
                                       )
                                       (i32.wrap_i64
                                        (local.get $4)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eqz
                                        (local.get $3)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global289)
                                         )
                                        )
                                        (local.set $4
                                         (call $function88
                                          (local.get $1)
                                          (local.get $2)
                                          (local.tee $3
                                           (i64.sub
                                            (local.get $3)
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global112)
                                         )
                                        )
                                        (if
                                         (i64.gt_u
                                          (local.get $3)
                                          (i64.const 4294967295)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (array.set $type29
                                         (local.get $0)
                                         (i32.wrap_i64
                                          (local.get $3)
                                         )
                                         (i32.wrap_i64
                                          (local.get $4)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eqz
                                          (local.get $3)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global289)
                                           )
                                          )
                                          (local.set $3
                                           (call $function88
                                            (local.get $1)
                                            (local.get $2)
                                            (local.tee $4
                                             (i64.sub
                                              (local.get $3)
                                              (i64.const 1)
                                             )
                                            )
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global112)
                                           )
                                          )
                                          (call $function42
                                           (local.get $0)
                                           (local.get $4)
                                           (local.get $3)
                                          )
                                          (return_call $function90
                                           (local.get $0)
                                           (local.get $1)
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (local.get $4)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function90 (type $65) (param $0 (ref $type29)) (param $1 (ref $type29)) (param $2 (ref $type29)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (if (result i32)
   (i64.eqz
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global289)
     )
    )
    (local.set $7
     (call $function88
      (local.get $1)
      (local.get $2)
      (local.tee $6
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (call $function42
     (local.get $0)
     (local.get $6)
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function90
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function93 (type $64) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type88))
  (local $2 (ref $type29))
  (local $3 (ref $type29))
  (local $4 (ref $type29))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type88))
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i32)
  (local $scratch (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type88))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global309)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (local.set $7
     (struct.get $type88 0
      (local.tee $9
       (if (result (ref $type88))
        (i64.lt_s
         (if (result i64)
          (i64.lt_s
           (local.tee $10
            (i64.extend_i32_u
             (array.len
              (local.tee $2
               (struct.get $type28 1
                (local.get $0)
               )
              )
             )
            )
           )
           (local.tee $12
            (i64.extend_i32_u
             (array.len
              (local.tee $3
               (struct.get $type28 1
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (then
           (i64.const -1)
          )
          (else
           (if (result i64)
            (i64.gt_s
             (local.get $10)
             (local.get $12)
            )
            (then
             (i64.const 1)
            )
            (else
             (call $function58
              (local.get $2)
              (local.get $3)
              (i32.const 0)
              (i32.const 1)
              (local.get $10)
             )
            )
           )
          )
         )
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global132)
          )
         )
         (struct.new $type88
          (ref.as_non_null
           (global.get $global108)
          )
          (if (result (ref $type28))
           (struct.get $type28 0
            (local.get $0)
           )
           (then
            (struct.new $type28
             (i32.const 0)
             (struct.get $type28 1
              (local.get $0)
             )
            )
           )
           (else
            (local.get $0)
           )
          )
         )
        )
        (else
         (if (result (ref $type88))
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $3)
            )
           )
           (i64.const 1)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global109)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global248)
            )
           )
           (if
            (i64.gt_u
             (local.tee $10
              (i64.extend_i32_u
               (array.len
                (local.get $2)
               )
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $10
            (call $function81
             (local.tee $4
              (array.new_default $type29
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
             (local.get $2)
             (i64.extend_i32_s
              (array.get $type29
               (local.get $3)
               (i32.const 0)
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $2)
              )
             )
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (struct.new $type88
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function46
                  (local.get $4)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global108)
              )
             )
             (else
              (struct.new $type28
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global141)
              )
             )
             (call $function53
              (local.get $10)
             )
            )
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global300)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global109)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global239)
            )
           )
           (if
            (i64.gt_u
             (local.tee $12
              (i64.sub
               (local.tee $10
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (local.set $5
            (call $function79
             (local.get $2)
             (local.tee $12
              (i64.div_s
               (i64.const 1073741824)
               (i64.add
                (i64.extend_i32_s
                 (array.get $type29
                  (local.get $3)
                  (i32.wrap_i64
                   (local.get $12)
                  )
                 )
                )
                (i64.const 1)
               )
              )
             )
             (local.tee $11
              (i64.extend_i32_u
               (array.len
                (local.get $2)
               )
              )
             )
             (block (result (ref (exact $type29)))
              (if
               (i64.gt_u
                (local.tee $11
                 (i64.add
                  (local.get $11)
                  (i64.const 1)
                 )
                )
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (array.new_default $type29
               (i32.wrap_i64
                (local.get $11)
               )
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global239)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (local.set $3
            (call $function46
             (block (result (ref $type29))
              (local.set $scratch
               (call $function79
                (local.get $3)
                (local.get $12)
                (local.tee $11
                 (i64.extend_i32_u
                  (array.len
                   (local.get $3)
                  )
                 )
                )
                (block (result (ref (exact $type29)))
                 (if
                  (i64.gt_u
                   (local.tee $11
                    (i64.add
                     (local.get $11)
                     (i64.const 1)
                    )
                   )
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (array.new_default $type29
                  (i32.wrap_i64
                   (local.get $11)
                  )
                 )
                )
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
                (i64.const 0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global122)
               )
              )
              (local.get $scratch)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (if
            (i64.gt_u
             (local.tee $11
              (i64.add
               (i64.sub
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
                (local.get $10)
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global294)
            )
           )
           (drop
            (call $function89
             (local.tee $6
              (array.new_default $type29
               (i32.wrap_i64
                (local.get $11)
               )
              )
             )
             (local.get $5)
             (local.get $3)
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (array.copy $type29 $type29
            (local.tee $4
             (array.new_default $type29
              (local.tee $13
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
            )
            (i32.const 0)
            (local.get $5)
            (i32.const 0)
            (local.get $13)
           )
           (drop
            (ref.as_non_null
             (global.get $global248)
            )
           )
           (if
            (i64.ne
             (call $function81
              (local.get $4)
              (local.get $4)
              (local.get $12)
              (i32.const 0)
              (i32.const 1)
              (i64.extend_i32_u
               (array.len
                (local.get $4)
               )
              )
              (i64.const 0)
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (struct.new $type88
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function46
                  (local.get $6)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global108)
              )
             )
             (else
              (struct.new $type28
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (if (result (ref $type28))
              (i64.eqz
               (i64.extend_i32_u
                (array.len
                 (local.tee $2
                  (call $function46
                   (local.get $4)
                  )
                 )
                )
               )
              )
              (then
               (ref.as_non_null
                (global.get $global108)
               )
              )
              (else
               (struct.new $type28
                (i32.const 0)
                (local.get $2)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.set $8
     (struct.get $type88 1
      (local.get $9)
     )
    )
    (struct.new $type88
     (if (result (ref $type28))
      (select
       (i32.eqz
        (local.tee $13
         (struct.get $type28 0
          (local.get $1)
         )
        )
       )
       (local.get $13)
       (struct.get $type28 0
        (local.get $0)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global134)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global130)
        )
       )
       (if (result (ref $type28))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type28 1
            (local.get $7)
           )
          )
         )
        )
        (then
         (local.get $7)
        )
        (else
         (struct.new $type28
          (i32.eqz
           (struct.get $type28 0
            (local.get $7)
           )
          )
          (struct.get $type28 1
           (local.get $7)
          )
         )
        )
       )
      )
      (else
       (local.get $7)
      )
     )
     (if (result (ref $type28))
      (struct.get $type28 0
       (local.get $0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global134)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global130)
        )
       )
       (if (result (ref $type28))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type28 1
            (local.get $8)
           )
          )
         )
        )
        (then
         (local.get $8)
        )
        (else
         (struct.new $type28
          (i32.eqz
           (struct.get $type28 0
            (local.get $8)
           )
          )
          (struct.get $type28 1
           (local.get $8)
          )
         )
        )
       )
      )
      (else
       (local.get $8)
      )
     )
    )
   )
  )
 )
 (func $function95 (type $call80) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global316)
   )
  )
  (struct.get $type88 1
   (call $function93
    (local.get $0)
    (local.get $1)
   )
  )
 )
 (func $function97 (type $61) (param $0 (ref $type18)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i32)
  (local $7 i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.lt_s
       (local.tee $7
        (i64.sub
         (i64.extend_i32_u
          (array.get $type19
           (if (result (ref $type19))
            (i32.lt_u
             (local.tee $6
              (i32.wrap_i64
               (local.get $4)
              )
             )
             (i32.const 8192)
            )
            (then
             (struct.get $type18 2
              (local.get $0)
             )
            )
            (else
             (ref.as_non_null
              (array.get $type20
               (struct.get $type18 3
                (local.get $0)
               )
               (i32.sub
                (i32.shr_u
                 (local.get $6)
                 (i32.const 13)
                )
                (i32.const 1)
               )
              )
             )
            )
           )
           (i32.and
            (local.get $6)
            (i32.const 8191)
           )
          )
         )
         (i64.const 48)
        )
       )
       (i64.const 0)
      )
      (then
       (i32.const 1)
      )
      (else
       (i64.gt_s
        (local.get $7)
        (i64.const 9)
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function97
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
       (i64.add
        (local.get $7)
        (i64.mul
         (local.get $5)
         (i64.const 10)
        )
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function98 (type $60) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
     (then
      (i64.const 10)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (i64.const 100)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
         )
         (then
          (i64.const 1000)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
           )
           (then
            (i64.const 10000)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (i64.const 100000)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.sub
                  (local.get $0)
                  (i64.const 1)
                 )
                )
               )
               (then
                (i64.const 1000000)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (i64.const 10000000)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (i64.const 100000000)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (i64.const 1000000000)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.sub
                          (local.get $0)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (i64.const 10000000000)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (i64.const 100000000000)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.sub
                              (local.get $0)
                              (i64.const 1)
                             )
                            )
                           )
                           (then
                            (i64.const 1000000000000)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.sub
                                (local.get $0)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (i64.const 10000000000000)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                               )
                               (then
                                (i64.const 100000000000000)
                               )
                               (else
                                (if (result i64)
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.sub
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 1000000000000000)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.sub
                                      (local.get $0)
                                      (i64.const 1)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 10000000000000000)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.sub
                                        (local.get $0)
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 100000000000000000)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.sub
                                          (local.get $0)
                                          (i64.const 1)
                                         )
                                        )
                                       )
                                       (then
                                        (i64.const 1000000000000000000)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.sub
                                            (local.get $0)
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                         (then
                                          (i64.const -8446744073709551616)
                                         )
                                         (else
                                          (return_call $function99
                                           (i64.const 10)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.sub
                                            (local.get $0)
                                            (i64.const 1)
                                           )
                                           (i64.const 7766279631452241920)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function99 (type $59) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function99
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (i64.mul
      (local.get $0)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function101 (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 (ref $type28)) (result (ref $type28))
  (local $7 i64)
  (local $8 i64)
  (local $9 (ref $type29))
  (local $10 (ref $type28))
  (local $scratch (ref $type29))
  (local $scratch_12 i64)
  (local $scratch_13 (ref $type28))
  (if (result (ref $type28))
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (if (result (ref $type28))
     (local.get $1)
     (then
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (local.get $6)
          )
         )
        )
       )
       (then
        (local.get $6)
       )
       (else
        (struct.new $type28
         (i32.eqz
          (struct.get $type28 0
           (local.get $6)
          )
         )
         (struct.get $type28 1
          (local.get $6)
         )
        )
       )
      )
     )
     (else
      (local.get $6)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (local.set $7
     (call $function98
      (local.tee $8
       (select
        (i64.const 9)
        (local.tee $8
         (i64.sub
          (local.get $2)
          (local.get $5)
         )
        )
        (i64.gt_s
         (local.get $8)
         (i64.const 9)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global239)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (local.set $6
     (call $function71
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $9
           (call $function46
            (block (result (ref $type29))
             (local.set $scratch
              (call $function79
               (local.tee $9
                (struct.get $type28 1
                 (local.get $6)
                )
               )
               (local.get $7)
               (local.tee $7
                (i64.extend_i32_u
                 (array.len
                  (local.get $9)
                 )
                )
               )
               (block (result (ref (exact $type29)))
                (if
                 (i64.gt_u
                  (local.tee $7
                   (i64.add
                    (local.get $7)
                    (i64.const 1)
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $7)
                 )
                )
               )
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type28
         (i32.const 0)
         (local.get $9)
        )
       )
      )
      (block (result (ref $type28))
       (drop
        (ref.as_non_null
         (global.get $global328)
        )
       )
       (local.set $scratch_13
        (call $function53
         (block (result i64)
          (local.set $scratch_12
           (call $function97
            (local.get $0)
            (i64.add
             (local.get $5)
             (local.get $8)
            )
            (i32.const 0)
            (i32.const 1)
            (local.get $5)
            (i64.const 0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global141)
           )
          )
          (local.get $scratch_12)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global211)
        )
       )
       (local.get $scratch_13)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function101
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (local.get $8)
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function102 (type $call93) (param $0 (ref $type18)) (result (ref $type28))
  (local $1 i32)
  (local $2 i32)
  (local $3 i64)
  (local $4 i64)
  (if
   (i64.eqz
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global342)
     )
    )
    (if
     (i64.eq
      (local.tee $3
       (i64.extend_i32_u
        (i32.or
         (local.tee $2
          (i32.eq
           (local.tee $1
            (array.get $type19
             (struct.get $type18 2
              (local.get $0)
             )
             (i32.const 0)
            )
           )
           (i32.const 45)
          )
         )
         (i32.eq
          (local.get $1)
          (i32.const 43)
         )
        )
       )
      )
      (local.tee $4
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (return_call $function101
       (local.get $0)
       (local.get $2)
       (local.get $4)
       (i32.const 0)
       (i32.const 1)
       (local.get $3)
       (ref.as_non_null
        (global.get $global108)
       )
      )
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function105 (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 (ref $type28)) (result (ref $type28))
  (local $7 i64)
  (local $8 i32)
  (local $9 (ref $type29))
  (local $10 (ref $type28))
  (local $scratch (ref $type29))
  (local $scratch_12 (ref $type28))
  (if (result (ref $type28))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $5)
   )
   (then
    (if (result (ref $type28))
     (local.get $1)
     (then
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (local.get $6)
          )
         )
        )
       )
       (then
        (local.get $6)
       )
       (else
        (struct.new $type28
         (i32.eqz
          (struct.get $type28 0
           (local.get $6)
          )
         )
         (struct.get $type28 1
          (local.get $6)
         )
        )
       )
      )
     )
     (else
      (local.get $6)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global239)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (local.set $6
     (call $function71
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $9
           (call $function46
            (block (result (ref $type29))
             (local.set $scratch
              (call $function79
               (local.tee $9
                (struct.get $type28 1
                 (local.get $6)
                )
               )
               (local.get $2)
               (local.tee $7
                (i64.extend_i32_u
                 (array.len
                  (local.get $9)
                 )
                )
               )
               (block (result (ref (exact $type29)))
                (if
                 (i64.gt_u
                  (local.tee $7
                   (i64.add
                    (local.get $7)
                    (i64.const 1)
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type29
                 (i32.wrap_i64
                  (local.get $7)
                 )
                )
               )
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type28
         (i32.const 0)
         (local.get $9)
        )
       )
      )
      (block (result (ref $type28))
       (if
        (i64.ge_u
         (local.get $5)
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global358)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global141)
        )
       )
       (local.set $scratch_12
        (call $function53
         (if (result i64)
          (if (result i32)
           (i64.lt_s
            (local.tee $7
             (if (result i64)
              (if (result i32)
               (i64.ge_u
                (local.tee $7
                 (i64.extend_i32_u
                  (array.get $type19
                   (if (result (ref $type19))
                    (i32.lt_u
                     (local.tee $8
                      (i32.wrap_i64
                       (local.get $5)
                      )
                     )
                     (i32.const 8192)
                    )
                    (then
                     (struct.get $type18 2
                      (local.get $0)
                     )
                    )
                    (else
                     (ref.as_non_null
                      (array.get $type20
                       (struct.get $type18 3
                        (local.get $0)
                       )
                       (i32.sub
                        (i32.shr_u
                         (local.get $8)
                         (i32.const 13)
                        )
                        (i32.const 1)
                       )
                      )
                     )
                    )
                   )
                   (i32.and
                    (local.get $8)
                    (i32.const 8191)
                   )
                  )
                 )
                )
                (i64.const 48)
               )
               (then
                (i64.le_u
                 (local.get $7)
                 (i64.const 57)
                )
               )
               (else
                (i32.const 0)
               )
              )
              (then
               (i64.sub
                (local.get $7)
                (i64.const 48)
               )
              )
              (else
               (if (result i64)
                (i32.and
                 (i64.le_u
                  (local.get $7)
                  (i64.const 90)
                 )
                 (i64.ge_u
                  (local.get $7)
                  (i64.const 65)
                 )
                )
                (then
                 (i64.sub
                  (local.get $7)
                  (i64.const 55)
                 )
                )
                (else
                 (select
                  (i64.sub
                   (local.get $7)
                   (i64.const 87)
                  )
                  (i64.const -1)
                  (i32.and
                   (i64.le_u
                    (local.get $7)
                    (i64.const 122)
                   )
                   (i64.ge_u
                    (local.get $7)
                    (i64.const 97)
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (i64.const 0)
           )
           (then
            (i32.const 1)
           )
           (else
            (i64.le_s
             (local.get $2)
             (local.get $7)
            )
           )
          )
          (then
           (unreachable)
          )
          (else
           (local.get $7)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global211)
        )
       )
       (local.get $scratch_12)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function105
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function106 (type $call96) (param $0 (ref $type18)) (param $1 i64) (result (ref $type28))
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (if
   (if (result i32)
    (i64.lt_s
     (local.get $1)
     (i64.const 2)
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.or
      (i64.eqz
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $0)
        )
       )
      )
      (i64.gt_s
       (local.get $1)
       (i64.const 36)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i64.eq
      (local.get $1)
      (i64.const 10)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global353)
       )
      )
      (return_call $function102
       (local.get $0)
      )
     )
     (else
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global363)
       )
      )
      (if
       (i64.eq
        (local.tee $4
         (i64.extend_i32_u
          (i32.or
           (local.tee $3
            (i32.eq
             (local.tee $2
              (array.get $type19
               (struct.get $type18 2
                (local.get $0)
               )
               (i32.const 0)
              )
             )
             (i32.const 45)
            )
           )
           (i32.eq
            (local.get $2)
            (i32.const 43)
           )
          )
         )
        )
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
       (else
        (return_call $function105
         (local.get $0)
         (local.get $3)
         (local.get $1)
         (i32.const 0)
         (i32.const 1)
         (local.get $4)
         (ref.as_non_null
          (global.get $global108)
         )
        )
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function107 (type $call97) (param $0 (ref $type29)) (result (ref null $type44))
  (local $1 (ref $type44))
  (local $2 (ref $type29))
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global383)
   )
  )
  (if (result (ref null $type44))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.tee $2
       (if (result (ref $type29))
        (i64.eqz
         (local.tee $3
          (i64.extend_i32_u
           (array.len
            (local.get $0)
           )
          )
         )
        )
        (then
         (array.new_fixed $type29 0)
        )
        (else
         (if
          (i64.gt_u
           (local.get $3)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (array.new $type29
           (array.get $type29
            (local.get $0)
            (i32.const 0)
           )
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
         (if
          (i64.gt_u
           (local.get $3)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.copy $type29 $type29
          (local.get $2)
          (i32.const 0)
          (local.get $0)
          (i32.const 0)
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (local.get $2)
        )
       )
      )
     )
    )
   )
   (then
    (ref.null none)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global248)
     )
    )
    (local.set $1
     (struct.new $type44
      (call $function81
       (local.get $2)
       (local.get $2)
       (i64.const 1000000000)
       (i32.const 0)
       (i32.const 1)
       (i64.extend_i32_u
        (array.len
         (local.get $2)
        )
       )
       (i64.const 0)
      )
      (block (result nullref)
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (ref.null none)
      )
     )
    )
    (if (result (ref $type44))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $0
         (call $function46
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global248)
       )
      )
      (local.set $1
       (struct.new $type44
        (call $function81
         (local.get $0)
         (local.get $0)
         (i64.const 1000000000)
         (i32.const 0)
         (i32.const 1)
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (i64.const 0)
        )
        (block (result (ref $type44))
         (drop
          (ref.as_non_null
           (global.get $global122)
          )
         )
         (local.get $1)
        )
       )
      )
      (if (result (ref $type44))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $0
           (call $function46
            (local.get $0)
           )
          )
         )
        )
       )
       (then
        (local.get $1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global248)
         )
        )
        (local.set $1
         (struct.new $type44
          (call $function81
           (local.get $0)
           (local.get $0)
           (i64.const 1000000000)
           (i32.const 0)
           (i32.const 1)
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (i64.const 0)
          )
          (block (result (ref $type44))
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.get $1)
          )
         )
        )
        (if (result (ref $type44))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (local.tee $0
             (call $function46
              (local.get $0)
             )
            )
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global248)
           )
          )
          (local.set $1
           (struct.new $type44
            (call $function81
             (local.get $0)
             (local.get $0)
             (i64.const 1000000000)
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $0)
              )
             )
             (i64.const 0)
            )
            (block (result (ref $type44))
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $1)
            )
           )
          )
          (if (result (ref $type44))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (local.tee $0
               (call $function46
                (local.get $0)
               )
              )
             )
            )
           )
           (then
            (local.get $1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global248)
             )
            )
            (local.set $1
             (struct.new $type44
              (call $function81
               (local.get $0)
               (local.get $0)
               (i64.const 1000000000)
               (i32.const 0)
               (i32.const 1)
               (i64.extend_i32_u
                (array.len
                 (local.get $0)
                )
               )
               (i64.const 0)
              )
              (block (result (ref $type44))
               (drop
                (ref.as_non_null
                 (global.get $global122)
                )
               )
               (local.get $1)
              )
             )
            )
            (if (result (ref $type44))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $0
                 (call $function46
                  (local.get $0)
                 )
                )
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global248)
               )
              )
              (local.set $1
               (struct.new $type44
                (call $function81
                 (local.get $0)
                 (local.get $0)
                 (i64.const 1000000000)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.extend_i32_u
                  (array.len
                   (local.get $0)
                  )
                 )
                 (i64.const 0)
                )
                (block (result (ref $type44))
                 (drop
                  (ref.as_non_null
                   (global.get $global122)
                  )
                 )
                 (local.get $1)
                )
               )
              )
              (if (result (ref $type44))
               (i64.eqz
                (i64.extend_i32_u
                 (array.len
                  (local.tee $0
                   (call $function46
                    (local.get $0)
                   )
                  )
                 )
                )
               )
               (then
                (local.get $1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global248)
                 )
                )
                (local.set $1
                 (struct.new $type44
                  (call $function81
                   (local.get $0)
                   (local.get $0)
                   (i64.const 1000000000)
                   (i32.const 0)
                   (i32.const 1)
                   (i64.extend_i32_u
                    (array.len
                     (local.get $0)
                    )
                   )
                   (i64.const 0)
                  )
                  (block (result (ref $type44))
                   (drop
                    (ref.as_non_null
                     (global.get $global122)
                    )
                   )
                   (local.get $1)
                  )
                 )
                )
                (if (result (ref $type44))
                 (i64.eqz
                  (i64.extend_i32_u
                   (array.len
                    (local.tee $0
                     (call $function46
                      (local.get $0)
                     )
                    )
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global248)
                   )
                  )
                  (local.set $1
                   (struct.new $type44
                    (call $function81
                     (local.get $0)
                     (local.get $0)
                     (i64.const 1000000000)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.extend_i32_u
                      (array.len
                       (local.get $0)
                      )
                     )
                     (i64.const 0)
                    )
                    (block (result (ref $type44))
                     (drop
                      (ref.as_non_null
                       (global.get $global122)
                      )
                     )
                     (local.get $1)
                    )
                   )
                  )
                  (if (result (ref $type44))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (local.tee $0
                       (call $function46
                        (local.get $0)
                       )
                      )
                     )
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global248)
                     )
                    )
                    (local.set $1
                     (struct.new $type44
                      (call $function81
                       (local.get $0)
                       (local.get $0)
                       (i64.const 1000000000)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.extend_i32_u
                        (array.len
                         (local.get $0)
                        )
                       )
                       (i64.const 0)
                      )
                      (block (result (ref $type44))
                       (drop
                        (ref.as_non_null
                         (global.get $global122)
                        )
                       )
                       (local.get $1)
                      )
                     )
                    )
                    (if (result (ref $type44))
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (local.tee $0
                         (call $function46
                          (local.get $0)
                         )
                        )
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global248)
                       )
                      )
                      (local.set $1
                       (struct.new $type44
                        (call $function81
                         (local.get $0)
                         (local.get $0)
                         (i64.const 1000000000)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.extend_i32_u
                          (array.len
                           (local.get $0)
                          )
                         )
                         (i64.const 0)
                        )
                        (block (result (ref $type44))
                         (drop
                          (ref.as_non_null
                           (global.get $global122)
                          )
                         )
                         (local.get $1)
                        )
                       )
                      )
                      (if (result (ref $type44))
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (local.tee $0
                           (call $function46
                            (local.get $0)
                           )
                          )
                         )
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global248)
                         )
                        )
                        (local.set $1
                         (struct.new $type44
                          (call $function81
                           (local.get $0)
                           (local.get $0)
                           (i64.const 1000000000)
                           (i32.const 0)
                           (i32.const 1)
                           (i64.extend_i32_u
                            (array.len
                             (local.get $0)
                            )
                           )
                           (i64.const 0)
                          )
                          (block (result (ref $type44))
                           (drop
                            (ref.as_non_null
                             (global.get $global122)
                            )
                           )
                           (local.get $1)
                          )
                         )
                        )
                        (if (result (ref $type44))
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (local.tee $0
                             (call $function46
                              (local.get $0)
                             )
                            )
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global248)
                           )
                          )
                          (local.set $1
                           (struct.new $type44
                            (call $function81
                             (local.get $0)
                             (local.get $0)
                             (i64.const 1000000000)
                             (i32.const 0)
                             (i32.const 1)
                             (i64.extend_i32_u
                              (array.len
                               (local.get $0)
                              )
                             )
                             (i64.const 0)
                            )
                            (block (result (ref $type44))
                             (drop
                              (ref.as_non_null
                               (global.get $global122)
                              )
                             )
                             (local.get $1)
                            )
                           )
                          )
                          (if (result (ref $type44))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (local.tee $0
                               (call $function46
                                (local.get $0)
                               )
                              )
                             )
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global248)
                             )
                            )
                            (local.set $1
                             (struct.new $type44
                              (call $function81
                               (local.get $0)
                               (local.get $0)
                               (i64.const 1000000000)
                               (i32.const 0)
                               (i32.const 1)
                               (i64.extend_i32_u
                                (array.len
                                 (local.get $0)
                                )
                               )
                               (i64.const 0)
                              )
                              (block (result (ref $type44))
                               (drop
                                (ref.as_non_null
                                 (global.get $global122)
                                )
                               )
                               (local.get $1)
                              )
                             )
                            )
                            (if (result (ref $type44))
                             (i64.eqz
                              (i64.extend_i32_u
                               (array.len
                                (local.tee $0
                                 (call $function46
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global248)
                               )
                              )
                              (local.set $1
                               (struct.new $type44
                                (call $function81
                                 (local.get $0)
                                 (local.get $0)
                                 (i64.const 1000000000)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.extend_i32_u
                                  (array.len
                                   (local.get $0)
                                  )
                                 )
                                 (i64.const 0)
                                )
                                (block (result (ref $type44))
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global122)
                                  )
                                 )
                                 (local.get $1)
                                )
                               )
                              )
                              (if (result (ref $type44))
                               (i64.eqz
                                (i64.extend_i32_u
                                 (array.len
                                  (local.tee $0
                                   (call $function46
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global248)
                                 )
                                )
                                (local.set $1
                                 (struct.new $type44
                                  (call $function81
                                   (local.get $0)
                                   (local.get $0)
                                   (i64.const 1000000000)
                                   (i32.const 0)
                                   (i32.const 1)
                                   (i64.extend_i32_u
                                    (array.len
                                     (local.get $0)
                                    )
                                   )
                                   (i64.const 0)
                                  )
                                  (block (result (ref $type44))
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global122)
                                    )
                                   )
                                   (local.get $1)
                                  )
                                 )
                                )
                                (if (result (ref $type44))
                                 (i64.eqz
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.tee $0
                                     (call $function46
                                      (local.get $0)
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global248)
                                   )
                                  )
                                  (local.set $1
                                   (struct.new $type44
                                    (call $function81
                                     (local.get $0)
                                     (local.get $0)
                                     (i64.const 1000000000)
                                     (i32.const 0)
                                     (i32.const 1)
                                     (i64.extend_i32_u
                                      (array.len
                                       (local.get $0)
                                      )
                                     )
                                     (i64.const 0)
                                    )
                                    (block (result (ref $type44))
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global122)
                                      )
                                     )
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (if (result (ref $type44))
                                   (i64.eqz
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.tee $0
                                       (call $function46
                                        (local.get $0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global248)
                                     )
                                    )
                                    (local.set $1
                                     (struct.new $type44
                                      (call $function81
                                       (local.get $0)
                                       (local.get $0)
                                       (i64.const 1000000000)
                                       (i32.const 0)
                                       (i32.const 1)
                                       (i64.extend_i32_u
                                        (array.len
                                         (local.get $0)
                                        )
                                       )
                                       (i64.const 0)
                                      )
                                      (block (result (ref $type44))
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global122)
                                        )
                                       )
                                       (local.get $1)
                                      )
                                     )
                                    )
                                    (if (result (ref $type44))
                                     (i64.eqz
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.tee $0
                                         (call $function46
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global248)
                                       )
                                      )
                                      (local.set $1
                                       (struct.new $type44
                                        (call $function81
                                         (local.get $0)
                                         (local.get $0)
                                         (i64.const 1000000000)
                                         (i32.const 0)
                                         (i32.const 1)
                                         (i64.extend_i32_u
                                          (array.len
                                           (local.get $0)
                                          )
                                         )
                                         (i64.const 0)
                                        )
                                        (block (result (ref $type44))
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global122)
                                          )
                                         )
                                         (local.get $1)
                                        )
                                       )
                                      )
                                      (if (result (ref $type44))
                                       (i64.eqz
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.tee $0
                                           (call $function46
                                            (local.get $0)
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global248)
                                         )
                                        )
                                        (local.set $1
                                         (struct.new $type44
                                          (call $function81
                                           (local.get $0)
                                           (local.get $0)
                                           (i64.const 1000000000)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.extend_i32_u
                                            (array.len
                                             (local.get $0)
                                            )
                                           )
                                           (i64.const 0)
                                          )
                                          (block (result (ref $type44))
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global122)
                                            )
                                           )
                                           (local.get $1)
                                          )
                                         )
                                        )
                                        (if (result (ref $type44))
                                         (i64.eqz
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.tee $0
                                             (call $function46
                                              (local.get $0)
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global248)
                                           )
                                          )
                                          (local.set $3
                                           (call $function80
                                            (local.get $0)
                                            (local.get $0)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global122)
                                           )
                                          )
                                          (return_call $function108
                                           (i32.const 0)
                                           (i32.const 1)
                                           (call $function46
                                            (local.get $0)
                                           )
                                           (struct.new $type44
                                            (local.get $3)
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function108 (type $53) (param $0 i32) (param $1 i32) (param $2 (ref $type29)) (param $3 (ref $type44)) (result (ref null $type44))
  (local $4 i64)
  (if (result (ref $type44))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.get $2)
     )
    )
   )
   (then
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global248)
     )
    )
    (local.set $4
     (call $function80
      (local.get $2)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (local.set $2
     (call $function46
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function108
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (struct.new $type44
      (local.get $4)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function110 (type $call72) (param $0 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $0)
    (i64.const 10)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 10)
       )
      )
      (i64.const 10)
     )
     (then
      (i64.const 2)
     )
     (else
      (if (result i64)
       (i64.lt_s
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 10)
         )
        )
        (i64.const 10)
       )
       (then
        (i64.const 3)
       )
       (else
        (if (result i64)
         (i64.lt_s
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 10)
           )
          )
          (i64.const 10)
         )
         (then
          (i64.const 4)
         )
         (else
          (if (result i64)
           (i64.lt_s
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 10)
             )
            )
            (i64.const 10)
           )
           (then
            (i64.const 5)
           )
           (else
            (if (result i64)
             (i64.lt_s
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 10)
               )
              )
              (i64.const 10)
             )
             (then
              (i64.const 6)
             )
             (else
              (if (result i64)
               (i64.lt_s
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 10)
                 )
                )
                (i64.const 10)
               )
               (then
                (i64.const 7)
               )
               (else
                (if (result i64)
                 (i64.lt_s
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 10)
                   )
                  )
                  (i64.const 10)
                 )
                 (then
                  (i64.const 8)
                 )
                 (else
                  (if (result i64)
                   (i64.lt_s
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 10)
                     )
                    )
                    (i64.const 10)
                   )
                   (then
                    (i64.const 9)
                   )
                   (else
                    (if (result i64)
                     (i64.lt_s
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 10)
                       )
                      )
                      (i64.const 10)
                     )
                     (then
                      (i64.const 10)
                     )
                     (else
                      (if (result i64)
                       (i64.lt_s
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 10)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (i64.const 11)
                       )
                       (else
                        (if (result i64)
                         (i64.lt_s
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 10)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (i64.const 12)
                         )
                         (else
                          (if (result i64)
                           (i64.lt_s
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 10)
                             )
                            )
                            (i64.const 10)
                           )
                           (then
                            (i64.const 13)
                           )
                           (else
                            (if (result i64)
                             (i64.lt_s
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 10)
                               )
                              )
                              (i64.const 10)
                             )
                             (then
                              (i64.const 14)
                             )
                             (else
                              (if (result i64)
                               (i64.lt_s
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 10)
                                 )
                                )
                                (i64.const 10)
                               )
                               (then
                                (i64.const 15)
                               )
                               (else
                                (if (result i64)
                                 (i64.lt_s
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 10)
                                   )
                                  )
                                  (i64.const 10)
                                 )
                                 (then
                                  (i64.const 16)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.lt_s
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 10)
                                     )
                                    )
                                    (i64.const 10)
                                   )
                                   (then
                                    (i64.const 17)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.lt_s
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 10)
                                       )
                                      )
                                      (i64.const 10)
                                     )
                                     (then
                                      (i64.const 18)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.lt_s
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 10)
                                         )
                                        )
                                        (i64.const 10)
                                       )
                                       (then
                                        (i64.const 19)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.lt_s
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 10)
                                           )
                                          )
                                          (i64.const 10)
                                         )
                                         (then
                                          (i64.const 20)
                                         )
                                         (else
                                          (return_call $function111
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 10)
                                           )
                                           (i64.const 21)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function111 (type $84) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $2)
    (i64.const 10)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function111
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 10)
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function112 (type $call51) (param $0 (ref null $type44)) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.tee $0
       (struct.get $type44 1
        (local.get $0)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (ref.is_null
        (local.tee $0
         (struct.get $type44 1
          (local.get $0)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $0
           (struct.get $type44 1
            (local.get $0)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $0
             (struct.get $type44 1
              (local.get $0)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $0
               (struct.get $type44 1
                (local.get $0)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $0
                 (struct.get $type44 1
                  (local.get $0)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type44 1
                    (local.get $0)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type44 1
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $0
                       (struct.get $type44 1
                        (local.get $0)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (ref.is_null
                        (local.tee $0
                         (struct.get $type44 1
                          (local.get $0)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (ref.is_null
                          (local.tee $0
                           (struct.get $type44 1
                            (local.get $0)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (ref.is_null
                            (local.tee $0
                             (struct.get $type44 1
                              (local.get $0)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (ref.is_null
                              (local.tee $0
                               (struct.get $type44 1
                                (local.get $0)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (ref.is_null
                                (local.tee $0
                                 (struct.get $type44 1
                                  (local.get $0)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (if (result i64)
                                 (ref.is_null
                                  (local.tee $0
                                   (struct.get $type44 1
                                    (local.get $0)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 15)
                                 )
                                 (else
                                  (if (result i64)
                                   (ref.is_null
                                    (local.tee $0
                                     (struct.get $type44 1
                                      (local.get $0)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 16)
                                   )
                                   (else
                                    (if (result i64)
                                     (ref.is_null
                                      (local.tee $0
                                       (struct.get $type44 1
                                        (local.get $0)
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 17)
                                     )
                                     (else
                                      (if (result i64)
                                       (ref.is_null
                                        (local.tee $0
                                         (struct.get $type44 1
                                          (local.get $0)
                                         )
                                        )
                                       )
                                       (then
                                        (i64.const 18)
                                       )
                                       (else
                                        (if (result i64)
                                         (ref.is_null
                                          (local.tee $0
                                           (struct.get $type44 1
                                            (local.get $0)
                                           )
                                          )
                                         )
                                         (then
                                          (i64.const 19)
                                         )
                                         (else
                                          (return_call $function113
                                           (i32.const 0)
                                           (i32.const 1)
                                           (struct.get $type44 1
                                            (local.get $0)
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function113 (type $51) (param $0 i32) (param $1 i32) (param $2 (ref null $type44)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type44 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function113
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function115 (type $50) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (if (result i32)
   (i64.eqz
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $6
       (i64.add
        (i64.rem_s
         (local.get $5)
         (i64.const 10)
        )
        (i64.const 48)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $6)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $6)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.tee $7
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $8
        (i32.wrap_i64
         (local.get $7)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $8)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $8)
      (i32.const 8191)
     )
     (i32.wrap_i64
      (local.get $6)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function115
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (i64.sub
      (local.get $4)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $5)
      (i64.const 10)
     )
    )
   )
  )
 )
 (func $function116 (type $call99) (param $0 (ref $type18)) (param $1 i64) (param $2 (ref null $type44)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global397)
     )
    )
    (drop
     (call $function115
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (i64.add
       (local.get $1)
       (i64.const 9)
      )
      (i64.const 9)
      (struct.get $type44 0
       (local.get $2)
      )
     )
    )
    (local.set $2
     (struct.get $type44 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready406)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global406)
     )
    )
    (return_call $function116
     (local.get $0)
     (i64.add
      (local.get $1)
      (i64.const 9)
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function117 (type $call100) (param $0 (ref $type28)) (result (ref $type18))
  (local $1 (ref null $type44))
  (local $2 (ref $type18))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type18))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global63)
     )
    )
    (if
     (i32.eqz
      (global.get $ready65)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global65)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global68)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (return_call $function30
     (call $string-new
      (i32.const 1)
     )
     (i32.const 0)
     (i32.const 1)
     (struct.new_default $type49)
     (i64.const 0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global377)
     )
    )
    (local.set $1
     (call $function107
      (struct.get $type28 1
       (local.get $0)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global387)
     )
    )
    (local.set $3
     (i64.add
      (i64.add
       (local.tee $5
        (i64.extend_i32_u
         (i32.ne
          (local.tee $6
           (struct.get $type28 0
            (local.get $0)
           )
          )
          (i32.const 0)
         )
        )
       )
       (local.tee $4
        (call $function110
         (struct.get $type44 0
          (local.get $1)
         )
        )
       )
      )
      (block (result i64)
       (drop
        (ref.as_non_null
         (global.get $global392)
        )
       )
       (i64.mul
        (i64.sub
         (call $function112
          (local.get $1)
         )
         (i64.const 1)
        )
        (i64.const 9)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $string-new
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if
     (local.get $6)
     (then
      (if
       (i32.ne
        (struct.get $type18 0
         (local.get $2)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type19
       (struct.get $type18 2
        (local.get $2)
       )
       (i32.const 0)
       (i32.const 45)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global406)
     )
    )
    (drop
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global397)
        )
       )
       (drop
        (call $function115
         (local.get $2)
         (i32.const 0)
         (i32.const 1)
         (i64.add
          (local.get $4)
          (local.get $5)
         )
         (local.get $4)
         (struct.get $type44 0
          (local.get $1)
         )
        )
       )
       (local.set $1
        (struct.get $type44 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready406)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global406)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global397)
          )
         )
         (drop
          (call $function115
           (local.get $2)
           (i32.const 0)
           (i32.const 1)
           (i64.add
            (local.tee $3
             (i64.add
              (local.get $4)
              (local.get $5)
             )
            )
            (i64.const 9)
           )
           (i64.const 9)
           (struct.get $type44 0
            (local.get $1)
           )
          )
         )
         (local.set $1
          (struct.get $type44 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready406)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global406)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global397)
            )
           )
           (drop
            (call $function115
             (local.get $2)
             (i32.const 0)
             (i32.const 1)
             (i64.add
              (local.tee $3
               (i64.add
                (local.get $3)
                (i64.const 9)
               )
              )
              (i64.const 9)
             )
             (i64.const 9)
             (struct.get $type44 0
              (local.get $1)
             )
            )
           )
           (local.set $1
            (struct.get $type44 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready406)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global406)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global397)
              )
             )
             (drop
              (call $function115
               (local.get $2)
               (i32.const 0)
               (i32.const 1)
               (i64.add
                (local.tee $3
                 (i64.add
                  (local.get $3)
                  (i64.const 9)
                 )
                )
                (i64.const 9)
               )
               (i64.const 9)
               (struct.get $type44 0
                (local.get $1)
               )
              )
             )
             (local.set $1
              (struct.get $type44 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready406)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global406)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global397)
                )
               )
               (drop
                (call $function115
                 (local.get $2)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.add
                  (local.tee $3
                   (i64.add
                    (local.get $3)
                    (i64.const 9)
                   )
                  )
                  (i64.const 9)
                 )
                 (i64.const 9)
                 (struct.get $type44 0
                  (local.get $1)
                 )
                )
               )
               (local.set $1
                (struct.get $type44 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready406)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global406)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global397)
                  )
                 )
                 (drop
                  (call $function115
                   (local.get $2)
                   (i32.const 0)
                   (i32.const 1)
                   (i64.add
                    (local.tee $3
                     (i64.add
                      (local.get $3)
                      (i64.const 9)
                     )
                    )
                    (i64.const 9)
                   )
                   (i64.const 9)
                   (struct.get $type44 0
                    (local.get $1)
                   )
                  )
                 )
                 (local.set $1
                  (struct.get $type44 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready406)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global406)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global397)
                    )
                   )
                   (drop
                    (call $function115
                     (local.get $2)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.add
                      (local.tee $3
                       (i64.add
                        (local.get $3)
                        (i64.const 9)
                       )
                      )
                      (i64.const 9)
                     )
                     (i64.const 9)
                     (struct.get $type44 0
                      (local.get $1)
                     )
                    )
                   )
                   (local.set $1
                    (struct.get $type44 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready406)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global406)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global397)
                      )
                     )
                     (drop
                      (call $function115
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.add
                        (local.tee $3
                         (i64.add
                          (local.get $3)
                          (i64.const 9)
                         )
                        )
                        (i64.const 9)
                       )
                       (i64.const 9)
                       (struct.get $type44 0
                        (local.get $1)
                       )
                      )
                     )
                     (local.set $1
                      (struct.get $type44 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready406)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global406)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global397)
                        )
                       )
                       (drop
                        (call $function115
                         (local.get $2)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.add
                          (local.tee $3
                           (i64.add
                            (local.get $3)
                            (i64.const 9)
                           )
                          )
                          (i64.const 9)
                         )
                         (i64.const 9)
                         (struct.get $type44 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.set $1
                        (struct.get $type44 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready406)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global406)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $1)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global397)
                          )
                         )
                         (drop
                          (call $function115
                           (local.get $2)
                           (i32.const 0)
                           (i32.const 1)
                           (i64.add
                            (local.tee $3
                             (i64.add
                              (local.get $3)
                              (i64.const 9)
                             )
                            )
                            (i64.const 9)
                           )
                           (i64.const 9)
                           (struct.get $type44 0
                            (local.get $1)
                           )
                          )
                         )
                         (local.set $1
                          (struct.get $type44 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready406)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global406)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global397)
                            )
                           )
                           (drop
                            (call $function115
                             (local.get $2)
                             (i32.const 0)
                             (i32.const 1)
                             (i64.add
                              (local.tee $3
                               (i64.add
                                (local.get $3)
                                (i64.const 9)
                               )
                              )
                              (i64.const 9)
                             )
                             (i64.const 9)
                             (struct.get $type44 0
                              (local.get $1)
                             )
                            )
                           )
                           (local.set $1
                            (struct.get $type44 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready406)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global406)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (drop
                              (ref.as_non_null
                               (global.get $global397)
                              )
                             )
                             (drop
                              (call $function115
                               (local.get $2)
                               (i32.const 0)
                               (i32.const 1)
                               (i64.add
                                (local.tee $3
                                 (i64.add
                                  (local.get $3)
                                  (i64.const 9)
                                 )
                                )
                                (i64.const 9)
                               )
                               (i64.const 9)
                               (struct.get $type44 0
                                (local.get $1)
                               )
                              )
                             )
                             (local.set $1
                              (struct.get $type44 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready406)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global406)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $1)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (drop
                                (ref.as_non_null
                                 (global.get $global397)
                                )
                               )
                               (drop
                                (call $function115
                                 (local.get $2)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.add
                                  (local.tee $3
                                   (i64.add
                                    (local.get $3)
                                    (i64.const 9)
                                   )
                                  )
                                  (i64.const 9)
                                 )
                                 (i64.const 9)
                                 (struct.get $type44 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (local.set $1
                                (struct.get $type44 1
                                 (local.get $1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready406)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global406)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $1)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global397)
                                  )
                                 )
                                 (drop
                                  (call $function115
                                   (local.get $2)
                                   (i32.const 0)
                                   (i32.const 1)
                                   (i64.add
                                    (local.tee $3
                                     (i64.add
                                      (local.get $3)
                                      (i64.const 9)
                                     )
                                    )
                                    (i64.const 9)
                                   )
                                   (i64.const 9)
                                   (struct.get $type44 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (local.set $1
                                  (struct.get $type44 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready406)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global406)
                                  )
                                 )
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global397)
                                    )
                                   )
                                   (drop
                                    (call $function115
                                     (local.get $2)
                                     (i32.const 0)
                                     (i32.const 1)
                                     (i64.add
                                      (local.tee $3
                                       (i64.add
                                        (local.get $3)
                                        (i64.const 9)
                                       )
                                      )
                                      (i64.const 9)
                                     )
                                     (i64.const 9)
                                     (struct.get $type44 0
                                      (local.get $1)
                                     )
                                    )
                                   )
                                   (local.set $1
                                    (struct.get $type44 1
                                     (local.get $1)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready406)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global406)
                                    )
                                   )
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global397)
                                      )
                                     )
                                     (drop
                                      (call $function115
                                       (local.get $2)
                                       (i32.const 0)
                                       (i32.const 1)
                                       (i64.add
                                        (local.tee $3
                                         (i64.add
                                          (local.get $3)
                                          (i64.const 9)
                                         )
                                        )
                                        (i64.const 9)
                                       )
                                       (i64.const 9)
                                       (struct.get $type44 0
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (local.set $1
                                      (struct.get $type44 1
                                       (local.get $1)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready406)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global406)
                                      )
                                     )
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $1)
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global397)
                                        )
                                       )
                                       (drop
                                        (call $function115
                                         (local.get $2)
                                         (i32.const 0)
                                         (i32.const 1)
                                         (i64.add
                                          (local.tee $3
                                           (i64.add
                                            (local.get $3)
                                            (i64.const 9)
                                           )
                                          )
                                          (i64.const 9)
                                         )
                                         (i64.const 9)
                                         (struct.get $type44 0
                                          (local.get $1)
                                         )
                                        )
                                       )
                                       (local.set $1
                                        (struct.get $type44 1
                                         (local.get $1)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready406)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global406)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $1)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global397)
                                          )
                                         )
                                         (drop
                                          (call $function115
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.add
                                            (local.tee $3
                                             (i64.add
                                              (local.get $3)
                                              (i64.const 9)
                                             )
                                            )
                                            (i64.const 9)
                                           )
                                           (i64.const 9)
                                           (struct.get $type44 0
                                            (local.get $1)
                                           )
                                          )
                                         )
                                         (local.set $1
                                          (struct.get $type44 1
                                           (local.get $1)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready406)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global406)
                                          )
                                         )
                                         (if (result i32)
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                          (then
                                           (i32.const 0)
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global397)
                                            )
                                           )
                                           (drop
                                            (call $function115
                                             (local.get $2)
                                             (i32.const 0)
                                             (i32.const 1)
                                             (i64.add
                                              (local.tee $3
                                               (i64.add
                                                (local.get $3)
                                                (i64.const 9)
                                               )
                                              )
                                              (i64.const 9)
                                             )
                                             (i64.const 9)
                                             (struct.get $type44 0
                                              (local.get $1)
                                             )
                                            )
                                           )
                                           (local.set $1
                                            (struct.get $type44 1
                                             (local.get $1)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready406)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global406)
                                            )
                                           )
                                           (call $function116
                                            (local.get $2)
                                            (i64.add
                                             (local.get $3)
                                             (i64.const 9)
                                            )
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.get $2)
   )
  )
 )
 (func $function120 (type $46) (param $0 i32) (param $1 i32) (param $2 (ref $type28)) (param $3 (ref $type28)) (param $4 (ref $type28)) (result (ref $type28))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type28))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $3)
      )
     )
    )
   )
   (then
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i32.wrap_i64
      (i64.and
       (i64.extend_i32_s
        (array.get $type29
         (struct.get $type28 1
          (local.get $3)
         )
         (i32.const 0)
        )
       )
       (i64.const 1)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global236)
       )
      )
      (local.set $4
       (call $function77
        (local.get $4)
        (local.get $2)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global417)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global248)
     )
    )
    (if
     (i64.gt_u
      (local.tee $9
       (i64.extend_i32_u
        (array.len
         (local.tee $5
          (struct.get $type28 1
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function81
      (local.tee $6
       (array.new_default $type29
        (i32.wrap_i64
         (local.get $9)
        )
       )
      )
      (local.get $5)
      (i64.const 2)
      (i32.const 0)
      (i32.const 1)
      (i64.extend_i32_u
       (array.len
        (local.get $5)
       )
      )
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (local.set $7
     (if (result (ref $type28))
      (i64.eqz
       (i64.extend_i32_u
        (array.len
         (local.tee $5
          (call $function46
           (local.get $6)
          )
         )
        )
       )
      )
      (then
       (ref.as_non_null
        (global.get $global108)
       )
      )
      (else
       (struct.new $type28
        (i32.const 0)
        (local.get $5)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $7)
        )
       )
      )
     )
     (then
      (local.get $4)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global236)
       )
      )
      (local.set $8
       (call $function77
        (local.get $2)
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function120
       (local.get $0)
       (local.get $1)
       (local.get $8)
       (local.get $7)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function122 (type $call72) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 2)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 2)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 2)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 2)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 2)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 2)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 2)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 2)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 2)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 2)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 2)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 2)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 2)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 2)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (if (result i64)
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 2)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 15)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 2)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 16)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 2)
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 17)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 2)
                                         )
                                        )
                                       )
                                       (then
                                        (i64.const 18)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 2)
                                           )
                                          )
                                         )
                                         (then
                                          (i64.const 19)
                                         )
                                         (else
                                          (return_call $function123
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 2)
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function123 (type $84) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function123
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 2)
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function129 (type $call105) (param $0 f64) (result i64)
  (if (result i64)
   (f64.eq
    (local.get $0)
    (f64.const 0.0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (f64.eq
      (local.tee $0
       (f64.trunc
        (f64.mul
         (local.get $0)
         (f64.const 9.313225746154785e-10)
        )
       )
      )
      (f64.const 0.0)
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (f64.eq
        (local.tee $0
         (f64.trunc
          (f64.mul
           (local.get $0)
           (f64.const 9.313225746154785e-10)
          )
         )
        )
        (f64.const 0.0)
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (f64.eq
          (local.tee $0
           (f64.trunc
            (f64.mul
             (local.get $0)
             (f64.const 9.313225746154785e-10)
            )
           )
          )
          (f64.const 0.0)
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (f64.eq
            (local.tee $0
             (f64.trunc
              (f64.mul
               (local.get $0)
               (f64.const 9.313225746154785e-10)
              )
             )
            )
            (f64.const 0.0)
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (f64.eq
              (local.tee $0
               (f64.trunc
                (f64.mul
                 (local.get $0)
                 (f64.const 9.313225746154785e-10)
                )
               )
              )
              (f64.const 0.0)
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (f64.eq
                (local.tee $0
                 (f64.trunc
                  (f64.mul
                   (local.get $0)
                   (f64.const 9.313225746154785e-10)
                  )
                 )
                )
                (f64.const 0.0)
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (f64.eq
                  (local.tee $0
                   (f64.trunc
                    (f64.mul
                     (local.get $0)
                     (f64.const 9.313225746154785e-10)
                    )
                   )
                  )
                  (f64.const 0.0)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (f64.eq
                    (local.tee $0
                     (f64.trunc
                      (f64.mul
                       (local.get $0)
                       (f64.const 9.313225746154785e-10)
                      )
                     )
                    )
                    (f64.const 0.0)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (f64.eq
                      (local.tee $0
                       (f64.trunc
                        (f64.mul
                         (local.get $0)
                         (f64.const 9.313225746154785e-10)
                        )
                       )
                      )
                      (f64.const 0.0)
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (f64.eq
                        (local.tee $0
                         (f64.trunc
                          (f64.mul
                           (local.get $0)
                           (f64.const 9.313225746154785e-10)
                          )
                         )
                        )
                        (f64.const 0.0)
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (f64.eq
                          (local.tee $0
                           (f64.trunc
                            (f64.mul
                             (local.get $0)
                             (f64.const 9.313225746154785e-10)
                            )
                           )
                          )
                          (f64.const 0.0)
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (f64.eq
                            (local.tee $0
                             (f64.trunc
                              (f64.mul
                               (local.get $0)
                               (f64.const 9.313225746154785e-10)
                              )
                             )
                            )
                            (f64.const 0.0)
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (f64.eq
                              (local.tee $0
                               (f64.trunc
                                (f64.mul
                                 (local.get $0)
                                 (f64.const 9.313225746154785e-10)
                                )
                               )
                              )
                              (f64.const 0.0)
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (f64.eq
                                (local.tee $0
                                 (f64.trunc
                                  (f64.mul
                                   (local.get $0)
                                   (f64.const 9.313225746154785e-10)
                                  )
                                 )
                                )
                                (f64.const 0.0)
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (if (result i64)
                                 (f64.eq
                                  (local.tee $0
                                   (f64.trunc
                                    (f64.mul
                                     (local.get $0)
                                     (f64.const 9.313225746154785e-10)
                                    )
                                   )
                                  )
                                  (f64.const 0.0)
                                 )
                                 (then
                                  (i64.const 15)
                                 )
                                 (else
                                  (if (result i64)
                                   (f64.eq
                                    (local.tee $0
                                     (f64.trunc
                                      (f64.mul
                                       (local.get $0)
                                       (f64.const 9.313225746154785e-10)
                                      )
                                     )
                                    )
                                    (f64.const 0.0)
                                   )
                                   (then
                                    (i64.const 16)
                                   )
                                   (else
                                    (if (result i64)
                                     (f64.eq
                                      (local.tee $0
                                       (f64.trunc
                                        (f64.mul
                                         (local.get $0)
                                         (f64.const 9.313225746154785e-10)
                                        )
                                       )
                                      )
                                      (f64.const 0.0)
                                     )
                                     (then
                                      (i64.const 17)
                                     )
                                     (else
                                      (if (result i64)
                                       (f64.eq
                                        (local.tee $0
                                         (f64.trunc
                                          (f64.mul
                                           (local.get $0)
                                           (f64.const 9.313225746154785e-10)
                                          )
                                         )
                                        )
                                        (f64.const 0.0)
                                       )
                                       (then
                                        (i64.const 18)
                                       )
                                       (else
                                        (if (result i64)
                                         (f64.eq
                                          (local.tee $0
                                           (f64.trunc
                                            (f64.mul
                                             (local.get $0)
                                             (f64.const 9.313225746154785e-10)
                                            )
                                           )
                                          )
                                          (f64.const 0.0)
                                         )
                                         (then
                                          (i64.const 19)
                                         )
                                         (else
                                          (return_call $function130
                                           (i32.const 0)
                                           (i32.const 1)
                                           (f64.trunc
                                            (f64.mul
                                             (local.get $0)
                                             (f64.const 9.313225746154785e-10)
                                            )
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function130 (type $44) (param $0 i32) (param $1 i32) (param $2 f64) (param $3 i64) (result i64)
  (if (result i64)
   (f64.eq
    (local.get $2)
    (f64.const 0.0)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function130
     (local.get $0)
     (local.get $1)
     (f64.trunc
      (f64.mul
       (local.get $2)
       (f64.const 9.313225746154785e-10)
      )
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function132 (type $43) (param $0 i32) (param $1 (ref $type29)) (param $2 f64) (param $3 i32) (param $4 i32) (param $5 f64) (param $6 i64) (result (ref $type28))
  (local $7 i64)
  (if (result (ref $type28))
   (f64.eq
    (local.get $5)
    (f64.const 0.0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $1
         (call $function46
          (local.get $1)
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type28
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $7
     (i64.trunc_f64_s
      (f64.sub
       (local.get $5)
       (f64.mul
        (local.tee $5
         (f64.trunc
          (f64.div
           (local.get $5)
           (local.get $2)
          )
         )
        )
        (local.get $2)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (local.get $1)
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function132
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function136 (type $call107) (param $0 i64) (result f64)
  (local $1 f64)
  (local $2 f64)
  (local $3 i32)
  (local.set $2
   (select
    (f64.const 0.5)
    (f64.const 2.0)
    (local.tee $3
     (i64.lt_s
      (local.get $0)
      (i64.const 0)
     )
    )
   )
  )
  (if (result f64)
   (i64.eqz
    (local.tee $0
     (select
      (i64.sub
       (i64.const 0)
       (local.get $0)
      )
      (local.get $0)
      (local.get $3)
     )
    )
   )
   (then
    (f64.const 1.0)
   )
   (else
    (local.set $1
     (f64.mul
      (local.get $2)
      (f64.const 1.0)
     )
    )
    (if (result f64)
     (i64.eqz
      (local.tee $0
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (local.set $1
       (f64.mul
        (local.get $1)
        (local.get $2)
       )
      )
      (if (result f64)
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (local.get $1)
       )
       (else
        (local.set $1
         (f64.mul
          (local.get $1)
          (local.get $2)
         )
        )
        (if (result f64)
         (i64.eqz
          (local.tee $0
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (local.set $1
           (f64.mul
            (local.get $1)
            (local.get $2)
           )
          )
          (if (result f64)
           (i64.eqz
            (local.tee $0
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $1)
           )
           (else
            (local.set $1
             (f64.mul
              (local.get $1)
              (local.get $2)
             )
            )
            (if (result f64)
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (local.set $1
               (f64.mul
                (local.get $1)
                (local.get $2)
               )
              )
              (if (result f64)
               (i64.eqz
                (local.tee $0
                 (i64.sub
                  (local.get $0)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $1)
               )
               (else
                (local.set $1
                 (f64.mul
                  (local.get $1)
                  (local.get $2)
                 )
                )
                (if (result f64)
                 (i64.eqz
                  (local.tee $0
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (local.set $1
                   (f64.mul
                    (local.get $1)
                    (local.get $2)
                   )
                  )
                  (if (result f64)
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (local.set $1
                     (f64.mul
                      (local.get $1)
                      (local.get $2)
                     )
                    )
                    (if (result f64)
                     (i64.eqz
                      (local.tee $0
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (local.set $1
                       (f64.mul
                        (local.get $1)
                        (local.get $2)
                       )
                      )
                      (if (result f64)
                       (i64.eqz
                        (local.tee $0
                         (i64.sub
                          (local.get $0)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (local.set $1
                         (f64.mul
                          (local.get $1)
                          (local.get $2)
                         )
                        )
                        (if (result f64)
                         (i64.eqz
                          (local.tee $0
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (local.set $1
                           (f64.mul
                            (local.get $1)
                            (local.get $2)
                           )
                          )
                          (if (result f64)
                           (i64.eqz
                            (local.tee $0
                             (i64.sub
                              (local.get $0)
                              (i64.const 1)
                             )
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (local.set $1
                             (f64.mul
                              (local.get $1)
                              (local.get $2)
                             )
                            )
                            (if (result f64)
                             (i64.eqz
                              (local.tee $0
                               (i64.sub
                                (local.get $0)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (local.set $1
                               (f64.mul
                                (local.get $1)
                                (local.get $2)
                               )
                              )
                              (if (result f64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (local.set $1
                                 (f64.mul
                                  (local.get $1)
                                  (local.get $2)
                                 )
                                )
                                (if (result f64)
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.sub
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (local.set $1
                                   (f64.mul
                                    (local.get $1)
                                    (local.get $2)
                                   )
                                  )
                                  (if (result f64)
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.sub
                                      (local.get $0)
                                      (i64.const 1)
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (local.set $1
                                     (f64.mul
                                      (local.get $1)
                                      (local.get $2)
                                     )
                                    )
                                    (if (result f64)
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.sub
                                        (local.get $0)
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (local.set $1
                                       (f64.mul
                                        (local.get $1)
                                        (local.get $2)
                                       )
                                      )
                                      (if (result f64)
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.sub
                                          (local.get $0)
                                          (i64.const 1)
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (local.set $1
                                         (f64.mul
                                          (local.get $1)
                                          (local.get $2)
                                         )
                                        )
                                        (if (result f64)
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.sub
                                            (local.get $0)
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (return_call $function137
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.sub
                                            (local.get $0)
                                            (i64.const 1)
                                           )
                                           (f64.mul
                                            (local.get $1)
                                            (local.get $2)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function137 (type $41) (param $0 f64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 f64) (result f64)
  (if (result f64)
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function137
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (f64.mul
      (local.get $4)
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function142 (type $call110) (param $0 (ref $type28)) (param $1 (ref $type28)) (result f64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 f64)
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type28))
  (local $10 (ref $type28))
  (local $11 (ref $type28))
  (local $12 (ref $type28))
  (local $13 (ref $type28))
  (local $14 (ref $type29))
  (local $15 (ref $type88))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result f64)
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (if (result f64)
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (f64.const 0.0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global132)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global502)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global473)
       )
      )
      (select
       (f64.sub
        (f64.const -0.0)
        (local.tee $6
         (if (result f64)
          (i64.gt_s
           (local.tee $2
            (i64.sub
             (if (result i64)
              (i64.eqz
               (local.tee $2
                (i64.extend_i32_u
                 (array.len
                  (local.tee $14
                   (struct.get $type28 1
                    (local.tee $9
                     (if (result (ref $type28))
                      (struct.get $type28 0
                       (local.get $0)
                      )
                      (then
                       (struct.new $type28
                        (i32.const 0)
                        (struct.get $type28 1
                         (local.get $0)
                        )
                       )
                      )
                      (else
                       (local.get $0)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (then
               (i64.const 0)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global109)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global433)
                )
               )
               (if
                (i64.gt_u
                 (local.tee $2
                  (i64.sub
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (i64.add
                (call $function122
                 (i64.extend_i32_s
                  (array.get $type29
                   (local.get $14)
                   (i32.wrap_i64
                    (local.get $2)
                   )
                  )
                 )
                )
                (i64.mul
                 (local.get $2)
                 (i64.const 30)
                )
               )
              )
             )
             (block (result i64)
              (drop
               (ref.as_non_null
                (global.get $global473)
               )
              )
              (if (result i64)
               (i64.eqz
                (local.tee $2
                 (i64.extend_i32_u
                  (array.len
                   (local.tee $14
                    (struct.get $type28 1
                     (local.tee $11
                      (if (result (ref $type28))
                       (struct.get $type28 0
                        (local.get $1)
                       )
                       (then
                        (struct.new $type28
                         (i32.const 0)
                         (struct.get $type28 1
                          (local.get $1)
                         )
                        )
                       )
                       (else
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
               (then
                (i64.const 0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global109)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global433)
                 )
                )
                (if
                 (i64.gt_u
                  (local.tee $2
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (i64.add
                 (call $function122
                  (i64.extend_i32_s
                   (array.get $type29
                    (local.get $14)
                    (i32.wrap_i64
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (i64.mul
                  (local.get $2)
                  (i64.const 30)
                 )
                )
               )
              )
             )
            )
           )
           (i64.const 1024)
          )
          (then
           (f64.const inf)
          )
          (else
           (if (result f64)
            (i64.lt_s
             (local.get $2)
             (i64.const -1075)
            )
            (then
             (f64.const 0.0)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global486)
              )
             )
             (local.set $7
              (local.get $9)
             )
             (local.set $10
              (local.get $11)
             )
             (if
              (i64.lt_s
               (local.get $2)
               (i64.const 0)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global477)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global141)
                )
               )
               (local.set $12
                (call $function53
                 (i64.const 2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global430)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global141)
                )
               )
               (local.set $8
                (call $function53
                 (i64.sub
                  (i64.const 0)
                  (local.get $2)
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global421)
                )
               )
               (local.set $8
                (if (result (ref $type28))
                 (struct.get $type28 0
                  (local.get $8)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global141)
                   )
                  )
                  (call $function120
                   (i32.const 0)
                   (i32.const 1)
                   (local.get $12)
                   (local.get $8)
                   (call $function53
                    (i64.const 1)
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global236)
                )
               )
               (local.set $7
                (call $function77
                 (local.get $7)
                 (local.get $8)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global477)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global141)
                )
               )
               (local.set $12
                (call $function53
                 (i64.const 2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global430)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global141)
                )
               )
               (local.set $8
                (call $function53
                 (local.get $2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global421)
                )
               )
               (local.set $8
                (if (result (ref $type28))
                 (struct.get $type28 0
                  (local.get $8)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global141)
                   )
                  )
                  (call $function120
                   (i32.const 0)
                   (i32.const 1)
                   (local.get $12)
                   (local.get $8)
                   (call $function53
                    (i64.const 1)
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global236)
                )
               )
               (local.set $10
                (call $function77
                 (local.get $10)
                 (local.get $8)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global174)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global167)
              )
             )
             (if (result f64)
              (i64.gt_s
               (local.tee $2
                (select
                 (i64.sub
                  (local.get $2)
                  (i64.const 1)
                 )
                 (local.get $2)
                 (i64.lt_s
                  (call $function59
                   (local.get $7)
                   (local.get $10)
                  )
                  (i64.const 0)
                 )
                )
               )
               (i64.const 1023)
              )
              (then
               (f64.const inf)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global497)
                )
               )
               (if
                (i64.lt_s
                 (local.tee $2
                  (select
                   (i64.const -1074)
                   (i64.sub
                    (local.get $2)
                    (i64.const 52)
                   )
                   (i64.lt_s
                    (local.get $2)
                    (i64.const -1022)
                   )
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (drop
                  (ref.as_non_null
                   (global.get $global477)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global141)
                  )
                 )
                 (local.set $10
                  (call $function53
                   (i64.const 2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global430)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global141)
                  )
                 )
                 (local.set $7
                  (call $function53
                   (i64.sub
                    (i64.const 0)
                    (local.get $2)
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global421)
                  )
                 )
                 (local.set $7
                  (if (result (ref $type28))
                   (struct.get $type28 0
                    (local.get $7)
                   )
                   (then
                    (unreachable)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global141)
                     )
                    )
                    (call $function120
                     (i32.const 0)
                     (i32.const 1)
                     (local.get $10)
                     (local.get $7)
                     (call $function53
                      (i64.const 1)
                     )
                    )
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global236)
                  )
                 )
                 (local.set $9
                  (call $function77
                   (local.get $9)
                   (local.get $7)
                  )
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global477)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global141)
                  )
                 )
                 (local.set $10
                  (call $function53
                   (i64.const 2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global430)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global141)
                  )
                 )
                 (local.set $7
                  (call $function53
                   (local.get $2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global421)
                  )
                 )
                 (local.set $7
                  (if (result (ref $type28))
                   (struct.get $type28 0
                    (local.get $7)
                   )
                   (then
                    (unreachable)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global141)
                     )
                    )
                    (call $function120
                     (i32.const 0)
                     (i32.const 1)
                     (local.get $10)
                     (local.get $7)
                     (call $function53
                      (i64.const 1)
                     )
                    )
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global236)
                  )
                 )
                 (local.set $11
                  (call $function77
                   (local.get $11)
                   (local.get $7)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global490)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global316)
                )
               )
               (local.set $15
                (call $function93
                 (local.get $9)
                 (local.get $11)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global149)
                )
               )
               (local.set $3
                (call $function56
                 (local.tee $14
                  (struct.get $type28 1
                   (local.tee $9
                    (struct.get $type88 0
                     (local.get $15)
                    )
                   )
                  )
                 )
                 (local.tee $5
                  (struct.get $type28 0
                   (local.get $9)
                  )
                 )
                 (select
                  (i64.const -9223372036854775808)
                  (i64.const -9223372036854775807)
                  (local.get $5)
                 )
                 (i32.const 0)
                 (i32.const 1)
                 (i64.extend_i32_u
                  (array.len
                   (local.get $14)
                  )
                 )
                 (i64.const 0)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global211)
                )
               )
               (local.set $13
                (call $function71
                 (local.tee $9
                  (struct.get $type88 1
                   (local.get $15)
                  )
                 )
                 (local.get $9)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global167)
                )
               )
               (f64.mul
                (f64.convert_i64_s
                 (select
                  (i64.add
                   (local.get $3)
                   (i64.const 1)
                  )
                  (local.get $3)
                  (if (result i32)
                   (i64.gt_s
                    (local.tee $4
                     (call $function59
                      (local.get $13)
                      (local.get $11)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (i32.const 1)
                   )
                   (else
                    (if (result i32)
                     (i64.eqz
                      (local.get $4)
                     )
                     (then
                      (i64.eq
                       (i64.rem_s
                        (local.get $3)
                        (i64.const 2)
                       )
                       (i64.const 1)
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
                (block (result f64)
                 (drop
                  (ref.as_non_null
                   (global.get $global479)
                  )
                 )
                 (call $function136
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (local.get $6)
       (select
        (i32.eqz
         (local.tee $5
          (struct.get $type28 0
           (local.get $1)
          )
         )
        )
        (local.get $5)
        (struct.get $type28 0
         (local.get $0)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function145 (type $call80) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (struct.get $type28 0
    (local.get $0)
   )
   (then
    (local.set $0
     (struct.new $type28
      (i32.const 0)
      (struct.get $type28 1
       (local.get $0)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (struct.get $type28 0
    (local.get $1)
   )
   (then
    (local.set $1
     (struct.new $type28
      (i32.const 0)
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
  )
  (if (result (ref $type28))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global325)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global316)
     )
    )
    (local.set $0
     (struct.get $type88 1
      (call $function93
       (local.get $0)
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (if (result (ref $type28))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type28 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global325)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global316)
       )
      )
      (local.set $1
       (struct.get $type88 1
        (call $function93
         (local.get $1)
         (local.get $0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if (result (ref $type28))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (local.get $1)
          )
         )
        )
       )
       (then
        (local.get $0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global325)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global316)
         )
        )
        (local.set $0
         (struct.get $type88 1
          (call $function93
           (local.get $0)
           (local.get $1)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global130)
         )
        )
        (if (result (ref $type28))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (struct.get $type28 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global325)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global316)
           )
          )
          (local.set $1
           (struct.get $type88 1
            (call $function93
             (local.get $1)
             (local.get $0)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global130)
           )
          )
          (if (result (ref $type28))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (struct.get $type28 1
               (local.get $1)
              )
             )
            )
           )
           (then
            (local.get $0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global325)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global316)
             )
            )
            (local.set $0
             (struct.get $type88 1
              (call $function93
               (local.get $0)
               (local.get $1)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global130)
             )
            )
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (struct.get $type28 1
                 (local.get $0)
                )
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global325)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global316)
               )
              )
              (local.set $1
               (struct.get $type88 1
                (call $function93
                 (local.get $1)
                 (local.get $0)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global130)
               )
              )
              (if (result (ref $type28))
               (i64.eqz
                (i64.extend_i32_u
                 (array.len
                  (struct.get $type28 1
                   (local.get $1)
                  )
                 )
                )
               )
               (then
                (local.get $0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global325)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global316)
                 )
                )
                (local.set $0
                 (struct.get $type88 1
                  (call $function93
                   (local.get $0)
                   (local.get $1)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global130)
                 )
                )
                (if (result (ref $type28))
                 (i64.eqz
                  (i64.extend_i32_u
                   (array.len
                    (struct.get $type28 1
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global325)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global316)
                   )
                  )
                  (local.set $1
                   (struct.get $type88 1
                    (call $function93
                     (local.get $1)
                     (local.get $0)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global130)
                   )
                  )
                  (if (result (ref $type28))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type28 1
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (then
                    (local.get $0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global325)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global316)
                     )
                    )
                    (local.set $0
                     (struct.get $type88 1
                      (call $function93
                       (local.get $0)
                       (local.get $1)
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global130)
                     )
                    )
                    (if (result (ref $type28))
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (struct.get $type28 1
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global325)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global316)
                       )
                      )
                      (local.set $1
                       (struct.get $type88 1
                        (call $function93
                         (local.get $1)
                         (local.get $0)
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global130)
                       )
                      )
                      (if (result (ref $type28))
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (struct.get $type28 1
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (then
                        (local.get $0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global325)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global316)
                         )
                        )
                        (local.set $0
                         (struct.get $type88 1
                          (call $function93
                           (local.get $0)
                           (local.get $1)
                          )
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global130)
                         )
                        )
                        (if (result (ref $type28))
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (struct.get $type28 1
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global325)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global316)
                           )
                          )
                          (local.set $1
                           (struct.get $type88 1
                            (call $function93
                             (local.get $1)
                             (local.get $0)
                            )
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global130)
                           )
                          )
                          (if (result (ref $type28))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (struct.get $type28 1
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (then
                            (local.get $0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global325)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global316)
                             )
                            )
                            (local.set $0
                             (struct.get $type88 1
                              (call $function93
                               (local.get $0)
                               (local.get $1)
                              )
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global130)
                             )
                            )
                            (if (result (ref $type28))
                             (i64.eqz
                              (i64.extend_i32_u
                               (array.len
                                (struct.get $type28 1
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global325)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global316)
                               )
                              )
                              (local.set $1
                               (struct.get $type88 1
                                (call $function93
                                 (local.get $1)
                                 (local.get $0)
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global130)
                               )
                              )
                              (if (result (ref $type28))
                               (i64.eqz
                                (i64.extend_i32_u
                                 (array.len
                                  (struct.get $type28 1
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (then
                                (local.get $0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global325)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global316)
                                 )
                                )
                                (local.set $0
                                 (struct.get $type88 1
                                  (call $function93
                                   (local.get $0)
                                   (local.get $1)
                                  )
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global130)
                                 )
                                )
                                (if (result (ref $type28))
                                 (i64.eqz
                                  (i64.extend_i32_u
                                   (array.len
                                    (struct.get $type28 1
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global325)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global316)
                                   )
                                  )
                                  (local.set $1
                                   (struct.get $type88 1
                                    (call $function93
                                     (local.get $1)
                                     (local.get $0)
                                    )
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global130)
                                   )
                                  )
                                  (if (result (ref $type28))
                                   (i64.eqz
                                    (i64.extend_i32_u
                                     (array.len
                                      (struct.get $type28 1
                                       (local.get $1)
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $0)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global325)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global316)
                                     )
                                    )
                                    (local.set $2
                                     (struct.get $type88 1
                                      (call $function93
                                       (local.get $0)
                                       (local.get $1)
                                      )
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global130)
                                     )
                                    )
                                    (if (result (ref $type28))
                                     (i64.eqz
                                      (i64.extend_i32_u
                                       (array.len
                                        (struct.get $type28 1
                                         (local.get $2)
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global325)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global316)
                                       )
                                      )
                                      (local.set $0
                                       (struct.get $type88 1
                                        (call $function93
                                         (local.get $1)
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global130)
                                       )
                                      )
                                      (if (result (ref $type28))
                                       (i64.eqz
                                        (i64.extend_i32_u
                                         (array.len
                                          (struct.get $type28 1
                                           (local.get $0)
                                          )
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $2)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global325)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global316)
                                         )
                                        )
                                        (local.set $1
                                         (struct.get $type88 1
                                          (call $function93
                                           (local.get $2)
                                           (local.get $0)
                                          )
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global130)
                                         )
                                        )
                                        (if (result (ref $type28))
                                         (call $function48
                                          (local.get $1)
                                         )
                                         (then
                                          (local.get $0)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global325)
                                           )
                                          )
                                          (return_call $function146
                                           (i32.const 0)
                                           (i32.const 1)
                                           (local.get $1)
                                           (call $function95
                                            (local.get $0)
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function146 (type $39) (param $0 i32) (param $1 i32) (param $2 (ref $type28)) (param $3 (ref $type28)) (result (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type28))
   (call $function48
    (local.get $3)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global325)
     )
    )
    (local.set $2
     (call $function95
      (local.get $2)
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function146
     (local.get $0)
     (local.get $1)
     (local.get $3)
     (local.get $2)
    )
   )
  )
 )
 (func $function153 (type $call112) (param $0 (ref $type28)) (param $1 (ref $type28)) (result (ref $type27))
  (local $2 (ref $type28))
  (local $3 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type27))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (struct.get $type28 0
      (local.get $1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if
       (i64.ne
        (i64.extend_i32_u
         (array.len
          (local.tee $3
           (struct.get $type28 1
            (local.get $0)
           )
          )
         )
        )
        (i64.const 0)
       )
       (then
        (local.set $0
         (struct.new $type28
          (i32.eqz
           (struct.get $type28 0
            (local.get $0)
           )
          )
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global132)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global515)
     )
    )
    (if
     (struct.get $type28 0
      (local.get $1)
     )
     (then
      (local.set $1
       (struct.new $type28
        (i32.const 0)
        (struct.get $type28 1
         (local.get $1)
        )
       )
      )
     )
    )
    (local.set $2
     (call $function145
      (local.get $0)
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global322)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global316)
     )
    )
    (struct.new $type27
     (struct.get $type88 0
      (call $function93
       (local.get $0)
       (local.get $2)
      )
     )
     (block (result (ref $type28))
      (drop
       (ref.as_non_null
        (global.get $global322)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global316)
       )
      )
      (struct.get $type88 0
       (call $function93
        (local.get $1)
        (local.get $2)
       )
      )
     )
    )
   )
  )
 )
 (func $function173 (type $36) (param $0 i32) (param $1 i32) (param $2 f64) (param $3 i64) (result (ref $type27))
  (local $4 (ref $type28))
  (local $5 (ref $type28))
  (local $6 i64)
  (local $7 i32)
  (local $scratch (ref $type28))
  (if
   (local.tee $7
    (f64.eq
     (f64.trunc
      (local.get $2)
     )
     (local.get $2)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global461)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global454)
     )
    )
    (return_call $function153
     (if (result (ref $type28))
      (select
       (local.get $7)
       (i32.const 0)
       (if (result i32)
        (f64.eq
         (local.get $2)
         (local.get $2)
        )
        (then
         (i32.and
          (f64.lt
           (local.get $2)
           (f64.const inf)
          )
          (f64.gt
           (local.get $2)
           (f64.const -inf)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global456)
        )
       )
       (local.set $6
        (call $function129
         (local.tee $2
          (select
           (f64.sub
            (f64.const 0.0)
            (local.get $2)
           )
           (local.get $2)
           (local.tee $0
            (f64.lt
             (local.get $2)
             (f64.const 0.0)
            )
           )
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global116)
        )
       )
       (if
        (i64.gt_u
         (local.get $6)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (call $function132
        (local.get $0)
        (array.new_default $type29
         (i32.wrap_i64
          (local.get $6)
         )
        )
        (f64.const 1073741824.0)
        (i32.const 0)
        (i32.const 1)
        (local.get $2)
        (i64.const 0)
       )
      )
      (else
       (unreachable)
      )
     )
     (block (result (ref $type28))
      (drop
       (ref.as_non_null
        (global.get $global141)
       )
      )
      (local.set $5
       (call $function53
        (i64.const 2)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global430)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global141)
       )
      )
      (local.set $4
       (call $function53
        (local.get $3)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global421)
       )
      )
      (local.set $scratch
       (if (result (ref $type28))
        (struct.get $type28 0
         (local.get $4)
        )
        (then
         (unreachable)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global141)
          )
         )
         (call $function120
          (i32.const 0)
          (i32.const 1)
          (local.get $5)
          (local.get $4)
          (call $function53
           (i64.const 1)
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global540)
       )
      )
      (local.get $scratch)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function173
     (local.get $0)
     (local.get $1)
     (f64.mul
      (local.get $2)
      (f64.const 1073741824.0)
     )
     (i64.add
      (local.get $3)
      (i64.const 30)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function177 (type $call123) (param $0 (ref $type27)) (result (ref $type32))
  (local $1 (ref $type28))
  (local $2 (ref $type28))
  (local $3 (ref $type29))
  (local $4 i32)
  (drop
   (ref.as_non_null
    (global.get $global549)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (if (result (ref $type32))
   (if (result i32)
    (i64.eqz
     (call $function59
      (struct.get $type27 1
       (local.get $0)
      )
      (ref.as_non_null
       (global.get $global539)
      )
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global513)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global141)
      )
     )
     (local.set $1
      (call $function53
       (i64.const -9223372036854775808)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global183)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global167)
      )
     )
     (if (result i32)
      (i64.ge_s
       (call $function59
        (local.tee $2
         (struct.get $type27 0
          (local.get $0)
         )
        )
        (local.get $1)
       )
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global141)
        )
       )
       (local.set $1
        (call $function53
         (i64.const 9223372036854775807)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global177)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global167)
        )
       )
       (i64.le_s
        (call $function59
         (local.get $2)
         (local.get $1)
        )
        (i64.const 0)
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global149)
     )
    )
    (struct.new $type33
     (i32.const 0)
     (call $function56
      (local.tee $3
       (struct.get $type28 1
        (local.tee $1
         (struct.get $type27 0
          (local.get $0)
         )
        )
       )
      )
      (local.tee $4
       (struct.get $type28 0
        (local.get $1)
       )
      )
      (select
       (i64.const -9223372036854775808)
       (i64.const -9223372036854775807)
       (local.get $4)
      )
      (i32.const 0)
      (i32.const 1)
      (i64.extend_i32_u
       (array.len
        (local.get $3)
       )
      )
      (i64.const 0)
     )
    )
   )
   (else
    (struct.new $type34
     (i32.const 1)
     (local.get $0)
    )
   )
  )
 )
 (func $function180 (type $call126) (param $0 (ref $type28)) (result (ref $type24))
  (local $1 (ref $type32))
  (local $2 i32)
  (drop
   (ref.as_non_null
    (global.get $global547)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global614)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global606)
   )
  )
  (local.set $1
   (call $function177
    (struct.new $type27
     (local.get $0)
     (ref.as_non_null
      (global.get $global539)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global608)
   )
  )
  (if (result (ref $type24))
   (local.tee $2
    (struct.get $type32 0
     (local.get $1)
    )
   )
   (then
    (if (result (ref $type24))
     (i32.eq
      (local.get $2)
      (i32.const 1)
     )
     (then
      (struct.new $type26
       (i32.const 1)
       (struct.get $type34 1
        (ref.cast (ref $type34)
         (local.get $1)
        )
       )
      )
     )
     (else
      (struct.new $type30
       (i32.const 2)
       (struct.get $type35 1
        (ref.cast (ref $type35)
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (else
    (struct.new $type25
     (i32.const 0)
     (struct.get $type33 1
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function184 (type $call129) (param $0 (ref $type32)) (result (ref $type27))
  (local $1 f64)
  (local $2 i32)
  (if (result (ref $type27))
   (local.tee $2
    (struct.get $type32 0
     (local.get $0)
    )
   )
   (then
    (if (result (ref $type27))
     (i32.eq
      (local.get $2)
      (i32.const 1)
     )
     (then
      (struct.get $type34 1
       (ref.cast (ref $type34)
        (local.get $0)
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global593)
       )
      )
      (if
       (if (result i32)
        (f64.eq
         (local.tee $1
          (struct.get $type35 1
           (ref.cast (ref $type35)
            (local.get $0)
           )
          )
         )
         (local.get $1)
        )
        (then
         (i32.and
          (f64.lt
           (local.get $1)
           (f64.const inf)
          )
          (f64.gt
           (local.get $1)
           (f64.const -inf)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (return_call $function173
         (i32.const 0)
         (i32.const 1)
         (local.get $1)
         (i64.const 0)
        )
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global141)
     )
    )
    (struct.new $type27
     (call $function53
      (struct.get $type33 1
       (ref.cast (ref $type33)
        (local.get $0)
       )
      )
     )
     (block (result (ref $type28))
      (drop
       (ref.as_non_null
        (global.get $global547)
       )
      )
      (ref.as_non_null
       (global.get $global539)
      )
     )
    )
   )
  )
 )
 (func $function185 (type $call130) (param $0 (ref $type32)) (param $1 (ref $type32)) (result (ref $type24))
  (local $2 i32)
  (local $3 (ref $type27))
  (drop
   (ref.as_non_null
    (global.get $global618)
   )
  )
  (if (result (ref $type24))
   (if (result i32)
    (if (result i32)
     (local.tee $2
      (struct.get $type32 0
       (local.get $1)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type34)
          (local.get $1)
         )
        )
        (i32.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type35)
          (local.get $1)
         )
        )
        (i32.const 0)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $1)
       )
      )
      (i32.const 1)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global624)
      )
     )
     (if (result i32)
      (local.tee $2
       (struct.get $type32 0
        (local.get $1)
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $2)
         (i32.const 1)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global551)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global130)
          )
         )
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (struct.get $type28 1
             (struct.get $type27 0
              (struct.get $type34 1
               (ref.cast (ref $type34)
                (local.get $1)
               )
              )
             )
            )
           )
          )
         )
        )
        (else
         (f64.eq
          (struct.get $type35 1
           (ref.cast (ref $type35)
            (local.get $1)
           )
          )
          (f64.const 0.0)
         )
        )
       )
      )
      (else
       (i64.eqz
        (struct.get $type33 1
         (ref.cast (ref $type33)
          (local.get $1)
         )
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global608)
     )
    )
    (if (result (ref $type24))
     (local.tee $2
      (struct.get $type32 0
       (local.get $0)
      )
     )
     (then
      (if (result (ref $type24))
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (struct.new $type26
         (i32.const 1)
         (struct.get $type34 1
          (ref.cast (ref $type34)
           (local.get $0)
          )
         )
        )
       )
       (else
        (struct.new $type30
         (i32.const 2)
         (struct.get $type35 1
          (ref.cast (ref $type35)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (else
      (struct.new $type25
       (i32.const 0)
       (struct.get $type33 1
        (ref.cast (ref $type33)
         (local.get $0)
        )
       )
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global618)
     )
    )
    (if (result (ref $type31))
     (if (result i32)
      (if (result i32)
       (local.tee $2
        (struct.get $type32 0
         (local.get $0)
        )
       )
       (then
        (if (result i32)
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type34)
            (local.get $0)
           )
          )
          (i32.const 1)
         )
         (else
          (drop
           (ref.cast (ref $type35)
            (local.get $0)
           )
          )
          (i32.const 0)
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type33)
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global618)
        )
       )
       (if (result i32)
        (local.tee $2
         (struct.get $type32 0
          (local.get $1)
         )
        )
        (then
         (if (result i32)
          (i32.eq
           (local.get $2)
           (i32.const 1)
          )
          (then
           (drop
            (ref.cast (ref $type34)
             (local.get $1)
            )
           )
           (i32.const 1)
          )
          (else
           (drop
            (ref.cast (ref $type35)
             (local.get $1)
            )
           )
           (i32.const 0)
          )
         )
        )
        (else
         (drop
          (ref.cast (ref $type33)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (struct.new $type31
       (i32.const 3)
       (local.get $0)
       (local.get $1)
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global630)
       )
      )
      (struct.new $type31
       (i32.const 3)
       (struct.new $type35
        (i32.const 2)
        (if (result f64)
         (local.tee $2
          (struct.get $type32 0
           (local.get $0)
          )
         )
         (then
          (if (result f64)
           (i32.eq
            (local.get $2)
            (i32.const 1)
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global598)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global507)
             )
            )
            (call $function142
             (struct.get $type27 0
              (local.tee $3
               (struct.get $type34 1
                (ref.cast (ref $type34)
                 (local.get $0)
                )
               )
              )
             )
             (struct.get $type27 1
              (local.get $3)
             )
            )
           )
           (else
            (struct.get $type35 1
             (ref.cast (ref $type35)
              (local.get $0)
             )
            )
           )
          )
         )
         (else
          (f64.convert_i64_s
           (struct.get $type33 1
            (ref.cast (ref $type33)
             (local.get $0)
            )
           )
          )
         )
        )
       )
       (block (result (ref (exact $type35)))
        (drop
         (ref.as_non_null
          (global.get $global630)
         )
        )
        (struct.new $type35
         (i32.const 2)
         (if (result f64)
          (local.tee $2
           (struct.get $type32 0
            (local.get $1)
           )
          )
          (then
           (if (result f64)
            (i32.eq
             (local.get $2)
             (i32.const 1)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global598)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global507)
              )
             )
             (call $function142
              (struct.get $type27 0
               (local.tee $3
                (struct.get $type34 1
                 (ref.cast (ref $type34)
                  (local.get $1)
                 )
                )
               )
              )
              (struct.get $type27 1
               (local.get $3)
              )
             )
            )
            (else
             (struct.get $type35 1
              (ref.cast (ref $type35)
               (local.get $1)
              )
             )
            )
           )
          )
          (else
           (f64.convert_i64_s
            (struct.get $type33 1
             (ref.cast (ref $type33)
              (local.get $1)
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function190 (type $call131) (param $0 (ref $type24)) (result (ref $type32))
  (local $1 i32)
  (local $2 (ref $type32))
  (drop
   (ref.as_non_null
    (global.get $global658)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global624)
   )
  )
  (if (result (ref $type32))
   (if (result i32)
    (local.tee $1
     (struct.get $type32 0
      (local.tee $2
       (if (result (ref $type32))
        (local.tee $1
         (struct.get $type24 0
          (local.get $0)
         )
        )
        (then
         (if (result (ref $type32))
          (i32.eq
           (local.get $1)
           (i32.const 1)
          )
          (then
           (drop
            (ref.cast (ref $type26)
             (local.get $0)
            )
           )
           (struct.new_default $type33)
          )
          (else
           (if (result (ref $type32))
            (i32.eq
             (struct.get $type24 0
              (local.get $0)
             )
             (i32.const 2)
            )
            (then
             (drop
              (ref.cast (ref $type30)
               (local.get $0)
              )
             )
             (struct.new_default $type33)
            )
            (else
             (struct.get $type31 2
              (ref.cast (ref $type31)
               (local.get $0)
              )
             )
            )
           )
          )
         )
        )
        (else
         (drop
          (ref.cast (ref $type25)
           (local.get $0)
          )
         )
         (struct.new_default $type33)
        )
       )
      )
     )
    )
    (then
     (if (result i32)
      (i32.eq
       (local.get $1)
       (i32.const 1)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global551)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global130)
        )
       )
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (struct.get $type27 0
            (struct.get $type34 1
             (ref.cast (ref $type34)
              (local.get $2)
             )
            )
           )
          )
         )
        )
       )
      )
      (else
       (f64.eq
        (struct.get $type35 1
         (ref.cast (ref $type35)
          (local.get $2)
         )
        )
        (f64.const 0.0)
       )
      )
     )
    )
    (else
     (i64.eqz
      (struct.get $type33 1
       (ref.cast (ref $type33)
        (local.get $2)
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global650)
     )
    )
    (if (result (ref $type32))
     (local.tee $1
      (struct.get $type24 0
       (local.get $0)
      )
     )
     (then
      (if (result (ref $type32))
       (i32.eq
        (local.get $1)
        (i32.const 1)
       )
       (then
        (struct.new $type34
         (i32.const 1)
         (struct.get $type26 1
          (ref.cast (ref $type26)
           (local.get $0)
          )
         )
        )
       )
       (else
        (if (result (ref $type32))
         (i32.eq
          (struct.get $type24 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (struct.new $type35
           (i32.const 2)
           (struct.get $type30 1
            (ref.cast (ref $type30)
             (local.get $0)
            )
           )
          )
         )
         (else
          (struct.get $type31 1
           (ref.cast (ref $type31)
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
     (else
      (struct.new $type33
       (i32.const 0)
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $0)
        )
       )
      )
     )
    )
   )
   (else
    (unreachable)
   )
  )
 )
 (func $function199 (type $call132) (param $0 (ref $type24)) (result i32)
  (local $1 i32)
  (local $2 (ref $type32))
  (drop
   (ref.as_non_null
    (global.get $global658)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global624)
   )
  )
  (if (result i32)
   (local.tee $1
    (struct.get $type32 0
     (local.tee $2
      (if (result (ref $type32))
       (local.tee $1
        (struct.get $type24 0
         (local.get $0)
        )
       )
       (then
        (if (result (ref $type32))
         (i32.eq
          (local.get $1)
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type26)
            (local.get $0)
           )
          )
          (struct.new_default $type33)
         )
         (else
          (if (result (ref $type32))
           (i32.eq
            (struct.get $type24 0
             (local.get $0)
            )
            (i32.const 2)
           )
           (then
            (drop
             (ref.cast (ref $type30)
              (local.get $0)
             )
            )
            (struct.new_default $type33)
           )
           (else
            (struct.get $type31 2
             (ref.cast (ref $type31)
              (local.get $0)
             )
            )
           )
          )
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type25)
          (local.get $0)
         )
        )
        (struct.new_default $type33)
       )
      )
     )
    )
   )
   (then
    (if (result i32)
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global551)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (i64.eqz
       (i64.extend_i32_u
        (array.len
         (struct.get $type28 1
          (struct.get $type27 0
           (struct.get $type34 1
            (ref.cast (ref $type34)
             (local.get $2)
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (f64.eq
       (struct.get $type35 1
        (ref.cast (ref $type35)
         (local.get $2)
        )
       )
       (f64.const 0.0)
      )
     )
    )
   )
   (else
    (i64.eqz
     (struct.get $type33 1
      (ref.cast (ref $type33)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function200 (type $call132) (param $0 (ref $type24)) (result i32)
  (local $1 i32)
  (local $2 (ref $type32))
  (drop
   (ref.as_non_null
    (global.get $global650)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global618)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $1
     (struct.get $type32 0
      (local.tee $2
       (if (result (ref $type32))
        (local.tee $1
         (struct.get $type24 0
          (local.get $0)
         )
        )
        (then
         (if (result (ref $type32))
          (i32.eq
           (local.get $1)
           (i32.const 1)
          )
          (then
           (struct.new $type34
            (i32.const 1)
            (struct.get $type26 1
             (ref.cast (ref $type26)
              (local.get $0)
             )
            )
           )
          )
          (else
           (if (result (ref $type32))
            (i32.eq
             (struct.get $type24 0
              (local.get $0)
             )
             (i32.const 2)
            )
            (then
             (struct.new $type35
              (i32.const 2)
              (struct.get $type30 1
               (ref.cast (ref $type30)
                (local.get $0)
               )
              )
             )
            )
            (else
             (struct.get $type31 1
              (ref.cast (ref $type31)
               (local.get $0)
              )
             )
            )
           )
          )
         )
        )
        (else
         (struct.new $type33
          (i32.const 0)
          (struct.get $type25 1
           (ref.cast (ref $type25)
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
    )
    (then
     (if (result i32)
      (i32.eq
       (local.get $1)
       (i32.const 1)
      )
      (then
       (drop
        (ref.cast (ref $type34)
         (local.get $2)
        )
       )
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type35)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $2)
      )
     )
     (i32.const 1)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global658)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global618)
     )
    )
    (if (result i32)
     (local.tee $1
      (struct.get $type32 0
       (local.tee $2
        (if (result (ref $type32))
         (local.tee $1
          (struct.get $type24 0
           (local.get $0)
          )
         )
         (then
          (if (result (ref $type32))
           (i32.eq
            (local.get $1)
            (i32.const 1)
           )
           (then
            (drop
             (ref.cast (ref $type26)
              (local.get $0)
             )
            )
            (struct.new_default $type33)
           )
           (else
            (if (result (ref $type32))
             (i32.eq
              (struct.get $type24 0
               (local.get $0)
              )
              (i32.const 2)
             )
             (then
              (drop
               (ref.cast (ref $type30)
                (local.get $0)
               )
              )
              (struct.new_default $type33)
             )
             (else
              (struct.get $type31 2
               (ref.cast (ref $type31)
                (local.get $0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (drop
           (ref.cast (ref $type25)
            (local.get $0)
           )
          )
          (struct.new_default $type33)
         )
        )
       )
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $1)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type34)
          (local.get $2)
         )
        )
        (i32.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type35)
          (local.get $2)
         )
        )
        (i32.const 0)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $2)
       )
      )
      (i32.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function202 (type $call132) (param $0 (ref $type24)) (result i32)
  (local $1 f64)
  (local $2 i32)
  (local $3 (ref $type32))
  (drop
   (ref.as_non_null
    (global.get $global702)
   )
  )
  (if (result i32)
   (call $function199
    (local.get $0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global650)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global696)
     )
    )
    (if (result i32)
     (local.tee $2
      (struct.get $type32 0
       (local.tee $3
        (if (result (ref $type32))
         (local.tee $2
          (struct.get $type24 0
           (local.get $0)
          )
         )
         (then
          (if (result (ref $type32))
           (i32.eq
            (local.get $2)
            (i32.const 1)
           )
           (then
            (struct.new $type34
             (i32.const 1)
             (struct.get $type26 1
              (ref.cast (ref $type26)
               (local.get $0)
              )
             )
            )
           )
           (else
            (if (result (ref $type32))
             (i32.eq
              (struct.get $type24 0
               (local.get $0)
              )
              (i32.const 2)
             )
             (then
              (struct.new $type35
               (i32.const 2)
               (struct.get $type30 1
                (ref.cast (ref $type30)
                 (local.get $0)
                )
               )
              )
             )
             (else
              (struct.get $type31 1
               (ref.cast (ref $type31)
                (local.get $0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (struct.new $type33
           (i32.const 0)
           (struct.get $type25 1
            (ref.cast (ref $type25)
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global549)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global171)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global167)
         )
        )
        (i64.eqz
         (call $function59
          (struct.get $type27 1
           (struct.get $type34 1
            (ref.cast (ref $type34)
             (local.get $3)
            )
           )
          )
          (ref.as_non_null
           (global.get $global539)
          )
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global688)
         )
        )
        (if (result i32)
         (if (result i32)
          (f64.eq
           (local.tee $1
            (struct.get $type35 1
             (ref.cast (ref $type35)
              (local.get $3)
             )
            )
           )
           (local.get $1)
          )
          (then
           (i32.and
            (f64.lt
             (local.get $1)
             (f64.const inf)
            )
            (f64.gt
             (local.get $1)
             (f64.const -inf)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
         (then
          (f64.eq
           (f64.trunc
            (local.get $1)
           )
           (local.get $1)
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $3)
       )
      )
      (i32.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function210 (type $call137) (param $0 (ref $type32)) (param $1 (ref $type32)) (result (ref $type32))
  (local $2 i32)
  (local $3 (ref $type27))
  (local $4 (ref $type27))
  (local $5 (ref $type27))
  (local $6 (ref $type28))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $scratch (ref $type28))
  (local $scratch_10 (ref $type28))
  (local $scratch_11 (ref $type27))
  (drop
   (ref.as_non_null
    (global.get $global618)
   )
  )
  (if (result (ref $type35))
   (if (result i32)
    (if (result i32)
     (local.tee $2
      (struct.get $type32 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type34)
          (local.get $0)
         )
        )
        (i32.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type35)
          (local.get $0)
         )
        )
        (i32.const 0)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $0)
       )
      )
      (i32.const 1)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global618)
      )
     )
     (if (result i32)
      (local.tee $2
       (struct.get $type32 0
        (local.get $1)
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $2)
         (i32.const 1)
        )
        (then
         (drop
          (ref.cast (ref $type34)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
        (else
         (drop
          (ref.cast (ref $type35)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global636)
     )
    )
    (local.set $3
     (call $function184
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global636)
     )
    )
    (local.set $4
     (call $function184
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global559)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global236)
     )
    )
    (return_call $function177
     (block (result (ref $type27))
      (local.set $scratch_11
       (call $function153
        (call $function71
         (call $function77
          (struct.get $type27 0
           (local.get $3)
          )
          (local.tee $7
           (struct.get $type27 1
            (local.get $4)
           )
          )
         )
         (block (result (ref $type28))
          (drop
           (ref.as_non_null
            (global.get $global236)
           )
          )
          (local.set $scratch
           (call $function77
            (struct.get $type27 0
             (local.get $4)
            )
            (local.tee $8
             (struct.get $type27 1
              (local.get $3)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global211)
           )
          )
          (local.get $scratch)
         )
        )
        (block (result (ref $type28))
         (drop
          (ref.as_non_null
           (global.get $global236)
          )
         )
         (local.set $scratch_10
          (call $function77
           (local.get $8)
           (local.get $7)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global540)
          )
         )
         (local.get $scratch_10)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global606)
       )
      )
      (local.get $scratch_11)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global630)
     )
    )
    (struct.new $type35
     (i32.const 2)
     (f64.add
      (if (result f64)
       (local.tee $2
        (struct.get $type32 0
         (local.get $0)
        )
       )
       (then
        (if (result f64)
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global598)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global507)
           )
          )
          (call $function142
           (struct.get $type27 0
            (local.tee $3
             (struct.get $type34 1
              (ref.cast (ref $type34)
               (local.get $0)
              )
             )
            )
           )
           (struct.get $type27 1
            (local.get $3)
           )
          )
         )
         (else
          (struct.get $type35 1
           (ref.cast (ref $type35)
            (local.get $0)
           )
          )
         )
        )
       )
       (else
        (f64.convert_i64_s
         (struct.get $type33 1
          (ref.cast (ref $type33)
           (local.get $0)
          )
         )
        )
       )
      )
      (block (result f64)
       (drop
        (ref.as_non_null
         (global.get $global630)
        )
       )
       (if (result f64)
        (local.tee $2
         (struct.get $type32 0
          (local.get $1)
         )
        )
        (then
         (if (result f64)
          (i32.eq
           (local.get $2)
           (i32.const 1)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global598)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global507)
            )
           )
           (call $function142
            (struct.get $type27 0
             (local.tee $3
              (struct.get $type34 1
               (ref.cast (ref $type34)
                (local.get $1)
               )
              )
             )
            )
            (struct.get $type27 1
             (local.get $3)
            )
           )
          )
          (else
           (struct.get $type35 1
            (ref.cast (ref $type35)
             (local.get $1)
            )
           )
          )
         )
        )
        (else
         (f64.convert_i64_s
          (struct.get $type33 1
           (ref.cast (ref $type33)
            (local.get $1)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function211 (type $call138) (param $0 (ref $type32)) (result (ref $type32))
  (local $1 (ref $type28))
  (local $2 (ref $type27))
  (local $3 (ref null $type27))
  (local $4 i32)
  (block $block
   (return
    (if (result (ref $type35))
     (local.tee $4
      (struct.get $type32 0
       (local.get $0)
      )
     )
     (then
      (if (result (ref $type35))
       (i32.eq
        (local.get $4)
        (i32.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global555)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global134)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global130)
         )
        )
        (local.set $3
         (struct.new $type27
          (if (result (ref $type28))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (struct.get $type28 1
               (local.tee $1
                (struct.get $type27 0
                 (local.tee $2
                  (struct.get $type34 1
                   (ref.cast (ref $type34)
                    (local.get $0)
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
           (then
            (local.get $1)
           )
           (else
            (struct.new $type28
             (i32.eqz
              (struct.get $type28 0
               (local.get $1)
              )
             )
             (struct.get $type28 1
              (local.get $1)
             )
            )
           )
          )
          (struct.get $type27 1
           (local.get $2)
          )
         )
        )
        (br $block)
       )
       (else
        (struct.new $type35
         (i32.const 2)
         (f64.sub
          (f64.const -0.0)
          (struct.get $type35 1
           (ref.cast (ref $type35)
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global636)
       )
      )
      (local.set $2
       (call $function184
        (struct.new $type33
         (i32.const 0)
         (struct.get $type33 1
          (ref.cast (ref $type33)
           (local.get $0)
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global555)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (local.set $3
       (struct.new $type27
        (if (result (ref $type28))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (struct.get $type28 1
             (local.tee $1
              (struct.get $type27 0
               (local.get $2)
              )
             )
            )
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (struct.new $type28
           (i32.eqz
            (struct.get $type28 0
             (local.get $1)
            )
           )
           (struct.get $type28 1
            (local.get $1)
           )
          )
         )
        )
        (struct.get $type27 1
         (local.get $2)
        )
       )
      )
      (br $block)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global606)
   )
  )
  (return_call $function177
   (ref.as_non_null
    (local.get $3)
   )
  )
 )
 (func $function212 (type $call137) (param $0 (ref $type32)) (param $1 (ref $type32)) (result (ref $type32))
  (local $2 i32)
  (local $3 (ref $type27))
  (local $4 (ref $type27))
  (local $5 (ref $type27))
  (local $6 (ref $type28))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $scratch (ref $type28))
  (local $scratch_10 (ref $type28))
  (local $scratch_11 (ref $type27))
  (drop
   (ref.as_non_null
    (global.get $global618)
   )
  )
  (if (result (ref $type35))
   (if (result i32)
    (if (result i32)
     (local.tee $2
      (struct.get $type32 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type34)
          (local.get $0)
         )
        )
        (i32.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type35)
          (local.get $0)
         )
        )
        (i32.const 0)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $0)
       )
      )
      (i32.const 1)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global618)
      )
     )
     (if (result i32)
      (local.tee $2
       (struct.get $type32 0
        (local.get $1)
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $2)
         (i32.const 1)
        )
        (then
         (drop
          (ref.cast (ref $type34)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
        (else
         (drop
          (ref.cast (ref $type35)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global636)
     )
    )
    (local.set $3
     (call $function184
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global636)
     )
    )
    (local.set $4
     (call $function184
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global562)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global555)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global559)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global236)
     )
    )
    (return_call $function177
     (block (result (ref $type27))
      (local.set $scratch_11
       (call $function153
        (call $function71
         (call $function77
          (struct.get $type27 0
           (local.get $3)
          )
          (local.tee $8
           (struct.get $type27 1
            (local.get $4)
           )
          )
         )
         (block (result (ref $type28))
          (drop
           (ref.as_non_null
            (global.get $global236)
           )
          )
          (local.set $scratch
           (call $function77
            (if (result (ref $type28))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (struct.get $type28 1
                 (local.tee $6
                  (struct.get $type27 0
                   (local.get $4)
                  )
                 )
                )
               )
              )
             )
             (then
              (local.get $6)
             )
             (else
              (struct.new $type28
               (i32.eqz
                (struct.get $type28 0
                 (local.get $6)
                )
               )
               (struct.get $type28 1
                (local.get $6)
               )
              )
             )
            )
            (local.tee $6
             (struct.get $type27 1
              (local.get $3)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global211)
           )
          )
          (local.get $scratch)
         )
        )
        (block (result (ref $type28))
         (drop
          (ref.as_non_null
           (global.get $global236)
          )
         )
         (local.set $scratch_10
          (call $function77
           (local.get $6)
           (local.get $8)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global540)
          )
         )
         (local.get $scratch_10)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global606)
       )
      )
      (local.get $scratch_11)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global630)
     )
    )
    (struct.new $type35
     (i32.const 2)
     (f64.sub
      (if (result f64)
       (local.tee $2
        (struct.get $type32 0
         (local.get $0)
        )
       )
       (then
        (if (result f64)
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global598)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global507)
           )
          )
          (call $function142
           (struct.get $type27 0
            (local.tee $3
             (struct.get $type34 1
              (ref.cast (ref $type34)
               (local.get $0)
              )
             )
            )
           )
           (struct.get $type27 1
            (local.get $3)
           )
          )
         )
         (else
          (struct.get $type35 1
           (ref.cast (ref $type35)
            (local.get $0)
           )
          )
         )
        )
       )
       (else
        (f64.convert_i64_s
         (struct.get $type33 1
          (ref.cast (ref $type33)
           (local.get $0)
          )
         )
        )
       )
      )
      (block (result f64)
       (drop
        (ref.as_non_null
         (global.get $global630)
        )
       )
       (if (result f64)
        (local.tee $2
         (struct.get $type32 0
          (local.get $1)
         )
        )
        (then
         (if (result f64)
          (i32.eq
           (local.get $2)
           (i32.const 1)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global598)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global507)
            )
           )
           (call $function142
            (struct.get $type27 0
             (local.tee $3
              (struct.get $type34 1
               (ref.cast (ref $type34)
                (local.get $1)
               )
              )
             )
            )
            (struct.get $type27 1
             (local.get $3)
            )
           )
          )
          (else
           (struct.get $type35 1
            (ref.cast (ref $type35)
             (local.get $1)
            )
           )
          )
         )
        )
        (else
         (f64.convert_i64_s
          (struct.get $type33 1
           (ref.cast (ref $type33)
            (local.get $1)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function213 (type $call137) (param $0 (ref $type32)) (param $1 (ref $type32)) (result (ref $type32))
  (local $2 i32)
  (local $3 (ref $type27))
  (local $4 (ref $type27))
  (local $5 (ref $type27))
  (local $6 (ref $type28))
  (local $scratch (ref $type28))
  (local $scratch_8 (ref $type27))
  (drop
   (ref.as_non_null
    (global.get $global618)
   )
  )
  (if (result (ref $type35))
   (if (result i32)
    (if (result i32)
     (local.tee $2
      (struct.get $type32 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type34)
          (local.get $0)
         )
        )
        (i32.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type35)
          (local.get $0)
         )
        )
        (i32.const 0)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $0)
       )
      )
      (i32.const 1)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global618)
      )
     )
     (if (result i32)
      (local.tee $2
       (struct.get $type32 0
        (local.get $1)
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $2)
         (i32.const 1)
        )
        (then
         (drop
          (ref.cast (ref $type34)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
        (else
         (drop
          (ref.cast (ref $type35)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global636)
     )
    )
    (local.set $3
     (call $function184
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global636)
     )
    )
    (local.set $4
     (call $function184
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global565)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global236)
     )
    )
    (return_call $function177
     (block (result (ref $type27))
      (local.set $scratch_8
       (call $function153
        (call $function77
         (struct.get $type27 0
          (local.get $3)
         )
         (struct.get $type27 0
          (local.get $4)
         )
        )
        (block (result (ref $type28))
         (drop
          (ref.as_non_null
           (global.get $global236)
          )
         )
         (local.set $scratch
          (call $function77
           (struct.get $type27 1
            (local.get $3)
           )
           (struct.get $type27 1
            (local.get $4)
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global540)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global606)
       )
      )
      (local.get $scratch_8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global630)
     )
    )
    (struct.new $type35
     (i32.const 2)
     (f64.mul
      (if (result f64)
       (local.tee $2
        (struct.get $type32 0
         (local.get $0)
        )
       )
       (then
        (if (result f64)
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global598)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global507)
           )
          )
          (call $function142
           (struct.get $type27 0
            (local.tee $3
             (struct.get $type34 1
              (ref.cast (ref $type34)
               (local.get $0)
              )
             )
            )
           )
           (struct.get $type27 1
            (local.get $3)
           )
          )
         )
         (else
          (struct.get $type35 1
           (ref.cast (ref $type35)
            (local.get $0)
           )
          )
         )
        )
       )
       (else
        (f64.convert_i64_s
         (struct.get $type33 1
          (ref.cast (ref $type33)
           (local.get $0)
          )
         )
        )
       )
      )
      (block (result f64)
       (drop
        (ref.as_non_null
         (global.get $global630)
        )
       )
       (if (result f64)
        (local.tee $2
         (struct.get $type32 0
          (local.get $1)
         )
        )
        (then
         (if (result f64)
          (i32.eq
           (local.get $2)
           (i32.const 1)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global598)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global507)
            )
           )
           (call $function142
            (struct.get $type27 0
             (local.tee $3
              (struct.get $type34 1
               (ref.cast (ref $type34)
                (local.get $1)
               )
              )
             )
            )
            (struct.get $type27 1
             (local.get $3)
            )
           )
          )
          (else
           (struct.get $type35 1
            (ref.cast (ref $type35)
             (local.get $1)
            )
           )
          )
         )
        )
        (else
         (f64.convert_i64_s
          (struct.get $type33 1
           (ref.cast (ref $type33)
            (local.get $1)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function214 (type $call137) (param $0 (ref $type32)) (param $1 (ref $type32)) (result (ref $type32))
  (local $2 i32)
  (local $3 (ref $type27))
  (local $4 (ref $type27))
  (local $5 (ref $type27))
  (local $6 (ref $type28))
  (local $scratch (ref $type28))
  (local $scratch_8 (ref $type27))
  (drop
   (ref.as_non_null
    (global.get $global618)
   )
  )
  (if (result (ref $type35))
   (if (result i32)
    (if (result i32)
     (local.tee $2
      (struct.get $type32 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type34)
          (local.get $0)
         )
        )
        (i32.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type35)
          (local.get $0)
         )
        )
        (i32.const 0)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $0)
       )
      )
      (i32.const 1)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global618)
      )
     )
     (if (result i32)
      (local.tee $2
       (struct.get $type32 0
        (local.get $1)
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $2)
         (i32.const 1)
        )
        (then
         (drop
          (ref.cast (ref $type34)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
        (else
         (drop
          (ref.cast (ref $type35)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $1)
        )
       )
       (i32.const 1)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global636)
     )
    )
    (local.set $3
     (call $function184
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global636)
     )
    )
    (local.set $4
     (call $function184
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global568)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global236)
     )
    )
    (return_call $function177
     (block (result (ref $type27))
      (local.set $scratch_8
       (call $function153
        (call $function77
         (struct.get $type27 0
          (local.get $3)
         )
         (struct.get $type27 1
          (local.get $4)
         )
        )
        (block (result (ref $type28))
         (drop
          (ref.as_non_null
           (global.get $global236)
          )
         )
         (local.set $scratch
          (call $function77
           (struct.get $type27 1
            (local.get $3)
           )
           (struct.get $type27 0
            (local.get $4)
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global540)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global606)
       )
      )
      (local.get $scratch_8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global630)
     )
    )
    (struct.new $type35
     (i32.const 2)
     (f64.div
      (if (result f64)
       (local.tee $2
        (struct.get $type32 0
         (local.get $0)
        )
       )
       (then
        (if (result f64)
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global598)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global507)
           )
          )
          (call $function142
           (struct.get $type27 0
            (local.tee $3
             (struct.get $type34 1
              (ref.cast (ref $type34)
               (local.get $0)
              )
             )
            )
           )
           (struct.get $type27 1
            (local.get $3)
           )
          )
         )
         (else
          (struct.get $type35 1
           (ref.cast (ref $type35)
            (local.get $0)
           )
          )
         )
        )
       )
       (else
        (f64.convert_i64_s
         (struct.get $type33 1
          (ref.cast (ref $type33)
           (local.get $0)
          )
         )
        )
       )
      )
      (block (result f64)
       (drop
        (ref.as_non_null
         (global.get $global630)
        )
       )
       (if (result f64)
        (local.tee $2
         (struct.get $type32 0
          (local.get $1)
         )
        )
        (then
         (if (result f64)
          (i32.eq
           (local.get $2)
           (i32.const 1)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global598)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global507)
            )
           )
           (call $function142
            (struct.get $type27 0
             (local.tee $3
              (struct.get $type34 1
               (ref.cast (ref $type34)
                (local.get $1)
               )
              )
             )
            )
            (struct.get $type27 1
             (local.get $3)
            )
           )
          )
          (else
           (struct.get $type35 1
            (ref.cast (ref $type35)
             (local.get $1)
            )
           )
          )
         )
        )
        (else
         (f64.convert_i64_s
          (struct.get $type33 1
           (ref.cast (ref $type33)
            (local.get $1)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function215 (type $call139) (param $0 (ref $type24)) (param $1 (ref $type24)) (result (ref $type24))
  (local $2 i32)
  (local $3 (ref $type32))
  (local $scratch (ref $type32))
  (drop
   (ref.as_non_null
    (global.get $global650)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global732)
   )
  )
  (return_call $function185
   (call $function210
    (if (result (ref $type32))
     (local.tee $2
      (struct.get $type24 0
       (local.get $0)
      )
     )
     (then
      (if (result (ref $type32))
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (struct.new $type34
         (i32.const 1)
         (struct.get $type26 1
          (ref.cast (ref $type26)
           (local.get $0)
          )
         )
        )
       )
       (else
        (if (result (ref $type32))
         (i32.eq
          (struct.get $type24 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (struct.new $type35
           (i32.const 2)
           (struct.get $type30 1
            (ref.cast (ref $type30)
             (local.get $0)
            )
           )
          )
         )
         (else
          (struct.get $type31 1
           (ref.cast (ref $type31)
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
     (else
      (struct.new $type33
       (i32.const 0)
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $0)
        )
       )
      )
     )
    )
    (if (result (ref $type32))
     (local.tee $2
      (struct.get $type24 0
       (local.get $1)
      )
     )
     (then
      (if (result (ref $type32))
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (struct.new $type34
         (i32.const 1)
         (struct.get $type26 1
          (ref.cast (ref $type26)
           (local.get $1)
          )
         )
        )
       )
       (else
        (if (result (ref $type32))
         (i32.eq
          (struct.get $type24 0
           (local.get $1)
          )
          (i32.const 2)
         )
         (then
          (struct.new $type35
           (i32.const 2)
           (struct.get $type30 1
            (ref.cast (ref $type30)
             (local.get $1)
            )
           )
          )
         )
         (else
          (struct.get $type31 1
           (ref.cast (ref $type31)
            (local.get $1)
           )
          )
         )
        )
       )
      )
     )
     (else
      (struct.new $type33
       (i32.const 0)
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (block (result (ref $type32))
    (drop
     (ref.as_non_null
      (global.get $global658)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global732)
     )
    )
    (local.set $scratch
     (call $function210
      (if (result (ref $type32))
       (local.tee $2
        (struct.get $type24 0
         (local.get $0)
        )
       )
       (then
        (if (result (ref $type32))
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type26)
            (local.get $0)
           )
          )
          (struct.new_default $type33)
         )
         (else
          (if (result (ref $type32))
           (i32.eq
            (struct.get $type24 0
             (local.get $0)
            )
            (i32.const 2)
           )
           (then
            (drop
             (ref.cast (ref $type30)
              (local.get $0)
             )
            )
            (struct.new_default $type33)
           )
           (else
            (struct.get $type31 2
             (ref.cast (ref $type31)
              (local.get $0)
             )
            )
           )
          )
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type25)
          (local.get $0)
         )
        )
        (struct.new_default $type33)
       )
      )
      (if (result (ref $type32))
       (local.tee $2
        (struct.get $type24 0
         (local.get $1)
        )
       )
       (then
        (if (result (ref $type32))
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type26)
            (local.get $1)
           )
          )
          (struct.new_default $type33)
         )
         (else
          (if (result (ref $type32))
           (i32.eq
            (struct.get $type24 0
             (local.get $1)
            )
            (i32.const 2)
           )
           (then
            (drop
             (ref.cast (ref $type30)
              (local.get $1)
             )
            )
            (struct.new_default $type33)
           )
           (else
            (struct.get $type31 2
             (ref.cast (ref $type31)
              (local.get $1)
             )
            )
           )
          )
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type25)
          (local.get $1)
         )
        )
        (struct.new_default $type33)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global642)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function216 (type $call133) (param $0 (ref $type24)) (result (ref $type24))
  (local $1 i32)
  (local $2 (ref $type32))
  (local $scratch (ref $type32))
  (drop
   (ref.as_non_null
    (global.get $global650)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global735)
   )
  )
  (return_call $function185
   (call $function211
    (if (result (ref $type32))
     (local.tee $1
      (struct.get $type24 0
       (local.get $0)
      )
     )
     (then
      (if (result (ref $type32))
       (i32.eq
        (local.get $1)
        (i32.const 1)
       )
       (then
        (struct.new $type34
         (i32.const 1)
         (struct.get $type26 1
          (ref.cast (ref $type26)
           (local.get $0)
          )
         )
        )
       )
       (else
        (if (result (ref $type32))
         (i32.eq
          (struct.get $type24 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (struct.new $type35
           (i32.const 2)
           (struct.get $type30 1
            (ref.cast (ref $type30)
             (local.get $0)
            )
           )
          )
         )
         (else
          (struct.get $type31 1
           (ref.cast (ref $type31)
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
     (else
      (struct.new $type33
       (i32.const 0)
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $0)
        )
       )
      )
     )
    )
   )
   (block (result (ref $type32))
    (drop
     (ref.as_non_null
      (global.get $global658)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global735)
     )
    )
    (local.set $scratch
     (call $function211
      (if (result (ref $type32))
       (local.tee $1
        (struct.get $type24 0
         (local.get $0)
        )
       )
       (then
        (if (result (ref $type32))
         (i32.eq
          (local.get $1)
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type26)
            (local.get $0)
           )
          )
          (struct.new_default $type33)
         )
         (else
          (if (result (ref $type32))
           (i32.eq
            (struct.get $type24 0
             (local.get $0)
            )
            (i32.const 2)
           )
           (then
            (drop
             (ref.cast (ref $type30)
              (local.get $0)
             )
            )
            (struct.new_default $type33)
           )
           (else
            (struct.get $type31 2
             (ref.cast (ref $type31)
              (local.get $0)
             )
            )
           )
          )
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type25)
          (local.get $0)
         )
        )
        (struct.new_default $type33)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global642)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function219 (type $call139) (param $0 (ref $type24)) (param $1 (ref $type24)) (result (ref $type24))
  (local $2 (ref $type32))
  (local $3 (ref $type32))
  (local $4 (ref $type32))
  (local $5 (ref $type32))
  (local $6 (ref $type32))
  (local $7 (ref $type32))
  (local $8 i32)
  (local $scratch (ref $type32))
  (local $scratch_10 (ref $type32))
  (local $scratch_11 (ref $type32))
  (local $scratch_12 (ref $type32))
  (drop
   (ref.as_non_null
    (global.get $global650)
   )
  )
  (local.set $5
   (if (result (ref $type32))
    (local.tee $8
     (struct.get $type24 0
      (local.get $0)
     )
    )
    (then
     (if (result (ref $type32))
      (i32.eq
       (local.get $8)
       (i32.const 1)
      )
      (then
       (struct.new $type34
        (i32.const 1)
        (struct.get $type26 1
         (ref.cast (ref $type26)
          (local.get $0)
         )
        )
       )
      )
      (else
       (if (result (ref $type32))
        (i32.eq
         (struct.get $type24 0
          (local.get $0)
         )
         (i32.const 2)
        )
        (then
         (struct.new $type35
          (i32.const 2)
          (struct.get $type30 1
           (ref.cast (ref $type30)
            (local.get $0)
           )
          )
         )
        )
        (else
         (struct.get $type31 1
          (ref.cast (ref $type31)
           (local.get $0)
          )
         )
        )
       )
      )
     )
    )
    (else
     (struct.new $type33
      (i32.const 0)
      (struct.get $type25 1
       (ref.cast (ref $type25)
        (local.get $0)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global658)
   )
  )
  (local.set $6
   (if (result (ref $type32))
    (local.tee $8
     (struct.get $type24 0
      (local.get $0)
     )
    )
    (then
     (if (result (ref $type32))
      (i32.eq
       (local.get $8)
       (i32.const 1)
      )
      (then
       (drop
        (ref.cast (ref $type26)
         (local.get $0)
        )
       )
       (struct.new_default $type33)
      )
      (else
       (if (result (ref $type32))
        (i32.eq
         (struct.get $type24 0
          (local.get $0)
         )
         (i32.const 2)
        )
        (then
         (drop
          (ref.cast (ref $type30)
           (local.get $0)
          )
         )
         (struct.new_default $type33)
        )
        (else
         (struct.get $type31 2
          (ref.cast (ref $type31)
           (local.get $0)
          )
         )
        )
       )
      )
     )
    )
    (else
     (drop
      (ref.cast (ref $type25)
       (local.get $0)
      )
     )
     (struct.new_default $type33)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global650)
   )
  )
  (local.set $2
   (if (result (ref $type32))
    (local.tee $8
     (struct.get $type24 0
      (local.get $1)
     )
    )
    (then
     (if (result (ref $type32))
      (i32.eq
       (local.get $8)
       (i32.const 1)
      )
      (then
       (struct.new $type34
        (i32.const 1)
        (struct.get $type26 1
         (ref.cast (ref $type26)
          (local.get $1)
         )
        )
       )
      )
      (else
       (if (result (ref $type32))
        (i32.eq
         (struct.get $type24 0
          (local.get $1)
         )
         (i32.const 2)
        )
        (then
         (struct.new $type35
          (i32.const 2)
          (struct.get $type30 1
           (ref.cast (ref $type30)
            (local.get $1)
           )
          )
         )
        )
        (else
         (struct.get $type31 1
          (ref.cast (ref $type31)
           (local.get $1)
          )
         )
        )
       )
      )
     )
    )
    (else
     (struct.new $type33
      (i32.const 0)
      (struct.get $type25 1
       (ref.cast (ref $type25)
        (local.get $1)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global658)
   )
  )
  (local.set $3
   (if (result (ref $type32))
    (local.tee $8
     (struct.get $type24 0
      (local.get $1)
     )
    )
    (then
     (if (result (ref $type32))
      (i32.eq
       (local.get $8)
       (i32.const 1)
      )
      (then
       (drop
        (ref.cast (ref $type26)
         (local.get $1)
        )
       )
       (struct.new_default $type33)
      )
      (else
       (if (result (ref $type32))
        (i32.eq
         (struct.get $type24 0
          (local.get $1)
         )
         (i32.const 2)
        )
        (then
         (drop
          (ref.cast (ref $type30)
           (local.get $1)
          )
         )
         (struct.new_default $type33)
        )
        (else
         (struct.get $type31 2
          (ref.cast (ref $type31)
           (local.get $1)
          )
         )
        )
       )
      )
     )
    )
    (else
     (drop
      (ref.cast (ref $type25)
       (local.get $1)
      )
     )
     (struct.new_default $type33)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global666)
   )
  )
  (if (result (ref $type24))
   (if (result i32)
    (if (result i32)
     (local.tee $8
      (struct.get $type24 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $8)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type26)
          (local.get $0)
         )
        )
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i32.eq
          (struct.get $type24 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (drop
           (ref.cast (ref $type30)
            (local.get $0)
           )
          )
          (i32.const 0)
         )
         (else
          (drop
           (ref.cast (ref $type31)
            (local.get $0)
           )
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type25)
        (local.get $0)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global666)
      )
     )
     (if (result i32)
      (local.tee $8
       (struct.get $type24 0
        (local.get $1)
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $8)
         (i32.const 1)
        )
        (then
         (drop
          (ref.cast (ref $type26)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
        (else
         (if (result i32)
          (i32.eq
           (struct.get $type24 0
            (local.get $1)
           )
           (i32.const 2)
          )
          (then
           (drop
            (ref.cast (ref $type30)
             (local.get $1)
            )
           )
           (i32.const 0)
          )
          (else
           (drop
            (ref.cast (ref $type31)
             (local.get $1)
            )
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (else
       (drop
        (ref.cast (ref $type25)
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global744)
     )
    )
    (local.set $4
     (call $function210
      (call $function213
       (local.get $2)
       (local.get $2)
      )
      (block (result (ref $type32))
       (drop
        (ref.as_non_null
         (global.get $global744)
        )
       )
       (local.set $scratch
        (call $function213
         (local.get $3)
         (local.get $3)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global732)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global744)
     )
    )
    (return_call $function185
     (call $function214
      (call $function210
       (call $function213
        (local.get $5)
        (local.get $2)
       )
       (block (result (ref $type32))
        (drop
         (ref.as_non_null
          (global.get $global744)
         )
        )
        (local.set $scratch_10
         (call $function213
          (local.get $6)
          (local.get $3)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global732)
         )
        )
        (local.get $scratch_10)
       )
      )
      (block (result (ref $type32))
       (drop
        (ref.as_non_null
         (global.get $global747)
        )
       )
       (local.get $4)
      )
     )
     (block (result (ref $type32))
      (drop
       (ref.as_non_null
        (global.get $global744)
       )
      )
      (local.set $scratch_12
       (call $function214
        (call $function212
         (call $function213
          (local.get $6)
          (local.get $2)
         )
         (block (result (ref $type32))
          (drop
           (ref.as_non_null
            (global.get $global744)
           )
          )
          (local.set $scratch_11
           (call $function213
            (local.get $5)
            (local.get $3)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global741)
           )
          )
          (local.get $scratch_11)
         )
        )
        (block (result (ref $type32))
         (drop
          (ref.as_non_null
           (global.get $global747)
          )
         )
         (local.get $4)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global642)
       )
      )
      (local.get $scratch_12)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global747)
     )
    )
    (local.set $2
     (call $function214
      (local.get $5)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global608)
     )
    )
    (if (result (ref $type24))
     (local.tee $8
      (struct.get $type32 0
       (local.get $2)
      )
     )
     (then
      (if (result (ref $type24))
       (i32.eq
        (local.get $8)
        (i32.const 1)
       )
       (then
        (struct.new $type26
         (i32.const 1)
         (struct.get $type34 1
          (ref.cast (ref $type34)
           (local.get $2)
          )
         )
        )
       )
       (else
        (struct.new $type30
         (i32.const 2)
         (struct.get $type35 1
          (ref.cast (ref $type35)
           (local.get $2)
          )
         )
        )
       )
      )
     )
     (else
      (struct.new $type25
       (i32.const 0)
       (struct.get $type33 1
        (ref.cast (ref $type33)
         (local.get $2)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function221 (type $call140) (param $0 (ref $type32)) (param $1 (ref $type32)) (result i64)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 i32)
  (local $6 (ref $type27))
  (local $7 (ref $type27))
  (local $8 (ref $type28))
  (local $scratch (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global773)
   )
  )
  (if (result i64)
   (if (result i32)
    (if (result i32)
     (local.tee $5
      (struct.get $type32 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $5)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type34)
          (local.get $0)
         )
        )
        (i32.const 0)
       )
       (else
        (f64.ne
         (local.tee $2
          (struct.get $type35 1
           (ref.cast (ref $type35)
            (local.get $0)
           )
          )
         )
         (local.get $2)
        )
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $0)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global773)
      )
     )
     (if (result i32)
      (local.tee $5
       (struct.get $type32 0
        (local.get $1)
       )
      )
      (then
       (if (result i32)
        (i32.eq
         (local.get $5)
         (i32.const 1)
        )
        (then
         (drop
          (ref.cast (ref $type34)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
        (else
         (f64.ne
          (local.tee $2
           (struct.get $type35 1
            (ref.cast (ref $type35)
             (local.get $1)
            )
           )
          )
          (local.get $2)
         )
        )
       )
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
    )
   )
   (then
    (i64.const 2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global690)
     )
    )
    (if (result i64)
     (if (result i32)
      (if (result i32)
       (local.tee $5
        (struct.get $type32 0
         (local.get $0)
        )
       )
       (then
        (if (result i32)
         (i32.eq
          (local.get $5)
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type34)
            (local.get $0)
           )
          )
          (i32.const 1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global688)
           )
          )
          (if (result i32)
           (f64.eq
            (local.tee $2
             (struct.get $type35 1
              (ref.cast (ref $type35)
               (local.get $0)
              )
             )
            )
            (local.get $2)
           )
           (then
            (i32.and
             (f64.lt
              (local.get $2)
              (f64.const inf)
             )
             (f64.gt
              (local.get $2)
              (f64.const -inf)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type33)
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global690)
        )
       )
       (if (result i32)
        (local.tee $5
         (struct.get $type32 0
          (local.get $1)
         )
        )
        (then
         (if (result i32)
          (i32.eq
           (local.get $5)
           (i32.const 1)
          )
          (then
           (drop
            (ref.cast (ref $type34)
             (local.get $1)
            )
           )
           (i32.const 1)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global688)
            )
           )
           (if (result i32)
            (f64.eq
             (local.tee $2
              (struct.get $type35 1
               (ref.cast (ref $type35)
                (local.get $1)
               )
              )
             )
             (local.get $2)
            )
            (then
             (i32.and
              (f64.lt
               (local.get $2)
               (f64.const inf)
              )
              (f64.gt
               (local.get $2)
               (f64.const -inf)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
         )
        )
        (else
         (drop
          (ref.cast (ref $type33)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global636)
       )
      )
      (local.set $6
       (call $function184
        (local.get $0)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global636)
       )
      )
      (local.set $7
       (call $function184
        (local.get $1)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global575)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global236)
       )
      )
      (return_call $function59
       (call $function77
        (struct.get $type27 0
         (local.get $6)
        )
        (struct.get $type27 1
         (local.get $7)
        )
       )
       (block (result (ref $type28))
        (drop
         (ref.as_non_null
          (global.get $global236)
         )
        )
        (local.set $scratch
         (call $function77
          (struct.get $type27 0
           (local.get $7)
          )
          (struct.get $type27 1
           (local.get $6)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global167)
         )
        )
        (local.get $scratch)
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global630)
       )
      )
      (if (result i64)
       (f64.lt
        (local.tee $3
         (if (result f64)
          (local.tee $5
           (struct.get $type32 0
            (local.get $0)
           )
          )
          (then
           (if (result f64)
            (i32.eq
             (local.get $5)
             (i32.const 1)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global598)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global507)
              )
             )
             (call $function142
              (struct.get $type27 0
               (local.tee $6
                (struct.get $type34 1
                 (ref.cast (ref $type34)
                  (local.get $0)
                 )
                )
               )
              )
              (struct.get $type27 1
               (local.get $6)
              )
             )
            )
            (else
             (struct.get $type35 1
              (ref.cast (ref $type35)
               (local.get $0)
              )
             )
            )
           )
          )
          (else
           (f64.convert_i64_s
            (struct.get $type33 1
             (ref.cast (ref $type33)
              (local.get $0)
             )
            )
           )
          )
         )
        )
        (block (result f64)
         (drop
          (ref.as_non_null
           (global.get $global630)
          )
         )
         (local.tee $4
          (if (result f64)
           (local.tee $5
            (struct.get $type32 0
             (local.get $1)
            )
           )
           (then
            (if (result f64)
             (i32.eq
              (local.get $5)
              (i32.const 1)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global598)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global507)
               )
              )
              (call $function142
               (struct.get $type27 0
                (local.tee $6
                 (struct.get $type34 1
                  (ref.cast (ref $type34)
                   (local.get $1)
                  )
                 )
                )
               )
               (struct.get $type27 1
                (local.get $6)
               )
              )
             )
             (else
              (struct.get $type35 1
               (ref.cast (ref $type35)
                (local.get $1)
               )
              )
             )
            )
           )
           (else
            (f64.convert_i64_s
             (struct.get $type33 1
              (ref.cast (ref $type33)
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (if (result i64)
         (f64.gt
          (local.get $3)
          (local.get $4)
         )
         (then
          (i64.const 1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global690)
           )
          )
          (if (result i64)
           (if (result i32)
            (local.tee $5
             (struct.get $type32 0
              (local.get $0)
             )
            )
            (then
             (if (result i32)
              (i32.eq
               (local.get $5)
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type34)
                 (local.get $0)
                )
               )
               (i32.const 1)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global688)
                )
               )
               (if (result i32)
                (f64.eq
                 (local.tee $2
                  (struct.get $type35 1
                   (ref.cast (ref $type35)
                    (local.get $0)
                   )
                  )
                 )
                 (local.get $2)
                )
                (then
                 (i32.and
                  (f64.lt
                   (local.get $2)
                   (f64.const inf)
                  )
                  (f64.gt
                   (local.get $2)
                   (f64.const -inf)
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
             )
            )
            (else
             (drop
              (ref.cast (ref $type33)
               (local.get $0)
              )
             )
             (i32.const 1)
            )
           )
           (then
            (select
             (i64.const 1)
             (i64.const -1)
             (f64.lt
              (local.get $4)
              (f64.const 0.0)
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global690)
             )
            )
            (if (result i64)
             (if (result i32)
              (local.tee $5
               (struct.get $type32 0
                (local.get $1)
               )
              )
              (then
               (if (result i32)
                (i32.eq
                 (local.get $5)
                 (i32.const 1)
                )
                (then
                 (drop
                  (ref.cast (ref $type34)
                   (local.get $1)
                  )
                 )
                 (i32.const 1)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global688)
                  )
                 )
                 (if (result i32)
                  (f64.eq
                   (local.tee $2
                    (struct.get $type35 1
                     (ref.cast (ref $type35)
                      (local.get $1)
                     )
                    )
                   )
                   (local.get $2)
                  )
                  (then
                   (i32.and
                    (f64.lt
                     (local.get $2)
                     (f64.const inf)
                    )
                    (f64.gt
                     (local.get $2)
                     (f64.const -inf)
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                )
               )
              )
              (else
               (drop
                (ref.cast (ref $type33)
                 (local.get $1)
                )
               )
               (i32.const 1)
              )
             )
             (then
              (select
               (i64.const -1)
               (i64.const 1)
               (f64.lt
                (local.get $3)
                (f64.const 0.0)
               )
              )
             )
             (else
              (i64.const 0)
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function222 (type $call141) (param $0 (ref $type24)) (param $1 (ref $type24)) (result i32)
  (local $2 i32)
  (drop
   (ref.as_non_null
    (global.get $global650)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global779)
   )
  )
  (if (result i32)
   (i64.eqz
    (call $function221
     (if (result (ref $type32))
      (local.tee $2
       (struct.get $type24 0
        (local.get $0)
       )
      )
      (then
       (if (result (ref $type32))
        (i32.eq
         (local.get $2)
         (i32.const 1)
        )
        (then
         (struct.new $type34
          (i32.const 1)
          (struct.get $type26 1
           (ref.cast (ref $type26)
            (local.get $0)
           )
          )
         )
        )
        (else
         (if (result (ref $type32))
          (i32.eq
           (struct.get $type24 0
            (local.get $0)
           )
           (i32.const 2)
          )
          (then
           (struct.new $type35
            (i32.const 2)
            (struct.get $type30 1
             (ref.cast (ref $type30)
              (local.get $0)
             )
            )
           )
          )
          (else
           (struct.get $type31 1
            (ref.cast (ref $type31)
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (else
       (struct.new $type33
        (i32.const 0)
        (struct.get $type25 1
         (ref.cast (ref $type25)
          (local.get $0)
         )
        )
       )
      )
     )
     (if (result (ref $type32))
      (local.tee $2
       (struct.get $type24 0
        (local.get $1)
       )
      )
      (then
       (if (result (ref $type32))
        (i32.eq
         (local.get $2)
         (i32.const 1)
        )
        (then
         (struct.new $type34
          (i32.const 1)
          (struct.get $type26 1
           (ref.cast (ref $type26)
            (local.get $1)
           )
          )
         )
        )
        (else
         (if (result (ref $type32))
          (i32.eq
           (struct.get $type24 0
            (local.get $1)
           )
           (i32.const 2)
          )
          (then
           (struct.new $type35
            (i32.const 2)
            (struct.get $type30 1
             (ref.cast (ref $type30)
              (local.get $1)
             )
            )
           )
          )
          (else
           (struct.get $type31 1
            (ref.cast (ref $type31)
             (local.get $1)
            )
           )
          )
         )
        )
       )
      )
      (else
       (struct.new $type33
        (i32.const 0)
        (struct.get $type25 1
         (ref.cast (ref $type25)
          (local.get $1)
         )
        )
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global658)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global779)
     )
    )
    (i64.eqz
     (call $function221
      (if (result (ref $type32))
       (local.tee $2
        (struct.get $type24 0
         (local.get $0)
        )
       )
       (then
        (if (result (ref $type32))
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type26)
            (local.get $0)
           )
          )
          (struct.new_default $type33)
         )
         (else
          (if (result (ref $type32))
           (i32.eq
            (struct.get $type24 0
             (local.get $0)
            )
            (i32.const 2)
           )
           (then
            (drop
             (ref.cast (ref $type30)
              (local.get $0)
             )
            )
            (struct.new_default $type33)
           )
           (else
            (struct.get $type31 2
             (ref.cast (ref $type31)
              (local.get $0)
             )
            )
           )
          )
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type25)
          (local.get $0)
         )
        )
        (struct.new_default $type33)
       )
      )
      (if (result (ref $type32))
       (local.tee $2
        (struct.get $type24 0
         (local.get $1)
        )
       )
       (then
        (if (result (ref $type32))
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type26)
            (local.get $1)
           )
          )
          (struct.new_default $type33)
         )
         (else
          (if (result (ref $type32))
           (i32.eq
            (struct.get $type24 0
             (local.get $1)
            )
            (i32.const 2)
           )
           (then
            (drop
             (ref.cast (ref $type30)
              (local.get $1)
             )
            )
            (struct.new_default $type33)
           )
           (else
            (struct.get $type31 2
             (ref.cast (ref $type31)
              (local.get $1)
             )
            )
           )
          )
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type25)
          (local.get $1)
         )
        )
        (struct.new_default $type33)
       )
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function229 (type $call142) (param $0 (ref $type32)) (param $1 (ref $type32)) (result i32)
  (local $2 i32)
  (local $3 f64)
  (local $4 i64)
  (local $5 (ref $type27))
  (local $6 (ref $type27))
  (if (result i32)
   (local.tee $2
    (struct.get $type32 0
     (local.get $0)
    )
   )
   (then
    (if (result i32)
     (i32.eq
      (local.get $2)
      (i32.const 1)
     )
     (then
      (local.set $5
       (struct.get $type34 1
        (ref.cast (ref $type34)
         (local.get $0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global618)
       )
      )
      (if (result i32)
       (if (result i32)
        (local.tee $2
         (struct.get $type32 0
          (local.get $1)
         )
        )
        (then
         (if (result i32)
          (i32.eq
           (local.get $2)
           (i32.const 1)
          )
          (then
           (drop
            (ref.cast (ref $type34)
             (local.get $1)
            )
           )
           (i32.const 1)
          )
          (else
           (drop
            (ref.cast (ref $type35)
             (local.get $1)
            )
           )
           (i32.const 0)
          )
         )
        )
        (else
         (drop
          (ref.cast (ref $type33)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global636)
         )
        )
        (local.set $6
         (call $function184
          (local.get $1)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global578)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global171)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global167)
         )
        )
        (if (result i32)
         (i64.eqz
          (call $function59
           (struct.get $type27 0
            (local.get $5)
           )
           (struct.get $type27 0
            (local.get $6)
           )
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global171)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global167)
           )
          )
          (i64.eqz
           (call $function59
            (struct.get $type27 1
             (local.get $5)
            )
            (struct.get $type27 1
             (local.get $6)
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (local.set $3
       (struct.get $type35 1
        (ref.cast (ref $type35)
         (local.get $0)
        )
       )
      )
      (if (result i32)
       (local.tee $2
        (struct.get $type32 0
         (local.get $1)
        )
       )
       (then
        (if (result i32)
         (i32.eq
          (local.get $2)
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type34)
            (local.get $1)
           )
          )
          (i32.const 0)
         )
         (else
          (i32.eq
           (call $foreign2
            (local.get $3)
            (struct.get $type35 1
             (ref.cast (ref $type35)
              (local.get $1)
             )
            )
           )
           (i32.const 1)
          )
         )
        )
       )
       (else
        (drop
         (ref.cast (ref $type33)
          (local.get $1)
         )
        )
        (i32.const 0)
       )
      )
     )
    )
   )
   (else
    (local.set $4
     (struct.get $type33 1
      (ref.cast (ref $type33)
       (local.get $0)
      )
     )
    )
    (if (result i32)
     (local.tee $2
      (struct.get $type32 0
       (local.get $1)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 2)
       )
       (then
        (drop
         (ref.cast (ref $type35)
          (local.get $1)
         )
        )
        (i32.const 0)
       )
       (else
        (local.set $5
         (struct.get $type34 1
          (ref.cast (ref $type34)
           (local.get $1)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global636)
         )
        )
        (local.set $6
         (call $function184
          (local.get $0)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global578)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global171)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global167)
         )
        )
        (if (result i32)
         (i64.eqz
          (call $function59
           (struct.get $type27 0
            (local.get $6)
           )
           (struct.get $type27 0
            (local.get $5)
           )
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global171)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global167)
           )
          )
          (i64.eqz
           (call $function59
            (struct.get $type27 1
             (local.get $6)
            )
            (struct.get $type27 1
             (local.get $5)
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
     (else
      (i64.eq
       (struct.get $type33 1
        (ref.cast (ref $type33)
         (local.get $1)
        )
       )
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function230 (type $call141) (param $0 (ref $type24)) (param $1 (ref $type24)) (result i32)
  (local $2 i32)
  (local $3 i64)
  (local $4 f64)
  (local $5 (ref $type27))
  (local $6 (ref $type27))
  (local $7 (ref $type32))
  (local $8 (ref $type32))
  (local $9 (ref $type31))
  (local $10 (ref $type31))
  (local $11 (ref $type28))
  (local $scratch (ref $type32))
  (if (result i32)
   (local.tee $2
    (struct.get $type24 0
     (local.get $0)
    )
   )
   (then
    (if (result i32)
     (i32.eq
      (local.get $2)
      (i32.const 1)
     )
     (then
      (local.set $5
       (struct.get $type26 1
        (ref.cast (ref $type26)
         (local.get $0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global666)
       )
      )
      (if (result i32)
       (if (result i32)
        (local.tee $2
         (struct.get $type24 0
          (local.get $1)
         )
        )
        (then
         (if (result i32)
          (i32.eq
           (local.get $2)
           (i32.const 1)
          )
          (then
           (drop
            (ref.cast (ref $type26)
             (local.get $1)
            )
           )
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i32.eq
             (struct.get $type24 0
              (local.get $1)
             )
             (i32.const 2)
            )
            (then
             (drop
              (ref.cast (ref $type30)
               (local.get $1)
              )
             )
             (i32.const 0)
            )
            (else
             (drop
              (ref.cast (ref $type31)
               (local.get $1)
              )
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (else
         (drop
          (ref.cast (ref $type25)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global704)
         )
        )
        (if (result i32)
         (call $function200
          (local.get $1)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global682)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global674)
           )
          )
          (local.set $6
           (call $function184
            (block (result (ref $type32))
             (local.set $scratch
              (call $function190
               (local.get $1)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global636)
              )
             )
             (local.get $scratch)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global578)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global171)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global167)
           )
          )
          (if (result i32)
           (i64.eqz
            (call $function59
             (struct.get $type27 0
              (local.get $5)
             )
             (struct.get $type27 0
              (local.get $6)
             )
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global171)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global167)
             )
            )
            (i64.eqz
             (call $function59
              (struct.get $type27 1
               (local.get $5)
              )
              (struct.get $type27 1
               (local.get $6)
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
     (else
      (if (result i32)
       (i32.eq
        (struct.get $type24 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (local.set $4
         (struct.get $type30 1
          (ref.cast (ref $type30)
           (local.get $0)
          )
         )
        )
        (if (result i32)
         (local.tee $2
          (struct.get $type24 0
           (local.get $1)
          )
         )
         (then
          (if (result i32)
           (i32.eq
            (local.get $2)
            (i32.const 1)
           )
           (then
            (drop
             (ref.cast (ref $type26)
              (local.get $1)
             )
            )
            (i32.const 0)
           )
           (else
            (if (result i32)
             (i32.eq
              (struct.get $type24 0
               (local.get $1)
              )
              (i32.const 3)
             )
             (then
              (drop
               (ref.cast (ref $type31)
                (local.get $1)
               )
              )
              (i32.const 0)
             )
             (else
              (i32.eq
               (call $foreign2
                (local.get $4)
                (struct.get $type30 1
                 (ref.cast (ref $type30)
                  (local.get $1)
                 )
                )
               )
               (i32.const 1)
              )
             )
            )
           )
          )
         )
         (else
          (drop
           (ref.cast (ref $type25)
            (local.get $1)
           )
          )
          (i32.const 0)
         )
        )
       )
       (else
        (local.set $7
         (struct.get $type31 1
          (local.tee $9
           (ref.cast (ref $type31)
            (local.get $0)
           )
          )
         )
        )
        (if (result i32)
         (local.tee $2
          (struct.get $type24 0
           (local.get $1)
          )
         )
         (then
          (if (result i32)
           (i32.eq
            (local.get $2)
            (i32.const 1)
           )
           (then
            (drop
             (ref.cast (ref $type26)
              (local.get $1)
             )
            )
            (i32.const 0)
           )
           (else
            (if (result i32)
             (i32.eq
              (struct.get $type24 0
               (local.get $1)
              )
              (i32.const 2)
             )
             (then
              (drop
               (ref.cast (ref $type30)
                (local.get $1)
               )
              )
              (i32.const 0)
             )
             (else
              (local.set $8
               (struct.get $type31 2
                (local.tee $10
                 (ref.cast (ref $type31)
                  (local.get $1)
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global809)
               )
              )
              (if (result i32)
               (call $function229
                (local.get $7)
                (struct.get $type31 1
                 (local.get $10)
                )
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global809)
                 )
                )
                (return_call $function229
                 (struct.get $type31 2
                  (local.get $9)
                 )
                 (local.get $8)
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (drop
           (ref.cast (ref $type25)
            (local.get $1)
           )
          )
          (i32.const 0)
         )
        )
       )
      )
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type25 1
      (ref.cast (ref $type25)
       (local.get $0)
      )
     )
    )
    (if (result i32)
     (local.tee $2
      (struct.get $type24 0
       (local.get $1)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 2)
       )
       (then
        (drop
         (ref.cast (ref $type30)
          (local.get $1)
         )
        )
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i32.eq
          (struct.get $type24 0
           (local.get $1)
          )
          (i32.const 3)
         )
         (then
          (drop
           (ref.cast (ref $type31)
            (local.get $1)
           )
          )
          (i32.const 0)
         )
         (else
          (local.set $5
           (struct.get $type26 1
            (ref.cast (ref $type26)
             (local.get $1)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global141)
           )
          )
          (if (result i32)
           (i64.eqz
            (call $function59
             (call $function53
              (local.get $3)
             )
             (block (result (ref $type28))
              (drop
               (ref.as_non_null
                (global.get $global547)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global578)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global171)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global167)
               )
              )
              (local.set $11
               (ref.as_non_null
                (global.get $global539)
               )
              )
              (struct.get $type27 0
               (local.get $5)
              )
             )
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global171)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global167)
             )
            )
            (i64.eqz
             (call $function59
              (local.get $11)
              (struct.get $type27 1
               (local.get $5)
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
       )
      )
     )
     (else
      (i64.eq
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $1)
        )
       )
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function231 (type $call72) (param $0 i64) (result i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (i64.const -10)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.gt_s
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 10)
       )
      )
      (i64.const -10)
     )
     (then
      (i64.const 2)
     )
     (else
      (if (result i64)
       (i64.gt_s
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 10)
         )
        )
        (i64.const -10)
       )
       (then
        (i64.const 3)
       )
       (else
        (if (result i64)
         (i64.gt_s
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 10)
           )
          )
          (i64.const -10)
         )
         (then
          (i64.const 4)
         )
         (else
          (if (result i64)
           (i64.gt_s
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 10)
             )
            )
            (i64.const -10)
           )
           (then
            (i64.const 5)
           )
           (else
            (if (result i64)
             (i64.gt_s
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 10)
               )
              )
              (i64.const -10)
             )
             (then
              (i64.const 6)
             )
             (else
              (if (result i64)
               (i64.gt_s
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 10)
                 )
                )
                (i64.const -10)
               )
               (then
                (i64.const 7)
               )
               (else
                (if (result i64)
                 (i64.gt_s
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 10)
                   )
                  )
                  (i64.const -10)
                 )
                 (then
                  (i64.const 8)
                 )
                 (else
                  (if (result i64)
                   (i64.gt_s
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 10)
                     )
                    )
                    (i64.const -10)
                   )
                   (then
                    (i64.const 9)
                   )
                   (else
                    (if (result i64)
                     (i64.gt_s
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 10)
                       )
                      )
                      (i64.const -10)
                     )
                     (then
                      (i64.const 10)
                     )
                     (else
                      (if (result i64)
                       (i64.gt_s
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 10)
                         )
                        )
                        (i64.const -10)
                       )
                       (then
                        (i64.const 11)
                       )
                       (else
                        (if (result i64)
                         (i64.gt_s
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 10)
                           )
                          )
                          (i64.const -10)
                         )
                         (then
                          (i64.const 12)
                         )
                         (else
                          (if (result i64)
                           (i64.gt_s
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 10)
                             )
                            )
                            (i64.const -10)
                           )
                           (then
                            (i64.const 13)
                           )
                           (else
                            (if (result i64)
                             (i64.gt_s
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 10)
                               )
                              )
                              (i64.const -10)
                             )
                             (then
                              (i64.const 14)
                             )
                             (else
                              (if (result i64)
                               (i64.gt_s
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 10)
                                 )
                                )
                                (i64.const -10)
                               )
                               (then
                                (i64.const 15)
                               )
                               (else
                                (if (result i64)
                                 (i64.gt_s
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 10)
                                   )
                                  )
                                  (i64.const -10)
                                 )
                                 (then
                                  (i64.const 16)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.gt_s
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 10)
                                     )
                                    )
                                    (i64.const -10)
                                   )
                                   (then
                                    (i64.const 17)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.gt_s
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 10)
                                       )
                                      )
                                      (i64.const -10)
                                     )
                                     (then
                                      (i64.const 18)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.gt_s
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 10)
                                         )
                                        )
                                        (i64.const -10)
                                       )
                                       (then
                                        (i64.const 19)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.gt_s
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 10)
                                           )
                                          )
                                          (i64.const -10)
                                         )
                                         (then
                                          (i64.const 20)
                                         )
                                         (else
                                          (return_call $function232
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 10)
                                           )
                                           (i64.const 21)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function232 (type $84) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (if (result i64)
   (i64.gt_s
    (local.get $2)
    (i64.const -10)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function232
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 10)
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function234 (type $15) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result (ref $type18))
  (local $5 i64)
  (local $6 i32)
  (if
   (i64.gt_u
    (local.tee $5
     (i64.sub
      (i64.const 48)
      (i64.rem_s
       (local.get $3)
       (i64.const 10)
      )
     )
    )
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $5)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $5)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $4)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type19
   (if (result (ref $type19))
    (i32.lt_u
     (local.tee $6
      (i32.wrap_i64
       (local.get $4)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type18 2
      (local.get $0)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type20
       (struct.get $type18 3
        (local.get $0)
       )
       (i32.sub
        (i32.shr_u
         (local.get $6)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $6)
    (i32.const 8191)
   )
   (i32.wrap_i64
    (local.get $5)
   )
  )
  (if (result (ref $type18))
   (i64.gt_s
    (local.get $3)
    (i64.const -10)
   )
   (then
    (local.get $0)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function234
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.div_s
      (local.get $3)
      (i64.const 10)
     )
     (i64.sub
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function236 (type $14) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (call $foreign6
     (local.get $0)
    )
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign5
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function236
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function237 (type $call144) (param $0 (ref $type32)) (result (ref $type18))
  (local $1 i64)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type27))
  (if (result (ref $type18))
   (local.tee $3
    (struct.get $type32 0
     (local.get $0)
    )
   )
   (then
    (if (result (ref $type18))
     (i32.eq
      (local.get $3)
      (i32.const 1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global600)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global411)
       )
      )
      (local.set $5
       (call $function117
        (struct.get $type27 0
         (local.tee $7
          (struct.get $type34 1
           (ref.cast (ref $type34)
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global549)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global171)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global167)
       )
      )
      (if (result (ref $type18))
       (i64.eqz
        (call $function59
         (struct.get $type27 1
          (local.get $7)
         )
         (ref.as_non_null
          (global.get $global539)
         )
        )
       )
       (then
        (local.get $5)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global411)
         )
        )
        (local.set $6
         (call $function117
          (struct.get $type27 1
           (local.get $7)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global88)
         )
        )
        (return_call $function35
         (struct.new $type61
          (local.get $5)
          (struct.new $type61
           (global.get $string0)
           (struct.new $type61
            (local.get $6)
            (ref.null none)
           )
          )
         )
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global865)
       )
      )
      (local.set $1
       (i64.extend_i32_s
        (call $foreign4
         (local.tee $3
          (call $foreign3
           (struct.get $type35 1
            (ref.cast (ref $type35)
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function236
       (local.get $3)
       (local.get $1)
       (call $string-new
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global856)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global851)
     )
    )
    (local.set $1
     (i64.add
      (call $function231
       (local.tee $2
        (select
         (local.tee $1
          (struct.get $type33 1
           (ref.cast (ref $type33)
            (local.get $0)
           )
          )
         )
         (i64.sub
          (i64.const 0)
          (local.get $1)
         )
         (local.tee $3
          (i64.lt_s
           (local.get $1)
           (i64.const 0)
          )
         )
        )
       )
      )
      (i64.extend_i32_u
       (local.get $3)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (call $string-new
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (local.get $3)
     (then
      (if
       (i32.ne
        (struct.get $type18 0
         (local.get $4)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $4)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type19
       (struct.get $type18 2
        (local.get $4)
       )
       (i32.const 0)
       (i32.const 45)
      )
     )
    )
    (return_call $function234
     (local.get $4)
     (i32.const 0)
     (i32.const 1)
     (local.get $2)
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function238 (type $call145) (param $0 (ref $type24)) (result (ref $type18))
  (local $1 i32)
  (local $2 (ref $type18))
  (local $3 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global650)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global872)
   )
  )
  (local.set $2
   (call $function237
    (if (result (ref $type32))
     (local.tee $1
      (struct.get $type24 0
       (local.get $0)
      )
     )
     (then
      (if (result (ref $type32))
       (i32.eq
        (local.get $1)
        (i32.const 1)
       )
       (then
        (struct.new $type34
         (i32.const 1)
         (struct.get $type26 1
          (ref.cast (ref $type26)
           (local.get $0)
          )
         )
        )
       )
       (else
        (if (result (ref $type32))
         (i32.eq
          (struct.get $type24 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (struct.new $type35
           (i32.const 2)
           (struct.get $type30 1
            (ref.cast (ref $type30)
             (local.get $0)
            )
           )
          )
         )
         (else
          (struct.get $type31 1
           (ref.cast (ref $type31)
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
     (else
      (struct.new $type33
       (i32.const 0)
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $0)
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global666)
   )
  )
  (if (result (ref $type18))
   (if (result i32)
    (local.tee $1
     (struct.get $type24 0
      (local.get $0)
     )
    )
    (then
     (if (result i32)
      (i32.eq
       (local.get $1)
       (i32.const 1)
      )
      (then
       (drop
        (ref.cast (ref $type26)
         (local.get $0)
        )
       )
       (i32.const 0)
      )
      (else
       (if (result i32)
        (i32.eq
         (struct.get $type24 0
          (local.get $0)
         )
         (i32.const 2)
        )
        (then
         (drop
          (ref.cast (ref $type30)
           (local.get $0)
          )
         )
         (i32.const 0)
        )
        (else
         (drop
          (ref.cast (ref $type31)
           (local.get $0)
          )
         )
         (i32.const 1)
        )
       )
      )
     )
    )
    (else
     (drop
      (ref.cast (ref $type25)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global658)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global872)
     )
    )
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.tee $3
         (call $function237
          (if (result (ref $type32))
           (local.tee $1
            (struct.get $type24 0
             (local.get $0)
            )
           )
           (then
            (if (result (ref $type32))
             (i32.eq
              (local.get $1)
              (i32.const 1)
             )
             (then
              (drop
               (ref.cast (ref $type26)
                (local.get $0)
               )
              )
              (struct.new_default $type33)
             )
             (else
              (if (result (ref $type32))
               (i32.eq
                (struct.get $type24 0
                 (local.get $0)
                )
                (i32.const 2)
               )
               (then
                (drop
                 (ref.cast (ref $type30)
                  (local.get $0)
                 )
                )
                (struct.new_default $type33)
               )
               (else
                (struct.get $type31 2
                 (ref.cast (ref $type31)
                  (local.get $0)
                 )
                )
               )
              )
             )
            )
           )
           (else
            (drop
             (ref.cast (ref $type25)
              (local.get $0)
             )
            )
            (struct.new_default $type33)
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global88)
     )
    )
    (return_call $function35
     (struct.new $type61
      (local.get $2)
      (struct.new $type61
       (select (result (ref $type18))
        (global.get $string4)
        (global.get $string3)
        (i32.or
         (i32.eq
          (local.tee $1
           (array.get $type19
            (struct.get $type18 2
             (local.get $3)
            )
            (i32.const 0)
           )
          )
          (i32.const 45)
         )
         (i32.eq
          (local.get $1)
          (i32.const 43)
         )
        )
       )
       (struct.new $type61
        (local.get $3)
        (struct.new $type61
         (global.get $string5)
         (ref.null none)
        )
       )
      )
     )
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function279 (type $call169) (param $0 (ref $type18)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local.set $1
   (call $foreign7)
  )
  (if (result i32)
   (i64.eqz
    (local.tee $2
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign8
     (local.get $1)
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 1)
     )
     (then
      (local.get $1)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign8
       (local.get $1)
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $2)
        (i64.const 2)
       )
       (then
        (local.get $1)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign8
         (local.get $1)
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $2)
          (i64.const 3)
         )
         (then
          (local.get $1)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign8
           (local.get $1)
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $2)
            (i64.const 4)
           )
           (then
            (local.get $1)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign8
             (local.get $1)
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $2)
              (i64.const 5)
             )
             (then
              (local.get $1)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign8
               (local.get $1)
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $2)
                (i64.const 6)
               )
               (then
                (local.get $1)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign8
                 (local.get $1)
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $2)
                  (i64.const 7)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign8
                   (local.get $1)
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $2)
                    (i64.const 8)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign8
                     (local.get $1)
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $2)
                      (i64.const 9)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign8
                       (local.get $1)
                       (array.get $type19
                        (struct.get $type18 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $2)
                        (i64.const 10)
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign8
                         (local.get $1)
                         (array.get $type19
                          (struct.get $type18 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $2)
                          (i64.const 11)
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type18 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign8
                           (local.get $1)
                           (array.get $type19
                            (struct.get $type18 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $2)
                            (i64.const 12)
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign8
                             (local.get $1)
                             (array.get $type19
                              (struct.get $type18 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $2)
                              (i64.const 13)
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type18 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign8
                               (local.get $1)
                               (array.get $type19
                                (struct.get $type18 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $2)
                                (i64.const 14)
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign8
                                 (local.get $1)
                                 (array.get $type19
                                  (struct.get $type18 2
                                   (local.get $0)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $2)
                                  (i64.const 15)
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type18 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $foreign8
                                   (local.get $1)
                                   (array.get $type19
                                    (struct.get $type18 2
                                     (local.get $0)
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $2)
                                    (i64.const 16)
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (call $foreign8
                                     (local.get $1)
                                     (array.get $type19
                                      (struct.get $type18 2
                                       (local.get $0)
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $2)
                                      (i64.const 17)
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type18 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call $foreign8
                                       (local.get $1)
                                       (array.get $type19
                                        (struct.get $type18 2
                                         (local.get $0)
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $2)
                                        (i64.const 18)
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (call $foreign8
                                         (local.get $1)
                                         (array.get $type19
                                          (struct.get $type18 2
                                           (local.get $0)
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $2)
                                          (i64.const 19)
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $0)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $foreign8
                                           (local.get $1)
                                           (array.get $type19
                                            (call $string-block
                                             (local.get $0)
                                             (i32.const 19)
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (return_call $function280
                                           (local.get $0)
                                           (local.get $1)
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function280 (type $10) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign8
     (local.get $1)
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function280
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function288 (type $9) (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref $type18)) (param $5 i32) (param $6 i32) (param $7 i64) (result (ref $type18))
  (local $8 i32)
  (local $9 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $3)
    (local.get $7)
   )
   (then
    (local.get $4)
   )
   (else
    (local.set $9
     (call $foreign16
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (i32.wrap_i64
       (local.get $7)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $4)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $7)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $8
        (i32.wrap_i64
         (local.get $7)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $4)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $4)
         )
         (i32.sub
          (i32.shr_u
           (local.get $8)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $8)
      (i32.const 8191)
     )
     (local.get $9)
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function288
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (i64.add
      (local.get $7)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function290 (type $call177) (param $0 i32) (param $1 i32) (param $2 i32) (result (ref $type32))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 (ref $type28))
  (local $7 (ref $type28))
  (local $8 (ref $type28))
  (local $9 (ref $type28))
  (local $10 (ref $type28))
  (local $11 (ref $type27))
  (local $12 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global1045)
   )
  )
  (local.set $12
   (call $function288
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (local.tee $3
     (i64.extend_i32_s
      (call $foreign15
       (local.get $0)
       (local.get $1)
       (i32.const 0)
      )
     )
    )
    (block (result (ref $type18))
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (if
      (i64.gt_u
       (local.get $3)
       (i64.const 4294967294)
      )
      (then
       (unreachable)
      )
     )
     (call $string-new
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1053)
   )
  )
  (local.set $4
   (i64.extend_i32_s
    (call $foreign17
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (local.set $3
   (call $foreign18
    (local.get $0)
    (local.get $1)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global371)
   )
  )
  (local.set $7
   (call $function106
    (local.get $12)
    (local.get $4)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1045)
   )
  )
  (local.set $8
   (call $function106
    (call $function288
     (local.get $0)
     (local.get $1)
     (i32.const 1)
     (local.tee $5
      (i64.extend_i32_s
       (call $foreign15
        (local.get $0)
        (local.get $1)
        (i32.const 1)
       )
      )
     )
     (block (result (ref $type18))
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-new
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
     (i32.const 0)
     (i32.const 1)
     (i64.const 0)
    )
    (block (result i64)
     (drop
      (ref.as_non_null
       (global.get $global371)
      )
     )
     (local.get $4)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (local.set $9
   (call $function53
    (i64.const 10)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global430)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (local.set $6
   (call $function53
    (select
     (i64.sub
      (i64.const 0)
      (local.get $3)
     )
     (local.get $3)
     (local.tee $0
      (i64.lt_s
       (local.get $3)
       (i64.const 0)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global421)
   )
  )
  (local.set $6
   (if (result (ref $type28))
    (struct.get $type28 0
     (local.get $6)
    )
    (then
     (unreachable)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global141)
      )
     )
     (call $function120
      (i32.const 0)
      (i32.const 1)
      (local.get $9)
      (local.get $6)
      (call $function53
       (i64.const 1)
      )
     )
    )
   )
  )
  (local.set $11
   (if (result (ref $type27))
    (local.get $0)
    (then
     (drop
      (ref.as_non_null
       (global.get $global236)
      )
     )
     (local.set $10
      (call $function77
       (local.get $8)
       (local.get $6)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global540)
      )
     )
     (call $function153
      (local.get $7)
      (local.get $10)
     )
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global236)
      )
     )
     (call $function153
      (call $function77
       (local.get $7)
       (local.get $6)
      )
      (block (result (ref $type28))
       (drop
        (ref.as_non_null
         (global.get $global540)
        )
       )
       (local.get $8)
      )
     )
    )
   )
  )
  (if (result (ref $type35))
   (i32.eq
    (local.get $2)
    (i32.const 5)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global606)
     )
    )
    (return_call $function177
     (local.get $11)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global551)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (struct.new $type35
     (i32.const 2)
     (if (result f64)
      (if (result i32)
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type28 1
           (struct.get $type27 0
            (local.get $11)
           )
          )
         )
        )
       )
       (then
        (if
         (i64.eqz
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $12)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (i32.eq
         (array.get $type19
          (struct.get $type18 2
           (local.get $12)
          )
          (i32.const 0)
         )
         (i32.const 45)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (f64.const -0.0)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global598)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global507)
        )
       )
       (call $function142
        (struct.get $type27 0
         (local.get $11)
        )
        (struct.get $type27 1
         (local.get $11)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function293 (type $14) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign23
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function293
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function296 (type $call185) (param $0 (ref $type18)) (param $1 i64) (result (ref $type181))
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 f64)
  (local $6 f64)
  (local $7 (ref $type32))
  (local $8 (ref $type32))
  (local $9 (ref $type27))
  (local $10 (ref $type181))
  (local $scratch (ref $type181))
  (if (result (ref $type181))
   (if (result i32)
    (i64.eq
     (local.get $1)
     (i64.const 2)
    )
    (then
     (i32.const 1)
    )
    (else
     (if (result i32)
      (i64.eq
       (local.get $1)
       (i64.const 8)
      )
      (then
       (i32.const 1)
      )
      (else
       (i32.or
        (i64.eq
         (local.get $1)
         (i64.const 16)
        )
        (i64.eq
         (local.get $1)
         (i64.const 10)
        )
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global1021)
     )
    )
    (local.set $2
     (call $foreign24
      (local.tee $3
       (call $function279
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global1083)
     )
    )
    (local.set $scratch
     (if (result (ref $type181))
      (local.get $2)
      (then
       (if (result (ref $type181))
        (i32.eq
         (local.get $2)
         (i32.const 4)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global1072)
          )
         )
         (drop
          (call $function293
           (local.get $3)
           (local.tee $1
            (i64.extend_i32_s
             (call $foreign22
              (local.get $3)
             )
            )
           )
           (block (result (ref $type18))
            (drop
             (ref.as_non_null
              (global.get $global61)
             )
            )
            (if
             (i64.gt_u
              (local.get $1)
              (i64.const 4294967294)
             )
             (then
              (unreachable)
             )
            )
            (call $string-new
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
           (i32.const 0)
           (i32.const 1)
           (i64.const 0)
          )
         )
         (struct.new $type184
          (i32.const 2)
         )
        )
        (else
         (if (result (ref $type181))
          (i32.eq
           (local.get $2)
           (i32.const 3)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global1068)
            )
           )
           (local.set $7
            (if (result (ref $type32))
             (i32.eq
              (local.tee $2
               (call $foreign19
                (local.get $3)
                (i32.const 0)
               )
              )
              (i32.const 1)
             )
             (then
              (struct.new $type33
               (i32.const 0)
               (call $foreign21
                (local.get $3)
                (i32.const 0)
               )
              )
             )
             (else
              (if (result (ref $type32))
               (i32.eq
                (local.get $2)
                (i32.const 2)
               )
               (then
                (struct.new $type35
                 (i32.const 2)
                 (call $foreign20
                  (local.get $3)
                  (i32.const 0)
                 )
                )
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global1062)
                 )
                )
                (call $function290
                 (local.get $3)
                 (i32.const 0)
                 (local.get $2)
                )
               )
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global1068)
            )
           )
           (local.set $8
            (if (result (ref $type32))
             (i32.eq
              (local.tee $2
               (call $foreign19
                (local.get $3)
                (i32.const 1)
               )
              )
              (i32.const 1)
             )
             (then
              (struct.new $type33
               (i32.const 0)
               (call $foreign21
                (local.get $3)
                (i32.const 1)
               )
              )
             )
             (else
              (if (result (ref $type32))
               (i32.eq
                (local.get $2)
                (i32.const 2)
               )
               (then
                (struct.new $type35
                 (i32.const 2)
                 (call $foreign20
                  (local.get $3)
                  (i32.const 1)
                 )
                )
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global1062)
                 )
                )
                (call $function290
                 (local.get $3)
                 (i32.const 1)
                 (local.get $2)
                )
               )
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global642)
            )
           )
           (struct.new $type183
            (i32.const 1)
            (call $function185
             (local.get $7)
             (local.get $8)
            )
           )
          )
          (else
           (if (result (ref $type181))
            (i32.or
             (i32.eq
              (local.get $2)
              (i32.const 8)
             )
             (i32.eq
              (local.get $2)
              (i32.const 7)
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global1078)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1068)
              )
             )
             (local.set $7
              (if (result (ref $type32))
               (i32.eq
                (local.tee $4
                 (call $foreign19
                  (local.get $3)
                  (i32.const 0)
                 )
                )
                (i32.const 1)
               )
               (then
                (struct.new $type33
                 (i32.const 0)
                 (call $foreign21
                  (local.get $3)
                  (i32.const 0)
                 )
                )
               )
               (else
                (if (result (ref $type32))
                 (i32.eq
                  (local.get $4)
                  (i32.const 2)
                 )
                 (then
                  (struct.new $type35
                   (i32.const 2)
                   (call $foreign20
                    (local.get $3)
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global1062)
                   )
                  )
                  (call $function290
                   (local.get $3)
                   (i32.const 0)
                   (local.get $4)
                  )
                 )
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1068)
              )
             )
             (local.set $8
              (if (result (ref $type32))
               (i32.eq
                (local.tee $4
                 (call $foreign19
                  (local.get $3)
                  (i32.const 1)
                 )
                )
                (i32.const 1)
               )
               (then
                (struct.new $type33
                 (i32.const 0)
                 (call $foreign21
                  (local.get $3)
                  (i32.const 1)
                 )
                )
               )
               (else
                (if (result (ref $type32))
                 (i32.eq
                  (local.get $4)
                  (i32.const 2)
                 )
                 (then
                  (struct.new $type35
                   (i32.const 2)
                   (call $foreign20
                    (local.get $3)
                    (i32.const 1)
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global1062)
                   )
                  )
                  (call $function290
                   (local.get $3)
                   (i32.const 1)
                   (local.get $4)
                  )
                 )
                )
               )
              )
             )
             (if (result (ref $type181))
              (if (result i32)
               (i32.eq
                (local.get $2)
                (i32.const 8)
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global618)
                 )
                )
                (i32.eqz
                 (if (result i32)
                  (if (result i32)
                   (if (result i32)
                    (local.tee $2
                     (struct.get $type32 0
                      (local.get $7)
                     )
                    )
                    (then
                     (if (result i32)
                      (i32.eq
                       (local.get $2)
                       (i32.const 1)
                      )
                      (then
                       (drop
                        (ref.cast (ref $type34)
                         (local.get $7)
                        )
                       )
                       (i32.const 1)
                      )
                      (else
                       (drop
                        (ref.cast (ref $type35)
                         (local.get $7)
                        )
                       )
                       (i32.const 0)
                      )
                     )
                    )
                    (else
                     (drop
                      (ref.cast (ref $type33)
                       (local.get $7)
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global624)
                     )
                    )
                    (if (result i32)
                     (local.tee $2
                      (struct.get $type32 0
                       (local.get $7)
                      )
                     )
                     (then
                      (if (result i32)
                       (i32.eq
                        (local.get $2)
                        (i32.const 1)
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global551)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global130)
                         )
                        )
                        (i64.eqz
                         (i64.extend_i32_u
                          (array.len
                           (struct.get $type28 1
                            (struct.get $type27 0
                             (struct.get $type34 1
                              (ref.cast (ref $type34)
                               (local.get $7)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                       (else
                        (f64.eq
                         (struct.get $type35 1
                          (ref.cast (ref $type35)
                           (local.get $7)
                          )
                         )
                         (f64.const 0.0)
                        )
                       )
                      )
                     )
                     (else
                      (i64.eqz
                       (struct.get $type33 1
                        (ref.cast (ref $type33)
                         (local.get $7)
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                  (then
                   (i32.const 1)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global618)
                    )
                   )
                   (if (result i32)
                    (if (result i32)
                     (local.tee $2
                      (struct.get $type32 0
                       (local.get $8)
                      )
                     )
                     (then
                      (if (result i32)
                       (i32.eq
                        (local.get $2)
                        (i32.const 1)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type34)
                          (local.get $8)
                         )
                        )
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.cast (ref $type35)
                          (local.get $8)
                         )
                        )
                        (i32.const 0)
                       )
                      )
                     )
                     (else
                      (drop
                       (ref.cast (ref $type33)
                        (local.get $8)
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (then
                     (drop
                      (ref.as_non_null
                       (global.get $global624)
                      )
                     )
                     (if (result i32)
                      (local.tee $2
                       (struct.get $type32 0
                        (local.get $8)
                       )
                      )
                      (then
                       (if (result i32)
                        (i32.eq
                         (local.get $2)
                         (i32.const 1)
                        )
                        (then
                         (drop
                          (ref.as_non_null
                           (global.get $global551)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global130)
                          )
                         )
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (struct.get $type28 1
                             (struct.get $type27 0
                              (struct.get $type34 1
                               (ref.cast (ref $type34)
                                (local.get $8)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (f64.eq
                          (struct.get $type35 1
                           (ref.cast (ref $type35)
                            (local.get $8)
                           )
                          )
                          (f64.const 0.0)
                         )
                        )
                       )
                      )
                      (else
                       (i64.eqz
                        (struct.get $type33 1
                         (ref.cast (ref $type33)
                          (local.get $8)
                         )
                        )
                       )
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
              (then
               (struct.new $type184
                (i32.const 2)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global645)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global618)
                )
               )
               (struct.new $type183
                (i32.const 1)
                (if (result (ref $type24))
                 (if (result i32)
                  (if (result i32)
                   (local.tee $2
                    (struct.get $type32 0
                     (local.get $7)
                    )
                   )
                   (then
                    (if (result i32)
                     (i32.eq
                      (local.get $2)
                      (i32.const 1)
                     )
                     (then
                      (drop
                       (ref.cast (ref $type34)
                        (local.get $7)
                       )
                      )
                      (i32.const 1)
                     )
                     (else
                      (drop
                       (ref.cast (ref $type35)
                        (local.get $7)
                       )
                      )
                      (i32.const 0)
                     )
                    )
                   )
                   (else
                    (drop
                     (ref.cast (ref $type33)
                      (local.get $7)
                     )
                    )
                    (i32.const 1)
                   )
                  )
                  (then
                   (drop
                    (ref.as_non_null
                     (global.get $global624)
                    )
                   )
                   (if (result i32)
                    (local.tee $2
                     (struct.get $type32 0
                      (local.get $7)
                     )
                    )
                    (then
                     (if (result i32)
                      (i32.eq
                       (local.get $2)
                       (i32.const 1)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global551)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global130)
                        )
                       )
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (struct.get $type28 1
                           (struct.get $type27 0
                            (struct.get $type34 1
                             (ref.cast (ref $type34)
                              (local.get $7)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                      (else
                       (f64.eq
                        (struct.get $type35 1
                         (ref.cast (ref $type35)
                          (local.get $7)
                         )
                        )
                        (f64.const 0.0)
                       )
                      )
                     )
                    )
                    (else
                     (i64.eqz
                      (struct.get $type33 1
                       (ref.cast (ref $type33)
                        (local.get $7)
                       )
                      )
                     )
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                 (then
                  (struct.new_default $type25)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global618)
                   )
                  )
                  (if (result (ref $type24))
                   (if (result i32)
                    (if (result i32)
                     (local.tee $2
                      (struct.get $type32 0
                       (local.get $8)
                      )
                     )
                     (then
                      (if (result i32)
                       (i32.eq
                        (local.get $2)
                        (i32.const 1)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type34)
                          (local.get $8)
                         )
                        )
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.cast (ref $type35)
                          (local.get $8)
                         )
                        )
                        (i32.const 0)
                       )
                      )
                     )
                     (else
                      (drop
                       (ref.cast (ref $type33)
                        (local.get $8)
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (then
                     (drop
                      (ref.as_non_null
                       (global.get $global624)
                      )
                     )
                     (if (result i32)
                      (local.tee $2
                       (struct.get $type32 0
                        (local.get $8)
                       )
                      )
                      (then
                       (if (result i32)
                        (i32.eq
                         (local.get $2)
                         (i32.const 1)
                        )
                        (then
                         (drop
                          (ref.as_non_null
                           (global.get $global551)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global130)
                          )
                         )
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (struct.get $type28 1
                             (struct.get $type27 0
                              (struct.get $type34 1
                               (ref.cast (ref $type34)
                                (local.get $8)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (f64.eq
                          (struct.get $type35 1
                           (ref.cast (ref $type35)
                            (local.get $8)
                           )
                          )
                          (f64.const 0.0)
                         )
                        )
                       )
                      )
                      (else
                       (i64.eqz
                        (struct.get $type33 1
                         (ref.cast (ref $type33)
                          (local.get $8)
                         )
                        )
                       )
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global608)
                     )
                    )
                    (if (result (ref $type24))
                     (local.tee $2
                      (struct.get $type32 0
                       (local.get $7)
                      )
                     )
                     (then
                      (if (result (ref $type24))
                       (i32.eq
                        (local.get $2)
                        (i32.const 1)
                       )
                       (then
                        (struct.new $type26
                         (i32.const 1)
                         (struct.get $type34 1
                          (ref.cast (ref $type34)
                           (local.get $7)
                          )
                         )
                        )
                       )
                       (else
                        (struct.new $type30
                         (i32.const 2)
                         (struct.get $type35 1
                          (ref.cast (ref $type35)
                           (local.get $7)
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (struct.new $type25
                       (i32.const 0)
                       (struct.get $type33 1
                        (ref.cast (ref $type33)
                         (local.get $7)
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global630)
                     )
                    )
                    (struct.new $type31
                     (i32.const 3)
                     (struct.new $type35
                      (i32.const 2)
                      (f64.mul
                       (local.tee $5
                        (if (result f64)
                         (local.tee $2
                          (struct.get $type32 0
                           (local.get $7)
                          )
                         )
                         (then
                          (if (result f64)
                           (i32.eq
                            (local.get $2)
                            (i32.const 1)
                           )
                           (then
                            (drop
                             (ref.as_non_null
                              (global.get $global598)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global507)
                             )
                            )
                            (call $function142
                             (struct.get $type27 0
                              (local.tee $9
                               (struct.get $type34 1
                                (ref.cast (ref $type34)
                                 (local.get $7)
                                )
                               )
                              )
                             )
                             (struct.get $type27 1
                              (local.get $9)
                             )
                            )
                           )
                           (else
                            (struct.get $type35 1
                             (ref.cast (ref $type35)
                              (local.get $7)
                             )
                            )
                           )
                          )
                         )
                         (else
                          (f64.convert_i64_s
                           (struct.get $type33 1
                            (ref.cast (ref $type33)
                             (local.get $7)
                            )
                           )
                          )
                         )
                        )
                       )
                       (block (result f64)
                        (drop
                         (ref.as_non_null
                          (global.get $global630)
                         )
                        )
                        (call $foreign0
                         (local.tee $6
                          (if (result f64)
                           (local.tee $2
                            (struct.get $type32 0
                             (local.get $8)
                            )
                           )
                           (then
                            (if (result f64)
                             (i32.eq
                              (local.get $2)
                              (i32.const 1)
                             )
                             (then
                              (drop
                               (ref.as_non_null
                                (global.get $global598)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global507)
                               )
                              )
                              (call $function142
                               (struct.get $type27 0
                                (local.tee $9
                                 (struct.get $type34 1
                                  (ref.cast (ref $type34)
                                   (local.get $8)
                                  )
                                 )
                                )
                               )
                               (struct.get $type27 1
                                (local.get $9)
                               )
                              )
                             )
                             (else
                              (struct.get $type35 1
                               (ref.cast (ref $type35)
                                (local.get $8)
                               )
                              )
                             )
                            )
                           )
                           (else
                            (f64.convert_i64_s
                             (struct.get $type33 1
                              (ref.cast (ref $type33)
                               (local.get $8)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (struct.new $type35
                      (i32.const 2)
                      (f64.mul
                       (local.get $5)
                       (call $foreign1
                        (local.get $6)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global1068)
              )
             )
             (local.set $7
              (if (result (ref $type32))
               (i32.eq
                (local.tee $2
                 (call $foreign19
                  (local.get $3)
                  (i32.const 0)
                 )
                )
                (i32.const 1)
               )
               (then
                (struct.new $type33
                 (i32.const 0)
                 (call $foreign21
                  (local.get $3)
                  (i32.const 0)
                 )
                )
               )
               (else
                (if (result (ref $type32))
                 (i32.eq
                  (local.get $2)
                  (i32.const 2)
                 )
                 (then
                  (struct.new $type35
                   (i32.const 2)
                   (call $foreign20
                    (local.get $3)
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global1062)
                   )
                  )
                  (call $function290
                   (local.get $3)
                   (i32.const 0)
                   (local.get $2)
                  )
                 )
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global608)
              )
             )
             (struct.new $type183
              (i32.const 1)
              (if (result (ref $type24))
               (local.tee $2
                (struct.get $type32 0
                 (local.get $7)
                )
               )
               (then
                (if (result (ref $type24))
                 (i32.eq
                  (local.get $2)
                  (i32.const 1)
                 )
                 (then
                  (struct.new $type26
                   (i32.const 1)
                   (struct.get $type34 1
                    (ref.cast (ref $type34)
                     (local.get $7)
                    )
                   )
                  )
                 )
                 (else
                  (struct.new $type30
                   (i32.const 2)
                   (struct.get $type35 1
                    (ref.cast (ref $type35)
                     (local.get $7)
                    )
                   )
                  )
                 )
                )
               )
               (else
                (struct.new $type25
                 (i32.const 0)
                 (struct.get $type33 1
                  (ref.cast (ref $type33)
                   (local.get $7)
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (else
       (global.get $empty182)
      )
     )
    )
    (call $foreign6
     (local.get $3)
    )
    (local.get $scratch)
   )
   (else
    (struct.new $type184
     (i32.const 2)
    )
   )
  )
 )
 (func $function382 (type $14) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign27
      (local.get $0)
      (local.get $5)
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function382
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function383 (type $call224) (param $0 (ref $type18)) (result i32)
  (if (result i32)
   (i64.eqz
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign28
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign28
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign28
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign28
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign28
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign28
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign28
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign28
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign28
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign28
                       (array.get $type19
                        (struct.get $type18 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign28
                         (array.get $type19
                          (struct.get $type18 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (local.get $0)
                           )
                          )
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type18 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign28
                           (array.get $type19
                            (struct.get $type18 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (struct.get $type18 1
                              (local.get $0)
                             )
                            )
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign28
                             (array.get $type19
                              (struct.get $type18 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.get $0)
                               )
                              )
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type18 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign28
                               (array.get $type19
                                (struct.get $type18 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (struct.get $type18 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign28
                                 (array.get $type19
                                  (struct.get $type18 2
                                   (local.get $0)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 15)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type18 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $foreign28
                                   (array.get $type19
                                    (struct.get $type18 2
                                     (local.get $0)
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (struct.get $type18 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 16)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (call $foreign28
                                     (array.get $type19
                                      (struct.get $type18 2
                                       (local.get $0)
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 17)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type18 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call $foreign28
                                       (array.get $type19
                                        (struct.get $type18 2
                                         (local.get $0)
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (i64.extend_i32_u
                                         (struct.get $type18 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 18)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (call $foreign28
                                         (array.get $type19
                                          (struct.get $type18 2
                                           (local.get $0)
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 19)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $0)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $foreign28
                                           (array.get $type19
                                            (call $string-block
                                             (local.get $0)
                                             (i32.const 19)
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (return_call $function384
                                           (local.get $0)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function384 (type $3) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign28
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $4
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (i32.and
       (local.get $4)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function384
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (param $1 f64) (result f64)
  (local $2 (ref $type32))
  (local $3 (ref $type32))
  (local $4 (ref $type32))
  (local $5 (ref $type32))
  (local $6 (ref $type32))
  (local $7 (ref $type24))
  (local $8 (ref $type24))
  (local $9 (ref $type28))
  (local $10 (ref $type28))
  (local $11 (ref $type27))
  (local $12 (ref null $type181))
  (local $13 (ref $type18))
  (local $14 (ref $type18))
  (local $15 (ref $type29))
  (local $16 (ref $type181))
  (local $17 i32)
  (local $18 i64)
  (local $scratch (ref $type24))
  (local $scratch_20 (ref $type27))
  (local $scratch_21 (ref $type27))
  (local $scratch_22 (ref $type32))
  (local $scratch_23 (ref $type18))
  (local $scratch_24 (ref $type28))
  (local $scratch_25 (ref $type32))
  (local $scratch_26 (ref $type32))
  (local $scratch_27 (ref $type32))
  (local $scratch_28 (ref $type32))
  (local $scratch_29 (ref $type28))
  (local $scratch_30 (ref $type28))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready1452)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global1452)
   )
  )
  (block $block1 (result f64)
   (block $block
    (br $block1
     (if (result f64)
      (if (result i32)
       (i64.eq
        (local.get $0)
        (i64.const 6)
       )
       (then
        (i32.const 1)
       )
       (else
        (i32.and
         (i64.le_s
          (local.get $0)
          (i64.const 15)
         )
         (i64.ge_s
          (local.get $0)
          (i64.const 13)
         )
        )
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global1455)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1435)
        )
       )
       (br_if $block
        (i32.ne
         (struct.get $type181 0
          (local.tee $12
           (call $function296
            (call $function382
             (i32.const 0)
             (local.tee $18
              (call $foreign26
               (i32.const 0)
              )
             )
             (block (result (ref $type18))
              (drop
               (ref.as_non_null
                (global.get $global61)
               )
              )
              (if
               (i64.gt_u
                (local.get $18)
                (i64.const 4294967294)
               )
               (then
                (unreachable)
               )
              )
              (call $string-new
               (i32.wrap_i64
                (local.get $18)
               )
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
            )
            (block (result i64)
             (drop
              (ref.as_non_null
               (global.get $global1445)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1092)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global1086)
              )
             )
             (i64.const 10)
            )
           )
          )
         )
         (i32.const 1)
        )
       )
       (local.set $7
        (struct.get $type183 1
         (ref.cast (ref $type183)
          (local.get $12)
         )
        )
       )
       (if (result f64)
        (i64.eq
         (local.get $0)
         (i64.const 6)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global716)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global666)
          )
         )
         (local.set $2
          (call $function190
           (block (result (ref $type24))
            (local.set $scratch
             (if (result (ref $type24))
              (if (result i32)
               (local.tee $17
                (struct.get $type24 0
                 (local.get $7)
                )
               )
               (then
                (if (result i32)
                 (i32.eq
                  (local.get $17)
                  (i32.const 1)
                 )
                 (then
                  (drop
                   (ref.cast (ref $type26)
                    (local.get $7)
                   )
                  )
                  (i32.const 0)
                 )
                 (else
                  (if (result i32)
                   (i32.eq
                    (struct.get $type24 0
                     (local.get $7)
                    )
                    (i32.const 2)
                   )
                   (then
                    (drop
                     (ref.cast (ref $type30)
                      (local.get $7)
                     )
                    )
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (ref.cast (ref $type31)
                      (local.get $7)
                     )
                    )
                    (i32.const 1)
                   )
                  )
                 )
                )
               )
               (else
                (drop
                 (ref.cast (ref $type25)
                  (local.get $7)
                 )
                )
                (i32.const 0)
               )
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global650)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global630)
                )
               )
               (local.set $1
                (if (result f64)
                 (local.tee $17
                  (struct.get $type32 0
                   (local.tee $2
                    (if (result (ref $type32))
                     (local.tee $17
                      (struct.get $type24 0
                       (local.get $7)
                      )
                     )
                     (then
                      (if (result (ref $type32))
                       (i32.eq
                        (local.get $17)
                        (i32.const 1)
                       )
                       (then
                        (struct.new $type34
                         (i32.const 1)
                         (struct.get $type26 1
                          (ref.cast (ref $type26)
                           (local.get $7)
                          )
                         )
                        )
                       )
                       (else
                        (if (result (ref $type32))
                         (i32.eq
                          (struct.get $type24 0
                           (local.get $7)
                          )
                          (i32.const 2)
                         )
                         (then
                          (struct.new $type35
                           (i32.const 2)
                           (struct.get $type30 1
                            (ref.cast (ref $type30)
                             (local.get $7)
                            )
                           )
                          )
                         )
                         (else
                          (struct.get $type31 1
                           (ref.cast (ref $type31)
                            (local.get $7)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (struct.new $type33
                       (i32.const 0)
                       (struct.get $type25 1
                        (ref.cast (ref $type25)
                         (local.get $7)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (then
                  (if (result f64)
                   (i32.eq
                    (local.get $17)
                    (i32.const 1)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global598)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global507)
                     )
                    )
                    (call $function142
                     (struct.get $type27 0
                      (local.tee $11
                       (struct.get $type34 1
                        (ref.cast (ref $type34)
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (struct.get $type27 1
                      (local.get $11)
                     )
                    )
                   )
                   (else
                    (struct.get $type35 1
                     (ref.cast (ref $type35)
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                 (else
                  (f64.convert_i64_s
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (local.get $2)
                    )
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global658)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global630)
                )
               )
               (struct.new $type31
                (i32.const 3)
                (struct.new $type35
                 (i32.const 2)
                 (local.get $1)
                )
                (struct.new $type35
                 (i32.const 2)
                 (if (result f64)
                  (local.tee $17
                   (struct.get $type32 0
                    (local.tee $2
                     (if (result (ref $type32))
                      (local.tee $17
                       (struct.get $type24 0
                        (local.get $7)
                       )
                      )
                      (then
                       (if (result (ref $type32))
                        (i32.eq
                         (local.get $17)
                         (i32.const 1)
                        )
                        (then
                         (drop
                          (ref.cast (ref $type26)
                           (local.get $7)
                          )
                         )
                         (struct.new_default $type33)
                        )
                        (else
                         (if (result (ref $type32))
                          (i32.eq
                           (struct.get $type24 0
                            (local.get $7)
                           )
                           (i32.const 2)
                          )
                          (then
                           (drop
                            (ref.cast (ref $type30)
                             (local.get $7)
                            )
                           )
                           (struct.new_default $type33)
                          )
                          (else
                           (struct.get $type31 2
                            (ref.cast (ref $type31)
                             (local.get $7)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                      (else
                       (drop
                        (ref.cast (ref $type25)
                         (local.get $7)
                        )
                       )
                       (struct.new_default $type33)
                      )
                     )
                    )
                   )
                  )
                  (then
                   (if (result f64)
                    (i32.eq
                     (local.get $17)
                     (i32.const 1)
                    )
                    (then
                     (drop
                      (ref.as_non_null
                       (global.get $global598)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global507)
                      )
                     )
                     (call $function142
                      (struct.get $type27 0
                       (local.tee $11
                        (struct.get $type34 1
                         (ref.cast (ref $type34)
                          (local.get $2)
                         )
                        )
                       )
                      )
                      (struct.get $type27 1
                       (local.get $11)
                      )
                     )
                    )
                    (else
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (local.get $2)
                      )
                     )
                    )
                   )
                  )
                  (else
                   (f64.convert_i64_s
                    (struct.get $type33 1
                     (ref.cast (ref $type33)
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global680)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global674)
                )
               )
               (local.set $2
                (call $function190
                 (local.get $7)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global630)
                )
               )
               (struct.new $type30
                (i32.const 2)
                (if (result f64)
                 (local.tee $17
                  (struct.get $type32 0
                   (local.get $2)
                  )
                 )
                 (then
                  (if (result f64)
                   (i32.eq
                    (local.get $17)
                    (i32.const 1)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global598)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global507)
                     )
                    )
                    (call $function142
                     (struct.get $type27 0
                      (local.tee $11
                       (struct.get $type34 1
                        (ref.cast (ref $type34)
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (struct.get $type27 1
                      (local.get $11)
                     )
                    )
                   )
                   (else
                    (struct.get $type35 1
                     (ref.cast (ref $type35)
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                 (else
                  (f64.convert_i64_s
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (local.get $2)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global680)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global674)
             )
            )
            (local.get $scratch)
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global630)
          )
         )
         (br $block1
          (if (result f64)
           (local.tee $17
            (struct.get $type32 0
             (local.get $2)
            )
           )
           (then
            (if (result f64)
             (i32.eq
              (local.get $17)
              (i32.const 1)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global598)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global507)
               )
              )
              (return_call $function142
               (struct.get $type27 0
                (local.tee $11
                 (struct.get $type34 1
                  (ref.cast (ref $type34)
                   (local.get $2)
                  )
                 )
                )
               )
               (struct.get $type27 1
                (local.get $11)
               )
              )
             )
             (else
              (struct.get $type35 1
               (ref.cast (ref $type35)
                (local.get $2)
               )
              )
             )
            )
           )
           (else
            (f64.convert_i64_s
             (struct.get $type33 1
              (ref.cast (ref $type33)
               (local.get $2)
              )
             )
            )
           )
          )
         )
        )
        (else
         (if (result f64)
          (i64.eq
           (local.get $0)
           (i64.const 14)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global1450)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global704)
            )
           )
           (f64.convert_i64_s
            (i64.add
             (i64.extend_i32_u
              (i32.ne
               (call $function200
                (local.get $7)
               )
               (i32.const 0)
              )
             )
             (block (result i64)
              (drop
               (ref.as_non_null
                (global.get $global702)
               )
              )
              (i64.add
               (select
                (i64.const 2)
                (i64.const 0)
                (call $function199
                 (local.get $7)
                )
               )
               (block (result i64)
                (drop
                 (ref.as_non_null
                  (global.get $global706)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global702)
                 )
                )
                (i64.add
                 (select
                  (i64.const 4)
                  (i64.const 0)
                  (if (result i32)
                   (call $function199
                    (local.get $7)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global650)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global690)
                     )
                    )
                    (if (result i32)
                     (local.tee $17
                      (struct.get $type32 0
                       (local.tee $2
                        (if (result (ref $type32))
                         (local.tee $17
                          (struct.get $type24 0
                           (local.get $7)
                          )
                         )
                         (then
                          (if (result (ref $type32))
                           (i32.eq
                            (local.get $17)
                            (i32.const 1)
                           )
                           (then
                            (struct.new $type34
                             (i32.const 1)
                             (struct.get $type26 1
                              (ref.cast (ref $type26)
                               (local.get $7)
                              )
                             )
                            )
                           )
                           (else
                            (if (result (ref $type32))
                             (i32.eq
                              (struct.get $type24 0
                               (local.get $7)
                              )
                              (i32.const 2)
                             )
                             (then
                              (struct.new $type35
                               (i32.const 2)
                               (struct.get $type30 1
                                (ref.cast (ref $type30)
                                 (local.get $7)
                                )
                               )
                              )
                             )
                             (else
                              (struct.get $type31 1
                               (ref.cast (ref $type31)
                                (local.get $7)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (struct.new $type33
                           (i32.const 0)
                           (struct.get $type25 1
                            (ref.cast (ref $type25)
                             (local.get $7)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (then
                      (if (result i32)
                       (i32.eq
                        (local.get $17)
                        (i32.const 1)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type34)
                          (local.get $2)
                         )
                        )
                        (i32.const 1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global688)
                         )
                        )
                        (if (result i32)
                         (f64.eq
                          (local.tee $1
                           (struct.get $type35 1
                            (ref.cast (ref $type35)
                             (local.get $2)
                            )
                           )
                          )
                          (local.get $1)
                         )
                         (then
                          (i32.and
                           (f64.lt
                            (local.get $1)
                            (f64.const inf)
                           )
                           (f64.gt
                            (local.get $1)
                            (f64.const -inf)
                           )
                          )
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                       )
                      )
                     )
                     (else
                      (drop
                       (ref.cast (ref $type33)
                        (local.get $2)
                       )
                      )
                      (i32.const 1)
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (block (result i64)
                  (drop
                   (ref.as_non_null
                    (global.get $global708)
                   )
                  )
                  (i64.add
                   (select
                    (i64.const 8)
                    (i64.const 0)
                    (call $function202
                     (local.get $7)
                    )
                   )
                   (block (result i64)
                    (drop
                     (ref.as_non_null
                      (global.get $global710)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global704)
                     )
                    )
                    (select
                     (i64.const 16)
                     (i64.const 0)
                     (if (result i32)
                      (call $function200
                       (local.get $7)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global708)
                        )
                       )
                       (call $function202
                        (local.get $7)
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global1435)
            )
           )
           (br_if $block
            (i32.ne
             (struct.get $type181 0
              (local.tee $12
               (call $function296
                (call $function382
                 (i32.const 1)
                 (local.tee $18
                  (call $foreign26
                   (i32.const 1)
                  )
                 )
                 (block (result (ref $type18))
                  (drop
                   (ref.as_non_null
                    (global.get $global61)
                   )
                  )
                  (if
                   (i64.gt_u
                    (local.get $18)
                    (i64.const 4294967294)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $string-new
                   (i32.wrap_i64
                    (local.get $18)
                   )
                  )
                 )
                 (i32.const 0)
                 (i32.const 1)
                 (i64.const 0)
                )
                (block (result i64)
                 (drop
                  (ref.as_non_null
                   (global.get $global1445)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1092)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global1086)
                  )
                 )
                 (i64.const 10)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (local.set $8
            (struct.get $type183 1
             (ref.cast (ref $type183)
              (local.get $12)
             )
            )
           )
           (if (result f64)
            (i64.eq
             (local.get $0)
             (i64.const 13)
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global1459)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global784)
              )
             )
             (f64.convert_i64_s
              (i64.add
               (i64.extend_i32_u
                (i32.ne
                 (call $function222
                  (local.get $7)
                  (local.get $8)
                 )
                 (i32.const 0)
                )
               )
               (block (result i64)
                (drop
                 (ref.as_non_null
                  (global.get $global787)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global674)
                 )
                )
                (local.set $2
                 (call $function190
                  (local.get $7)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global674)
                 )
                )
                (local.set $3
                 (call $function190
                  (local.get $8)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global779)
                 )
                )
                (i64.add
                 (select
                  (i64.const 2)
                  (i64.const 0)
                  (i64.eq
                   (call $function221
                    (local.get $2)
                    (local.get $3)
                   )
                   (i64.const -1)
                  )
                 )
                 (block (result i64)
                  (drop
                   (ref.as_non_null
                    (global.get $global793)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global674)
                   )
                  )
                  (local.set $2
                   (call $function190
                    (local.get $7)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global674)
                   )
                  )
                  (local.set $3
                   (call $function190
                    (local.get $8)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global779)
                   )
                  )
                  (i64.add
                   (select
                    (i64.const 4)
                    (i64.const 0)
                    (i64.eqz
                     (if (result i64)
                      (i64.eq
                       (local.tee $0
                        (call $function221
                         (local.get $2)
                         (local.get $3)
                        )
                       )
                       (i64.const -1)
                      )
                      (then
                       (i64.const 0)
                      )
                      (else
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (block (result i64)
                    (drop
                     (ref.as_non_null
                      (global.get $global790)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global674)
                     )
                    )
                    (local.set $2
                     (call $function190
                      (local.get $7)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global674)
                     )
                    )
                    (local.set $3
                     (call $function190
                      (local.get $8)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global779)
                     )
                    )
                    (i64.add
                     (select
                      (i64.const 8)
                      (i64.const 0)
                      (i64.eq
                       (call $function221
                        (local.get $2)
                        (local.get $3)
                       )
                       (i64.const 1)
                      )
                     )
                     (block (result i64)
                      (drop
                       (ref.as_non_null
                        (global.get $global797)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global674)
                       )
                      )
                      (local.set $2
                       (call $function190
                        (local.get $7)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global674)
                       )
                      )
                      (local.set $3
                       (call $function190
                        (local.get $8)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global779)
                       )
                      )
                      (select
                       (i64.const 16)
                       (i64.const 0)
                       (i64.eqz
                        (if (result i64)
                         (i64.eq
                          (local.tee $0
                           (call $function221
                            (local.get $2)
                            (local.get $3)
                           )
                          )
                          (i64.const 1)
                         )
                         (then
                          (i64.const 0)
                         )
                         (else
                          (local.get $0)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global824)
              )
             )
             (select
              (f64.const 1.0)
              (f64.const 0.0)
              (call $function230
               (local.get $7)
               (local.get $8)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global1463)
        )
       )
       (local.set $7
        (if (result (ref $type24))
         (i64.eq
          (local.get $0)
          (i64.const 5)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global714)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global650)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global636)
           )
          )
          (call $function185
           (call $function177
            (block (result (ref $type27))
             (local.set $scratch_20
              (call $function184
               (struct.new $type35
                (i32.const 2)
                (local.get $1)
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global606)
              )
             )
             (local.get $scratch_20)
            )
           )
           (block (result (ref $type32))
            (drop
             (ref.as_non_null
              (global.get $global658)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global636)
             )
            )
            (local.set $scratch_22
             (call $function177
              (block (result (ref $type27))
               (local.set $scratch_21
                (call $function184
                 (struct.new_default $type33)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global606)
                )
               )
               (local.get $scratch_21)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global642)
             )
            )
            (local.get $scratch_22)
           )
          )
         )
         (else
          (if (result (ref $type24))
           (i64.ge_s
            (local.get $0)
            (i64.const 19)
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global1466)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1435)
             )
            )
            (local.set $13
             (call $function382
              (i32.const 0)
              (local.tee $18
               (call $foreign26
                (i32.const 0)
               )
              )
              (block (result (ref $type18))
               (drop
                (ref.as_non_null
                 (global.get $global61)
                )
               )
               (if
                (i64.gt_u
                 (local.get $18)
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
               )
               (call $string-new
                (i32.wrap_i64
                 (local.get $18)
                )
               )
              )
              (i32.const 0)
              (i32.const 1)
              (i64.const 0)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global1435)
             )
            )
            (local.set $9
             (call $function102
              (block (result (ref $type18))
               (local.set $scratch_23
                (call $function382
                 (i32.const 1)
                 (local.tee $18
                  (call $foreign26
                   (i32.const 1)
                  )
                 )
                 (block (result (ref $type18))
                  (drop
                   (ref.as_non_null
                    (global.get $global61)
                   )
                  )
                  (if
                   (i64.gt_u
                    (local.get $18)
                    (i64.const 4294967294)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $string-new
                   (i32.wrap_i64
                    (local.get $18)
                   )
                  )
                 )
                 (i32.const 0)
                 (i32.const 1)
                 (i64.const 0)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global353)
                )
               )
               (local.get $scratch_23)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global149)
             )
            )
            (local.set $18
             (call $function56
              (local.tee $15
               (struct.get $type28 1
                (local.get $9)
               )
              )
              (local.tee $17
               (struct.get $type28 0
                (local.get $9)
               )
              )
              (select
               (i64.const -9223372036854775808)
               (i64.const -9223372036854775807)
               (local.get $17)
              )
              (i32.const 0)
              (i32.const 1)
              (i64.extend_i32_u
               (array.len
                (local.get $15)
               )
              )
              (i64.const 0)
             )
            )
            (if (result (ref $type24))
             (i64.eq
              (local.get $0)
              (i64.const 19)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global1086)
               )
              )
              (if
               (i32.ne
                (struct.get $type181 0
                 (local.tee $16
                  (call $function296
                   (local.get $13)
                   (local.get $18)
                  )
                 )
                )
                (i32.const 1)
               )
               (then
                (unreachable)
               )
              )
              (struct.get $type183 1
               (ref.cast (ref $type183)
                (local.get $16)
               )
              )
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global371)
               )
              )
              (call $function180
               (block (result (ref $type28))
                (local.set $scratch_24
                 (call $function106
                  (local.get $13)
                  (local.get $18)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global616)
                 )
                )
                (local.get $scratch_24)
               )
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global1435)
             )
            )
            (br_if $block
             (i32.ne
              (struct.get $type181 0
               (local.tee $12
                (call $function296
                 (call $function382
                  (i32.const 0)
                  (local.tee $18
                   (call $foreign26
                    (i32.const 0)
                   )
                  )
                  (block (result (ref $type18))
                   (drop
                    (ref.as_non_null
                     (global.get $global61)
                    )
                   )
                   (if
                    (i64.gt_u
                     (local.get $18)
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (call $string-new
                    (i32.wrap_i64
                     (local.get $18)
                    )
                   )
                  )
                  (i32.const 0)
                  (i32.const 1)
                  (i64.const 0)
                 )
                 (block (result i64)
                  (drop
                   (ref.as_non_null
                    (global.get $global1445)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global1092)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global1086)
                   )
                  )
                  (i64.const 10)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (local.set $7
             (struct.get $type183 1
              (ref.cast (ref $type183)
               (local.get $12)
              )
             )
            )
            (if (result (ref $type24))
             (i64.eqz
              (local.get $0)
             )
             (then
              (local.get $7)
             )
             (else
              (if (result (ref $type24))
               (i64.le_s
                (local.get $0)
                (i64.const 4)
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global1435)
                 )
                )
                (br_if $block
                 (i32.ne
                  (struct.get $type181 0
                   (local.tee $12
                    (call $function296
                     (call $function382
                      (i32.const 1)
                      (local.tee $18
                       (call $foreign26
                        (i32.const 1)
                       )
                      )
                      (block (result (ref $type18))
                       (drop
                        (ref.as_non_null
                         (global.get $global61)
                        )
                       )
                       (if
                        (i64.gt_u
                         (local.get $18)
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $string-new
                        (i32.wrap_i64
                         (local.get $18)
                        )
                       )
                      )
                      (i32.const 0)
                      (i32.const 1)
                      (i64.const 0)
                     )
                     (block (result i64)
                      (drop
                       (ref.as_non_null
                        (global.get $global1445)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global1092)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global1086)
                       )
                      )
                      (i64.const 10)
                     )
                    )
                   )
                  )
                  (i32.const 1)
                 )
                )
                (local.set $8
                 (struct.get $type183 1
                  (ref.cast (ref $type183)
                   (local.get $12)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global1471)
                 )
                )
                (if (result (ref $type24))
                 (i64.eq
                  (local.get $0)
                  (i64.const 1)
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global750)
                   )
                  )
                  (call $function215
                   (local.get $7)
                   (local.get $8)
                  )
                 )
                 (else
                  (if (result (ref $type24))
                   (i64.eq
                    (local.get $0)
                    (i64.const 2)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global755)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global650)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global741)
                     )
                    )
                    (call $function185
                     (call $function212
                      (if (result (ref $type32))
                       (local.tee $17
                        (struct.get $type24 0
                         (local.get $7)
                        )
                       )
                       (then
                        (if (result (ref $type32))
                         (i32.eq
                          (local.get $17)
                          (i32.const 1)
                         )
                         (then
                          (struct.new $type34
                           (i32.const 1)
                           (struct.get $type26 1
                            (ref.cast (ref $type26)
                             (local.get $7)
                            )
                           )
                          )
                         )
                         (else
                          (if (result (ref $type32))
                           (i32.eq
                            (struct.get $type24 0
                             (local.get $7)
                            )
                            (i32.const 2)
                           )
                           (then
                            (struct.new $type35
                             (i32.const 2)
                             (struct.get $type30 1
                              (ref.cast (ref $type30)
                               (local.get $7)
                              )
                             )
                            )
                           )
                           (else
                            (struct.get $type31 1
                             (ref.cast (ref $type31)
                              (local.get $7)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                       (else
                        (struct.new $type33
                         (i32.const 0)
                         (struct.get $type25 1
                          (ref.cast (ref $type25)
                           (local.get $7)
                          )
                         )
                        )
                       )
                      )
                      (if (result (ref $type32))
                       (local.tee $17
                        (struct.get $type24 0
                         (local.get $8)
                        )
                       )
                       (then
                        (if (result (ref $type32))
                         (i32.eq
                          (local.get $17)
                          (i32.const 1)
                         )
                         (then
                          (struct.new $type34
                           (i32.const 1)
                           (struct.get $type26 1
                            (ref.cast (ref $type26)
                             (local.get $8)
                            )
                           )
                          )
                         )
                         (else
                          (if (result (ref $type32))
                           (i32.eq
                            (struct.get $type24 0
                             (local.get $8)
                            )
                            (i32.const 2)
                           )
                           (then
                            (struct.new $type35
                             (i32.const 2)
                             (struct.get $type30 1
                              (ref.cast (ref $type30)
                               (local.get $8)
                              )
                             )
                            )
                           )
                           (else
                            (struct.get $type31 1
                             (ref.cast (ref $type31)
                              (local.get $8)
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                       (else
                        (struct.new $type33
                         (i32.const 0)
                         (struct.get $type25 1
                          (ref.cast (ref $type25)
                           (local.get $8)
                          )
                         )
                        )
                       )
                      )
                     )
                     (block (result (ref $type32))
                      (drop
                       (ref.as_non_null
                        (global.get $global658)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global741)
                       )
                      )
                      (local.set $scratch_25
                       (call $function212
                        (if (result (ref $type32))
                         (local.tee $17
                          (struct.get $type24 0
                           (local.get $7)
                          )
                         )
                         (then
                          (if (result (ref $type32))
                           (i32.eq
                            (local.get $17)
                            (i32.const 1)
                           )
                           (then
                            (drop
                             (ref.cast (ref $type26)
                              (local.get $7)
                             )
                            )
                            (struct.new_default $type33)
                           )
                           (else
                            (if (result (ref $type32))
                             (i32.eq
                              (struct.get $type24 0
                               (local.get $7)
                              )
                              (i32.const 2)
                             )
                             (then
                              (drop
                               (ref.cast (ref $type30)
                                (local.get $7)
                               )
                              )
                              (struct.new_default $type33)
                             )
                             (else
                              (struct.get $type31 2
                               (ref.cast (ref $type31)
                                (local.get $7)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (drop
                           (ref.cast (ref $type25)
                            (local.get $7)
                           )
                          )
                          (struct.new_default $type33)
                         )
                        )
                        (if (result (ref $type32))
                         (local.tee $17
                          (struct.get $type24 0
                           (local.get $8)
                          )
                         )
                         (then
                          (if (result (ref $type32))
                           (i32.eq
                            (local.get $17)
                            (i32.const 1)
                           )
                           (then
                            (drop
                             (ref.cast (ref $type26)
                              (local.get $8)
                             )
                            )
                            (struct.new_default $type33)
                           )
                           (else
                            (if (result (ref $type32))
                             (i32.eq
                              (struct.get $type24 0
                               (local.get $8)
                              )
                              (i32.const 2)
                             )
                             (then
                              (drop
                               (ref.cast (ref $type30)
                                (local.get $8)
                               )
                              )
                              (struct.new_default $type33)
                             )
                             (else
                              (struct.get $type31 2
                               (ref.cast (ref $type31)
                                (local.get $8)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (drop
                           (ref.cast (ref $type25)
                            (local.get $8)
                           )
                          )
                          (struct.new_default $type33)
                         )
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global642)
                       )
                      )
                      (local.get $scratch_25)
                     )
                    )
                   )
                   (else
                    (if (result (ref $type24))
                     (i64.eq
                      (local.get $0)
                      (i64.const 3)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global758)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global650)
                       )
                      )
                      (local.set $2
                       (if (result (ref $type32))
                        (local.tee $17
                         (struct.get $type24 0
                          (local.get $7)
                         )
                        )
                        (then
                         (if (result (ref $type32))
                          (i32.eq
                           (local.get $17)
                           (i32.const 1)
                          )
                          (then
                           (struct.new $type34
                            (i32.const 1)
                            (struct.get $type26 1
                             (ref.cast (ref $type26)
                              (local.get $7)
                             )
                            )
                           )
                          )
                          (else
                           (if (result (ref $type32))
                            (i32.eq
                             (struct.get $type24 0
                              (local.get $7)
                             )
                             (i32.const 2)
                            )
                            (then
                             (struct.new $type35
                              (i32.const 2)
                              (struct.get $type30 1
                               (ref.cast (ref $type30)
                                (local.get $7)
                               )
                              )
                             )
                            )
                            (else
                             (struct.get $type31 1
                              (ref.cast (ref $type31)
                               (local.get $7)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (struct.new $type33
                          (i32.const 0)
                          (struct.get $type25 1
                           (ref.cast (ref $type25)
                            (local.get $7)
                           )
                          )
                         )
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global658)
                       )
                      )
                      (local.set $4
                       (if (result (ref $type32))
                        (local.tee $17
                         (struct.get $type24 0
                          (local.get $7)
                         )
                        )
                        (then
                         (if (result (ref $type32))
                          (i32.eq
                           (local.get $17)
                           (i32.const 1)
                          )
                          (then
                           (drop
                            (ref.cast (ref $type26)
                             (local.get $7)
                            )
                           )
                           (struct.new_default $type33)
                          )
                          (else
                           (if (result (ref $type32))
                            (i32.eq
                             (struct.get $type24 0
                              (local.get $7)
                             )
                             (i32.const 2)
                            )
                            (then
                             (drop
                              (ref.cast (ref $type30)
                               (local.get $7)
                              )
                             )
                             (struct.new_default $type33)
                            )
                            (else
                             (struct.get $type31 2
                              (ref.cast (ref $type31)
                               (local.get $7)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.cast (ref $type25)
                           (local.get $7)
                          )
                         )
                         (struct.new_default $type33)
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global650)
                       )
                      )
                      (local.set $3
                       (if (result (ref $type32))
                        (local.tee $17
                         (struct.get $type24 0
                          (local.get $8)
                         )
                        )
                        (then
                         (if (result (ref $type32))
                          (i32.eq
                           (local.get $17)
                           (i32.const 1)
                          )
                          (then
                           (struct.new $type34
                            (i32.const 1)
                            (struct.get $type26 1
                             (ref.cast (ref $type26)
                              (local.get $8)
                             )
                            )
                           )
                          )
                          (else
                           (if (result (ref $type32))
                            (i32.eq
                             (struct.get $type24 0
                              (local.get $8)
                             )
                             (i32.const 2)
                            )
                            (then
                             (struct.new $type35
                              (i32.const 2)
                              (struct.get $type30 1
                               (ref.cast (ref $type30)
                                (local.get $8)
                               )
                              )
                             )
                            )
                            (else
                             (struct.get $type31 1
                              (ref.cast (ref $type31)
                               (local.get $8)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (struct.new $type33
                          (i32.const 0)
                          (struct.get $type25 1
                           (ref.cast (ref $type25)
                            (local.get $8)
                           )
                          )
                         )
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global658)
                       )
                      )
                      (local.set $5
                       (if (result (ref $type32))
                        (local.tee $17
                         (struct.get $type24 0
                          (local.get $8)
                         )
                        )
                        (then
                         (if (result (ref $type32))
                          (i32.eq
                           (local.get $17)
                           (i32.const 1)
                          )
                          (then
                           (drop
                            (ref.cast (ref $type26)
                             (local.get $8)
                            )
                           )
                           (struct.new_default $type33)
                          )
                          (else
                           (if (result (ref $type32))
                            (i32.eq
                             (struct.get $type24 0
                              (local.get $8)
                             )
                             (i32.const 2)
                            )
                            (then
                             (drop
                              (ref.cast (ref $type30)
                               (local.get $8)
                              )
                             )
                             (struct.new_default $type33)
                            )
                            (else
                             (struct.get $type31 2
                              (ref.cast (ref $type31)
                               (local.get $8)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.cast (ref $type25)
                           (local.get $8)
                          )
                         )
                         (struct.new_default $type33)
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global666)
                       )
                      )
                      (if (result (ref $type24))
                       (if (result i32)
                        (if (result i32)
                         (local.tee $17
                          (struct.get $type24 0
                           (local.get $7)
                          )
                         )
                         (then
                          (if (result i32)
                           (i32.eq
                            (local.get $17)
                            (i32.const 1)
                           )
                           (then
                            (drop
                             (ref.cast (ref $type26)
                              (local.get $7)
                             )
                            )
                            (i32.const 0)
                           )
                           (else
                            (if (result i32)
                             (i32.eq
                              (struct.get $type24 0
                               (local.get $7)
                              )
                              (i32.const 2)
                             )
                             (then
                              (drop
                               (ref.cast (ref $type30)
                                (local.get $7)
                               )
                              )
                              (i32.const 0)
                             )
                             (else
                              (drop
                               (ref.cast (ref $type31)
                                (local.get $7)
                               )
                              )
                              (i32.const 1)
                             )
                            )
                           )
                          )
                         )
                         (else
                          (drop
                           (ref.cast (ref $type25)
                            (local.get $7)
                           )
                          )
                          (i32.const 0)
                         )
                        )
                        (then
                         (i32.const 1)
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global666)
                          )
                         )
                         (if (result i32)
                          (local.tee $17
                           (struct.get $type24 0
                            (local.get $8)
                           )
                          )
                          (then
                           (if (result i32)
                            (i32.eq
                             (local.get $17)
                             (i32.const 1)
                            )
                            (then
                             (drop
                              (ref.cast (ref $type26)
                               (local.get $8)
                              )
                             )
                             (i32.const 0)
                            )
                            (else
                             (if (result i32)
                              (i32.eq
                               (struct.get $type24 0
                                (local.get $8)
                               )
                               (i32.const 2)
                              )
                              (then
                               (drop
                                (ref.cast (ref $type30)
                                 (local.get $8)
                                )
                               )
                               (i32.const 0)
                              )
                              (else
                               (drop
                                (ref.cast (ref $type31)
                                 (local.get $8)
                                )
                               )
                               (i32.const 1)
                              )
                             )
                            )
                           )
                          )
                          (else
                           (drop
                            (ref.cast (ref $type25)
                             (local.get $8)
                            )
                           )
                           (i32.const 0)
                          )
                         )
                        )
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global744)
                         )
                        )
                        (call $function185
                         (call $function212
                          (call $function213
                           (local.get $2)
                           (local.get $3)
                          )
                          (block (result (ref $type32))
                           (drop
                            (ref.as_non_null
                             (global.get $global744)
                            )
                           )
                           (local.set $scratch_26
                            (call $function213
                             (local.get $4)
                             (local.get $5)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global741)
                            )
                           )
                           (local.get $scratch_26)
                          )
                         )
                         (block (result (ref $type32))
                          (drop
                           (ref.as_non_null
                            (global.get $global744)
                           )
                          )
                          (local.set $scratch_28
                           (call $function210
                            (call $function213
                             (local.get $2)
                             (local.get $5)
                            )
                            (block (result (ref $type32))
                             (drop
                              (ref.as_non_null
                               (global.get $global744)
                              )
                             )
                             (local.set $scratch_27
                              (call $function213
                               (local.get $4)
                               (local.get $3)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global732)
                              )
                             )
                             (local.get $scratch_27)
                            )
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global642)
                           )
                          )
                          (local.get $scratch_28)
                         )
                        )
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global744)
                         )
                        )
                        (local.set $2
                         (call $function213
                          (local.get $2)
                          (local.get $3)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global608)
                         )
                        )
                        (if (result (ref $type24))
                         (local.tee $17
                          (struct.get $type32 0
                           (local.get $2)
                          )
                         )
                         (then
                          (if (result (ref $type24))
                           (i32.eq
                            (local.get $17)
                            (i32.const 1)
                           )
                           (then
                            (struct.new $type26
                             (i32.const 1)
                             (struct.get $type34 1
                              (ref.cast (ref $type34)
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (else
                            (struct.new $type30
                             (i32.const 2)
                             (struct.get $type35 1
                              (ref.cast (ref $type35)
                               (local.get $2)
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (struct.new $type25
                           (i32.const 0)
                           (struct.get $type33 1
                            (ref.cast (ref $type33)
                             (local.get $2)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global765)
                       )
                      )
                      (call $function219
                       (local.get $7)
                       (local.get $8)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global1475)
                 )
                )
                (if (result (ref $type24))
                 (i64.eq
                  (local.get $0)
                  (i64.const 7)
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global718)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global674)
                   )
                  )
                  (if (result (ref $type24))
                   (struct.get $type32 0
                    (local.tee $2
                     (call $function190
                      (local.get $7)
                     )
                    )
                   )
                   (then
                    (if (result (ref $type24))
                     (i32.eq
                      (struct.get $type32 0
                       (local.get $2)
                      )
                      (i32.const 1)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global571)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global322)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global316)
                       )
                      )
                      (call $function180
                       (block (result (ref $type28))
                        (local.set $scratch_29
                         (struct.get $type88 0
                          (call $function93
                           (struct.get $type27 0
                            (local.tee $11
                             (struct.get $type34 1
                              (ref.cast (ref $type34)
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (struct.get $type27 1
                            (local.get $11)
                           )
                          )
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global616)
                         )
                        )
                        (local.get $scratch_29)
                       )
                      )
                     )
                     (else
                      (struct.new $type30
                       (i32.const 2)
                       (f64.trunc
                        (struct.get $type35 1
                         (ref.cast (ref $type35)
                          (local.get $2)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (struct.new $type25
                     (i32.const 0)
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $2)
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (if (result (ref $type24))
                   (i64.eq
                    (local.get $0)
                    (i64.const 9)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global724)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global674)
                     )
                    )
                    (local.set $2
                     (call $function190
                      (local.get $7)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global618)
                     )
                    )
                    (if (result (ref $type24))
                     (if (result i32)
                      (if (result i32)
                       (local.tee $17
                        (struct.get $type32 0
                         (local.get $2)
                        )
                       )
                       (then
                        (if (result i32)
                         (i32.eq
                          (local.get $17)
                          (i32.const 1)
                         )
                         (then
                          (drop
                           (ref.cast (ref $type34)
                            (local.get $2)
                           )
                          )
                          (i32.const 1)
                         )
                         (else
                          (drop
                           (ref.cast (ref $type35)
                            (local.get $2)
                           )
                          )
                          (i32.const 0)
                         )
                        )
                       )
                       (else
                        (drop
                         (ref.cast (ref $type33)
                          (local.get $2)
                         )
                        )
                        (i32.const 1)
                       )
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global624)
                        )
                       )
                       (if (result i32)
                        (local.tee $17
                         (struct.get $type32 0
                          (local.get $2)
                         )
                        )
                        (then
                         (if (result i32)
                          (i32.eq
                           (local.get $17)
                           (i32.const 1)
                          )
                          (then
                           (drop
                            (ref.as_non_null
                             (global.get $global551)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global130)
                            )
                           )
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (struct.get $type28 1
                               (struct.get $type27 0
                                (struct.get $type34 1
                                 (ref.cast (ref $type34)
                                  (local.get $2)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (else
                           (f64.eq
                            (struct.get $type35 1
                             (ref.cast (ref $type35)
                              (local.get $2)
                             )
                            )
                            (f64.const 0.0)
                           )
                          )
                         )
                        )
                        (else
                         (i64.eqz
                          (struct.get $type33 1
                           (ref.cast (ref $type33)
                            (local.get $2)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global608)
                       )
                      )
                      (if (result (ref $type24))
                       (local.tee $17
                        (struct.get $type32 0
                         (local.get $2)
                        )
                       )
                       (then
                        (if (result (ref $type24))
                         (i32.eq
                          (local.get $17)
                          (i32.const 1)
                         )
                         (then
                          (struct.new $type26
                           (i32.const 1)
                           (struct.get $type34 1
                            (ref.cast (ref $type34)
                             (local.get $2)
                            )
                           )
                          )
                         )
                         (else
                          (struct.new $type30
                           (i32.const 2)
                           (struct.get $type35 1
                            (ref.cast (ref $type35)
                             (local.get $2)
                            )
                           )
                          )
                         )
                        )
                       )
                       (else
                        (struct.new $type25
                         (i32.const 0)
                         (struct.get $type33 1
                          (ref.cast (ref $type33)
                           (local.get $2)
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global636)
                       )
                      )
                      (local.set $9
                       (struct.get $type27 0
                        (call $function184
                         (local.get $2)
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global618)
                       )
                      )
                      (if (result (ref $type24))
                       (if (result i32)
                        (local.tee $17
                         (struct.get $type32 0
                          (local.get $2)
                         )
                        )
                        (then
                         (if (result i32)
                          (i32.eq
                           (local.get $17)
                           (i32.const 1)
                          )
                          (then
                           (drop
                            (ref.cast (ref $type34)
                             (local.get $2)
                            )
                           )
                           (i32.const 1)
                          )
                          (else
                           (drop
                            (ref.cast (ref $type35)
                             (local.get $2)
                            )
                           )
                           (i32.const 0)
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.cast (ref $type33)
                           (local.get $2)
                          )
                         )
                         (i32.const 1)
                        )
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global616)
                         )
                        )
                        (call $function180
                         (local.get $9)
                        )
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global511)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global141)
                         )
                        )
                        (local.set $10
                         (call $function53
                          (i64.const 1)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global507)
                         )
                        )
                        (struct.new $type30
                         (i32.const 2)
                         (call $function142
                          (local.get $9)
                          (local.get $10)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (if (result (ref $type24))
                     (i64.eq
                      (local.get $0)
                      (i64.const 10)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global728)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global674)
                       )
                      )
                      (local.set $2
                       (call $function190
                        (local.get $7)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global636)
                       )
                      )
                      (local.set $9
                       (struct.get $type27 1
                        (call $function184
                         (local.get $2)
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global618)
                       )
                      )
                      (if (result (ref $type24))
                       (if (result i32)
                        (local.tee $17
                         (struct.get $type32 0
                          (local.get $2)
                         )
                        )
                        (then
                         (if (result i32)
                          (i32.eq
                           (local.get $17)
                           (i32.const 1)
                          )
                          (then
                           (drop
                            (ref.cast (ref $type34)
                             (local.get $2)
                            )
                           )
                           (i32.const 1)
                          )
                          (else
                           (drop
                            (ref.cast (ref $type35)
                             (local.get $2)
                            )
                           )
                           (i32.const 0)
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.cast (ref $type33)
                           (local.get $2)
                          )
                         )
                         (i32.const 1)
                        )
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global616)
                         )
                        )
                        (call $function180
                         (local.get $9)
                        )
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global511)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global141)
                         )
                        )
                        (local.set $10
                         (call $function53
                          (i64.const 1)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global507)
                         )
                        )
                        (struct.new $type30
                         (i32.const 2)
                         (call $function142
                          (local.get $9)
                          (local.get $10)
                         )
                        )
                       )
                      )
                     )
                     (else
                      (if (result (ref $type24))
                       (i64.eq
                        (local.get $0)
                        (i64.const 11)
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global676)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global650)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global608)
                         )
                        )
                        (if (result (ref $type24))
                         (local.tee $17
                          (struct.get $type32 0
                           (local.tee $2
                            (if (result (ref $type32))
                             (local.tee $17
                              (struct.get $type24 0
                               (local.get $7)
                              )
                             )
                             (then
                              (if (result (ref $type32))
                               (i32.eq
                                (local.get $17)
                                (i32.const 1)
                               )
                               (then
                                (struct.new $type34
                                 (i32.const 1)
                                 (struct.get $type26 1
                                  (ref.cast (ref $type26)
                                   (local.get $7)
                                  )
                                 )
                                )
                               )
                               (else
                                (if (result (ref $type32))
                                 (i32.eq
                                  (struct.get $type24 0
                                   (local.get $7)
                                  )
                                  (i32.const 2)
                                 )
                                 (then
                                  (struct.new $type35
                                   (i32.const 2)
                                   (struct.get $type30 1
                                    (ref.cast (ref $type30)
                                     (local.get $7)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (struct.get $type31 1
                                   (ref.cast (ref $type31)
                                    (local.get $7)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                             (else
                              (struct.new $type33
                               (i32.const 0)
                               (struct.get $type25 1
                                (ref.cast (ref $type25)
                                 (local.get $7)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                         (then
                          (if (result (ref $type24))
                           (i32.eq
                            (local.get $17)
                            (i32.const 1)
                           )
                           (then
                            (struct.new $type26
                             (i32.const 1)
                             (struct.get $type34 1
                              (ref.cast (ref $type34)
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (else
                            (struct.new $type30
                             (i32.const 2)
                             (struct.get $type35 1
                              (ref.cast (ref $type35)
                               (local.get $2)
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (struct.new $type25
                           (i32.const 0)
                           (struct.get $type33 1
                            (ref.cast (ref $type33)
                             (local.get $2)
                            )
                           )
                          )
                         )
                        )
                       )
                       (else
                        (if (result (ref $type24))
                         (i64.eq
                          (local.get $0)
                          (i64.const 12)
                         )
                         (then
                          (drop
                           (ref.as_non_null
                            (global.get $global678)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global658)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global608)
                           )
                          )
                          (if (result (ref $type24))
                           (local.tee $17
                            (struct.get $type32 0
                             (local.tee $2
                              (if (result (ref $type32))
                               (local.tee $17
                                (struct.get $type24 0
                                 (local.get $7)
                                )
                               )
                               (then
                                (if (result (ref $type32))
                                 (i32.eq
                                  (local.get $17)
                                  (i32.const 1)
                                 )
                                 (then
                                  (drop
                                   (ref.cast (ref $type26)
                                    (local.get $7)
                                   )
                                  )
                                  (struct.new_default $type33)
                                 )
                                 (else
                                  (if (result (ref $type32))
                                   (i32.eq
                                    (struct.get $type24 0
                                     (local.get $7)
                                    )
                                    (i32.const 2)
                                   )
                                   (then
                                    (drop
                                     (ref.cast (ref $type30)
                                      (local.get $7)
                                     )
                                    )
                                    (struct.new_default $type33)
                                   )
                                   (else
                                    (struct.get $type31 2
                                     (ref.cast (ref $type31)
                                      (local.get $7)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (drop
                                 (ref.cast (ref $type25)
                                  (local.get $7)
                                 )
                                )
                                (struct.new_default $type33)
                               )
                              )
                             )
                            )
                           )
                           (then
                            (if (result (ref $type24))
                             (i32.eq
                              (local.get $17)
                              (i32.const 1)
                             )
                             (then
                              (struct.new $type26
                               (i32.const 1)
                               (struct.get $type34 1
                                (ref.cast (ref $type34)
                                 (local.get $2)
                                )
                               )
                              )
                             )
                             (else
                              (struct.new $type30
                               (i32.const 2)
                               (struct.get $type35 1
                                (ref.cast (ref $type35)
                                 (local.get $2)
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (struct.new $type25
                             (i32.const 0)
                             (struct.get $type33 1
                              (ref.cast (ref $type33)
                               (local.get $2)
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (if (result (ref $type24))
                           (i64.eq
                            (local.get $0)
                            (i64.const 16)
                           )
                           (then
                            (drop
                             (ref.as_non_null
                              (global.get $global753)
                             )
                            )
                            (call $function216
                             (local.get $7)
                            )
                           )
                           (else
                            (if (result (ref $type24))
                             (i64.eq
                              (local.get $0)
                              (i64.const 17)
                             )
                             (then
                              (drop
                               (ref.as_non_null
                                (global.get $global803)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global674)
                               )
                              )
                              (local.set $2
                               (if (result (ref $type32))
                                (struct.get $type32 0
                                 (local.tee $2
                                  (call $function190
                                   (local.get $7)
                                  )
                                 )
                                )
                                (then
                                 (if (result (ref $type32))
                                  (i32.eq
                                   (struct.get $type32 0
                                    (local.get $2)
                                   )
                                   (i32.const 1)
                                  )
                                  (then
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global557)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global606)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global553)
                                    )
                                   )
                                   (call $function177
                                    (if (result (ref $type27))
                                     (struct.get $type28 0
                                      (local.tee $9
                                       (struct.get $type27 0
                                        (local.tee $11
                                         (struct.get $type34 1
                                          (ref.cast (ref $type34)
                                           (local.get $2)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global555)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global134)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global130)
                                       )
                                      )
                                      (struct.new $type27
                                       (if (result (ref $type28))
                                        (i64.eqz
                                         (i64.extend_i32_u
                                          (array.len
                                           (struct.get $type28 1
                                            (local.get $9)
                                           )
                                          )
                                         )
                                        )
                                        (then
                                         (local.get $9)
                                        )
                                        (else
                                         (struct.new $type28
                                          (i32.eqz
                                           (struct.get $type28 0
                                            (local.get $9)
                                           )
                                          )
                                          (struct.get $type28 1
                                           (local.get $9)
                                          )
                                         )
                                        )
                                       )
                                       (struct.get $type27 1
                                        (local.get $11)
                                       )
                                      )
                                     )
                                     (else
                                      (local.get $11)
                                     )
                                    )
                                   )
                                  )
                                  (else
                                   (struct.new $type35
                                    (i32.const 2)
                                    (if (result f64)
                                     (f64.le
                                      (local.tee $1
                                       (struct.get $type35 1
                                        (ref.cast (ref $type35)
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (f64.const 0.0)
                                     )
                                     (then
                                      (f64.sub
                                       (f64.const 0.0)
                                       (local.get $1)
                                      )
                                     )
                                     (else
                                      (local.get $1)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global636)
                                  )
                                 )
                                 (local.set $11
                                  (call $function184
                                   (struct.new $type33
                                    (i32.const 0)
                                    (struct.get $type33 1
                                     (ref.cast (ref $type33)
                                      (local.get $2)
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global557)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global606)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global553)
                                  )
                                 )
                                 (call $function177
                                  (if (result (ref $type27))
                                   (struct.get $type28 0
                                    (local.tee $9
                                     (struct.get $type27 0
                                      (local.get $11)
                                     )
                                    )
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global555)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global134)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global130)
                                     )
                                    )
                                    (struct.new $type27
                                     (if (result (ref $type28))
                                      (i64.eqz
                                       (i64.extend_i32_u
                                        (array.len
                                         (struct.get $type28 1
                                          (local.get $9)
                                         )
                                        )
                                       )
                                      )
                                      (then
                                       (local.get $9)
                                      )
                                      (else
                                       (struct.new $type28
                                        (i32.eqz
                                         (struct.get $type28 0
                                          (local.get $9)
                                         )
                                        )
                                        (struct.get $type28 1
                                         (local.get $9)
                                        )
                                       )
                                      )
                                     )
                                     (struct.get $type27 1
                                      (local.get $11)
                                     )
                                    )
                                   )
                                   (else
                                    (local.get $11)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global608)
                               )
                              )
                              (if (result (ref $type24))
                               (local.tee $17
                                (struct.get $type32 0
                                 (local.get $2)
                                )
                               )
                               (then
                                (if (result (ref $type24))
                                 (i32.eq
                                  (local.get $17)
                                  (i32.const 1)
                                 )
                                 (then
                                  (struct.new $type26
                                   (i32.const 1)
                                   (struct.get $type34 1
                                    (ref.cast (ref $type34)
                                     (local.get $2)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (struct.new $type30
                                   (i32.const 2)
                                   (struct.get $type35 1
                                    (ref.cast (ref $type35)
                                     (local.get $2)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (struct.new $type25
                                 (i32.const 0)
                                 (struct.get $type33 1
                                  (ref.cast (ref $type33)
                                   (local.get $2)
                                  )
                                 )
                                )
                               )
                              )
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global684)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global674)
                               )
                              )
                              (local.set $2
                               (call $function190
                                (local.get $7)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global618)
                               )
                              )
                              (call $function180
                               (block (result (ref $type28))
                                (local.set $scratch_30
                                 (if (result (ref $type28))
                                  (if (result i32)
                                   (local.tee $17
                                    (struct.get $type32 0
                                     (local.get $2)
                                    )
                                   )
                                   (then
                                    (if (result i32)
                                     (i32.eq
                                      (local.get $17)
                                      (i32.const 1)
                                     )
                                     (then
                                      (drop
                                       (ref.cast (ref $type34)
                                        (local.get $2)
                                       )
                                      )
                                      (i32.const 1)
                                     )
                                     (else
                                      (drop
                                       (ref.cast (ref $type35)
                                        (local.get $2)
                                       )
                                      )
                                      (i32.const 0)
                                     )
                                    )
                                   )
                                   (else
                                    (drop
                                     (ref.cast (ref $type33)
                                      (local.get $2)
                                     )
                                    )
                                    (i32.const 1)
                                   )
                                  )
                                  (then
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global636)
                                    )
                                   )
                                   (local.set $11
                                    (call $function184
                                     (local.get $2)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global549)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global171)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global167)
                                    )
                                   )
                                   (if (result (ref $type28))
                                    (i64.eqz
                                     (call $function59
                                      (struct.get $type27 1
                                       (local.get $11)
                                      )
                                      (ref.as_non_null
                                       (global.get $global539)
                                      )
                                     )
                                    )
                                    (then
                                     (struct.get $type27 0
                                      (local.get $11)
                                     )
                                    )
                                    (else
                                     (unreachable)
                                    )
                                   )
                                  )
                                  (else
                                   (unreachable)
                                  )
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global616)
                                 )
                                )
                                (local.get $scratch_30)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global878)
        )
       )
       (local.set $13
        (call $function238
         (local.get $7)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1445)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1092)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1086)
        )
       )
       (br_if $block
        (i32.ne
         (struct.get $type181 0
          (local.tee $12
           (call $function296
            (local.get $13)
            (i64.const 10)
           )
          )
         )
         (i32.const 1)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global824)
        )
       )
       (if
        (i32.eqz
         (call $function230
          (local.get $7)
          (struct.get $type183 1
           (ref.cast (ref $type183)
            (local.get $12)
           )
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global1441)
        )
       )
       (drop
        (call $function383
         (local.get $13)
        )
       )
       (f64.const 0.0)
      )
     )
    )
   )
   (if
    (struct.get $type181 0
     (local.get $12)
    )
    (then
     (drop
      (ref.cast (ref $type184)
       (local.get $12)
      )
     )
    )
   )
   (unreachable)
  )
 )
 (func $main
  (local $0 (ref $type28))
  (local $1 (ref $type28))
  (local $2 (ref $type28))
  (local $3 (ref $type18))
  (local $4 (ref $type18))
  (local $5 (ref $type27))
  (local $6 (ref $type27))
  (local $7 (ref $type27))
  (local $8 (ref $type32))
  (local $9 (ref $type24))
  (local $10 (ref $type24))
  (local $11 (ref $type25))
  (local $12 i32)
  (local $scratch (ref $type28))
  (local $scratch_14 (ref $type28))
  (local $scratch_15 (ref $type28))
  (local $scratch_16 (ref $type28))
  (local $scratch_17 (ref $type28))
  (local $scratch_18 (ref $type27))
  (local $scratch_19 (ref $type32))
  (local $scratch_20 (ref $type24))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global68
   (struct.new_default $type48)
  )
  (global.set $global383
   (struct.new_default $type52)
  )
  (global.set $global61
   (struct.new_default $type54)
  )
  (global.set $global63
   (struct.new_default $type55)
  )
  (global.set $global65
   (struct.new_default $type56)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global88
   (struct.new_default $type60)
  )
  (global.set $global91
   (struct.new_default $type62)
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global96
   (struct.new_default $type63)
  )
  (global.set $ready96
   (i32.const 1)
  )
  (global.set $global101
   (struct.new_default $type64)
  )
  (global.set $global108
   (struct.new $type28
    (i32.const 0)
    (array.new_fixed $type29 0)
   )
  )
  (global.set $global109
   (struct.new_default $type65)
  )
  (global.set $global112
   (struct.new_default $type66)
  )
  (global.set $global116
   (struct.new_default $type67)
  )
  (global.set $global118
   (struct.new_default $type68)
  )
  (global.set $global122
   (struct.new_default $type52)
  )
  (global.set $global126
   (struct.new_default $type69)
  )
  (global.set $global130
   (struct.new_default $type70)
  )
  (global.set $global132
   (struct.new_default $type71)
  )
  (global.set $global134
   (struct.new_default $type71)
  )
  (global.set $global136
   (struct.new_default $type72)
  )
  (global.set $global141
   (struct.new_default $type73)
  )
  (global.set $global149
   (struct.new_default $type74)
  )
  (global.set $global158
   (struct.new_default $type75)
  )
  (global.set $global167
   (struct.new_default $type76)
  )
  (global.set $global171
   (struct.new_default $type77)
  )
  (global.set $global174
   (struct.new_default $type77)
  )
  (global.set $global177
   (struct.new_default $type77)
  )
  (global.set $global183
   (struct.new_default $type77)
  )
  (global.set $global186
   (struct.new_default $type65)
  )
  (global.set $global189
   (struct.new_default $type78)
  )
  (global.set $global198
   (struct.new_default $type78)
  )
  (global.set $global207
   (struct.new_default $type79)
  )
  (global.set $global211
   (struct.new_default $type80)
  )
  (global.set $global219
   (struct.new_default $type81)
  )
  (global.set $global230
   (struct.new_default $type78)
  )
  (global.set $global236
   (struct.new_default $type80)
  )
  (global.set $global239
   (struct.new_default $type82)
  )
  (global.set $global248
   (struct.new_default $type83)
  )
  (global.set $global256
   (struct.new_default $type83)
  )
  (global.set $global268
   (struct.new_default $type84)
  )
  (global.set $global280
   (struct.new_default $type85)
  )
  (global.set $global289
   (struct.new_default $type83)
  )
  (global.set $global294
   (struct.new_default $type86)
  )
  (global.set $global300
   (struct.new_default $type87)
  )
  (global.set $global309
   (struct.new_default $type89)
  )
  (global.set $global316
   (struct.new_default $type89)
  )
  (global.set $global322
   (struct.new_default $type80)
  )
  (global.set $global325
   (struct.new_default $type80)
  )
  (global.set $global328
   (struct.new_default $type90)
  )
  (global.set $global336
   (struct.new_default $type91)
  )
  (global.set $global342
   (struct.new_default $type92)
  )
  (global.set $global353
   (struct.new_default $type93)
  )
  (global.set $global358
   (struct.new_default $type94)
  )
  (global.set $global363
   (struct.new_default $type95)
  )
  (global.set $global371
   (struct.new_default $type96)
  )
  (global.set $global377
   (struct.new_default $type97)
  )
  (global.set $global387
   (struct.new_default $type72)
  )
  (global.set $global392
   (struct.new_default $type51)
  )
  (global.set $global397
   (struct.new_default $type98)
  )
  (global.set $global406
   (struct.new_default $type99)
  )
  (global.set $ready406
   (i32.const 1)
  )
  (global.set $global411
   (struct.new_default $type100)
  )
  (global.set $global417
   (struct.new_default $type71)
  )
  (global.set $global421
   (struct.new_default $type80)
  )
  (global.set $global430
   (struct.new_default $type101)
  )
  (global.set $global433
   (struct.new_default $type72)
  )
  (global.set $global454
   (struct.new_default $type104)
  )
  (global.set $global456
   (struct.new_default $type105)
  )
  (global.set $global461
   (struct.new_default $type106)
  )
  (global.set $global473
   (struct.new_default $type74)
  )
  (global.set $global477
   (struct.new_default $type73)
  )
  (global.set $global479
   (struct.new_default $type107)
  )
  (global.set $global486
   (struct.new_default $type108)
  )
  (global.set $global490
   (struct.new_default $type76)
  )
  (global.set $global497
   (struct.new_default $type109)
  )
  (global.set $global502
   (struct.new_default $type110)
  )
  (global.set $global507
   (struct.new_default $type110)
  )
  (global.set $global511
   (struct.new_default $type111)
  )
  (global.set $global513
   (struct.new_default $type70)
  )
  (global.set $global515
   (struct.new_default $type80)
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (global.set $global539
   (call $function53
    (i64.const 1)
   )
  )
  (global.set $global540
   (struct.new_default $type112)
  )
  (global.set $global547
   (struct.new_default $type113)
  )
  (global.set $global549
   (struct.new_default $type114)
  )
  (global.set $global551
   (struct.new_default $type114)
  )
  (global.set $global553
   (struct.new_default $type114)
  )
  (global.set $global555
   (struct.new_default $type115)
  )
  (global.set $global557
   (struct.new_default $type115)
  )
  (global.set $global559
   (struct.new_default $type116)
  )
  (global.set $global562
   (struct.new_default $type116)
  )
  (global.set $global565
   (struct.new_default $type116)
  )
  (global.set $global568
   (struct.new_default $type116)
  )
  (global.set $global571
   (struct.new_default $type117)
  )
  (global.set $global575
   (struct.new_default $type118)
  )
  (global.set $global578
   (struct.new_default $type119)
  )
  (global.set $global593
   (struct.new_default $type120)
  )
  (global.set $global598
   (struct.new_default $type121)
  )
  (global.set $global600
   (struct.new_default $type122)
  )
  (global.set $global603
   (struct.new_default $type5)
  )
  (global.set $global606
   (struct.new_default $type123)
  )
  (global.set $global608
   (struct.new_default $type124)
  )
  (global.set $global614
   (struct.new_default $type125)
  )
  (global.set $global616
   (struct.new_default $type126)
  )
  (global.set $global618
   (struct.new_default $type127)
  )
  (global.set $global624
   (struct.new_default $type127)
  )
  (global.set $global630
   (struct.new_default $type128)
  )
  (global.set $global636
   (struct.new_default $type129)
  )
  (global.set $global642
   (struct.new_default $type130)
  )
  (global.set $global645
   (struct.new_default $type130)
  )
  (global.set $global650
   (struct.new_default $type131)
  )
  (global.set $global658
   (struct.new_default $type131)
  )
  (global.set $global666
   (struct.new_default $type132)
  )
  (global.set $global674
   (struct.new_default $type131)
  )
  (global.set $global676
   (struct.new_default $type133)
  )
  (global.set $global678
   (struct.new_default $type133)
  )
  (global.set $global680
   (struct.new_default $type134)
  )
  (global.set $global682
   (struct.new_default $type135)
  )
  (global.set $global684
   (struct.new_default $type136)
  )
  (global.set $global688
   (struct.new_default $type104)
  )
  (global.set $global690
   (struct.new_default $type127)
  )
  (global.set $global696
   (struct.new_default $type127)
  )
  (global.set $global702
   (struct.new_default $type132)
  )
  (global.set $global704
   (struct.new_default $type132)
  )
  (global.set $global706
   (struct.new_default $type132)
  )
  (global.set $global708
   (struct.new_default $type132)
  )
  (global.set $global710
   (struct.new_default $type132)
  )
  (global.set $global714
   (struct.new_default $type133)
  )
  (global.set $global716
   (struct.new_default $type133)
  )
  (global.set $global718
   (struct.new_default $type133)
  )
  (global.set $global724
   (struct.new_default $type133)
  )
  (global.set $global728
   (struct.new_default $type133)
  )
  (global.set $global732
   (struct.new_default $type137)
  )
  (global.set $global735
   (struct.new_default $type138)
  )
  (global.set $global741
   (struct.new_default $type137)
  )
  (global.set $global744
   (struct.new_default $type137)
  )
  (global.set $global747
   (struct.new_default $type137)
  )
  (global.set $global750
   (struct.new_default $type139)
  )
  (global.set $global753
   (struct.new_default $type133)
  )
  (global.set $global755
   (struct.new_default $type139)
  )
  (global.set $global758
   (struct.new_default $type139)
  )
  (global.set $global765
   (struct.new_default $type139)
  )
  (global.set $global773
   (struct.new_default $type127)
  )
  (global.set $global779
   (struct.new_default $type140)
  )
  (global.set $global784
   (struct.new_default $type141)
  )
  (global.set $global787
   (struct.new_default $type141)
  )
  (global.set $global790
   (struct.new_default $type141)
  )
  (global.set $global793
   (struct.new_default $type141)
  )
  (global.set $global797
   (struct.new_default $type141)
  )
  (global.set $global803
   (struct.new_default $type133)
  )
  (global.set $global809
   (struct.new_default $type142)
  )
  (global.set $global824
   (struct.new_default $type141)
  )
  (global.set $global851
   (struct.new_default $type72)
  )
  (global.set $global856
   (struct.new_default $type54)
  )
  (global.set $global865
   (struct.new_default $type143)
  )
  (global.set $global872
   (struct.new_default $type144)
  )
  (global.set $global878
   (struct.new_default $type145)
  )
  (global.set $global883
   (struct.new_default $type5)
  )
  (global.set $ready883
   (i32.const 1)
  )
  (global.set $global1021
   (struct.new_default $type169)
  )
  (global.set $global1045
   (struct.new_default $type175)
  )
  (global.set $global1053
   (struct.new_default $type176)
  )
  (global.set $global1062
   (struct.new_default $type177)
  )
  (global.set $global1068
   (struct.new_default $type178)
  )
  (global.set $global1072
   (struct.new_default $type179)
  )
  (global.set $global1078
   (struct.new_default $type180)
  )
  (global.set $global1083
   (struct.new_default $type180)
  )
  (global.set $global1086
   (struct.new_default $type185)
  )
  (global.set $global1092
   (struct.new_default $type186)
  )
  (global.set $global1435
   (struct.new_default $type179)
  )
  (global.set $global1441
   (struct.new_default $type224)
  )
  (global.set $global1445
   (struct.new_default $type225)
  )
  (global.set $global1471
   (struct.new_default $type226)
  )
  (global.set $global1475
   (struct.new_default $type227)
  )
  (global.set $global1450
   (struct.new_default $type228)
  )
  (global.set $global1459
   (struct.new_default $type229)
  )
  (global.set $global1466
   (struct.new_default $type230)
  )
  (global.set $global1463
   (struct.new_default $type231)
  )
  (global.set $global1455
   (struct.new_default $type107)
  )
  (global.set $global1452
   (struct.new_default $type0)
  )
  (global.set $ready1452
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global603)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (local.set $5
   (call $function153
    (call $function53
     (i64.const 2)
    )
    (block (result (ref $type28))
     (drop
      (ref.as_non_null
       (global.get $global141)
      )
     )
     (local.set $scratch
      (call $function53
       (i64.const -4)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global540)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (local.set $6
   (call $function153
    (call $function53
     (i64.const 0)
    )
    (block (result (ref $type28))
     (drop
      (ref.as_non_null
       (global.get $global141)
      )
     )
     (local.set $scratch_14
      (call $function53
       (i64.const -9)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global540)
      )
     )
     (local.get $scratch_14)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global600)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global411)
   )
  )
  (local.set $3
   (call $function117
    (struct.get $type27 0
     (local.get $5)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global549)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global171)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (if
   (i64.ne
    (call $function59
     (local.tee $0
      (struct.get $type27 1
       (local.get $5)
      )
     )
     (ref.as_non_null
      (global.get $global539)
     )
    )
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global411)
     )
    )
    (local.set $4
     (call $function117
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global88)
     )
    )
    (local.set $3
     (call $function35
      (struct.new $type61
       (local.get $3)
       (struct.new $type61
        (global.get $string0)
        (struct.new $type61
         (local.get $4)
         (ref.null none)
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global101)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (if (result i32)
      (i64.eq
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $3)
        )
       )
       (i64.const 4)
      )
      (then
       (call $function40
        (local.get $3)
        (global.get $string2)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global600)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global411)
       )
      )
      (local.set $3
       (call $function117
        (struct.get $type27 0
         (local.get $6)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global549)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global171)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global167)
       )
      )
      (if
       (i64.ne
        (call $function59
         (local.tee $0
          (struct.get $type27 1
           (local.get $6)
          )
         )
         (ref.as_non_null
          (global.get $global539)
         )
        )
        (i64.const 0)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global411)
         )
        )
        (local.set $4
         (call $function117
          (local.get $0)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global88)
         )
        )
        (local.set $3
         (call $function35
          (struct.new $type61
           (local.get $3)
           (struct.new $type61
            (global.get $string0)
            (struct.new $type61
             (local.get $4)
             (ref.null none)
            )
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global101)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $3)
          )
         )
         (i64.const 1)
        )
        (then
         (call $function40
          (local.get $3)
          (global.get $string1)
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global141)
         )
        )
        (local.set $0
         (call $function53
          (i64.const 1)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global171)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global167)
         )
        )
        (if (result i32)
         (i64.eqz
          (call $function59
           (struct.get $type27 1
            (local.get $6)
           )
           (local.get $0)
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global593)
           )
          )
          (local.set $7
           (call $function173
            (i32.const 0)
            (i32.const 1)
            (f64.const -0.5)
            (i64.const 0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global578)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global171)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global167)
           )
          )
          (if (result i32)
           (if (result i32)
            (i64.eqz
             (call $function59
              (struct.get $type27 0
               (local.get $7)
              )
              (struct.get $type27 0
               (local.get $5)
              )
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global171)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global167)
              )
             )
             (i64.eqz
              (call $function59
               (struct.get $type27 1
                (local.get $7)
               )
               (struct.get $type27 1
                (local.get $5)
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global555)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global134)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global559)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global130)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global236)
             )
            )
            (local.set $5
             (call $function153
              (call $function71
               (call $function77
                (local.tee $0
                 (struct.get $type27 0
                  (local.get $5)
                 )
                )
                (local.tee $1
                 (struct.get $type27 1
                  (local.get $5)
                 )
                )
               )
               (block (result (ref $type28))
                (drop
                 (ref.as_non_null
                  (global.get $global236)
                 )
                )
                (local.set $scratch_15
                 (call $function77
                  (if (result (ref $type28))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type28 1
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (then
                    (local.get $0)
                   )
                   (else
                    (struct.new $type28
                     (i32.eqz
                      (struct.get $type28 0
                       (local.get $0)
                      )
                     )
                     (struct.get $type28 1
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (local.get $1)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global211)
                 )
                )
                (local.get $scratch_15)
               )
              )
              (block (result (ref $type28))
               (drop
                (ref.as_non_null
                 (global.get $global236)
                )
               )
               (local.set $scratch_16
                (call $function77
                 (local.get $1)
                 (local.get $1)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global540)
                )
               )
               (local.get $scratch_16)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global578)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global171)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global167)
             )
            )
            (if (result i32)
             (i64.eqz
              (call $function59
               (struct.get $type27 0
                (local.get $5)
               )
               (struct.get $type27 0
                (local.get $6)
               )
              )
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global171)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global167)
               )
              )
              (i64.eqz
               (call $function59
                (struct.get $type27 1
                 (local.get $5)
                )
                (struct.get $type27 1
                 (local.get $6)
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready883)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global883)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global765)
   )
  )
  (local.set $10
   (call $function219
    (local.tee $11
     (struct.new $type25
      (i32.const 0)
      (i64.const -9223372036854775808)
     )
    )
    (struct.new $type25
     (i32.const 0)
     (i64.const -1)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (local.set $8
   (call $function177
    (block (result (ref $type27))
     (local.set $scratch_18
      (call $function153
       (call $function53
        (i64.const 1)
       )
       (block (result (ref $type28))
        (drop
         (ref.as_non_null
          (global.get $global141)
         )
        )
        (local.set $scratch_17
         (call $function53
          (i64.const 3)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global540)
         )
        )
        (local.get $scratch_17)
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global614)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global606)
      )
     )
     (local.get $scratch_18)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global608)
   )
  )
  (local.set $9
   (if (result (ref $type24))
    (local.tee $12
     (struct.get $type32 0
      (local.get $8)
     )
    )
    (then
     (if (result (ref $type24))
      (i32.eq
       (local.get $12)
       (i32.const 1)
      )
      (then
       (struct.new $type26
        (i32.const 1)
        (struct.get $type34 1
         (ref.cast (ref $type34)
          (local.get $8)
         )
        )
       )
      )
      (else
       (struct.new $type30
        (i32.const 2)
        (struct.get $type35 1
         (ref.cast (ref $type35)
          (local.get $8)
         )
        )
       )
      )
     )
    )
    (else
     (struct.new $type25
      (i32.const 0)
      (struct.get $type33 1
       (ref.cast (ref $type33)
        (local.get $8)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global878)
   )
  )
  (local.set $3
   (call $function238
    (local.get $10)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global101)
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (if (result i32)
      (i64.eq
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $3)
        )
       )
       (i64.const 19)
      )
      (then
       (call $function40
        (local.get $3)
        (global.get $string6)
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global753)
       )
      )
      (if (result i32)
       (call $function222
        (call $function216
         (local.get $11)
        )
        (block (result (ref $type24))
         (drop
          (ref.as_non_null
           (global.get $global784)
          )
         )
         (local.get $10)
        )
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global790)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global674)
         )
        )
        (if (result i32)
         (i64.eq
          (call $function221
           (call $function190
            (local.get $9)
           )
           (block (result (ref $type32))
            (drop
             (ref.as_non_null
              (global.get $global674)
             )
            )
            (local.set $scratch_19
             (call $function190
              (struct.new $type30
               (i32.const 2)
               (f64.const 0.3333333333333333)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global779)
             )
            )
            (local.get $scratch_19)
           )
          )
          (i64.const 1)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global750)
           )
          )
          (if (result i32)
           (call $function200
            (block (result (ref $type24))
             (local.set $scratch_20
              (call $function215
               (local.get $9)
               (local.get $9)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global704)
              )
             )
             (local.get $scratch_20)
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global824)
             )
            )
            (i32.eqz
             (call $function230
              (struct.new $type30
               (i32.const 2)
               (f64.const 0.0)
              )
              (struct.new $type30
               (i32.const 2)
               (f64.const -0.0)
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

