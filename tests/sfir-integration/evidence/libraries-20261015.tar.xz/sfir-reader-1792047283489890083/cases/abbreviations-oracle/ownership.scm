(same . #f) same "text" "text"
