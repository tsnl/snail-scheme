"" "λ😀" "a\n\t\r\a\b\\\"b" "a\x1f600;b" "ab
c"