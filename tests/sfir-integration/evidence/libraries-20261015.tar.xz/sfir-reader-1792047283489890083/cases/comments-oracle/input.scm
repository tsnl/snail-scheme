#| outer #| nested |# end |# #; #; a b c ;line
(d #; ignored e)