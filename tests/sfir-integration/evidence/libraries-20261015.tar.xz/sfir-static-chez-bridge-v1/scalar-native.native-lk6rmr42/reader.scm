(module
 (type $0 (func (param i32 i32) (result i32)))
 (type $1 (func (param i32) (result i32)))
 (rec
  (type $call31 (func (param i32 i32) (result i32)))
  (type $3 (func (param i32 i32 i32 i64 i32 i32 i64) (result i32)))
  (type $call30 (func (param i32 i32 i32) (result i32)))
  (type $call28 (func (param i32) (result i32)))
  (type $call27 (func (param i64) (result i32)))
  (type $7 (func (param i32 i32 i64 i64) (result i32)))
  (type $8 (func (param i32 i64 i32 i32 i64) (result i32)))
  (type $call4 (func (result i32)))
  (type $type0 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type4 (struct))
 )
 (type $18 (func (param i32)))
 (type $19 (func (param i32 i32) (result i64)))
 (type $20 (func (result i32)))
 (type $21 (func (param i32) (result i64)))
 (type $22 (func (param i32 i64) (result i32)))
 (type $23 (func (param i32 i32)))
 (type $24 (func (param f64) (result i32)))
 (type $25 (func (param i32 i32 i32) (result i32)))
 (type $26 (func (param i32 i32 i32 i32) (result i32)))
 (type $27 (func (param i32 i32) (result f64)))
 (type $28 (func (param i64 f64) (result f64)))
 (type $29 (func))
 (import "snail.library" "snail:datum/token-open" (func $foreign0 (result i32)))
 (import "oracle" "argument_length" (func $foreign1 (param i32) (result i64)))
 (import "oracle" "argument_character" (func $foreign2 (param i32 i64) (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign3 (param i32 i32)))
 (import "oracle" "emit_character" (func $foreign4 (param i32)))
 (import "snail.library" "snail:datum/token-text-length" (func $foreign5 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-text-character" (func $foreign6 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/real-text" (func $foreign7 (param f64) (result i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign8 (param i32)))
 (import "snail.library" "snail:datum/number-text-length" (func $foreign9 (param i32 i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-text-character" (func $foreign10 (param i32 i32 i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-scale" (func $foreign11 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-radix" (func $foreign12 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign13 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign14 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign15 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/error-length" (func $foreign16 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign17 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse-radix" (func $foreign18 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-intern" (func $foreign19 (param i32) (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $global106 (mut (ref null $type4)) (ref.null none))
 (global $global111 (mut (ref null $type4)) (ref.null none))
 (global $global115 (mut (ref null $type27)) (ref.null none))
 (global $ready115 (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type27)) (ref.null none))
 (global $global119 (mut (ref null $type28)) (ref.null none))
 (global $global124 (mut (ref null $type29)) (ref.null none))
 (global $global127 (mut (ref null $type30)) (ref.null none))
 (global $global134 (mut (ref null $type31)) (ref.null none))
 (global $global137 (mut (ref null $type31)) (ref.null none))
 (global $global141 (mut (ref null $type28)) (ref.null none))
 (global $global146 (mut (ref null $type32)) (ref.null none))
 (global $global152 (mut (ref null $type27)) (ref.null none))
 (global $global149 (mut (ref null $type0)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (export "probe" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call4) (result i32)
  (local $0 i32)
  (local $1 i64)
  (local.set $0
   (call $foreign0)
  )
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (call $foreign1
      (i32.const 0)
     )
    )
   )
   (then
    (local.get $0)
   )
   (else
    (call $foreign3
     (local.get $0)
     (call $foreign2
      (i32.const 0)
      (i64.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (local.get $0)
     )
     (else
      (call $foreign3
       (local.get $0)
       (call $foreign2
        (i32.const 0)
        (i64.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (local.get $0)
       )
       (else
        (call $foreign3
         (local.get $0)
         (call $foreign2
          (i32.const 0)
          (i64.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (local.get $0)
         )
         (else
          (call $foreign3
           (local.get $0)
           (call $foreign2
            (i32.const 0)
            (i64.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (local.get $0)
           )
           (else
            (call $foreign3
             (local.get $0)
             (call $foreign2
              (i32.const 0)
              (i64.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (local.get $0)
             )
             (else
              (call $foreign3
               (local.get $0)
               (call $foreign2
                (i32.const 0)
                (i64.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (local.get $0)
               )
               (else
                (call $foreign3
                 (local.get $0)
                 (call $foreign2
                  (i32.const 0)
                  (i64.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (local.get $0)
                 )
                 (else
                  (call $foreign3
                   (local.get $0)
                   (call $foreign2
                    (i32.const 0)
                    (i64.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (local.get $0)
                   )
                   (else
                    (call $foreign3
                     (local.get $0)
                     (call $foreign2
                      (i32.const 0)
                      (i64.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (local.get $0)
                     )
                     (else
                      (call $foreign3
                       (local.get $0)
                       (call $foreign2
                        (i32.const 0)
                        (i64.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (local.get $0)
                       )
                       (else
                        (call $foreign3
                         (local.get $0)
                         (call $foreign2
                          (i32.const 0)
                          (i64.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 11)
                         )
                         (then
                          (local.get $0)
                         )
                         (else
                          (call $foreign3
                           (local.get $0)
                           (call $foreign2
                            (i32.const 0)
                            (i64.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 12)
                           )
                           (then
                            (local.get $0)
                           )
                           (else
                            (call $foreign3
                             (local.get $0)
                             (call $foreign2
                              (i32.const 0)
                              (i64.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 13)
                             )
                             (then
                              (local.get $0)
                             )
                             (else
                              (call $foreign3
                               (local.get $0)
                               (call $foreign2
                                (i32.const 0)
                                (i64.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 14)
                               )
                               (then
                                (local.get $0)
                               )
                               (else
                                (call $foreign3
                                 (local.get $0)
                                 (call $foreign2
                                  (i32.const 0)
                                  (i64.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 15)
                                 )
                                 (then
                                  (local.get $0)
                                 )
                                 (else
                                  (call $foreign3
                                   (local.get $0)
                                   (call $foreign2
                                    (i32.const 0)
                                    (i64.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 16)
                                   )
                                   (then
                                    (local.get $0)
                                   )
                                   (else
                                    (call $foreign3
                                     (local.get $0)
                                     (call $foreign2
                                      (i32.const 0)
                                      (i64.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $1)
                                      (i64.const 17)
                                     )
                                     (then
                                      (local.get $0)
                                     )
                                     (else
                                      (call $foreign3
                                       (local.get $0)
                                       (call $foreign2
                                        (i32.const 0)
                                        (i64.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 18)
                                       )
                                       (then
                                        (local.get $0)
                                       )
                                       (else
                                        (call $foreign3
                                         (local.get $0)
                                         (call $foreign2
                                          (i32.const 0)
                                          (i64.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $1)
                                          (i64.const 19)
                                         )
                                         (then
                                          (local.get $0)
                                         )
                                         (else
                                          (call $foreign3
                                           (local.get $0)
                                           (call $foreign2
                                            (i32.const 0)
                                            (i64.const 19)
                                           )
                                          )
                                          (return_call $function42
                                           (local.get $0)
                                           (local.get $1)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $8) (param $0 i32) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $0)
   )
   (else
    (call $foreign3
     (local.get $0)
     (call $foreign2
      (i32.const 0)
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function43 (type $call4) (result i32)
  (local $0 i64)
  (if (result i32)
   (i64.eqz
    (call $foreign1
     (i32.const 1)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $0
     (i64.sub
      (i64.extend_i32_u
       (call $foreign2
        (i32.const 1)
        (i64.const 0)
       )
      )
      (i64.const 48)
     )
    )
    (if (result i32)
     (i64.eq
      (call $foreign1
       (i32.const 1)
      )
      (i64.const 1)
     )
     (then
      (i32.wrap_i64
       (local.get $0)
      )
     )
     (else
      (local.set $0
       (i64.add
        (i64.sub
         (i64.extend_i32_u
          (call $foreign2
           (i32.const 1)
           (i64.const 1)
          )
         )
         (i64.const 48)
        )
        (i64.mul
         (local.get $0)
         (i64.const 10)
        )
       )
      )
      (if (result i32)
       (i64.eq
        (call $foreign1
         (i32.const 1)
        )
        (i64.const 2)
       )
       (then
        (i32.wrap_i64
         (local.get $0)
        )
       )
       (else
        (local.set $0
         (i64.add
          (i64.sub
           (i64.extend_i32_u
            (call $foreign2
             (i32.const 1)
             (i64.const 2)
            )
           )
           (i64.const 48)
          )
          (i64.mul
           (local.get $0)
           (i64.const 10)
          )
         )
        )
        (if (result i32)
         (i64.eq
          (call $foreign1
           (i32.const 1)
          )
          (i64.const 3)
         )
         (then
          (i32.wrap_i64
           (local.get $0)
          )
         )
         (else
          (local.set $0
           (i64.add
            (i64.sub
             (i64.extend_i32_u
              (call $foreign2
               (i32.const 1)
               (i64.const 3)
              )
             )
             (i64.const 48)
            )
            (i64.mul
             (local.get $0)
             (i64.const 10)
            )
           )
          )
          (if (result i32)
           (i64.eq
            (call $foreign1
             (i32.const 1)
            )
            (i64.const 4)
           )
           (then
            (i32.wrap_i64
             (local.get $0)
            )
           )
           (else
            (local.set $0
             (i64.add
              (i64.sub
               (i64.extend_i32_u
                (call $foreign2
                 (i32.const 1)
                 (i64.const 4)
                )
               )
               (i64.const 48)
              )
              (i64.mul
               (local.get $0)
               (i64.const 10)
              )
             )
            )
            (if (result i32)
             (i64.eq
              (call $foreign1
               (i32.const 1)
              )
              (i64.const 5)
             )
             (then
              (i32.wrap_i64
               (local.get $0)
              )
             )
             (else
              (local.set $0
               (i64.add
                (i64.sub
                 (i64.extend_i32_u
                  (call $foreign2
                   (i32.const 1)
                   (i64.const 5)
                  )
                 )
                 (i64.const 48)
                )
                (i64.mul
                 (local.get $0)
                 (i64.const 10)
                )
               )
              )
              (if (result i32)
               (i64.eq
                (call $foreign1
                 (i32.const 1)
                )
                (i64.const 6)
               )
               (then
                (i32.wrap_i64
                 (local.get $0)
                )
               )
               (else
                (local.set $0
                 (i64.add
                  (i64.sub
                   (i64.extend_i32_u
                    (call $foreign2
                     (i32.const 1)
                     (i64.const 6)
                    )
                   )
                   (i64.const 48)
                  )
                  (i64.mul
                   (local.get $0)
                   (i64.const 10)
                  )
                 )
                )
                (if (result i32)
                 (i64.eq
                  (call $foreign1
                   (i32.const 1)
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.wrap_i64
                   (local.get $0)
                  )
                 )
                 (else
                  (local.set $0
                   (i64.add
                    (i64.sub
                     (i64.extend_i32_u
                      (call $foreign2
                       (i32.const 1)
                       (i64.const 7)
                      )
                     )
                     (i64.const 48)
                    )
                    (i64.mul
                     (local.get $0)
                     (i64.const 10)
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (call $foreign1
                     (i32.const 1)
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.wrap_i64
                     (local.get $0)
                    )
                   )
                   (else
                    (local.set $0
                     (i64.add
                      (i64.sub
                       (i64.extend_i32_u
                        (call $foreign2
                         (i32.const 1)
                         (i64.const 8)
                        )
                       )
                       (i64.const 48)
                      )
                      (i64.mul
                       (local.get $0)
                       (i64.const 10)
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (call $foreign1
                       (i32.const 1)
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.wrap_i64
                       (local.get $0)
                      )
                     )
                     (else
                      (local.set $0
                       (i64.add
                        (i64.sub
                         (i64.extend_i32_u
                          (call $foreign2
                           (i32.const 1)
                           (i64.const 9)
                          )
                         )
                         (i64.const 48)
                        )
                        (i64.mul
                         (local.get $0)
                         (i64.const 10)
                        )
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (call $foreign1
                         (i32.const 1)
                        )
                        (i64.const 10)
                       )
                       (then
                        (i32.wrap_i64
                         (local.get $0)
                        )
                       )
                       (else
                        (local.set $0
                         (i64.add
                          (i64.sub
                           (i64.extend_i32_u
                            (call $foreign2
                             (i32.const 1)
                             (i64.const 10)
                            )
                           )
                           (i64.const 48)
                          )
                          (i64.mul
                           (local.get $0)
                           (i64.const 10)
                          )
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (call $foreign1
                           (i32.const 1)
                          )
                          (i64.const 11)
                         )
                         (then
                          (i32.wrap_i64
                           (local.get $0)
                          )
                         )
                         (else
                          (local.set $0
                           (i64.add
                            (i64.sub
                             (i64.extend_i32_u
                              (call $foreign2
                               (i32.const 1)
                               (i64.const 11)
                              )
                             )
                             (i64.const 48)
                            )
                            (i64.mul
                             (local.get $0)
                             (i64.const 10)
                            )
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (call $foreign1
                             (i32.const 1)
                            )
                            (i64.const 12)
                           )
                           (then
                            (i32.wrap_i64
                             (local.get $0)
                            )
                           )
                           (else
                            (local.set $0
                             (i64.add
                              (i64.sub
                               (i64.extend_i32_u
                                (call $foreign2
                                 (i32.const 1)
                                 (i64.const 12)
                                )
                               )
                               (i64.const 48)
                              )
                              (i64.mul
                               (local.get $0)
                               (i64.const 10)
                              )
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (call $foreign1
                               (i32.const 1)
                              )
                              (i64.const 13)
                             )
                             (then
                              (i32.wrap_i64
                               (local.get $0)
                              )
                             )
                             (else
                              (local.set $0
                               (i64.add
                                (i64.sub
                                 (i64.extend_i32_u
                                  (call $foreign2
                                   (i32.const 1)
                                   (i64.const 13)
                                  )
                                 )
                                 (i64.const 48)
                                )
                                (i64.mul
                                 (local.get $0)
                                 (i64.const 10)
                                )
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (call $foreign1
                                 (i32.const 1)
                                )
                                (i64.const 14)
                               )
                               (then
                                (i32.wrap_i64
                                 (local.get $0)
                                )
                               )
                               (else
                                (local.set $0
                                 (i64.add
                                  (i64.sub
                                   (i64.extend_i32_u
                                    (call $foreign2
                                     (i32.const 1)
                                     (i64.const 14)
                                    )
                                   )
                                   (i64.const 48)
                                  )
                                  (i64.mul
                                   (local.get $0)
                                   (i64.const 10)
                                  )
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (call $foreign1
                                   (i32.const 1)
                                  )
                                  (i64.const 15)
                                 )
                                 (then
                                  (i32.wrap_i64
                                   (local.get $0)
                                  )
                                 )
                                 (else
                                  (local.set $0
                                   (i64.add
                                    (i64.sub
                                     (i64.extend_i32_u
                                      (call $foreign2
                                       (i32.const 1)
                                       (i64.const 15)
                                      )
                                     )
                                     (i64.const 48)
                                    )
                                    (i64.mul
                                     (local.get $0)
                                     (i64.const 10)
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (call $foreign1
                                     (i32.const 1)
                                    )
                                    (i64.const 16)
                                   )
                                   (then
                                    (i32.wrap_i64
                                     (local.get $0)
                                    )
                                   )
                                   (else
                                    (local.set $0
                                     (i64.add
                                      (i64.sub
                                       (i64.extend_i32_u
                                        (call $foreign2
                                         (i32.const 1)
                                         (i64.const 16)
                                        )
                                       )
                                       (i64.const 48)
                                      )
                                      (i64.mul
                                       (local.get $0)
                                       (i64.const 10)
                                      )
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (call $foreign1
                                       (i32.const 1)
                                      )
                                      (i64.const 17)
                                     )
                                     (then
                                      (i32.wrap_i64
                                       (local.get $0)
                                      )
                                     )
                                     (else
                                      (local.set $0
                                       (i64.add
                                        (i64.sub
                                         (i64.extend_i32_u
                                          (call $foreign2
                                           (i32.const 1)
                                           (i64.const 17)
                                          )
                                         )
                                         (i64.const 48)
                                        )
                                        (i64.mul
                                         (local.get $0)
                                         (i64.const 10)
                                        )
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (call $foreign1
                                         (i32.const 1)
                                        )
                                        (i64.const 18)
                                       )
                                       (then
                                        (i32.wrap_i64
                                         (local.get $0)
                                        )
                                       )
                                       (else
                                        (local.set $0
                                         (i64.add
                                          (i64.sub
                                           (i64.extend_i32_u
                                            (call $foreign2
                                             (i32.const 1)
                                             (i64.const 18)
                                            )
                                           )
                                           (i64.const 48)
                                          )
                                          (i64.mul
                                           (local.get $0)
                                           (i64.const 10)
                                          )
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (call $foreign1
                                           (i32.const 1)
                                          )
                                          (i64.const 19)
                                         )
                                         (then
                                          (i32.wrap_i64
                                           (local.get $0)
                                          )
                                         )
                                         (else
                                          (return_call $function44
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                           (i64.add
                                            (i64.sub
                                             (i64.extend_i32_u
                                              (call $foreign2
                                               (i32.const 1)
                                               (i64.const 19)
                                              )
                                             )
                                             (i64.const 48)
                                            )
                                            (i64.mul
                                             (local.get $0)
                                             (i64.const 10)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function44 (type $7) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (call $foreign1
     (i32.const 1)
    )
    (local.get $2)
   )
   (then
    (i32.wrap_i64
     (local.get $3)
    )
   )
   (else
    (local.set $4
     (call $foreign2
      (i32.const 1)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
     (i64.add
      (i64.sub
       (i64.extend_i32_u
        (local.get $4)
       )
       (i64.const 48)
      )
      (i64.mul
       (local.get $3)
       (i64.const 10)
      )
     )
    )
   )
  )
 )
 (func $function45 (type $call27) (param $0 i64) (result i32)
  (if
   (i64.le_s
    (local.get $0)
    (i64.const -10)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready115)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (drop
     (call $function45
      (i64.div_s
       (local.get $0)
       (i64.const 10)
      )
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (i64.sub
      (i64.const 48)
      (i64.rem_s
       (local.get $0)
       (i64.const 10)
      )
     )
    )
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $0)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $0)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (call $foreign4
   (i32.wrap_i64
    (local.get $0)
   )
  )
  (i32.const 0)
 )
 (func $function47 (type $call28) (param $0 i32) (result i32)
  (local $1 i64)
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_s
      (call $foreign5
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign4
     (call $foreign6
      (local.get $0)
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (call $foreign4
       (call $foreign6
        (local.get $0)
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (call $foreign4
         (call $foreign6
          (local.get $0)
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (call $foreign4
           (call $foreign6
            (local.get $0)
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (call $foreign4
             (call $foreign6
              (local.get $0)
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (call $foreign4
               (call $foreign6
                (local.get $0)
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (call $foreign4
                 (call $foreign6
                  (local.get $0)
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (call $foreign4
                   (call $foreign6
                    (local.get $0)
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign4
                     (call $foreign6
                      (local.get $0)
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign4
                       (call $foreign6
                        (local.get $0)
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (call $foreign4
                         (call $foreign6
                          (local.get $0)
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (call $foreign4
                           (call $foreign6
                            (local.get $0)
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (call $foreign4
                             (call $foreign6
                              (local.get $0)
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (call $foreign4
                               (call $foreign6
                                (local.get $0)
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (call $foreign4
                                 (call $foreign6
                                  (local.get $0)
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 15)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (call $foreign4
                                   (call $foreign6
                                    (local.get $0)
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 16)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (call $foreign4
                                     (call $foreign6
                                      (local.get $0)
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $1)
                                      (i64.const 17)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (call $foreign4
                                       (call $foreign6
                                        (local.get $0)
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 18)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (call $foreign4
                                         (call $foreign6
                                          (local.get $0)
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $1)
                                          (i64.const 19)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (call $foreign4
                                           (call $foreign6
                                            (local.get $0)
                                            (i32.const 19)
                                           )
                                          )
                                          (return_call $function48
                                           (local.get $0)
                                           (local.get $1)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function48 (type $8) (param $0 i32) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign4
     (call $foreign6
      (local.get $0)
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function50 (type $call30) (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i64)
  (if (result i32)
   (i64.eqz
    (local.tee $3
     (i64.extend_i32_s
      (call $foreign9
       (local.get $0)
       (local.get $1)
       (local.get $2)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign4
     (call $foreign10
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $3)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (call $foreign4
       (call $foreign10
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $3)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (call $foreign4
         (call $foreign10
          (local.get $0)
          (local.get $1)
          (local.get $2)
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $3)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (call $foreign4
           (call $foreign10
            (local.get $0)
            (local.get $1)
            (local.get $2)
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $3)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (call $foreign4
             (call $foreign10
              (local.get $0)
              (local.get $1)
              (local.get $2)
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $3)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (call $foreign4
               (call $foreign10
                (local.get $0)
                (local.get $1)
                (local.get $2)
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $3)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (call $foreign4
                 (call $foreign10
                  (local.get $0)
                  (local.get $1)
                  (local.get $2)
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $3)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (call $foreign4
                   (call $foreign10
                    (local.get $0)
                    (local.get $1)
                    (local.get $2)
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $3)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign4
                     (call $foreign10
                      (local.get $0)
                      (local.get $1)
                      (local.get $2)
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $3)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign4
                       (call $foreign10
                        (local.get $0)
                        (local.get $1)
                        (local.get $2)
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $3)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (call $foreign4
                         (call $foreign10
                          (local.get $0)
                          (local.get $1)
                          (local.get $2)
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $3)
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (call $foreign4
                           (call $foreign10
                            (local.get $0)
                            (local.get $1)
                            (local.get $2)
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $3)
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (call $foreign4
                             (call $foreign10
                              (local.get $0)
                              (local.get $1)
                              (local.get $2)
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $3)
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (call $foreign4
                               (call $foreign10
                                (local.get $0)
                                (local.get $1)
                                (local.get $2)
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $3)
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (call $foreign4
                                 (call $foreign10
                                  (local.get $0)
                                  (local.get $1)
                                  (local.get $2)
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $3)
                                  (i64.const 15)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (call $foreign4
                                   (call $foreign10
                                    (local.get $0)
                                    (local.get $1)
                                    (local.get $2)
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $3)
                                    (i64.const 16)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (call $foreign4
                                     (call $foreign10
                                      (local.get $0)
                                      (local.get $1)
                                      (local.get $2)
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $3)
                                      (i64.const 17)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (call $foreign4
                                       (call $foreign10
                                        (local.get $0)
                                        (local.get $1)
                                        (local.get $2)
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $3)
                                        (i64.const 18)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (call $foreign4
                                         (call $foreign10
                                          (local.get $0)
                                          (local.get $1)
                                          (local.get $2)
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $3)
                                          (i64.const 19)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (call $foreign4
                                           (call $foreign10
                                            (local.get $0)
                                            (local.get $1)
                                            (local.get $2)
                                            (i32.const 19)
                                           )
                                          )
                                          (return_call $function51
                                           (local.get $0)
                                           (local.get $1)
                                           (local.get $2)
                                           (local.get $3)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function51 (type $3) (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i64) (result i32)
  (if (result i32)
   (i64.eq
    (local.get $3)
    (local.get $6)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign4
     (call $foreign10
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (i32.wrap_i64
       (local.get $6)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function51
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function52 (type $call31) (param $0 i32) (param $1 i32) (result i32)
  (local $2 i64)
  (local.set $2
   (i64.extend_i32_s
    (call $foreign12
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (if
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (call $foreign4
     (i32.const 45)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (drop
   (call $function45
    (select
     (local.get $2)
     (i64.sub
      (i64.const 0)
      (local.get $2)
     )
     (i64.lt_s
      (local.get $2)
      (i64.const 0)
     )
    )
   )
  )
  (call $foreign4
   (i32.const 58)
  )
  (local.set $2
   (call $foreign11
    (local.get $0)
    (local.get $1)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (if
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (call $foreign4
     (i32.const 45)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (drop
   (call $function45
    (select
     (local.get $2)
     (i64.sub
      (i64.const 0)
      (local.get $2)
     )
     (i64.lt_s
      (local.get $2)
      (i64.const 0)
     )
    )
   )
  )
  (call $foreign4
   (i32.const 58)
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function50
    (local.get $0)
    (local.get $1)
    (i32.const 0)
   )
  )
  (call $foreign4
   (i32.const 47)
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (return_call $function50
   (local.get $0)
   (local.get $1)
   (i32.const 1)
  )
 )
 (func $function53 (type $call31) (param $0 i32) (param $1 i32) (result i32)
  (local $2 i64)
  (local $3 f64)
  (local $scratch f64)
  (local.set $2
   (i64.extend_i32_s
    (call $foreign13
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (call $foreign4
   (i32.const 124)
  )
  (drop
   (ref.as_non_null
    (global.get $global117)
   )
  )
  (if
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (call $foreign4
     (i32.const 45)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global115)
   )
  )
  (drop
   (call $function45
    (select
     (local.get $2)
     (i64.sub
      (i64.const 0)
      (local.get $2)
     )
     (i64.lt_s
      (local.get $2)
      (i64.const 0)
     )
    )
   )
  )
  (call $foreign4
   (i32.const 58)
  )
  (if (result i32)
   (i64.eq
    (local.get $2)
    (i64.const 1)
   )
   (then
    (local.set $2
     (call $foreign15
      (local.get $0)
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (if
     (i64.lt_s
      (local.get $2)
      (i64.const 0)
     )
     (then
      (call $foreign4
       (i32.const 45)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global115)
     )
    )
    (return_call $function45
     (select
      (local.get $2)
      (i64.sub
       (i64.const 0)
       (local.get $2)
      )
      (i64.lt_s
       (local.get $2)
       (i64.const 0)
      )
     )
    )
   )
   (else
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 2)
     )
     (then
      (local.set $0
       (call $foreign7
        (block (result f64)
         (local.set $scratch
          (call $foreign14
           (local.get $0)
           (local.get $1)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global124)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global119)
       )
      )
      (drop
       (call $function47
        (local.get $0)
       )
      )
      (call $foreign8
       (local.get $0)
      )
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (return_call $function52
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function54 (type $call28) (param $0 i32) (result i32)
  (local $1 i64)
  (call $foreign4
   (i32.const 124)
  )
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_s
      (call $foreign16
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign4
     (call $foreign17
      (local.get $0)
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (call $foreign4
       (call $foreign17
        (local.get $0)
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (call $foreign4
         (call $foreign17
          (local.get $0)
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (call $foreign4
           (call $foreign17
            (local.get $0)
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (call $foreign4
             (call $foreign17
              (local.get $0)
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (call $foreign4
               (call $foreign17
                (local.get $0)
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (call $foreign4
                 (call $foreign17
                  (local.get $0)
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (call $foreign4
                   (call $foreign17
                    (local.get $0)
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign4
                     (call $foreign17
                      (local.get $0)
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign4
                       (call $foreign17
                        (local.get $0)
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (call $foreign4
                         (call $foreign17
                          (local.get $0)
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (call $foreign4
                           (call $foreign17
                            (local.get $0)
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (call $foreign4
                             (call $foreign17
                              (local.get $0)
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (call $foreign4
                               (call $foreign17
                                (local.get $0)
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (call $foreign4
                                 (call $foreign17
                                  (local.get $0)
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 15)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (call $foreign4
                                   (call $foreign17
                                    (local.get $0)
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 16)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (call $foreign4
                                     (call $foreign17
                                      (local.get $0)
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $1)
                                      (i64.const 17)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (call $foreign4
                                       (call $foreign17
                                        (local.get $0)
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 18)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (call $foreign4
                                         (call $foreign17
                                          (local.get $0)
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $1)
                                          (i64.const 19)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (call $foreign4
                                           (call $foreign17
                                            (local.get $0)
                                            (i32.const 19)
                                           )
                                          )
                                          (return_call $function55
                                           (local.get $0)
                                           (local.get $1)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function55 (type $8) (param $0 i32) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign4
     (call $foreign17
      (local.get $0)
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function55
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (param $1 f64) (result f64)
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (local $scratch f64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready149)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global149)
   )
  )
  (if
   (i64.eq
    (local.get $0)
    (i64.const 1)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (local.set $2
     (call $foreign7
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global119)
     )
    )
    (drop
     (call $function47
      (local.get $2)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global152)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global106)
     )
    )
    (local.set $4
     (i64.extend_i32_s
      (call $foreign18
       (local.tee $2
        (call $function41)
       )
       (block (result i32)
        (drop
         (ref.as_non_null
          (global.get $global111)
         )
        )
        (call $function43)
       )
      )
     )
    )
    (drop
     (if (result i32)
      (i64.eqz
       (local.get $0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global146)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global117)
        )
       )
       (if
        (i64.lt_s
         (local.get $4)
         (i64.const 0)
        )
        (then
         (call $foreign4
          (i32.const 45)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global115)
        )
       )
       (drop
        (call $function45
         (select
          (local.get $4)
          (i64.sub
           (i64.const 0)
           (local.get $4)
          )
          (i64.lt_s
           (local.get $4)
           (i64.const 0)
          )
         )
        )
       )
       (if (result i32)
        (i64.eq
         (local.get $4)
         (i64.const 4)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global141)
          )
         )
         (call $function54
          (local.get $2)
         )
        )
        (else
         (if (result i32)
          (i64.eqz
           (local.get $4)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global137)
            )
           )
           (drop
            (call $function53
             (local.get $2)
             (i32.const 0)
            )
           )
           (if (result i32)
            (if (result i32)
             (i64.eq
              (local.get $4)
              (i64.const 3)
             )
             (then
              (i32.const 1)
             )
             (else
              (i32.or
               (i64.eq
                (local.get $4)
                (i64.const 8)
               )
               (i64.eq
                (local.get $4)
                (i64.const 7)
               )
              )
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global137)
              )
             )
             (call $function53
              (local.get $2)
              (i32.const 1)
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
         )
        )
       )
      )
      (else
       (if (result i32)
        (i64.eq
         (local.get $0)
         (i64.const 2)
        )
        (then
         (local.set $0
          (call $foreign15
           (local.get $2)
           (i32.const 0)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global117)
          )
         )
         (if
          (i64.lt_s
           (local.get $0)
           (i64.const 0)
          )
          (then
           (call $foreign4
            (i32.const 45)
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global115)
          )
         )
         (call $function45
          (select
           (local.get $0)
           (i64.sub
            (i64.const 0)
            (local.get $0)
           )
           (i64.lt_s
            (local.get $0)
            (i64.const 0)
           )
          )
         )
        )
        (else
         (if (result i32)
          (i64.eq
           (local.get $0)
           (i64.const 3)
          )
          (then
           (local.set $3
            (call $foreign7
             (block (result f64)
              (local.set $scratch
               (call $foreign14
                (local.get $2)
                (i32.const 0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global124)
               )
              )
              (local.get $scratch)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global119)
            )
           )
           (drop
            (call $function47
             (local.get $3)
            )
           )
           (call $foreign8
            (local.get $3)
           )
           (i32.const 0)
          )
          (else
           (if (result i32)
            (i64.eq
             (local.get $0)
             (i64.const 4)
            )
            (then
             (call $foreign8
              (local.get $2)
             )
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i64.eq
               (local.get $0)
               (i64.const 5)
              )
              (then
               (drop
                (call $foreign18
                 (local.get $2)
                 (i32.const 10)
                )
               )
               (i32.const 0)
              )
              (else
               (if (result i32)
                (i64.eq
                 (local.get $0)
                 (i64.const 6)
                )
                (then
                 (call $foreign3
                  (local.get $2)
                  (i32.const 97)
                 )
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (i64.eq
                   (local.get $0)
                   (i64.const 7)
                  )
                  (then
                   (drop
                    (call $foreign19
                     (local.get $2)
                    )
                   )
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i64.eq
                     (local.get $0)
                     (i64.const 8)
                    )
                    (then
                     (call $foreign8
                      (local.get $2)
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global119)
                      )
                     )
                     (call $function47
                      (local.get $2)
                     )
                    )
                    (else
                     (if (result i32)
                      (i64.eq
                       (local.get $0)
                       (i64.const 9)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global134)
                        )
                       )
                       (call $function52
                        (local.get $2)
                        (i32.const 0)
                       )
                      )
                      (else
                       (if (result i32)
                        (i64.eq
                         (local.get $0)
                         (i64.const 10)
                        )
                        (then
                         (drop
                          (ref.as_non_null
                           (global.get $global137)
                          )
                         )
                         (call $function53
                          (local.get $2)
                          (i32.const 2)
                         )
                        )
                        (else
                         (call $foreign8
                          (local.get $2)
                         )
                         (if (result i32)
                          (i64.eq
                           (local.get $0)
                           (i64.const 11)
                          )
                          (then
                           (drop
                            (ref.as_non_null
                             (global.get $global137)
                            )
                           )
                           (call $function53
                            (local.get $2)
                            (i32.const 0)
                           )
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global141)
                            )
                           )
                           (call $function54
                            (local.get $2)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (call $foreign8
   (local.get $2)
  )
  (f64.const 0.0)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type4)
  )
  (global.set $global111
   (struct.new_default $type4)
  )
  (global.set $global115
   (struct.new_default $type27)
  )
  (global.set $ready115
   (i32.const 1)
  )
  (global.set $global117
   (struct.new_default $type27)
  )
  (global.set $global119
   (struct.new_default $type28)
  )
  (global.set $global124
   (struct.new_default $type29)
  )
  (global.set $global127
   (struct.new_default $type30)
  )
  (global.set $global134
   (struct.new_default $type31)
  )
  (global.set $global137
   (struct.new_default $type31)
  )
  (global.set $global141
   (struct.new_default $type28)
  )
  (global.set $global146
   (struct.new_default $type32)
  )
  (global.set $global152
   (struct.new_default $type27)
  )
  (global.set $global149
   (struct.new_default $type0)
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

