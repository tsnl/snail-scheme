(module
 (rec
  (type $0 (func (param (ref $type16) i32 i32 i64) (result (ref $type80))))
  (type $1 (func (param (ref $type16) i32 i32 i64) (result i32)))
  (type $call92 (func (param (ref $type16)) (result i32)))
  (type $3 (func (param i32 i64 (ref $type16) i32 i32 i64) (result (ref $type16))))
  (type $4 (func (param i32 i32 f64 i64) (result (ref $type80))))
  (type $type80 (struct (field (ref $type29)) (field (ref $type29))))
  (type $call79 (func (param (ref $type29) (ref $type29)) (result (ref $type80))))
  (type $7 (func (param i32 i32 (ref $type29) (ref $type29)) (result (ref $type29))))
  (type $call77 (func (param (ref $type29) (ref $type29)) (result f64)))
  (type $9 (func (param f64 i32 i32 i64 f64) (result f64)))
  (type $call74 (func (param i64) (result f64)))
  (type $11 (func (param i32 (ref $type14) f64 i32 i32 f64 i64) (result (ref $type29))))
  (type $call73 (func (param f64) (result (ref $type29))))
  (type $13 (func (param i32 i32 f64 i64) (result i64)))
  (type $call72 (func (param f64) (result i64)))
  (type $15 (func (param i32 i32 (ref $type29) (ref $type29) (ref $type29)) (result (ref $type29))))
  (type $type12 (struct))
  (type $call67 (func (param (ref $type29)) (result (ref $type16))))
  (type $call66 (func (param (ref $type16) i64 (ref null $type63)) (result i32)))
  (type $19 (func (param (ref $type16) i32 i32 i64 i64 i64) (result i32)))
  (type $20 (func (param i32 i32 (ref null $type63) i64) (result i64)))
  (type $call64 (func (param (ref null $type63)) (result i64)))
  (type $22 (func (param i32 i32 (ref $type14) (ref $type63)) (result (ref null $type63))))
  (type $type63 (struct (field i64) (field (ref null $type63))))
  (type $call62 (func (param (ref $type14)) (result (ref null $type63))))
  (type $call58 (func (param (ref $type16)) (result (ref $type29))))
  (type $26 (func (param (ref $type16) i32 i64 i32 i32 i64 (ref $type29)) (result (ref $type29))))
  (type $27 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $28 (func (param i64) (result i64)))
  (type $29 (func (param (ref $type16) i64 i32 i32 i64 i64) (result i64)))
  (type $call45 (func (param (ref $type29) (ref $type29)) (result (ref $type29))))
  (type $type53 (struct (field (ref $type29)) (field (ref $type29))))
  (type $32 (func (param (ref $type29) (ref $type29)) (result (ref $type53))))
  (type $33 (func (param (ref $type14) (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
  (type $34 (func (param (ref $type14) (ref $type14) (ref $type14)) (result i32)))
  (type $call48 (func (param (ref $type14) (ref $type14) i64) (result i64)))
  (type $36 (func (param (ref $type14) (ref $type14) i64 i64 i32 i32 i64 i64) (result i32)))
  (type $37 (func (param (ref $type14) (ref $type14) i64 i64 i64 i32 i32 i64 i64) (result i64)))
  (type $38 (func (param (ref $type14) (ref $type14) i64 i32 i32 i64 i64) (result i64)))
  (type $39 (func (param (ref $type14) (ref $type14)) (result i64)))
  (type $40 (func (param (ref $type14) i64 i64 (ref $type14) i32 i32 i64 i64) (result (ref $type14))))
  (type $41 (func (param (ref $type14) (ref $type14) (ref $type14) i32 i32 i64) (result (ref $type14))))
  (type $call43 (func (param (ref $type14) (ref $type14)) (result (ref $type14))))
  (type $43 (func (param (ref $type14) (ref $type14) i64 i64 i64 i32 i32 i64 i64) (result i32)))
  (type $call46 (func (param (ref $type14) (ref $type14) i64 i64) (result i32)))
  (type $45 (func (param (ref $type29) (ref $type29)) (result (ref $type29))))
  (type $46 (func (param (ref $type14) (ref $type14) i64 (ref $type14) i32 i32 i64 i64) (result (ref $type14))))
  (type $call41 (func (param (ref $type29) (ref $type29)) (result i64)))
  (type $48 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i64)))
  (type $49 (func (param (ref $type14) i32 i64 i32 i32 i64 i64) (result i64)))
  (type $50 (func (param i32 (ref $type14) i32 i32 i64 i64) (result (ref $type29))))
  (type $call38 (func (param i64) (result (ref $type29))))
  (type $52 (func (param i32 i32 i64 i64) (result i64)))
  (type $call37 (func (param i64) (result i64)))
  (type $call35 (func (param (ref $type29)) (result i32)))
  (type $55 (func (param i32 (ref $type14)) (result (ref $type29))))
  (type $call13 (func (param (ref $type14)) (result (ref $type14))))
  (type $57 (func (param (ref $type14) i32 i32 i64) (result i64)))
  (type $call33 (func (param (ref $type14)) (result i64)))
  (type $59 (func (param (ref $type14) i64 i64)))
  (type $type14 (array (mut i32)))
  (type $call30 (func (param (ref $type14) i64) (result i64)))
  (type $call27 (func (param (ref $type16) (ref null $type25) i64) (result i32)))
  (type $63 (func (param i32 i32 (ref null $type25) i64) (result i64)))
  (type $type25 (struct (field (ref $type16)) (field (ref null $type25))))
  (type $65 (func (param (ref $type25)) (result (ref $type16))))
  (type $66 (func (param (ref $type16) i32 i32 (ref null $type12) i64) (result (ref $type16))))
  (type $67 (func (param (ref $type16) i64 (ref $type16) i64 i64)))
  (type $68 (func (param (ref $type16) i32) (result (ref $type17))))
  (type $type18 (array (mut (ref null $type17))))
  (type $70 (func (param i32) (result (ref $type16))))
  (type $type0 (struct))
  (type $type94 (struct))
  (type $type93 (struct))
  (type $type92 (struct))
  (type $type91 (struct))
  (type $type90 (struct))
  (type $type89 (struct))
  (type $type88 (struct))
  (type $type86 (struct))
  (type $type85 (struct))
  (type $type84 (struct))
  (type $type83 (struct))
  (type $type82 (struct))
  (type $type81 (struct))
  (type $type79 (struct))
  (type $type78 (struct))
  (type $type77 (struct))
  (type $type76 (struct))
  (type $type75 (struct))
  (type $type74 (struct))
  (type $type73 (struct))
  (type $type72 (struct))
  (type $type71 (struct))
  (type $type68 (struct))
  (type $type67 (struct))
  (type $type66 (struct))
  (type $type65 (struct))
  (type $type64 (struct))
  (type $type62 (struct))
  (type $type58 (struct))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct (field i32) (field (ref $type14))))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type24 (struct))
  (type $type22 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type15 (struct))
  (type $type13 (struct))
  (type $type11 (struct))
  (type $type16 (struct (field i32) (field i32) (field (ref $type17)) (field (ref null $type18))))
  (type $type17 (array (mut i32)))
 )
 (type $140 (func (param i32) (result i64)))
 (type $141 (func (param i32 i64) (result i32)))
 (type $142 (func (param i32)))
 (type $143 (func (param (ref $type16) i32 i64 i32 i32 i64 (ref $type29)) (result (ref $type29))))
 (type $144 (func (param i64 f64) (result f64)))
 (type $145 (func))
 (import "oracle" "argument_length" (func $foreign0 (param i32) (result i64)))
 (import "oracle" "argument_character" (func $foreign1 (param i32 i64) (result i32)))
 (import "oracle" "emit_character" (func $foreign2 (param i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type16) (struct.new $type16
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type17 1
   (i32.const 47)
  )
  (ref.null none)
 ))
 (global $global68 (mut (ref null $type11)) (ref.null none))
 (global $global383 (mut (ref null $type13)) (ref.null none))
 (global $global61 (mut (ref null $type15)) (ref.null none))
 (global $global63 (mut (ref null $type19)) (ref.null none))
 (global $global65 (mut (ref null $type20)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type22)) (ref.null none))
 (global $global88 (mut (ref null $type24)) (ref.null none))
 (global $global91 (mut (ref null $type26)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global96 (mut (ref null $type27)) (ref.null none))
 (global $ready96 (mut i32) (i32.const 0))
 (global $global108 (mut (ref null $type29)) (ref.null none))
 (global $global109 (mut (ref null $type30)) (ref.null none))
 (global $global112 (mut (ref null $type31)) (ref.null none))
 (global $global116 (mut (ref null $type32)) (ref.null none))
 (global $global118 (mut (ref null $type33)) (ref.null none))
 (global $global122 (mut (ref null $type13)) (ref.null none))
 (global $global126 (mut (ref null $type34)) (ref.null none))
 (global $global130 (mut (ref null $type35)) (ref.null none))
 (global $global132 (mut (ref null $type36)) (ref.null none))
 (global $global134 (mut (ref null $type36)) (ref.null none))
 (global $global136 (mut (ref null $type37)) (ref.null none))
 (global $global141 (mut (ref null $type38)) (ref.null none))
 (global $global149 (mut (ref null $type39)) (ref.null none))
 (global $global158 (mut (ref null $type40)) (ref.null none))
 (global $global167 (mut (ref null $type41)) (ref.null none))
 (global $global171 (mut (ref null $type42)) (ref.null none))
 (global $global174 (mut (ref null $type42)) (ref.null none))
 (global $global186 (mut (ref null $type30)) (ref.null none))
 (global $global189 (mut (ref null $type43)) (ref.null none))
 (global $global198 (mut (ref null $type43)) (ref.null none))
 (global $global207 (mut (ref null $type44)) (ref.null none))
 (global $global211 (mut (ref null $type45)) (ref.null none))
 (global $global216 (mut (ref null $type45)) (ref.null none))
 (global $global219 (mut (ref null $type46)) (ref.null none))
 (global $global230 (mut (ref null $type43)) (ref.null none))
 (global $global236 (mut (ref null $type45)) (ref.null none))
 (global $global239 (mut (ref null $type47)) (ref.null none))
 (global $global248 (mut (ref null $type48)) (ref.null none))
 (global $global256 (mut (ref null $type48)) (ref.null none))
 (global $global268 (mut (ref null $type49)) (ref.null none))
 (global $global280 (mut (ref null $type50)) (ref.null none))
 (global $global289 (mut (ref null $type48)) (ref.null none))
 (global $global294 (mut (ref null $type51)) (ref.null none))
 (global $global300 (mut (ref null $type52)) (ref.null none))
 (global $global309 (mut (ref null $type54)) (ref.null none))
 (global $global316 (mut (ref null $type54)) (ref.null none))
 (global $global322 (mut (ref null $type45)) (ref.null none))
 (global $global325 (mut (ref null $type45)) (ref.null none))
 (global $global328 (mut (ref null $type55)) (ref.null none))
 (global $global336 (mut (ref null $type56)) (ref.null none))
 (global $global342 (mut (ref null $type57)) (ref.null none))
 (global $global353 (mut (ref null $type58)) (ref.null none))
 (global $global377 (mut (ref null $type62)) (ref.null none))
 (global $global387 (mut (ref null $type37)) (ref.null none))
 (global $global392 (mut (ref null $type64)) (ref.null none))
 (global $global397 (mut (ref null $type65)) (ref.null none))
 (global $global406 (mut (ref null $type66)) (ref.null none))
 (global $ready406 (mut i32) (i32.const 0))
 (global $global411 (mut (ref null $type67)) (ref.null none))
 (global $global417 (mut (ref null $type36)) (ref.null none))
 (global $global421 (mut (ref null $type45)) (ref.null none))
 (global $global430 (mut (ref null $type68)) (ref.null none))
 (global $global433 (mut (ref null $type37)) (ref.null none))
 (global $global454 (mut (ref null $type71)) (ref.null none))
 (global $global456 (mut (ref null $type72)) (ref.null none))
 (global $global461 (mut (ref null $type73)) (ref.null none))
 (global $global471 (mut (ref null $type73)) (ref.null none))
 (global $global473 (mut (ref null $type39)) (ref.null none))
 (global $global477 (mut (ref null $type38)) (ref.null none))
 (global $global479 (mut (ref null $type74)) (ref.null none))
 (global $global486 (mut (ref null $type75)) (ref.null none))
 (global $global490 (mut (ref null $type41)) (ref.null none))
 (global $global497 (mut (ref null $type76)) (ref.null none))
 (global $global502 (mut (ref null $type77)) (ref.null none))
 (global $global507 (mut (ref null $type77)) (ref.null none))
 (global $global511 (mut (ref null $type78)) (ref.null none))
 (global $global515 (mut (ref null $type45)) (ref.null none))
 (global $global521 (mut (ref null $type45)) (ref.null none))
 (global $global525 (mut (ref null $type45)) (ref.null none))
 (global $global539 (mut (ref null $type29)) (ref.null none))
 (global $global540 (mut (ref null $type79)) (ref.null none))
 (global $global547 (mut (ref null $type81)) (ref.null none))
 (global $global549 (mut (ref null $type82)) (ref.null none))
 (global $global555 (mut (ref null $type83)) (ref.null none))
 (global $global559 (mut (ref null $type84)) (ref.null none))
 (global $global562 (mut (ref null $type84)) (ref.null none))
 (global $global565 (mut (ref null $type84)) (ref.null none))
 (global $global568 (mut (ref null $type84)) (ref.null none))
 (global $global571 (mut (ref null $type85)) (ref.null none))
 (global $global573 (mut (ref null $type85)) (ref.null none))
 (global $global575 (mut (ref null $type86)) (ref.null none))
 (global $global593 (mut (ref null $type88)) (ref.null none))
 (global $global598 (mut (ref null $type89)) (ref.null none))
 (global $global600 (mut (ref null $type90)) (ref.null none))
 (global $global606 (mut (ref null $type91)) (ref.null none))
 (global $global612 (mut (ref null $type92)) (ref.null none))
 (global $global616 (mut (ref null $type93)) (ref.null none))
 (global $global626 (mut (ref null $type94)) (ref.null none))
 (global $global623 (mut (ref null $type0)) (ref.null none))
 (global $global620 (mut (ref null $type0)) (ref.null none))
 (global $ready620 (mut i32) (i32.const 0))
 (export "probe" (func $export0))
 (export "main" (func $main))
 (func $string-new (type $70) (param $0 i32) (result (ref $type16))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type18))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type18
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type18
      (local.get $5)
      (local.get $2)
      (array.new_default $type17
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type16
   (i32.const 1)
   (local.get $0)
   (array.new_default $type17
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-block (type $68) (param $0 (ref $type16)) (param $1 i32) (result (ref $type17))
  (if (result (ref $type17))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type16 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type18
      (struct.get $type16 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy (type $67) (param $0 (ref $type16)) (param $1 i64) (param $2 (ref $type16)) (param $3 i64) (param $4 i64)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (if
   (i32.ne
    (struct.get $type16 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (i64.sub
     (local.get $4)
     (local.get $3)
    )
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type16 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.gt_u
     (local.get $1)
     (local.get $3)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (i64.sub
         (local.get $4)
         (local.get $3)
        )
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $8
     (i32.add
      (i32.wrap_i64
       (local.get $3)
      )
      (local.get $7)
     )
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type17 $type17
        (if (result (ref $type17))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $5
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $8)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $5)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type16 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type18
            (struct.get $type16 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type17))
         (i32.lt_u
          (local.tee $8
           (i32.sub
            (local.get $8)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type16 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type18
            (struct.get $type16 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $8)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $7
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $5
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.set $8
     (i32.wrap_i64
      (i64.sub
       (local.get $4)
       (local.get $3)
      )
     )
    )
    (loop $label1
     (if
      (local.get $8)
      (then
       (local.set $6
        (select
         (local.get $8)
         (local.tee $6
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $9
              (i32.and
               (local.get $7)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $11
            (i32.sub
             (i32.const 8192)
             (local.tee $10
              (i32.and
               (local.get $5)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.lt_u
            (local.get $6)
            (local.get $11)
           )
          )
         )
         (i32.gt_u
          (local.get $6)
          (local.get $8)
         )
        )
       )
       (array.copy $type17 $type17
        (if (result (ref $type17))
         (i32.lt_u
          (local.get $7)
          (i32.const 8192)
         )
         (then
          (struct.get $type16 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type18
            (struct.get $type16 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $7)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $9)
        (if (result (ref $type17))
         (i32.lt_u
          (local.get $5)
          (i32.const 8192)
         )
         (then
          (struct.get $type16 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type18
            (struct.get $type16 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $10)
        (local.get $6)
       )
       (local.set $7
        (i32.add
         (local.get $6)
         (local.get $7)
        )
       )
       (local.set $5
        (i32.add
         (local.get $5)
         (local.get $6)
        )
       )
       (local.set $8
        (i32.sub
         (local.get $8)
         (local.get $6)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function30 (type $66) (param $0 (ref $type16)) (param $1 i32) (param $2 i32) (param $3 (ref null $type12)) (param $4 i64) (result (ref $type16))
  (local $5 i32)
  (if (result (ref $type16))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (local.get $3)
     )
    )
    (if
     (i32.ne
      (struct.get $type16 0
       (local.get $0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (if (result (ref $type17))
      (i32.lt_u
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type16 2
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type18
         (struct.get $type16 3
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $5)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $5)
      (i32.const 8191)
     )
     (i32.const 48)
    )
    (drop
     (ref.as_non_null
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function30
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (ref.null none)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function35 (type $65) (param $0 (ref $type25)) (result (ref $type16))
  (local $1 (ref null $type25))
  (local $2 (ref null $type25))
  (local $3 (ref null $type25))
  (local $4 (ref $type16))
  (local $5 (ref $type16))
  (local $6 i64)
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready91)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global91)
   )
  )
  (local.set $6
   (if (result i64)
    (i64.gt_u
     (local.tee $6
      (i64.extend_i32_u
       (struct.get $type16 1
        (struct.get $type25 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type25 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $6)
      )
      (else
       (local.set $3
        (struct.get $type25 1
         (local.get $1)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $6
          (i64.add
           (i64.extend_i32_u
            (struct.get $type16 1
             (struct.get $type25 0
              (local.get $1)
             )
            )
           )
           (local.get $6)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (local.get $6)
          )
          (else
           (local.set $2
            (struct.get $type25 1
             (local.get $3)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $6
              (i64.add
               (i64.extend_i32_u
                (struct.get $type16 1
                 (struct.get $type25 0
                  (local.get $3)
                 )
                )
               )
               (local.get $6)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $1
                (struct.get $type25 1
                 (local.get $2)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $6
                  (i64.add
                   (i64.extend_i32_u
                    (struct.get $type16 1
                     (struct.get $type25 0
                      (local.get $2)
                     )
                    )
                   )
                   (local.get $6)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $2
                    (struct.get $type25 1
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.tee $6
                      (i64.add
                       (i64.extend_i32_u
                        (struct.get $type16 1
                         (struct.get $type25 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.get $6)
                      )
                     )
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $1
                        (struct.get $type25 1
                         (local.get $2)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.tee $6
                          (i64.add
                           (i64.extend_i32_u
                            (struct.get $type16 1
                             (struct.get $type25 0
                              (local.get $2)
                             )
                            )
                           )
                           (local.get $6)
                          )
                         )
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $2
                            (struct.get $type25 1
                             (local.get $1)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.tee $6
                              (i64.add
                               (i64.extend_i32_u
                                (struct.get $type16 1
                                 (struct.get $type25 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (local.get $6)
                              )
                             )
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (local.get $6)
                              )
                              (else
                               (local.set $1
                                (struct.get $type25 1
                                 (local.get $2)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.tee $6
                                  (i64.add
                                   (i64.extend_i32_u
                                    (struct.get $type16 1
                                     (struct.get $type25 0
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (local.get $6)
                                  )
                                 )
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (local.get $6)
                                  )
                                  (else
                                   (local.set $2
                                    (struct.get $type25 1
                                     (local.get $1)
                                    )
                                   )
                                   (if (result i64)
                                    (i64.gt_s
                                     (local.tee $6
                                      (i64.add
                                       (i64.extend_i32_u
                                        (struct.get $type16 1
                                         (struct.get $type25 0
                                          (local.get $1)
                                         )
                                        )
                                       )
                                       (local.get $6)
                                      )
                                     )
                                     (i64.const 4294967294)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.get $2)
                                      )
                                      (then
                                       (local.get $6)
                                      )
                                      (else
                                       (local.set $1
                                        (struct.get $type25 1
                                         (local.get $2)
                                        )
                                       )
                                       (if (result i64)
                                        (i64.gt_s
                                         (local.tee $6
                                          (i64.add
                                           (i64.extend_i32_u
                                            (struct.get $type16 1
                                             (struct.get $type25 0
                                              (local.get $2)
                                             )
                                            )
                                           )
                                           (local.get $6)
                                          )
                                         )
                                         (i64.const 4294967294)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                        (else
                                         (if (result i64)
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                          (then
                                           (local.get $6)
                                          )
                                          (else
                                           (local.set $2
                                            (struct.get $type25 1
                                             (local.get $1)
                                            )
                                           )
                                           (if (result i64)
                                            (i64.gt_s
                                             (local.tee $6
                                              (i64.add
                                               (i64.extend_i32_u
                                                (struct.get $type16 1
                                                 (struct.get $type25 0
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                               (local.get $6)
                                              )
                                             )
                                             (i64.const 4294967294)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                            (else
                                             (if (result i64)
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                              (then
                                               (local.get $6)
                                              )
                                              (else
                                               (local.set $1
                                                (struct.get $type25 1
                                                 (local.get $2)
                                                )
                                               )
                                               (if (result i64)
                                                (i64.gt_s
                                                 (local.tee $6
                                                  (i64.add
                                                   (i64.extend_i32_u
                                                    (struct.get $type16 1
                                                     (struct.get $type25 0
                                                      (local.get $2)
                                                     )
                                                    )
                                                   )
                                                   (local.get $6)
                                                  )
                                                 )
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                                (else
                                                 (if (result i64)
                                                  (ref.is_null
                                                   (local.get $1)
                                                  )
                                                  (then
                                                   (local.get $6)
                                                  )
                                                  (else
                                                   (local.set $2
                                                    (struct.get $type25 1
                                                     (local.get $1)
                                                    )
                                                   )
                                                   (if (result i64)
                                                    (i64.gt_s
                                                     (local.tee $6
                                                      (i64.add
                                                       (i64.extend_i32_u
                                                        (struct.get $type16 1
                                                         (struct.get $type25 0
                                                          (local.get $1)
                                                         )
                                                        )
                                                       )
                                                       (local.get $6)
                                                      )
                                                     )
                                                     (i64.const 4294967294)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                    (else
                                                     (if (result i64)
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                      (then
                                                       (local.get $6)
                                                      )
                                                      (else
                                                       (local.set $1
                                                        (struct.get $type25 1
                                                         (local.get $2)
                                                        )
                                                       )
                                                       (if (result i64)
                                                        (i64.gt_s
                                                         (local.tee $6
                                                          (i64.add
                                                           (i64.extend_i32_u
                                                            (struct.get $type16 1
                                                             (struct.get $type25 0
                                                              (local.get $2)
                                                             )
                                                            )
                                                           )
                                                           (local.get $6)
                                                          )
                                                         )
                                                         (i64.const 4294967294)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                        (else
                                                         (if (result i64)
                                                          (ref.is_null
                                                           (local.get $1)
                                                          )
                                                          (then
                                                           (local.get $6)
                                                          )
                                                          (else
                                                           (local.set $2
                                                            (struct.get $type25 1
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (if (result i64)
                                                            (i64.gt_s
                                                             (local.tee $6
                                                              (i64.add
                                                               (i64.extend_i32_u
                                                                (struct.get $type16 1
                                                                 (struct.get $type25 0
                                                                  (local.get $1)
                                                                 )
                                                                )
                                                               )
                                                               (local.get $6)
                                                              )
                                                             )
                                                             (i64.const 4294967294)
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                            (else
                                                             (if (result i64)
                                                              (ref.is_null
                                                               (local.get $2)
                                                              )
                                                              (then
                                                               (local.get $6)
                                                              )
                                                              (else
                                                               (local.set $1
                                                                (struct.get $type25 1
                                                                 (local.get $2)
                                                                )
                                                               )
                                                               (if (result i64)
                                                                (i64.gt_s
                                                                 (local.tee $6
                                                                  (i64.add
                                                                   (i64.extend_i32_u
                                                                    (struct.get $type16 1
                                                                     (struct.get $type25 0
                                                                      (local.get $2)
                                                                     )
                                                                    )
                                                                   )
                                                                   (local.get $6)
                                                                  )
                                                                 )
                                                                 (i64.const 4294967294)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                                (else
                                                                 (if (result i64)
                                                                  (ref.is_null
                                                                   (local.get $1)
                                                                  )
                                                                  (then
                                                                   (local.get $6)
                                                                  )
                                                                  (else
                                                                   (local.set $2
                                                                    (struct.get $type25 1
                                                                     (local.get $1)
                                                                    )
                                                                   )
                                                                   (if (result i64)
                                                                    (i64.gt_s
                                                                     (local.tee $6
                                                                      (i64.add
                                                                       (i64.extend_i32_u
                                                                        (struct.get $type16 1
                                                                         (struct.get $type25 0
                                                                          (local.get $1)
                                                                         )
                                                                        )
                                                                       )
                                                                       (local.get $6)
                                                                      )
                                                                     )
                                                                     (i64.const 4294967294)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                    (else
                                                                     (if (result i64)
                                                                      (ref.is_null
                                                                       (local.get $2)
                                                                      )
                                                                      (then
                                                                       (local.get $6)
                                                                      )
                                                                      (else
                                                                       (local.set $1
                                                                        (struct.get $type25 1
                                                                         (local.get $2)
                                                                        )
                                                                       )
                                                                       (if (result i64)
                                                                        (i64.gt_s
                                                                         (local.tee $6
                                                                          (i64.add
                                                                           (i64.extend_i32_u
                                                                            (struct.get $type16 1
                                                                             (struct.get $type25 0
                                                                              (local.get $2)
                                                                             )
                                                                            )
                                                                           )
                                                                           (local.get $6)
                                                                          )
                                                                         )
                                                                         (i64.const 4294967294)
                                                                        )
                                                                        (then
                                                                         (unreachable)
                                                                        )
                                                                        (else
                                                                         (if (result i64)
                                                                          (ref.is_null
                                                                           (local.get $1)
                                                                          )
                                                                          (then
                                                                           (local.get $6)
                                                                          )
                                                                          (else
                                                                           (call $function37
                                                                            (i32.const 0)
                                                                            (i32.const 1)
                                                                            (struct.get $type25 1
                                                                             (local.get $1)
                                                                            )
                                                                            (i64.add
                                                                             (i64.extend_i32_u
                                                                              (struct.get $type16 1
                                                                               (struct.get $type25 0
                                                                                (local.get $1)
                                                                               )
                                                                              )
                                                                             )
                                                                             (local.get $6)
                                                                            )
                                                                           )
                                                                          )
                                                                         )
                                                                        )
                                                                       )
                                                                      )
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call $string-new
    (i32.wrap_i64
     (local.get $6)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready96)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global96)
   )
  )
  (call $string-copy
   (local.get $5)
   (i64.const 0)
   (local.tee $4
    (struct.get $type25 0
     (local.get $0)
    )
   )
   (i64.const 0)
   (local.tee $7
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $4)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready96)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global96)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.tee $1
      (struct.get $type25 1
       (local.get $0)
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (call $string-copy
      (local.get $5)
      (local.get $7)
      (local.tee $4
       (struct.get $type25 0
        (local.get $1)
       )
      )
      (i64.const 0)
      (local.tee $6
       (i64.extend_i32_u
        (struct.get $type16 1
         (local.get $4)
        )
       )
      )
     )
     (local.set $1
      (struct.get $type25 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready96)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global96)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $string-copy
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $6)
          (local.get $7)
         )
        )
        (local.tee $4
         (struct.get $type25 0
          (local.get $1)
         )
        )
        (i64.const 0)
        (local.tee $6
         (i64.extend_i32_u
          (struct.get $type16 1
           (local.get $4)
          )
         )
        )
       )
       (local.set $1
        (struct.get $type25 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready96)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global96)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $string-copy
          (local.get $5)
          (local.tee $7
           (i64.add
            (local.get $6)
            (local.get $7)
           )
          )
          (local.tee $4
           (struct.get $type25 0
            (local.get $1)
           )
          )
          (i64.const 0)
          (local.tee $6
           (i64.extend_i32_u
            (struct.get $type16 1
             (local.get $4)
            )
           )
          )
         )
         (local.set $1
          (struct.get $type25 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready96)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global96)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $string-copy
            (local.get $5)
            (local.tee $7
             (i64.add
              (local.get $6)
              (local.get $7)
             )
            )
            (local.tee $4
             (struct.get $type25 0
              (local.get $1)
             )
            )
            (i64.const 0)
            (local.tee $6
             (i64.extend_i32_u
              (struct.get $type16 1
               (local.get $4)
              )
             )
            )
           )
           (local.set $1
            (struct.get $type25 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready96)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global96)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $string-copy
              (local.get $5)
              (local.tee $7
               (i64.add
                (local.get $6)
                (local.get $7)
               )
              )
              (local.tee $4
               (struct.get $type25 0
                (local.get $1)
               )
              )
              (i64.const 0)
              (local.tee $6
               (i64.extend_i32_u
                (struct.get $type16 1
                 (local.get $4)
                )
               )
              )
             )
             (local.set $1
              (struct.get $type25 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready96)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global96)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $string-copy
                (local.get $5)
                (local.tee $7
                 (i64.add
                  (local.get $6)
                  (local.get $7)
                 )
                )
                (local.tee $4
                 (struct.get $type25 0
                  (local.get $1)
                 )
                )
                (i64.const 0)
                (local.tee $6
                 (i64.extend_i32_u
                  (struct.get $type16 1
                   (local.get $4)
                  )
                 )
                )
               )
               (local.set $1
                (struct.get $type25 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready96)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global96)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $string-copy
                  (local.get $5)
                  (local.tee $7
                   (i64.add
                    (local.get $6)
                    (local.get $7)
                   )
                  )
                  (local.tee $4
                   (struct.get $type25 0
                    (local.get $1)
                   )
                  )
                  (i64.const 0)
                  (local.tee $6
                   (i64.extend_i32_u
                    (struct.get $type16 1
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (local.set $1
                  (struct.get $type25 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready96)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global96)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $string-copy
                    (local.get $5)
                    (local.tee $7
                     (i64.add
                      (local.get $6)
                      (local.get $7)
                     )
                    )
                    (local.tee $4
                     (struct.get $type25 0
                      (local.get $1)
                     )
                    )
                    (i64.const 0)
                    (local.tee $6
                     (i64.extend_i32_u
                      (struct.get $type16 1
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (local.set $1
                    (struct.get $type25 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready96)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global96)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $string-copy
                      (local.get $5)
                      (local.tee $7
                       (i64.add
                        (local.get $6)
                        (local.get $7)
                       )
                      )
                      (local.tee $4
                       (struct.get $type25 0
                        (local.get $1)
                       )
                      )
                      (i64.const 0)
                      (local.tee $6
                       (i64.extend_i32_u
                        (struct.get $type16 1
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.set $1
                      (struct.get $type25 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready96)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global96)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $string-copy
                        (local.get $5)
                        (local.tee $7
                         (i64.add
                          (local.get $6)
                          (local.get $7)
                         )
                        )
                        (local.tee $4
                         (struct.get $type25 0
                          (local.get $1)
                         )
                        )
                        (i64.const 0)
                        (local.tee $6
                         (i64.extend_i32_u
                          (struct.get $type16 1
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (local.set $1
                        (struct.get $type25 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready96)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global96)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $1)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (call $string-copy
                          (local.get $5)
                          (local.tee $7
                           (i64.add
                            (local.get $6)
                            (local.get $7)
                           )
                          )
                          (local.tee $4
                           (struct.get $type25 0
                            (local.get $1)
                           )
                          )
                          (i64.const 0)
                          (local.tee $6
                           (i64.extend_i32_u
                            (struct.get $type16 1
                             (local.get $4)
                            )
                           )
                          )
                         )
                         (local.set $1
                          (struct.get $type25 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready96)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global96)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (call $string-copy
                            (local.get $5)
                            (local.tee $7
                             (i64.add
                              (local.get $6)
                              (local.get $7)
                             )
                            )
                            (local.tee $4
                             (struct.get $type25 0
                              (local.get $1)
                             )
                            )
                            (i64.const 0)
                            (local.tee $6
                             (i64.extend_i32_u
                              (struct.get $type16 1
                               (local.get $4)
                              )
                             )
                            )
                           )
                           (local.set $1
                            (struct.get $type25 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready96)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global96)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (call $string-copy
                              (local.get $5)
                              (local.tee $7
                               (i64.add
                                (local.get $6)
                                (local.get $7)
                               )
                              )
                              (local.tee $4
                               (struct.get $type25 0
                                (local.get $1)
                               )
                              )
                              (i64.const 0)
                              (local.tee $6
                               (i64.extend_i32_u
                                (struct.get $type16 1
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (local.set $1
                              (struct.get $type25 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready96)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global96)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $1)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (call $string-copy
                                (local.get $5)
                                (local.tee $7
                                 (i64.add
                                  (local.get $6)
                                  (local.get $7)
                                 )
                                )
                                (local.tee $4
                                 (struct.get $type25 0
                                  (local.get $1)
                                 )
                                )
                                (i64.const 0)
                                (local.tee $6
                                 (i64.extend_i32_u
                                  (struct.get $type16 1
                                   (local.get $4)
                                  )
                                 )
                                )
                               )
                               (local.set $1
                                (struct.get $type25 1
                                 (local.get $1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready96)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global96)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $1)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (call $string-copy
                                  (local.get $5)
                                  (local.tee $7
                                   (i64.add
                                    (local.get $6)
                                    (local.get $7)
                                   )
                                  )
                                  (local.tee $4
                                   (struct.get $type25 0
                                    (local.get $1)
                                   )
                                  )
                                  (i64.const 0)
                                  (local.tee $6
                                   (i64.extend_i32_u
                                    (struct.get $type16 1
                                     (local.get $4)
                                    )
                                   )
                                  )
                                 )
                                 (local.set $1
                                  (struct.get $type25 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready96)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global96)
                                  )
                                 )
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (call $string-copy
                                    (local.get $5)
                                    (local.tee $7
                                     (i64.add
                                      (local.get $6)
                                      (local.get $7)
                                     )
                                    )
                                    (local.tee $4
                                     (struct.get $type25 0
                                      (local.get $1)
                                     )
                                    )
                                    (i64.const 0)
                                    (local.tee $6
                                     (i64.extend_i32_u
                                      (struct.get $type16 1
                                       (local.get $4)
                                      )
                                     )
                                    )
                                   )
                                   (local.set $1
                                    (struct.get $type25 1
                                     (local.get $1)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready96)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global96)
                                    )
                                   )
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (call $string-copy
                                      (local.get $5)
                                      (local.tee $7
                                       (i64.add
                                        (local.get $6)
                                        (local.get $7)
                                       )
                                      )
                                      (local.tee $4
                                       (struct.get $type25 0
                                        (local.get $1)
                                       )
                                      )
                                      (i64.const 0)
                                      (local.tee $6
                                       (i64.extend_i32_u
                                        (struct.get $type16 1
                                         (local.get $4)
                                        )
                                       )
                                      )
                                     )
                                     (local.set $1
                                      (struct.get $type25 1
                                       (local.get $1)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready96)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global96)
                                      )
                                     )
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $1)
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (call $string-copy
                                        (local.get $5)
                                        (local.tee $7
                                         (i64.add
                                          (local.get $6)
                                          (local.get $7)
                                         )
                                        )
                                        (local.tee $4
                                         (struct.get $type25 0
                                          (local.get $1)
                                         )
                                        )
                                        (i64.const 0)
                                        (local.tee $6
                                         (i64.extend_i32_u
                                          (struct.get $type16 1
                                           (local.get $4)
                                          )
                                         )
                                        )
                                       )
                                       (local.set $1
                                        (struct.get $type25 1
                                         (local.get $1)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready96)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global96)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $1)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (call $string-copy
                                          (local.get $5)
                                          (local.tee $7
                                           (i64.add
                                            (local.get $6)
                                            (local.get $7)
                                           )
                                          )
                                          (local.tee $4
                                           (struct.get $type25 0
                                            (local.get $1)
                                           )
                                          )
                                          (i64.const 0)
                                          (local.tee $6
                                           (i64.extend_i32_u
                                            (struct.get $type16 1
                                             (local.get $4)
                                            )
                                           )
                                          )
                                         )
                                         (local.set $1
                                          (struct.get $type25 1
                                           (local.get $1)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready96)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global96)
                                          )
                                         )
                                         (call $function38
                                          (local.get $5)
                                          (local.get $1)
                                          (i64.add
                                           (local.get $6)
                                           (local.get $7)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $5)
 )
 (func $function37 (type $63) (param $0 i32) (param $1 i32) (param $2 (ref null $type25)) (param $3 i64) (result i64)
  (local $4 (ref null $type25))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $4
       (struct.get $type25 1
        (local.get $2)
       )
      )
      (local.set $5
       (i64.extend_i32_u
        (struct.get $type16 1
         (struct.get $type25 0
          (local.get $2)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (i64.add
        (local.get $3)
        (local.get $5)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call27) (param $0 (ref $type16)) (param $1 (ref null $type25)) (param $2 i64) (result i32)
  (local $3 (ref $type16))
  (local $4 i64)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $3
      (struct.get $type25 0
       (local.get $1)
      )
     )
     (i64.const 0)
     (local.tee $4
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $3)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type25 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready96)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global96)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function41 (type $call30) (param $0 (ref $type14)) (param $1 i64) (result i64)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_s
   (array.get $type14
    (local.get $0)
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
 )
 (func $function42 (type $59) (param $0 (ref $type14)) (param $1 i64) (param $2 i64)
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type14
   (local.get $0)
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.wrap_i64
    (local.get $2)
   )
  )
 )
 (func $function44 (type $call33) (param $0 (ref $type14)) (result i64)
  (local $1 i64)
  (local $2 i64)
  (if (result i64)
   (if (result i32)
    (i64.eqz
     (local.tee $1
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (if
      (i64.gt_u
       (local.tee $2
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.ne
      (i64.extend_i32_s
       (array.get $type14
        (local.get $0)
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (i64.const 0)
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if (result i64)
     (if (result i32)
      (i64.eqz
       (local.tee $1
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global109)
        )
       )
       (if
        (i64.gt_u
         (local.tee $2
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (i64.ne
        (i64.extend_i32_s
         (array.get $type14
          (local.get $0)
          (i32.wrap_i64
           (local.get $2)
          )
         )
        )
        (i64.const 0)
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (if (result i64)
       (if (result i32)
        (i64.eqz
         (local.tee $1
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
        )
        (then
         (i32.const 1)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global109)
          )
         )
         (if
          (i64.gt_u
           (local.tee $2
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i64.ne
          (i64.extend_i32_s
           (array.get $type14
            (local.get $0)
            (i32.wrap_i64
             (local.get $2)
            )
           )
          )
          (i64.const 0)
         )
        )
       )
       (then
        (local.get $1)
       )
       (else
        (if (result i64)
         (if (result i32)
          (i64.eqz
           (local.tee $1
            (i64.sub
             (local.get $1)
             (i64.const 1)
            )
           )
          )
          (then
           (i32.const 1)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global109)
            )
           )
           (if
            (i64.gt_u
             (local.tee $2
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i64.ne
            (i64.extend_i32_s
             (array.get $type14
              (local.get $0)
              (i32.wrap_i64
               (local.get $2)
              )
             )
            )
            (i64.const 0)
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (if (result i64)
           (if (result i32)
            (i64.eqz
             (local.tee $1
              (i64.sub
               (local.get $1)
               (i64.const 1)
              )
             )
            )
            (then
             (i32.const 1)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global109)
              )
             )
             (if
              (i64.gt_u
               (local.tee $2
                (i64.sub
                 (local.get $1)
                 (i64.const 1)
                )
               )
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (i64.ne
              (i64.extend_i32_s
               (array.get $type14
                (local.get $0)
                (i32.wrap_i64
                 (local.get $2)
                )
               )
              )
              (i64.const 0)
             )
            )
           )
           (then
            (local.get $1)
           )
           (else
            (if (result i64)
             (if (result i32)
              (i64.eqz
               (local.tee $1
                (i64.sub
                 (local.get $1)
                 (i64.const 1)
                )
               )
              )
              (then
               (i32.const 1)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global109)
                )
               )
               (if
                (i64.gt_u
                 (local.tee $2
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (i64.ne
                (i64.extend_i32_s
                 (array.get $type14
                  (local.get $0)
                  (i32.wrap_i64
                   (local.get $2)
                  )
                 )
                )
                (i64.const 0)
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (if (result i64)
               (if (result i32)
                (i64.eqz
                 (local.tee $1
                  (i64.sub
                   (local.get $1)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (i32.const 1)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global109)
                  )
                 )
                 (if
                  (i64.gt_u
                   (local.tee $2
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (i64.ne
                  (i64.extend_i32_s
                   (array.get $type14
                    (local.get $0)
                    (i32.wrap_i64
                     (local.get $2)
                    )
                   )
                  )
                  (i64.const 0)
                 )
                )
               )
               (then
                (local.get $1)
               )
               (else
                (if (result i64)
                 (if (result i32)
                  (i64.eqz
                   (local.tee $1
                    (i64.sub
                     (local.get $1)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (i32.const 1)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global109)
                    )
                   )
                   (if
                    (i64.gt_u
                     (local.tee $2
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                     (i64.const 4294967295)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (i64.ne
                    (i64.extend_i32_s
                     (array.get $type14
                      (local.get $0)
                      (i32.wrap_i64
                       (local.get $2)
                      )
                     )
                    )
                    (i64.const 0)
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (if (result i64)
                   (if (result i32)
                    (i64.eqz
                     (local.tee $1
                      (i64.sub
                       (local.get $1)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (i32.const 1)
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global109)
                      )
                     )
                     (if
                      (i64.gt_u
                       (local.tee $2
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                       (i64.const 4294967295)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (i64.ne
                      (i64.extend_i32_s
                       (array.get $type14
                        (local.get $0)
                        (i32.wrap_i64
                         (local.get $2)
                        )
                       )
                      )
                      (i64.const 0)
                     )
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (if (result i64)
                     (if (result i32)
                      (i64.eqz
                       (local.tee $1
                        (i64.sub
                         (local.get $1)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (i32.const 1)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global109)
                        )
                       )
                       (if
                        (i64.gt_u
                         (local.tee $2
                          (i64.sub
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                         (i64.const 4294967295)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (i64.ne
                        (i64.extend_i32_s
                         (array.get $type14
                          (local.get $0)
                          (i32.wrap_i64
                           (local.get $2)
                          )
                         )
                        )
                        (i64.const 0)
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (if (result i64)
                       (if (result i32)
                        (i64.eqz
                         (local.tee $1
                          (i64.sub
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (i32.const 1)
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global109)
                          )
                         )
                         (if
                          (i64.gt_u
                           (local.tee $2
                            (i64.sub
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                           (i64.const 4294967295)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (i64.ne
                          (i64.extend_i32_s
                           (array.get $type14
                            (local.get $0)
                            (i32.wrap_i64
                             (local.get $2)
                            )
                           )
                          )
                          (i64.const 0)
                         )
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (if (result i64)
                         (if (result i32)
                          (i64.eqz
                           (local.tee $1
                            (i64.sub
                             (local.get $1)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (i32.const 1)
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global109)
                            )
                           )
                           (if
                            (i64.gt_u
                             (local.tee $2
                              (i64.sub
                               (local.get $1)
                               (i64.const 1)
                              )
                             )
                             (i64.const 4294967295)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (i64.ne
                            (i64.extend_i32_s
                             (array.get $type14
                              (local.get $0)
                              (i32.wrap_i64
                               (local.get $2)
                              )
                             )
                            )
                            (i64.const 0)
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (if (result i64)
                           (if (result i32)
                            (i64.eqz
                             (local.tee $1
                              (i64.sub
                               (local.get $1)
                               (i64.const 1)
                              )
                             )
                            )
                            (then
                             (i32.const 1)
                            )
                            (else
                             (drop
                              (ref.as_non_null
                               (global.get $global109)
                              )
                             )
                             (if
                              (i64.gt_u
                               (local.tee $2
                                (i64.sub
                                 (local.get $1)
                                 (i64.const 1)
                                )
                               )
                               (i64.const 4294967295)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (i64.ne
                              (i64.extend_i32_s
                               (array.get $type14
                                (local.get $0)
                                (i32.wrap_i64
                                 (local.get $2)
                                )
                               )
                              )
                              (i64.const 0)
                             )
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (if (result i64)
                             (if (result i32)
                              (i64.eqz
                               (local.tee $1
                                (i64.sub
                                 (local.get $1)
                                 (i64.const 1)
                                )
                               )
                              )
                              (then
                               (i32.const 1)
                              )
                              (else
                               (drop
                                (ref.as_non_null
                                 (global.get $global109)
                                )
                               )
                               (if
                                (i64.gt_u
                                 (local.tee $2
                                  (i64.sub
                                   (local.get $1)
                                   (i64.const 1)
                                  )
                                 )
                                 (i64.const 4294967295)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (i64.ne
                                (i64.extend_i32_s
                                 (array.get $type14
                                  (local.get $0)
                                  (i32.wrap_i64
                                   (local.get $2)
                                  )
                                 )
                                )
                                (i64.const 0)
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (if (result i64)
                               (if (result i32)
                                (i64.eqz
                                 (local.tee $1
                                  (i64.sub
                                   (local.get $1)
                                   (i64.const 1)
                                  )
                                 )
                                )
                                (then
                                 (i32.const 1)
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global109)
                                  )
                                 )
                                 (if
                                  (i64.gt_u
                                   (local.tee $2
                                    (i64.sub
                                     (local.get $1)
                                     (i64.const 1)
                                    )
                                   )
                                   (i64.const 4294967295)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (i64.ne
                                  (i64.extend_i32_s
                                   (array.get $type14
                                    (local.get $0)
                                    (i32.wrap_i64
                                     (local.get $2)
                                    )
                                   )
                                  )
                                  (i64.const 0)
                                 )
                                )
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (if (result i64)
                                 (if (result i32)
                                  (i64.eqz
                                   (local.tee $1
                                    (i64.sub
                                     (local.get $1)
                                     (i64.const 1)
                                    )
                                   )
                                  )
                                  (then
                                   (i32.const 1)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global109)
                                    )
                                   )
                                   (if
                                    (i64.gt_u
                                     (local.tee $2
                                      (i64.sub
                                       (local.get $1)
                                       (i64.const 1)
                                      )
                                     )
                                     (i64.const 4294967295)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (i64.ne
                                    (i64.extend_i32_s
                                     (array.get $type14
                                      (local.get $0)
                                      (i32.wrap_i64
                                       (local.get $2)
                                      )
                                     )
                                    )
                                    (i64.const 0)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (if (result i64)
                                   (if (result i32)
                                    (i64.eqz
                                     (local.tee $1
                                      (i64.sub
                                       (local.get $1)
                                       (i64.const 1)
                                      )
                                     )
                                    )
                                    (then
                                     (i32.const 1)
                                    )
                                    (else
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global109)
                                      )
                                     )
                                     (if
                                      (i64.gt_u
                                       (local.tee $2
                                        (i64.sub
                                         (local.get $1)
                                         (i64.const 1)
                                        )
                                       )
                                       (i64.const 4294967295)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (i64.ne
                                      (i64.extend_i32_s
                                       (array.get $type14
                                        (local.get $0)
                                        (i32.wrap_i64
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (if (result i64)
                                     (if (result i32)
                                      (i64.eqz
                                       (local.tee $1
                                        (i64.sub
                                         (local.get $1)
                                         (i64.const 1)
                                        )
                                       )
                                      )
                                      (then
                                       (i32.const 1)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global109)
                                        )
                                       )
                                       (if
                                        (i64.gt_u
                                         (local.tee $2
                                          (i64.sub
                                           (local.get $1)
                                           (i64.const 1)
                                          )
                                         )
                                         (i64.const 4294967295)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (i64.ne
                                        (i64.extend_i32_s
                                         (array.get $type14
                                          (local.get $0)
                                          (i32.wrap_i64
                                           (local.get $2)
                                          )
                                         )
                                        )
                                        (i64.const 0)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (if (result i64)
                                       (if (result i32)
                                        (i64.eqz
                                         (local.tee $1
                                          (i64.sub
                                           (local.get $1)
                                           (i64.const 1)
                                          )
                                         )
                                        )
                                        (then
                                         (i32.const 1)
                                        )
                                        (else
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global109)
                                          )
                                         )
                                         (if
                                          (i64.gt_u
                                           (local.tee $2
                                            (i64.sub
                                             (local.get $1)
                                             (i64.const 1)
                                            )
                                           )
                                           (i64.const 4294967295)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (i64.ne
                                          (i64.extend_i32_s
                                           (array.get $type14
                                            (local.get $0)
                                            (i32.wrap_i64
                                             (local.get $2)
                                            )
                                           )
                                          )
                                          (i64.const 0)
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (if (result i64)
                                         (if (result i32)
                                          (i64.eqz
                                           (local.tee $1
                                            (i64.sub
                                             (local.get $1)
                                             (i64.const 1)
                                            )
                                           )
                                          )
                                          (then
                                           (i32.const 1)
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global109)
                                            )
                                           )
                                           (i64.ne
                                            (call $function41
                                             (local.get $0)
                                             (i64.sub
                                              (local.get $1)
                                              (i64.const 1)
                                             )
                                            )
                                            (i64.const 0)
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (return_call $function45
                                           (local.get $0)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.sub
                                            (local.get $1)
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function45 (type $57) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (if (result i64)
   (if (result i32)
    (i64.eqz
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (i64.ne
      (call $function41
       (local.get $0)
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.const 0)
     )
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function46 (type $call13) (param $0 (ref $type14)) (result (ref $type14))
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type14))
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if (result (ref $type14))
   (i64.eq
    (local.tee $1
     (call $function44
      (local.get $0)
     )
    )
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type14 $type14
     (local.tee $3
      (array.new_default $type14
       (local.tee $2
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (i32.const 0)
     (local.get $0)
     (i32.const 0)
     (local.get $2)
    )
    (local.get $3)
   )
  )
 )
 (func $function47 (type $55) (param $0 i32) (param $1 (ref $type14)) (result (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.tee $1
       (call $function46
        (local.get $1)
       )
      )
     )
    )
   )
   (then
    (ref.as_non_null
     (global.get $global108)
    )
   )
   (else
    (struct.new $type29
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function48 (type $call35) (param $0 (ref $type29)) (result i32)
  (i64.eqz
   (i64.extend_i32_u
    (array.len
     (struct.get $type29 1
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function51 (type $call37) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 1073741824)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 1073741824)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 1073741824)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 1073741824)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 1073741824)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 1073741824)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 1073741824)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 1073741824)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 1073741824)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 1073741824)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 1073741824)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 1073741824)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 1073741824)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (if (result i64)
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 1073741824)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 15)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 1073741824)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 16)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 1073741824)
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 17)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 1073741824)
                                         )
                                        )
                                       )
                                       (then
                                        (i64.const 18)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                          )
                                         )
                                         (then
                                          (i64.const 19)
                                         )
                                         (else
                                          (return_call $function52
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function52 (type $52) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 1073741824)
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function53 (type $call38) (param $0 i64) (result (ref $type29))
  (local $1 (ref $type14))
  (local $2 (ref $type14))
  (local $3 i32)
  (local $4 i64)
  (local $5 i64)
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (local.set $5
   (call $function51
    (local.tee $4
     (select
      (i64.sub
       (i64.const 0)
       (local.get $0)
      )
      (local.get $0)
      (i64.gt_s
       (local.get $0)
       (i64.const 0)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i64.gt_u
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (i64.lt_s
    (local.get $0)
    (i64.const 0)
   )
  )
  (local.set $1
   (array.new_default $type14
    (i32.wrap_i64
     (local.get $5)
    )
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (local.get $4)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function46
          (local.get $1)
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type29
       (local.get $3)
       (local.get $2)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (array.set $type14
     (local.get $1)
     (i32.const 0)
     (i32.wrap_i64
      (i64.sub
       (i64.const 0)
       (i64.rem_s
        (local.get $4)
        (i64.const 1073741824)
       )
      )
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $4)
        (i64.const 1073741824)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global126)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global122)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function46
            (local.get $1)
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type29
         (local.get $3)
         (local.get $2)
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global112)
       )
      )
      (array.set $type14
       (local.get $1)
       (i32.const 1)
       (i32.wrap_i64
        (i64.sub
         (i64.const 0)
         (i64.rem_s
          (local.get $0)
          (i64.const 1073741824)
         )
        )
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 1073741824)
         )
        )
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global126)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global122)
         )
        )
        (if (result (ref $type29))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (local.tee $2
             (call $function46
              (local.get $1)
             )
            )
           )
          )
         )
         (then
          (ref.as_non_null
           (global.get $global108)
          )
         )
         (else
          (struct.new $type29
           (local.get $3)
           (local.get $2)
          )
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global112)
         )
        )
        (array.set $type14
         (local.get $1)
         (i32.const 2)
         (i32.wrap_i64
          (i64.sub
           (i64.const 0)
           (i64.rem_s
            (local.get $0)
            (i64.const 1073741824)
           )
          )
         )
        )
        (if (result (ref $type29))
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 1073741824)
           )
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global126)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global122)
           )
          )
          (if (result (ref $type29))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (local.tee $2
               (call $function46
                (local.get $1)
               )
              )
             )
            )
           )
           (then
            (ref.as_non_null
             (global.get $global108)
            )
           )
           (else
            (struct.new $type29
             (local.get $3)
             (local.get $2)
            )
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global112)
           )
          )
          (array.set $type14
           (local.get $1)
           (i32.const 3)
           (i32.wrap_i64
            (i64.sub
             (i64.const 0)
             (i64.rem_s
              (local.get $0)
              (i64.const 1073741824)
             )
            )
           )
          )
          (if (result (ref $type29))
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 1073741824)
             )
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global126)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global122)
             )
            )
            (if (result (ref $type29))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function46
                  (local.get $1)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global108)
              )
             )
             (else
              (struct.new $type29
               (local.get $3)
               (local.get $2)
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global112)
             )
            )
            (array.set $type14
             (local.get $1)
             (i32.const 4)
             (i32.wrap_i64
              (i64.sub
               (i64.const 0)
               (i64.rem_s
                (local.get $0)
                (i64.const 1073741824)
               )
              )
             )
            )
            (if (result (ref $type29))
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 1073741824)
               )
              )
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global126)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global122)
               )
              )
              (if (result (ref $type29))
               (i64.eqz
                (i64.extend_i32_u
                 (array.len
                  (local.tee $2
                   (call $function46
                    (local.get $1)
                   )
                  )
                 )
                )
               )
               (then
                (ref.as_non_null
                 (global.get $global108)
                )
               )
               (else
                (struct.new $type29
                 (local.get $3)
                 (local.get $2)
                )
               )
              )
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global112)
               )
              )
              (array.set $type14
               (local.get $1)
               (i32.const 5)
               (i32.wrap_i64
                (i64.sub
                 (i64.const 0)
                 (i64.rem_s
                  (local.get $0)
                  (i64.const 1073741824)
                 )
                )
               )
              )
              (if (result (ref $type29))
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 1073741824)
                 )
                )
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global126)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global122)
                 )
                )
                (if (result (ref $type29))
                 (i64.eqz
                  (i64.extend_i32_u
                   (array.len
                    (local.tee $2
                     (call $function46
                      (local.get $1)
                     )
                    )
                   )
                  )
                 )
                 (then
                  (ref.as_non_null
                   (global.get $global108)
                  )
                 )
                 (else
                  (struct.new $type29
                   (local.get $3)
                   (local.get $2)
                  )
                 )
                )
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global112)
                 )
                )
                (array.set $type14
                 (local.get $1)
                 (i32.const 6)
                 (i32.wrap_i64
                  (i64.sub
                   (i64.const 0)
                   (i64.rem_s
                    (local.get $0)
                    (i64.const 1073741824)
                   )
                  )
                 )
                )
                (if (result (ref $type29))
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 1073741824)
                   )
                  )
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global126)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global122)
                   )
                  )
                  (if (result (ref $type29))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (local.tee $2
                       (call $function46
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                   (then
                    (ref.as_non_null
                     (global.get $global108)
                    )
                   )
                   (else
                    (struct.new $type29
                     (local.get $3)
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global112)
                   )
                  )
                  (array.set $type14
                   (local.get $1)
                   (i32.const 7)
                   (i32.wrap_i64
                    (i64.sub
                     (i64.const 0)
                     (i64.rem_s
                      (local.get $0)
                      (i64.const 1073741824)
                     )
                    )
                   )
                  )
                  (if (result (ref $type29))
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 1073741824)
                     )
                    )
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global126)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global122)
                     )
                    )
                    (if (result (ref $type29))
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (local.tee $2
                         (call $function46
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                     (then
                      (ref.as_non_null
                       (global.get $global108)
                      )
                     )
                     (else
                      (struct.new $type29
                       (local.get $3)
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global112)
                     )
                    )
                    (array.set $type14
                     (local.get $1)
                     (i32.const 8)
                     (i32.wrap_i64
                      (i64.sub
                       (i64.const 0)
                       (i64.rem_s
                        (local.get $0)
                        (i64.const 1073741824)
                       )
                      )
                     )
                    )
                    (if (result (ref $type29))
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 1073741824)
                       )
                      )
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global126)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global122)
                       )
                      )
                      (if (result (ref $type29))
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (local.tee $2
                           (call $function46
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (then
                        (ref.as_non_null
                         (global.get $global108)
                        )
                       )
                       (else
                        (struct.new $type29
                         (local.get $3)
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global112)
                       )
                      )
                      (array.set $type14
                       (local.get $1)
                       (i32.const 9)
                       (i32.wrap_i64
                        (i64.sub
                         (i64.const 0)
                         (i64.rem_s
                          (local.get $0)
                          (i64.const 1073741824)
                         )
                        )
                       )
                      )
                      (if (result (ref $type29))
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 1073741824)
                         )
                        )
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global126)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global122)
                         )
                        )
                        (if (result (ref $type29))
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (local.tee $2
                             (call $function46
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                         (then
                          (ref.as_non_null
                           (global.get $global108)
                          )
                         )
                         (else
                          (struct.new $type29
                           (local.get $3)
                           (local.get $2)
                          )
                         )
                        )
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global112)
                         )
                        )
                        (array.set $type14
                         (local.get $1)
                         (i32.const 10)
                         (i32.wrap_i64
                          (i64.sub
                           (i64.const 0)
                           (i64.rem_s
                            (local.get $0)
                            (i64.const 1073741824)
                           )
                          )
                         )
                        )
                        (if (result (ref $type29))
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 1073741824)
                           )
                          )
                         )
                         (then
                          (drop
                           (ref.as_non_null
                            (global.get $global126)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global122)
                           )
                          )
                          (if (result (ref $type29))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (local.tee $2
                               (call $function46
                                (local.get $1)
                               )
                              )
                             )
                            )
                           )
                           (then
                            (ref.as_non_null
                             (global.get $global108)
                            )
                           )
                           (else
                            (struct.new $type29
                             (local.get $3)
                             (local.get $2)
                            )
                           )
                          )
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global112)
                           )
                          )
                          (array.set $type14
                           (local.get $1)
                           (i32.const 11)
                           (i32.wrap_i64
                            (i64.sub
                             (i64.const 0)
                             (i64.rem_s
                              (local.get $0)
                              (i64.const 1073741824)
                             )
                            )
                           )
                          )
                          (if (result (ref $type29))
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 1073741824)
                             )
                            )
                           )
                           (then
                            (drop
                             (ref.as_non_null
                              (global.get $global126)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global122)
                             )
                            )
                            (if (result (ref $type29))
                             (i64.eqz
                              (i64.extend_i32_u
                               (array.len
                                (local.tee $2
                                 (call $function46
                                  (local.get $1)
                                 )
                                )
                               )
                              )
                             )
                             (then
                              (ref.as_non_null
                               (global.get $global108)
                              )
                             )
                             (else
                              (struct.new $type29
                               (local.get $3)
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global112)
                             )
                            )
                            (array.set $type14
                             (local.get $1)
                             (i32.const 12)
                             (i32.wrap_i64
                              (i64.sub
                               (i64.const 0)
                               (i64.rem_s
                                (local.get $0)
                                (i64.const 1073741824)
                               )
                              )
                             )
                            )
                            (if (result (ref $type29))
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 1073741824)
                               )
                              )
                             )
                             (then
                              (drop
                               (ref.as_non_null
                                (global.get $global126)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global122)
                               )
                              )
                              (if (result (ref $type29))
                               (i64.eqz
                                (i64.extend_i32_u
                                 (array.len
                                  (local.tee $2
                                   (call $function46
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                               (then
                                (ref.as_non_null
                                 (global.get $global108)
                                )
                               )
                               (else
                                (struct.new $type29
                                 (local.get $3)
                                 (local.get $2)
                                )
                               )
                              )
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global112)
                               )
                              )
                              (array.set $type14
                               (local.get $1)
                               (i32.const 13)
                               (i32.wrap_i64
                                (i64.sub
                                 (i64.const 0)
                                 (i64.rem_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                )
                               )
                              )
                              (if (result (ref $type29))
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 1073741824)
                                 )
                                )
                               )
                               (then
                                (drop
                                 (ref.as_non_null
                                  (global.get $global126)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global122)
                                 )
                                )
                                (if (result (ref $type29))
                                 (i64.eqz
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.tee $2
                                     (call $function46
                                      (local.get $1)
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (ref.as_non_null
                                   (global.get $global108)
                                  )
                                 )
                                 (else
                                  (struct.new $type29
                                   (local.get $3)
                                   (local.get $2)
                                  )
                                 )
                                )
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global112)
                                 )
                                )
                                (array.set $type14
                                 (local.get $1)
                                 (i32.const 14)
                                 (i32.wrap_i64
                                  (i64.sub
                                   (i64.const 0)
                                   (i64.rem_s
                                    (local.get $0)
                                    (i64.const 1073741824)
                                   )
                                  )
                                 )
                                )
                                (if (result (ref $type29))
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 1073741824)
                                   )
                                  )
                                 )
                                 (then
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global126)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global122)
                                   )
                                  )
                                  (if (result (ref $type29))
                                   (i64.eqz
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.tee $2
                                       (call $function46
                                        (local.get $1)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (ref.as_non_null
                                     (global.get $global108)
                                    )
                                   )
                                   (else
                                    (struct.new $type29
                                     (local.get $3)
                                     (local.get $2)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global112)
                                   )
                                  )
                                  (array.set $type14
                                   (local.get $1)
                                   (i32.const 15)
                                   (i32.wrap_i64
                                    (i64.sub
                                     (i64.const 0)
                                     (i64.rem_s
                                      (local.get $0)
                                      (i64.const 1073741824)
                                     )
                                    )
                                   )
                                  )
                                  (if (result (ref $type29))
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 1073741824)
                                     )
                                    )
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global126)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global122)
                                     )
                                    )
                                    (if (result (ref $type29))
                                     (i64.eqz
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.tee $2
                                         (call $function46
                                          (local.get $1)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (ref.as_non_null
                                       (global.get $global108)
                                      )
                                     )
                                     (else
                                      (struct.new $type29
                                       (local.get $3)
                                       (local.get $2)
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global112)
                                     )
                                    )
                                    (array.set $type14
                                     (local.get $1)
                                     (i32.const 16)
                                     (i32.wrap_i64
                                      (i64.sub
                                       (i64.const 0)
                                       (i64.rem_s
                                        (local.get $0)
                                        (i64.const 1073741824)
                                       )
                                      )
                                     )
                                    )
                                    (if (result (ref $type29))
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 1073741824)
                                       )
                                      )
                                     )
                                     (then
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global126)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global122)
                                       )
                                      )
                                      (if (result (ref $type29))
                                       (i64.eqz
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.tee $2
                                           (call $function46
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (then
                                        (ref.as_non_null
                                         (global.get $global108)
                                        )
                                       )
                                       (else
                                        (struct.new $type29
                                         (local.get $3)
                                         (local.get $2)
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global112)
                                       )
                                      )
                                      (array.set $type14
                                       (local.get $1)
                                       (i32.const 17)
                                       (i32.wrap_i64
                                        (i64.sub
                                         (i64.const 0)
                                         (i64.rem_s
                                          (local.get $0)
                                          (i64.const 1073741824)
                                         )
                                        )
                                       )
                                      )
                                      (if (result (ref $type29))
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 1073741824)
                                         )
                                        )
                                       )
                                       (then
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global126)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global122)
                                         )
                                        )
                                        (if (result (ref $type29))
                                         (i64.eqz
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.tee $2
                                             (call $function46
                                              (local.get $1)
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (then
                                          (ref.as_non_null
                                           (global.get $global108)
                                          )
                                         )
                                         (else
                                          (struct.new $type29
                                           (local.get $3)
                                           (local.get $2)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global112)
                                         )
                                        )
                                        (array.set $type14
                                         (local.get $1)
                                         (i32.const 18)
                                         (i32.wrap_i64
                                          (i64.sub
                                           (i64.const 0)
                                           (i64.rem_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                          )
                                         )
                                        )
                                        (if
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                          )
                                         )
                                         (then
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global126)
                                           )
                                          )
                                          (return_call $function47
                                           (local.get $3)
                                           (local.get $1)
                                          )
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global112)
                                           )
                                          )
                                          (call $function42
                                           (local.get $1)
                                           (i64.const 19)
                                           (i64.sub
                                            (i64.const 0)
                                            (i64.rem_s
                                             (local.get $0)
                                             (i64.const 1073741824)
                                            )
                                           )
                                          )
                                          (return_call $function54
                                           (local.get $3)
                                           (local.get $1)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 1073741824)
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                        (unreachable)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function54 (type $50) (param $0 i32) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result (ref $type29))
  (if
   (i64.eqz
    (local.get $4)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (return_call $function47
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (call $function42
     (local.get $1)
     (local.get $5)
     (i64.sub
      (i64.const 0)
      (i64.rem_s
       (local.get $4)
       (i64.const 1073741824)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.div_s
      (local.get $4)
      (i64.const 1073741824)
     )
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function56 (type $49) (param $0 (ref $type14)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i64)
  (local $7 i64)
  (if (result i64)
   (i64.eqz
    (local.get $5)
   )
   (then
    (select
     (local.get $6)
     (i64.sub
      (i64.const 0)
      (local.get $6)
     )
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (i64.div_s
       (i64.add
        (local.tee $7
         (i64.extend_i32_s
          (array.get $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $7)
           )
          )
         )
        )
        (local.get $2)
       )
       (i64.const 1073741824)
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function56
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
       (i64.sub
        (i64.shl
         (local.get $6)
         (i64.const 30)
        )
        (local.get $7)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function58 (type $48) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (if (result i64)
   (i64.eqz
    (local.get $4)
   )
   (then
    (i64.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.sub
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (i64.lt_s
      (local.tee $5
       (i64.extend_i32_s
        (array.get $type14
         (local.get $0)
         (local.tee $7
          (i32.wrap_i64
           (local.get $5)
          )
         )
        )
       )
      )
      (local.tee $6
       (i64.extend_i32_s
        (array.get $type14
         (local.get $1)
         (local.get $7)
        )
       )
      )
     )
     (then
      (i64.const -1)
     )
     (else
      (if (result i64)
       (i64.gt_s
        (local.get $5)
        (local.get $6)
       )
       (then
        (i64.const 1)
       )
       (else
        (if
         (i32.eqz
          (local.get $3)
         )
         (then
          (unreachable)
         )
        )
        (return_call $function58
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $3)
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function59 (type $call41) (param $0 (ref $type29)) (param $1 (ref $type29)) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type14))
  (local $6 (ref $type14))
  (if (result i64)
   (i64.eq
    (i64.extend_i32_u
     (i32.ne
      (local.tee $4
       (struct.get $type29 0
        (local.get $0)
       )
      )
      (i32.const 0)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (struct.get $type29 0
       (local.get $1)
      )
      (i32.const 0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (select
     (i64.sub
      (i64.const 0)
      (local.tee $2
       (if (result i64)
        (i64.lt_s
         (local.tee $2
          (i64.extend_i32_u
           (array.len
            (local.tee $5
             (struct.get $type29 1
              (local.get $0)
             )
            )
           )
          )
         )
         (local.tee $3
          (i64.extend_i32_u
           (array.len
            (local.tee $6
             (struct.get $type29 1
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (if (result i64)
          (i64.gt_s
           (local.get $2)
           (local.get $3)
          )
          (then
           (i64.const 1)
          )
          (else
           (call $function58
            (local.get $5)
            (local.get $6)
            (i32.const 0)
            (i32.const 1)
            (local.get $2)
           )
          )
         )
        )
       )
      )
     )
     (local.get $2)
     (local.get $4)
    )
   )
   (else
    (select
     (i64.const -1)
     (i64.const 1)
     (struct.get $type29 0
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function67 (type $46) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 (ref $type14)) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result (ref $type14))
  (if (result (ref $type14))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $3)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global186)
     )
    )
    (local.set $7
     (i64.add
      (local.get $7)
      (i64.add
       (if (result i64)
        (i64.gt_s
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (local.get $6)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global109)
          )
         )
         (if
          (i64.gt_u
           (local.get $6)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i64.extend_i32_s
          (array.get $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
        (else
         (i64.const 0)
        )
       )
       (if (result i64)
        (i64.gt_s
         (i64.extend_i32_u
          (array.len
           (local.get $1)
          )
         )
         (local.get $6)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global109)
          )
         )
         (if
          (i64.gt_u
           (local.get $6)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i64.extend_i32_s
          (array.get $type14
           (local.get $1)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
        (else
         (i64.const 0)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $3)
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (i64.rem_s
       (local.get $7)
       (i64.const 1073741824)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $7)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function69 (type $46) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 (ref $type14)) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result (ref $type14))
  (if (result (ref $type14))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global186)
     )
    )
    (local.set $7
     (i64.sub
      (i64.sub
       (i64.extend_i32_s
        (array.get $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $6)
         )
        )
       )
       (if (result i64)
        (i64.gt_s
         (i64.extend_i32_u
          (array.len
           (local.get $1)
          )
         )
         (local.get $6)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global109)
          )
         )
         (if
          (i64.gt_u
           (local.get $6)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (i64.extend_i32_s
          (array.get $type14
           (local.get $1)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
        (else
         (i64.const 0)
        )
       )
      )
      (local.get $7)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $3)
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (select
       (i64.add
        (local.get $7)
        (i64.const 1073741824)
       )
       (local.get $7)
       (i64.lt_s
        (local.get $7)
        (i64.const 0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function69
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (i64.extend_i32_u
      (i64.lt_s
       (local.get $7)
       (i64.const 0)
      )
     )
    )
   )
  )
 )
 (func $function71 (type $45) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type29))
  (local $2 (ref $type14))
  (local $3 (ref $type14))
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (local $scratch (ref $type14))
  (local $scratch_8 (ref $type14))
  (local $scratch_9 (ref $type14))
  (local.set $2
   (struct.get $type29 1
    (local.get $0)
   )
  )
  (local.set $3
   (struct.get $type29 1
    (local.get $1)
   )
  )
  (if (result (ref $type29))
   (select
    (local.tee $6
     (struct.get $type29 0
      (local.get $1)
     )
    )
    (i32.eqz
     (local.get $6)
    )
    (local.tee $6
     (struct.get $type29 0
      (local.get $0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global189)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function46
          (block (result (ref $type14))
           (local.set $scratch
            (call $function67
             (local.get $2)
             (local.get $3)
             (local.tee $4
              (select
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (local.tee $5
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.gt_s
                (local.get $4)
                (local.get $5)
               )
              )
             )
             (block (result (ref (exact $type14)))
              (if
               (i64.gt_u
                (local.tee $4
                 (i64.add
                  (local.get $4)
                  (i64.const 1)
                 )
                )
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (array.new_default $type14
               (i32.wrap_i64
                (local.get $4)
               )
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type29
       (local.get $6)
       (local.get $2)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (local.set $6
     (struct.get $type29 0
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (if (result (ref $type29))
     (i64.lt_s
      (if (result i64)
       (i64.lt_s
        (local.tee $4
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
        )
        (local.tee $5
         (i64.extend_i32_u
          (array.len
           (local.get $3)
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (if (result i64)
         (i64.gt_s
          (local.get $4)
          (local.get $5)
         )
         (then
          (i64.const 1)
         )
         (else
          (call $function58
           (local.get $2)
           (local.get $3)
           (i32.const 0)
           (i32.const 1)
           (local.get $4)
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global198)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global116)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function46
            (block (result (ref $type14))
             (local.set $scratch_8
              (call $function69
               (local.get $3)
               (local.get $2)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (block (result (ref (exact $type14)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type14
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch_8)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type29
         (i32.eqz
          (local.get $6)
         )
         (local.get $2)
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global198)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global116)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $2
           (call $function46
            (block (result (ref $type14))
             (local.set $scratch_9
              (call $function69
               (local.get $2)
               (local.get $3)
               (local.tee $4
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
               )
               (block (result (ref (exact $type14)))
                (if
                 (i64.gt_u
                  (local.get $4)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type14
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
               )
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch_9)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type29
         (local.get $6)
         (local.get $2)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function73 (type $call46) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i64) (result i32)
  (return_call $function74
   (local.get $0)
   (local.get $1)
   (local.get $2)
   (local.get $3)
   (i64.extend_i32_u
    (array.len
     (local.get $1)
    )
   )
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $function74 (type $43) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i64) (param $8 i64) (result i32)
  (local $9 i64)
  (local $10 i64)
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $7)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.add
        (local.get $2)
        (local.get $4)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $9
       (i64.add
        (local.get $2)
        (local.get $7)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.rem_s
      (local.tee $8
       (i64.add
        (local.get $8)
        (i64.add
         (i64.extend_i32_s
          (array.get $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $9)
           )
          )
         )
         (i64.mul
          (local.get $3)
          (i64.extend_i32_s
           (array.get $type14
            (local.get $1)
            (i32.wrap_i64
             (local.get $7)
            )
           )
          )
         )
        )
       )
      )
      (i64.const 1073741824)
     )
    )
    (if
     (i64.gt_u
      (local.get $9)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $9)
     )
     (i32.wrap_i64
      (local.get $10)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (i64.add
      (local.get $7)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $8)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function75 (type $call43) (param $0 (ref $type14)) (param $1 (ref $type14)) (result (ref $type14))
  (local $2 (ref $type14))
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i64.gt_u
    (local.tee $3
     (i64.add
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.extend_i32_u
       (array.len
        (local.get $1)
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (array.new_default $type14
    (i32.wrap_i64
     (local.get $3)
    )
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global219)
     )
    )
    (drop
     (call $function74
      (local.get $2)
      (local.get $1)
      (i64.const 0)
      (i64.extend_i32_s
       (array.get $type14
        (local.get $0)
        (i32.const 0)
       )
      )
      (i64.extend_i32_u
       (array.len
        (local.get $1)
       )
      )
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
    )
    (if (result (ref $type14))
     (i64.eq
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (then
      (local.get $2)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global109)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global219)
       )
      )
      (drop
       (call $function74
        (local.get $2)
        (local.get $1)
        (i64.const 1)
        (i64.extend_i32_s
         (array.get $type14
          (local.get $0)
          (i32.const 1)
         )
        )
        (i64.extend_i32_u
         (array.len
          (local.get $1)
         )
        )
        (i32.const 0)
        (i32.const 1)
        (i64.const 0)
        (i64.const 0)
       )
      )
      (if (result (ref $type14))
       (i64.eq
        (i64.extend_i32_u
         (array.len
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (then
        (local.get $2)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global109)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global219)
         )
        )
        (drop
         (call $function74
          (local.get $2)
          (local.get $1)
          (i64.const 2)
          (i64.extend_i32_s
           (array.get $type14
            (local.get $0)
            (i32.const 2)
           )
          )
          (i64.extend_i32_u
           (array.len
            (local.get $1)
           )
          )
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
          (i64.const 0)
         )
        )
        (if (result (ref $type14))
         (i64.eq
          (i64.extend_i32_u
           (array.len
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (then
          (local.get $2)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global109)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global219)
           )
          )
          (drop
           (call $function74
            (local.get $2)
            (local.get $1)
            (i64.const 3)
            (i64.extend_i32_s
             (array.get $type14
              (local.get $0)
              (i32.const 3)
             )
            )
            (i64.extend_i32_u
             (array.len
              (local.get $1)
             )
            )
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
            (i64.const 0)
           )
          )
          (if (result (ref $type14))
           (i64.eq
            (i64.extend_i32_u
             (array.len
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (then
            (local.get $2)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global109)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global219)
             )
            )
            (drop
             (call $function74
              (local.get $2)
              (local.get $1)
              (i64.const 4)
              (i64.extend_i32_s
               (array.get $type14
                (local.get $0)
                (i32.const 4)
               )
              )
              (i64.extend_i32_u
               (array.len
                (local.get $1)
               )
              )
              (i32.const 0)
              (i32.const 1)
              (i64.const 0)
              (i64.const 0)
             )
            )
            (if (result (ref $type14))
             (i64.eq
              (i64.extend_i32_u
               (array.len
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (then
              (local.get $2)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global109)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global219)
               )
              )
              (drop
               (call $function74
                (local.get $2)
                (local.get $1)
                (i64.const 5)
                (i64.extend_i32_s
                 (array.get $type14
                  (local.get $0)
                  (i32.const 5)
                 )
                )
                (i64.extend_i32_u
                 (array.len
                  (local.get $1)
                 )
                )
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
                (i64.const 0)
               )
              )
              (if (result (ref $type14))
               (i64.eq
                (i64.extend_i32_u
                 (array.len
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (then
                (local.get $2)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global109)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global219)
                 )
                )
                (drop
                 (call $function74
                  (local.get $2)
                  (local.get $1)
                  (i64.const 6)
                  (i64.extend_i32_s
                   (array.get $type14
                    (local.get $0)
                    (i32.const 6)
                   )
                  )
                  (i64.extend_i32_u
                   (array.len
                    (local.get $1)
                   )
                  )
                  (i32.const 0)
                  (i32.const 1)
                  (i64.const 0)
                  (i64.const 0)
                 )
                )
                (if (result (ref $type14))
                 (i64.eq
                  (i64.extend_i32_u
                   (array.len
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global109)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global219)
                   )
                  )
                  (drop
                   (call $function74
                    (local.get $2)
                    (local.get $1)
                    (i64.const 7)
                    (i64.extend_i32_s
                     (array.get $type14
                      (local.get $0)
                      (i32.const 7)
                     )
                    )
                    (i64.extend_i32_u
                     (array.len
                      (local.get $1)
                     )
                    )
                    (i32.const 0)
                    (i32.const 1)
                    (i64.const 0)
                    (i64.const 0)
                   )
                  )
                  (if (result (ref $type14))
                   (i64.eq
                    (i64.extend_i32_u
                     (array.len
                      (local.get $0)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global109)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global219)
                     )
                    )
                    (drop
                     (call $function74
                      (local.get $2)
                      (local.get $1)
                      (i64.const 8)
                      (i64.extend_i32_s
                       (array.get $type14
                        (local.get $0)
                        (i32.const 8)
                       )
                      )
                      (i64.extend_i32_u
                       (array.len
                        (local.get $1)
                       )
                      )
                      (i32.const 0)
                      (i32.const 1)
                      (i64.const 0)
                      (i64.const 0)
                     )
                    )
                    (if (result (ref $type14))
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $0)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (local.get $2)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global109)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global219)
                       )
                      )
                      (drop
                       (call $function74
                        (local.get $2)
                        (local.get $1)
                        (i64.const 9)
                        (i64.extend_i32_s
                         (array.get $type14
                          (local.get $0)
                          (i32.const 9)
                         )
                        )
                        (i64.extend_i32_u
                         (array.len
                          (local.get $1)
                         )
                        )
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 0)
                        (i64.const 0)
                       )
                      )
                      (if (result (ref $type14))
                       (i64.eq
                        (i64.extend_i32_u
                         (array.len
                          (local.get $0)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (local.get $2)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global109)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global219)
                         )
                        )
                        (drop
                         (call $function74
                          (local.get $2)
                          (local.get $1)
                          (i64.const 10)
                          (i64.extend_i32_s
                           (array.get $type14
                            (local.get $0)
                            (i32.const 10)
                           )
                          )
                          (i64.extend_i32_u
                           (array.len
                            (local.get $1)
                           )
                          )
                          (i32.const 0)
                          (i32.const 1)
                          (i64.const 0)
                          (i64.const 0)
                         )
                        )
                        (if (result (ref $type14))
                         (i64.eq
                          (i64.extend_i32_u
                           (array.len
                            (local.get $0)
                           )
                          )
                          (i64.const 11)
                         )
                         (then
                          (local.get $2)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global109)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global219)
                           )
                          )
                          (drop
                           (call $function74
                            (local.get $2)
                            (local.get $1)
                            (i64.const 11)
                            (i64.extend_i32_s
                             (array.get $type14
                              (local.get $0)
                              (i32.const 11)
                             )
                            )
                            (i64.extend_i32_u
                             (array.len
                              (local.get $1)
                             )
                            )
                            (i32.const 0)
                            (i32.const 1)
                            (i64.const 0)
                            (i64.const 0)
                           )
                          )
                          (if (result (ref $type14))
                           (i64.eq
                            (i64.extend_i32_u
                             (array.len
                              (local.get $0)
                             )
                            )
                            (i64.const 12)
                           )
                           (then
                            (local.get $2)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global109)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global219)
                             )
                            )
                            (drop
                             (call $function74
                              (local.get $2)
                              (local.get $1)
                              (i64.const 12)
                              (i64.extend_i32_s
                               (array.get $type14
                                (local.get $0)
                                (i32.const 12)
                               )
                              )
                              (i64.extend_i32_u
                               (array.len
                                (local.get $1)
                               )
                              )
                              (i32.const 0)
                              (i32.const 1)
                              (i64.const 0)
                              (i64.const 0)
                             )
                            )
                            (if (result (ref $type14))
                             (i64.eq
                              (i64.extend_i32_u
                               (array.len
                                (local.get $0)
                               )
                              )
                              (i64.const 13)
                             )
                             (then
                              (local.get $2)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global109)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global219)
                               )
                              )
                              (drop
                               (call $function74
                                (local.get $2)
                                (local.get $1)
                                (i64.const 13)
                                (i64.extend_i32_s
                                 (array.get $type14
                                  (local.get $0)
                                  (i32.const 13)
                                 )
                                )
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $1)
                                 )
                                )
                                (i32.const 0)
                                (i32.const 1)
                                (i64.const 0)
                                (i64.const 0)
                               )
                              )
                              (if (result (ref $type14))
                               (i64.eq
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $0)
                                 )
                                )
                                (i64.const 14)
                               )
                               (then
                                (local.get $2)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global109)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global219)
                                 )
                                )
                                (drop
                                 (call $function74
                                  (local.get $2)
                                  (local.get $1)
                                  (i64.const 14)
                                  (i64.extend_i32_s
                                   (array.get $type14
                                    (local.get $0)
                                    (i32.const 14)
                                   )
                                  )
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $1)
                                   )
                                  )
                                  (i32.const 0)
                                  (i32.const 1)
                                  (i64.const 0)
                                  (i64.const 0)
                                 )
                                )
                                (if (result (ref $type14))
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 15)
                                 )
                                 (then
                                  (local.get $2)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global109)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global219)
                                   )
                                  )
                                  (drop
                                   (call $function74
                                    (local.get $2)
                                    (local.get $1)
                                    (i64.const 15)
                                    (i64.extend_i32_s
                                     (array.get $type14
                                      (local.get $0)
                                      (i32.const 15)
                                     )
                                    )
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $1)
                                     )
                                    )
                                    (i32.const 0)
                                    (i32.const 1)
                                    (i64.const 0)
                                    (i64.const 0)
                                   )
                                  )
                                  (if (result (ref $type14))
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 16)
                                   )
                                   (then
                                    (local.get $2)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global109)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global219)
                                     )
                                    )
                                    (drop
                                     (call $function74
                                      (local.get $2)
                                      (local.get $1)
                                      (i64.const 16)
                                      (i64.extend_i32_s
                                       (array.get $type14
                                        (local.get $0)
                                        (i32.const 16)
                                       )
                                      )
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.get $1)
                                       )
                                      )
                                      (i32.const 0)
                                      (i32.const 1)
                                      (i64.const 0)
                                      (i64.const 0)
                                     )
                                    )
                                    (if (result (ref $type14))
                                     (i64.eq
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 17)
                                     )
                                     (then
                                      (local.get $2)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global109)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global219)
                                       )
                                      )
                                      (drop
                                       (call $function74
                                        (local.get $2)
                                        (local.get $1)
                                        (i64.const 17)
                                        (i64.extend_i32_s
                                         (array.get $type14
                                          (local.get $0)
                                          (i32.const 17)
                                         )
                                        )
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.get $1)
                                         )
                                        )
                                        (i32.const 0)
                                        (i32.const 1)
                                        (i64.const 0)
                                        (i64.const 0)
                                       )
                                      )
                                      (if (result (ref $type14))
                                       (i64.eq
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 18)
                                       )
                                       (then
                                        (local.get $2)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global109)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global219)
                                         )
                                        )
                                        (drop
                                         (call $function74
                                          (local.get $2)
                                          (local.get $1)
                                          (i64.const 18)
                                          (i64.extend_i32_s
                                           (array.get $type14
                                            (local.get $0)
                                            (i32.const 18)
                                           )
                                          )
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.get $1)
                                           )
                                          )
                                          (i32.const 0)
                                          (i32.const 1)
                                          (i64.const 0)
                                          (i64.const 0)
                                         )
                                        )
                                        (if (result (ref $type14))
                                         (i64.eq
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 19)
                                         )
                                         (then
                                          (local.get $2)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global109)
                                           )
                                          )
                                          (local.set $3
                                           (call $function41
                                            (local.get $0)
                                            (i64.const 19)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global219)
                                           )
                                          )
                                          (drop
                                           (call $function73
                                            (local.get $2)
                                            (local.get $1)
                                            (i64.const 19)
                                            (local.get $3)
                                           )
                                          )
                                          (return_call $function76
                                           (local.get $0)
                                           (local.get $1)
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function76 (type $41) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 (ref $type14)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type14))
  (local $6 i64)
  (if (result (ref $type14))
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.set $6
     (call $function41
      (local.get $0)
      (local.get $5)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global219)
     )
    )
    (drop
     (call $function73
      (local.get $2)
      (local.get $1)
      (local.get $5)
      (local.get $6)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function76
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function77 (type $45) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type29))
  (local $2 (ref $type14))
  (local $3 i32)
  (local $scratch (ref $type14))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type29))
   (if (result i32)
    (i64.eqz
     (i64.extend_i32_u
      (array.len
       (struct.get $type29 1
        (local.get $0)
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global130)
      )
     )
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type29 1
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (ref.as_non_null
     (global.get $global108)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global230)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $2
         (call $function46
          (block (result (ref $type14))
           (local.set $scratch
            (call $function75
             (struct.get $type29 1
              (local.get $0)
             )
             (struct.get $type29 1
              (local.get $1)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (local.set $3
            (select
             (i32.eqz
              (local.tee $3
               (struct.get $type29 0
                (local.get $1)
               )
              )
             )
             (local.get $3)
             (struct.get $type29 0
              (local.get $0)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type29
       (local.get $3)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function79 (type $40) (param $0 (ref $type14)) (param $1 i64) (param $2 i64) (param $3 (ref $type14)) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result (ref $type14))
  (local $8 i64)
  (if (result (ref $type14))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $3)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (i64.rem_s
      (local.tee $7
       (i64.add
        (local.get $7)
        (i64.mul
         (local.get $1)
         (i64.extend_i32_s
          (array.get $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
       )
      )
      (i64.const 1073741824)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $3)
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function79
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $7)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function80 (type $39) (param $0 (ref $type14)) (param $1 (ref $type14)) (result i64)
  (return_call $function81
   (local.get $0)
   (local.get $1)
   (i64.const 1000000000)
   (i32.const 0)
   (i32.const 1)
   (i64.extend_i32_u
    (array.len
     (local.get $1)
    )
   )
   (i64.const 0)
  )
 )
 (func $function81 (type $38) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i64)
  (local $7 i64)
  (local $8 i64)
  (if (result i64)
   (i64.eqz
    (local.get $5)
   )
   (then
    (local.get $6)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (i64.div_s
      (local.tee $6
       (i64.add
        (i64.extend_i32_s
         (array.get $type14
          (local.get $1)
          (i32.wrap_i64
           (local.get $7)
          )
         )
        )
        (i64.shl
         (local.get $6)
         (i64.const 30)
        )
       )
      )
      (local.get $2)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (local.set $6
     (i64.rem_s
      (local.get $6)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function83 (type $37) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i64) (param $8 i64) (result i64)
  (local $9 i64)
  (local $10 i64)
  (if (result i64)
   (if (result i32)
    (i64.lt_s
     (local.get $8)
     (i64.const 1073741824)
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (if
      (i64.gt_u
       (local.tee $9
        (i64.sub
         (i64.add
          (local.get $2)
          (local.get $3)
         )
         (i64.const 2)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.gt_u
       (local.tee $10
        (i64.sub
         (local.get $3)
         (i64.const 2)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.lt_s
      (i64.add
       (i64.extend_i32_s
        (array.get $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $9)
         )
        )
       )
       (i64.shl
        (local.get $8)
        (i64.const 30)
       )
      )
      (i64.mul
       (local.get $7)
       (i64.extend_i32_s
        (array.get $type14
         (local.get $1)
         (i32.wrap_i64
          (local.get $10)
         )
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function83
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (i64.sub
      (local.get $7)
      (i64.const 1)
     )
     (i64.add
      (local.get $4)
      (local.get $8)
     )
    )
   )
   (else
    (local.get $7)
   )
  )
 )
 (func $function85 (type $43) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i64) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i64) (param $8 i64) (result i32)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (if (result i32)
   (i64.eq
    (local.get $4)
    (local.get $7)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (i64.add
        (local.get $2)
        (local.get $4)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.lt_s
       (local.tee $3
        (i64.sub
         (i64.extend_i32_s
          (array.get $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
         (local.get $8)
        )
       )
       (i64.const -1)
      )
      (then
       (i32.const 1)
      )
      (else
       (i64.gt_s
        (local.get $3)
        (i64.const 0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $3
     (select
      (i64.add
       (local.get $3)
       (i64.const 1073741824)
      )
      (local.get $3)
      (local.tee $5
       (i64.lt_s
        (local.get $3)
        (i64.const 0)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.add
        (local.get $2)
        (local.get $4)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.get $5)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $10
     (i64.add
      (local.get $8)
      (i64.mul
       (local.get $3)
       (i64.extend_i32_s
        (array.get $type14
         (local.get $1)
         (i32.wrap_i64
          (local.get $7)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.add
        (local.get $2)
        (local.get $7)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (select
      (i64.add
       (local.tee $9
        (i64.sub
         (i64.extend_i32_s
          (array.get $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
         (i64.and
          (local.get $10)
          (i64.const 1073741823)
         )
        )
       )
       (i64.const 1073741824)
      )
      (local.get $9)
      (i64.lt_s
       (local.get $9)
       (i64.const 0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $11)
     )
    )
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function85
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (i64.add
      (local.get $7)
      (i64.const 1)
     )
     (i64.add
      (i64.extend_i32_u
       (i64.lt_s
        (local.get $9)
        (i64.const 0)
       )
      )
      (i64.shr_u
       (local.get $10)
       (i64.const 30)
      )
     )
    )
   )
  )
 )
 (func $function87 (type $36) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i64) (param $7 i64) (result i32)
  (local $8 i64)
  (local $9 i64)
  (if (result i32)
   (i64.eq
    (local.get $3)
    (local.get $6)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.add
        (local.get $2)
        (local.get $3)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i64.rem_s
      (i64.add
       (local.get $7)
       (i64.extend_i32_s
        (array.get $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1073741824)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.add
        (local.get $2)
        (local.get $6)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (i64.rem_s
      (local.tee $7
       (i64.add
        (local.get $7)
        (i64.add
         (i64.extend_i32_s
          (array.get $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $8)
           )
          )
         )
         (i64.extend_i32_s
          (array.get $type14
           (local.get $1)
           (i32.wrap_i64
            (local.get $6)
           )
          )
         )
        )
       )
      )
      (i64.const 1073741824)
     )
    )
    (if
     (i64.gt_u
      (local.get $8)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $8)
     )
     (i32.wrap_i64
      (local.get $9)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $7)
      (i64.const 1073741824)
     )
    )
   )
  )
 )
 (func $function88 (type $call48) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (drop
   (ref.as_non_null
    (global.get $global256)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (if
   (i64.gt_u
    (local.tee $4
     (i64.sub
      (local.tee $3
       (i64.extend_i32_u
        (array.len
         (local.get $1)
        )
       )
      )
      (i64.const 1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (local.set $3
   (call $function83
    (local.get $0)
    (local.get $1)
    (local.get $2)
    (local.get $3)
    (local.tee $4
     (i64.extend_i32_s
      (array.get $type14
       (local.get $1)
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (i32.const 0)
    (i32.const 1)
    (block (result i64)
     (if
      (i64.gt_u
       (local.tee $3
        (i64.add
         (local.get $2)
         (local.get $3)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (if
      (i64.gt_u
       (local.tee $5
        (i64.sub
         (local.get $3)
         (i64.const 1)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.ge_s
       (local.tee $3
        (i64.div_s
         (local.tee $5
          (i64.add
           (i64.extend_i32_s
            (array.get $type14
             (local.get $0)
             (i32.wrap_i64
              (local.get $5)
             )
            )
           )
           (i64.shl
            (i64.extend_i32_s
             (array.get $type14
              (local.get $0)
              (i32.wrap_i64
               (local.get $3)
              )
             )
            )
            (i64.const 30)
           )
          )
         )
         (local.get $4)
        )
       )
       (i64.const 1073741824)
      )
      (then
       (local.set $3
        (i64.const 1073741823)
       )
      )
     )
     (local.get $3)
    )
    (i64.sub
     (local.get $5)
     (i64.mul
      (local.get $3)
      (local.get $4)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global268)
   )
  )
  (if (result i64)
   (call $function85
    (local.get $0)
    (local.get $1)
    (local.get $2)
    (local.get $3)
    (local.tee $4
     (i64.extend_i32_u
      (array.len
       (local.get $1)
      )
     )
    )
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (drop
     (call $function87
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
    )
    (i64.sub
     (local.get $3)
     (i64.const 1)
    )
   )
   (else
    (local.get $3)
   )
  )
 )
 (func $function89 (type $34) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 (ref $type14)) (result i32)
  (local $3 i64)
  (local $4 i64)
  (if (result i32)
   (i64.eqz
    (local.tee $3
     (i64.extend_i32_u
      (array.len
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global289)
     )
    )
    (local.set $4
     (call $function88
      (local.get $1)
      (local.get $2)
      (local.tee $3
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $0)
     (i32.wrap_i64
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (if (result i32)
     (i64.eqz
      (local.get $3)
     )
     (then
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global289)
       )
      )
      (local.set $4
       (call $function88
        (local.get $1)
        (local.get $2)
        (local.tee $3
         (i64.sub
          (local.get $3)
          (i64.const 1)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global112)
       )
      )
      (if
       (i64.gt_u
        (local.get $3)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (local.get $0)
       (i32.wrap_i64
        (local.get $3)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
      (if (result i32)
       (i64.eqz
        (local.get $3)
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global289)
         )
        )
        (local.set $4
         (call $function88
          (local.get $1)
          (local.get $2)
          (local.tee $3
           (i64.sub
            (local.get $3)
            (i64.const 1)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global112)
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type14
         (local.get $0)
         (i32.wrap_i64
          (local.get $3)
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
        (if (result i32)
         (i64.eqz
          (local.get $3)
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global289)
           )
          )
          (local.set $4
           (call $function88
            (local.get $1)
            (local.get $2)
            (local.tee $3
             (i64.sub
              (local.get $3)
              (i64.const 1)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global112)
           )
          )
          (if
           (i64.gt_u
            (local.get $3)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (array.set $type14
           (local.get $0)
           (i32.wrap_i64
            (local.get $3)
           )
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (if (result i32)
           (i64.eqz
            (local.get $3)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global289)
             )
            )
            (local.set $4
             (call $function88
              (local.get $1)
              (local.get $2)
              (local.tee $3
               (i64.sub
                (local.get $3)
                (i64.const 1)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global112)
             )
            )
            (if
             (i64.gt_u
              (local.get $3)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (array.set $type14
             (local.get $0)
             (i32.wrap_i64
              (local.get $3)
             )
             (i32.wrap_i64
              (local.get $4)
             )
            )
            (if (result i32)
             (i64.eqz
              (local.get $3)
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global289)
               )
              )
              (local.set $4
               (call $function88
                (local.get $1)
                (local.get $2)
                (local.tee $3
                 (i64.sub
                  (local.get $3)
                  (i64.const 1)
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global112)
               )
              )
              (if
               (i64.gt_u
                (local.get $3)
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (array.set $type14
               (local.get $0)
               (i32.wrap_i64
                (local.get $3)
               )
               (i32.wrap_i64
                (local.get $4)
               )
              )
              (if (result i32)
               (i64.eqz
                (local.get $3)
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global289)
                 )
                )
                (local.set $4
                 (call $function88
                  (local.get $1)
                  (local.get $2)
                  (local.tee $3
                   (i64.sub
                    (local.get $3)
                    (i64.const 1)
                   )
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global112)
                 )
                )
                (if
                 (i64.gt_u
                  (local.get $3)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.set $type14
                 (local.get $0)
                 (i32.wrap_i64
                  (local.get $3)
                 )
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
                (if (result i32)
                 (i64.eqz
                  (local.get $3)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global289)
                   )
                  )
                  (local.set $4
                   (call $function88
                    (local.get $1)
                    (local.get $2)
                    (local.tee $3
                     (i64.sub
                      (local.get $3)
                      (i64.const 1)
                     )
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global112)
                   )
                  )
                  (if
                   (i64.gt_u
                    (local.get $3)
                    (i64.const 4294967295)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (array.set $type14
                   (local.get $0)
                   (i32.wrap_i64
                    (local.get $3)
                   )
                   (i32.wrap_i64
                    (local.get $4)
                   )
                  )
                  (if (result i32)
                   (i64.eqz
                    (local.get $3)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global289)
                     )
                    )
                    (local.set $4
                     (call $function88
                      (local.get $1)
                      (local.get $2)
                      (local.tee $3
                       (i64.sub
                        (local.get $3)
                        (i64.const 1)
                       )
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global112)
                     )
                    )
                    (if
                     (i64.gt_u
                      (local.get $3)
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (array.set $type14
                     (local.get $0)
                     (i32.wrap_i64
                      (local.get $3)
                     )
                     (i32.wrap_i64
                      (local.get $4)
                     )
                    )
                    (if (result i32)
                     (i64.eqz
                      (local.get $3)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global289)
                       )
                      )
                      (local.set $4
                       (call $function88
                        (local.get $1)
                        (local.get $2)
                        (local.tee $3
                         (i64.sub
                          (local.get $3)
                          (i64.const 1)
                         )
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global112)
                       )
                      )
                      (if
                       (i64.gt_u
                        (local.get $3)
                        (i64.const 4294967295)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (array.set $type14
                       (local.get $0)
                       (i32.wrap_i64
                        (local.get $3)
                       )
                       (i32.wrap_i64
                        (local.get $4)
                       )
                      )
                      (if (result i32)
                       (i64.eqz
                        (local.get $3)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global289)
                         )
                        )
                        (local.set $4
                         (call $function88
                          (local.get $1)
                          (local.get $2)
                          (local.tee $3
                           (i64.sub
                            (local.get $3)
                            (i64.const 1)
                           )
                          )
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global112)
                         )
                        )
                        (if
                         (i64.gt_u
                          (local.get $3)
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (array.set $type14
                         (local.get $0)
                         (i32.wrap_i64
                          (local.get $3)
                         )
                         (i32.wrap_i64
                          (local.get $4)
                         )
                        )
                        (if (result i32)
                         (i64.eqz
                          (local.get $3)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global289)
                           )
                          )
                          (local.set $4
                           (call $function88
                            (local.get $1)
                            (local.get $2)
                            (local.tee $3
                             (i64.sub
                              (local.get $3)
                              (i64.const 1)
                             )
                            )
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global112)
                           )
                          )
                          (if
                           (i64.gt_u
                            (local.get $3)
                            (i64.const 4294967295)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (array.set $type14
                           (local.get $0)
                           (i32.wrap_i64
                            (local.get $3)
                           )
                           (i32.wrap_i64
                            (local.get $4)
                           )
                          )
                          (if (result i32)
                           (i64.eqz
                            (local.get $3)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global289)
                             )
                            )
                            (local.set $4
                             (call $function88
                              (local.get $1)
                              (local.get $2)
                              (local.tee $3
                               (i64.sub
                                (local.get $3)
                                (i64.const 1)
                               )
                              )
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global112)
                             )
                            )
                            (if
                             (i64.gt_u
                              (local.get $3)
                              (i64.const 4294967295)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (array.set $type14
                             (local.get $0)
                             (i32.wrap_i64
                              (local.get $3)
                             )
                             (i32.wrap_i64
                              (local.get $4)
                             )
                            )
                            (if (result i32)
                             (i64.eqz
                              (local.get $3)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global289)
                               )
                              )
                              (local.set $4
                               (call $function88
                                (local.get $1)
                                (local.get $2)
                                (local.tee $3
                                 (i64.sub
                                  (local.get $3)
                                  (i64.const 1)
                                 )
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global112)
                               )
                              )
                              (if
                               (i64.gt_u
                                (local.get $3)
                                (i64.const 4294967295)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (array.set $type14
                               (local.get $0)
                               (i32.wrap_i64
                                (local.get $3)
                               )
                               (i32.wrap_i64
                                (local.get $4)
                               )
                              )
                              (if (result i32)
                               (i64.eqz
                                (local.get $3)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global289)
                                 )
                                )
                                (local.set $4
                                 (call $function88
                                  (local.get $1)
                                  (local.get $2)
                                  (local.tee $3
                                   (i64.sub
                                    (local.get $3)
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global112)
                                 )
                                )
                                (if
                                 (i64.gt_u
                                  (local.get $3)
                                  (i64.const 4294967295)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (array.set $type14
                                 (local.get $0)
                                 (i32.wrap_i64
                                  (local.get $3)
                                 )
                                 (i32.wrap_i64
                                  (local.get $4)
                                 )
                                )
                                (if (result i32)
                                 (i64.eqz
                                  (local.get $3)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global289)
                                   )
                                  )
                                  (local.set $4
                                   (call $function88
                                    (local.get $1)
                                    (local.get $2)
                                    (local.tee $3
                                     (i64.sub
                                      (local.get $3)
                                      (i64.const 1)
                                     )
                                    )
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global112)
                                   )
                                  )
                                  (if
                                   (i64.gt_u
                                    (local.get $3)
                                    (i64.const 4294967295)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (array.set $type14
                                   (local.get $0)
                                   (i32.wrap_i64
                                    (local.get $3)
                                   )
                                   (i32.wrap_i64
                                    (local.get $4)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eqz
                                    (local.get $3)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global289)
                                     )
                                    )
                                    (local.set $4
                                     (call $function88
                                      (local.get $1)
                                      (local.get $2)
                                      (local.tee $3
                                       (i64.sub
                                        (local.get $3)
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global112)
                                     )
                                    )
                                    (if
                                     (i64.gt_u
                                      (local.get $3)
                                      (i64.const 4294967295)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (array.set $type14
                                     (local.get $0)
                                     (i32.wrap_i64
                                      (local.get $3)
                                     )
                                     (i32.wrap_i64
                                      (local.get $4)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eqz
                                      (local.get $3)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global289)
                                       )
                                      )
                                      (local.set $4
                                       (call $function88
                                        (local.get $1)
                                        (local.get $2)
                                        (local.tee $3
                                         (i64.sub
                                          (local.get $3)
                                          (i64.const 1)
                                         )
                                        )
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global112)
                                       )
                                      )
                                      (if
                                       (i64.gt_u
                                        (local.get $3)
                                        (i64.const 4294967295)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (array.set $type14
                                       (local.get $0)
                                       (i32.wrap_i64
                                        (local.get $3)
                                       )
                                       (i32.wrap_i64
                                        (local.get $4)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eqz
                                        (local.get $3)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global289)
                                         )
                                        )
                                        (local.set $4
                                         (call $function88
                                          (local.get $1)
                                          (local.get $2)
                                          (local.tee $3
                                           (i64.sub
                                            (local.get $3)
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global112)
                                         )
                                        )
                                        (if
                                         (i64.gt_u
                                          (local.get $3)
                                          (i64.const 4294967295)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (array.set $type14
                                         (local.get $0)
                                         (i32.wrap_i64
                                          (local.get $3)
                                         )
                                         (i32.wrap_i64
                                          (local.get $4)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eqz
                                          (local.get $3)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global289)
                                           )
                                          )
                                          (local.set $3
                                           (call $function88
                                            (local.get $1)
                                            (local.get $2)
                                            (local.tee $4
                                             (i64.sub
                                              (local.get $3)
                                              (i64.const 1)
                                             )
                                            )
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global112)
                                           )
                                          )
                                          (call $function42
                                           (local.get $0)
                                           (local.get $4)
                                           (local.get $3)
                                          )
                                          (return_call $function90
                                           (local.get $0)
                                           (local.get $1)
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (local.get $4)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function90 (type $33) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 (ref $type14)) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (if (result i32)
   (i64.eqz
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global289)
     )
    )
    (local.set $7
     (call $function88
      (local.get $1)
      (local.get $2)
      (local.tee $6
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (call $function42
     (local.get $0)
     (local.get $6)
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function90
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function93 (type $32) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type53))
  (local $2 (ref $type14))
  (local $3 (ref $type14))
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $6 (ref $type14))
  (local $7 (ref $type29))
  (local $8 (ref $type29))
  (local $9 (ref $type53))
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i32)
  (local $scratch (ref $type14))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type53))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type29 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global309)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (local.set $7
     (struct.get $type53 0
      (local.tee $9
       (if (result (ref $type53))
        (i64.lt_s
         (if (result i64)
          (i64.lt_s
           (local.tee $10
            (i64.extend_i32_u
             (array.len
              (local.tee $2
               (struct.get $type29 1
                (local.get $0)
               )
              )
             )
            )
           )
           (local.tee $12
            (i64.extend_i32_u
             (array.len
              (local.tee $3
               (struct.get $type29 1
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (then
           (i64.const -1)
          )
          (else
           (if (result i64)
            (i64.gt_s
             (local.get $10)
             (local.get $12)
            )
            (then
             (i64.const 1)
            )
            (else
             (call $function58
              (local.get $2)
              (local.get $3)
              (i32.const 0)
              (i32.const 1)
              (local.get $10)
             )
            )
           )
          )
         )
         (i64.const 0)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global132)
          )
         )
         (struct.new $type53
          (ref.as_non_null
           (global.get $global108)
          )
          (if (result (ref $type29))
           (struct.get $type29 0
            (local.get $0)
           )
           (then
            (struct.new $type29
             (i32.const 0)
             (struct.get $type29 1
              (local.get $0)
             )
            )
           )
           (else
            (local.get $0)
           )
          )
         )
        )
        (else
         (if (result (ref $type53))
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $3)
            )
           )
           (i64.const 1)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global109)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global248)
            )
           )
           (if
            (i64.gt_u
             (local.tee $10
              (i64.extend_i32_u
               (array.len
                (local.get $2)
               )
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $10
            (call $function81
             (local.tee $4
              (array.new_default $type14
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
             (local.get $2)
             (i64.extend_i32_s
              (array.get $type14
               (local.get $3)
               (i32.const 0)
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $2)
              )
             )
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (struct.new $type53
            (if (result (ref $type29))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function46
                  (local.get $4)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global108)
              )
             )
             (else
              (struct.new $type29
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (block (result (ref $type29))
             (drop
              (ref.as_non_null
               (global.get $global141)
              )
             )
             (call $function53
              (local.get $10)
             )
            )
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global300)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global109)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global239)
            )
           )
           (if
            (i64.gt_u
             (local.tee $12
              (i64.sub
               (local.tee $10
                (i64.extend_i32_u
                 (array.len
                  (local.get $3)
                 )
                )
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (local.set $5
            (call $function79
             (local.get $2)
             (local.tee $12
              (i64.div_s
               (i64.const 1073741824)
               (i64.add
                (i64.extend_i32_s
                 (array.get $type14
                  (local.get $3)
                  (i32.wrap_i64
                   (local.get $12)
                  )
                 )
                )
                (i64.const 1)
               )
              )
             )
             (local.tee $11
              (i64.extend_i32_u
               (array.len
                (local.get $2)
               )
              )
             )
             (block (result (ref (exact $type14)))
              (if
               (i64.gt_u
                (local.tee $11
                 (i64.add
                  (local.get $11)
                  (i64.const 1)
                 )
                )
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (array.new_default $type14
               (i32.wrap_i64
                (local.get $11)
               )
              )
             )
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
             (i64.const 0)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global239)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (local.set $3
            (call $function46
             (block (result (ref $type14))
              (local.set $scratch
               (call $function79
                (local.get $3)
                (local.get $12)
                (local.tee $11
                 (i64.extend_i32_u
                  (array.len
                   (local.get $3)
                  )
                 )
                )
                (block (result (ref (exact $type14)))
                 (if
                  (i64.gt_u
                   (local.tee $11
                    (i64.add
                     (local.get $11)
                     (i64.const 1)
                    )
                   )
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (array.new_default $type14
                  (i32.wrap_i64
                   (local.get $11)
                  )
                 )
                )
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
                (i64.const 0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global122)
               )
              )
              (local.get $scratch)
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (if
            (i64.gt_u
             (local.tee $11
              (i64.add
               (i64.sub
                (i64.extend_i32_u
                 (array.len
                  (local.get $2)
                 )
                )
                (local.get $10)
               )
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global116)
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global294)
            )
           )
           (drop
            (call $function89
             (local.tee $6
              (array.new_default $type14
               (i32.wrap_i64
                (local.get $11)
               )
              )
             )
             (local.get $5)
             (local.get $3)
            )
           )
           (if
            (i64.gt_u
             (local.get $10)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (array.copy $type14 $type14
            (local.tee $4
             (array.new_default $type14
              (local.tee $13
               (i32.wrap_i64
                (local.get $10)
               )
              )
             )
            )
            (i32.const 0)
            (local.get $5)
            (i32.const 0)
            (local.get $13)
           )
           (drop
            (ref.as_non_null
             (global.get $global248)
            )
           )
           (if
            (i64.ne
             (call $function81
              (local.get $4)
              (local.get $4)
              (local.get $12)
              (i32.const 0)
              (i32.const 1)
              (i64.extend_i32_u
               (array.len
                (local.get $4)
               )
              )
              (i64.const 0)
             )
             (i64.const 0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global126)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (struct.new $type53
            (if (result (ref $type29))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $2
                 (call $function46
                  (local.get $6)
                 )
                )
               )
              )
             )
             (then
              (ref.as_non_null
               (global.get $global108)
              )
             )
             (else
              (struct.new $type29
               (i32.const 0)
               (local.get $2)
              )
             )
            )
            (block (result (ref $type29))
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (if (result (ref $type29))
              (i64.eqz
               (i64.extend_i32_u
                (array.len
                 (local.tee $2
                  (call $function46
                   (local.get $4)
                  )
                 )
                )
               )
              )
              (then
               (ref.as_non_null
                (global.get $global108)
               )
              )
              (else
               (struct.new $type29
                (i32.const 0)
                (local.get $2)
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.set $8
     (struct.get $type53 1
      (local.get $9)
     )
    )
    (struct.new $type53
     (if (result (ref $type29))
      (select
       (i32.eqz
        (local.tee $13
         (struct.get $type29 0
          (local.get $1)
         )
        )
       )
       (local.get $13)
       (struct.get $type29 0
        (local.get $0)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global134)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global130)
        )
       )
       (if (result (ref $type29))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type29 1
            (local.get $7)
           )
          )
         )
        )
        (then
         (local.get $7)
        )
        (else
         (struct.new $type29
          (i32.eqz
           (struct.get $type29 0
            (local.get $7)
           )
          )
          (struct.get $type29 1
           (local.get $7)
          )
         )
        )
       )
      )
      (else
       (local.get $7)
      )
     )
     (if (result (ref $type29))
      (struct.get $type29 0
       (local.get $0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global134)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global130)
        )
       )
       (if (result (ref $type29))
        (i64.eqz
         (i64.extend_i32_u
          (array.len
           (struct.get $type29 1
            (local.get $8)
           )
          )
         )
        )
        (then
         (local.get $8)
        )
        (else
         (struct.new $type29
          (i32.eqz
           (struct.get $type29 0
            (local.get $8)
           )
          )
          (struct.get $type29 1
           (local.get $8)
          )
         )
        )
       )
      )
      (else
       (local.get $8)
      )
     )
    )
   )
  )
 )
 (func $function95 (type $call45) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global316)
   )
  )
  (struct.get $type53 1
   (call $function93
    (local.get $0)
    (local.get $1)
   )
  )
 )
 (func $function97 (type $29) (param $0 (ref $type16)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i32)
  (local $7 i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.lt_s
       (local.tee $7
        (i64.sub
         (i64.extend_i32_u
          (array.get $type17
           (if (result (ref $type17))
            (i32.lt_u
             (local.tee $6
              (i32.wrap_i64
               (local.get $4)
              )
             )
             (i32.const 8192)
            )
            (then
             (struct.get $type16 2
              (local.get $0)
             )
            )
            (else
             (ref.as_non_null
              (array.get $type18
               (struct.get $type16 3
                (local.get $0)
               )
               (i32.sub
                (i32.shr_u
                 (local.get $6)
                 (i32.const 13)
                )
                (i32.const 1)
               )
              )
             )
            )
           )
           (i32.and
            (local.get $6)
            (i32.const 8191)
           )
          )
         )
         (i64.const 48)
        )
       )
       (i64.const 0)
      )
      (then
       (i32.const 1)
      )
      (else
       (i64.gt_s
        (local.get $7)
        (i64.const 9)
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function97
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
       (i64.add
        (local.get $7)
        (i64.mul
         (local.get $5)
         (i64.const 10)
        )
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function98 (type $28) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
     (then
      (i64.const 10)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (i64.const 100)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
         )
         (then
          (i64.const 1000)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
           )
           (then
            (i64.const 10000)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (i64.const 100000)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.sub
                  (local.get $0)
                  (i64.const 1)
                 )
                )
               )
               (then
                (i64.const 1000000)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (i64.const 10000000)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (i64.const 100000000)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (i64.const 1000000000)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.sub
                          (local.get $0)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (i64.const 10000000000)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (i64.const 100000000000)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.sub
                              (local.get $0)
                              (i64.const 1)
                             )
                            )
                           )
                           (then
                            (i64.const 1000000000000)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.sub
                                (local.get $0)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (i64.const 10000000000000)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                               )
                               (then
                                (i64.const 100000000000000)
                               )
                               (else
                                (if (result i64)
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.sub
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 1000000000000000)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.sub
                                      (local.get $0)
                                      (i64.const 1)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 10000000000000000)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.sub
                                        (local.get $0)
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 100000000000000000)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.sub
                                          (local.get $0)
                                          (i64.const 1)
                                         )
                                        )
                                       )
                                       (then
                                        (i64.const 1000000000000000000)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.sub
                                            (local.get $0)
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                         (then
                                          (i64.const -8446744073709551616)
                                         )
                                         (else
                                          (return_call $function99
                                           (i64.const 10)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.sub
                                            (local.get $0)
                                            (i64.const 1)
                                           )
                                           (i64.const 7766279631452241920)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function99 (type $27) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function99
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (i64.mul
      (local.get $0)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function101 (param $0 (ref $type16)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 (ref $type29)) (result (ref $type29))
  (local $7 i64)
  (local $8 i64)
  (local $9 (ref $type14))
  (local $10 (ref $type29))
  (local $scratch (ref $type14))
  (local $scratch_12 i64)
  (local $scratch_13 (ref $type29))
  (if (result (ref $type29))
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (if (result (ref $type29))
     (local.get $1)
     (then
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type29 1
           (local.get $6)
          )
         )
        )
       )
       (then
        (local.get $6)
       )
       (else
        (struct.new $type29
         (i32.eqz
          (struct.get $type29 0
           (local.get $6)
          )
         )
         (struct.get $type29 1
          (local.get $6)
         )
        )
       )
      )
     )
     (else
      (local.get $6)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global336)
     )
    )
    (local.set $7
     (call $function98
      (local.tee $8
       (select
        (i64.const 9)
        (local.tee $8
         (i64.sub
          (local.get $2)
          (local.get $5)
         )
        )
        (i64.gt_s
         (local.get $8)
         (i64.const 9)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global239)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (local.set $6
     (call $function71
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $9
           (call $function46
            (block (result (ref $type14))
             (local.set $scratch
              (call $function79
               (local.tee $9
                (struct.get $type29 1
                 (local.get $6)
                )
               )
               (local.get $7)
               (local.tee $7
                (i64.extend_i32_u
                 (array.len
                  (local.get $9)
                 )
                )
               )
               (block (result (ref (exact $type14)))
                (if
                 (i64.gt_u
                  (local.tee $7
                   (i64.add
                    (local.get $7)
                    (i64.const 1)
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.new_default $type14
                 (i32.wrap_i64
                  (local.get $7)
                 )
                )
               )
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
               (i64.const 0)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global126)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $scratch)
            )
           )
          )
         )
        )
       )
       (then
        (ref.as_non_null
         (global.get $global108)
        )
       )
       (else
        (struct.new $type29
         (i32.const 0)
         (local.get $9)
        )
       )
      )
      (block (result (ref $type29))
       (drop
        (ref.as_non_null
         (global.get $global328)
        )
       )
       (local.set $scratch_13
        (call $function53
         (block (result i64)
          (local.set $scratch_12
           (call $function97
            (local.get $0)
            (i64.add
             (local.get $5)
             (local.get $8)
            )
            (i32.const 0)
            (i32.const 1)
            (local.get $5)
            (i64.const 0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global141)
           )
          )
          (local.get $scratch_12)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global211)
        )
       )
       (local.get $scratch_13)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function101
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (local.get $8)
     )
     (local.get $6)
    )
   )
  )
 )
 (func $function102 (type $call58) (param $0 (ref $type16)) (result (ref $type29))
  (local $1 i32)
  (local $2 i32)
  (local $3 i64)
  (local $4 i64)
  (if
   (i64.eqz
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global342)
     )
    )
    (if
     (i64.eq
      (local.tee $3
       (i64.extend_i32_u
        (i32.or
         (local.tee $2
          (i32.eq
           (local.tee $1
            (array.get $type17
             (struct.get $type16 2
              (local.get $0)
             )
             (i32.const 0)
            )
           )
           (i32.const 45)
          )
         )
         (i32.eq
          (local.get $1)
          (i32.const 43)
         )
        )
       )
      )
      (local.tee $4
       (i64.extend_i32_u
        (struct.get $type16 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (return_call $function101
       (local.get $0)
       (local.get $2)
       (local.get $4)
       (i32.const 0)
       (i32.const 1)
       (local.get $3)
       (ref.as_non_null
        (global.get $global108)
       )
      )
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function107 (type $call62) (param $0 (ref $type14)) (result (ref null $type63))
  (local $1 (ref $type63))
  (local $2 (ref $type14))
  (local $3 i64)
  (drop
   (ref.as_non_null
    (global.get $global383)
   )
  )
  (if (result (ref null $type63))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.tee $2
       (if (result (ref $type14))
        (i64.eqz
         (local.tee $3
          (i64.extend_i32_u
           (array.len
            (local.get $0)
           )
          )
         )
        )
        (then
         (array.new_fixed $type14 0)
        )
        (else
         (if
          (i64.gt_u
           (local.get $3)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (array.new $type14
           (array.get $type14
            (local.get $0)
            (i32.const 0)
           )
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
         (if
          (i64.gt_u
           (local.get $3)
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (array.copy $type14 $type14
          (local.get $2)
          (i32.const 0)
          (local.get $0)
          (i32.const 0)
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (local.get $2)
        )
       )
      )
     )
    )
   )
   (then
    (ref.null none)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global248)
     )
    )
    (local.set $1
     (struct.new $type63
      (call $function81
       (local.get $2)
       (local.get $2)
       (i64.const 1000000000)
       (i32.const 0)
       (i32.const 1)
       (i64.extend_i32_u
        (array.len
         (local.get $2)
        )
       )
       (i64.const 0)
      )
      (block (result nullref)
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (ref.null none)
      )
     )
    )
    (if (result (ref $type63))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $0
         (call $function46
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global248)
       )
      )
      (local.set $1
       (struct.new $type63
        (call $function81
         (local.get $0)
         (local.get $0)
         (i64.const 1000000000)
         (i32.const 0)
         (i32.const 1)
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (i64.const 0)
        )
        (block (result (ref $type63))
         (drop
          (ref.as_non_null
           (global.get $global122)
          )
         )
         (local.get $1)
        )
       )
      )
      (if (result (ref $type63))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (local.tee $0
           (call $function46
            (local.get $0)
           )
          )
         )
        )
       )
       (then
        (local.get $1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global248)
         )
        )
        (local.set $1
         (struct.new $type63
          (call $function81
           (local.get $0)
           (local.get $0)
           (i64.const 1000000000)
           (i32.const 0)
           (i32.const 1)
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (i64.const 0)
          )
          (block (result (ref $type63))
           (drop
            (ref.as_non_null
             (global.get $global122)
            )
           )
           (local.get $1)
          )
         )
        )
        (if (result (ref $type63))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (local.tee $0
             (call $function46
              (local.get $0)
             )
            )
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global248)
           )
          )
          (local.set $1
           (struct.new $type63
            (call $function81
             (local.get $0)
             (local.get $0)
             (i64.const 1000000000)
             (i32.const 0)
             (i32.const 1)
             (i64.extend_i32_u
              (array.len
               (local.get $0)
              )
             )
             (i64.const 0)
            )
            (block (result (ref $type63))
             (drop
              (ref.as_non_null
               (global.get $global122)
              )
             )
             (local.get $1)
            )
           )
          )
          (if (result (ref $type63))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (local.tee $0
               (call $function46
                (local.get $0)
               )
              )
             )
            )
           )
           (then
            (local.get $1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global248)
             )
            )
            (local.set $1
             (struct.new $type63
              (call $function81
               (local.get $0)
               (local.get $0)
               (i64.const 1000000000)
               (i32.const 0)
               (i32.const 1)
               (i64.extend_i32_u
                (array.len
                 (local.get $0)
                )
               )
               (i64.const 0)
              )
              (block (result (ref $type63))
               (drop
                (ref.as_non_null
                 (global.get $global122)
                )
               )
               (local.get $1)
              )
             )
            )
            (if (result (ref $type63))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (local.tee $0
                 (call $function46
                  (local.get $0)
                 )
                )
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global248)
               )
              )
              (local.set $1
               (struct.new $type63
                (call $function81
                 (local.get $0)
                 (local.get $0)
                 (i64.const 1000000000)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.extend_i32_u
                  (array.len
                   (local.get $0)
                  )
                 )
                 (i64.const 0)
                )
                (block (result (ref $type63))
                 (drop
                  (ref.as_non_null
                   (global.get $global122)
                  )
                 )
                 (local.get $1)
                )
               )
              )
              (if (result (ref $type63))
               (i64.eqz
                (i64.extend_i32_u
                 (array.len
                  (local.tee $0
                   (call $function46
                    (local.get $0)
                   )
                  )
                 )
                )
               )
               (then
                (local.get $1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global248)
                 )
                )
                (local.set $1
                 (struct.new $type63
                  (call $function81
                   (local.get $0)
                   (local.get $0)
                   (i64.const 1000000000)
                   (i32.const 0)
                   (i32.const 1)
                   (i64.extend_i32_u
                    (array.len
                     (local.get $0)
                    )
                   )
                   (i64.const 0)
                  )
                  (block (result (ref $type63))
                   (drop
                    (ref.as_non_null
                     (global.get $global122)
                    )
                   )
                   (local.get $1)
                  )
                 )
                )
                (if (result (ref $type63))
                 (i64.eqz
                  (i64.extend_i32_u
                   (array.len
                    (local.tee $0
                     (call $function46
                      (local.get $0)
                     )
                    )
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global248)
                   )
                  )
                  (local.set $1
                   (struct.new $type63
                    (call $function81
                     (local.get $0)
                     (local.get $0)
                     (i64.const 1000000000)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.extend_i32_u
                      (array.len
                       (local.get $0)
                      )
                     )
                     (i64.const 0)
                    )
                    (block (result (ref $type63))
                     (drop
                      (ref.as_non_null
                       (global.get $global122)
                      )
                     )
                     (local.get $1)
                    )
                   )
                  )
                  (if (result (ref $type63))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (local.tee $0
                       (call $function46
                        (local.get $0)
                       )
                      )
                     )
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global248)
                     )
                    )
                    (local.set $1
                     (struct.new $type63
                      (call $function81
                       (local.get $0)
                       (local.get $0)
                       (i64.const 1000000000)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.extend_i32_u
                        (array.len
                         (local.get $0)
                        )
                       )
                       (i64.const 0)
                      )
                      (block (result (ref $type63))
                       (drop
                        (ref.as_non_null
                         (global.get $global122)
                        )
                       )
                       (local.get $1)
                      )
                     )
                    )
                    (if (result (ref $type63))
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (local.tee $0
                         (call $function46
                          (local.get $0)
                         )
                        )
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global248)
                       )
                      )
                      (local.set $1
                       (struct.new $type63
                        (call $function81
                         (local.get $0)
                         (local.get $0)
                         (i64.const 1000000000)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.extend_i32_u
                          (array.len
                           (local.get $0)
                          )
                         )
                         (i64.const 0)
                        )
                        (block (result (ref $type63))
                         (drop
                          (ref.as_non_null
                           (global.get $global122)
                          )
                         )
                         (local.get $1)
                        )
                       )
                      )
                      (if (result (ref $type63))
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (local.tee $0
                           (call $function46
                            (local.get $0)
                           )
                          )
                         )
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global248)
                         )
                        )
                        (local.set $1
                         (struct.new $type63
                          (call $function81
                           (local.get $0)
                           (local.get $0)
                           (i64.const 1000000000)
                           (i32.const 0)
                           (i32.const 1)
                           (i64.extend_i32_u
                            (array.len
                             (local.get $0)
                            )
                           )
                           (i64.const 0)
                          )
                          (block (result (ref $type63))
                           (drop
                            (ref.as_non_null
                             (global.get $global122)
                            )
                           )
                           (local.get $1)
                          )
                         )
                        )
                        (if (result (ref $type63))
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (local.tee $0
                             (call $function46
                              (local.get $0)
                             )
                            )
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global248)
                           )
                          )
                          (local.set $1
                           (struct.new $type63
                            (call $function81
                             (local.get $0)
                             (local.get $0)
                             (i64.const 1000000000)
                             (i32.const 0)
                             (i32.const 1)
                             (i64.extend_i32_u
                              (array.len
                               (local.get $0)
                              )
                             )
                             (i64.const 0)
                            )
                            (block (result (ref $type63))
                             (drop
                              (ref.as_non_null
                               (global.get $global122)
                              )
                             )
                             (local.get $1)
                            )
                           )
                          )
                          (if (result (ref $type63))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (local.tee $0
                               (call $function46
                                (local.get $0)
                               )
                              )
                             )
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global248)
                             )
                            )
                            (local.set $1
                             (struct.new $type63
                              (call $function81
                               (local.get $0)
                               (local.get $0)
                               (i64.const 1000000000)
                               (i32.const 0)
                               (i32.const 1)
                               (i64.extend_i32_u
                                (array.len
                                 (local.get $0)
                                )
                               )
                               (i64.const 0)
                              )
                              (block (result (ref $type63))
                               (drop
                                (ref.as_non_null
                                 (global.get $global122)
                                )
                               )
                               (local.get $1)
                              )
                             )
                            )
                            (if (result (ref $type63))
                             (i64.eqz
                              (i64.extend_i32_u
                               (array.len
                                (local.tee $0
                                 (call $function46
                                  (local.get $0)
                                 )
                                )
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global248)
                               )
                              )
                              (local.set $1
                               (struct.new $type63
                                (call $function81
                                 (local.get $0)
                                 (local.get $0)
                                 (i64.const 1000000000)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.extend_i32_u
                                  (array.len
                                   (local.get $0)
                                  )
                                 )
                                 (i64.const 0)
                                )
                                (block (result (ref $type63))
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global122)
                                  )
                                 )
                                 (local.get $1)
                                )
                               )
                              )
                              (if (result (ref $type63))
                               (i64.eqz
                                (i64.extend_i32_u
                                 (array.len
                                  (local.tee $0
                                   (call $function46
                                    (local.get $0)
                                   )
                                  )
                                 )
                                )
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global248)
                                 )
                                )
                                (local.set $1
                                 (struct.new $type63
                                  (call $function81
                                   (local.get $0)
                                   (local.get $0)
                                   (i64.const 1000000000)
                                   (i32.const 0)
                                   (i32.const 1)
                                   (i64.extend_i32_u
                                    (array.len
                                     (local.get $0)
                                    )
                                   )
                                   (i64.const 0)
                                  )
                                  (block (result (ref $type63))
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global122)
                                    )
                                   )
                                   (local.get $1)
                                  )
                                 )
                                )
                                (if (result (ref $type63))
                                 (i64.eqz
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.tee $0
                                     (call $function46
                                      (local.get $0)
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global248)
                                   )
                                  )
                                  (local.set $1
                                   (struct.new $type63
                                    (call $function81
                                     (local.get $0)
                                     (local.get $0)
                                     (i64.const 1000000000)
                                     (i32.const 0)
                                     (i32.const 1)
                                     (i64.extend_i32_u
                                      (array.len
                                       (local.get $0)
                                      )
                                     )
                                     (i64.const 0)
                                    )
                                    (block (result (ref $type63))
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global122)
                                      )
                                     )
                                     (local.get $1)
                                    )
                                   )
                                  )
                                  (if (result (ref $type63))
                                   (i64.eqz
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.tee $0
                                       (call $function46
                                        (local.get $0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global248)
                                     )
                                    )
                                    (local.set $1
                                     (struct.new $type63
                                      (call $function81
                                       (local.get $0)
                                       (local.get $0)
                                       (i64.const 1000000000)
                                       (i32.const 0)
                                       (i32.const 1)
                                       (i64.extend_i32_u
                                        (array.len
                                         (local.get $0)
                                        )
                                       )
                                       (i64.const 0)
                                      )
                                      (block (result (ref $type63))
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global122)
                                        )
                                       )
                                       (local.get $1)
                                      )
                                     )
                                    )
                                    (if (result (ref $type63))
                                     (i64.eqz
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.tee $0
                                         (call $function46
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global248)
                                       )
                                      )
                                      (local.set $1
                                       (struct.new $type63
                                        (call $function81
                                         (local.get $0)
                                         (local.get $0)
                                         (i64.const 1000000000)
                                         (i32.const 0)
                                         (i32.const 1)
                                         (i64.extend_i32_u
                                          (array.len
                                           (local.get $0)
                                          )
                                         )
                                         (i64.const 0)
                                        )
                                        (block (result (ref $type63))
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global122)
                                          )
                                         )
                                         (local.get $1)
                                        )
                                       )
                                      )
                                      (if (result (ref $type63))
                                       (i64.eqz
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.tee $0
                                           (call $function46
                                            (local.get $0)
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global248)
                                         )
                                        )
                                        (local.set $1
                                         (struct.new $type63
                                          (call $function81
                                           (local.get $0)
                                           (local.get $0)
                                           (i64.const 1000000000)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.extend_i32_u
                                            (array.len
                                             (local.get $0)
                                            )
                                           )
                                           (i64.const 0)
                                          )
                                          (block (result (ref $type63))
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global122)
                                            )
                                           )
                                           (local.get $1)
                                          )
                                         )
                                        )
                                        (if (result (ref $type63))
                                         (i64.eqz
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.tee $0
                                             (call $function46
                                              (local.get $0)
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global248)
                                           )
                                          )
                                          (local.set $3
                                           (call $function80
                                            (local.get $0)
                                            (local.get $0)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global122)
                                           )
                                          )
                                          (return_call $function108
                                           (i32.const 0)
                                           (i32.const 1)
                                           (call $function46
                                            (local.get $0)
                                           )
                                           (struct.new $type63
                                            (local.get $3)
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function108 (type $22) (param $0 i32) (param $1 i32) (param $2 (ref $type14)) (param $3 (ref $type63)) (result (ref null $type63))
  (local $4 i64)
  (if (result (ref $type63))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (local.get $2)
     )
    )
   )
   (then
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global248)
     )
    )
    (local.set $4
     (call $function80
      (local.get $2)
      (local.get $2)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (local.set $2
     (call $function46
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function108
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (struct.new $type63
      (local.get $4)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function110 (type $call37) (param $0 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $0)
    (i64.const 10)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 10)
       )
      )
      (i64.const 10)
     )
     (then
      (i64.const 2)
     )
     (else
      (if (result i64)
       (i64.lt_s
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 10)
         )
        )
        (i64.const 10)
       )
       (then
        (i64.const 3)
       )
       (else
        (if (result i64)
         (i64.lt_s
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 10)
           )
          )
          (i64.const 10)
         )
         (then
          (i64.const 4)
         )
         (else
          (if (result i64)
           (i64.lt_s
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 10)
             )
            )
            (i64.const 10)
           )
           (then
            (i64.const 5)
           )
           (else
            (if (result i64)
             (i64.lt_s
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 10)
               )
              )
              (i64.const 10)
             )
             (then
              (i64.const 6)
             )
             (else
              (if (result i64)
               (i64.lt_s
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 10)
                 )
                )
                (i64.const 10)
               )
               (then
                (i64.const 7)
               )
               (else
                (if (result i64)
                 (i64.lt_s
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 10)
                   )
                  )
                  (i64.const 10)
                 )
                 (then
                  (i64.const 8)
                 )
                 (else
                  (if (result i64)
                   (i64.lt_s
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 10)
                     )
                    )
                    (i64.const 10)
                   )
                   (then
                    (i64.const 9)
                   )
                   (else
                    (if (result i64)
                     (i64.lt_s
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 10)
                       )
                      )
                      (i64.const 10)
                     )
                     (then
                      (i64.const 10)
                     )
                     (else
                      (if (result i64)
                       (i64.lt_s
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 10)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (i64.const 11)
                       )
                       (else
                        (if (result i64)
                         (i64.lt_s
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 10)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (i64.const 12)
                         )
                         (else
                          (if (result i64)
                           (i64.lt_s
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 10)
                             )
                            )
                            (i64.const 10)
                           )
                           (then
                            (i64.const 13)
                           )
                           (else
                            (if (result i64)
                             (i64.lt_s
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 10)
                               )
                              )
                              (i64.const 10)
                             )
                             (then
                              (i64.const 14)
                             )
                             (else
                              (if (result i64)
                               (i64.lt_s
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 10)
                                 )
                                )
                                (i64.const 10)
                               )
                               (then
                                (i64.const 15)
                               )
                               (else
                                (if (result i64)
                                 (i64.lt_s
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 10)
                                   )
                                  )
                                  (i64.const 10)
                                 )
                                 (then
                                  (i64.const 16)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.lt_s
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 10)
                                     )
                                    )
                                    (i64.const 10)
                                   )
                                   (then
                                    (i64.const 17)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.lt_s
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 10)
                                       )
                                      )
                                      (i64.const 10)
                                     )
                                     (then
                                      (i64.const 18)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.lt_s
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 10)
                                         )
                                        )
                                        (i64.const 10)
                                       )
                                       (then
                                        (i64.const 19)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.lt_s
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 10)
                                           )
                                          )
                                          (i64.const 10)
                                         )
                                         (then
                                          (i64.const 20)
                                         )
                                         (else
                                          (return_call $function111
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 10)
                                           )
                                           (i64.const 21)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function111 (type $52) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $2)
    (i64.const 10)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function111
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 10)
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function112 (type $call64) (param $0 (ref null $type63)) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.tee $0
       (struct.get $type63 1
        (local.get $0)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (ref.is_null
        (local.tee $0
         (struct.get $type63 1
          (local.get $0)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $0
           (struct.get $type63 1
            (local.get $0)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $0
             (struct.get $type63 1
              (local.get $0)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $0
               (struct.get $type63 1
                (local.get $0)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $0
                 (struct.get $type63 1
                  (local.get $0)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type63 1
                    (local.get $0)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type63 1
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (ref.is_null
                      (local.tee $0
                       (struct.get $type63 1
                        (local.get $0)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (ref.is_null
                        (local.tee $0
                         (struct.get $type63 1
                          (local.get $0)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (ref.is_null
                          (local.tee $0
                           (struct.get $type63 1
                            (local.get $0)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (ref.is_null
                            (local.tee $0
                             (struct.get $type63 1
                              (local.get $0)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (ref.is_null
                              (local.tee $0
                               (struct.get $type63 1
                                (local.get $0)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (ref.is_null
                                (local.tee $0
                                 (struct.get $type63 1
                                  (local.get $0)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (if (result i64)
                                 (ref.is_null
                                  (local.tee $0
                                   (struct.get $type63 1
                                    (local.get $0)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 15)
                                 )
                                 (else
                                  (if (result i64)
                                   (ref.is_null
                                    (local.tee $0
                                     (struct.get $type63 1
                                      (local.get $0)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 16)
                                   )
                                   (else
                                    (if (result i64)
                                     (ref.is_null
                                      (local.tee $0
                                       (struct.get $type63 1
                                        (local.get $0)
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 17)
                                     )
                                     (else
                                      (if (result i64)
                                       (ref.is_null
                                        (local.tee $0
                                         (struct.get $type63 1
                                          (local.get $0)
                                         )
                                        )
                                       )
                                       (then
                                        (i64.const 18)
                                       )
                                       (else
                                        (if (result i64)
                                         (ref.is_null
                                          (local.tee $0
                                           (struct.get $type63 1
                                            (local.get $0)
                                           )
                                          )
                                         )
                                         (then
                                          (i64.const 19)
                                         )
                                         (else
                                          (return_call $function113
                                           (i32.const 0)
                                           (i32.const 1)
                                           (struct.get $type63 1
                                            (local.get $0)
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function113 (type $20) (param $0 i32) (param $1 i32) (param $2 (ref null $type63)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type63 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function113
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function115 (type $19) (param $0 (ref $type16)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (param $5 i64) (result i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (if (result i32)
   (i64.eqz
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $6
       (i64.add
        (i64.rem_s
         (local.get $5)
         (i64.const 10)
        )
        (i64.const 48)
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $6)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $6)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type16 0
       (local.get $0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.tee $7
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
      )
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (if (result (ref $type17))
      (i32.lt_u
       (local.tee $8
        (i32.wrap_i64
         (local.get $7)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type16 2
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type18
         (struct.get $type16 3
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $8)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $8)
      (i32.const 8191)
     )
     (i32.wrap_i64
      (local.get $6)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function115
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (i64.sub
      (local.get $4)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $5)
      (i64.const 10)
     )
    )
   )
  )
 )
 (func $function116 (type $call66) (param $0 (ref $type16)) (param $1 i64) (param $2 (ref null $type63)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global397)
     )
    )
    (drop
     (call $function115
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (i64.add
       (local.get $1)
       (i64.const 9)
      )
      (i64.const 9)
      (struct.get $type63 0
       (local.get $2)
      )
     )
    )
    (local.set $2
     (struct.get $type63 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready406)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global406)
     )
    )
    (return_call $function116
     (local.get $0)
     (i64.add
      (local.get $1)
      (i64.const 9)
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function117 (type $call67) (param $0 (ref $type29)) (result (ref $type16))
  (local $1 (ref null $type63))
  (local $2 (ref $type16))
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type16))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type29 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global63)
     )
    )
    (if
     (i32.eqz
      (global.get $ready65)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global65)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global68)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (return_call $function30
     (call $string-new
      (i32.const 1)
     )
     (i32.const 0)
     (i32.const 1)
     (struct.new_default $type12)
     (i64.const 0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global377)
     )
    )
    (local.set $1
     (call $function107
      (struct.get $type29 1
       (local.get $0)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global387)
     )
    )
    (local.set $3
     (i64.add
      (i64.add
       (local.tee $5
        (i64.extend_i32_u
         (i32.ne
          (local.tee $6
           (struct.get $type29 0
            (local.get $0)
           )
          )
          (i32.const 0)
         )
        )
       )
       (local.tee $4
        (call $function110
         (struct.get $type63 0
          (local.get $1)
         )
        )
       )
      )
      (block (result i64)
       (drop
        (ref.as_non_null
         (global.get $global392)
        )
       )
       (i64.mul
        (i64.sub
         (call $function112
          (local.get $1)
         )
         (i64.const 1)
        )
        (i64.const 9)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $string-new
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if
     (local.get $6)
     (then
      (if
       (i32.ne
        (struct.get $type16 0
         (local.get $2)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type16 1
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (struct.get $type16 2
        (local.get $2)
       )
       (i32.const 0)
       (i32.const 45)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global406)
     )
    )
    (drop
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global397)
        )
       )
       (drop
        (call $function115
         (local.get $2)
         (i32.const 0)
         (i32.const 1)
         (i64.add
          (local.get $4)
          (local.get $5)
         )
         (local.get $4)
         (struct.get $type63 0
          (local.get $1)
         )
        )
       )
       (local.set $1
        (struct.get $type63 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready406)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global406)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global397)
          )
         )
         (drop
          (call $function115
           (local.get $2)
           (i32.const 0)
           (i32.const 1)
           (i64.add
            (local.tee $3
             (i64.add
              (local.get $4)
              (local.get $5)
             )
            )
            (i64.const 9)
           )
           (i64.const 9)
           (struct.get $type63 0
            (local.get $1)
           )
          )
         )
         (local.set $1
          (struct.get $type63 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready406)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global406)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global397)
            )
           )
           (drop
            (call $function115
             (local.get $2)
             (i32.const 0)
             (i32.const 1)
             (i64.add
              (local.tee $3
               (i64.add
                (local.get $3)
                (i64.const 9)
               )
              )
              (i64.const 9)
             )
             (i64.const 9)
             (struct.get $type63 0
              (local.get $1)
             )
            )
           )
           (local.set $1
            (struct.get $type63 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready406)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global406)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global397)
              )
             )
             (drop
              (call $function115
               (local.get $2)
               (i32.const 0)
               (i32.const 1)
               (i64.add
                (local.tee $3
                 (i64.add
                  (local.get $3)
                  (i64.const 9)
                 )
                )
                (i64.const 9)
               )
               (i64.const 9)
               (struct.get $type63 0
                (local.get $1)
               )
              )
             )
             (local.set $1
              (struct.get $type63 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready406)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global406)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global397)
                )
               )
               (drop
                (call $function115
                 (local.get $2)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.add
                  (local.tee $3
                   (i64.add
                    (local.get $3)
                    (i64.const 9)
                   )
                  )
                  (i64.const 9)
                 )
                 (i64.const 9)
                 (struct.get $type63 0
                  (local.get $1)
                 )
                )
               )
               (local.set $1
                (struct.get $type63 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready406)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global406)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global397)
                  )
                 )
                 (drop
                  (call $function115
                   (local.get $2)
                   (i32.const 0)
                   (i32.const 1)
                   (i64.add
                    (local.tee $3
                     (i64.add
                      (local.get $3)
                      (i64.const 9)
                     )
                    )
                    (i64.const 9)
                   )
                   (i64.const 9)
                   (struct.get $type63 0
                    (local.get $1)
                   )
                  )
                 )
                 (local.set $1
                  (struct.get $type63 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready406)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global406)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global397)
                    )
                   )
                   (drop
                    (call $function115
                     (local.get $2)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.add
                      (local.tee $3
                       (i64.add
                        (local.get $3)
                        (i64.const 9)
                       )
                      )
                      (i64.const 9)
                     )
                     (i64.const 9)
                     (struct.get $type63 0
                      (local.get $1)
                     )
                    )
                   )
                   (local.set $1
                    (struct.get $type63 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready406)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global406)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global397)
                      )
                     )
                     (drop
                      (call $function115
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.add
                        (local.tee $3
                         (i64.add
                          (local.get $3)
                          (i64.const 9)
                         )
                        )
                        (i64.const 9)
                       )
                       (i64.const 9)
                       (struct.get $type63 0
                        (local.get $1)
                       )
                      )
                     )
                     (local.set $1
                      (struct.get $type63 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready406)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global406)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global397)
                        )
                       )
                       (drop
                        (call $function115
                         (local.get $2)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.add
                          (local.tee $3
                           (i64.add
                            (local.get $3)
                            (i64.const 9)
                           )
                          )
                          (i64.const 9)
                         )
                         (i64.const 9)
                         (struct.get $type63 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.set $1
                        (struct.get $type63 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready406)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global406)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $1)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global397)
                          )
                         )
                         (drop
                          (call $function115
                           (local.get $2)
                           (i32.const 0)
                           (i32.const 1)
                           (i64.add
                            (local.tee $3
                             (i64.add
                              (local.get $3)
                              (i64.const 9)
                             )
                            )
                            (i64.const 9)
                           )
                           (i64.const 9)
                           (struct.get $type63 0
                            (local.get $1)
                           )
                          )
                         )
                         (local.set $1
                          (struct.get $type63 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready406)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global406)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global397)
                            )
                           )
                           (drop
                            (call $function115
                             (local.get $2)
                             (i32.const 0)
                             (i32.const 1)
                             (i64.add
                              (local.tee $3
                               (i64.add
                                (local.get $3)
                                (i64.const 9)
                               )
                              )
                              (i64.const 9)
                             )
                             (i64.const 9)
                             (struct.get $type63 0
                              (local.get $1)
                             )
                            )
                           )
                           (local.set $1
                            (struct.get $type63 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready406)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global406)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (drop
                              (ref.as_non_null
                               (global.get $global397)
                              )
                             )
                             (drop
                              (call $function115
                               (local.get $2)
                               (i32.const 0)
                               (i32.const 1)
                               (i64.add
                                (local.tee $3
                                 (i64.add
                                  (local.get $3)
                                  (i64.const 9)
                                 )
                                )
                                (i64.const 9)
                               )
                               (i64.const 9)
                               (struct.get $type63 0
                                (local.get $1)
                               )
                              )
                             )
                             (local.set $1
                              (struct.get $type63 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready406)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global406)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $1)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (drop
                                (ref.as_non_null
                                 (global.get $global397)
                                )
                               )
                               (drop
                                (call $function115
                                 (local.get $2)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.add
                                  (local.tee $3
                                   (i64.add
                                    (local.get $3)
                                    (i64.const 9)
                                   )
                                  )
                                  (i64.const 9)
                                 )
                                 (i64.const 9)
                                 (struct.get $type63 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (local.set $1
                                (struct.get $type63 1
                                 (local.get $1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready406)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global406)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $1)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global397)
                                  )
                                 )
                                 (drop
                                  (call $function115
                                   (local.get $2)
                                   (i32.const 0)
                                   (i32.const 1)
                                   (i64.add
                                    (local.tee $3
                                     (i64.add
                                      (local.get $3)
                                      (i64.const 9)
                                     )
                                    )
                                    (i64.const 9)
                                   )
                                   (i64.const 9)
                                   (struct.get $type63 0
                                    (local.get $1)
                                   )
                                  )
                                 )
                                 (local.set $1
                                  (struct.get $type63 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready406)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global406)
                                  )
                                 )
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global397)
                                    )
                                   )
                                   (drop
                                    (call $function115
                                     (local.get $2)
                                     (i32.const 0)
                                     (i32.const 1)
                                     (i64.add
                                      (local.tee $3
                                       (i64.add
                                        (local.get $3)
                                        (i64.const 9)
                                       )
                                      )
                                      (i64.const 9)
                                     )
                                     (i64.const 9)
                                     (struct.get $type63 0
                                      (local.get $1)
                                     )
                                    )
                                   )
                                   (local.set $1
                                    (struct.get $type63 1
                                     (local.get $1)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready406)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global406)
                                    )
                                   )
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global397)
                                      )
                                     )
                                     (drop
                                      (call $function115
                                       (local.get $2)
                                       (i32.const 0)
                                       (i32.const 1)
                                       (i64.add
                                        (local.tee $3
                                         (i64.add
                                          (local.get $3)
                                          (i64.const 9)
                                         )
                                        )
                                        (i64.const 9)
                                       )
                                       (i64.const 9)
                                       (struct.get $type63 0
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (local.set $1
                                      (struct.get $type63 1
                                       (local.get $1)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready406)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global406)
                                      )
                                     )
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $1)
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global397)
                                        )
                                       )
                                       (drop
                                        (call $function115
                                         (local.get $2)
                                         (i32.const 0)
                                         (i32.const 1)
                                         (i64.add
                                          (local.tee $3
                                           (i64.add
                                            (local.get $3)
                                            (i64.const 9)
                                           )
                                          )
                                          (i64.const 9)
                                         )
                                         (i64.const 9)
                                         (struct.get $type63 0
                                          (local.get $1)
                                         )
                                        )
                                       )
                                       (local.set $1
                                        (struct.get $type63 1
                                         (local.get $1)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready406)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global406)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $1)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global397)
                                          )
                                         )
                                         (drop
                                          (call $function115
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.add
                                            (local.tee $3
                                             (i64.add
                                              (local.get $3)
                                              (i64.const 9)
                                             )
                                            )
                                            (i64.const 9)
                                           )
                                           (i64.const 9)
                                           (struct.get $type63 0
                                            (local.get $1)
                                           )
                                          )
                                         )
                                         (local.set $1
                                          (struct.get $type63 1
                                           (local.get $1)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready406)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global406)
                                          )
                                         )
                                         (if (result i32)
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                          (then
                                           (i32.const 0)
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global397)
                                            )
                                           )
                                           (drop
                                            (call $function115
                                             (local.get $2)
                                             (i32.const 0)
                                             (i32.const 1)
                                             (i64.add
                                              (local.tee $3
                                               (i64.add
                                                (local.get $3)
                                                (i64.const 9)
                                               )
                                              )
                                              (i64.const 9)
                                             )
                                             (i64.const 9)
                                             (struct.get $type63 0
                                              (local.get $1)
                                             )
                                            )
                                           )
                                           (local.set $1
                                            (struct.get $type63 1
                                             (local.get $1)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready406)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global406)
                                            )
                                           )
                                           (call $function116
                                            (local.get $2)
                                            (i64.add
                                             (local.get $3)
                                             (i64.const 9)
                                            )
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (local.get $2)
   )
  )
 )
 (func $function120 (type $15) (param $0 i32) (param $1 i32) (param $2 (ref $type29)) (param $3 (ref $type29)) (param $4 (ref $type29)) (result (ref $type29))
  (local $5 (ref $type14))
  (local $6 (ref $type14))
  (local $7 (ref $type29))
  (local $8 (ref $type29))
  (local $9 i64)
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type29 1
       (local.get $3)
      )
     )
    )
   )
   (then
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i32.wrap_i64
      (i64.and
       (i64.extend_i32_s
        (array.get $type14
         (struct.get $type29 1
          (local.get $3)
         )
         (i32.const 0)
        )
       )
       (i64.const 1)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global236)
       )
      )
      (local.set $4
       (call $function77
        (local.get $4)
        (local.get $2)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global417)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global248)
     )
    )
    (if
     (i64.gt_u
      (local.tee $9
       (i64.extend_i32_u
        (array.len
         (local.tee $5
          (struct.get $type29 1
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function81
      (local.tee $6
       (array.new_default $type14
        (i32.wrap_i64
         (local.get $9)
        )
       )
      )
      (local.get $5)
      (i64.const 2)
      (i32.const 0)
      (i32.const 1)
      (i64.extend_i32_u
       (array.len
        (local.get $5)
       )
      )
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (local.set $7
     (if (result (ref $type29))
      (i64.eqz
       (i64.extend_i32_u
        (array.len
         (local.tee $5
          (call $function46
           (local.get $6)
          )
         )
        )
       )
      )
      (then
       (ref.as_non_null
        (global.get $global108)
       )
      )
      (else
       (struct.new $type29
        (i32.const 0)
        (local.get $5)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type29 1
         (local.get $7)
        )
       )
      )
     )
     (then
      (local.get $4)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global236)
       )
      )
      (local.set $8
       (call $function77
        (local.get $2)
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function120
       (local.get $0)
       (local.get $1)
       (local.get $8)
       (local.get $7)
       (local.get $4)
      )
     )
    )
   )
  )
 )
 (func $function122 (type $call37) (param $0 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eqz
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 2)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eqz
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 2)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eqz
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 2)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i64.eqz
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 2)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i64.eqz
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 2)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i64.eqz
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 2)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i64.eqz
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 2)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (i64.eqz
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 2)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (i64.eqz
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 2)
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (i64.eqz
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 2)
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (i64.eqz
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 2)
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (i64.eqz
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 2)
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (i64.eqz
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 2)
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 2)
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (if (result i64)
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 2)
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 15)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 2)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 16)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 2)
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 17)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 2)
                                         )
                                        )
                                       )
                                       (then
                                        (i64.const 18)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 2)
                                           )
                                          )
                                         )
                                         (then
                                          (i64.const 19)
                                         )
                                         (else
                                          (return_call $function123
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 2)
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function123 (type $52) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function123
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 2)
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function129 (type $call72) (param $0 f64) (result i64)
  (if (result i64)
   (f64.eq
    (local.get $0)
    (f64.const 0.0)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (f64.eq
      (local.tee $0
       (f64.trunc
        (f64.mul
         (local.get $0)
         (f64.const 9.313225746154785e-10)
        )
       )
      )
      (f64.const 0.0)
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (f64.eq
        (local.tee $0
         (f64.trunc
          (f64.mul
           (local.get $0)
           (f64.const 9.313225746154785e-10)
          )
         )
        )
        (f64.const 0.0)
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (f64.eq
          (local.tee $0
           (f64.trunc
            (f64.mul
             (local.get $0)
             (f64.const 9.313225746154785e-10)
            )
           )
          )
          (f64.const 0.0)
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (f64.eq
            (local.tee $0
             (f64.trunc
              (f64.mul
               (local.get $0)
               (f64.const 9.313225746154785e-10)
              )
             )
            )
            (f64.const 0.0)
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (f64.eq
              (local.tee $0
               (f64.trunc
                (f64.mul
                 (local.get $0)
                 (f64.const 9.313225746154785e-10)
                )
               )
              )
              (f64.const 0.0)
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (f64.eq
                (local.tee $0
                 (f64.trunc
                  (f64.mul
                   (local.get $0)
                   (f64.const 9.313225746154785e-10)
                  )
                 )
                )
                (f64.const 0.0)
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (f64.eq
                  (local.tee $0
                   (f64.trunc
                    (f64.mul
                     (local.get $0)
                     (f64.const 9.313225746154785e-10)
                    )
                   )
                  )
                  (f64.const 0.0)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (f64.eq
                    (local.tee $0
                     (f64.trunc
                      (f64.mul
                       (local.get $0)
                       (f64.const 9.313225746154785e-10)
                      )
                     )
                    )
                    (f64.const 0.0)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (if (result i64)
                     (f64.eq
                      (local.tee $0
                       (f64.trunc
                        (f64.mul
                         (local.get $0)
                         (f64.const 9.313225746154785e-10)
                        )
                       )
                      )
                      (f64.const 0.0)
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (if (result i64)
                       (f64.eq
                        (local.tee $0
                         (f64.trunc
                          (f64.mul
                           (local.get $0)
                           (f64.const 9.313225746154785e-10)
                          )
                         )
                        )
                        (f64.const 0.0)
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (if (result i64)
                         (f64.eq
                          (local.tee $0
                           (f64.trunc
                            (f64.mul
                             (local.get $0)
                             (f64.const 9.313225746154785e-10)
                            )
                           )
                          )
                          (f64.const 0.0)
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (if (result i64)
                           (f64.eq
                            (local.tee $0
                             (f64.trunc
                              (f64.mul
                               (local.get $0)
                               (f64.const 9.313225746154785e-10)
                              )
                             )
                            )
                            (f64.const 0.0)
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (if (result i64)
                             (f64.eq
                              (local.tee $0
                               (f64.trunc
                                (f64.mul
                                 (local.get $0)
                                 (f64.const 9.313225746154785e-10)
                                )
                               )
                              )
                              (f64.const 0.0)
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (if (result i64)
                               (f64.eq
                                (local.tee $0
                                 (f64.trunc
                                  (f64.mul
                                   (local.get $0)
                                   (f64.const 9.313225746154785e-10)
                                  )
                                 )
                                )
                                (f64.const 0.0)
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (if (result i64)
                                 (f64.eq
                                  (local.tee $0
                                   (f64.trunc
                                    (f64.mul
                                     (local.get $0)
                                     (f64.const 9.313225746154785e-10)
                                    )
                                   )
                                  )
                                  (f64.const 0.0)
                                 )
                                 (then
                                  (i64.const 15)
                                 )
                                 (else
                                  (if (result i64)
                                   (f64.eq
                                    (local.tee $0
                                     (f64.trunc
                                      (f64.mul
                                       (local.get $0)
                                       (f64.const 9.313225746154785e-10)
                                      )
                                     )
                                    )
                                    (f64.const 0.0)
                                   )
                                   (then
                                    (i64.const 16)
                                   )
                                   (else
                                    (if (result i64)
                                     (f64.eq
                                      (local.tee $0
                                       (f64.trunc
                                        (f64.mul
                                         (local.get $0)
                                         (f64.const 9.313225746154785e-10)
                                        )
                                       )
                                      )
                                      (f64.const 0.0)
                                     )
                                     (then
                                      (i64.const 17)
                                     )
                                     (else
                                      (if (result i64)
                                       (f64.eq
                                        (local.tee $0
                                         (f64.trunc
                                          (f64.mul
                                           (local.get $0)
                                           (f64.const 9.313225746154785e-10)
                                          )
                                         )
                                        )
                                        (f64.const 0.0)
                                       )
                                       (then
                                        (i64.const 18)
                                       )
                                       (else
                                        (if (result i64)
                                         (f64.eq
                                          (local.tee $0
                                           (f64.trunc
                                            (f64.mul
                                             (local.get $0)
                                             (f64.const 9.313225746154785e-10)
                                            )
                                           )
                                          )
                                          (f64.const 0.0)
                                         )
                                         (then
                                          (i64.const 19)
                                         )
                                         (else
                                          (return_call $function130
                                           (i32.const 0)
                                           (i32.const 1)
                                           (f64.trunc
                                            (f64.mul
                                             (local.get $0)
                                             (f64.const 9.313225746154785e-10)
                                            )
                                           )
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function130 (type $13) (param $0 i32) (param $1 i32) (param $2 f64) (param $3 i64) (result i64)
  (if (result i64)
   (f64.eq
    (local.get $2)
    (f64.const 0.0)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function130
     (local.get $0)
     (local.get $1)
     (f64.trunc
      (f64.mul
       (local.get $2)
       (f64.const 9.313225746154785e-10)
      )
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function131 (type $call73) (param $0 f64) (result (ref $type29))
  (local $1 i64)
  (local $2 i32)
  (drop
   (ref.as_non_null
    (global.get $global454)
   )
  )
  (if
   (select
    (f64.eq
     (f64.trunc
      (local.get $0)
     )
     (local.get $0)
    )
    (i32.const 0)
    (if (result i32)
     (f64.eq
      (local.get $0)
      (local.get $0)
     )
     (then
      (i32.and
       (f64.lt
        (local.get $0)
        (f64.const inf)
       )
       (f64.gt
        (local.get $0)
        (f64.const -inf)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global456)
     )
    )
    (local.set $1
     (call $function129
      (local.tee $0
       (select
        (f64.sub
         (f64.const 0.0)
         (local.get $0)
        )
        (local.get $0)
        (local.tee $2
         (f64.lt
          (local.get $0)
          (f64.const 0.0)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function132
     (local.get $2)
     (array.new_default $type14
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (f64.const 1073741824.0)
     (i32.const 0)
     (i32.const 1)
     (local.get $0)
     (i64.const 0)
    )
   )
   (else
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function132 (type $11) (param $0 i32) (param $1 (ref $type14)) (param $2 f64) (param $3 i32) (param $4 i32) (param $5 f64) (param $6 i64) (result (ref $type29))
  (local $7 i64)
  (if (result (ref $type29))
   (f64.eq
    (local.get $5)
    (f64.const 0.0)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (local.tee $1
         (call $function46
          (local.get $1)
         )
        )
       )
      )
     )
     (then
      (ref.as_non_null
       (global.get $global108)
      )
     )
     (else
      (struct.new $type29
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global112)
     )
    )
    (local.set $7
     (i64.trunc_f64_s
      (f64.sub
       (local.get $5)
       (f64.mul
        (local.tee $5
         (f64.trunc
          (f64.div
           (local.get $5)
           (local.get $2)
          )
         )
        )
        (local.get $2)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $1)
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function132
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function136 (type $call74) (param $0 i64) (result f64)
  (local $1 f64)
  (local $2 f64)
  (local $3 i32)
  (local.set $2
   (select
    (f64.const 0.5)
    (f64.const 2.0)
    (local.tee $3
     (i64.lt_s
      (local.get $0)
      (i64.const 0)
     )
    )
   )
  )
  (if (result f64)
   (i64.eqz
    (local.tee $0
     (select
      (i64.sub
       (i64.const 0)
       (local.get $0)
      )
      (local.get $0)
      (local.get $3)
     )
    )
   )
   (then
    (f64.const 1.0)
   )
   (else
    (local.set $1
     (f64.mul
      (local.get $2)
      (f64.const 1.0)
     )
    )
    (if (result f64)
     (i64.eqz
      (local.tee $0
       (i64.sub
        (local.get $0)
        (i64.const 1)
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (local.set $1
       (f64.mul
        (local.get $1)
        (local.get $2)
       )
      )
      (if (result f64)
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (local.get $1)
       )
       (else
        (local.set $1
         (f64.mul
          (local.get $1)
          (local.get $2)
         )
        )
        (if (result f64)
         (i64.eqz
          (local.tee $0
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (local.set $1
           (f64.mul
            (local.get $1)
            (local.get $2)
           )
          )
          (if (result f64)
           (i64.eqz
            (local.tee $0
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $1)
           )
           (else
            (local.set $1
             (f64.mul
              (local.get $1)
              (local.get $2)
             )
            )
            (if (result f64)
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (local.set $1
               (f64.mul
                (local.get $1)
                (local.get $2)
               )
              )
              (if (result f64)
               (i64.eqz
                (local.tee $0
                 (i64.sub
                  (local.get $0)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $1)
               )
               (else
                (local.set $1
                 (f64.mul
                  (local.get $1)
                  (local.get $2)
                 )
                )
                (if (result f64)
                 (i64.eqz
                  (local.tee $0
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (local.set $1
                   (f64.mul
                    (local.get $1)
                    (local.get $2)
                   )
                  )
                  (if (result f64)
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (local.set $1
                     (f64.mul
                      (local.get $1)
                      (local.get $2)
                     )
                    )
                    (if (result f64)
                     (i64.eqz
                      (local.tee $0
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (local.set $1
                       (f64.mul
                        (local.get $1)
                        (local.get $2)
                       )
                      )
                      (if (result f64)
                       (i64.eqz
                        (local.tee $0
                         (i64.sub
                          (local.get $0)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (local.set $1
                         (f64.mul
                          (local.get $1)
                          (local.get $2)
                         )
                        )
                        (if (result f64)
                         (i64.eqz
                          (local.tee $0
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (local.set $1
                           (f64.mul
                            (local.get $1)
                            (local.get $2)
                           )
                          )
                          (if (result f64)
                           (i64.eqz
                            (local.tee $0
                             (i64.sub
                              (local.get $0)
                              (i64.const 1)
                             )
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (local.set $1
                             (f64.mul
                              (local.get $1)
                              (local.get $2)
                             )
                            )
                            (if (result f64)
                             (i64.eqz
                              (local.tee $0
                               (i64.sub
                                (local.get $0)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (local.set $1
                               (f64.mul
                                (local.get $1)
                                (local.get $2)
                               )
                              )
                              (if (result f64)
                               (i64.eqz
                                (local.tee $0
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (local.set $1
                                 (f64.mul
                                  (local.get $1)
                                  (local.get $2)
                                 )
                                )
                                (if (result f64)
                                 (i64.eqz
                                  (local.tee $0
                                   (i64.sub
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (local.set $1
                                   (f64.mul
                                    (local.get $1)
                                    (local.get $2)
                                   )
                                  )
                                  (if (result f64)
                                   (i64.eqz
                                    (local.tee $0
                                     (i64.sub
                                      (local.get $0)
                                      (i64.const 1)
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (local.set $1
                                     (f64.mul
                                      (local.get $1)
                                      (local.get $2)
                                     )
                                    )
                                    (if (result f64)
                                     (i64.eqz
                                      (local.tee $0
                                       (i64.sub
                                        (local.get $0)
                                        (i64.const 1)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (local.set $1
                                       (f64.mul
                                        (local.get $1)
                                        (local.get $2)
                                       )
                                      )
                                      (if (result f64)
                                       (i64.eqz
                                        (local.tee $0
                                         (i64.sub
                                          (local.get $0)
                                          (i64.const 1)
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (local.set $1
                                         (f64.mul
                                          (local.get $1)
                                          (local.get $2)
                                         )
                                        )
                                        (if (result f64)
                                         (i64.eqz
                                          (local.tee $0
                                           (i64.sub
                                            (local.get $0)
                                            (i64.const 1)
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (return_call $function137
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.sub
                                            (local.get $0)
                                            (i64.const 1)
                                           )
                                           (f64.mul
                                            (local.get $1)
                                            (local.get $2)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function137 (type $9) (param $0 f64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 f64) (result f64)
  (if (result f64)
   (i64.eqz
    (local.get $3)
   )
   (then
    (local.get $4)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function137
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.sub
      (local.get $3)
      (i64.const 1)
     )
     (f64.mul
      (local.get $4)
      (local.get $0)
     )
    )
   )
  )
 )
 (func $function142 (type $call77) (param $0 (ref $type29)) (param $1 (ref $type29)) (result f64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 f64)
  (local $7 (ref $type29))
  (local $8 (ref $type29))
  (local $9 (ref $type29))
  (local $10 (ref $type29))
  (local $11 (ref $type29))
  (local $12 (ref $type29))
  (local $13 (ref $type29))
  (local $14 (ref $type14))
  (local $15 (ref $type53))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result f64)
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type29 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (if (result f64)
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type29 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (f64.const 0.0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global132)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global502)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global473)
       )
      )
      (select
       (f64.sub
        (f64.const -0.0)
        (local.tee $6
         (if (result f64)
          (i64.gt_s
           (local.tee $2
            (i64.sub
             (if (result i64)
              (i64.eqz
               (local.tee $2
                (i64.extend_i32_u
                 (array.len
                  (local.tee $14
                   (struct.get $type29 1
                    (local.tee $9
                     (if (result (ref $type29))
                      (struct.get $type29 0
                       (local.get $0)
                      )
                      (then
                       (struct.new $type29
                        (i32.const 0)
                        (struct.get $type29 1
                         (local.get $0)
                        )
                       )
                      )
                      (else
                       (local.get $0)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (then
               (i64.const 0)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global109)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global433)
                )
               )
               (if
                (i64.gt_u
                 (local.tee $2
                  (i64.sub
                   (local.get $2)
                   (i64.const 1)
                  )
                 )
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (i64.add
                (call $function122
                 (i64.extend_i32_s
                  (array.get $type14
                   (local.get $14)
                   (i32.wrap_i64
                    (local.get $2)
                   )
                  )
                 )
                )
                (i64.mul
                 (local.get $2)
                 (i64.const 30)
                )
               )
              )
             )
             (block (result i64)
              (drop
               (ref.as_non_null
                (global.get $global473)
               )
              )
              (if (result i64)
               (i64.eqz
                (local.tee $2
                 (i64.extend_i32_u
                  (array.len
                   (local.tee $14
                    (struct.get $type29 1
                     (local.tee $11
                      (if (result (ref $type29))
                       (struct.get $type29 0
                        (local.get $1)
                       )
                       (then
                        (struct.new $type29
                         (i32.const 0)
                         (struct.get $type29 1
                          (local.get $1)
                         )
                        )
                       )
                       (else
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
               (then
                (i64.const 0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global109)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global433)
                 )
                )
                (if
                 (i64.gt_u
                  (local.tee $2
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (i64.add
                 (call $function122
                  (i64.extend_i32_s
                   (array.get $type14
                    (local.get $14)
                    (i32.wrap_i64
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (i64.mul
                  (local.get $2)
                  (i64.const 30)
                 )
                )
               )
              )
             )
            )
           )
           (i64.const 1024)
          )
          (then
           (f64.const inf)
          )
          (else
           (if (result f64)
            (i64.lt_s
             (local.get $2)
             (i64.const -1075)
            )
            (then
             (f64.const 0.0)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global486)
              )
             )
             (local.set $7
              (local.get $9)
             )
             (local.set $10
              (local.get $11)
             )
             (if
              (i64.lt_s
               (local.get $2)
               (i64.const 0)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global477)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global141)
                )
               )
               (local.set $12
                (call $function53
                 (i64.const 2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global430)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global141)
                )
               )
               (local.set $8
                (call $function53
                 (i64.sub
                  (i64.const 0)
                  (local.get $2)
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global421)
                )
               )
               (local.set $8
                (if (result (ref $type29))
                 (struct.get $type29 0
                  (local.get $8)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global141)
                   )
                  )
                  (call $function120
                   (i32.const 0)
                   (i32.const 1)
                   (local.get $12)
                   (local.get $8)
                   (call $function53
                    (i64.const 1)
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global236)
                )
               )
               (local.set $7
                (call $function77
                 (local.get $7)
                 (local.get $8)
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global477)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global141)
                )
               )
               (local.set $12
                (call $function53
                 (i64.const 2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global430)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global141)
                )
               )
               (local.set $8
                (call $function53
                 (local.get $2)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global421)
                )
               )
               (local.set $8
                (if (result (ref $type29))
                 (struct.get $type29 0
                  (local.get $8)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global141)
                   )
                  )
                  (call $function120
                   (i32.const 0)
                   (i32.const 1)
                   (local.get $12)
                   (local.get $8)
                   (call $function53
                    (i64.const 1)
                   )
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global236)
                )
               )
               (local.set $10
                (call $function77
                 (local.get $10)
                 (local.get $8)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global174)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global167)
              )
             )
             (if (result f64)
              (i64.gt_s
               (local.tee $2
                (select
                 (i64.sub
                  (local.get $2)
                  (i64.const 1)
                 )
                 (local.get $2)
                 (i64.lt_s
                  (call $function59
                   (local.get $7)
                   (local.get $10)
                  )
                  (i64.const 0)
                 )
                )
               )
               (i64.const 1023)
              )
              (then
               (f64.const inf)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global497)
                )
               )
               (if
                (i64.lt_s
                 (local.tee $2
                  (select
                   (i64.const -1074)
                   (i64.sub
                    (local.get $2)
                    (i64.const 52)
                   )
                   (i64.lt_s
                    (local.get $2)
                    (i64.const -1022)
                   )
                  )
                 )
                 (i64.const 0)
                )
                (then
                 (drop
                  (ref.as_non_null
                   (global.get $global477)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global141)
                  )
                 )
                 (local.set $10
                  (call $function53
                   (i64.const 2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global430)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global141)
                  )
                 )
                 (local.set $7
                  (call $function53
                   (i64.sub
                    (i64.const 0)
                    (local.get $2)
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global421)
                  )
                 )
                 (local.set $7
                  (if (result (ref $type29))
                   (struct.get $type29 0
                    (local.get $7)
                   )
                   (then
                    (unreachable)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global141)
                     )
                    )
                    (call $function120
                     (i32.const 0)
                     (i32.const 1)
                     (local.get $10)
                     (local.get $7)
                     (call $function53
                      (i64.const 1)
                     )
                    )
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global236)
                  )
                 )
                 (local.set $9
                  (call $function77
                   (local.get $9)
                   (local.get $7)
                  )
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global477)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global141)
                  )
                 )
                 (local.set $10
                  (call $function53
                   (i64.const 2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global430)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global141)
                  )
                 )
                 (local.set $7
                  (call $function53
                   (local.get $2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global421)
                  )
                 )
                 (local.set $7
                  (if (result (ref $type29))
                   (struct.get $type29 0
                    (local.get $7)
                   )
                   (then
                    (unreachable)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global141)
                     )
                    )
                    (call $function120
                     (i32.const 0)
                     (i32.const 1)
                     (local.get $10)
                     (local.get $7)
                     (call $function53
                      (i64.const 1)
                     )
                    )
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global236)
                  )
                 )
                 (local.set $11
                  (call $function77
                   (local.get $11)
                   (local.get $7)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global490)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global316)
                )
               )
               (local.set $15
                (call $function93
                 (local.get $9)
                 (local.get $11)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global149)
                )
               )
               (local.set $3
                (call $function56
                 (local.tee $14
                  (struct.get $type29 1
                   (local.tee $9
                    (struct.get $type53 0
                     (local.get $15)
                    )
                   )
                  )
                 )
                 (local.tee $5
                  (struct.get $type29 0
                   (local.get $9)
                  )
                 )
                 (select
                  (i64.const -9223372036854775808)
                  (i64.const -9223372036854775807)
                  (local.get $5)
                 )
                 (i32.const 0)
                 (i32.const 1)
                 (i64.extend_i32_u
                  (array.len
                   (local.get $14)
                  )
                 )
                 (i64.const 0)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global211)
                )
               )
               (local.set $13
                (call $function71
                 (local.tee $9
                  (struct.get $type53 1
                   (local.get $15)
                  )
                 )
                 (local.get $9)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global167)
                )
               )
               (f64.mul
                (f64.convert_i64_s
                 (select
                  (i64.add
                   (local.get $3)
                   (i64.const 1)
                  )
                  (local.get $3)
                  (if (result i32)
                   (i64.gt_s
                    (local.tee $4
                     (call $function59
                      (local.get $13)
                      (local.get $11)
                     )
                    )
                    (i64.const 0)
                   )
                   (then
                    (i32.const 1)
                   )
                   (else
                    (if (result i32)
                     (i64.eqz
                      (local.get $4)
                     )
                     (then
                      (i64.eq
                       (i64.rem_s
                        (local.get $3)
                        (i64.const 2)
                       )
                       (i64.const 1)
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
                (block (result f64)
                 (drop
                  (ref.as_non_null
                   (global.get $global479)
                  )
                 )
                 (call $function136
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (local.get $6)
       (select
        (i32.eqz
         (local.tee $5
          (struct.get $type29 0
           (local.get $1)
          )
         )
        )
        (local.get $5)
        (struct.get $type29 0
         (local.get $0)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function145 (type $call45) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type29))
  (local $2 (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (struct.get $type29 0
    (local.get $0)
   )
   (then
    (local.set $0
     (struct.new $type29
      (i32.const 0)
      (struct.get $type29 1
       (local.get $0)
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (struct.get $type29 0
    (local.get $1)
   )
   (then
    (local.set $1
     (struct.new $type29
      (i32.const 0)
      (struct.get $type29 1
       (local.get $1)
      )
     )
    )
   )
  )
  (if (result (ref $type29))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type29 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (local.get $0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global325)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global316)
     )
    )
    (local.set $0
     (struct.get $type53 1
      (call $function93
       (local.get $0)
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (if (result (ref $type29))
     (i64.eqz
      (i64.extend_i32_u
       (array.len
        (struct.get $type29 1
         (local.get $0)
        )
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global325)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global316)
       )
      )
      (local.set $1
       (struct.get $type53 1
        (call $function93
         (local.get $1)
         (local.get $0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if (result (ref $type29))
       (i64.eqz
        (i64.extend_i32_u
         (array.len
          (struct.get $type29 1
           (local.get $1)
          )
         )
        )
       )
       (then
        (local.get $0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global325)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global316)
         )
        )
        (local.set $0
         (struct.get $type53 1
          (call $function93
           (local.get $0)
           (local.get $1)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global130)
         )
        )
        (if (result (ref $type29))
         (i64.eqz
          (i64.extend_i32_u
           (array.len
            (struct.get $type29 1
             (local.get $0)
            )
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global325)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global316)
           )
          )
          (local.set $1
           (struct.get $type53 1
            (call $function93
             (local.get $1)
             (local.get $0)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global130)
           )
          )
          (if (result (ref $type29))
           (i64.eqz
            (i64.extend_i32_u
             (array.len
              (struct.get $type29 1
               (local.get $1)
              )
             )
            )
           )
           (then
            (local.get $0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global325)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global316)
             )
            )
            (local.set $0
             (struct.get $type53 1
              (call $function93
               (local.get $0)
               (local.get $1)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global130)
             )
            )
            (if (result (ref $type29))
             (i64.eqz
              (i64.extend_i32_u
               (array.len
                (struct.get $type29 1
                 (local.get $0)
                )
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global325)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global316)
               )
              )
              (local.set $1
               (struct.get $type53 1
                (call $function93
                 (local.get $1)
                 (local.get $0)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global130)
               )
              )
              (if (result (ref $type29))
               (i64.eqz
                (i64.extend_i32_u
                 (array.len
                  (struct.get $type29 1
                   (local.get $1)
                  )
                 )
                )
               )
               (then
                (local.get $0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global325)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global316)
                 )
                )
                (local.set $0
                 (struct.get $type53 1
                  (call $function93
                   (local.get $0)
                   (local.get $1)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global130)
                 )
                )
                (if (result (ref $type29))
                 (i64.eqz
                  (i64.extend_i32_u
                   (array.len
                    (struct.get $type29 1
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global325)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global316)
                   )
                  )
                  (local.set $1
                   (struct.get $type53 1
                    (call $function93
                     (local.get $1)
                     (local.get $0)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global130)
                   )
                  )
                  (if (result (ref $type29))
                   (i64.eqz
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type29 1
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (then
                    (local.get $0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global325)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global316)
                     )
                    )
                    (local.set $0
                     (struct.get $type53 1
                      (call $function93
                       (local.get $0)
                       (local.get $1)
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global130)
                     )
                    )
                    (if (result (ref $type29))
                     (i64.eqz
                      (i64.extend_i32_u
                       (array.len
                        (struct.get $type29 1
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global325)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global316)
                       )
                      )
                      (local.set $1
                       (struct.get $type53 1
                        (call $function93
                         (local.get $1)
                         (local.get $0)
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global130)
                       )
                      )
                      (if (result (ref $type29))
                       (i64.eqz
                        (i64.extend_i32_u
                         (array.len
                          (struct.get $type29 1
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (then
                        (local.get $0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global325)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global316)
                         )
                        )
                        (local.set $0
                         (struct.get $type53 1
                          (call $function93
                           (local.get $0)
                           (local.get $1)
                          )
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global130)
                         )
                        )
                        (if (result (ref $type29))
                         (i64.eqz
                          (i64.extend_i32_u
                           (array.len
                            (struct.get $type29 1
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global325)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global316)
                           )
                          )
                          (local.set $1
                           (struct.get $type53 1
                            (call $function93
                             (local.get $1)
                             (local.get $0)
                            )
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global130)
                           )
                          )
                          (if (result (ref $type29))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (struct.get $type29 1
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (then
                            (local.get $0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global325)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global316)
                             )
                            )
                            (local.set $0
                             (struct.get $type53 1
                              (call $function93
                               (local.get $0)
                               (local.get $1)
                              )
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global130)
                             )
                            )
                            (if (result (ref $type29))
                             (i64.eqz
                              (i64.extend_i32_u
                               (array.len
                                (struct.get $type29 1
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global325)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global316)
                               )
                              )
                              (local.set $1
                               (struct.get $type53 1
                                (call $function93
                                 (local.get $1)
                                 (local.get $0)
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global130)
                               )
                              )
                              (if (result (ref $type29))
                               (i64.eqz
                                (i64.extend_i32_u
                                 (array.len
                                  (struct.get $type29 1
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (then
                                (local.get $0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global325)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global316)
                                 )
                                )
                                (local.set $0
                                 (struct.get $type53 1
                                  (call $function93
                                   (local.get $0)
                                   (local.get $1)
                                  )
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global130)
                                 )
                                )
                                (if (result (ref $type29))
                                 (i64.eqz
                                  (i64.extend_i32_u
                                   (array.len
                                    (struct.get $type29 1
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global325)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global316)
                                   )
                                  )
                                  (local.set $1
                                   (struct.get $type53 1
                                    (call $function93
                                     (local.get $1)
                                     (local.get $0)
                                    )
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global130)
                                   )
                                  )
                                  (if (result (ref $type29))
                                   (i64.eqz
                                    (i64.extend_i32_u
                                     (array.len
                                      (struct.get $type29 1
                                       (local.get $1)
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $0)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global325)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global316)
                                     )
                                    )
                                    (local.set $2
                                     (struct.get $type53 1
                                      (call $function93
                                       (local.get $0)
                                       (local.get $1)
                                      )
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global130)
                                     )
                                    )
                                    (if (result (ref $type29))
                                     (i64.eqz
                                      (i64.extend_i32_u
                                       (array.len
                                        (struct.get $type29 1
                                         (local.get $2)
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global325)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global316)
                                       )
                                      )
                                      (local.set $0
                                       (struct.get $type53 1
                                        (call $function93
                                         (local.get $1)
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global130)
                                       )
                                      )
                                      (if (result (ref $type29))
                                       (i64.eqz
                                        (i64.extend_i32_u
                                         (array.len
                                          (struct.get $type29 1
                                           (local.get $0)
                                          )
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $2)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global325)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global316)
                                         )
                                        )
                                        (local.set $1
                                         (struct.get $type53 1
                                          (call $function93
                                           (local.get $2)
                                           (local.get $0)
                                          )
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global130)
                                         )
                                        )
                                        (if (result (ref $type29))
                                         (call $function48
                                          (local.get $1)
                                         )
                                         (then
                                          (local.get $0)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global325)
                                           )
                                          )
                                          (return_call $function146
                                           (i32.const 0)
                                           (i32.const 1)
                                           (local.get $1)
                                           (call $function95
                                            (local.get $0)
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function146 (type $7) (param $0 i32) (param $1 i32) (param $2 (ref $type29)) (param $3 (ref $type29)) (result (ref $type29))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type29))
   (call $function48
    (local.get $3)
   )
   (then
    (local.get $2)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global325)
     )
    )
    (local.set $2
     (call $function95
      (local.get $2)
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function146
     (local.get $0)
     (local.get $1)
     (local.get $3)
     (local.get $2)
    )
   )
  )
 )
 (func $function147 (type $call45) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type29))
  (local $2 (ref $type53))
  (local $3 i32)
  (drop
   (ref.as_non_null
    (global.get $global316)
   )
  )
  (local.set $2
   (call $function93
    (local.get $0)
    (local.get $1)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type29))
   (if (result i32)
    (i64.eqz
     (i64.extend_i32_u
      (array.len
       (struct.get $type29 1
        (struct.get $type53 1
         (local.get $2)
        )
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (select
      (i32.eqz
       (local.tee $3
        (struct.get $type29 0
         (local.get $1)
        )
       )
      )
      (local.get $3)
      (struct.get $type29 0
       (local.get $0)
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global141)
     )
    )
    (local.set $0
     (call $function53
      (i64.const 1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global216)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global134)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global211)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global130)
     )
    )
    (return_call $function71
     (struct.get $type53 0
      (local.get $2)
     )
     (if (result (ref $type29))
      (i64.eqz
       (i64.extend_i32_u
        (array.len
         (struct.get $type29 1
          (local.get $0)
         )
        )
       )
      )
      (then
       (local.get $0)
      )
      (else
       (struct.new $type29
        (i32.eqz
         (struct.get $type29 0
          (local.get $0)
         )
        )
        (struct.get $type29 1
         (local.get $0)
        )
       )
      )
     )
    )
   )
   (else
    (struct.get $type53 0
     (local.get $2)
    )
   )
  )
 )
 (func $function153 (type $call79) (param $0 (ref $type29)) (param $1 (ref $type29)) (result (ref $type80))
  (local $2 (ref $type29))
  (local $3 (ref $type14))
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (if (result (ref $type80))
   (i64.eqz
    (i64.extend_i32_u
     (array.len
      (struct.get $type29 1
       (local.get $1)
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (struct.get $type29 0
      (local.get $1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global134)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global130)
       )
      )
      (if
       (i64.ne
        (i64.extend_i32_u
         (array.len
          (local.tee $3
           (struct.get $type29 1
            (local.get $0)
           )
          )
         )
        )
        (i64.const 0)
       )
       (then
        (local.set $0
         (struct.new $type29
          (i32.eqz
           (struct.get $type29 0
            (local.get $0)
           )
          )
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global132)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global515)
     )
    )
    (if
     (struct.get $type29 0
      (local.get $1)
     )
     (then
      (local.set $1
       (struct.new $type29
        (i32.const 0)
        (struct.get $type29 1
         (local.get $1)
        )
       )
      )
     )
    )
    (local.set $2
     (call $function145
      (local.get $0)
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global322)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global316)
     )
    )
    (struct.new $type80
     (struct.get $type53 0
      (call $function93
       (local.get $0)
       (local.get $2)
      )
     )
     (block (result (ref $type29))
      (drop
       (ref.as_non_null
        (global.get $global322)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global316)
       )
      )
      (struct.get $type53 0
       (call $function93
        (local.get $1)
        (local.get $2)
       )
      )
     )
    )
   )
  )
 )
 (func $function173 (type $4) (param $0 i32) (param $1 i32) (param $2 f64) (param $3 i64) (result (ref $type80))
  (local $4 (ref $type29))
  (local $5 (ref $type29))
  (local $scratch (ref $type29))
  (if
   (f64.eq
    (f64.trunc
     (local.get $2)
    )
    (local.get $2)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global461)
     )
    )
    (return_call $function153
     (call $function131
      (local.get $2)
     )
     (block (result (ref $type29))
      (drop
       (ref.as_non_null
        (global.get $global141)
       )
      )
      (local.set $5
       (call $function53
        (i64.const 2)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global430)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global141)
       )
      )
      (local.set $4
       (call $function53
        (local.get $3)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global421)
       )
      )
      (local.set $scratch
       (if (result (ref $type29))
        (struct.get $type29 0
         (local.get $4)
        )
        (then
         (unreachable)
        )
        (else
         (drop
          (ref.as_non_null
           (global.get $global141)
          )
         )
         (call $function120
          (i32.const 0)
          (i32.const 1)
          (local.get $5)
          (local.get $4)
          (call $function53
           (i64.const 1)
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global540)
       )
      )
      (local.get $scratch)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function173
     (local.get $0)
     (local.get $1)
     (f64.mul
      (local.get $2)
      (f64.const 1073741824.0)
     )
     (i64.add
      (local.get $3)
      (i64.const 30)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function178 (type $3) (param $0 i32) (param $1 i64) (param $2 (ref $type16)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type16))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type16))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign1
      (local.get $0)
      (local.get $5)
     )
    )
    (if
     (i32.ne
      (struct.get $type16 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (if (result (ref $type17))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type16 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type18
         (struct.get $type16 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function178
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function179 (type $call92) (param $0 (ref $type16)) (result i32)
  (if (result i32)
   (i64.eqz
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $0)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign2
     (array.get $type17
      (struct.get $type16 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type16 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign2
       (array.get $type17
        (struct.get $type16 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type16 1
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type16 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign2
         (array.get $type17
          (struct.get $type16 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type16 1
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type16 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign2
           (array.get $type17
            (struct.get $type16 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (struct.get $type16 1
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type16 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign2
             (array.get $type17
              (struct.get $type16 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (struct.get $type16 1
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type16 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign2
               (array.get $type17
                (struct.get $type16 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (i64.extend_i32_u
                 (struct.get $type16 1
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type16 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign2
                 (array.get $type17
                  (struct.get $type16 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (i64.extend_i32_u
                   (struct.get $type16 1
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type16 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign2
                   (array.get $type17
                    (struct.get $type16 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (i64.extend_i32_u
                     (struct.get $type16 1
                      (local.get $0)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type16 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign2
                     (array.get $type17
                      (struct.get $type16 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (struct.get $type16 1
                        (local.get $0)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type16 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign2
                       (array.get $type17
                        (struct.get $type16 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (struct.get $type16 1
                          (local.get $0)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type16 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign2
                         (array.get $type17
                          (struct.get $type16 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (struct.get $type16 1
                            (local.get $0)
                           )
                          )
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type16 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign2
                           (array.get $type17
                            (struct.get $type16 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (struct.get $type16 1
                              (local.get $0)
                             )
                            )
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type16 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign2
                             (array.get $type17
                              (struct.get $type16 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (struct.get $type16 1
                                (local.get $0)
                               )
                              )
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type16 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign2
                               (array.get $type17
                                (struct.get $type16 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (struct.get $type16 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type16 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign2
                                 (array.get $type17
                                  (struct.get $type16 2
                                   (local.get $0)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (struct.get $type16 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 15)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type16 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $foreign2
                                   (array.get $type17
                                    (struct.get $type16 2
                                     (local.get $0)
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (struct.get $type16 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 16)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type16 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (call $foreign2
                                     (array.get $type17
                                      (struct.get $type16 2
                                       (local.get $0)
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (i64.extend_i32_u
                                       (struct.get $type16 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 17)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type16 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call $foreign2
                                       (array.get $type17
                                        (struct.get $type16 2
                                         (local.get $0)
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (i64.extend_i32_u
                                         (struct.get $type16 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 18)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type16 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (call $foreign2
                                         (array.get $type17
                                          (struct.get $type16 2
                                           (local.get $0)
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (i64.extend_i32_u
                                           (struct.get $type16 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 19)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type16 1
                                              (local.get $0)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $foreign2
                                           (array.get $type17
                                            (call $string-block
                                             (local.get $0)
                                             (i32.const 19)
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (return_call $function180
                                           (local.get $0)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function180 (type $1) (param $0 (ref $type16)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign2
     (array.get $type17
      (call $string-block
       (local.get $0)
       (local.tee $4
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (i32.and
       (local.get $4)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function180
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function182 (type $0) (param $0 (ref $type16)) (param $1 i32) (param $2 i32) (param $3 i64) (result (ref $type80))
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (local $7 (ref null $type16))
  (local $8 (ref $type29))
  (local $scratch (ref $type29))
  (if (result (ref $type80))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type16 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global353)
     )
    )
    (struct.new $type80
     (call $function102
      (local.get $0)
     )
     (block (result (ref $type29))
      (drop
       (ref.as_non_null
        (global.get $global547)
       )
      )
      (ref.as_non_null
       (global.get $global539)
      )
     )
    )
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type16 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eq
      (array.get $type17
       (if (result (ref $type17))
        (i32.lt_u
         (local.tee $6
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type16 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type18
           (struct.get $type16 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $6)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $6)
        (i32.const 8191)
       )
      )
      (i32.const 47)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global81)
       )
      )
      (if
       (i32.or
        (i64.lt_s
         (local.get $3)
         (i64.const 0)
        )
        (i64.lt_s
         (i64.extend_i32_u
          (struct.get $type16 1
           (local.get $0)
          )
         )
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (if
         (i64.gt_u
          (local.get $3)
          (i64.const 4294967294)
         )
         (then
          (unreachable)
         )
        )
        (call $string-copy
         (ref.as_non_null
          (local.tee $7
           (call $string-new
            (i32.wrap_i64
             (local.get $3)
            )
           )
          )
         )
         (i64.const 0)
         (local.get $0)
         (i64.const 0)
         (local.get $3)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global353)
       )
      )
      (return_call $function153
       (call $function102
        (ref.as_non_null
         (local.get $7)
        )
       )
       (block (result (ref $type29))
        (drop
         (ref.as_non_null
          (global.get $global81)
         )
        )
        (local.set $4
         (i64.extend_i32_u
          (struct.get $type16 1
           (local.get $0)
          )
         )
        )
        (if
         (if (result i32)
          (i64.lt_s
           (local.tee $3
            (i64.add
             (local.get $3)
             (i64.const 1)
            )
           )
           (i64.const 0)
          )
          (then
           (i32.const 1)
          )
          (else
           (i32.or
            (i64.lt_s
             (i64.extend_i32_u
              (struct.get $type16 1
               (local.get $0)
              )
             )
             (local.get $4)
            )
            (i64.gt_s
             (local.get $3)
             (local.get $4)
            )
           )
          )
         )
         (then
          (unreachable)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global61)
           )
          )
          (if
           (i64.gt_u
            (local.tee $5
             (i64.sub
              (local.get $4)
              (local.get $3)
             )
            )
            (i64.const 4294967294)
           )
           (then
            (unreachable)
           )
          )
          (call $string-copy
           (ref.as_non_null
            (local.tee $7
             (call $string-new
              (i32.wrap_i64
               (local.get $5)
              )
             )
            )
           )
           (i64.const 0)
           (local.get $0)
           (local.get $3)
           (local.get $4)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global353)
         )
        )
        (local.set $scratch
         (call $function102
          (ref.as_non_null
           (local.get $7)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global540)
         )
        )
        (local.get $scratch)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function182
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $export0 (param $0 i64) (param $1 f64) (result f64)
  (local $2 (ref $type80))
  (local $3 (ref $type80))
  (local $4 (ref $type80))
  (local $5 (ref $type29))
  (local $6 (ref $type29))
  (local $7 (ref $type29))
  (local $8 (ref $type29))
  (local $9 (ref $type16))
  (local $10 (ref $type16))
  (local $11 (ref null $type29))
  (local $12 (ref null $type29))
  (local $13 i64)
  (local $scratch (ref $type29))
  (local $scratch_15 (ref $type29))
  (local $scratch_16 (ref $type29))
  (local $scratch_17 (ref $type29))
  (local $scratch_18 (ref $type29))
  (local $scratch_19 (ref $type29))
  (local $scratch_20 (ref $type29))
  (local $scratch_21 i64)
  (local $scratch_22 (ref $type29))
  (local $scratch_23 (ref $type16))
  (local $scratch_24 (ref $type16))
  (local $scratch_25 (ref $type16))
  (local $scratch_26 (ref $type29))
  (local $scratch_27 (ref $type16))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready620)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global620)
   )
  )
  (block $block2 (result f64)
   (block $block1
    (br $block2
     (if (result f64)
      (i64.ge_s
       (local.get $0)
       (i64.const 8)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global623)
        )
       )
       (if (result f64)
        (i64.eq
         (local.get $0)
         (i64.const 15)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global593)
          )
         )
         (local.set $2
          (if (result (ref $type80))
           (if (result i32)
            (f64.eq
             (local.get $1)
             (local.get $1)
            )
            (then
             (i32.and
              (f64.lt
               (local.get $1)
               (f64.const inf)
              )
              (f64.gt
               (local.get $1)
               (f64.const -inf)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
           (then
            (call $function173
             (i32.const 0)
             (i32.const 1)
             (local.get $1)
             (i64.const 0)
            )
           )
           (else
            (unreachable)
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global598)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global507)
          )
         )
         (return_call $function142
          (struct.get $type80 0
           (local.get $2)
          )
          (struct.get $type80 1
           (local.get $2)
          )
         )
        )
        (else
         (drop
          (call $function179
           (block (result (ref $type16))
            (local.set $scratch_23
             (if (result (ref $type16))
              (i64.eq
               (local.get $0)
               (i64.const 14)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global593)
                )
               )
               (local.set $2
                (if (result (ref $type80))
                 (if (result i32)
                  (f64.eq
                   (local.get $1)
                   (local.get $1)
                  )
                  (then
                   (i32.and
                    (f64.lt
                     (local.get $1)
                     (f64.const inf)
                    )
                    (f64.gt
                     (local.get $1)
                     (f64.const -inf)
                    )
                   )
                  )
                  (else
                   (i32.const 0)
                  )
                 )
                 (then
                  (call $function173
                   (i32.const 0)
                   (i32.const 1)
                   (local.get $1)
                   (i64.const 0)
                  )
                 )
                 (else
                  (unreachable)
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global600)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global411)
                )
               )
               (local.set $9
                (call $function117
                 (struct.get $type80 0
                  (local.get $2)
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global549)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global171)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global167)
                )
               )
               (if (result (ref $type16))
                (i64.eqz
                 (call $function59
                  (struct.get $type80 1
                   (local.get $2)
                  )
                  (ref.as_non_null
                   (global.get $global539)
                  )
                 )
                )
                (then
                 (local.get $9)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global411)
                  )
                 )
                 (local.set $10
                  (call $function117
                   (struct.get $type80 1
                    (local.get $2)
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global88)
                  )
                 )
                 (call $function35
                  (struct.new $type25
                   (local.get $9)
                   (struct.new $type25
                    (global.get $string0)
                    (struct.new $type25
                     (local.get $10)
                     (ref.null none)
                    )
                   )
                  )
                 )
                )
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global606)
                )
               )
               (local.set $2
                (call $function182
                 (call $function178
                  (i32.const 0)
                  (local.tee $13
                   (call $foreign0
                    (i32.const 0)
                   )
                  )
                  (block (result (ref $type16))
                   (drop
                    (ref.as_non_null
                     (global.get $global61)
                    )
                   )
                   (if
                    (i64.gt_u
                     (local.get $13)
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (call $string-new
                    (i32.wrap_i64
                     (local.get $13)
                    )
                   )
                  )
                  (i32.const 0)
                  (i32.const 1)
                  (i64.const 0)
                 )
                 (block (result i32)
                  (drop
                   (ref.as_non_null
                    (global.get $global616)
                   )
                  )
                  (i32.const 0)
                 )
                 (i32.const 1)
                 (i64.const 0)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global606)
                )
               )
               (local.set $3
                (call $function182
                 (call $function178
                  (i32.const 1)
                  (local.tee $13
                   (call $foreign0
                    (i32.const 1)
                   )
                  )
                  (block (result (ref $type16))
                   (drop
                    (ref.as_non_null
                     (global.get $global61)
                    )
                   )
                   (if
                    (i64.gt_u
                     (local.get $13)
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (call $string-new
                    (i32.wrap_i64
                     (local.get $13)
                    )
                   )
                  )
                  (i32.const 0)
                  (i32.const 1)
                  (i64.const 0)
                 )
                 (block (result i32)
                  (drop
                   (ref.as_non_null
                    (global.get $global616)
                   )
                  )
                  (i32.const 0)
                 )
                 (i32.const 1)
                 (i64.const 0)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global626)
                )
               )
               (block $block (result (ref $type16))
                (local.set $4
                 (if (result (ref $type80))
                  (i64.eq
                   (local.get $0)
                   (i64.const 8)
                  )
                  (then
                   (drop
                    (ref.as_non_null
                     (global.get $global559)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global236)
                    )
                   )
                   (call $function153
                    (call $function71
                     (call $function77
                      (struct.get $type80 0
                       (local.get $2)
                      )
                      (local.tee $6
                       (struct.get $type80 1
                        (local.get $3)
                       )
                      )
                     )
                     (block (result (ref $type29))
                      (drop
                       (ref.as_non_null
                        (global.get $global236)
                       )
                      )
                      (local.set $scratch
                       (call $function77
                        (struct.get $type80 0
                         (local.get $3)
                        )
                        (local.tee $7
                         (struct.get $type80 1
                          (local.get $2)
                         )
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global211)
                       )
                      )
                      (local.get $scratch)
                     )
                    )
                    (block (result (ref $type29))
                     (drop
                      (ref.as_non_null
                       (global.get $global236)
                      )
                     )
                     (local.set $scratch_15
                      (call $function77
                       (local.get $7)
                       (local.get $6)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global540)
                      )
                     )
                     (local.get $scratch_15)
                    )
                   )
                  )
                  (else
                   (if (result (ref $type80))
                    (i64.eq
                     (local.get $0)
                     (i64.const 9)
                    )
                    (then
                     (drop
                      (ref.as_non_null
                       (global.get $global562)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global555)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global134)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global559)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global130)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global236)
                      )
                     )
                     (call $function153
                      (call $function71
                       (call $function77
                        (struct.get $type80 0
                         (local.get $2)
                        )
                        (local.tee $7
                         (struct.get $type80 1
                          (local.get $3)
                         )
                        )
                       )
                       (block (result (ref $type29))
                        (drop
                         (ref.as_non_null
                          (global.get $global236)
                         )
                        )
                        (local.set $scratch_16
                         (call $function77
                          (if (result (ref $type29))
                           (i64.eqz
                            (i64.extend_i32_u
                             (array.len
                              (struct.get $type29 1
                               (local.tee $6
                                (struct.get $type80 0
                                 (local.get $3)
                                )
                               )
                              )
                             )
                            )
                           )
                           (then
                            (local.get $6)
                           )
                           (else
                            (struct.new $type29
                             (i32.eqz
                              (struct.get $type29 0
                               (local.get $6)
                              )
                             )
                             (struct.get $type29 1
                              (local.get $6)
                             )
                            )
                           )
                          )
                          (local.tee $6
                           (struct.get $type80 1
                            (local.get $2)
                           )
                          )
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global211)
                         )
                        )
                        (local.get $scratch_16)
                       )
                      )
                      (block (result (ref $type29))
                       (drop
                        (ref.as_non_null
                         (global.get $global236)
                        )
                       )
                       (local.set $scratch_17
                        (call $function77
                         (local.get $6)
                         (local.get $7)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global540)
                        )
                       )
                       (local.get $scratch_17)
                      )
                     )
                    )
                    (else
                     (if (result (ref $type80))
                      (i64.eq
                       (local.get $0)
                       (i64.const 10)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global565)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global236)
                        )
                       )
                       (call $function153
                        (call $function77
                         (struct.get $type80 0
                          (local.get $2)
                         )
                         (struct.get $type80 0
                          (local.get $3)
                         )
                        )
                        (block (result (ref $type29))
                         (drop
                          (ref.as_non_null
                           (global.get $global236)
                          )
                         )
                         (local.set $scratch_18
                          (call $function77
                           (struct.get $type80 1
                            (local.get $2)
                           )
                           (struct.get $type80 1
                            (local.get $3)
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global540)
                          )
                         )
                         (local.get $scratch_18)
                        )
                       )
                      )
                      (else
                       (if (result (ref $type80))
                        (i64.eq
                         (local.get $0)
                         (i64.const 11)
                        )
                        (then
                         (drop
                          (ref.as_non_null
                           (global.get $global568)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global236)
                          )
                         )
                         (call $function153
                          (call $function77
                           (struct.get $type80 0
                            (local.get $2)
                           )
                           (struct.get $type80 1
                            (local.get $3)
                           )
                          )
                          (block (result (ref $type29))
                           (drop
                            (ref.as_non_null
                             (global.get $global236)
                            )
                           )
                           (local.set $scratch_19
                            (call $function77
                             (struct.get $type80 1
                              (local.get $2)
                             )
                             (struct.get $type80 0
                              (local.get $3)
                             )
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global540)
                            )
                           )
                           (local.get $scratch_19)
                          )
                         )
                        )
                        (else
                         (br $block
                          (call $function117
                           (block (result (ref $type29))
                            (local.set $scratch_22
                             (if (result (ref $type29))
                              (i64.eq
                               (local.get $0)
                               (i64.const 12)
                              )
                              (then
                               (drop
                                (ref.as_non_null
                                 (global.get $global575)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global236)
                                )
                               )
                               (call $function53
                                (block (result i64)
                                 (local.set $scratch_21
                                  (call $function59
                                   (call $function77
                                    (struct.get $type80 0
                                     (local.get $2)
                                    )
                                    (struct.get $type80 1
                                     (local.get $3)
                                    )
                                   )
                                   (block (result (ref $type29))
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global236)
                                     )
                                    )
                                    (local.set $scratch_20
                                     (call $function77
                                      (struct.get $type80 0
                                       (local.get $3)
                                      )
                                      (struct.get $type80 1
                                       (local.get $2)
                                      )
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global167)
                                     )
                                    )
                                    (local.get $scratch_20)
                                   )
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global141)
                                  )
                                 )
                                 (local.get $scratch_21)
                                )
                               )
                              )
                              (else
                               (if (result (ref $type29))
                                (i64.eq
                                 (local.get $0)
                                 (i64.const 13)
                                )
                                (then
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global571)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global322)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global316)
                                  )
                                 )
                                 (struct.get $type53 0
                                  (call $function93
                                   (struct.get $type80 0
                                    (local.get $2)
                                   )
                                   (struct.get $type80 1
                                    (local.get $2)
                                   )
                                  )
                                 )
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global573)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global521)
                                  )
                                 )
                                 (call $function147
                                  (struct.get $type80 0
                                   (local.get $2)
                                  )
                                  (struct.get $type80 1
                                   (local.get $2)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global411)
                             )
                            )
                            (local.get $scratch_22)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global600)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global411)
                 )
                )
                (local.set $9
                 (call $function117
                  (struct.get $type80 0
                   (local.get $4)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global549)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global171)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global167)
                 )
                )
                (if (result (ref $type16))
                 (i64.eqz
                  (call $function59
                   (struct.get $type80 1
                    (local.get $4)
                   )
                   (ref.as_non_null
                    (global.get $global539)
                   )
                  )
                 )
                 (then
                  (local.get $9)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global411)
                   )
                  )
                  (local.set $10
                   (call $function117
                    (struct.get $type80 1
                     (local.get $4)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global88)
                   )
                  )
                  (call $function35
                   (struct.new $type25
                    (local.get $9)
                    (struct.new $type25
                     (global.get $string0)
                     (struct.new $type25
                      (local.get $10)
                      (ref.null none)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global612)
             )
            )
            (local.get $scratch_23)
           )
          )
         )
         (f64.const 0.0)
        )
       )
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global606)
        )
       )
       (local.set $12
        (call $function102
         (block (result (ref $type16))
          (local.set $scratch_24
           (call $function178
            (i32.const 0)
            (local.tee $13
             (call $foreign0
              (i32.const 0)
             )
            )
            (block (result (ref $type16))
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (if
              (i64.gt_u
               (local.get $13)
               (i64.const 4294967294)
              )
              (then
               (unreachable)
              )
             )
             (call $string-new
              (i32.wrap_i64
               (local.get $13)
              )
             )
            )
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global353)
           )
          )
          (local.get $scratch_24)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global606)
        )
       )
       (local.set $11
        (call $function102
         (block (result (ref $type16))
          (local.set $scratch_25
           (call $function178
            (i32.const 1)
            (local.tee $13
             (call $foreign0
              (i32.const 1)
             )
            )
            (block (result (ref $type16))
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (if
              (i64.gt_u
               (local.get $13)
               (i64.const 4294967294)
              )
              (then
               (unreachable)
              )
             )
             (call $string-new
              (i32.wrap_i64
               (local.get $13)
              )
             )
            )
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global353)
           )
          )
          (local.get $scratch_25)
         )
        )
       )
       (br_if $block1
        (i64.eqz
         (local.get $0)
        )
       )
       (if (result f64)
        (i64.eq
         (local.get $0)
         (i64.const 5)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global511)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global141)
          )
         )
         (local.set $11
          (call $function53
           (i64.const 1)
          )
         )
         (br $block1)
        )
        (else
         (drop
          (call $function179
           (block (result (ref $type16))
            (local.set $scratch_27
             (if (result (ref $type16))
              (i64.eq
               (local.get $0)
               (i64.const 7)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global540)
                )
               )
               (local.set $4
                (call $function153
                 (ref.as_non_null
                  (local.get $12)
                 )
                 (ref.as_non_null
                  (local.get $11)
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global600)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global411)
                )
               )
               (local.set $9
                (call $function117
                 (struct.get $type80 0
                  (local.get $4)
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global549)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global171)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global167)
                )
               )
               (if (result (ref $type16))
                (i64.eqz
                 (call $function59
                  (struct.get $type80 1
                   (local.get $4)
                  )
                  (ref.as_non_null
                   (global.get $global539)
                  )
                 )
                )
                (then
                 (local.get $9)
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global411)
                  )
                 )
                 (local.set $10
                  (call $function117
                   (struct.get $type80 1
                    (local.get $4)
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global88)
                  )
                 )
                 (call $function35
                  (struct.new $type25
                   (local.get $9)
                   (struct.new $type25
                    (global.get $string0)
                    (struct.new $type25
                     (local.get $10)
                     (ref.null none)
                    )
                   )
                  )
                 )
                )
               )
              )
              (else
               (call $function117
                (block (result (ref $type29))
                 (local.set $scratch_26
                  (if (result (ref $type29))
                   (i64.eq
                    (local.get $0)
                    (i64.const 1)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global461)
                     )
                    )
                    (call $function131
                     (local.get $1)
                    )
                   )
                   (else
                    (if (result (ref $type29))
                     (i64.eq
                      (local.get $0)
                      (i64.const 2)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global471)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global461)
                       )
                      )
                      (call $function131
                       (f64.trunc
                        (local.get $1)
                       )
                      )
                     )
                     (else
                      (if (result (ref $type29))
                       (i64.eq
                        (local.get $0)
                        (i64.const 3)
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global521)
                         )
                        )
                        (call $function147
                         (ref.as_non_null
                          (local.get $12)
                         )
                         (ref.as_non_null
                          (local.get $11)
                         )
                        )
                       )
                       (else
                        (if (result (ref $type29))
                         (i64.eq
                          (local.get $0)
                          (i64.const 4)
                         )
                         (then
                          (drop
                           (ref.as_non_null
                            (global.get $global525)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global521)
                           )
                          )
                          (local.set $8
                           (call $function147
                            (local.tee $6
                             (ref.as_non_null
                              (local.get $12)
                             )
                            )
                            (local.tee $7
                             (ref.as_non_null
                              (local.get $11)
                             )
                            )
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global236)
                           )
                          )
                          (local.set $5
                           (call $function77
                            (local.get $7)
                            (local.get $8)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global216)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global134)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global211)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global130)
                           )
                          )
                          (call $function71
                           (local.get $6)
                           (if (result (ref $type29))
                            (i64.eqz
                             (i64.extend_i32_u
                              (array.len
                               (struct.get $type29 1
                                (local.get $5)
                               )
                              )
                             )
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (struct.new $type29
                              (i32.eqz
                               (struct.get $type29 0
                                (local.get $5)
                               )
                              )
                              (struct.get $type29 1
                               (local.get $5)
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global515)
                           )
                          )
                          (call $function145
                           (ref.as_non_null
                            (local.get $12)
                           )
                           (ref.as_non_null
                            (local.get $11)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global411)
                  )
                 )
                 (local.get $scratch_26)
                )
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global612)
             )
            )
            (local.get $scratch_27)
           )
          )
         )
         (f64.const 0.0)
        )
       )
      )
     )
    )
   )
   (drop
    (ref.as_non_null
     (global.get $global507)
    )
   )
   (return_call $function142
    (ref.as_non_null
     (local.get $12)
    )
    (ref.as_non_null
     (local.get $11)
    )
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global68
   (struct.new_default $type11)
  )
  (global.set $global383
   (struct.new_default $type13)
  )
  (global.set $global61
   (struct.new_default $type15)
  )
  (global.set $global63
   (struct.new_default $type19)
  )
  (global.set $global65
   (struct.new_default $type20)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type22)
  )
  (global.set $global88
   (struct.new_default $type24)
  )
  (global.set $global91
   (struct.new_default $type26)
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global96
   (struct.new_default $type27)
  )
  (global.set $ready96
   (i32.const 1)
  )
  (global.set $global108
   (struct.new $type29
    (i32.const 0)
    (array.new_fixed $type14 0)
   )
  )
  (global.set $global109
   (struct.new_default $type30)
  )
  (global.set $global112
   (struct.new_default $type31)
  )
  (global.set $global116
   (struct.new_default $type32)
  )
  (global.set $global118
   (struct.new_default $type33)
  )
  (global.set $global122
   (struct.new_default $type13)
  )
  (global.set $global126
   (struct.new_default $type34)
  )
  (global.set $global130
   (struct.new_default $type35)
  )
  (global.set $global132
   (struct.new_default $type36)
  )
  (global.set $global134
   (struct.new_default $type36)
  )
  (global.set $global136
   (struct.new_default $type37)
  )
  (global.set $global141
   (struct.new_default $type38)
  )
  (global.set $global149
   (struct.new_default $type39)
  )
  (global.set $global158
   (struct.new_default $type40)
  )
  (global.set $global167
   (struct.new_default $type41)
  )
  (global.set $global171
   (struct.new_default $type42)
  )
  (global.set $global174
   (struct.new_default $type42)
  )
  (global.set $global186
   (struct.new_default $type30)
  )
  (global.set $global189
   (struct.new_default $type43)
  )
  (global.set $global198
   (struct.new_default $type43)
  )
  (global.set $global207
   (struct.new_default $type44)
  )
  (global.set $global211
   (struct.new_default $type45)
  )
  (global.set $global216
   (struct.new_default $type45)
  )
  (global.set $global219
   (struct.new_default $type46)
  )
  (global.set $global230
   (struct.new_default $type43)
  )
  (global.set $global236
   (struct.new_default $type45)
  )
  (global.set $global239
   (struct.new_default $type47)
  )
  (global.set $global248
   (struct.new_default $type48)
  )
  (global.set $global256
   (struct.new_default $type48)
  )
  (global.set $global268
   (struct.new_default $type49)
  )
  (global.set $global280
   (struct.new_default $type50)
  )
  (global.set $global289
   (struct.new_default $type48)
  )
  (global.set $global294
   (struct.new_default $type51)
  )
  (global.set $global300
   (struct.new_default $type52)
  )
  (global.set $global309
   (struct.new_default $type54)
  )
  (global.set $global316
   (struct.new_default $type54)
  )
  (global.set $global322
   (struct.new_default $type45)
  )
  (global.set $global325
   (struct.new_default $type45)
  )
  (global.set $global328
   (struct.new_default $type55)
  )
  (global.set $global336
   (struct.new_default $type56)
  )
  (global.set $global342
   (struct.new_default $type57)
  )
  (global.set $global353
   (struct.new_default $type58)
  )
  (global.set $global377
   (struct.new_default $type62)
  )
  (global.set $global387
   (struct.new_default $type37)
  )
  (global.set $global392
   (struct.new_default $type64)
  )
  (global.set $global397
   (struct.new_default $type65)
  )
  (global.set $global406
   (struct.new_default $type66)
  )
  (global.set $ready406
   (i32.const 1)
  )
  (global.set $global411
   (struct.new_default $type67)
  )
  (global.set $global417
   (struct.new_default $type36)
  )
  (global.set $global421
   (struct.new_default $type45)
  )
  (global.set $global430
   (struct.new_default $type68)
  )
  (global.set $global433
   (struct.new_default $type37)
  )
  (global.set $global454
   (struct.new_default $type71)
  )
  (global.set $global456
   (struct.new_default $type72)
  )
  (global.set $global461
   (struct.new_default $type73)
  )
  (global.set $global471
   (struct.new_default $type73)
  )
  (global.set $global473
   (struct.new_default $type39)
  )
  (global.set $global477
   (struct.new_default $type38)
  )
  (global.set $global479
   (struct.new_default $type74)
  )
  (global.set $global486
   (struct.new_default $type75)
  )
  (global.set $global490
   (struct.new_default $type41)
  )
  (global.set $global497
   (struct.new_default $type76)
  )
  (global.set $global502
   (struct.new_default $type77)
  )
  (global.set $global507
   (struct.new_default $type77)
  )
  (global.set $global511
   (struct.new_default $type78)
  )
  (global.set $global515
   (struct.new_default $type45)
  )
  (global.set $global521
   (struct.new_default $type45)
  )
  (global.set $global525
   (struct.new_default $type45)
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (global.set $global539
   (call $function53
    (i64.const 1)
   )
  )
  (global.set $global540
   (struct.new_default $type79)
  )
  (global.set $global547
   (struct.new_default $type81)
  )
  (global.set $global549
   (struct.new_default $type82)
  )
  (global.set $global555
   (struct.new_default $type83)
  )
  (global.set $global559
   (struct.new_default $type84)
  )
  (global.set $global562
   (struct.new_default $type84)
  )
  (global.set $global565
   (struct.new_default $type84)
  )
  (global.set $global568
   (struct.new_default $type84)
  )
  (global.set $global571
   (struct.new_default $type85)
  )
  (global.set $global573
   (struct.new_default $type85)
  )
  (global.set $global575
   (struct.new_default $type86)
  )
  (global.set $global593
   (struct.new_default $type88)
  )
  (global.set $global598
   (struct.new_default $type89)
  )
  (global.set $global600
   (struct.new_default $type90)
  )
  (global.set $global606
   (struct.new_default $type91)
  )
  (global.set $global612
   (struct.new_default $type92)
  )
  (global.set $global616
   (struct.new_default $type93)
  )
  (global.set $global626
   (struct.new_default $type94)
  )
  (global.set $global623
   (struct.new_default $type0)
  )
  (global.set $global620
   (struct.new_default $type0)
  )
  (global.set $ready620
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

