(module
 (rec
  (type $0 (func (param (ref $type28) i32 i32 i64 i64) (result i64)))
  (type $1 (func (param (ref $type28) i32 i32 i64 i64 i64) (result i64)))
  (type $call42 (func (param i64) (result i64)))
  (type $3 (func (param (ref $type28) (ref $type14) i64 i32 i32 i64 i64) (result i32)))
  (type $4 (func (param (ref $type14) i64 i32 i32 i64 i64) (result i64)))
  (type $5 (func (param (ref $type14) (ref $type28) i64 i32 i32 i64 i64) (result i32)))
  (type $6 (func (param (ref $type28) i64 i64 i32 i32 i64 i64) (result i32)))
  (type $type29 (array (mut i8)))
  (type $type28 (struct (field (ref $type29))))
  (type $9 (func (param (ref $type28) i64 i32 i32 i64 i64) (result i64)))
  (type $type12 (struct (field i32)))
  (type $11 (func (param (ref $type14) i32 i32 (ref null $type12) i64) (result (ref $type14))))
  (type $type14 (struct (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $15 (func (param i32) (result (ref $type14))))
  (type $type55 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type33 (struct))
  (type $type27 (struct))
  (type $type18 (struct))
  (type $type17 (struct))
  (type $type13 (struct))
  (type $type11 (struct))
 )
 (type $34 (func (param i64) (result i64)))
 (type $35 (func (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type11)) (ref.null none))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $global63 (mut (ref null $type17)) (ref.null none))
 (global $global65 (mut (ref null $type18)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global106 (mut (ref null $type27)) (ref.null none))
 (global $global132 (mut (ref null $type33)) (ref.null none))
 (global $global176 (mut (ref null $type42)) (ref.null none))
 (global $global187 (mut (ref null $type42)) (ref.null none))
 (global $global185 (mut (ref null $type42)) (ref.null none))
 (global $global171 (mut (ref null $type43)) (ref.null none))
 (global $global154 (mut (ref null $type44)) (ref.null none))
 (global $global178 (mut (ref null $type45)) (ref.null none))
 (global $global163 (mut (ref null $type43)) (ref.null none))
 (global $global189 (mut (ref null $type46)) (ref.null none))
 (global $global158 (mut (ref null $type47)) (ref.null none))
 (global $global201 (mut (ref null $type49)) (ref.null none))
 (global $global223 (mut (ref null $type42)) (ref.null none))
 (global $global216 (mut (ref null $type50)) (ref.null none))
 (global $global203 (mut (ref null $type51)) (ref.null none))
 (global $global225 (mut (ref null $type52)) (ref.null none))
 (global $global211 (mut (ref null $type53)) (ref.null none))
 (global $global238 (mut (ref null $type55)) (ref.null none))
 (global $global240 (mut (ref null $type42)) (ref.null none))
 (global $ready240 (mut i32) (i32.const 0))
 (global $global247 (mut (ref null $type42)) (ref.null none))
 (global $ready247 (mut i32) (i32.const 0))
 (export "encode-scalar" (func $export0))
 (export "decode-scalar" (func $export1))
 (export "main" (func $main))
 (func $string-new (type $15) (param $0 i32) (result (ref $type14))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type16))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $5)
      (local.get $2)
      (array.new_default $type15
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type14
   (local.get $0)
   (array.new_default $type15
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $function30 (type $11) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 (ref null $type12)) (param $4 i64) (result (ref $type14))
  (local $5 i32)
  (local $6 i32)
  (if (result (ref $type14))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (local.set $6
     (struct.get $type12 0
      (local.get $3)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 1
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 2
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $5)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $5)
      (i32.const 8191)
     )
     (local.get $6)
    )
    (drop
     (ref.as_non_null
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function30
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (ref.null none)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function59 (type $9) (param $0 (ref $type28)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global171)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global176)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (local.tee $6
       (if (result i64)
        (i64.lt_u
         (local.tee $6
          (i64.extend_i32_u
           (array.get_u $type29
            (struct.get $type28 0
             (local.get $0)
            )
            (i32.wrap_i64
             (local.get $4)
            )
           )
          )
         )
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i32.and
           (i64.lt_u
            (local.get $6)
            (i64.const 224)
           )
           (i64.ge_u
            (local.get $6)
            (i64.const 194)
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (i32.and
             (i64.lt_u
              (local.get $6)
              (i64.const 240)
             )
             (i64.ge_u
              (local.get $6)
              (i64.const 224)
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (i32.and
               (i64.lt_u
                (local.get $6)
                (i64.const 245)
               )
               (i64.ge_u
                (local.get $6)
                (i64.const 240)
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (unreachable)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.sub
       (local.get $1)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global187)
     )
    )
    (drop
     (call $function63
      (local.get $0)
      (local.get $4)
      (local.get $6)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (i64.sub
       (i64.extend_i32_u
        (array.get_u $type29
         (struct.get $type28 0
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (if (result i64)
        (i64.eq
         (local.get $6)
         (i64.const 1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (i64.eq
           (local.get $6)
           (i64.const 2)
          )
          (then
           (i64.const 192)
          )
          (else
           (select
            (i64.const 224)
            (i64.const 240)
            (i64.eq
             (local.get $6)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (local.get $6)
     )
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function63 (type $6) (param $0 (ref $type28)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global185)
     )
    )
    (if (result i32)
     (i64.gt_s
      (if (result i64)
       (i64.eq
        (local.get $2)
        (i64.const 1)
       )
       (then
        (i64.const 0)
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $2)
          (i64.const 2)
         )
         (then
          (i64.const 128)
         )
         (else
          (select
           (i64.const 2048)
           (i64.const 65536)
           (i64.eq
            (local.get $2)
            (i64.const 3)
           )
          )
         )
        )
       )
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $6)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $6)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $6)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global154)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (i64.add
        (local.get $1)
        (local.get $5)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (if (result i64)
      (if (result i32)
       (i64.lt_u
        (local.tee $7
         (i64.extend_i32_u
          (array.get_u $type29
           (struct.get $type28 0
            (local.get $0)
           )
           (i32.wrap_i64
            (local.get $7)
           )
          )
         )
        )
        (i64.const 128)
       )
       (then
        (i32.const 1)
       )
       (else
        (i64.gt_u
         (local.get $7)
         (i64.const 191)
        )
       )
      )
      (then
       (unreachable)
      )
      (else
       (i64.sub
        (local.get $7)
        (i64.const 128)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function63
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
     (i64.add
      (local.get $7)
      (i64.shl
       (local.get $6)
       (i64.const 6)
      )
     )
    )
   )
  )
 )
 (func $function67 (type $5) (param $0 (ref $type14)) (param $1 (ref $type28)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i32)
  (local $9 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global171)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global176)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (local.tee $7
       (if (result i64)
        (i64.lt_u
         (local.tee $7
          (i64.extend_i32_u
           (array.get_u $type29
            (struct.get $type28 0
             (local.get $1)
            )
            (i32.wrap_i64
             (local.get $5)
            )
           )
          )
         )
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i32.and
           (i64.lt_u
            (local.get $7)
            (i64.const 224)
           )
           (i64.ge_u
            (local.get $7)
            (i64.const 194)
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (i32.and
             (i64.lt_u
              (local.get $7)
              (i64.const 240)
             )
             (i64.ge_u
              (local.get $7)
              (i64.const 224)
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (i32.and
               (i64.lt_u
                (local.get $7)
                (i64.const 245)
               )
               (i64.ge_u
                (local.get $7)
                (i64.const 240)
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (unreachable)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.sub
       (local.get $2)
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global187)
     )
    )
    (local.set $9
     (call $function63
      (local.get $1)
      (local.get $5)
      (local.get $7)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (i64.sub
       (i64.extend_i32_u
        (array.get_u $type29
         (struct.get $type28 0
          (local.get $1)
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
       )
       (if (result i64)
        (i64.eq
         (local.get $7)
         (i64.const 1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (i64.eq
           (local.get $7)
           (i64.const 2)
          )
          (then
           (i64.const 192)
          )
          (else
           (select
            (i64.const 224)
            (i64.const 240)
            (i64.eq
             (local.get $7)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i64.ge_u
      (local.get $6)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $8
        (i32.wrap_i64
         (local.get $6)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 1
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 2
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $8)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $8)
      (i32.const 8191)
     )
     (local.get $9)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (local.get $7)
     )
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function71 (type $6) (param $0 (ref $type28)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (if (result i32)
   (i64.eq
    (local.get $5)
    (i64.const 1)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global187)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.add
        (if (result i64)
         (i64.eq
          (local.get $2)
          (i64.const 1)
         )
         (then
          (i64.const 0)
         )
         (else
          (if (result i64)
           (i64.eq
            (local.get $2)
            (i64.const 2)
           )
           (then
            (i64.const 192)
           )
           (else
            (select
             (i64.const 224)
             (i64.const 240)
             (i64.eq
              (local.get $2)
              (i64.const 3)
             )
            )
           )
          )
         )
        )
        (local.get $6)
       )
      )
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $7
       (i64.add
        (i64.sub
         (local.get $5)
         (i64.const 1)
        )
        (local.get $1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.add
        (i64.rem_s
         (local.get $6)
         (i64.const 64)
        )
        (i64.const 128)
       )
      )
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $6)
      (i64.const 64)
     )
    )
   )
  )
 )
 (func $function74 (type $4) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (local $7 i32)
  (if (result i64)
   (i64.gt_s
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (local.get $4)
     )
     (then
      (local.get $5)
     )
     (else
      (if
       (i64.ge_u
        (local.get $4)
        (i64.extend_i32_u
         (struct.get $type14 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global223)
       )
      )
      (local.set $6
       (if (result i64)
        (i64.lt_u
         (local.tee $6
          (i64.extend_i32_u
           (array.get $type15
            (if (result (ref $type15))
             (i32.lt_u
              (local.tee $7
               (i32.wrap_i64
                (local.get $4)
               )
              )
              (i32.const 8192)
             )
             (then
              (struct.get $type14 1
               (local.get $0)
              )
             )
             (else
              (ref.as_non_null
               (array.get $type16
                (struct.get $type14 2
                 (local.get $0)
                )
                (i32.sub
                 (i32.shr_u
                  (local.get $7)
                  (i32.const 13)
                 )
                 (i32.const 1)
                )
               )
              )
             )
            )
            (i32.and
             (local.get $7)
             (i32.const 8191)
            )
           )
          )
         )
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i64.lt_u
           (local.get $6)
           (i64.const 2048)
          )
          (then
           (i64.const 2)
          )
          (else
           (select
            (i64.const 3)
            (i64.const 4)
            (i64.lt_u
             (local.get $6)
             (i64.const 65536)
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function74
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
       (i64.add
        (local.get $5)
        (local.get $6)
       )
      )
     )
    )
   )
  )
 )
 (func $function77 (type $3) (param $0 (ref $type28)) (param $1 (ref $type14)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global223)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global203)
     )
    )
    (drop
     (call $function71
      (local.get $0)
      (local.get $6)
      (local.tee $8
       (if (result i64)
        (i64.lt_u
         (local.tee $7
          (i64.extend_i32_u
           (array.get $type15
            (if (result (ref $type15))
             (i32.lt_u
              (local.tee $9
               (i32.wrap_i64
                (local.get $5)
               )
              )
              (i32.const 8192)
             )
             (then
              (struct.get $type14 1
               (local.get $1)
              )
             )
             (else
              (ref.as_non_null
               (array.get $type16
                (struct.get $type14 2
                 (local.get $1)
                )
                (i32.sub
                 (i32.shr_u
                  (local.get $9)
                  (i32.const 13)
                 )
                 (i32.const 1)
                )
               )
              )
             )
            )
            (i32.and
             (local.get $9)
             (i32.const 8191)
            )
           )
          )
         )
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i64.lt_u
           (local.get $7)
           (i64.const 2048)
          )
          (then
           (i64.const 2)
          )
          (else
           (select
            (i64.const 3)
            (i64.const 4)
            (i64.lt_u
             (local.get $7)
             (i64.const 65536)
            )
           )
          )
         )
        )
       )
      )
      (i32.const 0)
      (i32.const 1)
      (local.get $8)
      (local.get $7)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function77
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
     (i64.add
      (local.get $6)
      (local.get $8)
     )
    )
   )
  )
 )
 (func $function80 (type $call42) (param $0 i64) (result i64)
  (local $1 (ref $type29))
  (local $2 (ref $type28))
  (local $3 (ref $type14))
  (local $4 i64)
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $0)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $0)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global63)
   )
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global68)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $3
   (call $function30
    (call $string-new
     (i32.const 1)
    )
    (i32.const 0)
    (i32.const 1)
    (struct.new $type12
     (i32.wrap_i64
      (local.get $0)
     )
    )
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global238)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global211)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (i64.lt_s
    (local.tee $4
     (i64.extend_i32_u
      (struct.get $type14 0
       (local.get $3)
      )
     )
    )
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global216)
   )
  )
  (local.set $0
   (call $function74
    (local.get $3)
    (local.get $4)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global225)
   )
  )
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function77
    (local.tee $2
     (struct.new $type28
      (array.new_default $type29
       (i32.wrap_i64
        (local.get $0)
       )
      )
     )
    )
    (local.get $3)
    (local.get $4)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (local.set $4
   (i64.shl
    (local.tee $0
     (i64.extend_i32_u
      (array.len
       (struct.get $type28 0
        (local.get $2)
       )
      )
     )
    )
    (i64.const 32)
   )
  )
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (local.get $4)
   )
   (else
    (local.set $0
     (i64.add
      (i64.extend_i32_u
       (array.get_u $type29
        (local.tee $1
         (struct.get $type28 0
          (local.get $2)
         )
        )
        (i32.const 0)
       )
      )
      (local.get $4)
     )
    )
    (if (result i64)
     (i64.eq
      (i64.extend_i32_u
       (array.len
        (local.get $1)
       )
      )
      (i64.const 1)
     )
     (then
      (local.get $0)
     )
     (else
      (local.set $0
       (i64.add
        (i64.shl
         (i64.extend_i32_u
          (array.get_u $type29
           (local.tee $1
            (struct.get $type28 0
             (local.get $2)
            )
           )
           (i32.const 1)
          )
         )
         (i64.const 8)
        )
        (local.get $0)
       )
      )
      (if (result i64)
       (i64.eq
        (i64.extend_i32_u
         (array.len
          (local.get $1)
         )
        )
        (i64.const 2)
       )
       (then
        (local.get $0)
       )
       (else
        (local.set $0
         (i64.add
          (i64.shl
           (i64.extend_i32_u
            (array.get_u $type29
             (local.tee $1
              (struct.get $type28 0
               (local.get $2)
              )
             )
             (i32.const 2)
            )
           )
           (i64.const 16)
          )
          (local.get $0)
         )
        )
        (if (result i64)
         (i64.eq
          (i64.extend_i32_u
           (array.len
            (local.get $1)
           )
          )
          (i64.const 3)
         )
         (then
          (local.get $0)
         )
         (else
          (local.set $0
           (i64.add
            (i64.shl
             (i64.extend_i32_u
              (array.get_u $type29
               (local.tee $1
                (struct.get $type28 0
                 (local.get $2)
                )
               )
               (i32.const 3)
              )
             )
             (i64.const 24)
            )
            (local.get $0)
           )
          )
          (if (result i64)
           (i64.eq
            (i64.extend_i32_u
             (array.len
              (local.get $1)
             )
            )
            (i64.const 4)
           )
           (then
            (local.get $0)
           )
           (else
            (local.set $0
             (i64.add
              (i64.shl
               (i64.extend_i32_u
                (array.get_u $type29
                 (local.tee $1
                  (struct.get $type28 0
                   (local.get $2)
                  )
                 )
                 (i32.const 4)
                )
               )
               (i64.const 32)
              )
              (local.get $0)
             )
            )
            (if (result i64)
             (i64.eq
              (i64.extend_i32_u
               (array.len
                (local.get $1)
               )
              )
              (i64.const 5)
             )
             (then
              (local.get $0)
             )
             (else
              (local.set $0
               (i64.add
                (i64.shl
                 (i64.extend_i32_u
                  (array.get_u $type29
                   (local.tee $1
                    (struct.get $type28 0
                     (local.get $2)
                    )
                   )
                   (i32.const 5)
                  )
                 )
                 (i64.const 40)
                )
                (local.get $0)
               )
              )
              (if (result i64)
               (i64.eq
                (i64.extend_i32_u
                 (array.len
                  (local.get $1)
                 )
                )
                (i64.const 6)
               )
               (then
                (local.get $0)
               )
               (else
                (local.set $0
                 (i64.add
                  (i64.shl
                   (i64.extend_i32_u
                    (array.get_u $type29
                     (local.tee $1
                      (struct.get $type28 0
                       (local.get $2)
                      )
                     )
                     (i32.const 6)
                    )
                   )
                   (i64.const 48)
                  )
                  (local.get $0)
                 )
                )
                (if (result i64)
                 (i64.eq
                  (i64.extend_i32_u
                   (array.len
                    (local.get $1)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (local.get $0)
                 )
                 (else
                  (local.set $0
                   (i64.add
                    (i64.shl
                     (i64.extend_i32_u
                      (array.get_u $type29
                       (local.tee $1
                        (struct.get $type28 0
                         (local.get $2)
                        )
                       )
                       (i32.const 7)
                      )
                     )
                     (i64.const 56)
                    )
                    (local.get $0)
                   )
                  )
                  (if (result i64)
                   (i64.eq
                    (i64.extend_i32_u
                     (array.len
                      (local.get $1)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (local.get $0)
                   )
                   (else
                    (drop
                     (array.get_u $type29
                      (local.tee $1
                       (struct.get $type28 0
                        (local.get $2)
                       )
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i64)
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $1)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (local.get $0)
                     )
                     (else
                      (drop
                       (array.get_u $type29
                        (local.tee $1
                         (struct.get $type28 0
                          (local.get $2)
                         )
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i64)
                       (i64.eq
                        (i64.extend_i32_u
                         (array.len
                          (local.get $1)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (local.get $0)
                       )
                       (else
                        (drop
                         (array.get_u $type29
                          (local.tee $1
                           (struct.get $type28 0
                            (local.get $2)
                           )
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i64)
                         (i64.eq
                          (i64.extend_i32_u
                           (array.len
                            (local.get $1)
                           )
                          )
                          (i64.const 11)
                         )
                         (then
                          (local.get $0)
                         )
                         (else
                          (drop
                           (array.get_u $type29
                            (local.tee $1
                             (struct.get $type28 0
                              (local.get $2)
                             )
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i64)
                           (i64.eq
                            (i64.extend_i32_u
                             (array.len
                              (local.get $1)
                             )
                            )
                            (i64.const 12)
                           )
                           (then
                            (local.get $0)
                           )
                           (else
                            (drop
                             (array.get_u $type29
                              (local.tee $1
                               (struct.get $type28 0
                                (local.get $2)
                               )
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i64)
                             (i64.eq
                              (i64.extend_i32_u
                               (array.len
                                (local.get $1)
                               )
                              )
                              (i64.const 13)
                             )
                             (then
                              (local.get $0)
                             )
                             (else
                              (drop
                               (array.get_u $type29
                                (local.tee $1
                                 (struct.get $type28 0
                                  (local.get $2)
                                 )
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i64)
                               (i64.eq
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $1)
                                 )
                                )
                                (i64.const 14)
                               )
                               (then
                                (local.get $0)
                               )
                               (else
                                (drop
                                 (array.get_u $type29
                                  (local.tee $1
                                   (struct.get $type28 0
                                    (local.get $2)
                                   )
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i64)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $1)
                                   )
                                  )
                                  (i64.const 15)
                                 )
                                 (then
                                  (local.get $0)
                                 )
                                 (else
                                  (drop
                                   (array.get_u $type29
                                    (local.tee $1
                                     (struct.get $type28 0
                                      (local.get $2)
                                     )
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i64)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $1)
                                     )
                                    )
                                    (i64.const 16)
                                   )
                                   (then
                                    (local.get $0)
                                   )
                                   (else
                                    (drop
                                     (array.get_u $type29
                                      (local.tee $1
                                       (struct.get $type28 0
                                        (local.get $2)
                                       )
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i64)
                                     (i64.eq
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.get $1)
                                       )
                                      )
                                      (i64.const 17)
                                     )
                                     (then
                                      (local.get $0)
                                     )
                                     (else
                                      (drop
                                       (array.get_u $type29
                                        (local.tee $1
                                         (struct.get $type28 0
                                          (local.get $2)
                                         )
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i64)
                                       (i64.eq
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.get $1)
                                         )
                                        )
                                        (i64.const 18)
                                       )
                                       (then
                                        (local.get $0)
                                       )
                                       (else
                                        (drop
                                         (array.get_u $type29
                                          (local.tee $1
                                           (struct.get $type28 0
                                            (local.get $2)
                                           )
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i64)
                                         (i64.eq
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.get $1)
                                           )
                                          )
                                          (i64.const 19)
                                         )
                                         (then
                                          (local.get $0)
                                         )
                                         (else
                                          (drop
                                           (array.get_u $type29
                                            (local.tee $1
                                             (struct.get $type28 0
                                              (local.get $2)
                                             )
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (if (result i64)
                                           (i64.eq
                                            (i64.extend_i32_u
                                             (array.len
                                              (local.get $1)
                                             )
                                            )
                                            (i64.const 20)
                                           )
                                           (then
                                            (local.get $0)
                                           )
                                           (else
                                            (drop
                                             (array.get_u $type29
                                              (local.tee $1
                                               (struct.get $type28 0
                                                (local.get $2)
                                               )
                                              )
                                              (i32.const 20)
                                             )
                                            )
                                            (if (result i64)
                                             (i64.eq
                                              (i64.extend_i32_u
                                               (array.len
                                                (local.get $1)
                                               )
                                              )
                                              (i64.const 21)
                                             )
                                             (then
                                              (local.get $0)
                                             )
                                             (else
                                              (drop
                                               (array.get_u $type29
                                                (local.tee $1
                                                 (struct.get $type28 0
                                                  (local.get $2)
                                                 )
                                                )
                                                (i32.const 21)
                                               )
                                              )
                                              (if (result i64)
                                               (i64.eq
                                                (i64.extend_i32_u
                                                 (array.len
                                                  (local.get $1)
                                                 )
                                                )
                                                (i64.const 22)
                                               )
                                               (then
                                                (local.get $0)
                                               )
                                               (else
                                                (drop
                                                 (array.get_u $type29
                                                  (local.tee $1
                                                   (struct.get $type28 0
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (i32.const 22)
                                                 )
                                                )
                                                (if (result i64)
                                                 (i64.eq
                                                  (i64.extend_i32_u
                                                   (array.len
                                                    (local.get $1)
                                                   )
                                                  )
                                                  (i64.const 23)
                                                 )
                                                 (then
                                                  (local.get $0)
                                                 )
                                                 (else
                                                  (drop
                                                   (array.get_u $type29
                                                    (local.tee $1
                                                     (struct.get $type28 0
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (i32.const 23)
                                                   )
                                                  )
                                                  (if (result i64)
                                                   (i64.eq
                                                    (i64.extend_i32_u
                                                     (array.len
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (i64.const 24)
                                                   )
                                                   (then
                                                    (local.get $0)
                                                   )
                                                   (else
                                                    (drop
                                                     (array.get_u $type29
                                                      (struct.get $type28 0
                                                       (local.get $2)
                                                      )
                                                      (i32.const 24)
                                                     )
                                                    )
                                                    (return_call $function81
                                                     (local.get $2)
                                                     (i32.const 0)
                                                     (i32.const 1)
                                                     (i64.const 25)
                                                     (i64.const 0)
                                                     (local.get $0)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function81 (type $1) (param $0 (ref $type28)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (if (result i64)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 0
       (local.get $0)
      )
     )
    )
    (local.get $3)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (i64.shl
      (local.get $4)
      (i64.const 8)
     )
     (i64.add
      (i64.mul
       (local.get $4)
       (local.get $6)
      )
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function83 (type $0) (param $0 (ref $type28)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 i64)
  (local $6 (ref $type14))
  (if (result i64)
   (i64.eq
    (local.tee $5
     (i64.extend_i32_u
      (array.len
       (struct.get $type28 0
        (local.get $0)
       )
      )
     )
    )
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global201)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global158)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global132)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global163)
     )
    )
    (local.set $3
     (call $function59
      (local.get $0)
      (local.get $5)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (call $string-new
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global189)
     )
    )
    (drop
     (call $function67
      (local.get $6)
      (local.get $0)
      (local.get $5)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.const 0)
     )
    )
    (if (result i64)
     (i64.eq
      (local.tee $3
       (i64.extend_i32_u
        (struct.get $type14 0
         (local.get $6)
        )
       )
      )
      (i64.const 1)
     )
     (then
      (if
       (i64.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (i64.extend_i32_u
       (array.get $type15
        (struct.get $type14 1
         (local.get $6)
        )
        (i32.const 0)
       )
      )
     )
     (else
      (unreachable)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.rem_s
        (local.get $4)
        (i64.const 256)
       )
      )
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function83
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $4)
      (i64.const 256)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready240)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global240)
   )
  )
  (return_call $function80
   (local.get $0)
  )
 )
 (func $export1 (param $0 i64) (result i64)
  (local $1 i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready247)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global247)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global106)
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (i64.div_s
      (local.get $0)
      (i64.const 4294967296)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function83
   (struct.new $type28
    (array.new_default $type29
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.rem_s
    (local.get $0)
    (i64.const 4294967296)
   )
  )
 )
 (func $main (result i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global68
   (struct.new_default $type11)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $global63
   (struct.new_default $type17)
  )
  (global.set $global65
   (struct.new_default $type18)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global106
   (struct.new_default $type27)
  )
  (global.set $global132
   (struct.new_default $type33)
  )
  (global.set $global176
   (struct.new_default $type42)
  )
  (global.set $global187
   (struct.new_default $type42)
  )
  (global.set $global185
   (struct.new_default $type42)
  )
  (global.set $global171
   (struct.new_default $type43)
  )
  (global.set $global154
   (struct.new_default $type44)
  )
  (global.set $global178
   (struct.new_default $type45)
  )
  (global.set $global163
   (struct.new_default $type43)
  )
  (global.set $global189
   (struct.new_default $type46)
  )
  (global.set $global158
   (struct.new_default $type47)
  )
  (global.set $global201
   (struct.new_default $type49)
  )
  (global.set $global223
   (struct.new_default $type42)
  )
  (global.set $global216
   (struct.new_default $type50)
  )
  (global.set $global203
   (struct.new_default $type51)
  )
  (global.set $global225
   (struct.new_default $type52)
  )
  (global.set $global211
   (struct.new_default $type53)
  )
  (global.set $global238
   (struct.new_default $type55)
  )
  (global.set $global240
   (struct.new_default $type42)
  )
  (global.set $ready240
   (i32.const 1)
  )
  (global.set $global247
   (struct.new_default $type42)
  )
  (global.set $ready247
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
  (i64.const 0)
 )
)

