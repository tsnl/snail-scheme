from pathlib import Path
from collections import Counter
import hashlib, io, json, tarfile

root = Path('/tmp/snail-checked-types-full57-20261018')
repo = Path('/tmp/snail-checked-types-20261018')
out = repo / 'benchmarks/lofi/evidence'
stem = '20261018-checked-types-full57'
validation = json.loads((root / 'validation.json').read_text())
manifest = json.loads((root / 'manifest.json').read_text())
rows = validation['cases']
routes = {
    'wasm_validation': 'Lofi Wasm',
    'chez_validation': 'Chez original',
    'chez_adapted_validation': 'Chez adapted',
    'rust_wasm_validation': 'Rust Wasm',
    'rust_native_validation': 'Rust native',
}
assert len(rows) == 57
assert all(r.get('scheduler_validation') for r in rows)
assert all(r[k] != 'pending' or (k == 'wasm_validation' and r['build'] == 'failed')
           for r in rows for k in routes)
assert manifest['source_status'] == ''
assert manifest['source_revision'] == 'a2818640e3d6b681bbe5e07e4ecf018c473dd401'

files = {p for p in root.glob('*.json')}
files.update(p for p in (root / 'commands').rglob('*') if p.is_file())
files.update(p for p in (root / 'frozen-driver').rglob('*') if p.is_file())
for case in rows:
    folder = root / 'validation' / case['name']
    files.update(folder.glob('*.json'))
    files.update(p for p in (folder / 'commands').rglob('*') if p.is_file())

entries = {str(p.relative_to(root)): p.read_bytes() for p in files}
for name in ['prepare', 'validate', 'verify']:
    path = Path(f'/tmp/snail-checked-types-full57-{name}.log')
    entries[f'campaign/{name}.log'] = path.read_bytes()
entries['campaign/chibi-wrapper.sh'] = Path('/tmp/snail-chibi-measure').read_bytes()
entries['campaign/pack-evidence.py'] = Path(__file__).read_bytes()
artifacts = {}
for row in rows:
    folder = root / 'validation' / row['name']
    for p in list(folder.glob('*.wasm')) + list(folder.glob('*.so')):
        data = p.read_bytes()
        artifacts[str(p.relative_to(root))] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
entries['campaign/artifacts.json'] = (json.dumps(artifacts, indent=2) + '\n').encode()
index = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
         for name, data in sorted(entries.items())}
entries['index.json'] = (json.dumps(index, indent=2) + '\n').encode()
archive = out / f'{stem}-records.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, data in sorted(entries.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(data), 0o644
        tar.addfile(info, io.BytesIO(data))

def outcome(row, key):
    if key == 'wasm_validation' and row['build'] == 'failed':
        return 'build-failed'
    return row[key]

counts = {key: dict(Counter(outcome(r, key) for r in rows)) for key in routes}
failed_commands = []
for name, data in sorted(entries.items()):
    if name.endswith('/record.json'):
        record = json.loads(data)
        if record.get('returncode') != 0 or record.get('timeout'):
            failed_commands.append({'record': name, 'status': record.get('status'),
                                    'returncode': record.get('returncode'),
                                    'timeout': record.get('timeout'),
                                    'wall_seconds': record.get('wall_seconds')})
report = {
    'kind': 'canonical-correctness-validation',
    'source_revision': manifest['source_revision'],
    'source_status': manifest['source_status'],
    'benchmark_revision': '85f6acdc4cc4e2b857f307ba56bd0ba931dcccd1',
    'campaign_path': str(root),
    'configuration': manifest['config'],
    'limits': {'memory_bytes': 4294967296, 'swap_bytes': 0, 'cpu_quota_percent': 200,
               'whole_campaign_seconds': 21600, 'binaryen_cores': 1,
               'chibi_heap_arguments': '-h16M/1G'},
    'measurement': 'not-measured',
    'limitations': [
        'Validation command durations are diagnostics, not clean runtime timing samples.',
        'The compiler and inputs are frozen; source presence and historical manifest statuses are not current validation.',
        'Absent adapted controls remain unavailable. Failed routes remain failed.',
        'Lofi has no native execution route at this revision; Rust native is an independent control.',
    ],
    'coverage': counts,
    'coverage_note': 'A failed Lofi build is counted as build-failed; the unchanged raw row may retain wasm_validation=pending because execution was not attempted.',
    'cases': rows,
    'failed_commands': failed_commands,
    'records': {'archive': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                'manifest_sha256': hashlib.sha256((root / 'manifest.json').read_bytes()).hexdigest(),
                'entries': len(index)},
}
(out / f'{stem}.json').write_text(json.dumps(report, indent=2) + '\n')

lines = [
    '# Lofi: 57-workload correctness check, 18 October 2026', '',
    'Compiler `a2818640e3d6b681bbe5e07e4ecf018c473dd401` was frozen with a clean',
    'source tree after the fixed-arity migration, Wasm-only backend reconciliation',
    'and checked type evidence changes. All 57 canonical workloads were attempted',
    'on Lofi/Wasm and the four control routes. Twelve workloads have no adapted',
    'Chez source; those controls remain unavailable.', '',
    f'The [exact results]({stem}.json) retain every status and artifact hash.',
    f'The [indexed raw archive]({stem}-records.tar.gz) contains the frozen manifest,',
    'command receipts, exact stdout/stderr, per-case results, build traces and',
    'compiled artifact identities. It excludes generated binaries and toolchain',
    'contents; the manifest records their source/tool identities.', '',
    '| Route | Passed | Failed | Unavailable |',
    '| --- | ---: | ---: | ---: |',
]
for key, label in routes.items():
    c = counts[key]
    lines.append(f"| {label} | {c.get('passed', 0)} | {sum(n for s,n in c.items() if s not in ('passed','unavailable'))} | {c.get('unavailable', 0)} |")
lines += ['', '## Retained failures', '']
for row in rows:
    failed = [label + ': ' + outcome(row, key) for key,label in routes.items() if outcome(row, key) not in ('passed', 'unavailable')]
    if failed:
        lines.append('- **' + row['name'] + '** — ' + '; '.join(failed) + '.')
lines += ['', '## Reproduction and scope', '',
    'The pinned R7RS benchmark inputs are revision',
    '`85f6acdc4cc4e2b857f307ba56bd0ba931dcccd1`. Preparation freezes the compiler,',
    'benchmark sources, providers, Rust toolchain and locked crate dependencies.',
    'Both Rust wrapper environment variables were unset. Chibi ran with',
    '`-h16M/1G`; Binaryen used one core. The campaign had a two-CPU quota, 4 GiB',
    'memory limit, no swap and a six-hour overall limit. Each compilation had a',
    '600-second limit and each execution a 1,200-second limit.', '',
    '```sh',
    'env -u RUSTC_WRAPPER -u RUSTC_WORKSPACE_WRAPPER CHIBI=/path/to/chibi-wrapper BINARYEN_CORES=1 \\',
    '  /path/to/chibi-wrapper -I bootstrap -I benchmarks benchmarks/lofi/runner.scm prepare \\',
    '  --output /tmp/lofi-full57-check --compile-timeout 600 --run-timeout 1200',
    'env -u RUSTC_WRAPPER -u RUSTC_WORKSPACE_WRAPPER CHIBI=/path/to/chibi-wrapper BINARYEN_CORES=1 \\',
    '  /path/to/chibi-wrapper -I bootstrap -I benchmarks benchmarks/lofi/runner.scm validate \\',
    '  --output /tmp/lofi-full57-check',
    '```', '',
    'The wrapper and supervisor output are included in the archive. Apply the',
    'stated resource limits externally when reproducing this bounded run.',
    'Passing requires the complete canonical predicate. Rust/native',
    'executes native machine code; there is no Lofi/native backend in this snapshot.', '',
    'This is correctness evidence. Retained command durations are diagnostic and',
    'provide no new runtime ranking or speedup. The earlier clean full57 timing',
    'campaign remains historical evidence for its own compiler and sources.',
    'The [fresh Siegework build measurements](../../../doc/compilation-performance.md#checked-expression-evidence-18-october-2026)',
    'measure compilation separately.', '',
    '## Complete matrix', '',
    '| Case | Lofi Wasm | Chez original | Chez adapted | Rust Wasm | Rust native |',
    '| --- | --- | --- | --- | --- | --- |',
]
for row in rows:
    lines.append('| ' + row['name'] + ' | ' + ' | '.join(outcome(row, key) for key in routes) + ' |')
(out / f'{stem}.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'coverage': counts, 'archive_bytes': archive.stat().st_size, 'record_entries':len(index)},indent=2))
