#!/bin/sh
exec /nix/store/rymbc3gyix886hxf3ns6cr7smmc9swy2-chibi-scheme-0.12/bin/chibi-scheme -h16M/1G "$@"
