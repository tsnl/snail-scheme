from pathlib import Path
import hashlib,io,json,tarfile
root=Path('/tmp/snail-compiler-roomy-20261018')
out=Path('/tmp/snail-checked-types-20261018/benchmarks/lofi/evidence')
stem='20261018-compiler-memory-check'
manifest=json.loads((root/'manifest.json').read_text())
validation=json.loads((root/'validation.json').read_text())
assert manifest['source_status']==''
assert len(validation['cases'])==1
assert validation['cases'][0].get('scheduler_validation')
files={p for p in root.glob('*.json')}
for folder in ['commands','frozen-driver','validation/compiler/commands']:
    files.update(p for p in (root/folder).rglob('*') if p.is_file())
files.update((root/'validation/compiler').glob('*.json'))
entries={str(p.relative_to(root)):p.read_bytes() for p in files}
for name in ['prepare','validate','verify']:
    entries[f'campaign/{name}.log']=Path(f'/tmp/snail-compiler-roomy-{name}.log').read_bytes()
entries['campaign/chibi-wrapper.sh']=Path('/tmp/snail-chibi-correctness').read_bytes()
entries['campaign/package.py']=Path(__file__).read_bytes()
artifacts={}
for p in list((root/'validation/compiler').glob('*.wasm'))+list((root/'validation/compiler').glob('*.so')):
    data=p.read_bytes();artifacts[str(p.relative_to(root))]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
entries['campaign/artifacts.json']=(json.dumps(artifacts,indent=2)+'\n').encode()
entries['index.json']=(json.dumps({name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())},indent=2)+'\n').encode()
archive=out/f'{stem}-records.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for name,data in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'kind':'canonical-correctness-memory-check','source_revision':manifest['source_revision'],
        'source_status':manifest['source_status'],'configuration':manifest['config'],
        'limits':{'memory_bytes':17179869184,'swap_bytes':0,'cpu_quota_percent':200,
                  'binaryen_cores':1,'chibi_heap_arguments':'-h64M/4G','whole_campaign_seconds':7200},
        'cases':validation['cases'],'measurement':'not-measured',
        'diagnostics':{'build_wall_seconds':json.loads((root/'validation/compiler/commands/lofi-build/record.json').read_text())['wall_seconds'],
                       'execution_wall_seconds':json.loads((root/'validation/compiler/commands/lofi-wasm/record.json').read_text())['wall_seconds'],
                       'supervisor_reported_memory_peak':'10.9G','swap_bytes':0},
        'scope':'The compiler and Compiler workload sources are unchanged from a2818640. This separate attempt raises the process-group memory limit from 8 to 16 GiB; it does not replace any prior failure or provide a controlled timing comparison.',
        'records':{'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
                   'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()}}
(out/f'{stem}.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cases':validation['cases'],'archive_bytes':archive.stat().st_size},indent=2))
