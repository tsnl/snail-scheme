from pathlib import Path
from collections import Counter
import hashlib,io,json,tarfile,subprocess

root=Path('/tmp/snail-checked-types-followup-20261018')
repo=Path('/tmp/snail-checked-types-20261018')
original=Path('/tmp/snail-checked-types-full57-20261018')
output=repo/'benchmarks/lofi/evidence'
stem='20261018-checked-types-followup'
manifest=json.loads((root/'manifest.json').read_text())
validation=json.loads((root/'validation.json').read_text())
rows=validation['cases']
assert manifest['source_status']==''
assert next(row for row in rows if row['name']=='simplex').get('scheduler_validation')=='passed'
keys=['wasm_validation','chez_validation','chez_adapted_validation','rust_wasm_validation','rust_native_validation']
files={p for p in root.glob('*.json')}
files.update(p for p in (root/'commands').rglob('*') if p.is_file())
files.update(p for p in (root/'frozen-driver').rglob('*') if p.is_file())
artifacts={}
for row in rows:
    folder=root/'validation'/row['name']
    files.update(folder.glob('*.json'))
    files.update(p for p in (folder/'commands').rglob('*') if p.is_file())
    for p in list(folder.glob('*.wasm'))+list(folder.glob('*.so')):
        data=p.read_bytes()
        artifacts[str(p.relative_to(root))]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
entries={str(p.relative_to(root)):p.read_bytes() for p in files}
for name in ['prepare','validate']:
    entries[f'campaign/{name}.log']=Path(f'/tmp/snail-checked-types-followup-{name}.log').read_bytes()
entries['campaign/chibi-wrapper.sh']=Path('/tmp/snail-chibi-correctness').read_bytes()
entries['campaign/package.py']=Path(__file__).read_bytes()
entries['campaign/artifacts.json']=(json.dumps(artifacts,indent=2)+'\n').encode()
entries['campaign/source.diff']=subprocess.check_output(['git','diff','a2818640',manifest['source_revision']],cwd=repo)
for p in Path('/tmp/snail-simplex-baseline-20261018').iterdir():
    if p.is_file():
        entries['simplex-baseline/'+p.name]=p.read_bytes()
entries['index.json']=(json.dumps({k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(entries.items())},indent=2)+'\n').encode()
archive=output/f'{stem}-records.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for name,data in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'kind':'canonical-correctness-followup','source_revision':manifest['source_revision'],
        'source_status':manifest['source_status'],'primary_source_revision':'a2818640e3d6b681bbe5e07e4ecf018c473dd401',
        'configuration':manifest['config'],'measurement':'not-measured','cases':rows,
        'limits':{'memory_bytes':8589934592,'swap_bytes':0,'cpu_quota_percent':200,
                  'binaryen_cores':1,'chibi_heap_arguments':'-h64M/4G','whole_campaign_seconds':7200},
        'interruption':{'result':'oom-kill','signal':9,'service_runtime_seconds':215.777,
                        'unfinished_commands':[name for name,data in entries.items() if name.endswith('/record.json') and json.loads(data).get('status')=='started'],
                        'scope':'The process group exceeded 8 GiB during Compiler emission. Simplex completed all routes. Compiler has no execution result; unfinished command records remain unchanged.'},
        'case_outcomes':{'simplex':'passed','compiler':'memory-limit'},
        'scope':'Simplex removes a redundant list constructor and updates its provenance. The compiler and all other benchmark sources are unchanged from the primary campaign.',
        'records':{'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
                   'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()}}
(output/f'{stem}.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cases':rows,'archive_bytes':archive.stat().st_size},indent=2))
