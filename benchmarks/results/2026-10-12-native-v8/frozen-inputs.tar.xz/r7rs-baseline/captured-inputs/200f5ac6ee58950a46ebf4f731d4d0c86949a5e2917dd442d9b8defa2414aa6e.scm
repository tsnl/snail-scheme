(module
 (type $0 (func (param i32) (result i32)))
 (type $bytes (array (mut i8)))
 (rec
  (type $2 (func (param eqref eqref eqref eqref nullref) (result eqref)))
  (type $cell (struct (field (mut (ref struct)))))
  (type $4 (func (param eqref eqref eqref nullref) (result eqref)))
  (type $5 (func (param eqref nullref) (result eqref)))
  (type $6 (func (param eqref eqref) (result (ref struct))))
  (type $7 (func (param (ref $vector) (ref $atom) nullref) (result eqref)))
  (type $8 (func (param eqref eqref eqref nullref) (result eqref)))
  (type $9 (func (param eqref eqref nullref) (result eqref)))
  (type $10 (func (param (ref $vector) (ref $pair) nullref) (result eqref)))
  (type $result_guard_fn_0 (func (param eqref) (result eqref)))
  (type $12 (func (param eqref) (result (ref $atom))))
  (type $extension (struct (field i32) (field i32)))
  (type $bytevector (struct (field (ref $bytes))))
  (type $15 (func (param i32) (result eqref)))
  (type $values (struct (field (ref $vector))))
  (type $call (func (param eqref (ref $vector) nullref) (result eqref)))
  (type $18 (func (param (ref $vector) nullref) (result eqref)))
  (type $19 (func (param eqref eqref) (result (ref $atom))))
  (type $20 (func (param eqref eqref) (result eqref)))
  (type $21 (func (param eqref eqref) (result i32)))
  (type $22 (func (param i64 f64) (result i32)))
  (type $integer (struct (field i64)))
  (type $float (struct (field f64)))
  (type $complex (struct (field eqref) (field eqref)))
  (type $26 (func (param eqref) (result f64)))
  (type $closure (struct (field (ref $call)) (field (ref $vector))))
  (type $vector (array (mut eqref)))
  (type $pair (struct (field (mut eqref)) (field (mut eqref))))
  (type $text_object (struct (field (ref $text))))
  (type $text (array (mut i32)))
  (type $atom (struct (field i32)))
 )
 (type $33 (func (param i32 i32) (result i32)))
 (type $34 (func (param i32 i32 i32)))
 (type $35 (func (param eqref) (result i32)))
 (type $36 (func (param i32 i32)))
 (type $37 (func (param eqref i32 i32)))
 (type $38 (func (param i32)))
 (type $39 (func (result i32)))
 (type $40 (func (param i64) (result i32)))
 (type $41 (func (param f64) (result i32)))
 (type $42 (func (param i32) (result i64)))
 (type $43 (func (param i32) (result f64)))
 (type $44 (func (result eqref)))
 (import "snail.rust" "snail:fail" (func $rust_fail (param i32) (result i32)))
 (import "snail.host" "register-finalizer" (func $host_register_finalizer (param eqref i32 i32)))
 (import "snail.host" "hash-identity" (func $host_hash_identity (param eqref) (result i32)))
 (import "snail.rust" "snail:inexact" (func $rust20 (param i32) (result i32)))
 (import "snail.rust" "snail:round" (func $rust24 (param i32) (result i32)))
 (import "snail.rust" "snail:number->string" (func $rust33 (param i32) (result i32)))
 (import "snail.rust" "snail:error" (func $rust60 (param i32) (result i32)))
 (import "snail.rust" "snail:close-port" (func $rust66 (param i32) (result i32)))
 (import "snail.rust" "snail:read" (func $rust74 (param i32) (result i32)))
 (import "snail.rust" "snail:display" (func $rust88 (param i32) (result i32)))
 (import "snail.rust" "snail:write" (func $rust89 (param i32) (result i32)))
 (import "snail.rust" "snail:flush-output-port" (func $rust92 (param i32) (result i32)))
 (import "snail.rust" "snail:newline" (func $rust93 (param i32) (result i32)))
 (import "snail.rust" "snail:%current-input-port" (func $rust94 (param i32) (result i32)))
 (import "snail.rust" "snail:%current-output-port" (func $rust95 (param i32) (result i32)))
 (import "snail.rust" "snail:%current-error-port" (func $rust96 (param i32) (result i32)))
 (import "snail.rust" "snail:%set-current-input-port!" (func $rust97 (param i32) (result i32)))
 (import "snail.rust" "snail:%set-current-output-port!" (func $rust98 (param i32) (result i32)))
 (import "snail.rust" "snail:%set-current-error-port!" (func $rust99 (param i32) (result i32)))
 (import "snail.rust" "snail:current-second" (func $rust103 (param i32) (result i32)))
 (import "snail.rust" "snail:current-jiffy" (func $rust104 (param i32) (result i32)))
 (import "snail.rust" "snail:jiffies-per-second" (func $rust105 (param i32) (result i32)))
 (import "snail.rust" "snail:symbol-length" (func $rust_symbol_length (param i32) (result i32)))
 (import "snail.rust" "snail:symbol-character" (func $rust_symbol_character (param i32 i32) (result i32)))
 (global $false (ref $atom) (struct.new $atom
  (i32.const 0)
 ))
 (global $true (ref $atom) (struct.new $atom
  (i32.const 1)
 ))
 (global $nil (ref $atom) (struct.new $atom
  (i32.const 2)
 ))
 (global $unspecified (ref $atom) (struct.new $atom
  (i32.const 3)
 ))
 (global $eof (ref $atom) (struct.new $atom
  (i32.const 4)
 ))
 (global $uninitialized (ref $atom) (struct.new $atom
  (i32.const 5)
 ))
 (global $error_code (mut i32) (i32.const 0))
 (global $awi_links (mut (ref $text)) (array.new $text
  (i32.const -2)
  (i32.const 16)
 ))
 (global $awi_used (mut i32) (i32.const 0))
 (global $awi_free (mut i32) (i32.const -2))
 (global $awi_live (mut i32) (i32.const 0))
 (global $g13 (mut (ref null $closure)) (ref.null none))
 (global $g18 (mut (ref null $closure)) (ref.null none))
 (global $g42 (mut (ref null $closure)) (ref.null none))
 (global $g44 (mut (ref null $closure)) (ref.null none))
 (global $g61 (mut (ref null $closure)) (ref.null none))
 (global $g62 (mut (ref null $closure)) (ref.null none))
 (global $g63 (mut (ref null $closure)) (ref.null none))
 (global $g72 (mut (ref null $closure)) (ref.null none))
 (global $g78 (mut (ref null $closure)) (ref.null none))
 (global $g117 (mut (ref null $closure)) (ref.null none))
 (global $g118 (mut (ref null $closure)) (ref.null none))
 (global $g122 (mut (ref null $closure)) (ref.null none))
 (global $g128 (mut (ref null $closure)) (ref.null none))
 (global $g136 (mut (ref null $closure)) (ref.null none))
 (global $g151 (mut (ref null $closure)) (ref.null none))
 (global $g152 (mut (ref null $closure)) (ref.null none))
 (global $g155 (mut (ref null $closure)) (ref.null none))
 (global $g156 (mut (ref null $closure)) (ref.null none))
 (global $g157 (mut (ref null $closure)) (ref.null none))
 (global $g158 (mut (ref null $closure)) (ref.null none))
 (global $g159 (mut (ref null $closure)) (ref.null none))
 (global $g160 (mut (ref null $closure)) (ref.null none))
 (global $g161 (mut (ref null $closure)) (ref.null none))
 (global $g162 (mut (ref null $closure)) (ref.null none))
 (global $g167 (mut (ref null $closure)) (ref.null none))
 (global $g168 (mut (ref null $closure)) (ref.null none))
 (global $g169 (mut (ref null $closure)) (ref.null none))
 (global $g181 (mut (ref null $closure)) (ref.null none))
 (global $g183 (mut (ref null $closure)) (ref.null none))
 (global $g184 (mut (ref null $closure)) (ref.null none))
 (global $g186 (mut (ref null $closure)) (ref.null none))
 (global $g190 (mut (ref null $closure)) (ref.null none))
 (global $g192 (mut (ref null $closure)) (ref.null none))
 (global $g195 (mut (ref null $closure)) (ref.null none))
 (global $g198 (mut (ref null $closure)) (ref.null none))
 (global $g199 (mut (ref null $closure)) (ref.null none))
 (global $g203 (mut (ref null $closure)) (ref.null none))
 (global $g204 (mut (ref null $closure)) (ref.null none))
 (global $g236 (mut (ref null $pair)) (ref.null none))
 (global $g237 (mut (ref null $closure)) (ref.null none))
 (global $g239 (mut (ref null $closure)) (ref.null none))
 (global $g241 (mut (ref null $closure)) (ref.null none))
 (global $g247 (mut (ref null $closure)) (ref.null none))
 (global $g248 (mut (ref null $closure)) (ref.null none))
 (global $g249 (mut (ref null $closure)) (ref.null none))
 (global $g250 (mut (ref null $closure)) (ref.null none))
 (global $g251 (mut (ref null $closure)) (ref.null none))
 (global $literal0 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 43
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
   (i32.const 45)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 110)
   (i32.const 110)
   (i32.const 101)
   (i32.const 103)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 100)
   (i32.const 101)
   (i32.const 120)
  )
 ))
 (global $literal3 (ref $atom) (struct.new $atom
  (i32.const -2147483648)
 ))
 (global $literal4 (ref $pair) (struct.new $pair
  (struct.new $atom
   (i32.const -2147483647)
  )
  (global.get $nil)
 ))
 (global $literal6 (ref $pair) (struct.new $pair
  (struct.new $atom
   (i32.const -2147483646)
  )
  (global.get $nil)
 ))
 (global $literal8 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 36
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 110)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 112)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 111)
   (i32.const 112)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
 ))
 (global $literal9 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 27
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 112)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 103)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 115)
  )
 ))
 (global $literal10 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 3
   (i32.const 97)
   (i32.const 99)
   (i32.const 107)
  )
 ))
 (global $literal11 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 1
   (i32.const 58)
  )
 ))
 (global $literal12 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 1
   (i32.const 58)
  )
 ))
 (global $literal13 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 1
   (i32.const 58)
  )
 ))
 (global $literal14 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 12
   (i32.const 115)
   (i32.const 110)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
   (i32.const 45)
   (i32.const 115)
   (i32.const 99)
   (i32.const 104)
   (i32.const 101)
   (i32.const 109)
   (i32.const 101)
  )
 ))
 (global $literal15 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 8
   (i32.const 82)
   (i32.const 117)
   (i32.const 110)
   (i32.const 110)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
  )
 ))
 (global $literal16 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 14
   (i32.const 69)
   (i32.const 108)
   (i32.const 97)
   (i32.const 112)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 105)
   (i32.const 109)
   (i32.const 101)
   (i32.const 58)
   (i32.const 32)
  )
 ))
 (global $literal17 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 10
   (i32.const 32)
   (i32.const 115)
   (i32.const 101)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 100)
   (i32.const 115)
   (i32.const 32)
   (i32.const 40)
  )
 ))
 (global $literal18 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 6
   (i32.const 41)
   (i32.const 32)
   (i32.const 102)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
  )
 ))
 (global $literal19 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 11
   (i32.const 43)
   (i32.const 33)
   (i32.const 67)
   (i32.const 83)
   (i32.const 86)
   (i32.const 76)
   (i32.const 73)
   (i32.const 78)
   (i32.const 69)
   (i32.const 33)
   (i32.const 43)
  )
 ))
 (global $literal20 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 1
   (i32.const 44)
  )
 ))
 (global $literal21 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 1
   (i32.const 44)
  )
 ))
 (global $literal22 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 34
   (i32.const 69)
   (i32.const 82)
   (i32.const 82)
   (i32.const 79)
   (i32.const 82)
   (i32.const 58)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 116)
   (i32.const 117)
   (i32.const 114)
   (i32.const 110)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 114)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 117)
   (i32.const 108)
   (i32.const 116)
   (i32.const 58)
   (i32.const 32)
  )
 ))
 (global $literal23 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 11
   (i32.const 43)
   (i32.const 33)
   (i32.const 67)
   (i32.const 83)
   (i32.const 86)
   (i32.const 76)
   (i32.const 73)
   (i32.const 78)
   (i32.const 69)
   (i32.const 33)
   (i32.const 43)
  )
 ))
 (global $literal24 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 1
   (i32.const 44)
  )
 ))
 (global $literal25 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 1
   (i32.const 44)
  )
 ))
 (global $literal26 (ref $text_object) (struct.new $text_object
  (array.new_fixed $text 9
   (i32.const 73)
   (i32.const 78)
   (i32.const 67)
   (i32.const 79)
   (i32.const 82)
   (i32.const 82)
   (i32.const 69)
   (i32.const 67)
   (i32.const 84)
  )
 ))
 (global $symbol_names (ref $vector) (array.new_fixed $vector 3
  (struct.new $text_object
   (array.new_fixed $text 9
    (i32.const 112)
    (i32.const 97)
    (i32.const 114)
    (i32.const 97)
    (i32.const 109)
    (i32.const 101)
    (i32.const 116)
    (i32.const 101)
    (i32.const 114)
   )
  )
  (struct.new $text_object
   (array.new_fixed $text 7
    (i32.const 99)
    (i32.const 111)
    (i32.const 110)
    (i32.const 118)
    (i32.const 101)
    (i32.const 114)
    (i32.const 116)
   )
  )
  (struct.new $text_object
   (array.new_fixed $text 7
    (i32.const 114)
    (i32.const 101)
    (i32.const 115)
    (i32.const 116)
    (i32.const 111)
    (i32.const 114)
    (i32.const 101)
   )
  )
 ))
 (table $awi_roots 16 eqref)
 (export "error_code" (global $error_code))
 (export "awi_live_roots" (global $awi_live))
 (export "release" (func $awi_release))
 (export "retain" (func $14))
 (export "same" (func $15))
 (export "identity_hash" (func $16))
 (export "literal_symbol_names" (func $17))
 (export "kind" (func $18))
 (export "integer" (func $19))
 (export "real" (func $20))
 (export "complex" (func $21))
 (export "real_part" (func $22))
 (export "imag_part" (func $23))
 (export "atom" (func $24))
 (export "pair" (func $25))
 (export "pair_set_car" (func $26))
 (export "pair_set_cdr" (func $27))
 (export "extension" (func $28))
 (export "vector_new" (func $29))
 (export "values" (func $30))
 (export "vector_set" (func $31))
 (export "string_new" (func $32))
 (export "string_set" (func $33))
 (export "bytes_new" (func $34))
 (export "byte_set" (func $35))
 (export "as_integer" (func $36))
 (export "as_real" (func $37))
 (export "atom_value" (func $38))
 (export "length" (func $39))
 (export "at" (func $40))
 (export "char_at" (func $41))
 (export "byte_at" (func $42))
 (export "car" (func $43))
 (export "cdr" (func $44))
 (export "extension_kind" (func $45))
 (export "extension_id" (func $46))
 (export "call" (func $47))
 (export "snail_main" (func $program))
 (export "snail:main" (func $115))
 (func $float_value (type $26) (param $0 eqref) (result f64)
  (local $1 i32)
  (block $block
   (if
    (local.tee $1
     (ref.test (ref $complex)
      (local.get $0)
     )
    )
    (then
     (br_if $block
      (f64.ne
       (call $float_value
        (if (result eqref)
         (local.get $1)
         (then
          (struct.get $complex 1
           (ref.cast (ref $complex)
            (local.get $0)
           )
          )
         )
         (else
          (drop
           (call $float_value
            (local.get $0)
           )
          )
          (ref.i31
           (i32.const 0)
          )
         )
        )
       )
       (f64.const 0.0)
      )
     )
     (return
      (call $float_value
       (if (result eqref)
        (ref.test (ref $complex)
         (local.get $0)
        )
        (then
         (struct.get $complex 0
          (ref.cast (ref $complex)
           (local.get $0)
          )
         )
        )
        (else
         (drop
          (call $float_value
           (local.get $0)
          )
         )
         (local.get $0)
        )
       )
      )
     )
    )
   )
   (return
    (if (result f64)
     (ref.test (ref $float)
      (local.get $0)
     )
     (then
      (struct.get $float 0
       (ref.cast (ref $float)
        (local.get $0)
       )
      )
     )
     (else
      (f64.convert_i64_s
       (if (result i64)
        (ref.test (ref i31)
         (local.get $0)
        )
        (then
         (i64.extend_i32_s
          (i31.get_s
           (ref.cast (ref i31)
            (local.get $0)
           )
          )
         )
        )
        (else
         (if (result i64)
          (ref.test (ref $integer)
           (local.get $0)
          )
          (then
           (struct.get $integer 0
            (ref.cast (ref $integer)
             (local.get $0)
            )
           )
          )
          (else
           (br $block)
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $error_code
   (i32.const 1)
  )
  (drop
   (call $rust_fail
    (i32.const 1)
   )
  )
  (unreachable)
 )
 (func $compare_integer_float (type $22) (param $0 i64) (param $1 f64) (result i32)
  (local $2 i64)
  (local $3 f64)
  (local $4 i32)
  (if
   (f64.ne
    (local.get $1)
    (local.get $1)
   )
   (then
    (return
     (i32.const 2)
    )
   )
  )
  (if
   (f64.ge
    (local.get $1)
    (f64.const 9223372036854775808.0)
   )
   (then
    (return
     (i32.const -1)
    )
   )
  )
  (if
   (f64.lt
    (local.get $1)
    (f64.const -9223372036854775808.0)
   )
   (then
    (return
     (i32.const 1)
    )
   )
  )
  (if (result i32)
   (local.tee $4
    (select
     (i32.const -1)
     (i64.lt_s
      (local.tee $2
       (i64.trunc_f64_s
        (local.get $1)
       )
      )
      (local.get $0)
     )
     (i64.lt_s
      (local.get $0)
      (local.get $2)
     )
    )
   )
   (then
    (local.get $4)
   )
   (else
    (if (result i32)
     (f64.gt
      (local.get $1)
      (local.tee $3
       (f64.convert_i64_s
        (local.get $2)
       )
      )
     )
     (then
      (i32.const -1)
     )
     (else
      (select
       (i32.const 1)
       (select
        (i32.const 2)
        (i32.const 0)
        (f64.ne
         (local.get $1)
         (local.get $3)
        )
       )
       (f64.lt
        (local.get $1)
        (local.get $3)
       )
      )
     )
    )
   )
  )
 )
 (func $cold.compare (type $21) (param $0 eqref) (param $1 eqref) (result i32)
  (local $2 i32)
  (local $3 f64)
  (local $4 f64)
  (local $5 i64)
  (local $6 i64)
  (block $block
   (return
    (if (result i32)
     (i32.or
      (local.tee $2
       (ref.test (ref i31)
        (local.get $0)
       )
      )
      (ref.test (ref $integer)
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.or
        (ref.test (ref i31)
         (local.get $1)
        )
        (ref.test (ref $integer)
         (local.get $1)
        )
       )
       (then
        (select
         (i32.const -1)
         (i64.gt_s
          (local.tee $5
           (if (result i64)
            (local.get $2)
            (then
             (i64.extend_i32_s
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $0)
               )
              )
             )
            )
            (else
             (if (result i64)
              (ref.test (ref $integer)
               (local.get $0)
              )
              (then
               (struct.get $integer 0
                (ref.cast (ref $integer)
                 (local.get $0)
                )
               )
              )
              (else
               (br $block)
              )
             )
            )
           )
          )
          (local.tee $6
           (if (result i64)
            (ref.test (ref i31)
             (local.get $1)
            )
            (then
             (i64.extend_i32_s
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $1)
               )
              )
             )
            )
            (else
             (if (result i64)
              (ref.test (ref $integer)
               (local.get $1)
              )
              (then
               (struct.get $integer 0
                (ref.cast (ref $integer)
                 (local.get $1)
                )
               )
              )
              (else
               (br $block)
              )
             )
            )
           )
          )
         )
         (i64.lt_s
          (local.get $5)
          (local.get $6)
         )
        )
       )
       (else
        (call $compare_integer_float
         (if (result i64)
          (ref.test (ref i31)
           (local.get $0)
          )
          (then
           (i64.extend_i32_s
            (i31.get_s
             (ref.cast (ref i31)
              (local.get $0)
             )
            )
           )
          )
          (else
           (if (result i64)
            (ref.test (ref $integer)
             (local.get $0)
            )
            (then
             (struct.get $integer 0
              (ref.cast (ref $integer)
               (local.get $0)
              )
             )
            )
            (else
             (br $block)
            )
           )
          )
         )
         (call $float_value
          (local.get $1)
         )
        )
       )
      )
     )
     (else
      (if (result i32)
       (i32.or
        (local.tee $2
         (ref.test (ref i31)
          (local.get $1)
         )
        )
        (ref.test (ref $integer)
         (local.get $1)
        )
       )
       (then
        (select
         (i32.const 2)
         (i32.sub
          (i32.const 0)
          (local.tee $2
           (call $compare_integer_float
            (if (result i64)
             (local.get $2)
             (then
              (i64.extend_i32_s
               (i31.get_s
                (ref.cast (ref i31)
                 (local.get $1)
                )
               )
              )
             )
             (else
              (if (result i64)
               (ref.test (ref $integer)
                (local.get $1)
               )
               (then
                (struct.get $integer 0
                 (ref.cast (ref $integer)
                  (local.get $1)
                 )
                )
               )
               (else
                (br $block)
               )
              )
             )
            )
            (call $float_value
             (local.get $0)
            )
           )
          )
         )
         (i32.eq
          (local.get $2)
          (i32.const 2)
         )
        )
       )
       (else
        (if (result i32)
         (f64.lt
          (local.tee $3
           (call $float_value
            (local.get $0)
           )
          )
          (local.tee $4
           (call $float_value
            (local.get $1)
           )
          )
         )
         (then
          (i32.const -1)
         )
         (else
          (select
           (i32.const 1)
           (select
            (i32.const 2)
            (i32.const 0)
            (f64.ne
             (local.get $3)
             (local.get $4)
            )
           )
           (f64.gt
            (local.get $3)
            (local.get $4)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $error_code
   (i32.const 1)
  )
  (drop
   (call $rust_fail
    (i32.const 1)
   )
  )
  (unreachable)
 )
 (func $cold.checked_add (type $20) (param $0 eqref) (param $1 eqref) (result eqref)
  (local $2 i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 eqref)
  (local $6 eqref)
  (if
   (i32.or
    (local.tee $2
     (ref.test (ref $complex)
      (local.get $0)
     )
    )
    (ref.test (ref $complex)
     (local.get $1)
    )
   )
   (then
    (return
     (call $make_complex
      (if (result eqref)
       (i32.and
        (ref.test (ref i31)
         (local.tee $5
          (if (result eqref)
           (local.get $2)
           (then
            (struct.get $complex 0
             (ref.cast (ref $complex)
              (local.get $0)
             )
            )
           )
           (else
            (drop
             (call $float_value
              (local.get $0)
             )
            )
            (local.get $0)
           )
          )
         )
        )
        (ref.test (ref i31)
         (local.tee $6
          (if (result eqref)
           (ref.test (ref $complex)
            (local.get $1)
           )
           (then
            (struct.get $complex 0
             (ref.cast (ref $complex)
              (local.get $1)
             )
            )
           )
           (else
            (drop
             (call $float_value
              (local.get $1)
             )
            )
            (local.get $1)
           )
          )
         )
        )
       )
       (then
        (if (result eqref)
         (i32.le_u
          (i32.add
           (local.tee $2
            (i32.add
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $5)
              )
             )
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $6)
              )
             )
            )
           )
           (i32.const 1073741824)
          )
          (i32.const 2147483647)
         )
         (then
          (ref.i31
           (local.get $2)
          )
         )
         (else
          (call $cold.checked_add
           (local.get $5)
           (local.get $6)
          )
         )
        )
       )
       (else
        (call $cold.checked_add
         (local.get $5)
         (local.get $6)
        )
       )
      )
      (if (result eqref)
       (i32.and
        (ref.test (ref i31)
         (local.tee $0
          (if (result eqref)
           (ref.test (ref $complex)
            (local.get $0)
           )
           (then
            (struct.get $complex 1
             (ref.cast (ref $complex)
              (local.get $0)
             )
            )
           )
           (else
            (drop
             (call $float_value
              (local.get $0)
             )
            )
            (ref.i31
             (i32.const 0)
            )
           )
          )
         )
        )
        (ref.test (ref i31)
         (local.tee $1
          (if (result eqref)
           (ref.test (ref $complex)
            (local.get $1)
           )
           (then
            (struct.get $complex 1
             (ref.cast (ref $complex)
              (local.get $1)
             )
            )
           )
           (else
            (drop
             (call $float_value
              (local.get $1)
             )
            )
            (ref.i31
             (i32.const 0)
            )
           )
          )
         )
        )
       )
       (then
        (if (result eqref)
         (i32.le_u
          (i32.add
           (local.tee $2
            (i32.add
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $0)
              )
             )
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $1)
              )
             )
            )
           )
           (i32.const 1073741824)
          )
          (i32.const 2147483647)
         )
         (then
          (ref.i31
           (local.get $2)
          )
         )
         (else
          (call $cold.checked_add
           (local.get $0)
           (local.get $1)
          )
         )
        )
       )
       (else
        (call $cold.checked_add
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
  (block $block
   (return
    (if (result (ref eq))
     (i32.and
      (i32.or
       (local.tee $2
        (ref.test (ref i31)
         (local.get $0)
        )
       )
       (ref.test (ref $integer)
        (local.get $0)
       )
      )
      (i32.or
       (ref.test (ref i31)
        (local.get $1)
       )
       (ref.test (ref $integer)
        (local.get $1)
       )
      )
     )
     (then
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.tee $3
           (if (result i64)
            (local.get $2)
            (then
             (i64.extend_i32_s
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $0)
               )
              )
             )
            )
            (else
             (if (result i64)
              (ref.test (ref $integer)
               (local.get $0)
              )
              (then
               (struct.get $integer 0
                (ref.cast (ref $integer)
                 (local.get $0)
                )
               )
              )
              (else
               (br $block)
              )
             )
            )
           )
          )
          (local.tee $3
           (i64.add
            (local.tee $4
             (if (result i64)
              (ref.test (ref i31)
               (local.get $1)
              )
              (then
               (i64.extend_i32_s
                (i31.get_s
                 (ref.cast (ref i31)
                  (local.get $1)
                 )
                )
               )
              )
              (else
               (if (result i64)
                (ref.test (ref $integer)
                 (local.get $1)
                )
                (then
                 (struct.get $integer 0
                  (ref.cast (ref $integer)
                   (local.get $1)
                  )
                 )
                )
                (else
                 (br $block)
                )
               )
              )
             )
            )
            (local.get $3)
           )
          )
         )
         (i64.xor
          (local.get $3)
          (local.get $4)
         )
        )
        (i64.const 0)
       )
       (then
        (global.set $error_code
         (i32.const 2)
        )
        (drop
         (call $rust_fail
          (i32.const 2)
         )
        )
        (unreachable)
       )
      )
      (if (result (ref eq))
       (i32.and
        (i64.le_s
         (local.get $3)
         (i64.const 1073741823)
        )
        (i64.ge_s
         (local.get $3)
         (i64.const -1073741824)
        )
       )
       (then
        (ref.i31
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (else
        (struct.new $integer
         (local.get $3)
        )
       )
      )
     )
     (else
      (struct.new $float
       (f64.add
        (call $float_value
         (local.get $0)
        )
        (call $float_value
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
  (global.set $error_code
   (i32.const 1)
  )
  (drop
   (call $rust_fail
    (i32.const 1)
   )
  )
  (unreachable)
 )
 (func $cold.checked_subtract (type $20) (param $0 eqref) (param $1 eqref) (result eqref)
  (local $2 i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 eqref)
  (local $7 eqref)
  (if
   (i32.or
    (local.tee $2
     (ref.test (ref $complex)
      (local.get $0)
     )
    )
    (ref.test (ref $complex)
     (local.get $1)
    )
   )
   (then
    (return
     (call $make_complex
      (if (result eqref)
       (i32.and
        (ref.test (ref i31)
         (local.tee $6
          (if (result eqref)
           (local.get $2)
           (then
            (struct.get $complex 0
             (ref.cast (ref $complex)
              (local.get $0)
             )
            )
           )
           (else
            (drop
             (call $float_value
              (local.get $0)
             )
            )
            (local.get $0)
           )
          )
         )
        )
        (ref.test (ref i31)
         (local.tee $7
          (if (result eqref)
           (ref.test (ref $complex)
            (local.get $1)
           )
           (then
            (struct.get $complex 0
             (ref.cast (ref $complex)
              (local.get $1)
             )
            )
           )
           (else
            (drop
             (call $float_value
              (local.get $1)
             )
            )
            (local.get $1)
           )
          )
         )
        )
       )
       (then
        (if (result eqref)
         (i32.le_u
          (i32.add
           (local.tee $2
            (i32.sub
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $6)
              )
             )
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $7)
              )
             )
            )
           )
           (i32.const 1073741824)
          )
          (i32.const 2147483647)
         )
         (then
          (ref.i31
           (local.get $2)
          )
         )
         (else
          (call $cold.checked_subtract
           (local.get $6)
           (local.get $7)
          )
         )
        )
       )
       (else
        (call $cold.checked_subtract
         (local.get $6)
         (local.get $7)
        )
       )
      )
      (if (result eqref)
       (i32.and
        (ref.test (ref i31)
         (local.tee $0
          (if (result eqref)
           (ref.test (ref $complex)
            (local.get $0)
           )
           (then
            (struct.get $complex 1
             (ref.cast (ref $complex)
              (local.get $0)
             )
            )
           )
           (else
            (drop
             (call $float_value
              (local.get $0)
             )
            )
            (ref.i31
             (i32.const 0)
            )
           )
          )
         )
        )
        (ref.test (ref i31)
         (local.tee $1
          (if (result eqref)
           (ref.test (ref $complex)
            (local.get $1)
           )
           (then
            (struct.get $complex 1
             (ref.cast (ref $complex)
              (local.get $1)
             )
            )
           )
           (else
            (drop
             (call $float_value
              (local.get $1)
             )
            )
            (ref.i31
             (i32.const 0)
            )
           )
          )
         )
        )
       )
       (then
        (if (result eqref)
         (i32.le_u
          (i32.add
           (local.tee $2
            (i32.sub
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $0)
              )
             )
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $1)
              )
             )
            )
           )
           (i32.const 1073741824)
          )
          (i32.const 2147483647)
         )
         (then
          (ref.i31
           (local.get $2)
          )
         )
         (else
          (call $cold.checked_subtract
           (local.get $0)
           (local.get $1)
          )
         )
        )
       )
       (else
        (call $cold.checked_subtract
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
  (block $block
   (return
    (if (result (ref eq))
     (i32.and
      (i32.or
       (local.tee $2
        (ref.test (ref i31)
         (local.get $0)
        )
       )
       (ref.test (ref $integer)
        (local.get $0)
       )
      )
      (i32.or
       (ref.test (ref i31)
        (local.get $1)
       )
       (ref.test (ref $integer)
        (local.get $1)
       )
      )
     )
     (then
      (local.set $3
       (i64.sub
        (local.tee $4
         (if (result i64)
          (local.get $2)
          (then
           (i64.extend_i32_s
            (i31.get_s
             (ref.cast (ref i31)
              (local.get $0)
             )
            )
           )
          )
          (else
           (if (result i64)
            (ref.test (ref $integer)
             (local.get $0)
            )
            (then
             (struct.get $integer 0
              (ref.cast (ref $integer)
               (local.get $0)
              )
             )
            )
            (else
             (br $block)
            )
           )
          )
         )
        )
        (local.tee $5
         (if (result i64)
          (ref.test (ref i31)
           (local.get $1)
          )
          (then
           (i64.extend_i32_s
            (i31.get_s
             (ref.cast (ref i31)
              (local.get $1)
             )
            )
           )
          )
          (else
           (if (result i64)
            (ref.test (ref $integer)
             (local.get $1)
            )
            (then
             (struct.get $integer 0
              (ref.cast (ref $integer)
               (local.get $1)
              )
             )
            )
            (else
             (br $block)
            )
           )
          )
         )
        )
       )
      )
      (if
       (i64.lt_s
        (i64.and
         (i64.xor
          (local.get $4)
          (local.get $5)
         )
         (i64.xor
          (local.get $3)
          (local.get $4)
         )
        )
        (i64.const 0)
       )
       (then
        (global.set $error_code
         (i32.const 2)
        )
        (drop
         (call $rust_fail
          (i32.const 2)
         )
        )
        (unreachable)
       )
      )
      (if (result (ref eq))
       (i32.and
        (i64.le_s
         (local.get $3)
         (i64.const 1073741823)
        )
        (i64.ge_s
         (local.get $3)
         (i64.const -1073741824)
        )
       )
       (then
        (ref.i31
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (else
        (struct.new $integer
         (local.get $3)
        )
       )
      )
     )
     (else
      (struct.new $float
       (f64.sub
        (call $float_value
         (local.get $0)
        )
        (call $float_value
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
  (global.set $error_code
   (i32.const 1)
  )
  (drop
   (call $rust_fail
    (i32.const 1)
   )
  )
  (unreachable)
 )
 (func $numeric_equal (type $19) (param $0 eqref) (param $1 eqref) (result (ref $atom))
  (local $2 i32)
  (if
   (i32.or
    (local.tee $2
     (ref.test (ref $complex)
      (local.get $0)
     )
    )
    (ref.test (ref $complex)
     (local.get $1)
    )
   )
   (then
    (return
     (select (result (ref $atom))
      (global.get $false)
      (global.get $true)
      (i32.or
       (ref.eq
        (call $numeric_equal
         (if (result eqref)
          (local.get $2)
          (then
           (struct.get $complex 0
            (ref.cast (ref $complex)
             (local.get $0)
            )
           )
          )
          (else
           (drop
            (call $float_value
             (local.get $0)
            )
           )
           (local.get $0)
          )
         )
         (if (result eqref)
          (ref.test (ref $complex)
           (local.get $1)
          )
          (then
           (struct.get $complex 0
            (ref.cast (ref $complex)
             (local.get $1)
            )
           )
          )
          (else
           (drop
            (call $float_value
             (local.get $1)
            )
           )
           (local.get $1)
          )
         )
        )
        (global.get $false)
       )
       (ref.eq
        (call $numeric_equal
         (if (result eqref)
          (ref.test (ref $complex)
           (local.get $0)
          )
          (then
           (struct.get $complex 1
            (ref.cast (ref $complex)
             (local.get $0)
            )
           )
          )
          (else
           (drop
            (call $float_value
             (local.get $0)
            )
           )
           (ref.i31
            (i32.const 0)
           )
          )
         )
         (if (result eqref)
          (ref.test (ref $complex)
           (local.get $1)
          )
          (then
           (struct.get $complex 1
            (ref.cast (ref $complex)
             (local.get $1)
            )
           )
          )
          (else
           (drop
            (call $float_value
             (local.get $1)
            )
           )
           (ref.i31
            (i32.const 0)
           )
          )
         )
        )
        (global.get $false)
       )
      )
     )
    )
   )
  )
  (select (result (ref $atom))
   (global.get $true)
   (global.get $false)
   (if (result i32)
    (i32.and
     (ref.test (ref i31)
      (local.get $0)
     )
     (ref.test (ref i31)
      (local.get $1)
     )
    )
    (then
     (i32.eq
      (i31.get_s
       (ref.cast (ref i31)
        (local.get $0)
       )
      )
      (i31.get_s
       (ref.cast (ref i31)
        (local.get $1)
       )
      )
     )
    )
    (else
     (i32.and
      (i32.eqz
       (local.tee $2
        (call $cold.compare
         (local.get $0)
         (local.get $1)
        )
       )
      )
      (i32.ne
       (local.get $2)
       (i32.const 2)
      )
     )
    )
   )
  )
 )
 (func $multiply (type $20) (param $0 eqref) (param $1 eqref) (result eqref)
  (local $2 i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 eqref)
  (local $7 eqref)
  (local $8 eqref)
  (local $9 eqref)
  (if
   (i32.or
    (local.tee $2
     (ref.test (ref $complex)
      (local.get $0)
     )
    )
    (ref.test (ref $complex)
     (local.get $1)
    )
   )
   (then
    (local.set $6
     (if (result eqref)
      (local.get $2)
      (then
       (struct.get $complex 0
        (ref.cast (ref $complex)
         (local.get $0)
        )
       )
      )
      (else
       (drop
        (call $float_value
         (local.get $0)
        )
       )
       (local.get $0)
      )
     )
    )
    (local.set $7
     (if (result eqref)
      (ref.test (ref $complex)
       (local.get $0)
      )
      (then
       (struct.get $complex 1
        (ref.cast (ref $complex)
         (local.get $0)
        )
       )
      )
      (else
       (drop
        (call $float_value
         (local.get $0)
        )
       )
       (ref.i31
        (i32.const 0)
       )
      )
     )
    )
    (local.set $8
     (if (result eqref)
      (ref.test (ref $complex)
       (local.get $1)
      )
      (then
       (struct.get $complex 0
        (ref.cast (ref $complex)
         (local.get $1)
        )
       )
      )
      (else
       (drop
        (call $float_value
         (local.get $1)
        )
       )
       (local.get $1)
      )
     )
    )
    (local.set $9
     (if (result eqref)
      (ref.test (ref $complex)
       (local.get $1)
      )
      (then
       (struct.get $complex 1
        (ref.cast (ref $complex)
         (local.get $1)
        )
       )
      )
      (else
       (drop
        (call $float_value
         (local.get $1)
        )
       )
       (ref.i31
        (i32.const 0)
       )
      )
     )
    )
    (return
     (call $make_complex
      (if (result eqref)
       (i32.and
        (ref.test (ref i31)
         (local.tee $0
          (call $multiply
           (local.get $6)
           (local.get $8)
          )
         )
        )
        (ref.test (ref i31)
         (local.tee $1
          (call $multiply
           (local.get $7)
           (local.get $9)
          )
         )
        )
       )
       (then
        (if (result eqref)
         (i32.le_u
          (i32.add
           (local.tee $2
            (i32.sub
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $0)
              )
             )
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $1)
              )
             )
            )
           )
           (i32.const 1073741824)
          )
          (i32.const 2147483647)
         )
         (then
          (ref.i31
           (local.get $2)
          )
         )
         (else
          (call $cold.checked_subtract
           (local.get $0)
           (local.get $1)
          )
         )
        )
       )
       (else
        (call $cold.checked_subtract
         (local.get $0)
         (local.get $1)
        )
       )
      )
      (if (result eqref)
       (i32.and
        (ref.test (ref i31)
         (local.tee $0
          (call $multiply
           (local.get $6)
           (local.get $9)
          )
         )
        )
        (ref.test (ref i31)
         (local.tee $1
          (call $multiply
           (local.get $7)
           (local.get $8)
          )
         )
        )
       )
       (then
        (if (result eqref)
         (i32.le_u
          (i32.add
           (local.tee $2
            (i32.add
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $0)
              )
             )
             (i31.get_s
              (ref.cast (ref i31)
               (local.get $1)
              )
             )
            )
           )
           (i32.const 1073741824)
          )
          (i32.const 2147483647)
         )
         (then
          (ref.i31
           (local.get $2)
          )
         )
         (else
          (call $cold.checked_add
           (local.get $0)
           (local.get $1)
          )
         )
        )
       )
       (else
        (call $cold.checked_add
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
  (block $block
   (block $block1
    (return
     (if (result (ref eq))
      (i32.and
       (i32.or
        (local.tee $2
         (ref.test (ref i31)
          (local.get $0)
         )
        )
        (ref.test (ref $integer)
         (local.get $0)
        )
       )
       (i32.or
        (ref.test (ref i31)
         (local.get $1)
        )
        (ref.test (ref $integer)
         (local.get $1)
        )
       )
      )
      (then
       (br_if $block1
        (i32.and
         (i64.eq
          (local.tee $5
           (if (result i64)
            (local.get $2)
            (then
             (i64.extend_i32_s
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $0)
               )
              )
             )
            )
            (else
             (if (result i64)
              (ref.test (ref $integer)
               (local.get $0)
              )
              (then
               (struct.get $integer 0
                (ref.cast (ref $integer)
                 (local.get $0)
                )
               )
              )
              (else
               (br $block)
              )
             )
            )
           )
          )
          (i64.const -9223372036854775808)
         )
         (i64.eq
          (local.tee $4
           (if (result i64)
            (ref.test (ref i31)
             (local.get $1)
            )
            (then
             (i64.extend_i32_s
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $1)
               )
              )
             )
            )
            (else
             (if (result i64)
              (ref.test (ref $integer)
               (local.get $1)
              )
              (then
               (struct.get $integer 0
                (ref.cast (ref $integer)
                 (local.get $1)
                )
               )
              )
              (else
               (br $block)
              )
             )
            )
           )
          )
          (i64.const -1)
         )
        )
       )
       (local.set $3
        (i64.mul
         (local.get $4)
         (local.get $5)
        )
       )
       (if
        (i64.ne
         (local.get $4)
         (i64.const 0)
        )
        (then
         (br_if $block1
          (i64.ne
           (i64.div_s
            (local.get $3)
            (local.get $4)
           )
           (local.get $5)
          )
         )
        )
       )
       (if (result (ref eq))
        (i32.and
         (i64.le_s
          (local.get $3)
          (i64.const 1073741823)
         )
         (i64.ge_s
          (local.get $3)
          (i64.const -1073741824)
         )
        )
        (then
         (ref.i31
          (i32.wrap_i64
           (local.get $3)
          )
         )
        )
        (else
         (struct.new $integer
          (local.get $3)
         )
        )
       )
      )
      (else
       (struct.new $float
        (f64.mul
         (call $float_value
          (local.get $0)
         )
         (call $float_value
          (local.get $1)
         )
        )
       )
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 2)
   )
   (drop
    (call $rust_fail
     (i32.const 2)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 1)
  )
  (drop
   (call $rust_fail
    (i32.const 1)
   )
  )
  (unreachable)
 )
 (func $divide (type $20) (param $0 eqref) (param $1 eqref) (result eqref)
  (local $2 i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 eqref)
  (local $6 eqref)
  (local $7 eqref)
  (local $8 eqref)
  (local $9 eqref)
  (if
   (i32.or
    (local.tee $2
     (ref.test (ref $complex)
      (local.get $0)
     )
    )
    (ref.test (ref $complex)
     (local.get $1)
    )
   )
   (then
    (local.set $7
     (if (result eqref)
      (local.get $2)
      (then
       (struct.get $complex 0
        (ref.cast (ref $complex)
         (local.get $0)
        )
       )
      )
      (else
       (drop
        (call $float_value
         (local.get $0)
        )
       )
       (local.get $0)
      )
     )
    )
    (local.set $8
     (if (result eqref)
      (ref.test (ref $complex)
       (local.get $0)
      )
      (then
       (struct.get $complex 1
        (ref.cast (ref $complex)
         (local.get $0)
        )
       )
      )
      (else
       (drop
        (call $float_value
         (local.get $0)
        )
       )
       (ref.i31
        (i32.const 0)
       )
      )
     )
    )
    (local.set $0
     (if (result eqref)
      (ref.test (ref $complex)
       (local.get $1)
      )
      (then
       (struct.get $complex 0
        (ref.cast (ref $complex)
         (local.get $1)
        )
       )
      )
      (else
       (drop
        (call $float_value
         (local.get $1)
        )
       )
       (local.get $1)
      )
     )
    )
    (local.set $1
     (if (result eqref)
      (ref.test (ref $complex)
       (local.get $1)
      )
      (then
       (struct.get $complex 1
        (ref.cast (ref $complex)
         (local.get $1)
        )
       )
      )
      (else
       (drop
        (call $float_value
         (local.get $1)
        )
       )
       (ref.i31
        (i32.const 0)
       )
      )
     )
    )
    (local.set $9
     (if (result eqref)
      (i32.and
       (ref.test (ref i31)
        (local.tee $5
         (call $multiply
          (local.get $0)
          (local.get $0)
         )
        )
       )
       (ref.test (ref i31)
        (local.tee $6
         (call $multiply
          (local.get $1)
          (local.get $1)
         )
        )
       )
      )
      (then
       (if (result eqref)
        (i32.le_u
         (i32.add
          (local.tee $2
           (i32.add
            (i31.get_s
             (ref.cast (ref i31)
              (local.get $5)
             )
            )
            (i31.get_s
             (ref.cast (ref i31)
              (local.get $6)
             )
            )
           )
          )
          (i32.const 1073741824)
         )
         (i32.const 2147483647)
        )
        (then
         (ref.i31
          (local.get $2)
         )
        )
        (else
         (call $cold.checked_add
          (local.get $5)
          (local.get $6)
         )
        )
       )
      )
      (else
       (call $cold.checked_add
        (local.get $5)
        (local.get $6)
       )
      )
     )
    )
    (return
     (call $make_complex
      (call $divide
       (if (result eqref)
        (i32.and
         (ref.test (ref i31)
          (local.tee $5
           (call $multiply
            (local.get $7)
            (local.get $0)
           )
          )
         )
         (ref.test (ref i31)
          (local.tee $6
           (call $multiply
            (local.get $8)
            (local.get $1)
           )
          )
         )
        )
        (then
         (if (result eqref)
          (i32.le_u
           (i32.add
            (local.tee $2
             (i32.add
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $5)
               )
              )
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $6)
               )
              )
             )
            )
            (i32.const 1073741824)
           )
           (i32.const 2147483647)
          )
          (then
           (ref.i31
            (local.get $2)
           )
          )
          (else
           (call $cold.checked_add
            (local.get $5)
            (local.get $6)
           )
          )
         )
        )
        (else
         (call $cold.checked_add
          (local.get $5)
          (local.get $6)
         )
        )
       )
       (local.get $9)
      )
      (call $divide
       (if (result eqref)
        (i32.and
         (ref.test (ref i31)
          (local.tee $0
           (call $multiply
            (local.get $8)
            (local.get $0)
           )
          )
         )
         (ref.test (ref i31)
          (local.tee $1
           (call $multiply
            (local.get $7)
            (local.get $1)
           )
          )
         )
        )
        (then
         (if (result eqref)
          (i32.le_u
           (i32.add
            (local.tee $2
             (i32.sub
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $0)
               )
              )
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $1)
               )
              )
             )
            )
            (i32.const 1073741824)
           )
           (i32.const 2147483647)
          )
          (then
           (ref.i31
            (local.get $2)
           )
          )
          (else
           (call $cold.checked_subtract
            (local.get $0)
            (local.get $1)
           )
          )
         )
        )
        (else
         (call $cold.checked_subtract
          (local.get $0)
          (local.get $1)
         )
        )
       )
       (local.get $9)
      )
     )
    )
   )
  )
  (block $block
   (if
    (i32.and
     (i32.or
      (local.tee $2
       (ref.test (ref i31)
        (local.get $0)
       )
      )
      (ref.test (ref $integer)
       (local.get $0)
      )
     )
     (i32.or
      (ref.test (ref i31)
       (local.get $1)
      )
      (ref.test (ref $integer)
       (local.get $1)
      )
     )
    )
    (then
     (local.set $3
      (if (result i64)
       (local.get $2)
       (then
        (i64.extend_i32_s
         (i31.get_s
          (ref.cast (ref i31)
           (local.get $0)
          )
         )
        )
       )
       (else
        (if (result i64)
         (ref.test (ref $integer)
          (local.get $0)
         )
         (then
          (struct.get $integer 0
           (ref.cast (ref $integer)
            (local.get $0)
           )
          )
         )
         (else
          (br $block)
         )
        )
       )
      )
     )
     (if
      (i64.eqz
       (local.tee $4
        (if (result i64)
         (ref.test (ref i31)
          (local.get $1)
         )
         (then
          (i64.extend_i32_s
           (i31.get_s
            (ref.cast (ref i31)
             (local.get $1)
            )
           )
          )
         )
         (else
          (if (result i64)
           (ref.test (ref $integer)
            (local.get $1)
           )
           (then
            (struct.get $integer 0
             (ref.cast (ref $integer)
              (local.get $1)
             )
            )
           )
           (else
            (br $block)
           )
          )
         )
        )
       )
      )
      (then
       (global.set $error_code
        (i32.const 9)
       )
       (drop
        (call $rust_fail
         (i32.const 9)
        )
       )
       (unreachable)
      )
     )
     (if
      (i32.and
       (i64.eq
        (local.get $3)
        (i64.const -9223372036854775808)
       )
       (i64.eq
        (local.get $4)
        (i64.const -1)
       )
      )
      (then
       (global.set $error_code
        (i32.const 2)
       )
       (drop
        (call $rust_fail
         (i32.const 2)
        )
       )
       (unreachable)
      )
     )
     (if
      (i64.eqz
       (i64.rem_s
        (local.get $3)
        (local.get $4)
       )
      )
      (then
       (return
        (if (result (ref eq))
         (i32.and
          (i64.le_s
           (local.tee $3
            (i64.div_s
             (local.get $3)
             (local.get $4)
            )
           )
           (i64.const 1073741823)
          )
          (i64.ge_s
           (local.get $3)
           (i64.const -1073741824)
          )
         )
         (then
          (ref.i31
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
         (else
          (struct.new $integer
           (local.get $3)
          )
         )
        )
       )
      )
     )
    )
   )
   (return
    (struct.new $float
     (f64.div
      (call $float_value
       (local.get $0)
      )
      (call $float_value
       (local.get $1)
      )
     )
    )
   )
  )
  (global.set $error_code
   (i32.const 1)
  )
  (drop
   (call $rust_fail
    (i32.const 1)
   )
  )
  (unreachable)
 )
 (func $make_complex (type $20) (param $0 eqref) (param $1 eqref) (result eqref)
  (drop
   (call $float_value
    (local.get $0)
   )
  )
  (drop
   (call $float_value
    (local.get $1)
   )
  )
  (local.set $0
   (if (result eqref)
    (ref.test (ref $complex)
     (local.get $0)
    )
    (then
     (struct.get $complex 0
      (ref.cast (ref $complex)
       (local.get $0)
      )
     )
    )
    (else
     (drop
      (call $float_value
       (local.get $0)
      )
     )
     (local.get $0)
    )
   )
  )
  (if
   (i32.or
    (ref.test (ref i31)
     (local.tee $1
      (if (result eqref)
       (ref.test (ref $complex)
        (local.get $1)
       )
       (then
        (struct.get $complex 0
         (ref.cast (ref $complex)
          (local.get $1)
         )
        )
       )
       (else
        (drop
         (call $float_value
          (local.get $1)
         )
        )
        (local.get $1)
       )
      )
     )
    )
    (ref.test (ref $integer)
     (local.get $1)
    )
   )
   (then
    (if
     (i64.eqz
      (if (result i64)
       (ref.test (ref i31)
        (local.get $1)
       )
       (then
        (i64.extend_i32_s
         (i31.get_s
          (ref.cast (ref i31)
           (local.get $1)
          )
         )
        )
       )
       (else
        (if (result i64)
         (ref.test (ref $integer)
          (local.get $1)
         )
         (then
          (struct.get $integer 0
           (ref.cast (ref $integer)
            (local.get $1)
           )
          )
         )
         (else
          (global.set $error_code
           (i32.const 1)
          )
          (drop
           (call $rust_fail
            (i32.const 1)
           )
          )
          (unreachable)
         )
        )
       )
      )
     )
     (then
      (return
       (local.get $0)
      )
     )
    )
   )
  )
  (struct.new $complex
   (local.get $0)
   (local.get $1)
  )
 )
 (func $eqv (type $19) (param $0 eqref) (param $1 eqref) (result (ref $atom))
  (local $2 i32)
  (if
   (ref.eq
    (local.get $0)
    (local.get $1)
   )
   (then
    (return
     (global.get $true)
    )
   )
  )
  (if
   (i32.and
    (local.tee $2
     (ref.test (ref $complex)
      (local.get $0)
     )
    )
    (ref.test (ref $complex)
     (local.get $1)
    )
   )
   (then
    (return
     (select (result (ref $atom))
      (global.get $false)
      (global.get $true)
      (i32.or
       (ref.eq
        (call $eqv
         (if (result eqref)
          (local.get $2)
          (then
           (struct.get $complex 0
            (ref.cast (ref $complex)
             (local.get $0)
            )
           )
          )
          (else
           (drop
            (call $float_value
             (local.get $0)
            )
           )
           (local.get $0)
          )
         )
         (if (result eqref)
          (ref.test (ref $complex)
           (local.get $1)
          )
          (then
           (struct.get $complex 0
            (ref.cast (ref $complex)
             (local.get $1)
            )
           )
          )
          (else
           (drop
            (call $float_value
             (local.get $1)
            )
           )
           (local.get $1)
          )
         )
        )
        (global.get $false)
       )
       (ref.eq
        (call $eqv
         (if (result eqref)
          (ref.test (ref $complex)
           (local.get $0)
          )
          (then
           (struct.get $complex 1
            (ref.cast (ref $complex)
             (local.get $0)
            )
           )
          )
          (else
           (drop
            (call $float_value
             (local.get $0)
            )
           )
           (ref.i31
            (i32.const 0)
           )
          )
         )
         (if (result eqref)
          (ref.test (ref $complex)
           (local.get $1)
          )
          (then
           (struct.get $complex 1
            (ref.cast (ref $complex)
             (local.get $1)
            )
           )
          )
          (else
           (drop
            (call $float_value
             (local.get $1)
            )
           )
           (ref.i31
            (i32.const 0)
           )
          )
         )
        )
        (global.get $false)
       )
      )
     )
    )
   )
  )
  (if
   (i32.and
    (i32.or
     (ref.test (ref i31)
      (local.get $0)
     )
     (ref.test (ref $integer)
      (local.get $0)
     )
    )
    (i32.or
     (ref.test (ref i31)
      (local.get $1)
     )
     (ref.test (ref $integer)
      (local.get $1)
     )
    )
   )
   (then
    (return
     (call $numeric_equal
      (local.get $0)
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.and
    (ref.test (ref $float)
     (local.get $0)
    )
    (ref.test (ref $float)
     (local.get $1)
    )
   )
   (then
    (return
     (select (result (ref $atom))
      (global.get $true)
      (global.get $false)
      (f64.eq
       (struct.get $float 0
        (ref.cast (ref $float)
         (local.get $0)
        )
       )
       (struct.get $float 0
        (ref.cast (ref $float)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.and
    (ref.test (ref $atom)
     (local.get $0)
    )
    (ref.test (ref $atom)
     (local.get $1)
    )
   )
   (then
    (return
     (select (result (ref $atom))
      (global.get $true)
      (global.get $false)
      (i32.eq
       (struct.get $atom 0
        (ref.cast (ref $atom)
         (local.get $0)
        )
       )
       (struct.get $atom 0
        (ref.cast (ref $atom)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
  (global.get $false)
 )
 (func $builtin:call-with-values (type $18) (param $0 (ref $vector)) (param $1 nullref) (result eqref)
  (local $2 (ref $closure))
  (local $3 eqref)
  (local $4 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $4
      (array.len
       (local.get $0)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $4)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (local.set $3
   (call_ref $call
    (struct.get $closure 1
     (local.tee $2
      (ref.cast (ref $closure)
       (array.get $vector
        (local.get $0)
        (i32.const 0)
       )
      )
     )
    )
    (array.new_fixed $vector 0)
    (ref.null none)
    (struct.get $closure 0
     (local.get $2)
    )
   )
  )
  (return_call_ref $call
   (struct.get $closure 1
    (local.tee $2
     (ref.cast (ref $closure)
      (array.get $vector
       (local.get $0)
       (i32.const 1)
      )
     )
    )
   )
   (if (result (ref $vector))
    (ref.test (ref $values)
     (local.get $3)
    )
    (then
     (struct.get $values 0
      (ref.cast (ref $values)
       (local.get $3)
      )
     )
    )
    (else
     (array.new_fixed $vector 1
      (local.get $3)
     )
    )
   )
   (local.get $1)
   (struct.get $closure 0
    (local.get $2)
   )
  )
 )
 (func $awi_root (param $0 eqref) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 (ref $text))
  (if
   (i32.ne
    (global.get $awi_free)
    (i32.const -2)
   )
   (then
    (global.set $awi_free
     (array.get $text
      (global.get $awi_links)
      (local.tee $1
       (global.get $awi_free)
      )
     )
    )
   )
   (else
    (if
     (i32.eq
      (local.tee $1
       (global.get $awi_used)
      )
      (table.size $awi_roots)
     )
     (then
      (array.copy $text $text
       (local.tee $3
        (array.new $text
         (i32.const -2)
         (i32.shl
          (local.tee $2
           (table.size $awi_roots)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 0)
       (global.get $awi_links)
       (i32.const 0)
       (local.get $2)
      )
      (if
       (i32.eq
        (table.grow $awi_roots
         (ref.null none)
         (local.get $2)
        )
        (i32.const -1)
       )
       (then
        (unreachable)
       )
      )
      (global.set $awi_links
       (local.get $3)
      )
     )
    )
    (global.set $awi_used
     (i32.add
      (local.get $1)
      (i32.const 1)
     )
    )
   )
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $1)
   (i32.const -1)
  )
  (table.set $awi_roots
   (local.get $1)
   (local.get $0)
  )
  (global.set $awi_live
   (i32.add
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $1)
 )
 (func $awi_release (param $0 i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $0)
   )
  )
  (table.set $awi_roots
   (local.get $0)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $0)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $0)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
 )
 (func $awi_take (type $15) (param $0 i32) (result eqref)
  (local $1 eqref)
  (local $scratch eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (local.set $scratch
   (table.get $awi_roots
    (local.get $0)
   )
  )
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $0)
   )
  )
  (table.set $awi_roots
   (local.get $0)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $0)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $0)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $14 (param $0 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (table.get $awi_roots
    (local.get $0)
   )
  )
 )
 (func $15 (param $0 i32) (param $1 i32) (result i32)
  (local $2 eqref)
  (local $3 eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ge_u
    (local.get $1)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $1)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (block $block (result i32)
   (drop
    (br_if $block
     (i32.const 1)
     (ref.eq
      (local.tee $2
       (table.get $awi_roots
        (local.get $0)
       )
      )
      (local.tee $3
       (table.get $awi_roots
        (local.get $1)
       )
      )
     )
    )
   )
   (if
    (i32.and
     (if (result i32)
      (ref.test (ref $atom)
       (local.get $2)
      )
      (then
       (i32.lt_s
        (struct.get $atom 0
         (ref.cast (ref $atom)
          (local.get $2)
         )
        )
        (i32.const 0)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (if (result i32)
      (ref.test (ref $atom)
       (local.get $3)
      )
      (then
       (i32.lt_s
        (struct.get $atom 0
         (ref.cast (ref $atom)
          (local.get $3)
         )
        )
        (i32.const 0)
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (then
     (br $block
      (i32.eq
       (struct.get $atom 0
        (ref.cast (ref $atom)
         (local.get $2)
        )
       )
       (struct.get $atom 0
        (ref.cast (ref $atom)
         (local.get $3)
        )
       )
      )
     )
    )
   )
   (i32.const 0)
  )
 )
 (func $16 (param $0 i32) (result i32)
  (local $1 eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (block $block (result i32)
   (if
    (if (result i32)
     (ref.test (ref $atom)
      (local.tee $1
       (table.get $awi_roots
        (local.get $0)
       )
      )
     )
     (then
      (i32.lt_s
       (struct.get $atom 0
        (ref.cast (ref $atom)
         (local.get $1)
        )
       )
       (i32.const 0)
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (br $block
      (i32.and
       (struct.get $atom 0
        (ref.cast (ref $atom)
         (local.get $1)
        )
       )
       (i32.const 1073741823)
      )
     )
    )
   )
   (call $host_hash_identity
    (local.get $1)
   )
  )
 )
 (func $17 (result i32)
  (call $awi_root
   (global.get $symbol_names)
  )
 )
 (func $18 (param $0 i32) (result i32)
  (local $1 eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.or
    (ref.test (ref i31)
     (local.tee $1
      (table.get $awi_roots
       (local.get $0)
      )
     )
    )
    (ref.test (ref $integer)
     (local.get $1)
    )
   )
   (then
    (return
     (i32.const 4)
    )
   )
  )
  (if
   (ref.test (ref $atom)
    (local.get $1)
   )
   (then
    (if
     (i32.lt_s
      (local.tee $0
       (struct.get $atom 0
        (ref.cast (ref $atom)
         (local.get $1)
        )
       )
      )
      (i32.const 0)
     )
     (then
      (return
       (i32.const 10)
      )
     )
    )
    (if
     (i32.lt_u
      (local.get $0)
      (i32.const 2)
     )
     (then
      (return
       (i32.const 1)
      )
     )
    )
    (if
     (i32.eq
      (local.get $0)
      (i32.const 2)
     )
     (then
      (return
       (i32.const 2)
      )
     )
    )
    (if
     (i32.eq
      (local.get $0)
      (i32.const 3)
     )
     (then
      (return
       (i32.const 0)
      )
     )
    )
    (if
     (i32.eq
      (local.get $0)
      (i32.const 4)
     )
     (then
      (return
       (i32.const 3)
      )
     )
    )
    (if
     (i32.eq
      (local.get $0)
      (i32.const 5)
     )
     (then
      (return
       (i32.const 16)
      )
     )
    )
    (return
     (i32.const 6)
    )
   )
  )
  (if
   (ref.test (ref $text_object)
    (local.get $1)
   )
   (then
    (return
     (i32.const 9)
    )
   )
  )
  (if
   (ref.test (ref $float)
    (local.get $1)
   )
   (then
    (return
     (i32.const 5)
    )
   )
  )
  (if
   (ref.test (ref $pair)
    (local.get $1)
   )
   (then
    (return
     (i32.const 7)
    )
   )
  )
  (if
   (ref.test (ref $vector)
    (local.get $1)
   )
   (then
    (return
     (i32.const 8)
    )
   )
  )
  (if
   (ref.test (ref $bytevector)
    (local.get $1)
   )
   (then
    (return
     (i32.const 11)
    )
   )
  )
  (if
   (ref.test (ref $closure)
    (local.get $1)
   )
   (then
    (return
     (i32.const 12)
    )
   )
  )
  (if
   (ref.test (ref $extension)
    (local.get $1)
   )
   (then
    (return
     (i32.const 14)
    )
   )
  )
  (if
   (ref.test (ref $values)
    (local.get $1)
   )
   (then
    (return
     (i32.const 15)
    )
   )
  )
  (if
   (ref.test (ref $complex)
    (local.get $1)
   )
   (then
    (return
     (i32.const 17)
    )
   )
  )
  (unreachable)
 )
 (func $19 (param $0 i64) (result i32)
  (call $awi_root
   (if (result (ref eq))
    (i32.and
     (i64.le_s
      (local.get $0)
      (i64.const 1073741823)
     )
     (i64.ge_s
      (local.get $0)
      (i64.const -1073741824)
     )
    )
    (then
     (ref.i31
      (i32.wrap_i64
       (local.get $0)
      )
     )
    )
    (else
     (struct.new $integer
      (local.get $0)
     )
    )
   )
  )
 )
 (func $20 (param $0 f64) (result i32)
  (call $awi_root
   (struct.new $float
    (local.get $0)
   )
  )
 )
 (func $21 (param $0 i32) (param $1 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ge_u
    (local.get $1)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $1)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (call $make_complex
    (table.get $awi_roots
     (local.get $0)
    )
    (table.get $awi_roots
     (local.get $1)
    )
   )
  )
 )
 (func $22 (param $0 i32) (result i32)
  (local $1 eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (if (result eqref)
    (ref.test (ref $complex)
     (local.tee $1
      (table.get $awi_roots
       (local.get $0)
      )
     )
    )
    (then
     (struct.get $complex 0
      (ref.cast (ref $complex)
       (local.get $1)
      )
     )
    )
    (else
     (drop
      (call $float_value
       (local.get $1)
      )
     )
     (local.get $1)
    )
   )
  )
 )
 (func $23 (param $0 i32) (result i32)
  (local $1 eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (if (result eqref)
    (ref.test (ref $complex)
     (local.tee $1
      (table.get $awi_roots
       (local.get $0)
      )
     )
    )
    (then
     (struct.get $complex 1
      (ref.cast (ref $complex)
       (local.get $1)
      )
     )
    )
    (else
     (drop
      (call $float_value
       (local.get $1)
      )
     )
     (ref.i31
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $24 (param $0 i32) (result i32)
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (return
     (call $awi_root
      (global.get $false)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 1)
   )
   (then
    (return
     (call $awi_root
      (global.get $true)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 2)
   )
   (then
    (return
     (call $awi_root
      (global.get $nil)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 3)
   )
   (then
    (return
     (call $awi_root
      (global.get $unspecified)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 4)
   )
   (then
    (return
     (call $awi_root
      (global.get $eof)
     )
    )
   )
  )
  (call $awi_root
   (struct.new $atom
    (local.get $0)
   )
  )
 )
 (func $25 (param $0 i32) (param $1 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ge_u
    (local.get $1)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $1)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (struct.new $pair
    (table.get $awi_roots
     (local.get $0)
    )
    (table.get $awi_roots
     (local.get $1)
    )
   )
  )
 )
 (func $26 (param $0 i32) (param $1 i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ge_u
    (local.get $1)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $1)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $pair 0
   (ref.cast (ref $pair)
    (table.get $awi_roots
     (local.get $0)
    )
   )
   (table.get $awi_roots
    (local.get $1)
   )
  )
 )
 (func $27 (param $0 i32) (param $1 i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ge_u
    (local.get $1)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $1)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $pair 1
   (ref.cast (ref $pair)
    (table.get $awi_roots
     (local.get $0)
    )
   )
   (table.get $awi_roots
    (local.get $1)
   )
  )
 )
 (func $28 (param $0 i32) (param $1 i32) (result i32)
  (local $2 (ref $extension))
  (call $host_register_finalizer
   (local.tee $2
    (struct.new $extension
     (local.get $0)
     (local.get $1)
    )
   )
   (local.get $0)
   (local.get $1)
  )
  (call $awi_root
   (local.get $2)
  )
 )
 (func $29 (param $0 i32) (result i32)
  (call $awi_root
   (array.new $vector
    (global.get $unspecified)
    (local.get $0)
   )
  )
 )
 (func $30 (param $0 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (struct.new $values
    (ref.cast (ref $vector)
     (table.get $awi_roots
      (local.get $0)
     )
    )
   )
  )
 )
 (func $31 (param $0 i32) (param $1 i32) (param $2 i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ge_u
    (local.get $2)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $2)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (array.set $vector
   (ref.cast (ref $vector)
    (table.get $awi_roots
     (local.get $0)
    )
   )
   (local.get $1)
   (table.get $awi_roots
    (local.get $2)
   )
  )
 )
 (func $32 (param $0 i32) (result i32)
  (call $awi_root
   (struct.new $text_object
    (array.new_default $text
     (local.get $0)
    )
   )
  )
 )
 (func $33 (param $0 i32) (param $1 i32) (param $2 i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (array.set $text
   (struct.get $text_object 0
    (ref.cast (ref $text_object)
     (table.get $awi_roots
      (local.get $0)
     )
    )
   )
   (local.get $1)
   (local.get $2)
  )
 )
 (func $34 (param $0 i32) (result i32)
  (call $awi_root
   (struct.new $bytevector
    (array.new_default $bytes
     (local.get $0)
    )
   )
  )
 )
 (func $35 (param $0 i32) (param $1 i32) (param $2 i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (array.set $bytes
   (struct.get $bytevector 0
    (ref.cast (ref $bytevector)
     (table.get $awi_roots
      (local.get $0)
     )
    )
   )
   (local.get $1)
   (local.get $2)
  )
 )
 (func $36 (param $0 i32) (result i64)
  (local $1 eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (ref.test (ref i31)
    (local.tee $1
     (table.get $awi_roots
      (local.get $0)
     )
    )
   )
   (then
    (i64.extend_i32_s
     (i31.get_s
      (ref.cast (ref i31)
       (local.get $1)
      )
     )
    )
   )
   (else
    (if (result i64)
     (ref.test (ref $integer)
      (local.get $1)
     )
     (then
      (struct.get $integer 0
       (ref.cast (ref $integer)
        (local.get $1)
       )
      )
     )
     (else
      (global.set $error_code
       (i32.const 1)
      )
      (drop
       (call $rust_fail
        (i32.const 1)
       )
      )
      (unreachable)
     )
    )
   )
  )
 )
 (func $37 (param $0 i32) (result f64)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $float_value
   (table.get $awi_roots
    (local.get $0)
   )
  )
 )
 (func $38 (param $0 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $atom 0
   (ref.cast (ref $atom)
    (table.get $awi_roots
     (local.get $0)
    )
   )
  )
 )
 (func $39 (param $0 i32) (result i32)
  (local $1 eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (ref.test (ref $vector)
    (local.tee $1
     (table.get $awi_roots
      (local.get $0)
     )
    )
   )
   (then
    (return
     (array.len
      (ref.cast (ref $vector)
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (ref.test (ref $values)
    (local.get $1)
   )
   (then
    (return
     (array.len
      (struct.get $values 0
       (ref.cast (ref $values)
        (local.get $1)
       )
      )
     )
    )
   )
  )
  (if
   (ref.test (ref $text_object)
    (local.get $1)
   )
   (then
    (return
     (array.len
      (struct.get $text_object 0
       (ref.cast (ref $text_object)
        (local.get $1)
       )
      )
     )
    )
   )
  )
  (if
   (if (result i32)
    (ref.test (ref $atom)
     (local.get $1)
    )
    (then
     (i32.lt_s
      (struct.get $atom 0
       (ref.cast (ref $atom)
        (local.get $1)
       )
      )
      (i32.const 0)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (return
     (call $rust_symbol_length
      (i32.and
       (struct.get $atom 0
        (ref.cast (ref $atom)
         (local.get $1)
        )
       )
       (i32.const 2147483647)
      )
     )
    )
   )
  )
  (array.len
   (struct.get $bytevector 0
    (ref.cast (ref $bytevector)
     (local.get $1)
    )
   )
  )
 )
 (func $40 (param $0 i32) (param $1 i32) (result i32)
  (local $2 eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (array.get $vector
    (if (result (ref $vector))
     (ref.test (ref $values)
      (local.tee $2
       (table.get $awi_roots
        (local.get $0)
       )
      )
     )
     (then
      (struct.get $values 0
       (ref.cast (ref $values)
        (local.get $2)
       )
      )
     )
     (else
      (ref.cast (ref $vector)
       (local.get $2)
      )
     )
    )
    (local.get $1)
   )
  )
 )
 (func $41 (param $0 i32) (param $1 i32) (result i32)
  (local $2 eqref)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (if (result i32)
    (ref.test (ref $atom)
     (local.tee $2
      (table.get $awi_roots
       (local.get $0)
      )
     )
    )
    (then
     (i32.lt_s
      (struct.get $atom 0
       (ref.cast (ref $atom)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (return
     (call $rust_symbol_character
      (i32.and
       (struct.get $atom 0
        (ref.cast (ref $atom)
         (local.get $2)
        )
       )
       (i32.const 2147483647)
      )
      (local.get $1)
     )
    )
   )
  )
  (array.get $text
   (struct.get $text_object 0
    (ref.cast (ref $text_object)
     (local.get $2)
    )
   )
   (local.get $1)
  )
 )
 (func $42 (param $0 i32) (param $1 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (array.get_u $bytes
   (struct.get $bytevector 0
    (ref.cast (ref $bytevector)
     (table.get $awi_roots
      (local.get $0)
     )
    )
   )
   (local.get $1)
  )
 )
 (func $43 (param $0 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (struct.get $pair 0
    (ref.cast (ref $pair)
     (table.get $awi_roots
      (local.get $0)
     )
    )
   )
  )
 )
 (func $44 (param $0 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (struct.get $pair 1
    (ref.cast (ref $pair)
     (table.get $awi_roots
      (local.get $0)
     )
    )
   )
  )
 )
 (func $45 (param $0 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $extension 0
   (ref.cast (ref $extension)
    (table.get $awi_roots
     (local.get $0)
    )
   )
  )
 )
 (func $46 (param $0 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $extension 1
   (ref.cast (ref $extension)
    (table.get $awi_roots
     (local.get $0)
    )
   )
  )
 )
 (func $47 (param $0 i32) (param $1 i32) (result i32)
  (local $2 (ref $closure))
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ge_u
    (local.get $1)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $1)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (call $awi_root
   (call_ref $call
    (struct.get $closure 1
     (local.tee $2
      (ref.cast (ref $closure)
       (table.get $awi_roots
        (local.get $0)
       )
      )
     )
    )
    (ref.cast (ref $vector)
     (table.get $awi_roots
      (local.get $1)
     )
    )
    (ref.null none)
    (struct.get $closure 0
     (local.get $2)
    )
   )
  )
 )
 (func $primitive13 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust20
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive18 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust24
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive42 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (call $eqv
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
  )
 )
 (func $primitive44 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 1)
    )
    (i32.eqz
     (local.get $3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (select (result (ref $atom))
   (global.get $true)
   (global.get $false)
   (i32.or
    (if (result i32)
     (local.tee $3
      (ref.test (ref $complex)
       (local.tee $0
        (array.get $vector
         (local.get $1)
         (i32.const 0)
        )
       )
      )
     )
     (then
      (f64.eq
       (call $float_value
        (if (result eqref)
         (local.get $3)
         (then
          (struct.get $complex 1
           (ref.cast (ref $complex)
            (local.get $0)
           )
          )
         )
         (else
          (drop
           (call $float_value
            (local.get $0)
           )
          )
          (ref.i31
           (i32.const 0)
          )
         )
        )
       )
       (f64.const 0.0)
      )
     )
     (else
      (i32.or
       (i32.or
        (ref.test (ref i31)
         (local.get $0)
        )
        (ref.test (ref $integer)
         (local.get $0)
        )
       )
       (ref.test (ref $float)
        (local.get $0)
       )
      )
     )
    )
    (ref.test (ref $complex)
     (local.get $0)
    )
   )
  )
 )
 (func $primitive61 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (struct.set $pair 1
   (ref.cast (ref $pair)
    (array.get $vector
     (local.get $1)
     (i32.const 0)
    )
   )
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
  )
  (global.get $unspecified)
 )
 (func $primitive62 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local.get $1)
 )
 (func $primitive63 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $4 i64)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (array.get $vector
   (ref.cast (ref $vector)
    (array.get $vector
     (local.get $1)
     (i32.const 0)
    )
   )
   (block (result i32)
    (if
     (i64.gt_u
      (local.tee $4
       (if (result i64)
        (ref.test (ref i31)
         (local.tee $0
          (array.get $vector
           (local.get $1)
           (i32.const 1)
          )
         )
        )
        (then
         (i64.extend_i32_s
          (i31.get_s
           (ref.cast (ref i31)
            (local.get $0)
           )
          )
         )
        )
        (else
         (if (result i64)
          (ref.test (ref $integer)
           (local.get $0)
          )
          (then
           (struct.get $integer 0
            (ref.cast (ref $integer)
             (local.get $0)
            )
           )
          )
          (else
           (global.set $error_code
            (i32.const 1)
           )
           (drop
            (call $rust_fail
             (i32.const 1)
            )
           )
           (unreachable)
          )
         )
        )
       )
      )
      (i64.const 2147483647)
     )
     (then
      (global.set $error_code
       (i32.const 3)
      )
      (drop
       (call $rust_fail
        (i32.const 3)
       )
      )
      (unreachable)
     )
    )
    (i32.wrap_i64
     (local.get $4)
    )
   )
  )
 )
 (func $primitive72 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 (ref $text))
  (local $7 (ref $text))
  (block $block
   (loop $label
    (if
     (i32.ne
      (array.len
       (local.get $1)
      )
      (local.get $3)
     )
     (then
      (br_if $block
       (i32.eqz
        (ref.test (ref $text_object)
         (local.tee $0
          (array.get $vector
           (local.get $1)
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $4
       (i32.add
        (local.get $4)
        (array.len
         (struct.get $text_object 0
          (ref.cast (ref $text_object)
           (local.get $0)
          )
         )
        )
       )
      )
      (local.set $3
       (i32.add
        (local.get $3)
        (i32.const 1)
       )
      )
      (br $label)
     )
    )
   )
   (local.set $6
    (array.new_default $text
     (local.get $4)
    )
   )
   (local.set $3
    (i32.const 0)
   )
   (loop $label1
    (if
     (i32.ne
      (array.len
       (local.get $1)
      )
      (local.get $3)
     )
     (then
      (br_if $block
       (i32.eqz
        (ref.test (ref $text_object)
         (local.tee $0
          (array.get $vector
           (local.get $1)
           (local.get $3)
          )
         )
        )
       )
      )
      (array.copy $text $text
       (local.get $6)
       (local.get $5)
       (local.tee $7
        (struct.get $text_object 0
         (ref.cast (ref $text_object)
          (local.get $0)
         )
        )
       )
       (i32.const 0)
       (local.tee $4
        (array.len
         (local.get $7)
        )
       )
      )
      (local.set $5
       (i32.add
        (local.get $4)
        (local.get $5)
       )
      )
      (local.set $3
       (i32.add
        (local.get $3)
        (i32.const 1)
       )
      )
      (br $label1)
     )
    )
   )
   (return
    (struct.new $text_object
     (local.get $6)
    )
   )
  )
  (global.set $error_code
   (i32.const 8)
  )
  (drop
   (call $rust_fail
    (i32.const 8)
   )
  )
  (unreachable)
 )
 (func $primitive78 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust33
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive117 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (if (result eqref)
   (i32.eq
    (array.len
     (local.get $1)
    )
    (i32.const 1)
   )
   (then
    (array.get $vector
     (local.get $1)
     (i32.const 0)
    )
   )
   (else
    (struct.new $values
     (local.get $1)
    )
   )
  )
 )
 (func $primitive118 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (return_call $builtin:call-with-values
   (local.get $1)
   (local.get $2)
  )
 )
 (func $primitive122 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust60
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive128 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust66
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive136 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust74
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive151 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust88
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive152 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust89
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive155 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust92
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive156 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust93
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive157 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust94
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive158 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust95
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive159 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust96
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive160 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust97
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive161 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust98
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive162 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust99
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive167 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust103
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive168 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust104
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $primitive169 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $scratch eqref)
  (local.set $scratch
   (call $awi_take
    (call $rust105
     (local.tee $3
      (call $awi_root
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $3)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $3)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (table.get $awi_roots
    (local.get $3)
   )
  )
  (table.set $awi_roots
   (local.get $3)
   (ref.null none)
  )
  (array.set $text
   (global.get $awi_links)
   (local.get $3)
   (global.get $awi_free)
  )
  (global.set $awi_free
   (local.get $3)
  )
  (global.set $awi_live
   (i32.sub
    (global.get $awi_live)
    (i32.const 1)
   )
  )
  (local.get $scratch)
 )
 (func $function0 (type $12) (param $0 eqref) (result (ref $atom))
  (local $1 (ref $vector))
  (select (result (ref $atom))
   (global.get $true)
   (global.get $false)
   (ref.eq
    (block $block (result eqref)
     (if
      (i32.or
       (ref.is_null
        (local.get $0)
       )
       (ref.eq
        (local.get $0)
        (global.get $uninitialized)
       )
      )
      (then
       (global.set $error_code
        (i32.const 6)
       )
       (drop
        (call $rust_fail
         (i32.const 6)
        )
       )
       (unreachable)
      )
     )
     (if
      (ref.test (ref $values)
       (local.get $0)
      )
      (then
       (if
        (i32.ne
         (array.len
          (local.tee $1
           (struct.get $values 0
            (ref.cast (ref $values)
             (local.get $0)
            )
           )
          )
         )
         (i32.const 1)
        )
        (then
         (global.set $error_code
          (i32.const 5)
         )
         (drop
          (call $rust_fail
           (i32.const 5)
          )
         )
         (unreachable)
        )
       )
       (br $block
        (array.get $vector
         (local.get $1)
         (i32.const 0)
        )
       )
      )
     )
     (local.get $0)
    )
    (global.get $false)
   )
  )
 )
 (func $adapter0 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 1)
    )
    (i32.eqz
     (local.get $3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function0
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
  )
 )
 (func $function2 (type $result_guard_fn_0) (param $0 eqref) (result eqref)
  (local $1 (ref $vector))
  (block $block
   (return
    (struct.get $pair 0
     (ref.cast (ref $pair)
      (block $block2 (result eqref)
       (if
        (ref.test (ref $values)
         (local.tee $0
          (struct.get $pair 0
           (ref.cast (ref $pair)
            (block $block1 (result eqref)
             (if
              (i32.or
               (ref.is_null
                (local.get $0)
               )
               (ref.eq
                (local.get $0)
                (global.get $uninitialized)
               )
              )
              (then
               (global.set $error_code
                (i32.const 6)
               )
               (drop
                (call $rust_fail
                 (i32.const 6)
                )
               )
               (unreachable)
              )
             )
             (if
              (ref.test (ref $values)
               (local.get $0)
              )
              (then
               (br_if $block
                (i32.ne
                 (array.len
                  (local.tee $1
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block1
                (array.get $vector
                 (local.get $1)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $0)
            )
           )
          )
         )
        )
        (then
         (br_if $block
          (i32.ne
           (array.len
            (local.tee $1
             (struct.get $values 0
              (ref.cast (ref $values)
               (local.get $0)
              )
             )
            )
           )
           (i32.const 1)
          )
         )
         (br $block2
          (array.get $vector
           (local.get $1)
           (i32.const 0)
          )
         )
        )
       )
       (local.get $0)
      )
     )
    )
   )
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter2 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 1)
    )
    (i32.eqz
     (local.get $3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function2
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
  )
 )
 (func $function3 (type $result_guard_fn_0) (param $0 eqref) (result eqref)
  (local $1 (ref $vector))
  (block $block
   (return
    (struct.get $pair 0
     (ref.cast (ref $pair)
      (block $block2 (result eqref)
       (if
        (ref.test (ref $values)
         (local.tee $0
          (struct.get $pair 1
           (ref.cast (ref $pair)
            (block $block1 (result eqref)
             (if
              (i32.or
               (ref.is_null
                (local.get $0)
               )
               (ref.eq
                (local.get $0)
                (global.get $uninitialized)
               )
              )
              (then
               (global.set $error_code
                (i32.const 6)
               )
               (drop
                (call $rust_fail
                 (i32.const 6)
                )
               )
               (unreachable)
              )
             )
             (if
              (ref.test (ref $values)
               (local.get $0)
              )
              (then
               (br_if $block
                (i32.ne
                 (array.len
                  (local.tee $1
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block1
                (array.get $vector
                 (local.get $1)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $0)
            )
           )
          )
         )
        )
        (then
         (br_if $block
          (i32.ne
           (array.len
            (local.tee $1
             (struct.get $values 0
              (ref.cast (ref $values)
               (local.get $0)
              )
             )
            )
           )
           (i32.const 1)
          )
         )
         (br $block2
          (array.get $vector
           (local.get $1)
           (i32.const 0)
          )
         )
        )
       )
       (local.get $0)
      )
     )
    )
   )
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter3 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 1)
    )
    (i32.eqz
     (local.get $3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function3
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
  )
 )
 (func $function5 (type $result_guard_fn_0) (param $0 eqref) (result eqref)
  (local $1 (ref $vector))
  (block $block
   (return
    (struct.get $pair 1
     (ref.cast (ref $pair)
      (block $block2 (result eqref)
       (if
        (ref.test (ref $values)
         (local.tee $0
          (struct.get $pair 1
           (ref.cast (ref $pair)
            (block $block1 (result eqref)
             (if
              (i32.or
               (ref.is_null
                (local.get $0)
               )
               (ref.eq
                (local.get $0)
                (global.get $uninitialized)
               )
              )
              (then
               (global.set $error_code
                (i32.const 6)
               )
               (drop
                (call $rust_fail
                 (i32.const 6)
                )
               )
               (unreachable)
              )
             )
             (if
              (ref.test (ref $values)
               (local.get $0)
              )
              (then
               (br_if $block
                (i32.ne
                 (array.len
                  (local.tee $1
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block1
                (array.get $vector
                 (local.get $1)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $0)
            )
           )
          )
         )
        )
        (then
         (br_if $block
          (i32.ne
           (array.len
            (local.tee $1
             (struct.get $values 0
              (ref.cast (ref $values)
               (local.get $0)
              )
             )
            )
           )
           (i32.const 1)
          )
         )
         (br $block2
          (array.get $vector
           (local.get $1)
           (i32.const 0)
          )
         )
        )
       )
       (local.get $0)
      )
     )
    )
   )
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter5 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 1)
    )
    (i32.eqz
     (local.get $3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function5
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
  )
 )
 (func $function18 (type $10) (param $0 (ref $vector)) (param $1 (ref $pair)) (param $2 nullref) (result eqref)
  (local $3 eqref)
  (local $4 eqref)
  (local $5 (ref $vector))
  (local $6 (ref null $closure))
  (local $7 (ref null $vector))
  (local $8 i32)
  (block $block1
   (block $block
    (if
     (i32.or
      (i32.ne
       (local.tee $8
        (array.len
         (local.tee $0
          (array.new_fixed $vector 2
           (block $block2 (result eqref)
            (br_if $block
             (i32.or
              (ref.is_null
               (local.tee $3
                (array.get $vector
                 (local.tee $7
                  (local.get $0)
                 )
                 (i32.const 0)
                )
               )
              )
              (ref.eq
               (local.get $3)
               (global.get $uninitialized)
              )
             )
            )
            (if
             (ref.test (ref $values)
              (local.get $3)
             )
             (then
              (br_if $block1
               (i32.ne
                (array.len
                 (local.tee $5
                  (struct.get $values 0
                   (ref.cast (ref $values)
                    (local.get $3)
                   )
                  )
                 )
                )
                (i32.const 1)
               )
              )
              (br $block2
               (array.get $vector
                (local.get $5)
                (i32.const 0)
               )
              )
             )
            )
            (local.get $3)
           )
           (block (result (ref $pair))
            (br_if $block
             (ref.is_null
              (local.tee $6
               (global.get $g61)
              )
             )
            )
            (drop
             (struct.get $closure 1
              (local.get $6)
             )
            )
            (local.get $1)
           )
          )
         )
        )
       )
       (i32.const 2)
      )
      (i32.lt_u
       (local.get $8)
       (i32.const 2)
      )
     )
     (then
      (global.set $error_code
       (i32.const 4)
      )
      (drop
       (call $rust_fail
        (i32.const 4)
       )
      )
      (unreachable)
     )
    )
    (struct.set $pair 1
     (ref.cast (ref $pair)
      (array.get $vector
       (local.get $0)
       (i32.const 0)
      )
     )
     (array.get $vector
      (local.get $0)
      (i32.const 1)
     )
    )
    (local.set $3
     (block $block4 (result eqref)
      (if
       (ref.test (ref $values)
        (local.tee $3
         (struct.get $pair 1
          (ref.cast (ref $pair)
           (block $block3 (result eqref)
            (br_if $block
             (i32.or
              (ref.is_null
               (local.tee $3
                (array.get $vector
                 (local.get $7)
                 (i32.const 1)
                )
               )
              )
              (ref.eq
               (local.get $3)
               (global.get $uninitialized)
              )
             )
            )
            (if
             (ref.test (ref $values)
              (local.get $3)
             )
             (then
              (br_if $block1
               (i32.ne
                (array.len
                 (local.tee $5
                  (struct.get $values 0
                   (ref.cast (ref $values)
                    (local.get $3)
                   )
                  )
                 )
                )
                (i32.const 1)
               )
              )
              (br $block3
               (array.get $vector
                (local.get $5)
                (i32.const 0)
               )
              )
             )
            )
            (local.get $3)
           )
          )
         )
        )
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $5
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $3)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block4
         (array.get $vector
          (local.get $5)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (br_if $block
     (ref.is_null
      (local.tee $6
       (global.get $g190)
      )
     )
    )
    (drop
     (ref.as_non_null
      (local.get $6)
     )
    )
    (return
     (if (result (ref $pair))
      (if (result i32)
       (ref.eq
        (local.tee $4
         (block $block5 (result eqref)
          (br_if $block
           (i32.or
            (ref.is_null
             (local.get $3)
            )
            (ref.eq
             (local.get $3)
             (global.get $uninitialized)
            )
           )
          )
          (if
           (ref.test (ref $values)
            (local.get $3)
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $5
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $3)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block5
             (array.get $vector
              (local.get $5)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $3)
         )
        )
        (global.get $nil)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (if (result i32)
          (ref.test (ref $atom)
           (local.get $4)
          )
          (then
           (i32.lt_s
            (struct.get $atom 0
             (ref.cast (ref $atom)
              (local.get $4)
             )
            )
            (i32.const 0)
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (i32.const 0)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (return_call $function18
        (array.new_fixed $vector 2
         (local.get $1)
         (local.get $3)
        )
        (struct.new $pair
         (block $block7 (result eqref)
          (if
           (ref.test (ref $values)
            (local.tee $3
             (struct.get $pair 0
              (ref.cast (ref $pair)
               (block $block6 (result eqref)
                (br_if $block
                 (i32.or
                  (ref.is_null
                   (local.get $3)
                  )
                  (ref.eq
                   (local.get $3)
                   (global.get $uninitialized)
                  )
                 )
                )
                (if
                 (ref.test (ref $values)
                  (local.get $3)
                 )
                 (then
                  (br_if $block1
                   (i32.ne
                    (array.len
                     (local.tee $5
                      (struct.get $values 0
                       (ref.cast (ref $values)
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (i32.const 1)
                   )
                  )
                  (br $block6
                   (array.get $vector
                    (local.get $5)
                    (i32.const 0)
                   )
                  )
                 )
                )
                (local.get $3)
               )
              )
             )
            )
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $5
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $3)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block7
             (array.get $vector
              (local.get $5)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $3)
         )
         (global.get $nil)
        )
        (local.get $2)
       )
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter17 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 eqref)
  (local $4 eqref)
  (local $5 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $5
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $5)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (local.set $3
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
  )
  (block $block1
   (block $block
    (return
     (if (result eqref)
      (if (result i32)
       (ref.eq
        (local.tee $4
         (block $block2 (result eqref)
          (br_if $block
           (i32.or
            (ref.is_null
             (local.tee $0
              (array.get $vector
               (local.get $1)
               (i32.const 0)
              )
             )
            )
            (ref.eq
             (local.get $0)
             (global.get $uninitialized)
            )
           )
          )
          (if
           (ref.test (ref $values)
            (local.get $0)
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $1
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block2
             (array.get $vector
              (local.get $1)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $0)
         )
        )
        (global.get $nil)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (if (result i32)
          (ref.test (ref $atom)
           (local.get $4)
          )
          (then
           (i32.lt_s
            (struct.get $atom 0
             (ref.cast (ref $atom)
              (local.get $4)
             )
            )
            (i32.const 0)
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (i32.const 0)
       )
      )
      (then
       (br_if $block
        (i32.or
         (ref.is_null
          (local.get $3)
         )
         (ref.eq
          (local.get $3)
          (global.get $uninitialized)
         )
        )
       )
       (local.get $3)
      )
      (else
       (return_call $function18
        (array.new_fixed $vector 2
         (local.get $3)
         (local.get $0)
        )
        (struct.new $pair
         (block $block4 (result eqref)
          (if
           (ref.test (ref $values)
            (local.tee $0
             (struct.get $pair 0
              (ref.cast (ref $pair)
               (block $block3 (result eqref)
                (br_if $block
                 (i32.or
                  (ref.is_null
                   (local.get $0)
                  )
                  (ref.eq
                   (local.get $0)
                   (global.get $uninitialized)
                  )
                 )
                )
                (if
                 (ref.test (ref $values)
                  (local.get $0)
                 )
                 (then
                  (br_if $block1
                   (i32.ne
                    (array.len
                     (local.tee $1
                      (struct.get $values 0
                       (ref.cast (ref $values)
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (i32.const 1)
                   )
                  )
                  (br $block3
                   (array.get $vector
                    (local.get $1)
                    (i32.const 0)
                   )
                  )
                 )
                )
                (local.get $0)
               )
              )
             )
            )
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $1
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block4
             (array.get $vector
              (local.get $1)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $0)
         )
         (global.get $nil)
        )
        (local.get $2)
       )
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $function22 (type $9) (param $0 eqref) (param $1 eqref) (param $2 nullref) (result eqref)
  (local $3 (ref $vector))
  (local $4 eqref)
  (local $5 (ref null $closure))
  (local $6 (ref i31))
  (local $7 (ref $atom))
  (local $8 i32)
  (local $scratch (ref $atom))
  (block $block1
   (block $block
    (drop
     (if (result (ref null $atom))
      (ref.eq
       (call $function0
        (block (result (ref $atom))
         (local.set $scratch
          (if (result (ref $atom))
           (i32.or
            (ref.test (ref i31)
             (local.tee $4
              (block $block2 (result eqref)
               (br_if $block
                (i32.or
                 (ref.is_null
                  (local.get $1)
                 )
                 (ref.eq
                  (local.get $1)
                  (global.get $uninitialized)
                 )
                )
               )
               (if
                (ref.test (ref $values)
                 (local.get $1)
                )
                (then
                 (br_if $block1
                  (i32.ne
                   (array.len
                    (local.tee $3
                     (struct.get $values 0
                      (ref.cast (ref $values)
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (br $block2
                  (array.get $vector
                   (local.get $3)
                   (i32.const 0)
                  )
                 )
                )
               )
               (local.get $1)
              )
             )
            )
            (ref.test (ref $integer)
             (local.get $4)
            )
           )
           (then
            (select (result (ref $atom))
             (global.get $true)
             (global.get $false)
             (if (result i32)
              (ref.test (ref i31)
               (local.tee $4
                (block $block3 (result eqref)
                 (br_if $block
                  (i32.or
                   (ref.is_null
                    (local.get $1)
                   )
                   (ref.eq
                    (local.get $1)
                    (global.get $uninitialized)
                   )
                  )
                 )
                 (if
                  (ref.test (ref $values)
                   (local.get $1)
                  )
                  (then
                   (br_if $block1
                    (i32.ne
                     (array.len
                      (local.tee $3
                       (struct.get $values 0
                        (ref.cast (ref $values)
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (br $block3
                    (array.get $vector
                     (local.get $3)
                     (i32.const 0)
                    )
                   )
                  )
                 )
                 (local.get $1)
                )
               )
              )
              (then
               (i32.ge_s
                (i31.get_s
                 (ref.cast (ref i31)
                  (local.get $4)
                 )
                )
                (i32.const 0)
               )
              )
              (else
               (i64.ge_s
                (if (result i64)
                 (ref.test (ref i31)
                  (local.get $4)
                 )
                 (then
                  (i64.extend_i32_s
                   (i31.get_s
                    (ref.cast (ref i31)
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (else
                  (struct.get $integer 0
                   (ref.cast (ref $integer)
                    (local.get $4)
                   )
                  )
                 )
                )
                (i64.const 0)
               )
              )
             )
            )
           )
           (else
            (global.get $false)
           )
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g181)
           )
          )
         )
         (drop
          (ref.as_non_null
           (local.get $5)
          )
         )
         (local.get $scratch)
        )
       )
       (global.get $false)
      )
      (then
       (global.get $unspecified)
      )
      (else
       (local.set $4
        (block $block4 (result eqref)
         (br_if $block
          (i32.or
           (ref.is_null
            (local.get $1)
           )
           (ref.eq
            (local.get $1)
            (global.get $uninitialized)
           )
          )
         )
         (if
          (ref.test (ref $values)
           (local.get $1)
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $3
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $1)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block4
            (array.get $vector
             (local.get $3)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $1)
        )
       )
       (br_if $block
        (ref.is_null
         (local.tee $5
          (global.get $g122)
         )
        )
       )
       (drop
        (struct.get $closure 1
         (local.get $5)
        )
       )
       (drop
        (call $awi_take
         (call $rust60
          (local.tee $8
           (call $awi_root
            (array.new_fixed $vector 2
             (global.get $literal0)
             (local.get $4)
            )
           )
          )
         )
        )
       )
       (if
        (i32.ge_u
         (local.get $8)
         (global.get $awi_used)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.ne
         (array.get $text
          (global.get $awi_links)
          (local.get $8)
         )
         (i32.const -1)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (table.get $awi_roots
         (local.get $8)
        )
       )
       (table.set $awi_roots
        (local.get $8)
        (ref.null none)
       )
       (array.set $text
        (global.get $awi_links)
        (local.get $8)
        (global.get $awi_free)
       )
       (global.set $awi_free
        (local.get $8)
       )
       (global.set $awi_live
        (i32.sub
         (global.get $awi_live)
         (i32.const 1)
        )
       )
       (ref.null none)
      )
     )
    )
    (return
     (if (result eqref)
      (ref.eq
       (call $numeric_equal
        (block $block5 (result eqref)
         (br_if $block
          (i32.or
           (ref.is_null
            (local.get $1)
           )
           (ref.eq
            (local.get $1)
            (global.get $uninitialized)
           )
          )
         )
         (if
          (ref.test (ref $values)
           (local.get $1)
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $3
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $1)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block5
            (array.get $vector
             (local.get $3)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $1)
        )
        (ref.i31
         (i32.const 0)
        )
       )
       (global.get $false)
      )
      (then
       (return_call $function22
        (block $block7 (result eqref)
         (if
          (ref.test (ref $values)
           (local.tee $0
            (struct.get $pair 1
             (ref.cast (ref $pair)
              (block $block6 (result eqref)
               (br_if $block
                (i32.or
                 (ref.is_null
                  (local.get $0)
                 )
                 (ref.eq
                  (local.get $0)
                  (global.get $uninitialized)
                 )
                )
               )
               (if
                (ref.test (ref $values)
                 (local.get $0)
                )
                (then
                 (br_if $block1
                  (i32.ne
                   (array.len
                    (local.tee $3
                     (struct.get $values 0
                      (ref.cast (ref $values)
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (br $block6
                  (array.get $vector
                   (local.get $3)
                   (i32.const 0)
                  )
                 )
                )
               )
               (local.get $0)
              )
             )
            )
           )
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $3
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $0)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block7
            (array.get $vector
             (local.get $3)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $0)
        )
        (block (result eqref)
         (local.set $6
          (ref.i31
           (i32.const 1)
          )
         )
         (if (result eqref)
          (ref.test (ref i31)
           (local.tee $0
            (block $block8 (result eqref)
             (br_if $block
              (i32.or
               (ref.is_null
                (local.get $1)
               )
               (ref.eq
                (local.get $1)
                (global.get $uninitialized)
               )
              )
             )
             (if
              (ref.test (ref $values)
               (local.get $1)
              )
              (then
               (br_if $block1
                (i32.ne
                 (array.len
                  (local.tee $3
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block8
                (array.get $vector
                 (local.get $3)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $1)
            )
           )
          )
          (then
           (if (result eqref)
            (i32.le_u
             (i32.add
              (local.tee $8
               (i32.sub
                (i31.get_s
                 (ref.cast (ref i31)
                  (local.get $0)
                 )
                )
                (i32.const 1)
               )
              )
              (i32.const 1073741824)
             )
             (i32.const 2147483647)
            )
            (then
             (ref.i31
              (local.get $8)
             )
            )
            (else
             (call $cold.checked_subtract
              (local.get $0)
              (local.get $6)
             )
            )
           )
          )
          (else
           (call $cold.checked_subtract
            (local.get $0)
            (local.get $6)
           )
          )
         )
        )
        (block (result nullref)
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g192)
           )
          )
         )
         (drop
          (ref.as_non_null
           (local.get $5)
          )
         )
         (local.get $2)
        )
       )
      )
      (else
       (br_if $block
        (i32.or
         (ref.is_null
          (local.get $0)
         )
         (ref.eq
          (local.get $0)
          (global.get $uninitialized)
         )
        )
       )
       (local.get $0)
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter22 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function22
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
   (local.get $2)
  )
 )
 (func $function28 (type $8) (param $0 eqref) (param $1 eqref) (param $2 eqref) (param $3 nullref) (result eqref)
  (local $4 (ref $vector))
  (local $5 eqref)
  (local $6 eqref)
  (local $7 (ref $closure))
  (local $8 (ref null $closure))
  (block $block1
   (block $block
    (return
     (if (result eqref)
      (if (result i32)
       (ref.eq
        (local.tee $5
         (block $block2 (result eqref)
          (br_if $block
           (i32.or
            (ref.is_null
             (local.get $2)
            )
            (ref.eq
             (local.get $2)
             (global.get $uninitialized)
            )
           )
          )
          (if
           (ref.test (ref $values)
            (local.get $2)
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $4
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $2)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block2
             (array.get $vector
              (local.get $4)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $2)
         )
        )
        (global.get $nil)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (if (result i32)
          (ref.test (ref $atom)
           (local.get $5)
          )
          (then
           (i32.lt_s
            (struct.get $atom 0
             (ref.cast (ref $atom)
              (local.get $5)
             )
            )
            (i32.const 0)
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (i32.const 0)
       )
      )
      (then
       (global.get $false)
      )
      (else
       (local.set $6
        (block $block3 (result eqref)
         (br_if $block
          (i32.or
           (ref.is_null
            (local.get $1)
           )
           (ref.eq
            (local.get $1)
            (global.get $uninitialized)
           )
          )
         )
         (if
          (ref.test (ref $values)
           (local.get $1)
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $4
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $1)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block3
            (array.get $vector
             (local.get $4)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $1)
        )
       )
       (local.set $5
        (block $block5 (result eqref)
         (if
          (ref.test (ref $values)
           (local.tee $5
            (struct.get $pair 0
             (ref.cast (ref $pair)
              (block $block4 (result eqref)
               (br_if $block
                (i32.or
                 (ref.is_null
                  (local.get $2)
                 )
                 (ref.eq
                  (local.get $2)
                  (global.get $uninitialized)
                 )
                )
               )
               (if
                (ref.test (ref $values)
                 (local.get $2)
                )
                (then
                 (br_if $block1
                  (i32.ne
                   (array.len
                    (local.tee $4
                     (struct.get $values 0
                      (ref.cast (ref $values)
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (br $block4
                  (array.get $vector
                   (local.get $4)
                   (i32.const 0)
                  )
                 )
                )
               )
               (local.get $2)
              )
             )
            )
           )
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $4
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $5)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block5
            (array.get $vector
             (local.get $4)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $5)
        )
       )
       (if (result eqref)
        (ref.eq
         (block $block7 (result eqref)
          (if
           (ref.test (ref $values)
            (local.tee $5
             (call_ref $call
              (struct.get $closure 1
               (local.tee $7
                (ref.cast (ref $closure)
                 (block $block6 (result eqref)
                  (br_if $block
                   (i32.or
                    (ref.is_null
                     (local.get $0)
                    )
                    (ref.eq
                     (local.get $0)
                     (global.get $uninitialized)
                    )
                   )
                  )
                  (if
                   (ref.test (ref $values)
                    (local.get $0)
                   )
                   (then
                    (br_if $block1
                     (i32.ne
                      (array.len
                       (local.tee $4
                        (struct.get $values 0
                         (ref.cast (ref $values)
                          (local.get $0)
                         )
                        )
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (br $block6
                     (array.get $vector
                      (local.get $4)
                      (i32.const 0)
                     )
                    )
                   )
                  )
                  (local.get $0)
                 )
                )
               )
              )
              (array.new_fixed $vector 2
               (local.get $6)
               (local.get $5)
              )
              (ref.null none)
              (struct.get $closure 0
               (local.get $7)
              )
             )
            )
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $4
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $5)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block7
             (array.get $vector
              (local.get $4)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $5)
         )
         (global.get $false)
        )
        (then
         (return_call $function28
          (block $block8 (result eqref)
           (br_if $block
            (i32.or
             (ref.is_null
              (local.get $0)
             )
             (ref.eq
              (local.get $0)
              (global.get $uninitialized)
             )
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $0)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $4
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $0)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block8
              (array.get $vector
               (local.get $4)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $0)
          )
          (block $block9 (result eqref)
           (br_if $block
            (i32.or
             (ref.is_null
              (local.get $1)
             )
             (ref.eq
              (local.get $1)
              (global.get $uninitialized)
             )
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $1)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $4
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $1)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block9
              (array.get $vector
               (local.get $4)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $1)
          )
          (block $block11 (result eqref)
           (if
            (ref.test (ref $values)
             (local.tee $0
              (struct.get $pair 1
               (ref.cast (ref $pair)
                (block $block10 (result eqref)
                 (br_if $block
                  (i32.or
                   (ref.is_null
                    (local.get $2)
                   )
                   (ref.eq
                    (local.get $2)
                    (global.get $uninitialized)
                   )
                  )
                 )
                 (if
                  (ref.test (ref $values)
                   (local.get $2)
                  )
                  (then
                   (br_if $block1
                    (i32.ne
                     (array.len
                      (local.tee $4
                       (struct.get $values 0
                        (ref.cast (ref $values)
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (br $block10
                    (array.get $vector
                     (local.get $4)
                     (i32.const 0)
                    )
                   )
                  )
                 )
                 (local.get $2)
                )
               )
              )
             )
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $4
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $0)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block11
              (array.get $vector
               (local.get $4)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $0)
          )
          (block (result nullref)
           (br_if $block
            (ref.is_null
             (local.tee $8
              (global.get $g195)
             )
            )
           )
           (drop
            (ref.as_non_null
             (local.get $8)
            )
           )
           (local.get $3)
          )
         )
        )
        (else
         (br_if $block
          (i32.or
           (ref.is_null
            (local.get $2)
           )
           (ref.eq
            (local.get $2)
            (global.get $uninitialized)
           )
          )
         )
         (local.get $2)
        )
       )
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter28 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 3)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function28
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 2)
   )
   (local.get $2)
  )
 )
 (func $adapter31 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 eqref)
  (local $4 (ref null $closure))
  (local $5 (ref null $closure))
  (local $6 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $6
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $6)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (local.set $0
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
  )
  (local.set $3
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (ref.is_null
      (local.tee $4
       (global.get $g42)
      )
     )
    )
    (local.set $0
     (block $block2 (result eqref)
      (br_if $block
       (i32.or
        (ref.is_null
         (local.get $0)
        )
        (ref.eq
         (local.get $0)
         (global.get $uninitialized)
        )
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $0)
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $1
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $0)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block2
         (array.get $vector
          (local.get $1)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $0)
     )
    )
    (local.set $3
     (block $block3 (result eqref)
      (br_if $block
       (i32.or
        (ref.is_null
         (local.get $3)
        )
        (ref.eq
         (local.get $3)
         (global.get $uninitialized)
        )
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $3)
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $1
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $3)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block3
         (array.get $vector
          (local.get $1)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (br_if $block
     (ref.is_null
      (local.tee $5
       (global.get $g195)
      )
     )
    )
    (drop
     (ref.as_non_null
      (local.get $5)
     )
    )
    (return_call $function28
     (local.get $4)
     (local.get $0)
     (local.get $3)
     (local.get $2)
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $function32 (type $8) (param $0 eqref) (param $1 eqref) (param $2 eqref) (param $3 nullref) (result eqref)
  (local $4 (ref $vector))
  (local $5 eqref)
  (local $6 eqref)
  (local $7 (ref null $closure))
  (local $8 (ref $closure))
  (block $block1
   (block $block
    (return
     (if (result eqref)
      (if (result i32)
       (ref.eq
        (local.tee $5
         (block $block2 (result eqref)
          (br_if $block
           (i32.or
            (ref.is_null
             (local.get $2)
            )
            (ref.eq
             (local.get $2)
             (global.get $uninitialized)
            )
           )
          )
          (if
           (ref.test (ref $values)
            (local.get $2)
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $4
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $2)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block2
             (array.get $vector
              (local.get $4)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $2)
         )
        )
        (global.get $nil)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (if (result i32)
          (ref.test (ref $atom)
           (local.get $5)
          )
          (then
           (i32.lt_s
            (struct.get $atom 0
             (ref.cast (ref $atom)
              (local.get $5)
             )
            )
            (i32.const 0)
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (i32.const 0)
       )
      )
      (then
       (global.get $false)
      )
      (else
       (local.set $6
        (block $block3 (result eqref)
         (br_if $block
          (i32.or
           (ref.is_null
            (local.get $1)
           )
           (ref.eq
            (local.get $1)
            (global.get $uninitialized)
           )
          )
         )
         (if
          (ref.test (ref $values)
           (local.get $1)
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $4
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $1)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block3
            (array.get $vector
             (local.get $4)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $1)
        )
       )
       (local.set $5
        (block $block4 (result eqref)
         (br_if $block
          (i32.or
           (ref.is_null
            (local.get $2)
           )
           (ref.eq
            (local.get $2)
            (global.get $uninitialized)
           )
          )
         )
         (if
          (ref.test (ref $values)
           (local.get $2)
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $4
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $2)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block4
            (array.get $vector
             (local.get $4)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $2)
        )
       )
       (br_if $block
        (ref.is_null
         (local.tee $7
          (global.get $g183)
         )
        )
       )
       (drop
        (ref.as_non_null
         (local.get $7)
        )
       )
       (local.set $5
        (block $block5 (result eqref)
         (if
          (ref.test (ref $values)
           (local.tee $5
            (call $function2
             (local.get $5)
            )
           )
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $4
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $5)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block5
            (array.get $vector
             (local.get $4)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $5)
        )
       )
       (if (result eqref)
        (ref.eq
         (block $block7 (result eqref)
          (if
           (ref.test (ref $values)
            (local.tee $5
             (call_ref $call
              (struct.get $closure 1
               (local.tee $8
                (ref.cast (ref $closure)
                 (block $block6 (result eqref)
                  (br_if $block
                   (i32.or
                    (ref.is_null
                     (local.get $0)
                    )
                    (ref.eq
                     (local.get $0)
                     (global.get $uninitialized)
                    )
                   )
                  )
                  (if
                   (ref.test (ref $values)
                    (local.get $0)
                   )
                   (then
                    (br_if $block1
                     (i32.ne
                      (array.len
                       (local.tee $4
                        (struct.get $values 0
                         (ref.cast (ref $values)
                          (local.get $0)
                         )
                        )
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (br $block6
                     (array.get $vector
                      (local.get $4)
                      (i32.const 0)
                     )
                    )
                   )
                  )
                  (local.get $0)
                 )
                )
               )
              )
              (array.new_fixed $vector 2
               (local.get $6)
               (local.get $5)
              )
              (ref.null none)
              (struct.get $closure 0
               (local.get $8)
              )
             )
            )
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $4
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $5)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block7
             (array.get $vector
              (local.get $4)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $5)
         )
         (global.get $false)
        )
        (then
         (return_call $function32
          (block $block8 (result eqref)
           (br_if $block
            (i32.or
             (ref.is_null
              (local.get $0)
             )
             (ref.eq
              (local.get $0)
              (global.get $uninitialized)
             )
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $0)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $4
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $0)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block8
              (array.get $vector
               (local.get $4)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $0)
          )
          (block $block9 (result eqref)
           (br_if $block
            (i32.or
             (ref.is_null
              (local.get $1)
             )
             (ref.eq
              (local.get $1)
              (global.get $uninitialized)
             )
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $1)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $4
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $1)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block9
              (array.get $vector
               (local.get $4)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $1)
          )
          (block $block11 (result eqref)
           (if
            (ref.test (ref $values)
             (local.tee $0
              (struct.get $pair 1
               (ref.cast (ref $pair)
                (block $block10 (result eqref)
                 (br_if $block
                  (i32.or
                   (ref.is_null
                    (local.get $2)
                   )
                   (ref.eq
                    (local.get $2)
                    (global.get $uninitialized)
                   )
                  )
                 )
                 (if
                  (ref.test (ref $values)
                   (local.get $2)
                  )
                  (then
                   (br_if $block1
                    (i32.ne
                     (array.len
                      (local.tee $4
                       (struct.get $values 0
                        (ref.cast (ref $values)
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (br $block10
                    (array.get $vector
                     (local.get $4)
                     (i32.const 0)
                    )
                   )
                  )
                 )
                 (local.get $2)
                )
               )
              )
             )
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $4
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $0)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block11
              (array.get $vector
               (local.get $4)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $0)
          )
          (block (result nullref)
           (br_if $block
            (ref.is_null
             (local.tee $7
              (global.get $g199)
             )
            )
           )
           (drop
            (ref.as_non_null
             (local.get $7)
            )
           )
           (local.get $3)
          )
         )
        )
        (else
         (struct.get $pair 0
          (ref.cast (ref $pair)
           (block $block12 (result eqref)
            (br_if $block
             (i32.or
              (ref.is_null
               (local.get $2)
              )
              (ref.eq
               (local.get $2)
               (global.get $uninitialized)
              )
             )
            )
            (if
             (ref.test (ref $values)
              (local.get $2)
             )
             (then
              (br_if $block1
               (i32.ne
                (array.len
                 (local.tee $4
                  (struct.get $values 0
                   (ref.cast (ref $values)
                    (local.get $2)
                   )
                  )
                 )
                )
                (i32.const 1)
               )
              )
              (br $block12
               (array.get $vector
                (local.get $4)
                (i32.const 0)
               )
              )
             )
            )
            (local.get $2)
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter32 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 3)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function32
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 2)
   )
   (local.get $2)
  )
 )
 (func $function37 (type $7) (param $0 (ref $vector)) (param $1 (ref $atom)) (param $2 nullref) (result eqref)
  (local $3 eqref)
  (local $4 (ref $vector))
  (local $5 (ref null $closure))
  (block $block1
   (block $block
    (br_if $block
     (ref.eq
      (local.get $1)
      (global.get $uninitialized)
     )
    )
    (return
     (if (result (ref $atom))
      (ref.eq
       (local.get $1)
       (global.get $false)
      )
      (then
       (local.set $3
        (block $block3 (result eqref)
         (if
          (ref.test (ref $values)
           (local.tee $3
            (struct.get $pair 1
             (ref.cast (ref $pair)
              (block $block2 (result eqref)
               (br_if $block
                (i32.or
                 (ref.is_null
                  (local.tee $3
                   (array.get $vector
                    (local.get $0)
                    (i32.const 0)
                   )
                  )
                 )
                 (ref.eq
                  (local.get $3)
                  (global.get $uninitialized)
                 )
                )
               )
               (if
                (ref.test (ref $values)
                 (local.get $3)
                )
                (then
                 (br_if $block1
                  (i32.ne
                   (array.len
                    (local.tee $4
                     (struct.get $values 0
                      (ref.cast (ref $values)
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (br $block2
                  (array.get $vector
                   (local.get $4)
                   (i32.const 0)
                  )
                 )
                )
               )
               (local.get $3)
              )
             )
            )
           )
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $4
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $3)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block3
            (array.get $vector
             (local.get $4)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $3)
        )
       )
       (br_if $block
        (ref.is_null
         (local.tee $5
          (global.get $g203)
         )
        )
       )
       (drop
        (ref.as_non_null
         (local.get $5)
        )
       )
       (if (result (ref $atom))
        (ref.test (ref $pair)
         (block $block4 (result eqref)
          (br_if $block
           (i32.or
            (ref.is_null
             (local.get $3)
            )
            (ref.eq
             (local.get $3)
             (global.get $uninitialized)
            )
           )
          )
          (if
           (ref.test (ref $values)
            (local.get $3)
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $4
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $3)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block4
             (array.get $vector
              (local.get $4)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $3)
         )
        )
        (then
         (return_call $function37
          (array.new_fixed $vector 1
           (local.get $3)
          )
          (select (result (ref $atom))
           (global.get $true)
           (global.get $false)
           (if (result i32)
            (ref.eq
             (local.tee $3
              (block $block6 (result eqref)
               (if
                (ref.test (ref $values)
                 (local.tee $3
                  (struct.get $pair 0
                   (ref.cast (ref $pair)
                    (block $block5 (result eqref)
                     (br_if $block
                      (i32.or
                       (ref.is_null
                        (local.get $3)
                       )
                       (ref.eq
                        (local.get $3)
                        (global.get $uninitialized)
                       )
                      )
                     )
                     (if
                      (ref.test (ref $values)
                       (local.get $3)
                      )
                      (then
                       (br_if $block1
                        (i32.ne
                         (array.len
                          (local.tee $4
                           (struct.get $values 0
                            (ref.cast (ref $values)
                             (local.get $3)
                            )
                           )
                          )
                         )
                         (i32.const 1)
                        )
                       )
                       (br $block5
                        (array.get $vector
                         (local.get $4)
                         (i32.const 0)
                        )
                       )
                      )
                     )
                     (local.get $3)
                    )
                   )
                  )
                 )
                )
                (then
                 (br_if $block1
                  (i32.ne
                   (array.len
                    (local.tee $4
                     (struct.get $values 0
                      (ref.cast (ref $values)
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (br $block6
                  (array.get $vector
                   (local.get $4)
                   (i32.const 0)
                  )
                 )
                )
               )
               (local.get $3)
              )
             )
             (global.get $nil)
            )
            (then
             (i32.const 1)
            )
            (else
             (drop
              (if (result i32)
               (ref.test (ref $atom)
                (local.get $3)
               )
               (then
                (i32.lt_s
                 (struct.get $atom 0
                  (ref.cast (ref $atom)
                   (local.get $3)
                  )
                 )
                 (i32.const 0)
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
             (i32.const 0)
            )
           )
          )
          (local.get $2)
         )
        )
        (else
         (global.get $false)
        )
       )
      )
      (else
       (br_if $block
        (ref.eq
         (local.get $1)
         (global.get $uninitialized)
        )
       )
       (local.get $1)
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter36 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 1)
    )
    (i32.eqz
     (local.get $3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (block $block1
   (block $block
    (return
     (if (result (ref $atom))
      (ref.test (ref $pair)
       (block $block2 (result eqref)
        (br_if $block
         (i32.or
          (ref.is_null
           (local.tee $0
            (array.get $vector
             (local.get $1)
             (i32.const 0)
            )
           )
          )
          (ref.eq
           (local.get $0)
           (global.get $uninitialized)
          )
         )
        )
        (if
         (ref.test (ref $values)
          (local.get $0)
         )
         (then
          (br_if $block1
           (i32.ne
            (array.len
             (local.tee $1
              (struct.get $values 0
               (ref.cast (ref $values)
                (local.get $0)
               )
              )
             )
            )
            (i32.const 1)
           )
          )
          (br $block2
           (array.get $vector
            (local.get $1)
            (i32.const 0)
           )
          )
         )
        )
        (local.get $0)
       )
      )
      (then
       (return_call $function37
        (array.new_fixed $vector 1
         (local.get $0)
        )
        (select (result (ref $atom))
         (global.get $true)
         (global.get $false)
         (if (result i32)
          (ref.eq
           (local.tee $0
            (block $block4 (result eqref)
             (if
              (ref.test (ref $values)
               (local.tee $0
                (struct.get $pair 0
                 (ref.cast (ref $pair)
                  (block $block3 (result eqref)
                   (br_if $block
                    (i32.or
                     (ref.is_null
                      (local.get $0)
                     )
                     (ref.eq
                      (local.get $0)
                      (global.get $uninitialized)
                     )
                    )
                   )
                   (if
                    (ref.test (ref $values)
                     (local.get $0)
                    )
                    (then
                     (br_if $block1
                      (i32.ne
                       (array.len
                        (local.tee $1
                         (struct.get $values 0
                          (ref.cast (ref $values)
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (i32.const 1)
                      )
                     )
                     (br $block3
                      (array.get $vector
                       (local.get $1)
                       (i32.const 0)
                      )
                     )
                    )
                   )
                   (local.get $0)
                  )
                 )
                )
               )
              )
              (then
               (br_if $block1
                (i32.ne
                 (array.len
                  (local.tee $1
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block4
                (array.get $vector
                 (local.get $1)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $0)
            )
           )
           (global.get $nil)
          )
          (then
           (i32.const 1)
          )
          (else
           (drop
            (if (result i32)
             (ref.test (ref $atom)
              (local.get $0)
             )
             (then
              (i32.lt_s
               (struct.get $atom 0
                (ref.cast (ref $atom)
                 (local.get $0)
                )
               )
               (i32.const 0)
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
           (i32.const 0)
          )
         )
        )
        (local.get $2)
       )
      )
      (else
       (global.get $false)
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $function38 (type $6) (param $0 eqref) (param $1 eqref) (result (ref struct))
  (local $2 (ref $vector))
  (local $3 eqref)
  (local $4 (ref struct))
  (local $5 (ref $closure))
  (local $6 (ref null $closure))
  (block $block1
   (block $block
    (return
     (if (result (ref struct))
      (if (result i32)
       (ref.eq
        (local.tee $3
         (block $block2 (result eqref)
          (br_if $block
           (i32.or
            (ref.is_null
             (local.get $1)
            )
            (ref.eq
             (local.get $1)
             (global.get $uninitialized)
            )
           )
          )
          (if
           (ref.test (ref $values)
            (local.get $1)
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $2
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $1)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block2
             (array.get $vector
              (local.get $2)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $1)
         )
        )
        (global.get $nil)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (if (result i32)
          (ref.test (ref $atom)
           (local.get $3)
          )
          (then
           (i32.lt_s
            (struct.get $atom 0
             (ref.cast (ref $atom)
              (local.get $3)
             )
            )
            (i32.const 0)
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (i32.const 0)
       )
      )
      (then
       (global.get $nil)
      )
      (else
       (local.set $3
        (block $block4 (result eqref)
         (if
          (ref.test (ref $values)
           (local.tee $3
            (struct.get $pair 0
             (ref.cast (ref $pair)
              (block $block3 (result eqref)
               (br_if $block
                (i32.or
                 (ref.is_null
                  (local.get $1)
                 )
                 (ref.eq
                  (local.get $1)
                  (global.get $uninitialized)
                 )
                )
               )
               (if
                (ref.test (ref $values)
                 (local.get $1)
                )
                (then
                 (br_if $block1
                  (i32.ne
                   (array.len
                    (local.tee $2
                     (struct.get $values 0
                      (ref.cast (ref $values)
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (br $block3
                  (array.get $vector
                   (local.get $2)
                   (i32.const 0)
                  )
                 )
                )
               )
               (local.get $1)
              )
             )
            )
           )
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $2
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $3)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block4
            (array.get $vector
             (local.get $2)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $3)
        )
       )
       (struct.new $pair
        (block $block6 (result eqref)
         (if
          (ref.test (ref $values)
           (local.tee $3
            (call_ref $call
             (struct.get $closure 1
              (local.tee $5
               (ref.cast (ref $closure)
                (block $block5 (result eqref)
                 (br_if $block
                  (i32.or
                   (ref.is_null
                    (local.get $0)
                   )
                   (ref.eq
                    (local.get $0)
                    (global.get $uninitialized)
                   )
                  )
                 )
                 (if
                  (ref.test (ref $values)
                   (local.get $0)
                  )
                  (then
                   (br_if $block1
                    (i32.ne
                     (array.len
                      (local.tee $2
                       (struct.get $values 0
                        (ref.cast (ref $values)
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (br $block5
                    (array.get $vector
                     (local.get $2)
                     (i32.const 0)
                    )
                   )
                  )
                 )
                 (local.get $0)
                )
               )
              )
             )
             (array.new_fixed $vector 1
              (local.get $3)
             )
             (ref.null none)
             (struct.get $closure 0
              (local.get $5)
             )
            )
           )
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $2
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $3)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block6
            (array.get $vector
             (local.get $2)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $3)
        )
        (block (result eqref)
         (local.set $3
          (block $block7 (result eqref)
           (br_if $block
            (i32.or
             (ref.is_null
              (local.get $0)
             )
             (ref.eq
              (local.get $0)
              (global.get $uninitialized)
             )
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $0)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $2
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $0)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block7
              (array.get $vector
               (local.get $2)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $0)
          )
         )
         (local.set $0
          (block $block9 (result eqref)
           (if
            (ref.test (ref $values)
             (local.tee $0
              (struct.get $pair 1
               (ref.cast (ref $pair)
                (block $block8 (result eqref)
                 (br_if $block
                  (i32.or
                   (ref.is_null
                    (local.get $1)
                   )
                   (ref.eq
                    (local.get $1)
                    (global.get $uninitialized)
                   )
                  )
                 )
                 (if
                  (ref.test (ref $values)
                   (local.get $1)
                  )
                  (then
                   (br_if $block1
                    (i32.ne
                     (array.len
                      (local.tee $2
                       (struct.get $values 0
                        (ref.cast (ref $values)
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (br $block8
                    (array.get $vector
                     (local.get $2)
                     (i32.const 0)
                    )
                   )
                  )
                 )
                 (local.get $1)
                )
               )
              )
             )
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $2
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $0)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block9
              (array.get $vector
               (local.get $2)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $0)
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $6
            (global.get $g204)
           )
          )
         )
         (drop
          (ref.as_non_null
           (local.get $6)
          )
         )
         (block $block10 (result eqref)
          (if
           (ref.test (ref $values)
            (local.tee $4
             (call $function38
              (local.get $3)
              (local.get $0)
             )
            )
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $2
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $4)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block10
             (array.get $vector
              (local.get $2)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $4)
         )
        )
       )
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter38 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function38
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
  )
 )
 (func $adapter99 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 eqref)
  (local $4 eqref)
  (local $5 eqref)
  (local $6 (ref struct))
  (local $7 (ref null $closure))
  (local $8 (ref null $closure))
  (local $9 (ref $closure))
  (local $10 (ref null $vector))
  (local $11 (ref null $pair))
  (local $12 i32)
  (local $scratch eqref)
  (local $scratch_14 eqref)
  (local.set $12
   (array.len
    (local.get $1)
   )
  )
  (local.set $6
   (global.get $nil)
  )
  (loop $label
   (if
    (local.get $12)
    (then
     (local.set $6
      (struct.new $pair
       (array.get $vector
        (local.get $1)
        (local.tee $12
         (i32.sub
          (local.get $12)
          (i32.const 1)
         )
        )
       )
       (local.get $6)
      )
     )
     (br $label)
    )
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (ref.eq
      (local.get $6)
      (global.get $uninitialized)
     )
    )
    (return
     (if (result eqref)
      (if (result i32)
       (ref.eq
        (local.get $6)
        (global.get $nil)
       )
       (then
        (i32.const 1)
       )
       (else
        (drop
         (if (result i32)
          (ref.test (ref $atom)
           (local.get $6)
          )
          (then
           (i32.lt_s
            (struct.get $atom 0
             (ref.cast (ref $atom)
              (local.get $6)
             )
            )
            (i32.const 0)
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (i32.const 0)
       )
      )
      (then
       (return_call_ref $call
        (struct.get $closure 1
         (local.tee $9
          (ref.cast (ref $closure)
           (block $block2 (result eqref)
            (br_if $block
             (i32.or
              (ref.is_null
               (local.tee $0
                (array.get $vector
                 (ref.cast (ref $vector)
                  (local.get $0)
                 )
                 (i32.const 0)
                )
               )
              )
              (ref.eq
               (local.get $0)
               (global.get $uninitialized)
              )
             )
            )
            (if
             (ref.test (ref $values)
              (local.get $0)
             )
             (then
              (br_if $block1
               (i32.ne
                (array.len
                 (local.tee $1
                  (struct.get $values 0
                   (ref.cast (ref $values)
                    (local.get $0)
                   )
                  )
                 )
                )
                (i32.const 1)
               )
              )
              (br $block2
               (array.get $vector
                (local.get $1)
                (i32.const 0)
               )
              )
             )
            )
            (local.get $0)
           )
          )
         )
        )
        (array.new_fixed $vector 0)
        (local.get $2)
        (struct.get $closure 0
         (local.get $9)
        )
       )
      )
      (else
       (if (result eqref)
        (if (result i32)
         (ref.eq
          (local.tee $3
           (block $block3 (result eqref)
            (br_if $block
             (ref.eq
              (local.get $6)
              (global.get $uninitialized)
             )
            )
            (if
             (ref.test (ref $values)
              (local.tee $3
               (struct.get $pair 1
                (ref.cast (ref $pair)
                 (local.get $6)
                )
               )
              )
             )
             (then
              (br_if $block1
               (i32.ne
                (array.len
                 (local.tee $1
                  (struct.get $values 0
                   (ref.cast (ref $values)
                    (local.get $3)
                   )
                  )
                 )
                )
                (i32.const 1)
               )
              )
              (br $block3
               (array.get $vector
                (local.get $1)
                (i32.const 0)
               )
              )
             )
            )
            (local.get $3)
           )
          )
          (global.get $nil)
         )
         (then
          (i32.const 1)
         )
         (else
          (drop
           (if (result i32)
            (ref.test (ref $atom)
             (local.get $3)
            )
            (then
             (i32.lt_s
              (struct.get $atom 0
               (ref.cast (ref $atom)
                (local.get $3)
               )
              )
              (i32.const 0)
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (i32.const 0)
         )
        )
        (then
         (local.set $3
          (block $block4 (result eqref)
           (br_if $block
            (ref.eq
             (local.get $6)
             (global.get $uninitialized)
            )
           )
           (if
            (ref.test (ref $values)
             (local.tee $3
              (struct.get $pair 0
               (ref.cast (ref $pair)
                (local.get $6)
               )
              )
             )
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $1
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $3)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block4
              (array.get $vector
               (local.get $1)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $3)
          )
         )
         (local.set $3
          (block $block6 (result eqref)
           (if
            (ref.test (ref $values)
             (local.tee $0
              (call_ref $call
               (struct.get $closure 1
                (local.tee $9
                 (ref.cast (ref $closure)
                  (block $block5 (result eqref)
                   (br_if $block
                    (i32.or
                     (ref.is_null
                      (local.tee $0
                       (array.get $vector
                        (local.tee $10
                         (ref.cast (ref $vector)
                          (local.get $0)
                         )
                        )
                        (i32.const 2)
                       )
                      )
                     )
                     (ref.eq
                      (local.get $0)
                      (global.get $uninitialized)
                     )
                    )
                   )
                   (if
                    (ref.test (ref $values)
                     (local.get $0)
                    )
                    (then
                     (br_if $block1
                      (i32.ne
                       (array.len
                        (local.tee $1
                         (struct.get $values 0
                          (ref.cast (ref $values)
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (i32.const 1)
                      )
                     )
                     (br $block5
                      (array.get $vector
                       (local.get $1)
                       (i32.const 0)
                      )
                     )
                    )
                   )
                   (local.get $0)
                  )
                 )
                )
               )
               (array.new_fixed $vector 1
                (local.get $3)
               )
               (ref.null none)
               (struct.get $closure 0
                (local.get $9)
               )
              )
             )
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $1
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $0)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block6
              (array.get $vector
               (local.get $1)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $0)
          )
         )
         (return_call_ref $call
          (struct.get $closure 1
           (local.tee $9
            (ref.cast (ref $closure)
             (block $block7 (result eqref)
              (br_if $block
               (i32.or
                (ref.is_null
                 (local.tee $0
                  (array.get $vector
                   (local.get $10)
                   (i32.const 1)
                  )
                 )
                )
                (ref.eq
                 (local.get $0)
                 (global.get $uninitialized)
                )
               )
              )
              (if
               (ref.test (ref $values)
                (local.get $0)
               )
               (then
                (br_if $block1
                 (i32.ne
                  (array.len
                   (local.tee $1
                    (struct.get $values 0
                     (ref.cast (ref $values)
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (i32.const 1)
                 )
                )
                (br $block7
                 (array.get $vector
                  (local.get $1)
                  (i32.const 0)
                 )
                )
               )
              )
              (local.get $0)
             )
            )
           )
          )
          (array.new_fixed $vector 1
           (local.get $3)
          )
          (local.get $2)
          (struct.get $closure 0
           (local.get $9)
          )
         )
        )
        (else
         (if (result eqref)
          (if (result i32)
           (ref.eq
            (local.tee $3
             (block $block8 (result eqref)
              (br_if $block
               (ref.eq
                (local.get $6)
                (global.get $uninitialized)
               )
              )
              (if
               (ref.test (ref $values)
                (local.tee $3
                 (struct.get $pair 0
                  (ref.cast (ref $pair)
                   (local.get $6)
                  )
                 )
                )
               )
               (then
                (br_if $block1
                 (i32.ne
                  (array.len
                   (local.tee $1
                    (struct.get $values 0
                     (ref.cast (ref $values)
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (i32.const 1)
                 )
                )
                (br $block8
                 (array.get $vector
                  (local.get $1)
                  (i32.const 0)
                 )
                )
               )
              )
              (local.get $3)
             )
            )
            (block (result (ref null $pair))
             (br_if $block
              (ref.is_null
               (local.tee $11
                (global.get $g236)
               )
              )
             )
             (local.get $11)
            )
           )
           (then
            (i32.const 1)
           )
           (else
            (drop
             (if (result i32)
              (ref.test (ref $atom)
               (local.get $3)
              )
              (then
               (i32.lt_s
                (struct.get $atom 0
                 (ref.cast (ref $atom)
                  (local.get $3)
                 )
                )
                (i32.const 0)
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (i32.const 0)
           )
          )
          (then
           (br_if $block
            (ref.eq
             (local.get $6)
             (global.get $uninitialized)
            )
           )
           (br_if $block
            (ref.is_null
             (local.tee $7
              (global.get $g184)
             )
            )
           )
           (drop
            (ref.as_non_null
             (local.get $7)
            )
           )
           (local.set $3
            (block $block9 (result eqref)
             (if
              (ref.test (ref $values)
               (local.tee $3
                (call $function3
                 (local.get $6)
                )
               )
              )
              (then
               (br_if $block1
                (i32.ne
                 (array.len
                  (local.tee $1
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $3)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block9
                (array.get $vector
                 (local.get $1)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $3)
            )
           )
           (return
            (block $block20 (result eqref)
             (local.set $0
              (array.get $vector
               (local.tee $1
                (ref.cast (ref $vector)
                 (local.get $0)
                )
               )
               (i32.const 2)
              )
             )
             (local.set $4
              (array.get $vector
               (local.get $1)
               (i32.const 1)
              )
             )
             (br_if $block
              (local.tee $12
               (i32.or
                (ref.is_null
                 (local.get $3)
                )
                (ref.eq
                 (local.get $3)
                 (global.get $uninitialized)
                )
               )
              )
             )
             (br_if $block
              (ref.is_null
               (local.tee $7
                (global.get $g198)
               )
              )
             )
             (drop
              (ref.as_non_null
               (local.get $7)
              )
             )
             (br_if $block
              (ref.is_null
               (local.tee $7
                (global.get $g42)
               )
              )
             )
             (block $block10
              (local.set $5
               (block $block11 (result eqref)
                (br_if $block
                 (local.get $12)
                )
                (if
                 (ref.test (ref $values)
                  (local.get $3)
                 )
                 (then
                  (br_if $block10
                   (i32.ne
                    (array.len
                     (local.tee $1
                      (struct.get $values 0
                       (ref.cast (ref $values)
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (i32.const 1)
                   )
                  )
                  (br $block11
                   (array.get $vector
                    (local.get $1)
                    (i32.const 0)
                   )
                  )
                 )
                )
                (local.get $3)
               )
              )
              (br_if $block
               (ref.is_null
                (local.tee $8
                 (global.get $g195)
                )
               )
              )
              (drop
               (ref.as_non_null
                (local.get $8)
               )
              )
              (if
               (ref.eq
                (block $block12 (result eqref)
                 (if
                  (ref.test (ref $values)
                   (local.tee $5
                    (call $function28
                     (local.get $7)
                     (local.get $5)
                     (global.get $literal4)
                     (ref.null none)
                    )
                   )
                  )
                  (then
                   (br_if $block10
                    (i32.ne
                     (array.len
                      (local.tee $1
                       (struct.get $values 0
                        (ref.cast (ref $values)
                         (local.get $5)
                        )
                       )
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (br $block12
                    (array.get $vector
                     (local.get $1)
                     (i32.const 0)
                    )
                   )
                  )
                 )
                 (local.get $5)
                )
                (global.get $false)
               )
               (then
                (br_if $block
                 (local.tee $12
                  (i32.or
                   (ref.is_null
                    (local.get $3)
                   )
                   (ref.eq
                    (local.get $3)
                    (global.get $uninitialized)
                   )
                  )
                 )
                )
                (br $block20
                 (block $block16 (result eqref)
                  (br_if $block
                   (local.get $12)
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $7
                     (global.get $g198)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (local.get $7)
                   )
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $7
                     (global.get $g42)
                    )
                   )
                  )
                  (block $block13
                   (local.set $0
                    (block $block14 (result eqref)
                     (br_if $block
                      (local.get $12)
                     )
                     (if
                      (ref.test (ref $values)
                       (local.get $3)
                      )
                      (then
                       (br_if $block13
                        (i32.ne
                         (array.len
                          (local.tee $1
                           (struct.get $values 0
                            (ref.cast (ref $values)
                             (local.get $3)
                            )
                           )
                          )
                         )
                         (i32.const 1)
                        )
                       )
                       (br $block14
                        (array.get $vector
                         (local.get $1)
                         (i32.const 0)
                        )
                       )
                      )
                     )
                     (local.get $3)
                    )
                   )
                   (br_if $block
                    (ref.is_null
                     (local.tee $8
                      (global.get $g195)
                     )
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (local.get $8)
                    )
                   )
                   (if
                    (ref.eq
                     (block $block15 (result eqref)
                      (if
                       (ref.test (ref $values)
                        (local.tee $0
                         (call $function28
                          (local.get $7)
                          (local.get $0)
                          (global.get $literal6)
                          (ref.null none)
                         )
                        )
                       )
                       (then
                        (br_if $block13
                         (i32.ne
                          (array.len
                           (local.tee $1
                            (struct.get $values 0
                             (ref.cast (ref $values)
                              (local.get $0)
                             )
                            )
                           )
                          )
                          (i32.const 1)
                         )
                        )
                        (br $block15
                         (array.get $vector
                          (local.get $1)
                          (i32.const 0)
                         )
                        )
                       )
                      )
                      (local.get $0)
                     )
                     (global.get $false)
                    )
                    (then
                     (br_if $block
                      (i32.or
                       (ref.is_null
                        (local.get $3)
                       )
                       (ref.eq
                        (local.get $3)
                        (global.get $uninitialized)
                       )
                      )
                     )
                     (br_if $block
                      (ref.is_null
                       (local.tee $7
                        (global.get $g122)
                       )
                      )
                     )
                     (drop
                      (struct.get $closure 1
                       (local.get $7)
                      )
                     )
                     (br $block16
                      (block (result eqref)
                       (local.set $scratch
                        (call $awi_take
                         (call $rust60
                          (local.tee $12
                           (call $awi_root
                            (array.new_fixed $vector 1
                             (global.get $literal8)
                            )
                           )
                          )
                         )
                        )
                       )
                       (if
                        (i32.ge_u
                         (local.get $12)
                         (global.get $awi_used)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.ne
                         (array.get $text
                          (global.get $awi_links)
                          (local.get $12)
                         )
                         (i32.const -1)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (table.get $awi_roots
                         (local.get $12)
                        )
                       )
                       (table.set $awi_roots
                        (local.get $12)
                        (ref.null none)
                       )
                       (array.set $text
                        (global.get $awi_links)
                        (local.get $12)
                        (global.get $awi_free)
                       )
                       (global.set $awi_free
                        (local.get $12)
                       )
                       (global.set $awi_live
                        (i32.sub
                         (global.get $awi_live)
                         (i32.const 1)
                        )
                       )
                       (local.get $scratch)
                      )
                     )
                    )
                    (else
                     (br_if $block
                      (ref.eq
                       (local.get $6)
                       (global.get $uninitialized)
                      )
                     )
                     (br_if $block
                      (ref.is_null
                       (local.tee $7
                        (global.get $g186)
                       )
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (local.get $7)
                      )
                     )
                     (local.set $0
                      (block $block18 (result eqref)
                       (if
                        (ref.test (ref $values)
                         (local.tee $0
                          (struct.get $pair 0
                           (ref.cast (ref $pair)
                            (block $block17 (result eqref)
                             (if
                              (ref.test (ref $values)
                               (local.tee $0
                                (call $function5
                                 (local.get $6)
                                )
                               )
                              )
                              (then
                               (br_if $block13
                                (i32.ne
                                 (array.len
                                  (local.tee $1
                                   (struct.get $values 0
                                    (ref.cast (ref $values)
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (i32.const 1)
                                )
                               )
                               (br $block17
                                (array.get $vector
                                 (local.get $1)
                                 (i32.const 0)
                                )
                               )
                              )
                             )
                             (local.get $0)
                            )
                           )
                          )
                         )
                        )
                        (then
                         (br_if $block13
                          (i32.ne
                           (array.len
                            (local.tee $1
                             (struct.get $values 0
                              (ref.cast (ref $values)
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (i32.const 1)
                          )
                         )
                         (br $block18
                          (array.get $vector
                           (local.get $1)
                           (i32.const 0)
                          )
                         )
                        )
                       )
                       (local.get $0)
                      )
                     )
                     (return_call_ref $call
                      (struct.get $closure 1
                       (local.tee $9
                        (ref.cast (ref $closure)
                         (block $block19 (result eqref)
                          (br_if $block
                           (i32.or
                            (ref.is_null
                             (local.get $4)
                            )
                            (ref.eq
                             (local.get $4)
                             (global.get $uninitialized)
                            )
                           )
                          )
                          (if
                           (ref.test (ref $values)
                            (local.get $4)
                           )
                           (then
                            (br_if $block13
                             (i32.ne
                              (array.len
                               (local.tee $1
                                (struct.get $values 0
                                 (ref.cast (ref $values)
                                  (local.get $4)
                                 )
                                )
                               )
                              )
                              (i32.const 1)
                             )
                            )
                            (br $block19
                             (array.get $vector
                              (local.get $1)
                              (i32.const 0)
                             )
                            )
                           )
                          )
                          (local.get $4)
                         )
                        )
                       )
                      )
                      (array.new_fixed $vector 1
                       (local.get $0)
                      )
                      (local.get $2)
                      (struct.get $closure 0
                       (local.get $9)
                      )
                     )
                    )
                   )
                   (unreachable)
                  )
                  (br $block10)
                 )
                )
               )
               (else
                (br_if $block
                 (ref.eq
                  (local.get $6)
                  (global.get $uninitialized)
                 )
                )
                (br_if $block
                 (ref.is_null
                  (local.tee $7
                   (global.get $g186)
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (local.get $7)
                 )
                )
                (local.set $3
                 (block $block22 (result eqref)
                  (if
                   (ref.test (ref $values)
                    (local.tee $3
                     (struct.get $pair 0
                      (ref.cast (ref $pair)
                       (block $block21 (result eqref)
                        (if
                         (ref.test (ref $values)
                          (local.tee $3
                           (call $function5
                            (local.get $6)
                           )
                          )
                         )
                         (then
                          (br_if $block10
                           (i32.ne
                            (array.len
                             (local.tee $1
                              (struct.get $values 0
                               (ref.cast (ref $values)
                                (local.get $3)
                               )
                              )
                             )
                            )
                            (i32.const 1)
                           )
                          )
                          (br $block21
                           (array.get $vector
                            (local.get $1)
                            (i32.const 0)
                           )
                          )
                         )
                        )
                        (local.get $3)
                       )
                      )
                     )
                    )
                   )
                   (then
                    (br_if $block10
                     (i32.ne
                      (array.len
                       (local.tee $1
                        (struct.get $values 0
                         (ref.cast (ref $values)
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (br $block22
                     (array.get $vector
                      (local.get $1)
                      (i32.const 0)
                     )
                    )
                   )
                  )
                  (local.get $3)
                 )
                )
                (return_call_ref $call
                 (struct.get $closure 1
                  (local.tee $9
                   (ref.cast (ref $closure)
                    (block $block23 (result eqref)
                     (br_if $block
                      (i32.or
                       (ref.is_null
                        (local.get $0)
                       )
                       (ref.eq
                        (local.get $0)
                        (global.get $uninitialized)
                       )
                      )
                     )
                     (if
                      (ref.test (ref $values)
                       (local.get $0)
                      )
                      (then
                       (br_if $block10
                        (i32.ne
                         (array.len
                          (local.tee $1
                           (struct.get $values 0
                            (ref.cast (ref $values)
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (i32.const 1)
                        )
                       )
                       (br $block23
                        (array.get $vector
                         (local.get $1)
                         (i32.const 0)
                        )
                       )
                      )
                     )
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (array.new_fixed $vector 1
                  (local.get $3)
                 )
                 (local.get $2)
                 (struct.get $closure 0
                  (local.get $9)
                 )
                )
               )
              )
              (unreachable)
             )
             (br $block1)
            )
           )
          )
          (else
           (br_if $block
            (ref.eq
             (local.get $6)
             (global.get $uninitialized)
            )
           )
           (br_if $block
            (ref.is_null
             (local.tee $7
              (global.get $g122)
             )
            )
           )
           (drop
            (struct.get $closure 1
             (local.get $7)
            )
           )
           (local.set $scratch_14
            (call $awi_take
             (call $rust60
              (local.tee $12
               (call $awi_root
                (array.new_fixed $vector 2
                 (global.get $literal9)
                 (local.get $6)
                )
               )
              )
             )
            )
           )
           (if
            (i32.ge_u
             (local.get $12)
             (global.get $awi_used)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.ne
             (array.get $text
              (global.get $awi_links)
              (local.get $12)
             )
             (i32.const -1)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (table.get $awi_roots
             (local.get $12)
            )
           )
           (table.set $awi_roots
            (local.get $12)
            (ref.null none)
           )
           (array.set $text
            (global.get $awi_links)
            (local.get $12)
            (global.get $awi_free)
           )
           (global.set $awi_free
            (local.get $12)
           )
           (global.set $awi_live
            (i32.sub
             (global.get $awi_live)
             (i32.const 1)
            )
           )
           (local.get $scratch_14)
          )
         )
        )
       )
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter98 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 3)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (struct.new $closure
   (ref.func $adapter99)
   (array.new_fixed $vector 3
    (array.get $vector
     (local.get $1)
     (i32.const 0)
    )
    (array.get $vector
     (local.get $1)
     (i32.const 1)
    )
    (array.get $vector
     (local.get $1)
     (i32.const 2)
    )
   )
  )
 )
 (func $adapter109 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 1)
    )
    (i32.eqz
     (local.get $3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (if
   (i32.or
    (ref.is_null
     (local.tee $0
      (array.get $vector
       (local.get $1)
       (i32.const 0)
      )
     )
    )
    (ref.eq
     (local.get $0)
     (global.get $uninitialized)
    )
   )
   (then
    (global.set $error_code
     (i32.const 6)
    )
    (drop
     (call $rust_fail
      (i32.const 6)
     )
    )
    (unreachable)
   )
  )
  (local.get $0)
 )
 (func $function121 (type $9) (param $0 eqref) (param $1 eqref) (param $2 nullref) (result eqref)
  (local $3 (ref $vector))
  (local $4 (ref i31))
  (local $5 eqref)
  (local $6 eqref)
  (local $7 (ref null $closure))
  (local $8 i32)
  (block $block1
   (block $block
    (return
     (if (result eqref)
      (ref.eq
       (call $numeric_equal
        (block $block2 (result eqref)
         (br_if $block
          (i32.or
           (ref.is_null
            (local.get $0)
           )
           (ref.eq
            (local.get $0)
            (global.get $uninitialized)
           )
          )
         )
         (if
          (ref.test (ref $values)
           (local.get $0)
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $3
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $0)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block2
            (array.get $vector
             (local.get $3)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $0)
        )
        (ref.i31
         (i32.const 0)
        )
       )
       (global.get $false)
      )
      (then
       (if
        (ref.eq
         (call $numeric_equal
          (block $block3 (result eqref)
           (br_if $block
            (i32.or
             (ref.is_null
              (local.get $1)
             )
             (ref.eq
              (local.get $1)
              (global.get $uninitialized)
             )
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $1)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $3
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $1)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block3
              (array.get $vector
               (local.get $3)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $1)
          )
          (ref.i31
           (i32.const 0)
          )
         )
         (global.get $false)
        )
        (then
         (local.set $4
          (ref.i31
           (i32.const 1)
          )
         )
         (return_call $function121
          (if (result eqref)
           (ref.test (ref i31)
            (local.tee $5
             (block $block4 (result eqref)
              (br_if $block
               (i32.or
                (ref.is_null
                 (local.get $0)
                )
                (ref.eq
                 (local.get $0)
                 (global.get $uninitialized)
                )
               )
              )
              (if
               (ref.test (ref $values)
                (local.get $0)
               )
               (then
                (br_if $block1
                 (i32.ne
                  (array.len
                   (local.tee $3
                    (struct.get $values 0
                     (ref.cast (ref $values)
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (i32.const 1)
                 )
                )
                (br $block4
                 (array.get $vector
                  (local.get $3)
                  (i32.const 0)
                 )
                )
               )
              )
              (local.get $0)
             )
            )
           )
           (then
            (if (result eqref)
             (i32.le_u
              (i32.add
               (local.tee $8
                (i32.sub
                 (i31.get_s
                  (ref.cast (ref i31)
                   (local.get $5)
                  )
                 )
                 (i32.const 1)
                )
               )
               (i32.const 1073741824)
              )
              (i32.const 2147483647)
             )
             (then
              (ref.i31
               (local.get $8)
              )
             )
             (else
              (call $cold.checked_subtract
               (local.get $5)
               (local.get $4)
              )
             )
            )
           )
           (else
            (call $cold.checked_subtract
             (local.get $5)
             (local.get $4)
            )
           )
          )
          (block (result eqref)
           (local.set $6
            (block $block5 (result eqref)
             (br_if $block
              (i32.or
               (ref.is_null
                (local.get $0)
               )
               (ref.eq
                (local.get $0)
                (global.get $uninitialized)
               )
              )
             )
             (if
              (ref.test (ref $values)
               (local.get $0)
              )
              (then
               (br_if $block1
                (i32.ne
                 (array.len
                  (local.tee $3
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block5
                (array.get $vector
                 (local.get $3)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $0)
            )
           )
           (local.set $0
            (if (result eqref)
             (ref.test (ref i31)
              (local.tee $0
               (block $block6 (result eqref)
                (br_if $block
                 (i32.or
                  (ref.is_null
                   (local.get $1)
                  )
                  (ref.eq
                   (local.get $1)
                   (global.get $uninitialized)
                  )
                 )
                )
                (if
                 (ref.test (ref $values)
                  (local.get $1)
                 )
                 (then
                  (br_if $block1
                   (i32.ne
                    (array.len
                     (local.tee $3
                      (struct.get $values 0
                       (ref.cast (ref $values)
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (i32.const 1)
                   )
                  )
                  (br $block6
                   (array.get $vector
                    (local.get $3)
                    (i32.const 0)
                   )
                  )
                 )
                )
                (local.get $1)
               )
              )
             )
             (then
              (if (result eqref)
               (i32.le_u
                (i32.add
                 (local.tee $8
                  (i32.sub
                   (i31.get_s
                    (ref.cast (ref i31)
                     (local.get $0)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (i32.const 1073741824)
                )
                (i32.const 2147483647)
               )
               (then
                (ref.i31
                 (local.get $8)
                )
               )
               (else
                (call $cold.checked_subtract
                 (local.get $0)
                 (local.get $4)
                )
               )
              )
             )
             (else
              (call $cold.checked_subtract
               (local.get $0)
               (local.get $4)
              )
             )
            )
           )
           (br_if $block
            (ref.is_null
             (local.tee $7
              (global.get $g247)
             )
            )
           )
           (drop
            (ref.as_non_null
             (local.get $7)
            )
           )
           (block $block7 (result eqref)
            (if
             (ref.test (ref $values)
              (local.tee $0
               (call $function121
                (local.get $6)
                (local.get $0)
                (ref.null none)
               )
              )
             )
             (then
              (br_if $block1
               (i32.ne
                (array.len
                 (local.tee $3
                  (struct.get $values 0
                   (ref.cast (ref $values)
                    (local.get $0)
                   )
                  )
                 )
                )
                (i32.const 1)
               )
              )
              (br $block7
               (array.get $vector
                (local.get $3)
                (i32.const 0)
               )
              )
             )
            )
            (local.get $0)
           )
          )
          (block (result nullref)
           (br_if $block
            (ref.is_null
             (local.tee $7
              (global.get $g247)
             )
            )
           )
           (drop
            (ref.as_non_null
             (local.get $7)
            )
           )
           (local.get $2)
          )
         )
        )
        (else
         (local.set $4
          (ref.i31
           (i32.const 1)
          )
         )
         (return_call $function121
          (if (result eqref)
           (ref.test (ref i31)
            (local.tee $0
             (block $block8 (result eqref)
              (br_if $block
               (i32.or
                (ref.is_null
                 (local.get $0)
                )
                (ref.eq
                 (local.get $0)
                 (global.get $uninitialized)
                )
               )
              )
              (if
               (ref.test (ref $values)
                (local.get $0)
               )
               (then
                (br_if $block1
                 (i32.ne
                  (array.len
                   (local.tee $3
                    (struct.get $values 0
                     (ref.cast (ref $values)
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (i32.const 1)
                 )
                )
                (br $block8
                 (array.get $vector
                  (local.get $3)
                  (i32.const 0)
                 )
                )
               )
              )
              (local.get $0)
             )
            )
           )
           (then
            (if (result eqref)
             (i32.le_u
              (i32.add
               (local.tee $8
                (i32.sub
                 (i31.get_s
                  (ref.cast (ref i31)
                   (local.get $0)
                  )
                 )
                 (i32.const 1)
                )
               )
               (i32.const 1073741824)
              )
              (i32.const 2147483647)
             )
             (then
              (ref.i31
               (local.get $8)
              )
             )
             (else
              (call $cold.checked_subtract
               (local.get $0)
               (local.get $4)
              )
             )
            )
           )
           (else
            (call $cold.checked_subtract
             (local.get $0)
             (local.get $4)
            )
           )
          )
          (block (result (ref i31))
           (br_if $block
            (ref.is_null
             (local.tee $7
              (global.get $g247)
             )
            )
           )
           (drop
            (ref.as_non_null
             (local.get $7)
            )
           )
           (local.get $4)
          )
          (local.get $2)
         )
        )
       )
       (unreachable)
      )
      (else
       (local.set $4
        (ref.i31
         (i32.const 1)
        )
       )
       (if (result eqref)
        (ref.test (ref i31)
         (local.tee $0
          (block $block9 (result eqref)
           (br_if $block
            (i32.or
             (ref.is_null
              (local.get $1)
             )
             (ref.eq
              (local.get $1)
              (global.get $uninitialized)
             )
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $1)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $3
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $1)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block9
              (array.get $vector
               (local.get $3)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $1)
          )
         )
        )
        (then
         (if (result eqref)
          (i32.le_u
           (i32.add
            (local.tee $8
             (i32.add
              (i31.get_s
               (ref.cast (ref i31)
                (local.get $0)
               )
              )
              (i32.const 1)
             )
            )
            (i32.const 1073741824)
           )
           (i32.const 2147483647)
          )
          (then
           (ref.i31
            (local.get $8)
           )
          )
          (else
           (call $cold.checked_add
            (local.get $0)
            (local.get $4)
           )
          )
         )
        )
        (else
         (call $cold.checked_add
          (local.get $0)
          (local.get $4)
         )
        )
       )
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter121 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function121
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
   (local.get $2)
  )
 )
 (func $adapter132 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 (ref null $closure))
  (local $4 eqref)
  (local $5 eqref)
  (local $6 (ref $vector))
  (if
   (array.len
    (local.get $1)
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (i32.or
      (ref.is_null
       (local.tee $0
        (array.get $vector
         (local.tee $1
          (ref.cast (ref $vector)
           (local.get $0)
          )
         )
         (i32.const 0)
        )
       )
      )
      (ref.eq
       (local.get $0)
       (global.get $uninitialized)
      )
     )
    )
    (br_if $block
     (i32.or
      (ref.is_null
       (local.tee $4
        (array.get $vector
         (local.get $1)
         (i32.const 1)
        )
       )
      )
      (ref.eq
       (local.get $4)
       (global.get $uninitialized)
      )
     )
    )
    (br_if $block
     (ref.is_null
      (local.tee $3
       (global.get $g250)
      )
     )
    )
    (drop
     (ref.as_non_null
      (local.get $3)
     )
    )
    (return_call $function121
     (block $block2 (result eqref)
      (br_if $block
       (ref.is_null
        (local.tee $3
         (global.get $g118)
        )
       )
      )
      (drop
       (ref.as_non_null
        (local.get $3)
       )
      )
      (if
       (ref.test (ref $values)
        (local.tee $0
         (call $builtin:call-with-values
          (array.new_fixed $vector 2
           (struct.new $closure
            (ref.func $adapter136)
            (array.new_fixed $vector 1
             (local.get $0)
            )
           )
           (struct.new $closure
            (ref.func $adapter138)
            (array.new_fixed $vector 1
             (local.get $4)
            )
           )
          )
          (ref.null none)
         )
        )
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $6
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $0)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block2
         (array.get $vector
          (local.get $6)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $0)
     )
     (block (result eqref)
      (br_if $block
       (i32.or
        (ref.is_null
         (local.tee $0
          (array.get $vector
           (local.get $1)
           (i32.const 0)
          )
         )
        )
        (ref.eq
         (local.get $0)
         (global.get $uninitialized)
        )
       )
      )
      (br_if $block
       (i32.or
        (ref.is_null
         (local.tee $4
          (array.get $vector
           (local.get $1)
           (i32.const 2)
          )
         )
        )
        (ref.eq
         (local.get $4)
         (global.get $uninitialized)
        )
       )
      )
      (br_if $block
       (ref.is_null
        (local.tee $3
         (global.get $g250)
        )
       )
      )
      (drop
       (ref.as_non_null
        (local.get $3)
       )
      )
      (block $block3 (result eqref)
       (br_if $block
        (ref.is_null
         (local.tee $3
          (global.get $g118)
         )
        )
       )
       (drop
        (ref.as_non_null
         (local.get $3)
        )
       )
       (if
        (ref.test (ref $values)
         (local.tee $0
          (call $builtin:call-with-values
           (array.new_fixed $vector 2
            (struct.new $closure
             (ref.func $adapter136)
             (array.new_fixed $vector 1
              (local.get $0)
             )
            )
            (struct.new $closure
             (ref.func $adapter138)
             (array.new_fixed $vector 1
              (local.get $4)
             )
            )
           )
           (ref.null none)
          )
         )
        )
        (then
         (br_if $block1
          (i32.ne
           (array.len
            (local.tee $1
             (struct.get $values 0
              (ref.cast (ref $values)
               (local.get $0)
              )
             )
            )
           )
           (i32.const 1)
          )
         )
         (br $block3
          (array.get $vector
           (local.get $1)
           (i32.const 0)
          )
         )
        )
       )
       (local.get $0)
      )
     )
     (block (result nullref)
      (br_if $block
       (ref.is_null
        (local.tee $3
         (global.get $g247)
        )
       )
      )
      (drop
       (ref.as_non_null
        (local.get $3)
       )
      )
      (local.get $2)
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter133 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 eqref)
  (local $4 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $4
      (array.len
       (local.get $1)
      )
     )
     (i32.const 1)
    )
    (i32.eqz
     (local.get $4)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (block $block
   (return
    (call $numeric_equal
     (block $block1 (result eqref)
      (br_if $block
       (i32.or
        (ref.is_null
         (local.tee $3
          (array.get $vector
           (local.get $1)
           (i32.const 0)
          )
         )
        )
        (ref.eq
         (local.get $3)
         (global.get $uninitialized)
        )
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $3)
       )
       (then
        (if
         (i32.ne
          (array.len
           (local.tee $1
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $3)
             )
            )
           )
          )
          (i32.const 1)
         )
         (then
          (global.set $error_code
           (i32.const 5)
          )
          (drop
           (call $rust_fail
            (i32.const 5)
           )
          )
          (unreachable)
         )
        )
        (br $block1
         (array.get $vector
          (local.get $1)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $3)
     )
     (block (result eqref)
      (br_if $block
       (i32.or
        (ref.is_null
         (local.tee $0
          (array.get $vector
           (ref.cast (ref $vector)
            (local.get $0)
           )
           (i32.const 0)
          )
         )
        )
        (ref.eq
         (local.get $0)
         (global.get $uninitialized)
        )
       )
      )
      (local.get $0)
     )
    )
   )
  )
  (global.set $error_code
   (i32.const 6)
  )
  (drop
   (call $rust_fail
    (i32.const 6)
   )
  )
  (unreachable)
 )
 (func $function123 (type $5) (param $0 eqref) (param $1 nullref) (result eqref)
  (local $2 i32)
  (local $3 eqref)
  (local $4 eqref)
  (local $5 eqref)
  (local $6 eqref)
  (local $7 eqref)
  (local $8 eqref)
  (local $9 (ref null $closure))
  (local $10 (ref $vector))
  (local $11 (ref $text_object))
  (block $block
   (block $block1
    (local.set $4
     (block $block2 (result eqref)
      (br_if $block
       (ref.is_null
        (local.tee $9
         (global.get $g136)
        )
       )
      )
      (drop
       (struct.get $closure 1
        (local.get $9)
       )
      )
      (local.set $4
       (call $awi_take
        (call $rust74
         (local.tee $2
          (call $awi_root
           (array.new_fixed $vector 0)
          )
         )
        )
       )
      )
      (if
       (i32.ge_u
        (local.get $2)
        (global.get $awi_used)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (array.get $text
         (global.get $awi_links)
         (local.get $2)
        )
        (i32.const -1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (table.get $awi_roots
        (local.get $2)
       )
      )
      (table.set $awi_roots
       (local.get $2)
       (ref.null none)
      )
      (array.set $text
       (global.get $awi_links)
       (local.get $2)
       (global.get $awi_free)
      )
      (global.set $awi_free
       (local.get $2)
      )
      (global.set $awi_live
       (i32.sub
        (global.get $awi_live)
        (i32.const 1)
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $4)
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $10
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $4)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block2
         (array.get $vector
          (local.get $10)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $4)
     )
    )
    (local.set $5
     (block $block3 (result eqref)
      (br_if $block
       (ref.is_null
        (local.tee $9
         (global.get $g136)
        )
       )
      )
      (drop
       (struct.get $closure 1
        (local.get $9)
       )
      )
      (local.set $5
       (call $awi_take
        (call $rust74
         (local.tee $2
          (call $awi_root
           (array.new_fixed $vector 0)
          )
         )
        )
       )
      )
      (if
       (i32.ge_u
        (local.get $2)
        (global.get $awi_used)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (array.get $text
         (global.get $awi_links)
         (local.get $2)
        )
        (i32.const -1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (table.get $awi_roots
        (local.get $2)
       )
      )
      (table.set $awi_roots
       (local.get $2)
       (ref.null none)
      )
      (array.set $text
       (global.get $awi_links)
       (local.get $2)
       (global.get $awi_free)
      )
      (global.set $awi_free
       (local.get $2)
      )
      (global.set $awi_live
       (i32.sub
        (global.get $awi_live)
        (i32.const 1)
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $5)
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $10
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $5)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block3
         (array.get $vector
          (local.get $10)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $5)
     )
    )
    (block $block4
     (local.set $8
      (block $block5 (result eqref)
       (br_if $block
        (ref.is_null
         (local.tee $9
          (global.get $g136)
         )
        )
       )
       (drop
        (struct.get $closure 1
         (local.get $9)
        )
       )
       (local.set $3
        (call $awi_take
         (call $rust74
          (local.tee $2
           (call $awi_root
            (array.new_fixed $vector 0)
           )
          )
         )
        )
       )
       (if
        (i32.ge_u
         (local.get $2)
         (global.get $awi_used)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.ne
         (array.get $text
          (global.get $awi_links)
          (local.get $2)
         )
         (i32.const -1)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (table.get $awi_roots
         (local.get $2)
        )
       )
       (table.set $awi_roots
        (local.get $2)
        (ref.null none)
       )
       (array.set $text
        (global.get $awi_links)
        (local.get $2)
        (global.get $awi_free)
       )
       (global.set $awi_free
        (local.get $2)
       )
       (global.set $awi_live
        (i32.sub
         (global.get $awi_live)
         (i32.const 1)
        )
       )
       (if
        (ref.test (ref $values)
         (local.get $3)
        )
        (then
         (br_if $block4
          (i32.ne
           (array.len
            (local.tee $10
             (struct.get $values 0
              (ref.cast (ref $values)
               (local.get $3)
              )
             )
            )
           )
           (i32.const 1)
          )
         )
         (br $block5
          (array.get $vector
           (local.get $10)
           (i32.const 0)
          )
         )
        )
       )
       (local.get $3)
      )
     )
     (br_if $block
      (i32.or
       (ref.is_null
        (local.get $0)
       )
       (ref.eq
        (local.get $0)
        (global.get $uninitialized)
       )
      )
     )
     (local.set $3
      (block $block6 (result eqref)
       (br_if $block
        (ref.is_null
         (local.tee $9
          (global.get $g78)
         )
        )
       )
       (drop
        (struct.get $closure 1
         (local.get $9)
        )
       )
       (local.set $3
        (call $awi_take
         (call $rust33
          (local.tee $2
           (call $awi_root
            (array.new_fixed $vector 1
             (local.get $0)
            )
           )
          )
         )
        )
       )
       (if
        (i32.ge_u
         (local.get $2)
         (global.get $awi_used)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.ne
         (array.get $text
          (global.get $awi_links)
          (local.get $2)
         )
         (i32.const -1)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (table.get $awi_roots
         (local.get $2)
        )
       )
       (table.set $awi_roots
        (local.get $2)
        (ref.null none)
       )
       (array.set $text
        (global.get $awi_links)
        (local.get $2)
        (global.get $awi_free)
       )
       (global.set $awi_free
        (local.get $2)
       )
       (global.set $awi_live
        (i32.sub
         (global.get $awi_live)
         (i32.const 1)
        )
       )
       (if
        (ref.test (ref $values)
         (local.get $3)
        )
        (then
         (br_if $block4
          (i32.ne
           (array.len
            (local.tee $10
             (struct.get $values 0
              (ref.cast (ref $values)
               (local.get $3)
              )
             )
            )
           )
           (i32.const 1)
          )
         )
         (br $block6
          (array.get $vector
           (local.get $10)
           (i32.const 0)
          )
         )
        )
       )
       (local.get $3)
      )
     )
     (block $block7
      (br_if $block7
       (i32.or
        (ref.is_null
         (local.get $5)
        )
        (ref.eq
         (local.get $5)
         (global.get $uninitialized)
        )
       )
      )
      (block $block8
       (local.set $6
        (block $block9 (result eqref)
         (br_if $block7
          (ref.is_null
           (local.tee $9
            (global.get $g78)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $9)
          )
         )
         (local.set $6
          (call $awi_take
           (call $rust33
            (local.tee $2
             (call $awi_root
              (array.new_fixed $vector 1
               (local.get $5)
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $2)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $2)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $2)
          )
         )
         (table.set $awi_roots
          (local.get $2)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $2)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $2)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (if
          (ref.test (ref $values)
           (local.get $6)
          )
          (then
           (br_if $block8
            (i32.ne
             (array.len
              (local.tee $10
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $6)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block9
            (array.get $vector
             (local.get $10)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $6)
        )
       )
       (br_if $block7
        (i32.or
         (ref.is_null
          (local.get $4)
         )
         (ref.eq
          (local.get $4)
          (global.get $uninitialized)
         )
        )
       )
       (local.set $11
        (global.get $literal10)
       )
       (block $block11
        (br_if $block11
         (i32.or
          (ref.is_null
           (local.tee $7
            (block $block10 (result eqref)
             (br_if $block7
              (ref.is_null
               (local.tee $9
                (global.get $g78)
               )
              )
             )
             (drop
              (struct.get $closure 1
               (local.get $9)
              )
             )
             (local.set $7
              (call $awi_take
               (call $rust33
                (local.tee $2
                 (call $awi_root
                  (array.new_fixed $vector 1
                   (local.get $4)
                  )
                 )
                )
               )
              )
             )
             (if
              (i32.ge_u
               (local.get $2)
               (global.get $awi_used)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.ne
               (array.get $text
                (global.get $awi_links)
                (local.get $2)
               )
               (i32.const -1)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (table.get $awi_roots
               (local.get $2)
              )
             )
             (table.set $awi_roots
              (local.get $2)
              (ref.null none)
             )
             (array.set $text
              (global.get $awi_links)
              (local.get $2)
              (global.get $awi_free)
             )
             (global.set $awi_free
              (local.get $2)
             )
             (global.set $awi_live
              (i32.sub
               (global.get $awi_live)
               (i32.const 1)
              )
             )
             (if
              (ref.test (ref $values)
               (local.get $7)
              )
              (then
               (br_if $block8
                (i32.ne
                 (array.len
                  (local.tee $10
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $7)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block10
                (array.get $vector
                 (local.get $10)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $7)
            )
           )
          )
          (ref.eq
           (local.get $7)
           (global.get $uninitialized)
          )
         )
        )
        (br_if $block11
         (i32.or
          (ref.is_null
           (local.get $6)
          )
          (ref.eq
           (local.get $6)
           (global.get $uninitialized)
          )
         )
        )
        (br_if $block11
         (i32.or
          (ref.is_null
           (local.get $3)
          )
          (ref.eq
           (local.get $3)
           (global.get $uninitialized)
          )
         )
        )
        (return_call $function139
         (block $block12 (result eqref)
          (br_if $block11
           (ref.is_null
            (local.tee $9
             (global.get $g72)
            )
           )
          )
          (if
           (ref.test (ref $values)
            (local.tee $3
             (call $primitive72
              (struct.get $closure 1
               (local.get $9)
              )
              (array.new_fixed $vector 7
               (local.get $11)
               (global.get $literal11)
               (local.get $7)
               (global.get $literal12)
               (local.get $6)
               (global.get $literal13)
               (local.get $3)
              )
              (ref.null none)
             )
            )
           )
           (then
            (br_if $block8
             (i32.ne
              (array.len
               (local.tee $10
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $3)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block12
             (array.get $vector
              (local.get $10)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $3)
         )
         (block (result eqref)
          (br_if $block11
           (i32.or
            (ref.is_null
             (local.get $0)
            )
            (ref.eq
             (local.get $0)
             (global.get $uninitialized)
            )
           )
          )
          (br_if $block11
           (ref.is_null
            (local.tee $9
             (global.get $g251)
            )
           )
          )
          (drop
           (ref.as_non_null
            (local.get $9)
           )
          )
          (local.get $0)
         )
         (struct.new $closure
          (ref.func $adapter132)
          (array.new_fixed $vector 3
           (local.get $0)
           (local.get $4)
           (local.get $5)
          )
         )
         (struct.new $closure
          (ref.func $adapter133)
          (array.new_fixed $vector 1
           (local.get $8)
          )
         )
         (local.get $1)
        )
       )
       (br $block7)
      )
      (br $block1)
     )
     (br $block)
    )
   )
   (global.set $error_code
    (i32.const 5)
   )
   (drop
    (call $rust_fail
     (i32.const 5)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 6)
  )
  (drop
   (call $rust_fail
    (i32.const 6)
   )
  )
  (unreachable)
 )
 (func $adapter122 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $4 (ref null $closure))
  (if
   (array.len
    (local.get $1)
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function123
   (block $block (result eqref)
    (if
     (ref.is_null
      (local.tee $4
       (global.get $g136)
      )
     )
     (then
      (global.set $error_code
       (i32.const 6)
      )
      (drop
       (call $rust_fail
        (i32.const 6)
       )
      )
      (unreachable)
     )
    )
    (drop
     (struct.get $closure 1
      (local.get $4)
     )
    )
    (local.set $0
     (call $awi_take
      (call $rust74
       (local.tee $3
        (call $awi_root
         (array.new_fixed $vector 0)
        )
       )
      )
     )
    )
    (if
     (i32.ge_u
      (local.get $3)
      (global.get $awi_used)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (array.get $text
       (global.get $awi_links)
       (local.get $3)
      )
      (i32.const -1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (table.get $awi_roots
      (local.get $3)
     )
    )
    (table.set $awi_roots
     (local.get $3)
     (ref.null none)
    )
    (array.set $text
     (global.get $awi_links)
     (local.get $3)
     (global.get $awi_free)
    )
    (global.set $awi_free
     (local.get $3)
    )
    (global.set $awi_live
     (i32.sub
      (global.get $awi_live)
      (i32.const 1)
     )
    )
    (if
     (ref.test (ref $values)
      (local.get $0)
     )
     (then
      (if
       (i32.ne
        (array.len
         (local.tee $1
          (struct.get $values 0
           (ref.cast (ref $values)
            (local.get $0)
           )
          )
         )
        )
        (i32.const 1)
       )
       (then
        (global.set $error_code
         (i32.const 5)
        )
        (drop
         (call $rust_fail
          (i32.const 5)
         )
        )
        (unreachable)
       )
      )
      (br $block
       (array.get $vector
        (local.get $1)
        (i32.const 0)
       )
      )
     )
    )
    (local.get $0)
   )
   (local.get $2)
  )
 )
 (func $adapter134 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (if
   (array.len
    (local.get $1)
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (global.get $literal14)
 )
 (func $adapter136 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 (ref $vector))
  (local $4 (ref null $closure))
  (local $5 (ref null $closure))
  (local $6 (ref i31))
  (local $7 i32)
  (local $scratch (ref i31))
  (if
   (array.len
    (local.get $1)
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (block $block3 (result eqref)
   (block $block1
    (block $block
     (br_if $block
      (ref.is_null
       (local.tee $4
        (global.get $g117)
       )
      )
     )
     (br_if $block
      (ref.is_null
       (local.tee $5
        (global.get $g62)
       )
      )
     )
     (drop
      (ref.as_non_null
       (local.get $5)
      )
     )
     (br $block3
      (if (result eqref)
       (i32.eq
        (array.len
         (local.tee $3
          (array.new_fixed $vector 2
           (array.new_fixed $vector 2
            (local.get $4)
            (struct.new $closure
             (ref.func $adapter109)
             (array.new_fixed $vector 0)
            )
           )
           (block (result (ref i31))
            (local.set $6
             (ref.i31
              (i32.const 100)
             )
            )
            (local.set $scratch
             (ref.i31
              (i32.eqz
               (if (result i32)
                (ref.test (ref i31)
                 (local.tee $0
                  (block $block2 (result eqref)
                   (br_if $block
                    (i32.or
                     (ref.is_null
                      (local.tee $0
                       (array.get $vector
                        (ref.cast (ref $vector)
                         (local.get $0)
                        )
                        (i32.const 0)
                       )
                      )
                     )
                     (ref.eq
                      (local.get $0)
                      (global.get $uninitialized)
                     )
                    )
                   )
                   (if
                    (ref.test (ref $values)
                     (local.get $0)
                    )
                    (then
                     (br_if $block1
                      (i32.ne
                       (array.len
                        (local.tee $1
                         (struct.get $values 0
                          (ref.cast (ref $values)
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (i32.const 1)
                      )
                     )
                     (br $block2
                      (array.get $vector
                       (local.get $1)
                       (i32.const 0)
                      )
                     )
                    )
                   )
                   (local.get $0)
                  )
                 )
                )
                (then
                 (i32.lt_s
                  (i31.get_s
                   (ref.cast (ref i31)
                    (local.get $0)
                   )
                  )
                  (i32.const 100)
                 )
                )
                (else
                 (i32.and
                  (i32.ne
                   (local.tee $7
                    (call $cold.compare
                     (local.get $0)
                     (local.get $6)
                    )
                   )
                   (i32.const 2)
                  )
                  (i32.lt_s
                   (local.get $7)
                   (i32.const 0)
                  )
                 )
                )
               )
              )
             )
            )
            (br_if $block
             (ref.is_null
              (local.tee $4
               (global.get $g117)
              )
             )
            )
            (drop
             (ref.as_non_null
              (local.get $4)
             )
            )
            (local.get $scratch)
           )
          )
         )
        )
        (i32.const 1)
       )
       (then
        (array.get $vector
         (local.get $3)
         (i32.const 0)
        )
       )
       (else
        (struct.new $values
         (local.get $3)
        )
       )
      )
     )
    )
    (global.set $error_code
     (i32.const 6)
    )
    (drop
     (call $rust_fail
      (i32.const 6)
     )
    )
    (unreachable)
   )
   (global.set $error_code
    (i32.const 5)
   )
   (drop
    (call $rust_fail
     (i32.const 5)
    )
   )
   (unreachable)
  )
 )
 (func $adapter138 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 eqref)
  (local $4 eqref)
  (local $5 eqref)
  (local $6 (ref null $closure))
  (local $7 (ref $closure))
  (local $8 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $8
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $8)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (local.set $3
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
  )
  (local.set $4
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
  )
  (block $block1
   (block $block
    (local.set $5
     (block $block2 (result eqref)
      (br_if $block
       (i32.or
        (ref.is_null
         (local.tee $0
          (array.get $vector
           (ref.cast (ref $vector)
            (local.get $0)
           )
           (i32.const 0)
          )
         )
        )
        (ref.eq
         (local.get $0)
         (global.get $uninitialized)
        )
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $0)
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $1
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $0)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block2
         (array.get $vector
          (local.get $1)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $0)
     )
    )
    (local.set $0
     (block $block3 (result eqref)
      (br_if $block
       (i32.or
        (ref.is_null
         (local.get $3)
        )
        (ref.eq
         (local.get $3)
         (global.get $uninitialized)
        )
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $3)
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $1
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $3)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block3
         (array.get $vector
          (local.get $1)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $3)
     )
    )
    (local.set $3
     (block $block4 (result eqref)
      (br_if $block
       (i32.or
        (ref.is_null
         (local.get $4)
        )
        (ref.eq
         (local.get $4)
         (global.get $uninitialized)
        )
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $4)
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $1
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $4)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block4
         (array.get $vector
          (local.get $1)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $4)
     )
    )
    (return_call_ref $call
     (struct.get $closure 1
      (local.tee $7
       (ref.cast (ref $closure)
        (block $block5 (result eqref)
         (br_if $block
          (ref.is_null
           (local.tee $6
            (global.get $g63)
           )
          )
         )
         (if
          (ref.test (ref $values)
           (local.tee $0
            (call $primitive63
             (struct.get $closure 1
              (local.get $6)
             )
             (array.new_fixed $vector 2
              (local.get $0)
              (local.get $3)
             )
             (ref.null none)
            )
           )
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $1
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $0)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block5
            (array.get $vector
             (local.get $1)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $0)
        )
       )
      )
     )
     (array.new_fixed $vector 1
      (local.get $5)
     )
     (local.get $2)
     (struct.get $closure 0
      (local.get $7)
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter135 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $4 eqref)
  (local $5 (ref null $closure))
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (local.set $0
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
  )
  (local.set $4
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
  )
  (if
   (ref.is_null
    (local.tee $5
     (global.get $g118)
    )
   )
   (then
    (global.set $error_code
     (i32.const 6)
    )
    (drop
     (call $rust_fail
      (i32.const 6)
     )
    )
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (local.get $5)
   )
  )
  (return_call $builtin:call-with-values
   (array.new_fixed $vector 2
    (struct.new $closure
     (ref.func $adapter136)
     (array.new_fixed $vector 1
      (local.get $0)
     )
    )
    (struct.new $closure
     (ref.func $adapter138)
     (array.new_fixed $vector 1
      (local.get $4)
     )
    )
   )
   (local.get $2)
  )
 )
 (func $adapter140 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (local $4 (ref i31))
  (local $5 (ref null $closure))
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 1)
    )
    (i32.eqz
     (local.get $3)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (block $block1
   (block $block
    (local.set $0
     (call $multiply
      (local.tee $4
       (ref.i31
        (i32.const 1000)
       )
      )
      (block $block2 (result eqref)
       (br_if $block
        (i32.or
         (ref.is_null
          (local.tee $0
           (array.get $vector
            (local.get $1)
            (i32.const 0)
           )
          )
         )
         (ref.eq
          (local.get $0)
          (global.get $uninitialized)
         )
        )
       )
       (if
        (ref.test (ref $values)
         (local.get $0)
        )
        (then
         (br_if $block1
          (i32.ne
           (array.len
            (local.tee $1
             (struct.get $values 0
              (ref.cast (ref $values)
               (local.get $0)
              )
             )
            )
           )
           (i32.const 1)
          )
         )
         (br $block2
          (array.get $vector
           (local.get $1)
           (i32.const 0)
          )
         )
        )
       )
       (local.get $0)
      )
     )
    )
    (return
     (call $divide
      (block $block3 (result eqref)
       (br_if $block
        (ref.is_null
         (local.tee $5
          (global.get $g18)
         )
        )
       )
       (drop
        (struct.get $closure 1
         (local.get $5)
        )
       )
       (local.set $0
        (call $awi_take
         (call $rust24
          (local.tee $3
           (call $awi_root
            (array.new_fixed $vector 1
             (local.get $0)
            )
           )
          )
         )
        )
       )
       (if
        (i32.ge_u
         (local.get $3)
         (global.get $awi_used)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.ne
         (array.get $text
          (global.get $awi_links)
          (local.get $3)
         )
         (i32.const -1)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (table.get $awi_roots
         (local.get $3)
        )
       )
       (table.set $awi_roots
        (local.get $3)
        (ref.null none)
       )
       (array.set $text
        (global.get $awi_links)
        (local.get $3)
        (global.get $awi_free)
       )
       (global.set $awi_free
        (local.get $3)
       )
       (global.set $awi_live
        (i32.sub
         (global.get $awi_live)
         (i32.const 1)
        )
       )
       (if
        (ref.test (ref $values)
         (local.get $0)
        )
        (then
         (br_if $block1
          (i32.ne
           (array.len
            (local.tee $1
             (struct.get $values 0
              (ref.cast (ref $values)
               (local.get $0)
              )
             )
            )
           )
           (i32.const 1)
          )
         )
         (br $block3
          (array.get $vector
           (local.get $1)
           (i32.const 0)
          )
         )
        )
       )
       (local.get $0)
      )
      (local.get $4)
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $function146 (type $4) (param $0 eqref) (param $1 eqref) (param $2 eqref) (param $3 nullref) (result eqref)
  (local $4 i32)
  (local $5 (ref null $closure))
  (local $6 (ref $vector))
  (local $7 eqref)
  (local $8 eqref)
  (local $9 eqref)
  (local $10 eqref)
  (local $11 (ref null $vector))
  (local $12 (ref i31))
  (local $13 (ref $closure))
  (local $14 (ref $closure))
  (local $15 (ref struct))
  (local $scratch eqref)
  (local $scratch_17 eqref)
  (local $scratch_18 eqref)
  (local $scratch_19 eqref)
  (local $scratch_20 eqref)
  (local $scratch_21 eqref)
  (local $scratch_22 eqref)
  (block $block1
   (block $block
    (return
     (if (result (ref i31))
      (if (result i32)
       (i32.and
        (ref.test (ref i31)
         (local.tee $7
          (block $block2 (result eqref)
           (br_if $block
            (i32.or
             (ref.is_null
              (local.get $1)
             )
             (ref.eq
              (local.get $1)
              (global.get $uninitialized)
             )
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $1)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $6
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $1)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block2
              (array.get $vector
               (local.get $6)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $1)
          )
         )
        )
        (ref.test (ref i31)
         (local.tee $0
          (block $block3 (result eqref)
           (br_if $block
            (i32.or
             (ref.is_null
              (local.tee $0
               (array.get $vector
                (local.tee $11
                 (ref.cast (ref $vector)
                  (local.get $0)
                 )
                )
                (i32.const 0)
               )
              )
             )
             (ref.eq
              (local.get $0)
              (global.get $uninitialized)
             )
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $0)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $6
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $0)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block3
              (array.get $vector
               (local.get $6)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $0)
          )
         )
        )
       )
       (then
        (i32.lt_s
         (i31.get_s
          (ref.cast (ref i31)
           (local.get $7)
          )
         )
         (i31.get_s
          (ref.cast (ref i31)
           (local.get $0)
          )
         )
        )
       )
       (else
        (i32.and
         (i32.ne
          (local.tee $4
           (call $cold.compare
            (local.get $7)
            (local.get $0)
           )
          )
          (i32.const 2)
         )
         (i32.lt_s
          (local.get $4)
          (i32.const 0)
         )
        )
       )
      )
      (then
       (local.set $12
        (ref.i31
         (i32.const 1)
        )
       )
       (local.set $1
        (if (result eqref)
         (ref.test (ref i31)
          (local.tee $0
           (block $block4 (result eqref)
            (br_if $block
             (i32.or
              (ref.is_null
               (local.get $1)
              )
              (ref.eq
               (local.get $1)
               (global.get $uninitialized)
              )
             )
            )
            (if
             (ref.test (ref $values)
              (local.get $1)
             )
             (then
              (br_if $block1
               (i32.ne
                (array.len
                 (local.tee $6
                  (struct.get $values 0
                   (ref.cast (ref $values)
                    (local.get $1)
                   )
                  )
                 )
                )
                (i32.const 1)
               )
              )
              (br $block4
               (array.get $vector
                (local.get $6)
                (i32.const 0)
               )
              )
             )
            )
            (local.get $1)
           )
          )
         )
         (then
          (if (result eqref)
           (i32.le_u
            (i32.add
             (local.tee $4
              (i32.add
               (i31.get_s
                (ref.cast (ref i31)
                 (local.get $0)
                )
               )
               (i32.const 1)
              )
             )
             (i32.const 1073741824)
            )
            (i32.const 2147483647)
           )
           (then
            (ref.i31
             (local.get $4)
            )
           )
           (else
            (call $cold.checked_add
             (local.get $0)
             (local.get $12)
            )
           )
          )
         )
         (else
          (call $cold.checked_add
           (local.get $0)
           (local.get $12)
          )
         )
        )
       )
       (local.set $0
        (block $block6 (result eqref)
         (if
          (ref.test (ref $values)
           (local.tee $0
            (call_ref $call
             (struct.get $closure 1
              (local.tee $13
               (ref.cast (ref $closure)
                (block $block5 (result eqref)
                 (br_if $block
                  (i32.or
                   (ref.is_null
                    (local.tee $0
                     (array.get $vector
                      (local.get $11)
                      (i32.const 2)
                     )
                    )
                   )
                   (ref.eq
                    (local.get $0)
                    (global.get $uninitialized)
                   )
                  )
                 )
                 (if
                  (ref.test (ref $values)
                   (local.get $0)
                  )
                  (then
                   (br_if $block1
                    (i32.ne
                     (array.len
                      (local.tee $6
                       (struct.get $values 0
                        (ref.cast (ref $values)
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (br $block5
                    (array.get $vector
                     (local.get $6)
                     (i32.const 0)
                    )
                   )
                  )
                 )
                 (local.get $0)
                )
               )
              )
             )
             (array.new_fixed $vector 0)
             (ref.null none)
             (struct.get $closure 0
              (local.get $13)
             )
            )
           )
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $6
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $0)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block6
            (array.get $vector
             (local.get $6)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $0)
        )
       )
       (br_if $block
        (ref.eq
         (local.tee $15
          (struct.get $cell 0
           (ref.cast (ref $cell)
            (array.get $vector
             (local.get $11)
             (i32.const 1)
            )
           )
          )
         )
         (global.get $uninitialized)
        )
       )
       (return_call $function146
        (struct.get $closure 1
         (ref.cast (ref $closure)
          (local.get $15)
         )
        )
        (local.get $1)
        (local.get $0)
        (local.get $3)
       )
      )
      (else
       (local.set $1
        (block $block7 (result eqref)
         (br_if $block
          (i32.or
           (ref.is_null
            (local.get $2)
           )
           (ref.eq
            (local.get $2)
            (global.get $uninitialized)
           )
          )
         )
         (if
          (ref.test (ref $values)
           (local.get $2)
          )
          (then
           (br_if $block1
            (i32.ne
             (array.len
              (local.tee $6
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $2)
                )
               )
              )
             )
             (i32.const 1)
            )
           )
           (br $block7
            (array.get $vector
             (local.get $6)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $2)
        )
       )
       (if
        (ref.eq
         (block $block9 (result eqref)
          (if
           (ref.test (ref $values)
            (local.tee $0
             (call_ref $call
              (struct.get $closure 1
               (local.tee $13
                (ref.cast (ref $closure)
                 (block $block8 (result eqref)
                  (br_if $block
                   (i32.or
                    (ref.is_null
                     (local.tee $0
                      (array.get $vector
                       (local.get $11)
                       (i32.const 3)
                      )
                     )
                    )
                    (ref.eq
                     (local.get $0)
                     (global.get $uninitialized)
                    )
                   )
                  )
                  (if
                   (ref.test (ref $values)
                    (local.get $0)
                   )
                   (then
                    (br_if $block1
                     (i32.ne
                      (array.len
                       (local.tee $6
                        (struct.get $values 0
                         (ref.cast (ref $values)
                          (local.get $0)
                         )
                        )
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (br $block8
                     (array.get $vector
                      (local.get $6)
                      (i32.const 0)
                     )
                    )
                   )
                  )
                  (local.get $0)
                 )
                )
               )
              )
              (array.new_fixed $vector 1
               (local.get $1)
              )
              (ref.null none)
              (struct.get $closure 0
               (local.get $13)
              )
             )
            )
           )
           (then
            (br_if $block1
             (i32.ne
              (array.len
               (local.tee $6
                (struct.get $values 0
                 (ref.cast (ref $values)
                  (local.get $0)
                 )
                )
               )
              )
              (i32.const 1)
             )
            )
            (br $block9
             (array.get $vector
              (local.get $6)
              (i32.const 0)
             )
            )
           )
          )
          (local.get $0)
         )
         (global.get $false)
        )
        (then
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g151)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $5)
          )
         )
         (drop
          (call $awi_take
           (call $rust88
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 1
               (global.get $literal22)
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (drop
          (call $awi_take
           (call $rust89
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 1
               (block (result eqref)
                (local.set $scratch
                 (block $block10 (result eqref)
                  (br_if $block
                   (i32.or
                    (ref.is_null
                     (local.get $2)
                    )
                    (ref.eq
                     (local.get $2)
                     (global.get $uninitialized)
                    )
                   )
                  )
                  (if
                   (ref.test (ref $values)
                    (local.get $2)
                   )
                   (then
                    (br_if $block1
                     (i32.ne
                      (array.len
                       (local.tee $6
                        (struct.get $values 0
                         (ref.cast (ref $values)
                          (local.get $2)
                         )
                        )
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (br $block10
                     (array.get $vector
                      (local.get $6)
                      (i32.const 0)
                     )
                    )
                   )
                  )
                  (local.get $2)
                 )
                )
                (br_if $block
                 (ref.is_null
                  (local.tee $5
                   (global.get $g152)
                  )
                 )
                )
                (drop
                 (struct.get $closure 1
                  (local.get $5)
                 )
                )
                (local.get $scratch)
               )
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g156)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $5)
          )
         )
         (drop
          (call $awi_take
           (call $rust93
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 0)
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g151)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $5)
          )
         )
         (drop
          (call $awi_take
           (call $rust88
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 1
               (global.get $literal23)
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g249)
           )
          )
         )
         (drop
          (ref.as_non_null
           (local.get $5)
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g151)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $5)
          )
         )
         (drop
          (call $awi_take
           (call $rust88
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 1
               (global.get $literal14)
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g151)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $5)
          )
         )
         (drop
          (call $awi_take
           (call $rust88
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 1
               (global.get $literal24)
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (drop
          (call $awi_take
           (call $rust88
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 1
               (block (result eqref)
                (local.set $scratch_17
                 (block $block11 (result eqref)
                  (br_if $block
                   (i32.or
                    (ref.is_null
                     (local.tee $0
                      (array.get $vector
                       (local.get $11)
                       (i32.const 4)
                      )
                     )
                    )
                    (ref.eq
                     (local.get $0)
                     (global.get $uninitialized)
                    )
                   )
                  )
                  (if
                   (ref.test (ref $values)
                    (local.get $0)
                   )
                   (then
                    (br_if $block1
                     (i32.ne
                      (array.len
                       (local.tee $6
                        (struct.get $values 0
                         (ref.cast (ref $values)
                          (local.get $0)
                         )
                        )
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (br $block11
                     (array.get $vector
                      (local.get $6)
                      (i32.const 0)
                     )
                    )
                   )
                  )
                  (local.get $0)
                 )
                )
                (br_if $block
                 (ref.is_null
                  (local.tee $5
                   (global.get $g151)
                  )
                 )
                )
                (drop
                 (struct.get $closure 1
                  (local.get $5)
                 )
                )
                (local.get $scratch_17)
               )
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g151)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $5)
          )
         )
         (drop
          (call $awi_take
           (call $rust88
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 1
               (global.get $literal25)
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g151)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $5)
          )
         )
         (drop
          (call $awi_take
           (call $rust88
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 1
               (global.get $literal26)
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (br_if $block
          (ref.is_null
           (local.tee $5
            (global.get $g156)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $5)
          )
         )
         (drop
          (call $awi_take
           (call $rust93
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 0)
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (drop
          (call $awi_take
           (call $rust92
            (local.tee $4
             (call $awi_root
              (array.new_fixed $vector 1
               (block (result eqref)
                (local.set $scratch_18
                 (block $block12 (result eqref)
                  (br_if $block
                   (ref.is_null
                    (local.tee $5
                     (global.get $g241)
                    )
                   )
                  )
                  (if
                   (ref.test (ref $values)
                    (local.tee $0
                     (call_ref $call
                      (struct.get $closure 1
                       (local.tee $14
                        (ref.as_non_null
                         (local.get $5)
                        )
                       )
                      )
                      (array.new_fixed $vector 0)
                      (ref.null none)
                      (struct.get $closure 0
                       (local.get $14)
                      )
                     )
                    )
                   )
                   (then
                    (br_if $block1
                     (i32.ne
                      (array.len
                       (local.tee $6
                        (struct.get $values 0
                         (ref.cast (ref $values)
                          (local.get $0)
                         )
                        )
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (br $block12
                     (array.get $vector
                      (local.get $6)
                      (i32.const 0)
                     )
                    )
                   )
                  )
                  (local.get $0)
                 )
                )
                (br_if $block
                 (ref.is_null
                  (local.tee $5
                   (global.get $g155)
                  )
                 )
                )
                (drop
                 (struct.get $closure 1
                  (local.get $5)
                 )
                )
                (local.get $scratch_18)
               )
              )
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $4)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $4)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $4)
          )
         )
         (table.set $awi_roots
          (local.get $4)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $4)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $4)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
        )
        (else
         (local.set $1
          (block $block13 (result eqref)
           (br_if $block
            (ref.is_null
             (local.tee $5
              (global.get $g167)
             )
            )
           )
           (drop
            (struct.get $closure 1
             (local.get $5)
            )
           )
           (local.set $0
            (call $awi_take
             (call $rust103
              (local.tee $4
               (call $awi_root
                (array.new_fixed $vector 0)
               )
              )
             )
            )
           )
           (if
            (i32.ge_u
             (local.get $4)
             (global.get $awi_used)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.ne
             (array.get $text
              (global.get $awi_links)
              (local.get $4)
             )
             (i32.const -1)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (table.get $awi_roots
             (local.get $4)
            )
           )
           (table.set $awi_roots
            (local.get $4)
            (ref.null none)
           )
           (array.set $text
            (global.get $awi_links)
            (local.get $4)
            (global.get $awi_free)
           )
           (global.set $awi_free
            (local.get $4)
           )
           (global.set $awi_live
            (i32.sub
             (global.get $awi_live)
             (i32.const 1)
            )
           )
           (if
            (ref.test (ref $values)
             (local.get $0)
            )
            (then
             (br_if $block1
              (i32.ne
               (array.len
                (local.tee $6
                 (struct.get $values 0
                  (ref.cast (ref $values)
                   (local.get $0)
                  )
                 )
                )
               )
               (i32.const 1)
              )
             )
             (br $block13
              (array.get $vector
               (local.get $6)
               (i32.const 0)
              )
             )
            )
           )
           (local.get $0)
          )
         )
         (drop
          (block $block26 (result eqref)
           (local.set $0
            (array.get $vector
             (local.get $11)
             (i32.const 4)
            )
           )
           (local.set $9
            (array.get $vector
             (local.get $11)
             (i32.const 5)
            )
           )
           (local.set $2
            (array.get $vector
             (local.get $11)
             (i32.const 6)
            )
           )
           (local.set $10
            (array.get $vector
             (local.get $11)
             (i32.const 7)
            )
           )
           (local.set $7
            (array.get $vector
             (local.get $11)
             (i32.const 8)
            )
           )
           (block $block15
            (br_if $block15
             (i32.or
              (ref.is_null
               (local.tee $8
                (block $block14 (result eqref)
                 (br_if $block
                  (ref.is_null
                   (local.tee $5
                    (global.get $g168)
                   )
                  )
                 )
                 (drop
                  (struct.get $closure 1
                   (local.get $5)
                  )
                 )
                 (local.set $8
                  (call $awi_take
                   (call $rust104
                    (local.tee $4
                     (call $awi_root
                      (array.new_fixed $vector 0)
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.ge_u
                   (local.get $4)
                   (global.get $awi_used)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.ne
                   (array.get $text
                    (global.get $awi_links)
                    (local.get $4)
                   )
                   (i32.const -1)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (table.get $awi_roots
                   (local.get $4)
                  )
                 )
                 (table.set $awi_roots
                  (local.get $4)
                  (ref.null none)
                 )
                 (array.set $text
                  (global.get $awi_links)
                  (local.get $4)
                  (global.get $awi_free)
                 )
                 (global.set $awi_free
                  (local.get $4)
                 )
                 (global.set $awi_live
                  (i32.sub
                   (global.get $awi_live)
                   (i32.const 1)
                  )
                 )
                 (if
                  (ref.test (ref $values)
                   (local.get $8)
                  )
                  (then
                   (br_if $block1
                    (i32.ne
                     (array.len
                      (local.tee $6
                       (struct.get $values 0
                        (ref.cast (ref $values)
                         (local.get $8)
                        )
                       )
                      )
                     )
                     (i32.const 1)
                    )
                   )
                   (br $block14
                    (array.get $vector
                     (local.get $6)
                     (i32.const 0)
                    )
                   )
                  )
                 )
                 (local.get $8)
                )
               )
              )
              (ref.eq
               (local.get $8)
               (global.get $uninitialized)
              )
             )
            )
            (br_if $block15
             (i32.or
              (ref.is_null
               (local.get $7)
              )
              (ref.eq
               (local.get $7)
               (global.get $uninitialized)
              )
             )
            )
            (br_if $block15
             (i32.or
              (ref.is_null
               (local.tee $7
                (if (result eqref)
                 (i32.and
                  (ref.test (ref i31)
                   (local.get $8)
                  )
                  (ref.test (ref i31)
                   (local.get $7)
                  )
                 )
                 (then
                  (if (result eqref)
                   (i32.le_u
                    (i32.add
                     (local.tee $4
                      (i32.sub
                       (i31.get_s
                        (ref.cast (ref i31)
                         (local.get $8)
                        )
                       )
                       (i31.get_s
                        (ref.cast (ref i31)
                         (local.get $7)
                        )
                       )
                      )
                     )
                     (i32.const 1073741824)
                    )
                    (i32.const 2147483647)
                   )
                   (then
                    (ref.i31
                     (local.get $4)
                    )
                   )
                   (else
                    (call $cold.checked_subtract
                     (local.get $8)
                     (local.get $7)
                    )
                   )
                  )
                 )
                 (else
                  (call $cold.checked_subtract
                   (local.get $8)
                   (local.get $7)
                  )
                 )
                )
               )
              )
              (ref.eq
               (local.get $7)
               (global.get $uninitialized)
              )
             )
            )
            (br_if $block15
             (i32.or
              (ref.is_null
               (local.get $10)
              )
              (ref.eq
               (local.get $10)
               (global.get $uninitialized)
              )
             )
            )
            (local.set $7
             (call $divide
              (local.get $7)
              (local.get $10)
             )
            )
            (br $block26
             (block $block25 (result eqref)
              (local.set $7
               (block $block16 (result eqref)
                (br_if $block15
                 (ref.is_null
                  (local.tee $5
                   (global.get $g13)
                  )
                 )
                )
                (drop
                 (struct.get $closure 1
                  (local.get $5)
                 )
                )
                (local.set $7
                 (call $awi_take
                  (call $rust20
                   (local.tee $4
                    (call $awi_root
                     (array.new_fixed $vector 1
                      (local.get $7)
                     )
                    )
                   )
                  )
                 )
                )
                (if
                 (i32.ge_u
                  (local.get $4)
                  (global.get $awi_used)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.ne
                  (array.get $text
                   (global.get $awi_links)
                   (local.get $4)
                  )
                  (i32.const -1)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (table.get $awi_roots
                  (local.get $4)
                 )
                )
                (table.set $awi_roots
                 (local.get $4)
                 (ref.null none)
                )
                (array.set $text
                 (global.get $awi_links)
                 (local.get $4)
                 (global.get $awi_free)
                )
                (global.set $awi_free
                 (local.get $4)
                )
                (global.set $awi_live
                 (i32.sub
                  (global.get $awi_live)
                  (i32.const 1)
                 )
                )
                (if
                 (ref.test (ref $values)
                  (local.get $7)
                 )
                 (then
                  (br_if $block1
                   (i32.ne
                    (array.len
                     (local.tee $6
                      (struct.get $values 0
                       (ref.cast (ref $values)
                        (local.get $7)
                       )
                      )
                     )
                    )
                    (i32.const 1)
                   )
                  )
                  (br $block16
                   (array.get $vector
                    (local.get $6)
                    (i32.const 0)
                   )
                  )
                 )
                )
                (local.get $7)
               )
              )
              (br_if $block
               (i32.or
                (ref.is_null
                 (local.get $1)
                )
                (ref.eq
                 (local.get $1)
                 (global.get $uninitialized)
                )
               )
              )
              (br_if $block
               (i32.or
                (ref.is_null
                 (local.get $2)
                )
                (ref.eq
                 (local.get $2)
                 (global.get $uninitialized)
                )
               )
              )
              (local.set $1
               (if (result eqref)
                (i32.and
                 (ref.test (ref i31)
                  (local.get $1)
                 )
                 (ref.test (ref i31)
                  (local.get $2)
                 )
                )
                (then
                 (if (result eqref)
                  (i32.le_u
                   (i32.add
                    (local.tee $4
                     (i32.sub
                      (i31.get_s
                       (ref.cast (ref i31)
                        (local.get $1)
                       )
                      )
                      (i31.get_s
                       (ref.cast (ref i31)
                        (local.get $2)
                       )
                      )
                     )
                    )
                    (i32.const 1073741824)
                   )
                   (i32.const 2147483647)
                  )
                  (then
                   (ref.i31
                    (local.get $4)
                   )
                  )
                  (else
                   (call $cold.checked_subtract
                    (local.get $1)
                    (local.get $2)
                   )
                  )
                 )
                )
                (else
                 (call $cold.checked_subtract
                  (local.get $1)
                  (local.get $2)
                 )
                )
               )
              )
              (br_if $block
               (i32.or
                (ref.is_null
                 (local.get $9)
                )
                (ref.eq
                 (local.get $9)
                 (global.get $uninitialized)
                )
               )
              )
              (drop
               (ref.cast (ref $closure)
                (local.get $9)
               )
              )
              (block $block17
               (local.set $1
                (call $multiply
                 (local.tee $12
                  (ref.i31
                   (i32.const 1000)
                  )
                 )
                 (block $block18 (result eqref)
                  (br_if $block
                   (i32.or
                    (ref.is_null
                     (local.get $1)
                    )
                    (ref.eq
                     (local.get $1)
                     (global.get $uninitialized)
                    )
                   )
                  )
                  (if
                   (ref.test (ref $values)
                    (local.get $1)
                   )
                   (then
                    (br_if $block17
                     (i32.ne
                      (array.len
                       (local.tee $6
                        (struct.get $values 0
                         (ref.cast (ref $values)
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (i32.const 1)
                     )
                    )
                    (br $block18
                     (array.get $vector
                      (local.get $6)
                      (i32.const 0)
                     )
                    )
                   )
                  )
                  (local.get $1)
                 )
                )
               )
               (br $block25
                (block $block24 (result eqref)
                 (local.set $1
                  (call $divide
                   (block $block19 (result eqref)
                    (br_if $block
                     (ref.is_null
                      (local.tee $5
                       (global.get $g18)
                      )
                     )
                    )
                    (drop
                     (struct.get $closure 1
                      (local.get $5)
                     )
                    )
                    (local.set $1
                     (call $awi_take
                      (call $rust24
                       (local.tee $4
                        (call $awi_root
                         (array.new_fixed $vector 1
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                    )
                    (if
                     (i32.ge_u
                      (local.get $4)
                      (global.get $awi_used)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.ne
                      (array.get $text
                       (global.get $awi_links)
                       (local.get $4)
                      )
                      (i32.const -1)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (table.get $awi_roots
                      (local.get $4)
                     )
                    )
                    (table.set $awi_roots
                     (local.get $4)
                     (ref.null none)
                    )
                    (array.set $text
                     (global.get $awi_links)
                     (local.get $4)
                     (global.get $awi_free)
                    )
                    (global.set $awi_free
                     (local.get $4)
                    )
                    (global.set $awi_live
                     (i32.sub
                      (global.get $awi_live)
                      (i32.const 1)
                     )
                    )
                    (if
                     (ref.test (ref $values)
                      (local.get $1)
                     )
                     (then
                      (br_if $block17
                       (i32.ne
                        (array.len
                         (local.tee $6
                          (struct.get $values 0
                           (ref.cast (ref $values)
                            (local.get $1)
                           )
                          )
                         )
                        )
                        (i32.const 1)
                       )
                      )
                      (br $block19
                       (array.get $vector
                        (local.get $6)
                        (i32.const 0)
                       )
                      )
                     )
                    )
                    (local.get $1)
                   )
                   (local.get $12)
                  )
                 )
                 (br_if $block
                  (ref.is_null
                   (local.tee $5
                    (global.get $g151)
                   )
                  )
                 )
                 (drop
                  (struct.get $closure 1
                   (local.get $5)
                  )
                 )
                 (drop
                  (call $awi_take
                   (call $rust88
                    (local.tee $4
                     (call $awi_root
                      (array.new_fixed $vector 1
                       (global.get $literal16)
                      )
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.ge_u
                   (local.get $4)
                   (global.get $awi_used)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.ne
                   (array.get $text
                    (global.get $awi_links)
                    (local.get $4)
                   )
                   (i32.const -1)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (table.get $awi_roots
                   (local.get $4)
                  )
                 )
                 (table.set $awi_roots
                  (local.get $4)
                  (ref.null none)
                 )
                 (array.set $text
                  (global.get $awi_links)
                  (local.get $4)
                  (global.get $awi_free)
                 )
                 (global.set $awi_free
                  (local.get $4)
                 )
                 (global.set $awi_live
                  (i32.sub
                   (global.get $awi_live)
                   (i32.const 1)
                  )
                 )
                 (br_if $block
                  (i32.or
                   (ref.is_null
                    (local.get $7)
                   )
                   (ref.eq
                    (local.get $7)
                    (global.get $uninitialized)
                   )
                  )
                 )
                 (br_if $block
                  (ref.is_null
                   (local.tee $5
                    (global.get $g152)
                   )
                  )
                 )
                 (drop
                  (struct.get $closure 1
                   (local.get $5)
                  )
                 )
                 (drop
                  (call $awi_take
                   (call $rust89
                    (local.tee $4
                     (call $awi_root
                      (array.new_fixed $vector 1
                       (local.get $7)
                      )
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.ge_u
                   (local.get $4)
                   (global.get $awi_used)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.ne
                   (array.get $text
                    (global.get $awi_links)
                    (local.get $4)
                   )
                   (i32.const -1)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (table.get $awi_roots
                   (local.get $4)
                  )
                 )
                 (table.set $awi_roots
                  (local.get $4)
                  (ref.null none)
                 )
                 (array.set $text
                  (global.get $awi_links)
                  (local.get $4)
                  (global.get $awi_free)
                 )
                 (global.set $awi_free
                  (local.get $4)
                 )
                 (global.set $awi_live
                  (i32.sub
                   (global.get $awi_live)
                   (i32.const 1)
                  )
                 )
                 (br_if $block
                  (ref.is_null
                   (local.tee $5
                    (global.get $g151)
                   )
                  )
                 )
                 (drop
                  (struct.get $closure 1
                   (local.get $5)
                  )
                 )
                 (drop
                  (call $awi_take
                   (call $rust88
                    (local.tee $4
                     (call $awi_root
                      (array.new_fixed $vector 1
                       (global.get $literal17)
                      )
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.ge_u
                   (local.get $4)
                   (global.get $awi_used)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.ne
                   (array.get $text
                    (global.get $awi_links)
                    (local.get $4)
                   )
                   (i32.const -1)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (table.get $awi_roots
                   (local.get $4)
                  )
                 )
                 (table.set $awi_roots
                  (local.get $4)
                  (ref.null none)
                 )
                 (array.set $text
                  (global.get $awi_links)
                  (local.get $4)
                  (global.get $awi_free)
                 )
                 (global.set $awi_free
                  (local.get $4)
                 )
                 (global.set $awi_live
                  (i32.sub
                   (global.get $awi_live)
                   (i32.const 1)
                  )
                 )
                 (br_if $block
                  (i32.or
                   (ref.is_null
                    (local.get $1)
                   )
                   (ref.eq
                    (local.get $1)
                    (global.get $uninitialized)
                   )
                  )
                 )
                 (br_if $block
                  (ref.is_null
                   (local.tee $5
                    (global.get $g152)
                   )
                  )
                 )
                 (drop
                  (struct.get $closure 1
                   (local.get $5)
                  )
                 )
                 (drop
                  (call $awi_take
                   (call $rust89
                    (local.tee $4
                     (call $awi_root
                      (array.new_fixed $vector 1
                       (local.get $1)
                      )
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.ge_u
                   (local.get $4)
                   (global.get $awi_used)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.ne
                   (array.get $text
                    (global.get $awi_links)
                    (local.get $4)
                   )
                   (i32.const -1)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (table.get $awi_roots
                   (local.get $4)
                  )
                 )
                 (table.set $awi_roots
                  (local.get $4)
                  (ref.null none)
                 )
                 (array.set $text
                  (global.get $awi_links)
                  (local.get $4)
                  (global.get $awi_free)
                 )
                 (global.set $awi_free
                  (local.get $4)
                 )
                 (global.set $awi_live
                  (i32.sub
                   (global.get $awi_live)
                   (i32.const 1)
                  )
                 )
                 (br_if $block
                  (ref.is_null
                   (local.tee $5
                    (global.get $g151)
                   )
                  )
                 )
                 (drop
                  (struct.get $closure 1
                   (local.get $5)
                  )
                 )
                 (drop
                  (call $awi_take
                   (call $rust88
                    (local.tee $4
                     (call $awi_root
                      (array.new_fixed $vector 1
                       (global.get $literal18)
                      )
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.ge_u
                   (local.get $4)
                   (global.get $awi_used)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if
                  (i32.ne
                   (array.get $text
                    (global.get $awi_links)
                    (local.get $4)
                   )
                   (i32.const -1)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (table.get $awi_roots
                   (local.get $4)
                  )
                 )
                 (table.set $awi_roots
                  (local.get $4)
                  (ref.null none)
                 )
                 (array.set $text
                  (global.get $awi_links)
                  (local.get $4)
                  (global.get $awi_free)
                 )
                 (global.set $awi_free
                  (local.get $4)
                 )
                 (global.set $awi_live
                  (i32.sub
                   (global.get $awi_live)
                   (i32.const 1)
                  )
                 )
                 (block $block20
                  (drop
                   (call $awi_take
                    (call $rust88
                     (local.tee $4
                      (call $awi_root
                       (array.new_fixed $vector 1
                        (block (result eqref)
                         (local.set $scratch_19
                          (block $block21 (result eqref)
                           (br_if $block
                            (i32.or
                             (ref.is_null
                              (local.get $0)
                             )
                             (ref.eq
                              (local.get $0)
                              (global.get $uninitialized)
                             )
                            )
                           )
                           (if
                            (ref.test (ref $values)
                             (local.get $0)
                            )
                            (then
                             (br_if $block20
                              (i32.ne
                               (array.len
                                (local.tee $6
                                 (struct.get $values 0
                                  (ref.cast (ref $values)
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                               (i32.const 1)
                              )
                             )
                             (br $block21
                              (array.get $vector
                               (local.get $6)
                               (i32.const 0)
                              )
                             )
                            )
                           )
                           (local.get $0)
                          )
                         )
                         (br_if $block
                          (ref.is_null
                           (local.tee $5
                            (global.get $g151)
                           )
                          )
                         )
                         (drop
                          (struct.get $closure 1
                           (local.get $5)
                          )
                         )
                         (local.get $scratch_19)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.ge_u
                    (local.get $4)
                    (global.get $awi_used)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.ne
                    (array.get $text
                     (global.get $awi_links)
                     (local.get $4)
                    )
                    (i32.const -1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (table.get $awi_roots
                    (local.get $4)
                   )
                  )
                  (table.set $awi_roots
                   (local.get $4)
                   (ref.null none)
                  )
                  (array.set $text
                   (global.get $awi_links)
                   (local.get $4)
                   (global.get $awi_free)
                  )
                  (global.set $awi_free
                   (local.get $4)
                  )
                  (global.set $awi_live
                   (i32.sub
                    (global.get $awi_live)
                    (i32.const 1)
                   )
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $5
                     (global.get $g156)
                    )
                   )
                  )
                  (drop
                   (struct.get $closure 1
                    (local.get $5)
                   )
                  )
                  (drop
                   (call $awi_take
                    (call $rust93
                     (local.tee $4
                      (call $awi_root
                       (array.new_fixed $vector 0)
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.ge_u
                    (local.get $4)
                    (global.get $awi_used)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.ne
                    (array.get $text
                     (global.get $awi_links)
                     (local.get $4)
                    )
                    (i32.const -1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (table.get $awi_roots
                    (local.get $4)
                   )
                  )
                  (table.set $awi_roots
                   (local.get $4)
                   (ref.null none)
                  )
                  (array.set $text
                   (global.get $awi_links)
                   (local.get $4)
                   (global.get $awi_free)
                  )
                  (global.set $awi_free
                   (local.get $4)
                  )
                  (global.set $awi_live
                   (i32.sub
                    (global.get $awi_live)
                    (i32.const 1)
                   )
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $5
                     (global.get $g151)
                    )
                   )
                  )
                  (drop
                   (struct.get $closure 1
                    (local.get $5)
                   )
                  )
                  (drop
                   (call $awi_take
                    (call $rust88
                     (local.tee $4
                      (call $awi_root
                       (array.new_fixed $vector 1
                        (global.get $literal19)
                       )
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.ge_u
                    (local.get $4)
                    (global.get $awi_used)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.ne
                    (array.get $text
                     (global.get $awi_links)
                     (local.get $4)
                    )
                    (i32.const -1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (table.get $awi_roots
                    (local.get $4)
                   )
                  )
                  (table.set $awi_roots
                   (local.get $4)
                   (ref.null none)
                  )
                  (array.set $text
                   (global.get $awi_links)
                   (local.get $4)
                   (global.get $awi_free)
                  )
                  (global.set $awi_free
                   (local.get $4)
                  )
                  (global.set $awi_live
                   (i32.sub
                    (global.get $awi_live)
                    (i32.const 1)
                   )
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $5
                     (global.get $g249)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (local.get $5)
                   )
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $5
                     (global.get $g151)
                    )
                   )
                  )
                  (drop
                   (struct.get $closure 1
                    (local.get $5)
                   )
                  )
                  (drop
                   (call $awi_take
                    (call $rust88
                     (local.tee $4
                      (call $awi_root
                       (array.new_fixed $vector 1
                        (global.get $literal14)
                       )
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.ge_u
                    (local.get $4)
                    (global.get $awi_used)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.ne
                    (array.get $text
                     (global.get $awi_links)
                     (local.get $4)
                    )
                    (i32.const -1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (table.get $awi_roots
                    (local.get $4)
                   )
                  )
                  (table.set $awi_roots
                   (local.get $4)
                   (ref.null none)
                  )
                  (array.set $text
                   (global.get $awi_links)
                   (local.get $4)
                   (global.get $awi_free)
                  )
                  (global.set $awi_free
                   (local.get $4)
                  )
                  (global.set $awi_live
                   (i32.sub
                    (global.get $awi_live)
                    (i32.const 1)
                   )
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $5
                     (global.get $g151)
                    )
                   )
                  )
                  (drop
                   (struct.get $closure 1
                    (local.get $5)
                   )
                  )
                  (drop
                   (call $awi_take
                    (call $rust88
                     (local.tee $4
                      (call $awi_root
                       (array.new_fixed $vector 1
                        (global.get $literal20)
                       )
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.ge_u
                    (local.get $4)
                    (global.get $awi_used)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.ne
                    (array.get $text
                     (global.get $awi_links)
                     (local.get $4)
                    )
                    (i32.const -1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (table.get $awi_roots
                    (local.get $4)
                   )
                  )
                  (table.set $awi_roots
                   (local.get $4)
                   (ref.null none)
                  )
                  (array.set $text
                   (global.get $awi_links)
                   (local.get $4)
                   (global.get $awi_free)
                  )
                  (global.set $awi_free
                   (local.get $4)
                  )
                  (global.set $awi_live
                   (i32.sub
                    (global.get $awi_live)
                    (i32.const 1)
                   )
                  )
                  (drop
                   (call $awi_take
                    (call $rust88
                     (local.tee $4
                      (call $awi_root
                       (array.new_fixed $vector 1
                        (block (result eqref)
                         (local.set $scratch_20
                          (block $block22 (result eqref)
                           (br_if $block
                            (i32.or
                             (ref.is_null
                              (local.get $0)
                             )
                             (ref.eq
                              (local.get $0)
                              (global.get $uninitialized)
                             )
                            )
                           )
                           (if
                            (ref.test (ref $values)
                             (local.get $0)
                            )
                            (then
                             (br_if $block20
                              (i32.ne
                               (array.len
                                (local.tee $6
                                 (struct.get $values 0
                                  (ref.cast (ref $values)
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                               (i32.const 1)
                              )
                             )
                             (br $block22
                              (array.get $vector
                               (local.get $6)
                               (i32.const 0)
                              )
                             )
                            )
                           )
                           (local.get $0)
                          )
                         )
                         (br_if $block
                          (ref.is_null
                           (local.tee $5
                            (global.get $g151)
                           )
                          )
                         )
                         (drop
                          (struct.get $closure 1
                           (local.get $5)
                          )
                         )
                         (local.get $scratch_20)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.ge_u
                    (local.get $4)
                    (global.get $awi_used)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.ne
                    (array.get $text
                     (global.get $awi_links)
                     (local.get $4)
                    )
                    (i32.const -1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (table.get $awi_roots
                    (local.get $4)
                   )
                  )
                  (table.set $awi_roots
                   (local.get $4)
                   (ref.null none)
                  )
                  (array.set $text
                   (global.get $awi_links)
                   (local.get $4)
                   (global.get $awi_free)
                  )
                  (global.set $awi_free
                   (local.get $4)
                  )
                  (global.set $awi_live
                   (i32.sub
                    (global.get $awi_live)
                    (i32.const 1)
                   )
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $5
                     (global.get $g151)
                    )
                   )
                  )
                  (drop
                   (struct.get $closure 1
                    (local.get $5)
                   )
                  )
                  (drop
                   (call $awi_take
                    (call $rust88
                     (local.tee $4
                      (call $awi_root
                       (array.new_fixed $vector 1
                        (global.get $literal21)
                       )
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.ge_u
                    (local.get $4)
                    (global.get $awi_used)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.ne
                    (array.get $text
                     (global.get $awi_links)
                     (local.get $4)
                    )
                    (i32.const -1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (table.get $awi_roots
                    (local.get $4)
                   )
                  )
                  (table.set $awi_roots
                   (local.get $4)
                   (ref.null none)
                  )
                  (array.set $text
                   (global.get $awi_links)
                   (local.get $4)
                   (global.get $awi_free)
                  )
                  (global.set $awi_free
                   (local.get $4)
                  )
                  (global.set $awi_live
                   (i32.sub
                    (global.get $awi_live)
                    (i32.const 1)
                   )
                  )
                  (br_if $block
                   (i32.or
                    (ref.is_null
                     (local.get $7)
                    )
                    (ref.eq
                     (local.get $7)
                     (global.get $uninitialized)
                    )
                   )
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $5
                     (global.get $g151)
                    )
                   )
                  )
                  (drop
                   (struct.get $closure 1
                    (local.get $5)
                   )
                  )
                  (drop
                   (call $awi_take
                    (call $rust88
                     (local.tee $4
                      (call $awi_root
                       (array.new_fixed $vector 1
                        (local.get $7)
                       )
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.ge_u
                    (local.get $4)
                    (global.get $awi_used)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.ne
                    (array.get $text
                     (global.get $awi_links)
                     (local.get $4)
                    )
                    (i32.const -1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (table.get $awi_roots
                    (local.get $4)
                   )
                  )
                  (table.set $awi_roots
                   (local.get $4)
                   (ref.null none)
                  )
                  (array.set $text
                   (global.get $awi_links)
                   (local.get $4)
                   (global.get $awi_free)
                  )
                  (global.set $awi_free
                   (local.get $4)
                  )
                  (global.set $awi_live
                   (i32.sub
                    (global.get $awi_live)
                    (i32.const 1)
                   )
                  )
                  (br_if $block
                   (ref.is_null
                    (local.tee $5
                     (global.get $g156)
                    )
                   )
                  )
                  (drop
                   (struct.get $closure 1
                    (local.get $5)
                   )
                  )
                  (drop
                   (call $awi_take
                    (call $rust93
                     (local.tee $4
                      (call $awi_root
                       (array.new_fixed $vector 0)
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.ge_u
                    (local.get $4)
                    (global.get $awi_used)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.ne
                    (array.get $text
                     (global.get $awi_links)
                     (local.get $4)
                    )
                    (i32.const -1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (table.get $awi_roots
                    (local.get $4)
                   )
                  )
                  (table.set $awi_roots
                   (local.get $4)
                   (ref.null none)
                  )
                  (array.set $text
                   (global.get $awi_links)
                   (local.get $4)
                   (global.get $awi_free)
                  )
                  (global.set $awi_free
                   (local.get $4)
                  )
                  (global.set $awi_live
                   (i32.sub
                    (global.get $awi_live)
                    (i32.const 1)
                   )
                  )
                  (br $block24
                   (block (result eqref)
                    (local.set $scratch_22
                     (call $awi_take
                      (call $rust92
                       (local.tee $4
                        (call $awi_root
                         (array.new_fixed $vector 1
                          (block (result eqref)
                           (local.set $scratch_21
                            (block $block23 (result eqref)
                             (br_if $block
                              (ref.is_null
                               (local.tee $5
                                (global.get $g241)
                               )
                              )
                             )
                             (if
                              (ref.test (ref $values)
                               (local.tee $0
                                (call_ref $call
                                 (struct.get $closure 1
                                  (local.tee $14
                                   (ref.as_non_null
                                    (local.get $5)
                                   )
                                  )
                                 )
                                 (array.new_fixed $vector 0)
                                 (ref.null none)
                                 (struct.get $closure 0
                                  (local.get $14)
                                 )
                                )
                               )
                              )
                              (then
                               (br_if $block20
                                (i32.ne
                                 (array.len
                                  (local.tee $6
                                   (struct.get $values 0
                                    (ref.cast (ref $values)
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (i32.const 1)
                                )
                               )
                               (br $block23
                                (array.get $vector
                                 (local.get $6)
                                 (i32.const 0)
                                )
                               )
                              )
                             )
                             (local.get $0)
                            )
                           )
                           (br_if $block
                            (ref.is_null
                             (local.tee $5
                              (global.get $g155)
                             )
                            )
                           )
                           (drop
                            (struct.get $closure 1
                             (local.get $5)
                            )
                           )
                           (local.get $scratch_21)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                    (if
                     (i32.ge_u
                      (local.get $4)
                      (global.get $awi_used)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.ne
                      (array.get $text
                       (global.get $awi_links)
                       (local.get $4)
                      )
                      (i32.const -1)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (table.get $awi_roots
                      (local.get $4)
                     )
                    )
                    (table.set $awi_roots
                     (local.get $4)
                     (ref.null none)
                    )
                    (array.set $text
                     (global.get $awi_links)
                     (local.get $4)
                     (global.get $awi_free)
                    )
                    (global.set $awi_free
                     (local.get $4)
                    )
                    (global.set $awi_live
                     (i32.sub
                      (global.get $awi_live)
                      (i32.const 1)
                     )
                    )
                    (local.get $scratch_22)
                   )
                  )
                 )
                 (br $block17)
                )
               )
              )
              (br $block1)
             )
            )
           )
           (br $block)
          )
         )
        )
       )
       (ref.i31
        (i32.const 0)
       )
      )
     )
    )
   )
   (global.set $error_code
    (i32.const 6)
   )
   (drop
    (call $rust_fail
     (i32.const 6)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 5)
  )
  (drop
   (call $rust_fail
    (i32.const 5)
   )
  )
  (unreachable)
 )
 (func $adapter146 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 2)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 2)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function146
   (local.get $0)
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
   (local.get $2)
  )
 )
 (func $function139 (type $2) (param $0 eqref) (param $1 eqref) (param $2 eqref) (param $3 eqref) (param $4 nullref) (result eqref)
  (local $5 i32)
  (local $6 eqref)
  (local $7 eqref)
  (local $8 eqref)
  (local $9 (ref null $closure))
  (local $10 (ref $vector))
  (local $11 (ref $closure))
  (local $12 (ref $closure))
  (local $13 (ref $cell))
  (local $14 (ref struct))
  (local $scratch eqref)
  (local $scratch_16 eqref)
  (block $block
   (br_if $block
    (ref.is_null
     (local.tee $9
      (global.get $g151)
     )
    )
   )
   (drop
    (struct.get $closure 1
     (local.get $9)
    )
   )
   (drop
    (call $awi_take
     (call $rust88
      (local.tee $5
       (call $awi_root
        (array.new_fixed $vector 1
         (global.get $literal15)
        )
       )
      )
     )
    )
   )
   (if
    (i32.ge_u
     (local.get $5)
     (global.get $awi_used)
    )
    (then
     (unreachable)
    )
   )
   (if
    (i32.ne
     (array.get $text
      (global.get $awi_links)
      (local.get $5)
     )
     (i32.const -1)
    )
    (then
     (unreachable)
    )
   )
   (drop
    (table.get $awi_roots
     (local.get $5)
    )
   )
   (table.set $awi_roots
    (local.get $5)
    (ref.null none)
   )
   (array.set $text
    (global.get $awi_links)
    (local.get $5)
    (global.get $awi_free)
   )
   (global.set $awi_free
    (local.get $5)
   )
   (global.set $awi_live
    (i32.sub
     (global.get $awi_live)
     (i32.const 1)
    )
   )
   (block $block1
    (drop
     (call $awi_take
      (call $rust88
       (local.tee $5
        (call $awi_root
         (array.new_fixed $vector 1
          (block (result eqref)
           (local.set $scratch
            (block $block2 (result eqref)
             (br_if $block
              (i32.or
               (ref.is_null
                (local.get $0)
               )
               (ref.eq
                (local.get $0)
                (global.get $uninitialized)
               )
              )
             )
             (if
              (ref.test (ref $values)
               (local.get $0)
              )
              (then
               (br_if $block1
                (i32.ne
                 (array.len
                  (local.tee $10
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block2
                (array.get $vector
                 (local.get $10)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $0)
            )
           )
           (br_if $block
            (ref.is_null
             (local.tee $9
              (global.get $g151)
             )
            )
           )
           (drop
            (struct.get $closure 1
             (local.get $9)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.ge_u
      (local.get $5)
      (global.get $awi_used)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (array.get $text
       (global.get $awi_links)
       (local.get $5)
      )
      (i32.const -1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (table.get $awi_roots
      (local.get $5)
     )
    )
    (table.set $awi_roots
     (local.get $5)
     (ref.null none)
    )
    (array.set $text
     (global.get $awi_links)
     (local.get $5)
     (global.get $awi_free)
    )
    (global.set $awi_free
     (local.get $5)
    )
    (global.set $awi_live
     (i32.sub
      (global.get $awi_live)
      (i32.const 1)
     )
    )
    (br_if $block
     (ref.is_null
      (local.tee $9
       (global.get $g156)
      )
     )
    )
    (drop
     (struct.get $closure 1
      (local.get $9)
     )
    )
    (drop
     (call $awi_take
      (call $rust93
       (local.tee $5
        (call $awi_root
         (array.new_fixed $vector 0)
        )
       )
      )
     )
    )
    (if
     (i32.ge_u
      (local.get $5)
      (global.get $awi_used)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (array.get $text
       (global.get $awi_links)
       (local.get $5)
      )
      (i32.const -1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (table.get $awi_roots
      (local.get $5)
     )
    )
    (table.set $awi_roots
     (local.get $5)
     (ref.null none)
    )
    (array.set $text
     (global.get $awi_links)
     (local.get $5)
     (global.get $awi_free)
    )
    (global.set $awi_free
     (local.get $5)
    )
    (global.set $awi_live
     (i32.sub
      (global.get $awi_live)
      (i32.const 1)
     )
    )
    (drop
     (call $awi_take
      (call $rust92
       (local.tee $5
        (call $awi_root
         (array.new_fixed $vector 1
          (block (result eqref)
           (local.set $scratch_16
            (block $block3 (result eqref)
             (br_if $block
              (ref.is_null
               (local.tee $9
                (global.get $g241)
               )
              )
             )
             (if
              (ref.test (ref $values)
               (local.tee $6
                (call_ref $call
                 (struct.get $closure 1
                  (local.tee $11
                   (ref.as_non_null
                    (local.get $9)
                   )
                  )
                 )
                 (array.new_fixed $vector 0)
                 (ref.null none)
                 (struct.get $closure 0
                  (local.get $11)
                 )
                )
               )
              )
              (then
               (br_if $block1
                (i32.ne
                 (array.len
                  (local.tee $10
                   (struct.get $values 0
                    (ref.cast (ref $values)
                     (local.get $6)
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
               )
               (br $block3
                (array.get $vector
                 (local.get $10)
                 (i32.const 0)
                )
               )
              )
             )
             (local.get $6)
            )
           )
           (br_if $block
            (ref.is_null
             (local.tee $9
              (global.get $g155)
             )
            )
           )
           (drop
            (struct.get $closure 1
             (local.get $9)
            )
           )
           (local.get $scratch_16)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.ge_u
      (local.get $5)
      (global.get $awi_used)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (array.get $text
       (global.get $awi_links)
       (local.get $5)
      )
      (i32.const -1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (table.get $awi_roots
      (local.get $5)
     )
    )
    (table.set $awi_roots
     (local.get $5)
     (ref.null none)
    )
    (array.set $text
     (global.get $awi_links)
     (local.get $5)
     (global.get $awi_free)
    )
    (global.set $awi_free
     (local.get $5)
    )
    (global.set $awi_live
     (i32.sub
      (global.get $awi_live)
      (i32.const 1)
     )
    )
    (local.set $11
     (struct.new $closure
      (ref.func $adapter140)
      (array.new_fixed $vector 0)
     )
    )
    (local.set $7
     (block $block4 (result eqref)
      (br_if $block
       (ref.is_null
        (local.tee $9
         (global.get $g169)
        )
       )
      )
      (drop
       (struct.get $closure 1
        (local.get $9)
       )
      )
      (local.set $6
       (call $awi_take
        (call $rust105
         (local.tee $5
          (call $awi_root
           (array.new_fixed $vector 0)
          )
         )
        )
       )
      )
      (if
       (i32.ge_u
        (local.get $5)
        (global.get $awi_used)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (array.get $text
         (global.get $awi_links)
         (local.get $5)
        )
        (i32.const -1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (table.get $awi_roots
        (local.get $5)
       )
      )
      (table.set $awi_roots
       (local.get $5)
       (ref.null none)
      )
      (array.set $text
       (global.get $awi_links)
       (local.get $5)
       (global.get $awi_free)
      )
      (global.set $awi_free
       (local.get $5)
      )
      (global.set $awi_live
       (i32.sub
        (global.get $awi_live)
        (i32.const 1)
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $6)
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $10
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $6)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block4
         (array.get $vector
          (local.get $10)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $6)
     )
    )
    (local.set $8
     (block $block5 (result eqref)
      (br_if $block
       (ref.is_null
        (local.tee $9
         (global.get $g167)
        )
       )
      )
      (drop
       (struct.get $closure 1
        (local.get $9)
       )
      )
      (local.set $6
       (call $awi_take
        (call $rust103
         (local.tee $5
          (call $awi_root
           (array.new_fixed $vector 0)
          )
         )
        )
       )
      )
      (if
       (i32.ge_u
        (local.get $5)
        (global.get $awi_used)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (array.get $text
         (global.get $awi_links)
         (local.get $5)
        )
        (i32.const -1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (table.get $awi_roots
        (local.get $5)
       )
      )
      (table.set $awi_roots
       (local.get $5)
       (ref.null none)
      )
      (array.set $text
       (global.get $awi_links)
       (local.get $5)
       (global.get $awi_free)
      )
      (global.set $awi_free
       (local.get $5)
      )
      (global.set $awi_live
       (i32.sub
        (global.get $awi_live)
        (i32.const 1)
       )
      )
      (if
       (ref.test (ref $values)
        (local.get $6)
       )
       (then
        (br_if $block1
         (i32.ne
          (array.len
           (local.tee $10
            (struct.get $values 0
             (ref.cast (ref $values)
              (local.get $6)
             )
            )
           )
          )
          (i32.const 1)
         )
        )
        (br $block5
         (array.get $vector
          (local.get $10)
          (i32.const 0)
         )
        )
       )
      )
      (local.get $6)
     )
    )
    (block $block6
     (local.set $6
      (block $block7 (result eqref)
       (br_if $block6
        (ref.is_null
         (local.tee $9
          (global.get $g168)
         )
        )
       )
       (drop
        (struct.get $closure 1
         (local.get $9)
        )
       )
       (local.set $6
        (call $awi_take
         (call $rust104
          (local.tee $5
           (call $awi_root
            (array.new_fixed $vector 0)
           )
          )
         )
        )
       )
       (if
        (i32.ge_u
         (local.get $5)
         (global.get $awi_used)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.ne
         (array.get $text
          (global.get $awi_links)
          (local.get $5)
         )
         (i32.const -1)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (table.get $awi_roots
         (local.get $5)
        )
       )
       (table.set $awi_roots
        (local.get $5)
        (ref.null none)
       )
       (array.set $text
        (global.get $awi_links)
        (local.get $5)
        (global.get $awi_free)
       )
       (global.set $awi_free
        (local.get $5)
       )
       (global.set $awi_live
        (i32.sub
         (global.get $awi_live)
         (i32.const 1)
        )
       )
       (if
        (ref.test (ref $values)
         (local.get $6)
        )
        (then
         (br_if $block1
          (i32.ne
           (array.len
            (local.tee $10
             (struct.get $values 0
              (ref.cast (ref $values)
               (local.get $6)
              )
             )
            )
           )
           (i32.const 1)
          )
         )
         (br $block7
          (array.get $vector
           (local.get $10)
           (i32.const 0)
          )
         )
        )
       )
       (local.get $6)
      )
     )
     (struct.set $cell 0
      (local.tee $13
       (struct.new $cell
        (global.get $uninitialized)
       )
      )
      (struct.new $closure
       (ref.func $adapter146)
       (array.new_fixed $vector 9
        (local.get $1)
        (local.get $13)
        (local.get $2)
        (local.get $3)
        (local.get $0)
        (local.get $11)
        (local.get $8)
        (local.get $7)
        (local.get $6)
       )
      )
     )
     (br_if $block6
      (ref.eq
       (local.tee $14
        (struct.get $cell 0
         (local.get $13)
        )
       )
       (global.get $uninitialized)
      )
     )
     (return_call_ref $call
      (struct.get $closure 1
       (local.tee $12
        (ref.cast (ref $closure)
         (local.get $14)
        )
       )
      )
      (array.new_fixed $vector 2
       (ref.i31
        (i32.const 0)
       )
       (global.get $false)
      )
      (local.get $4)
      (struct.get $closure 0
       (local.get $12)
      )
     )
    )
    (br $block)
   )
   (global.set $error_code
    (i32.const 5)
   )
   (drop
    (call $rust_fail
     (i32.const 5)
    )
   )
   (unreachable)
  )
  (global.set $error_code
   (i32.const 6)
  )
  (drop
   (call $rust_fail
    (i32.const 6)
   )
  )
  (unreachable)
 )
 (func $adapter139 (type $call) (param $0 eqref) (param $1 (ref $vector)) (param $2 nullref) (result eqref)
  (local $3 i32)
  (if
   (i32.or
    (i32.ne
     (local.tee $3
      (array.len
       (local.get $1)
      )
     )
     (i32.const 4)
    )
    (i32.lt_u
     (local.get $3)
     (i32.const 4)
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (return_call $function139
   (array.get $vector
    (local.get $1)
    (i32.const 0)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 1)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 2)
   )
   (array.get $vector
    (local.get $1)
    (i32.const 3)
   )
   (local.get $2)
  )
 )
 (func $program (result eqref)
  (local $0 i32)
  (local $1 (ref null $closure))
  (local $2 (ref null $closure))
  (local $3 (ref null $closure))
  (local $4 (ref null $closure))
  (local $5 eqref)
  (local $6 (ref $vector))
  (global.set $g13
   (struct.new $closure
    (ref.func $primitive13)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g18
   (struct.new $closure
    (ref.func $primitive18)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g42
   (struct.new $closure
    (ref.func $primitive42)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g44
   (struct.new $closure
    (ref.func $primitive44)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g61
   (struct.new $closure
    (ref.func $primitive61)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g62
   (struct.new $closure
    (ref.func $primitive62)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g63
   (struct.new $closure
    (ref.func $primitive63)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g72
   (struct.new $closure
    (ref.func $primitive72)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g78
   (struct.new $closure
    (ref.func $primitive78)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g117
   (struct.new $closure
    (ref.func $primitive117)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g118
   (struct.new $closure
    (ref.func $primitive118)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g122
   (struct.new $closure
    (ref.func $primitive122)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g128
   (struct.new $closure
    (ref.func $primitive128)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g136
   (struct.new $closure
    (ref.func $primitive136)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g151
   (struct.new $closure
    (ref.func $primitive151)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g152
   (struct.new $closure
    (ref.func $primitive152)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g155
   (struct.new $closure
    (ref.func $primitive155)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g156
   (struct.new $closure
    (ref.func $primitive156)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g157
   (struct.new $closure
    (ref.func $primitive157)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g158
   (struct.new $closure
    (ref.func $primitive158)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g159
   (struct.new $closure
    (ref.func $primitive159)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g160
   (struct.new $closure
    (ref.func $primitive160)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g161
   (struct.new $closure
    (ref.func $primitive161)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g162
   (struct.new $closure
    (ref.func $primitive162)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g167
   (struct.new $closure
    (ref.func $primitive167)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g168
   (struct.new $closure
    (ref.func $primitive168)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g169
   (struct.new $closure
    (ref.func $primitive169)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g181
   (struct.new $closure
    (ref.func $adapter0)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g183
   (struct.new $closure
    (ref.func $adapter2)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g184
   (struct.new $closure
    (ref.func $adapter3)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g186
   (struct.new $closure
    (ref.func $adapter5)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g190
   (struct.new $closure
    (ref.func $adapter17)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g192
   (struct.new $closure
    (ref.func $adapter22)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g195
   (struct.new $closure
    (ref.func $adapter28)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g198
   (struct.new $closure
    (ref.func $adapter31)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g199
   (struct.new $closure
    (ref.func $adapter32)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g203
   (struct.new $closure
    (ref.func $adapter36)
    (array.new_fixed $vector 0)
   )
  )
  (global.set $g204
   (struct.new $closure
    (ref.func $adapter38)
    (array.new_fixed $vector 0)
   )
  )
  (block $block
   (br_if $block
    (ref.is_null
     (global.get $g44)
    )
   )
   (global.set $g236
    (struct.new $pair
     (global.get $literal3)
     (global.get $nil)
    )
   )
   (global.set $g237
    (struct.new $closure
     (ref.func $adapter98)
     (array.new_fixed $vector 0)
    )
   )
   (global.set $g239
    (struct.new $closure
     (ref.func $adapter109)
     (array.new_fixed $vector 0)
    )
   )
   (br_if $block
    (ref.is_null
     (global.get $g157)
    )
   )
   (br_if $block
    (ref.is_null
     (global.get $g160)
    )
   )
   (br_if $block
    (local.tee $0
     (ref.is_null
      (global.get $g239)
     )
    )
   )
   (br_if $block
    (ref.is_null
     (local.tee $1
      (global.get $g237)
     )
    )
   )
   (drop
    (ref.as_non_null
     (local.get $1)
    )
   )
   (br_if $block
    (ref.is_null
     (local.tee $1
      (global.get $g158)
     )
    )
   )
   (br_if $block
    (ref.is_null
     (local.tee $2
      (global.get $g161)
     )
    )
   )
   (br_if $block
    (ref.is_null
     (local.tee $3
      (global.get $g239)
     )
    )
   )
   (br_if $block
    (ref.is_null
     (local.tee $4
      (global.get $g237)
     )
    )
   )
   (drop
    (ref.as_non_null
     (local.get $4)
    )
   )
   (global.set $g241
    (struct.new $closure
     (ref.func $adapter99)
     (array.new_fixed $vector 3
      (local.get $1)
      (local.get $2)
      (local.get $3)
     )
    )
   )
   (br_if $block
    (ref.is_null
     (global.get $g159)
    )
   )
   (br_if $block
    (ref.is_null
     (global.get $g162)
    )
   )
   (br_if $block
    (local.get $0)
   )
   (br_if $block
    (ref.is_null
     (local.tee $1
      (global.get $g237)
     )
    )
   )
   (drop
    (ref.as_non_null
     (local.get $1)
    )
   )
   (br_if $block
    (local.tee $0
     (ref.is_null
      (global.get $g128)
     )
    )
   )
   (br_if $block
    (local.get $0)
   )
   (return
    (block $block3 (result eqref)
     (global.set $g247
      (struct.new $closure
       (ref.func $adapter121)
       (array.new_fixed $vector 0)
      )
     )
     (global.set $g248
      (struct.new $closure
       (ref.func $adapter122)
       (array.new_fixed $vector 0)
      )
     )
     (global.set $g249
      (struct.new $closure
       (ref.func $adapter134)
       (array.new_fixed $vector 0)
      )
     )
     (global.set $g250
      (struct.new $closure
       (ref.func $adapter135)
       (array.new_fixed $vector 0)
      )
     )
     (global.set $g251
      (struct.new $closure
       (ref.func $adapter139)
       (array.new_fixed $vector 0)
      )
     )
     (block $block1
      (br_if $block1
       (ref.is_null
        (local.tee $1
         (global.get $g248)
        )
       )
      )
      (drop
       (ref.as_non_null
        (local.get $1)
       )
      )
      (br $block3
       (call $function123
        (block $block2 (result eqref)
         (br_if $block1
          (ref.is_null
           (local.tee $1
            (global.get $g136)
           )
          )
         )
         (drop
          (struct.get $closure 1
           (local.get $1)
          )
         )
         (local.set $5
          (call $awi_take
           (call $rust74
            (local.tee $0
             (call $awi_root
              (array.new_fixed $vector 0)
             )
            )
           )
          )
         )
         (if
          (i32.ge_u
           (local.get $0)
           (global.get $awi_used)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.ne
           (array.get $text
            (global.get $awi_links)
            (local.get $0)
           )
           (i32.const -1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (table.get $awi_roots
           (local.get $0)
          )
         )
         (table.set $awi_roots
          (local.get $0)
          (ref.null none)
         )
         (array.set $text
          (global.get $awi_links)
          (local.get $0)
          (global.get $awi_free)
         )
         (global.set $awi_free
          (local.get $0)
         )
         (global.set $awi_live
          (i32.sub
           (global.get $awi_live)
           (i32.const 1)
          )
         )
         (if
          (ref.test (ref $values)
           (local.get $5)
          )
          (then
           (if
            (i32.ne
             (array.len
              (local.tee $6
               (struct.get $values 0
                (ref.cast (ref $values)
                 (local.get $5)
                )
               )
              )
             )
             (i32.const 1)
            )
            (then
             (global.set $error_code
              (i32.const 5)
             )
             (drop
              (call $rust_fail
               (i32.const 5)
              )
             )
             (unreachable)
            )
           )
           (br $block2
            (array.get $vector
             (local.get $6)
             (i32.const 0)
            )
           )
          )
         )
         (local.get $5)
        )
        (ref.null none)
       )
      )
     )
     (br $block)
    )
   )
  )
  (global.set $error_code
   (i32.const 6)
  )
  (drop
   (call $rust_fail
    (i32.const 6)
   )
  )
  (unreachable)
 )
 (func $115 (param $0 i32) (result i32)
  (if
   (i32.ge_u
    (local.get $0)
    (global.get $awi_used)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $text
     (global.get $awi_links)
     (local.get $0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.len
    (ref.cast (ref $vector)
     (table.get $awi_roots
      (local.get $0)
     )
    )
   )
   (then
    (global.set $error_code
     (i32.const 4)
    )
    (drop
     (call $rust_fail
      (i32.const 4)
     )
    )
    (unreachable)
   )
  )
  (drop
   (call $program)
  )
  (call $awi_root
   (ref.i31
    (i32.const 0)
   )
  )
 )
)

