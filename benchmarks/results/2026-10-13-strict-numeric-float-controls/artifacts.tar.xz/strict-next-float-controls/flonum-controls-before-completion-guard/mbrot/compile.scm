(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-next-float-controls-20261013/build/strict-next-float-controls/flonum-controls/mbrot/program.scm" "/tmp/snail-strict-next-float-controls-20261013/build/strict-next-float-controls/flonum-controls/mbrot/program.so"))
