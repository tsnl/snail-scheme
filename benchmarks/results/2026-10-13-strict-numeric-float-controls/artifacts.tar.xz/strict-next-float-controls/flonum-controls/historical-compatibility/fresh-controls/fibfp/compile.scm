(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-next-float-historical-compat-20261013/strict-suite/flonum-controls/fibfp/program.scm" "/tmp/snail-next-float-historical-compat-20261013/strict-suite/flonum-controls/fibfp/program.so"))
