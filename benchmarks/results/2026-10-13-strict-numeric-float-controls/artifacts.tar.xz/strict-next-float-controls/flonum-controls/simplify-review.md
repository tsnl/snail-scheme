# Arithmetic control explanation review

The fresh explainer received only a behavioral brief and no repository, source,
diff or artifact access. The scope was flonum.py: prepare floating-only Chez
controls, preserve frozen strict binaries and original inputs, validate, and
measure fresh balanced pairs after a quiet-window authorization.

Its independent model separated preparation from sampling. Preparation must
record exact source edits, sources, inputs, drivers and executable hashes; build
Chez; and retain count 1/2 result validations. Sampling must recheck the frozen
files, run every selected control and strict artifact in fresh processes, save
each observation before proceeding, reject nonfinite or nonpositive durations,
and stop on a recorded failure.

Pseudocode:

    prepare selected ready cases:
        preserve original input and strict artifact
        replace audited floating operators, retaining integer forms
        prove exact reversal and unchanged surrounding source
        compile, validate counts 1 and 2, freeze files
    sample prepared cases after quiet authorization:
        recheck all frozen dependencies
        run one discarded and three retained alternating pairs
        save each success or failure; stop on failure
        summarize medians and ranges for the prepared cases

The critical debate considered a general syntax/type classifier. The agreed
bounded implementation uses unique function boundaries, pinned audited source,
explicit protected integer forms, exact floating-site counts, operator reversal
and unchanged surrounding bytes. Those checks establish textual preservation;
the arithmetic-domain audit remains an explicit premise. Counts and reversal
alone cannot classify an unlisted integer operation or establish dynamic type
intent. The final source-proof records state this limitation.

The implementation also rechecks the executed strict/control artifacts, input,
baseline source, host, tools and drivers before every sample. It assumes no file
mutation during a child process. Legacy fibfp/sumfp archives keep their recorded
source/artifact contract, and the new transformer reproduced both old source
files byte for byte and passed fresh count 1/2 checks.

Parent review found that the first successful case could prematurely mark a
multi-case preparation complete. The final driver saves incomplete progress,
records all expected case names, marks completion only after the loop, and
rejects a partial preparation even if its completion flag is falsely true.
