(import (chezscheme))
(define-syntax : (syntax-rules () ((_ . signature) (begin))))
(define-syntax ann (syntax-rules () ((_ value type) value)))
(define wall-value (vector 0))
(define (coordinate row column) (vector 1 row column))
(define (open-cell? value) (= (vector-ref value 0) 1))
(define (coordinate-row value) (vector-ref value 1))
(define (coordinate-column value) (vector-ref value 2))
(define (dimensions rows columns) (vector rows columns))
(define (dimension-rows value) (vector-ref value 0))
(define (dimension-columns value) (vector-ref value 1))
(define maze-initial-value (vector 0))
(define maze-error-value (vector 1))
(define maze-other-value (vector 3))
(define (maze-grid rows) (vector 2 rows))
(define (maze-kind value) (vector-ref value 0))
(define (maze-rows value) (vector-ref value 1))
;; Position lists contain Coordinate values by construction. Writes
;; share that same label; they never add a cell wrapper or copy its coordinates.
(define (same-bool? left right) (if left right (not right)))
(define (maze-even? value) (= (remainder value 2) 0))
(define (maze-odd? value) (not (maze-even? value)))
(define (same-cavity? left right)
  (if (open-cell? left)
      (and (open-cell? right) (= (coordinate-row left) (coordinate-row right))
           (= (coordinate-column left) (coordinate-column right)))
      (not (open-cell? right))))
(define (cavity-member? value values)
  (and (not (null? values))
       (or (same-cavity? value (car values)) (cavity-member? value (cdr values)))))
(: singleton (All (T) (-> T (List T))))
(define (singleton value) (cons value '()))
(: append-two (All (T) (-> (List T) (List T) (List T))))
(define (append-two first last)
  (if (null? first) last (cons (car first) (append-two (cdr first) last))))
(: append-four (All (T) (-> (List T) (List T) (List T) (List T) (List T))))
(define (append-four first second third last)
  (append-two first (append-two second (append-two third last))))
(: maze-map (All (A B) (-> (-> A B) (List A) (List B))))
(define (maze-map procedure values)
  (if (null? values) '()
      (let ((head (procedure (car values))))
        (cons head (maze-map procedure (cdr values))))))
(define (same-row? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (same-bool? (car left) (car right))
           (same-row? (cdr left) (cdr right)))))
(define (same-grid? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (same-row? (car left) (car right))
           (same-grid? (cdr left) (cdr right)))))
(define (same-maze? actual expected)
  (and (= (maze-kind actual) (maze-kind expected))
       (if (= (maze-kind actual) 2) (same-grid? (maze-rows actual) (maze-rows expected))
           (not (= (maze-kind actual) 3)))))
(: foldr (All (A B) (-> (-> A B B) B (List A) B)))
(: foldl (All (A B) (-> (-> B A B) B (List A) B)))
(: for (All (T) (-> I64 I64 (-> I64 T) (List T))))
(: concat (All (T) (-> (List (List T)) (List T))))
(: list-read (All (T) (-> (List T) I64 T)))
(: list-write (All (T) (-> (List T) I64 T (List T))))
(: list-remove-pos (All (T) (-> (List T) I64 (List T))))
(: make-matrix (All (T) (-> I64 I64 (-> I64 I64 T) (List (List T)))))
(: matrix-read (All (T) (-> (List (List T)) I64 I64 T)))
(: matrix-write (All (T) (-> (List (List T)) I64 I64 T (List (List T)))))
(: matrix-size (All (T) (-> (List (List T)) Dimensions)))
(: matrix-map (All (A B) (-> (-> A B) (List (List A)) (List (List B)))))
(: shuffle (All (T) (-> (List T) (List T))))
(: shuffle-aux (All (T) (-> (List T) I64 (List T))))
(: make-maze (-> I64 I64 MazeResult))
;;; MAZEFUN -- Constructs a maze in a purely functional way,
;;; written by Marc Feeley.


(define foldr
  (lambda (f base lst)
    (define foldr-aux
      (lambda (lst)
        (if (null? lst)
            base
            (f (car lst) (foldr-aux (cdr lst))))))

    (foldr-aux lst)))

(define foldl
  (lambda (f base lst)
    (define foldl-aux
      (lambda (base lst)
        (if (null? lst)
            base
            (foldl-aux (f base (car lst)) (cdr lst)))))

    (foldl-aux base lst)))

(define for
  (lambda (lo hi f)
    (define for-aux
      (lambda (lo)
        (if (< lo hi)
            (cons (f lo) (for-aux (+ lo 1)))
            '())))

    (for-aux lo)))

(define concat
  (lambda (lists)
    (foldr append-two '() lists)))

(define list-read
  (lambda (lst i)
    (if (= i 0)
        (car lst)
        (list-read (cdr lst) (- i 1)))))

(define list-write
  (lambda (lst i val)
    (if (= i 0)
        (cons val (cdr lst))
        (cons (car lst) (list-write (cdr lst) (- i 1) val)))))

(define list-remove-pos
  (lambda (lst i)
    (if (= i 0)
        (cdr lst)
        (cons (car lst) (list-remove-pos (cdr lst) (- i 1))))))

(define duplicates?
  (lambda (lst)
    (if (null? lst)
        #f
        (or (cavity-member? (car lst) (cdr lst))
            (duplicates? (cdr lst))))))

(define make-matrix
  (lambda (n m init)
    (for 0 n (lambda (i) (for 0 m (lambda (j) (init i j)))))))

(define matrix-read
  (lambda (mat i j)
    (list-read (list-read mat i) j)))

(define matrix-write
  (lambda (mat i j val)
    (list-write mat i (list-write (list-read mat i) j val))))

(define matrix-size
  (lambda (mat)
    (dimensions (length mat) (length (car mat)))))

(define matrix-map
  (lambda (f mat)
    (maze-map (lambda (lst) (maze-map f lst)) mat)))

(define initial-random 0)

(define next-random-number
  (lambda (current-random)
    (remainder (+ (* current-random 3581) 12751) 131072)))

(define shuffle
  (lambda (lst)
    (shuffle-aux lst initial-random)))

(define shuffle-aux
  (lambda (lst current-random)
    (if (null? lst)
        '()
        (let ((new-random (next-random-number current-random)))
          (let ((i (remainder new-random (length lst))))
            (cons (list-read lst i)
                  (shuffle-aux (list-remove-pos lst i)
                               new-random)))))))

(define make-maze
  (lambda (n m) ; n and m must be odd
    (if (not (and (maze-odd? n) (maze-odd? m)))
        maze-error-value
        (let ((cave
               (make-matrix n m (lambda (i j)
                                  (if (and (maze-even? i) (maze-even? j))
                                      (coordinate i j)
                                      wall-value))))
              (possible-holes
               (concat
                (for 0 n (lambda (i)
                           (concat
                            (for 0 m (lambda (j)
                                       (if (same-bool? (maze-even? i) (maze-even? j))
                                           '()
                                           (singleton (coordinate i j)))))))))))
          (cave-to-maze (pierce-randomly (shuffle possible-holes) cave))))))

(define cave-to-maze
  (lambda (cave)
    (maze-grid (matrix-map open-cell? cave))))

(define pierce
  (lambda (pos cave)
    (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
      (matrix-write cave i j pos))))

(define pierce-randomly
  (lambda (possible-holes cave)
    (if (null? possible-holes)
        cave
        (let ((hole (car possible-holes)))
          (pierce-randomly (cdr possible-holes)
                           (try-to-pierce hole cave))))))

(define try-to-pierce
  (lambda (pos cave)
    (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
      (let ((ncs (neighboring-cavities pos cave)))
        (if (duplicates?
             (maze-map (lambda (nc) (matrix-read cave (coordinate-row nc) (coordinate-column nc))) ncs))
            cave
            (pierce pos
                    (foldl (lambda (c nc) (change-cavity c nc pos))
                           cave
                           ncs)))))))

(define change-cavity
  (lambda (cave pos new-cavity-id)
    (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
      (change-cavity-aux cave pos new-cavity-id (matrix-read cave i j)))))

(define change-cavity-aux
  (lambda (cave pos new-cavity-id old-cavity-id)
    (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
      (let ((cavity-id (matrix-read cave i j)))
        (if (same-cavity? cavity-id old-cavity-id)
            (foldl (lambda (c nc)
                     (change-cavity-aux c nc new-cavity-id old-cavity-id))
                   (matrix-write cave i j new-cavity-id)
                   (neighboring-cavities pos cave))
            cave)))))

(define neighboring-cavities
  (lambda (pos cave)
    (let ((size (matrix-size cave)))
      (let ((n (dimension-rows size)) (m (dimension-columns size)))
        (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
          (append-four (if (and (> i 0) (open-cell? (matrix-read cave (- i 1) j)))
                      (singleton (coordinate (- i 1) j))
                      '())
                  (if (and (< i (- n 1)) (open-cell? (matrix-read cave (+ i 1) j)))
                      (singleton (coordinate (+ i 1) j))
                      '())
                  (if (and (> j 0) (open-cell? (matrix-read cave i (- j 1))))
                      (singleton (coordinate i (- j 1)))
                      '())
                  (if (and (< j (- m 1)) (open-cell? (matrix-read cave i (+ j 1))))
                      (singleton (coordinate i (+ j 1)))
                      '())))))))

(define (probe-initial n m) (make-matrix n m (lambda (i j)
                                  (if (and (maze-even? i) (maze-even? j))
                                      (coordinate i j)
                                      wall-value))))
(define (probe-holes n m) (concat
                (for 0 n (lambda (i)
                           (concat
                            (for 0 m (lambda (j)
                                       (if (same-bool? (maze-even? i) (maze-even? j))
                                           '()
                                           (singleton (coordinate i j))))))))))
(define (mark-code value) (if value 1 0))
(define (emit-i64 value) (write value) (newline))
(: emit-sequence (All (T) (-> (-> T Unit) (List T) Unit)))
(define (emit-sequence emit-value values)
  (emit-i64 (length values))
  (let loop ((values values))
    (unless (null? values) (emit-value (car values)) (loop (cdr values)))))
(define (emit-mark value) (emit-i64 (mark-code value)))
(define (emit-row row) (emit-sequence emit-mark row))
(define (emit-result value)
  (emit-i64 (maze-kind value))
  (when (= (maze-kind value) 2) (emit-sequence emit-row (maze-rows value))))
(define (emit-coordinate value)
  (emit-i64 (coordinate-row value)) (emit-i64 (coordinate-column value)))
(define (emit-cavity value)
  (emit-i64 (if (open-cell? value) 1 0))
  (when (open-cell? value) (emit-coordinate value)))
(define (emit-cave-row row) (emit-sequence emit-cavity row))
(define (probe-trace n m)
  (let* ((holes (probe-holes n m)) (ordered (shuffle holes)))
    (emit-sequence emit-coordinate holes) (emit-sequence emit-coordinate ordered)
    (let loop ((holes ordered) (cave (probe-initial n m)))
      (unless (null? holes)
        (let* ((hole (car holes)) (next (try-to-pierce hole cave)))
          (emit-coordinate hole) (emit-sequence emit-cave-row next)
          (loop (cdr holes) next))))))
(: probe (-> I64 I64 I64 I64))
(define (probe command n m)
  (if (= command 0) (emit-result (make-maze n m)) (probe-trace n m)) 1)
(define (probe-sharing)
  (let* ((grid (probe-initial 3 3))
         (first (list-read grid 0)) (middle (list-read grid 1)) (last (list-read grid 2))
         (label (coordinate 9 7)) (written (matrix-write grid 1 1 label))
         (row (list-read written 1)) (removed (list-remove-pos first 1))
         (appended (append-two first middle)))
    (for-each (lambda (value) (emit-i64 (if value 1 0)))
      (list (not (eq? written grid)) (not (eq? (cdr written) (cdr grid)))
            (eq? (cddr written) (cddr grid)) (eq? (list-read written 0) first)
            (eq? (list-read written 2) last) (not (eq? row middle))
            (not (eq? (cdr row) (cdr middle))) (eq? (cddr row) (cddr middle))
            (eq? (list-read row 1) label) (not (eq? (list-read middle 1) label))
            (not (eq? removed first)) (eq? (cdr removed) (cddr first))
            (eq? (list-remove-pos first 0) (cdr first))
            (not (eq? appended first)) (eq? (cdddr appended) middle)))))
(let* ((command (read)) (n (read)) (m (read))) (if (= command 2) (probe-sharing) (probe command n m)))
