(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-mazefun-preparation-20261014-r3/mazefun/program.scm" "/tmp/snail-strict-mazefun-preparation-20261014-r3/mazefun/program.so"))
