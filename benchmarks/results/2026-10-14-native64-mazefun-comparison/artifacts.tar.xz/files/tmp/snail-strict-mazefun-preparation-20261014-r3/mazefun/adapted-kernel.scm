(: foldr (All (A B) (-> (-> A B B) B (List A) B)))
(: foldl (All (A B) (-> (-> B A B) B (List A) B)))
(: for (All (T) (-> I64 I64 (-> I64 T) (List T))))
(: concat (All (T) (-> (List (List T)) (List T))))
(: list-read (All (T) (-> (List T) I64 T)))
(: list-write (All (T) (-> (List T) I64 T (List T))))
(: list-remove-pos (All (T) (-> (List T) I64 (List T))))
(: make-matrix (All (T) (-> I64 I64 (-> I64 I64 T) (List (List T)))))
(: matrix-read (All (T) (-> (List (List T)) I64 I64 T)))
(: matrix-write (All (T) (-> (List (List T)) I64 I64 T (List (List T)))))
(: matrix-size (All (T) (-> (List (List T)) Dimensions)))
(: matrix-map (All (A B) (-> (-> A B) (List (List A)) (List (List B)))))
(: shuffle (All (T) (-> (List T) (List T))))
(: shuffle-aux (All (T) (-> (List T) I64 (List T))))
(: make-maze (-> I64 I64 MazeResult))
;;; MAZEFUN -- Constructs a maze in a purely functional way,
;;; written by Marc Feeley.


(define foldr
  (lambda (f base lst)
    (define foldr-aux
      (lambda (lst)
        (if (null? lst)
            base
            (f (car lst) (foldr-aux (cdr lst))))))

    (foldr-aux lst)))

(define foldl
  (lambda (f base lst)
    (define foldl-aux
      (lambda (base lst)
        (if (null? lst)
            base
            (foldl-aux (f base (car lst)) (cdr lst)))))

    (foldl-aux base lst)))

(define for
  (lambda (lo hi f)
    (define for-aux
      (lambda (lo)
        (if (< lo hi)
            (cons (f lo) (for-aux (+ lo 1)))
            '())))

    (for-aux lo)))

(define concat
  (lambda (lists)
    (foldr append-two '() lists)))

(define list-read
  (lambda (lst i)
    (if (= i 0)
        (car lst)
        (list-read (cdr lst) (- i 1)))))

(define list-write
  (lambda (lst i val)
    (if (= i 0)
        (cons val (cdr lst))
        (cons (car lst) (list-write (cdr lst) (- i 1) val)))))

(define list-remove-pos
  (lambda (lst i)
    (if (= i 0)
        (cdr lst)
        (cons (car lst) (list-remove-pos (cdr lst) (- i 1))))))

(define duplicates?
  (lambda (lst)
    (if (null? lst)
        #f
        (or (cavity-member? (car lst) (cdr lst))
            (duplicates? (cdr lst))))))

(define make-matrix
  (lambda (n m init)
    (for 0 n (lambda (i) (for 0 m (lambda (j) (init i j)))))))

(define matrix-read
  (lambda (mat i j)
    (list-read (list-read mat i) j)))

(define matrix-write
  (lambda (mat i j val)
    (list-write mat i (list-write (list-read mat i) j val))))

(define matrix-size
  (lambda (mat)
    (dimensions (length mat) (length (car mat)))))

(define matrix-map
  (lambda (f mat)
    (maze-map (lambda (lst) (maze-map f lst)) mat)))

(define initial-random 0)

(define next-random-number
  (lambda (current-random)
    (remainder (+ (* current-random 3581) 12751) 131072)))

(define shuffle
  (lambda (lst)
    (shuffle-aux lst initial-random)))

(define shuffle-aux
  (lambda (lst current-random)
    (if (null? lst)
        '()
        (let ((new-random (next-random-number current-random)))
          (let ((i (remainder new-random (length lst))))
            (cons (list-read lst i)
                  (shuffle-aux (list-remove-pos lst i)
                               new-random)))))))

(define make-maze
  (lambda (n m) ; n and m must be odd
    (if (not (and (maze-odd? n) (maze-odd? m)))
        maze-error-value
        (let ((cave
               (make-matrix n m (lambda (i j)
                                  (if (and (maze-even? i) (maze-even? j))
                                      (coordinate i j)
                                      wall-value))))
              (possible-holes
               (concat
                (for 0 n (lambda (i)
                           (concat
                            (for 0 m (lambda (j)
                                       (if (same-bool? (maze-even? i) (maze-even? j))
                                           '()
                                           (singleton (coordinate i j)))))))))))
          (cave-to-maze (pierce-randomly (shuffle possible-holes) cave))))))

(define cave-to-maze
  (lambda (cave)
    (maze-grid (matrix-map open-cell? cave))))

(define pierce
  (lambda (pos cave)
    (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
      (matrix-write cave i j pos))))

(define pierce-randomly
  (lambda (possible-holes cave)
    (if (null? possible-holes)
        cave
        (let ((hole (car possible-holes)))
          (pierce-randomly (cdr possible-holes)
                           (try-to-pierce hole cave))))))

(define try-to-pierce
  (lambda (pos cave)
    (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
      (let ((ncs (neighboring-cavities pos cave)))
        (if (duplicates?
             (maze-map (lambda (nc) (matrix-read cave (coordinate-row nc) (coordinate-column nc))) ncs))
            cave
            (pierce pos
                    (foldl (lambda (c nc) (change-cavity c nc pos))
                           cave
                           ncs)))))))

(define change-cavity
  (lambda (cave pos new-cavity-id)
    (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
      (change-cavity-aux cave pos new-cavity-id (matrix-read cave i j)))))

(define change-cavity-aux
  (lambda (cave pos new-cavity-id old-cavity-id)
    (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
      (let ((cavity-id (matrix-read cave i j)))
        (if (same-cavity? cavity-id old-cavity-id)
            (foldl (lambda (c nc)
                     (change-cavity-aux c nc new-cavity-id old-cavity-id))
                   (matrix-write cave i j new-cavity-id)
                   (neighboring-cavities pos cave))
            cave)))))

(define neighboring-cavities
  (lambda (pos cave)
    (let ((size (matrix-size cave)))
      (let ((n (dimension-rows size)) (m (dimension-columns size)))
        (let ((i (coordinate-row pos)) (j (coordinate-column pos)))
          (append-four (if (and (> i 0) (open-cell? (matrix-read cave (- i 1) j)))
                      (singleton (coordinate (- i 1) j))
                      '())
                  (if (and (< i (- n 1)) (open-cell? (matrix-read cave (+ i 1) j)))
                      (singleton (coordinate (+ i 1) j))
                      '())
                  (if (and (> j 0) (open-cell? (matrix-read cave i (- j 1))))
                      (singleton (coordinate i (- j 1)))
                      '())
                  (if (and (< j (- m 1)) (open-cell? (matrix-read cave i (+ j 1))))
                      (singleton (coordinate i (+ j 1)))
                      '())))))))

