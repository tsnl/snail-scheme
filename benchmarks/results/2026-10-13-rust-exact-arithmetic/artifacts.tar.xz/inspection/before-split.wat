 (func $_ZN10chudnovsky5split17ha65d8562730fc0eeE (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i64)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 208)
    )
   )
  )
  (block $block11
   (block $block9
    (block $block8
     (block $block
      (br_if $block
       (i32.ne
        (i32.sub
         (local.get $2)
         (local.get $1)
        )
        (i32.const 1)
       )
      )
      (i64.store offset=80 align=4
       (local.get $3)
       (i64.const 6442450944)
      )
      (i32.store offset=88
       (local.get $3)
       (i32.add
        (local.tee $4
         (i32.mul
          (local.get $2)
          (i32.const 6)
         )
        )
        (i32.const -5)
       )
      )
      (call $_ZN10num_bigint7biguint14multiplication10scalar_mul17hf635b3c2da38325dE
       (i32.add
        (local.get $3)
        (i32.const 80)
       )
       (i32.add
        (i32.shl
         (local.get $2)
         (i32.const 1)
        )
        (i32.const -1)
       )
      )
      (local.set $1
       (i32.load offset=88
        (local.get $3)
       )
      )
      (local.set $5
       (i32.load offset=84
        (local.get $3)
       )
      )
      (block $block2
       (block $block1
        (br_if $block1
         (i32.eq
          (local.tee $6
           (i32.load offset=80
            (local.get $3)
           )
          )
          (i32.const -2147483648)
         )
        )
        (local.set $7
         (i32.eqz
          (local.get $1)
         )
        )
        (br $block2)
       )
       (local.set $7
        (i32.xor
         (local.get $5)
         (i32.const 1)
        )
       )
      )
      (i32.store offset=88
       (local.get $3)
       (local.get $1)
      )
      (i32.store offset=84
       (local.get $3)
       (local.get $5)
      )
      (i32.store offset=80
       (local.get $3)
       (local.get $6)
      )
      (call $_ZN10num_bigint7biguint14multiplication10scalar_mul17hf635b3c2da38325dE
       (i32.add
        (local.get $3)
        (i32.const 80)
       )
       (i32.add
        (local.get $4)
        (i32.const -1)
       )
      )
      (i32.store offset=40
       (local.get $3)
       (i32.load offset=88
        (local.get $3)
       )
      )
      (i64.store offset=32
       (local.get $3)
       (local.tee $8
        (i64.load offset=80 align=4
         (local.get $3)
        )
       )
      )
      (local.set $1
       (i32.wrap_i64
        (local.get $8)
       )
      )
      (block $block5
       (block $block3
        (br_if $block3
         (i32.eqz
          (i32.and
           (local.get $7)
           (i32.const 1)
          )
         )
        )
        (i32.store
         (i32.add
          (i32.add
           (local.get $3)
           (i32.const 32)
          )
          (select
           (i32.const 8)
           (i32.const 4)
           (local.tee $1
            (i32.ne
             (local.get $1)
             (i32.const -2147483648)
            )
           )
          )
         )
         (i32.const 0)
        )
        (block $block4
         (br_if $block4
          (local.get $1)
         )
         (br_if $block4
          (i32.load offset=36
           (local.get $3)
          )
         )
         (i64.store offset=32
          (local.get $3)
          (i64.const 2147483648)
         )
        )
        (call $_ZN10num_bigint9big_digit9BigDigits9normalize17h3304bda1751685ccE
         (i32.add
          (local.get $3)
          (i32.const 32)
         )
        )
        (local.set $1
         (i32.const 1)
        )
        (br $block5)
       )
       (block $block7
        (block $block6
         (br_if $block6
          (i32.eq
           (local.get $1)
           (i32.const -2147483648)
          )
         )
         (local.set $1
          (i32.eqz
           (i32.load offset=40
            (local.get $3)
           )
          )
         )
         (br $block7)
        )
        (local.set $1
         (i32.xor
          (i32.load offset=36
           (local.get $3)
          )
          (i32.const 1)
         )
        )
       )
       (local.set $1
        (select
         (i32.const 1)
         (i32.const 2)
         (local.get $1)
        )
       )
      )
      (i32.store offset=8
       (local.get $3)
       (i32.load offset=40
        (local.get $3)
       )
      )
      (i64.store
       (local.get $3)
       (i64.load offset=32
        (local.get $3)
       )
      )
      (i32.store8 offset=12
       (local.get $3)
       (local.get $1)
      )
      (i32.store offset=152
       (local.get $3)
       (i32.const 640320)
      )
      (i64.store offset=144 align=4
       (local.get $3)
       (i64.const 6442450944)
      )
      (i32.store8 offset=156
       (local.get $3)
       (i32.const 2)
      )
      (call $_ZN10num_bigint6bigint6BigInt3pow17h3716f8cb56d5acc6E
       (i32.add
        (local.get $3)
        (i32.const 128)
       )
       (i32.add
        (local.get $3)
        (i32.const 144)
       )
       (i32.const 3)
      )
      (br_if $block8
       (local.get $2)
      )
      (i64.store offset=88
       (local.get $3)
       (i64.load offset=1058364 align=4
        (i32.const 0)
       )
      )
      (i64.store offset=80
       (local.get $3)
       (i64.load offset=1058356 align=4
        (i32.const 0)
       )
      )
      (br $block9)
     )
     (call $_ZN10chudnovsky5split17ha65d8562730fc0eeE
      (i32.add
       (local.get $3)
       (i32.const 32)
      )
      (local.get $1)
      (local.tee $5
       (i32.shr_u
        (i32.add
         (local.get $2)
         (local.get $1)
        )
        (i32.const 1)
       )
      )
     )
     (call $_ZN10chudnovsky5split17ha65d8562730fc0eeE
      (i32.add
       (local.get $3)
       (i32.const 80)
      )
      (local.get $5)
      (local.get $2)
     )
     (call $_ZN10num_bigint6bigint14multiplication82_$LT$impl$u20$core..ops..arith..Mul$u20$for$u20$$RF$num_bigint..bigint..BigInt$GT$3mul17h033dfcce1719163eE
      (local.get $0)
      (i32.add
       (local.get $3)
       (i32.const 32)
      )
      (i32.add
       (local.get $3)
       (i32.const 80)
      )
     )
     (call $_ZN10num_bigint6bigint14multiplication82_$LT$impl$u20$core..ops..arith..Mul$u20$for$u20$$RF$num_bigint..bigint..BigInt$GT$3mul17h033dfcce1719163eE
      (i32.add
       (local.get $0)
       (i32.const 16)
      )
      (i32.add
       (i32.add
        (local.get $3)
        (i32.const 32)
       )
       (i32.const 16)
      )
      (local.tee $1
       (i32.add
        (i32.add
         (local.get $3)
         (i32.const 80)
        )
        (i32.const 16)
       )
      )
     )
     (call $_ZN10num_bigint6bigint14multiplication78_$LT$impl$u20$core..ops..arith..Mul$u20$for$u20$num_bigint..bigint..BigInt$GT$3mul17h13cbda9b0e54f985E
      (i32.add
       (local.get $3)
       (i32.const 128)
      )
      (i32.add
       (i32.add
        (local.get $3)
        (i32.const 32)
       )
       (i32.const 32)
      )
      (local.get $1)
     )
     (call $_ZN10num_bigint6bigint14multiplication78_$LT$impl$u20$core..ops..arith..Mul$u20$for$u20$num_bigint..bigint..BigInt$GT$3mul17h13cbda9b0e54f985E
      (i32.add
       (local.get $3)
       (i32.const 144)
      )
      (i32.add
       (i32.add
        (local.get $3)
        (i32.const 80)
       )
       (i32.const 32)
      )
      (i32.add
       (local.get $3)
       (i32.const 32)
      )
     )
     (call $_ZN10num_bigint6bigint8addition78_$LT$impl$u20$core..ops..arith..Add$u20$for$u20$num_bigint..bigint..BigInt$GT$3add17hfc1517233be34752E
      (i32.add
       (local.get $0)
       (i32.const 32)
      )
      (i32.add
       (local.get $3)
       (i32.const 128)
      )
      (i32.add
       (local.get $3)
       (i32.const 144)
      )
     )
     (block $block10
      (br_if $block10
       (i32.lt_s
        (i32.load offset=80
         (local.get $3)
        )
        (i32.const 1)
       )
      )
      (call $free
       (i32.load offset=84
        (local.get $3)
       )
      )
     )
     (br_if $block11
      (i32.lt_s
       (i32.load offset=48
        (local.get $3)
       )
       (i32.const 1)
      )
     )
     (call $free
      (i32.load offset=52
       (local.get $3)
      )
     )
     (br $block11)
    )
    (i32.store offset=88
     (local.get $3)
     (local.get $2)
    )
    (i64.store offset=80
     (local.get $3)
     (i64.const 6442450944)
    )
    (i32.store8 offset=92
     (local.get $3)
     (i32.const 2)
    )
   )
   (call $_ZN10num_bigint6bigint6BigInt3pow17h3716f8cb56d5acc6E
    (i32.add
     (local.get $3)
     (i32.const 32)
    )
    (i32.add
     (local.get $3)
     (i32.const 80)
    )
    (i32.const 3)
   )
   (call $_ZN10num_bigint6bigint14multiplication78_$LT$impl$u20$core..ops..arith..Mul$u20$for$u20$num_bigint..bigint..BigInt$GT$3mul17h13cbda9b0e54f985E
    (i32.add
     (local.get $3)
     (i32.const 16)
    )
    (i32.add
     (local.get $3)
     (i32.const 128)
    )
    (i32.add
     (local.get $3)
     (i32.const 32)
    )
   )
   (local.set $9
    (i32.load8_u offset=28
     (local.get $3)
    )
   )
   (i32.store offset=40
    (local.get $3)
    (i32.load offset=24
     (local.get $3)
    )
   )
   (i64.store offset=32
    (local.get $3)
    (local.tee $8
     (i64.load offset=16 align=4
      (local.get $3)
     )
    )
   )
   (block $block13
    (block $block14
     (block $block12
      (br_if $block12
       (i32.ne
        (i32.wrap_i64
         (local.get $8)
        )
        (i32.const -2147483648)
       )
      )
      (br_if $block13
       (i32.ne
        (i32.load offset=36
         (local.get $3)
        )
        (i32.const 1)
       )
      )
      (local.set $5
       (i32.add
        (local.get $3)
        (i32.const 40)
       )
      )
      (local.set $1
       (i32.const 4)
      )
      (br $block14)
     )
     (br_if $block13
      (i32.eqz
       (local.tee $1
        (i32.load offset=40
         (local.get $3)
        )
       )
      )
     )
     (local.set $1
      (i32.shl
       (local.get $1)
       (i32.const 2)
      )
     )
     (local.set $5
      (i32.load offset=36
       (local.get $3)
      )
     )
    )
    (local.set $7
     (i32.add
      (local.get $5)
      (i32.const -4)
     )
    )
    (local.set $5
     (i32.const 0)
    )
    (loop $label
     (i32.store
      (local.tee $4
       (i32.add
        (local.get $7)
        (local.get $1)
       )
      )
      (i32.or
       (local.tee $4
        (i32.div_u
         (local.tee $5
          (i32.or
           (i32.shl
            (i32.add
             (i32.mul
              (local.tee $6
               (i32.div_u
                (i32.or
                 (i32.shl
                  (local.get $5)
                  (i32.const 16)
                 )
                 (local.tee $4
                  (i32.shr_u
                   (local.tee $5
                    (i32.load
                     (local.get $4)
                    )
                   )
                   (i32.const 16)
                  )
                 )
                )
                (i32.const 24)
               )
              )
              (i32.const 65512)
             )
             (local.get $4)
            )
            (i32.const 16)
           )
           (i32.and
            (local.get $5)
            (i32.const 65535)
           )
          )
         )
         (i32.const 24)
        )
       )
       (i32.shl
        (local.get $6)
        (i32.const 16)
       )
      )
     )
     (local.set $5
      (i32.add
       (i32.mul
        (local.get $4)
        (i32.const -24)
       )
       (local.get $5)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.add
        (local.get $1)
        (i32.const -4)
       )
      )
     )
    )
   )
   (call $_ZN10num_bigint9big_digit9BigDigits9normalize17h3304bda1751685ccE
    (i32.add
     (local.get $3)
     (i32.const 32)
    )
   )
   (i32.store offset=168
    (local.get $3)
    (i32.load offset=40
     (local.get $3)
    )
   )
   (i64.store offset=160
    (local.get $3)
    (local.tee $8
     (i64.load offset=32
      (local.get $3)
     )
    )
   )
   (local.set $1
    (i32.wrap_i64
     (local.get $8)
    )
   )
   (block $block17
    (block $block15
     (br_if $block15
      (i32.ne
       (i32.and
        (local.get $9)
        (i32.const 255)
       )
       (i32.const 1)
      )
     )
     (i32.store
      (i32.add
       (i32.add
        (local.get $3)
        (i32.const 160)
       )
       (select
        (i32.const 8)
        (i32.const 4)
        (local.tee $1
         (i32.ne
          (local.get $1)
          (i32.const -2147483648)
         )
        )
       )
      )
      (i32.const 0)
     )
     (block $block16
      (br_if $block16
       (local.get $1)
      )
      (br_if $block16
       (i32.load offset=164
        (local.get $3)
       )
      )
      (i64.store offset=160
       (local.get $3)
       (i64.const 2147483648)
      )
     )
     (call $_ZN10num_bigint9big_digit9BigDigits9normalize17h3304bda1751685ccE
      (i32.add
       (local.get $3)
       (i32.const 160)
      )
     )
     (local.set $7
      (i32.const 1)
     )
     (br $block17)
    )
    (block $block19
     (block $block18
      (br_if $block18
       (i32.eq
        (local.get $1)
        (i32.const -2147483648)
       )
      )
      (local.set $1
       (i32.eqz
        (i32.load offset=168
         (local.get $3)
        )
       )
      )
      (br $block19)
     )
     (local.set $1
      (i32.xor
       (i32.load offset=164
        (local.get $3)
       )
       (i32.const 1)
      )
     )
    )
    (local.set $7
     (select
      (i32.const 1)
      (local.get $9)
      (local.get $1)
     )
    )
   )
   (block $block20
    (br_if $block20
     (i32.lt_s
      (i32.load offset=80
       (local.get $3)
      )
      (i32.const 1)
     )
    )
    (call $free
     (i32.load offset=84
      (local.get $3)
     )
    )
   )
   (i32.store offset=88
    (local.get $3)
    (local.get $2)
   )
   (i32.store offset=84
    (local.get $3)
    (i32.ne
     (local.get $2)
     (i32.const 0)
    )
   )
   (i32.store offset=80
    (local.get $3)
    (i32.const -2147483648)
   )
   (call $_ZN10num_bigint7biguint14multiplication10scalar_mul17hf635b3c2da38325dE
    (i32.add
     (local.get $3)
     (i32.const 80)
    )
    (i32.const 545140134)
   )
   (i32.store offset=40
    (local.get $3)
    (i32.load offset=88
     (local.get $3)
    )
   )
   (i64.store offset=32
    (local.get $3)
    (local.tee $8
     (i64.load offset=80 align=4
      (local.get $3)
     )
    )
   )
   (local.set $4
    (i32.wrap_i64
     (local.get $8)
    )
   )
   (block $block27
    (block $block23
     (block $block21
      (br_if $block21
       (local.get $2)
      )
      (i32.store
       (i32.add
        (i32.add
         (local.get $3)
         (i32.const 32)
        )
        (select
         (i32.const 8)
         (i32.const 4)
         (local.tee $1
          (i32.ne
           (local.get $4)
           (i32.const -2147483648)
          )
         )
        )
       )
       (i32.const 0)
      )
      (block $block22
       (br_if $block22
        (local.get $1)
       )
       (br_if $block22
        (i32.load offset=36
         (local.get $3)
        )
       )
       (i64.store offset=32
        (local.get $3)
        (i64.const 2147483648)
       )
      )
      (call $_ZN10num_bigint9big_digit9BigDigits9normalize17h3304bda1751685ccE
       (i32.add
        (local.get $3)
        (i32.const 32)
       )
      )
      (local.set $4
       (i32.load offset=32
        (local.get $3)
       )
      )
      (br $block23)
     )
     (block $block25
      (block $block24
       (br_if $block24
        (i32.eq
         (local.get $4)
         (i32.const -2147483648)
        )
       )
       (br_if $block23
        (i32.eqz
         (local.tee $9
          (i32.load offset=40
           (local.get $3)
          )
         )
        )
       )
       (local.set $1
        (i32.load offset=36
         (local.get $3)
        )
       )
       (i32.store offset=88
        (local.get $3)
        (local.get $9)
       )
       (i32.store offset=84
        (local.get $3)
        (local.get $1)
       )
       (i32.store offset=80
        (local.get $3)
        (local.get $4)
       )
       (local.set $5
        (i32.load
         (local.get $1)
        )
       )
       (local.set $6
        (local.get $1)
       )
       (br $block25)
      )
      (block $block26
       (br_if $block26
        (i32.load offset=36
         (local.get $3)
        )
       )
       (local.set $9
        (i32.const 0)
       )
       (local.set $5
        (i32.const 13591409)
       )
       (local.set $4
        (i32.const -2147483648)
       )
       (local.set $1
        (i32.const 1)
       )
       (br $block27)
      )
      (i32.store offset=88
       (local.get $3)
       (local.tee $5
        (i32.load offset=40
         (local.get $3)
        )
       )
      )
      (i64.store offset=80 align=4
       (local.get $3)
       (i64.const 6442450944)
      )
      (local.set $6
       (i32.add
        (local.get $3)
        (i32.const 88)
       )
      )
      (local.set $4
       (i32.const -2147483648)
      )
      (local.set $1
       (i32.const 1)
      )
      (local.set $9
       (i32.const 1)
      )
     )
     (i32.store
      (local.get $6)
      (i32.add
       (local.get $5)
       (i32.const 13591409)
      )
     )
     (block $block30
      (block $block29
       (block $block28
        (br_if $block28
         (i32.lt_u
          (local.get $5)
          (i32.const -13591409)
         )
        )
        (local.set $1
         (i32.add
          (local.get $6)
          (i32.const 4)
         )
        )
        (local.set $5
         (i32.add
          (i32.shl
           (local.get $9)
           (i32.const 2)
          )
          (i32.const -4)
         )
        )
        (loop $label1
         (br_if $block29
          (i32.eqz
           (local.get $5)
          )
         )
         (i32.store
          (local.get $1)
          (local.tee $6
           (i32.add
            (i32.load
             (local.get $1)
            )
            (i32.const 1)
           )
          )
         )
         (local.set $5
          (i32.add
           (local.get $5)
           (i32.const -4)
          )
         )
         (local.set $1
          (i32.add
           (local.get $1)
           (i32.const 4)
          )
         )
         (br_if $label1
          (i32.eqz
           (local.get $6)
          )
         )
        )
        (local.set $1
         (i32.load offset=84
          (local.get $3)
         )
        )
       )
       (local.set $5
        (i32.load offset=88
         (local.get $3)
        )
       )
       (br $block30)
      )
      (block $block31
       (br_if $block31
        (i32.eq
         (local.get $4)
         (i32.const -2147483648)
        )
       )
       (block $block32
        (br_if $block32
         (i32.ne
          (local.tee $5
           (i32.load offset=88
            (local.get $3)
           )
          )
          (local.get $4)
         )
        )
        (call $_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hdda5a8d5b445364dE
         (i32.add
          (local.get $3)
          (i32.const 80)
         )
        )
        (local.set $4
         (i32.load offset=80
          (local.get $3)
         )
        )
       )
       (i32.store
        (i32.add
         (local.tee $1
          (i32.load offset=84
           (local.get $3)
          )
         )
         (i32.shl
          (local.get $5)
          (i32.const 2)
         )
        )
        (i32.const 1)
       )
       (i32.store offset=88
        (local.get $3)
        (local.tee $5
         (i32.add
          (local.get $5)
          (i32.const 1)
         )
        )
       )
       (br $block30)
      )
      (local.set $1
       (i32.const 1)
      )
      (block $block34
       (block $block33
        (br_if $block33
         (i32.ne
          (i32.load offset=84
           (local.get $3)
          )
          (i32.const 1)
         )
        )
        (local.set $5
         (i32.load offset=88
          (local.get $3)
         )
        )
        (br_if $block34
         (i32.eqz
          (local.tee $1
           (call $malloc
            (i32.const 8)
           )
          )
         )
        )
        (i32.store offset=4
         (local.get $1)
         (i32.const 1)
        )
        (i32.store
         (local.get $1)
         (local.get $5)
        )
        (local.set $9
         (i32.const 0)
        )
        (local.set $4
         (i32.const 2)
        )
        (local.set $5
         (i32.const 2)
        )
        (br $block27)
       )
       (local.set $9
        (i32.const 0)
       )
       (local.set $4
        (i32.const -2147483648)
       )
       (local.set $5
        (i32.const 1)
       )
       (br $block27)
      )
      (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
       (i32.const 4)
       (i32.const 8)
      )
      (unreachable)
     )
     (block $block38
      (block $block36
       (block $block35
        (br_if $block35
         (i32.eq
          (local.get $4)
          (i32.const -2147483648)
         )
        )
        (br_if $block36
         (i32.eqz
          (local.get $5)
         )
        )
        (local.set $9
         (i32.const 0)
        )
        (br $block27)
       )
       (block $block37
        (br_if $block37
         (i32.eqz
          (i32.and
           (local.get $1)
           (i32.const 1)
          )
         )
        )
        (local.set $9
         (i32.const 0)
        )
        (local.set $1
         (i32.const 1)
        )
        (local.set $4
         (i32.const -2147483648)
        )
        (br $block27)
       )
       (local.set $9
        (i32.const 1)
       )
       (br $block38)
      )
      (local.set $9
       (i32.const 1)
      )
      (br_if $block38
       (i32.eqz
        (local.get $4)
       )
      )
      (call $free
       (local.get $1)
      )
     )
     (local.set $1
      (i32.const 0)
     )
     (local.set $4
      (i32.const -2147483648)
     )
     (br $block27)
    )
    (local.set $1
     (i32.const 1)
    )
    (local.set $6
     (i32.lt_s
      (local.get $4)
      (i32.const 1)
     )
    )
    (local.set $9
     (i32.const 0)
    )
    (local.set $5
     (i32.const 13591409)
    )
    (local.set $4
     (i32.const -2147483648)
    )
    (br_if $block27
     (local.get $6)
    )
    (call $free
     (i32.load offset=36
      (local.get $3)
     )
    )
   )
   (i32.store offset=40
    (local.get $3)
    (local.get $5)
   )
   (i32.store offset=36
    (local.get $3)
    (local.get $1)
   )
   (i32.store offset=32
    (local.get $3)
    (local.get $4)
   )
   (local.set $6
    (i32.load8_u offset=12
     (local.get $3)
    )
   )
   (local.set $10
    (i32.add
     (local.get $3)
     (i32.const 40)
    )
   )
   (block $block51
    (block $block44
     (block $block48
      (block $block43
       (block $block42
        (block $block40
         (block $block41
          (block $block39
           (br_if $block39
            (i32.ne
             (local.tee $11
              (i32.load
               (local.get $3)
              )
             )
             (i32.const -2147483648)
            )
           )
           (br_if $block40
            (i32.ne
             (i32.load offset=4
              (local.get $3)
             )
             (i32.const 1)
            )
           )
           (local.set $12
            (i32.const 1)
           )
           (local.set $15
            (select
             (local.tee $13
              (i32.and
               (local.get $1)
               (i32.const 1)
              )
             )
             (local.get $5)
             (local.tee $14
              (i32.eq
               (local.get $4)
               (i32.const -2147483648)
              )
             )
            )
           )
           (local.set $13
            (select
             (select
              (local.get $10)
              (i32.const 4)
              (local.get $13)
             )
             (local.get $1)
             (local.get $14)
            )
           )
           (local.set $14
            (i32.add
             (local.get $3)
             (i32.const 8)
            )
           )
           (local.set $16
            (i32.const 1)
           )
           (local.set $10
            (i32.const 1)
           )
           (br $block41)
          )
          (br_if $block40
           (i32.eqz
            (local.tee $12
             (i32.load offset=8
              (local.get $3)
             )
            )
           )
          )
          (local.set $15
           (select
            (local.tee $13
             (i32.and
              (local.get $1)
              (i32.const 1)
             )
            )
            (local.get $5)
            (local.tee $14
             (i32.eq
              (local.get $4)
              (i32.const -2147483648)
             )
            )
           )
          )
          (local.set $13
           (select
            (select
             (local.get $10)
             (i32.const 4)
             (local.get $13)
            )
            (local.get $1)
            (local.get $14)
           )
          )
          (local.set $14
           (local.tee $10
            (i32.load offset=4
             (local.get $3)
            )
           )
          )
          (local.set $16
           (local.get $10)
          )
         )
         (br_table $block40 $block42 $block43
          (local.get $15)
         )
        )
        (i32.store offset=184
         (local.get $3)
         (i32.load offset=1058380
          (i32.const 0)
         )
        )
        (i64.store offset=176
         (local.get $3)
         (i64.load offset=1058372 align=4
          (i32.const 0)
         )
        )
        (br $block44)
       )
       (local.set $15
        (i32.const -2147483648)
       )
       (local.set $12
        (i32.load
         (local.get $13)
        )
       )
       (local.set $5
        (i32.load offset=8
         (local.get $3)
        )
       )
       (block $block45
        (br_if $block45
         (i32.eq
          (local.get $11)
          (i32.const -2147483648)
         )
        )
        (local.set $10
         (local.get $5)
        )
        (block $block47
         (block $block46
          (br_table $block45 $block46 $block47
           (local.get $5)
          )
         )
         (local.set $5
          (i32.load
           (local.get $16)
          )
         )
         (local.set $10
          (i32.const 1)
         )
         (br $block45)
        )
        (br_if $block48
         (i32.eqz
          (local.tee $10
           (call $_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc
            (local.tee $11
             (i32.shl
              (local.get $5)
              (i32.const 2)
             )
            )
            (i32.const 4)
           )
          )
         )
        )
        (block $block49
         (br_if $block49
          (i32.eqz
           (local.get $11)
          )
         )
         (memory.copy
          (local.get $10)
          (local.get $16)
          (local.get $11)
         )
        )
        (local.set $15
         (local.get $5)
        )
       )
       (i32.store offset=88
        (local.get $3)
        (local.get $5)
       )
       (i32.store offset=84
        (local.get $3)
        (local.get $10)
       )
       (i32.store offset=80
        (local.get $3)
        (local.get $15)
       )
       (call $_ZN10num_bigint7biguint14multiplication10scalar_mul17hf635b3c2da38325dE
        (i32.add
         (local.get $3)
         (i32.const 80)
        )
        (local.get $12)
       )
       (i32.store offset=184
        (local.get $3)
        (i32.load offset=88
         (local.get $3)
        )
       )
       (i64.store offset=176
        (local.get $3)
        (i64.load offset=80 align=4
         (local.get $3)
        )
       )
       (br $block44)
      )
      (block $block50
       (br_if $block50
        (i32.eq
         (local.get $12)
         (i32.const 1)
        )
       )
       (call $_ZN10num_bigint7biguint14multiplication4mul317h1136dccddf5cc4a4E
        (i32.add
         (local.get $3)
         (i32.const 176)
        )
        (local.get $14)
        (local.get $12)
        (local.get $13)
        (local.get $15)
       )
       (br $block44)
      )
      (local.set $10
       (i32.load
        (local.get $14)
       )
      )
      (i32.store offset=88
       (local.get $3)
       (local.get $5)
      )
      (i32.store offset=84
       (local.get $3)
       (local.get $1)
      )
      (i32.store offset=80
       (local.get $3)
       (local.get $4)
      )
      (call $_ZN10num_bigint7biguint14multiplication10scalar_mul17hf635b3c2da38325dE
       (i32.add
        (local.get $3)
        (i32.const 80)
       )
       (local.get $10)
      )
      (i32.store offset=184
       (local.get $3)
       (i32.load offset=88
        (local.get $3)
       )
      )
      (i64.store offset=176
       (local.get $3)
       (i64.load offset=80 align=4
        (local.get $3)
       )
      )
      (br $block51)
     )
     (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
      (i32.const 4)
      (local.get $11)
     )
     (unreachable)
    )
    (br_if $block51
     (i32.lt_s
      (local.get $4)
      (i32.const 1)
     )
    )
    (call $free
     (local.get $1)
    )
   )
   (local.set $5
    (i32.and
     (local.get $2)
     (i32.const 1)
    )
   )
   (local.set $1
    (i32.load offset=176
     (local.get $3)
    )
   )
   (block $block61
    (block $block64
     (block $block55
      (block $block58
       (block $block59
        (block $block54
         (block $block52
          (br_if $block52
           (i32.eqz
            (i32.or
             (local.get $9)
             (i32.eq
              (local.get $6)
              (i32.const 1)
             )
            )
           )
          )
          (i32.store
           (i32.add
            (i32.add
             (local.get $3)
             (i32.const 176)
            )
            (select
             (i32.const 8)
             (i32.const 4)
             (local.tee $1
              (i32.ne
               (local.get $1)
               (i32.const -2147483648)
              )
             )
            )
           )
           (i32.const 0)
          )
          (block $block53
           (br_if $block53
            (local.get $1)
           )
           (br_if $block53
            (i32.load offset=180
             (local.get $3)
            )
           )
           (i64.store offset=176
            (local.get $3)
            (i64.const 2147483648)
           )
          )
          (call $_ZN10num_bigint9big_digit9BigDigits9normalize17h3304bda1751685ccE
           (i32.add
            (local.get $3)
            (i32.const 176)
           )
          )
          (i64.store offset=192
           (local.get $3)
           (local.tee $8
            (i64.load offset=176
             (local.get $3)
            )
           )
          )
          (i32.store offset=200
           (local.get $3)
           (i32.load offset=184
            (local.get $3)
           )
          )
          (local.set $1
           (i32.ne
            (i32.wrap_i64
             (local.get $8)
            )
            (i32.const -2147483648)
           )
          )
          (br_if $block54
           (i32.eqz
            (local.get $5)
           )
          )
          (br $block55)
         )
         (local.set $4
          (select
           (i32.const 2)
           (i32.const 0)
           (local.get $6)
          )
         )
         (block $block57
          (block $block56
           (br_if $block56
            (i32.eq
             (local.get $1)
             (i32.const -2147483648)
            )
           )
           (local.set $1
            (i32.eqz
             (i32.load offset=184
              (local.get $3)
             )
            )
           )
           (br $block57)
          )
          (local.set $1
           (i32.xor
            (i32.load offset=180
             (local.get $3)
            )
            (i32.const 1)
           )
          )
         )
         (local.set $1
          (select
           (i32.const 1)
           (local.get $4)
           (local.get $1)
          )
         )
         (br_if $block58
          (local.get $5)
         )
         (i32.store offset=200
          (local.get $3)
          (i32.load offset=184
           (local.get $3)
          )
         )
         (i64.store offset=192
          (local.get $3)
          (local.tee $8
           (i64.load offset=176
            (local.get $3)
           )
          )
         )
         (local.set $5
          (i32.wrap_i64
           (local.get $8)
          )
         )
         (br_if $block59
          (i32.ne
           (local.get $1)
           (i32.const 1)
          )
         )
         (local.set $1
          (i32.ne
           (local.get $5)
           (i32.const -2147483648)
          )
         )
        )
        (i32.store
         (i32.add
          (i32.add
           (local.get $3)
           (i32.const 192)
          )
          (select
           (i32.const 8)
           (i32.const 4)
           (local.get $1)
          )
         )
         (i32.const 0)
        )
        (block $block60
         (br_if $block60
          (local.get $1)
         )
         (br_if $block60
          (i32.load offset=196
           (local.get $3)
          )
         )
         (i64.store offset=192
          (local.get $3)
          (i64.const 2147483648)
         )
        )
        (call $_ZN10num_bigint9big_digit9BigDigits9normalize17h3304bda1751685ccE
         (i32.add
          (local.get $3)
          (i32.const 192)
         )
        )
        (local.set $1
         (i32.const 1)
        )
        (br $block61)
       )
       (block $block63
        (block $block62
         (br_if $block62
          (i32.eq
           (local.get $5)
           (i32.const -2147483648)
          )
         )
         (local.set $5
          (i32.eqz
           (i32.load offset=200
            (local.get $3)
           )
          )
         )
         (br $block63)
        )
        (local.set $5
         (i32.xor
          (i32.load offset=196
           (local.get $3)
          )
          (i32.const 1)
         )
        )
       )
       (local.set $1
        (select
         (i32.const 1)
         (local.get $1)
         (local.get $5)
        )
       )
       (br $block61)
      )
      (i32.store offset=200
       (local.get $3)
       (i32.load offset=184
        (local.get $3)
       )
      )
      (i64.store offset=192
       (local.get $3)
       (local.tee $8
        (i64.load offset=176
         (local.get $3)
        )
       )
      )
      (local.set $5
       (i32.wrap_i64
        (local.get $8)
       )
      )
      (br_if $block64
       (i32.eqz
        (i32.and
         (local.get $1)
         (i32.const 1)
        )
       )
      )
      (local.set $1
       (i32.ne
        (local.get $5)
        (i32.const -2147483648)
       )
      )
     )
     (i32.store
      (i32.add
       (i32.add
        (local.get $3)
        (i32.const 192)
       )
       (select
        (i32.const 8)
        (i32.const 4)
        (local.get $1)
       )
      )
      (i32.const 0)
     )
     (block $block65
      (br_if $block65
       (local.get $1)
      )
      (br_if $block65
       (i32.load offset=196
        (local.get $3)
       )
      )
      (i64.store offset=192
       (local.get $3)
       (i64.const 2147483648)
      )
     )
     (call $_ZN10num_bigint9big_digit9BigDigits9normalize17h3304bda1751685ccE
      (i32.add
       (local.get $3)
       (i32.const 192)
      )
     )
     (local.set $1
      (i32.const 1)
     )
     (br $block61)
    )
    (local.set $1
     (i32.sub
      (i32.const 2)
      (local.get $1)
     )
    )
    (block $block67
     (block $block66
      (br_if $block66
       (i32.eq
        (local.get $5)
        (i32.const -2147483648)
       )
      )
      (local.set $5
       (i32.eqz
        (i32.load offset=200
         (local.get $3)
        )
       )
      )
      (br $block67)
     )
     (local.set $5
      (i32.xor
       (i32.load offset=196
        (local.get $3)
       )
       (i32.const 1)
      )
     )
    )
    (local.set $1
     (select
      (i32.const 1)
      (local.get $1)
      (local.get $5)
     )
    )
   )
   (i64.store offset=8 align=4
    (local.get $0)
    (i64.load offset=8
     (local.get $3)
    )
   )
   (i64.store align=4
    (local.get $0)
    (i64.load
     (local.get $3)
    )
   )
   (i64.store offset=16 align=4
    (local.get $0)
    (i64.load offset=160
     (local.get $3)
    )
   )
   (i32.store offset=24
    (local.get $0)
    (i32.load offset=168
     (local.get $3)
    )
   )
   (i32.store8 offset=28
    (local.get $0)
    (local.get $7)
   )
   (i64.store offset=32 align=4
    (local.get $0)
    (i64.load offset=192
     (local.get $3)
    )
   )
   (i32.store offset=40
    (local.get $0)
    (i32.load offset=200
     (local.get $3)
    )
   )
   (i32.store8 offset=44
    (local.get $0)
    (local.get $1)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 208)
   )
  )
 )
