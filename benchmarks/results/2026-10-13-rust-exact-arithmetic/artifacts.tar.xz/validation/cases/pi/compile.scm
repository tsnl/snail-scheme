(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-rust-bigint-review-20261013/build/rust-bigint-reviewed-full/cases/pi/program.scm" "/tmp/snail-rust-bigint-review-20261013/build/rust-bigint-reviewed-full/cases/pi/program.so"))
