(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-rust-full-reference-20261013/build/compiler-asm-linked-draft/assembler.scm" "/tmp/snail-rust-full-reference-20261013/build/compiler-asm-linked-draft/assembler.so"))
