(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-rust-full-reference-20261013/build/compiler-gvm-with-assembler/raw-gvm.scm" "/tmp/snail-rust-full-reference-20261013/build/compiler-gvm-with-assembler/raw-gvm.so"))
