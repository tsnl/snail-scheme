(import (chezscheme))
(parameterize ((optimize-level 2)) (compile-program "/tmp/snail-rust-full-reference-20261013/build/compiler-gvm-with-assembler/purified-gvm.scm" "/tmp/snail-rust-full-reference-20261013/build/compiler-gvm-with-assembler/purified-gvm.so"))
