(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-fft-20261013/build/strict-fft-probe-b-unit-tail/fft/chez-dft-probe/program.scm" "/tmp/snail-strict-fft-20261013/build/strict-fft-probe-b-unit-tail/fft/chez-dft-probe/program.so"))
