(module
 (rec
  (type $type0 (struct (field (ref $environment38))))
  (type $type30 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $environment38 (struct (field i64) (field (ref $type30))))
  (type $call0 (func (param (ref $environment38) i64 f64) (result f64)))
  (type $type23 (struct (field (ref $environment36))))
  (type $type24 (struct (field (mut i32)) (field (mut (ref null $type23)))))
  (type $environment36 (struct (field (ref $type20)) (field (ref $type24))))
  (type $call23 (func (param (ref $environment36) i64) (result i32)))
  (type $environment35 (struct (field (ref $type19)) (field i64) (field f64) (field (ref $type12)) (field f64) (field (ref $type22)) (field (ref $type29)) (field (ref $type25)) (field (ref $type25)) (field i64)))
  (type $call28 (func (param (ref $environment34) f64 f64 i64) (result i32)))
  (type $type28 (struct (field (ref $environment34))))
  (type $environment34 (struct (field i64) (field (ref $type19)) (field (ref $type12)) (field (ref $type29)) (field (ref $type25)) (field (ref $type25))))
  (type $type29 (struct (field (mut i32)) (field (mut (ref null $type28)))))
  (type $environment32 (struct (field (ref $type27)) (field (ref $type27)) (field i64)))
  (type $environment33 (struct (field (ref $type19)) (field (ref $type25)) (field (ref $type12)) (field (ref $type22))))
  (type $type25 (struct (field f64)))
  (type $call26 (func (param (ref struct) i64 i64) (result i32)))
  (type $environment31 (struct (field (ref $type19)) (field (ref $type12)) (field (ref $type27))))
  (type $type26 (struct (field (ref $call26)) (field (ref struct))))
  (type $type27 (struct (field (mut i32)) (field (mut (ref null $type26)))))
  (type $call17 (func (param (ref $type12)) (result i32)))
  (type $type21 (struct (field (ref $call21)) (field (ref struct))))
  (type $type22 (struct (field (mut i32)) (field (mut (ref null $type21)))))
  (type $type12 (array (mut f64)))
  (type $type20 (struct (field (ref $type12))))
  (type $type19 (struct (field i64)))
  (type $environment26 (struct (field (ref $type19)) (field (ref $type20)) (field (ref $type22))))
  (type $call21 (func (param (ref struct) i64) (result i32)))
  (type $type18 (struct))
  (type $type17 (struct))
  (type $type16 (struct))
  (type $type15 (struct))
  (type $type14 (struct))
  (type $type13 (struct))
  (type $type11 (struct))
 )
 (type $35 (func (param i32) (result i64)))
 (type $36 (func (param i64) (result f64)))
 (type $37 (func (param i32 i64) (result f64)))
 (type $38 (func (result f64)))
 (type $39 (func (result i64)))
 (type $40 (func (param f64) (result f64)))
 (type $41 (func (result i32)))
 (type $42 (func (param i32) (result f64)))
 (type $43 (func (param i64) (result i64)))
 (type $44 (func))
 (import "benchmark" "vector_length" (func $foreign0 (param i32) (result i64)))
 (import "benchmark" "vector_f64" (func $foreign1 (param i32 i64) (result f64)))
 (import "benchmark" "tolerance" (func $foreign2 (result f64)))
 (import "benchmark" "expected_length" (func $foreign3 (result i64)))
 (import "math" "snail_sin" (func $foreign4 (param f64) (result f64)))
 (import "benchmark" "expected_f64" (func $foreign5 (param i64) (result f64)))
 (import "benchmark" "barrier" (func $foreign6 (result i32)))
 (import "benchmark" "input_f64" (func $foreign7 (param i32) (result f64)))
 (import "benchmark" "input_i64" (func $foreign8 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type11)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global67 (mut (ref null $type13)) (ref.null none))
 (global $ready67 (mut i32) (i32.const 0))
 (global $global69 (mut (ref null $type14)) (ref.null none))
 (global $ready69 (mut i32) (i32.const 0))
 (global $global75 (mut (ref null $type15)) (ref.null none))
 (global $ready75 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type16)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global78 (mut (ref null $type17)) (ref.null none))
 (global $ready78 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type18)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global109 (mut i64) (i64.const 0))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut f64) (f64.const 0))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type13)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "fft-probe" (func $export1))
 (export "main" (func $main))
 (func $function26 (type $call21) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment26))
  (local $3 f64)
  (if
   (i64.gt_s
    (struct.get $type19 0
     (struct.get $environment26 0
      (local.tee $2
       (ref.cast (ref $environment26)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $3
     (call $foreign1
      (i32.const 2)
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type20 0
      (struct.get $environment26 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type22 0
       (struct.get $environment26 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function26
      (struct.get $type21 1
       (struct.get $type22 1
        (struct.get $environment26 2
         (local.get $2)
        )
       )
      )
      (i64.add
       (local.get $1)
       (i64.const 1)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function30 (type $call17) (param $0 (ref $type12)) (result i32)
  (local $1 (ref $type27))
  (local $2 (ref $type22))
  (local $3 (ref $type19))
  (local $4 (ref $type26))
  (local $5 (ref $type21))
  (struct.set $type27 1
   (local.tee $1
    (struct.new_default $type27)
   )
   (struct.new $type26
    (ref.func $function31)
    (struct.new $environment31
     (local.tee $3
      (struct.new $type19
       (i64.extend_i32_u
        (array.len
         (local.get $0)
        )
       )
      )
     )
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type27 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type27 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call26
    (struct.get $type26 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type27 1
        (local.get $1)
       )
      )
     )
    )
    (i64.const 0)
    (i64.const 0)
    (struct.get $type26 0
     (local.get $4)
    )
   )
  )
  (struct.set $type22 1
   (local.tee $2
    (struct.new_default $type22)
   )
   (struct.new $type21
    (ref.func $function33)
    (struct.new $environment33
     (local.get $3)
     (struct.new $type25
      (f64.const 6.28318530717959)
     )
     (local.get $0)
     (local.get $2)
    )
   )
  )
  (struct.set $type22 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call21
   (struct.get $type21 1
    (local.tee $5
     (ref.as_non_null
      (struct.get $type22 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 2)
   (struct.get $type21 0
    (local.get $5)
   )
  )
 )
 (func $function31 (type $call26) (param $0 (ref struct)) (param $1 i64) (param $2 i64) (result i32)
  (local $3 (ref $environment31))
  (local $4 (ref $type27))
  (local $5 (ref $type26))
  (local $6 i64)
  (local $7 f64)
  (local $8 f64)
  (if
   (i64.gt_s
    (struct.get $type19 0
     (struct.get $environment31 0
      (local.tee $3
       (ref.cast (ref $environment31)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.lt_s
      (local.get $1)
      (local.get $2)
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (array.get $type12
        (struct.get $environment31 1
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (array.get $type12
        (struct.get $environment31 1
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $2)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $environment31 1
        (local.get $3)
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $8)
      )
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $environment31 1
        (local.get $3)
       )
       (i32.wrap_i64
        (local.get $2)
       )
       (local.get $7)
      )
      (if
       (i64.gt_u
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (array.get $type12
        (struct.get $environment31 1
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $6
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (array.get $type12
        (struct.get $environment31 1
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $6)
        )
       )
      )
      (if
       (i64.gt_u
        (local.tee $6
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $environment31 1
        (local.get $3)
       )
       (i32.wrap_i64
        (local.get $6)
       )
       (local.get $8)
      )
      (if
       (i64.gt_u
        (local.tee $6
         (i64.add
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type12
       (struct.get $environment31 1
        (local.get $3)
       )
       (i32.wrap_i64
        (local.get $6)
       )
       (local.get $7)
      )
     )
    )
    (struct.set $type27 1
     (local.tee $4
      (struct.new_default $type27)
     )
     (struct.new $type26
      (ref.func $function32)
      (struct.new $environment32
       (local.get $4)
       (struct.get $environment31 2
        (local.get $3)
       )
       (local.get $1)
      )
     )
    )
    (struct.set $type27 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type27 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call26
      (struct.get $type26 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type27 1
          (local.get $4)
         )
        )
       )
      )
      (i64.div_s
       (struct.get $type19 0
        (struct.get $environment31 0
         (local.get $3)
        )
       )
       (i64.const 2)
      )
      (local.get $2)
      (struct.get $type26 0
       (local.get $5)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function32 (type $call26) (param $0 (ref struct)) (param $1 i64) (param $2 i64) (result i32)
  (local $3 (ref $environment32))
  (local $4 i64)
  (if
   (i32.and
    (i64.le_s
     (local.get $1)
     (local.get $2)
    )
    (i64.ge_s
     (local.get $1)
     (i64.const 2)
    )
   )
   (then
    (if
     (i32.eqz
      (struct.get $type27 0
       (struct.get $environment32 0
        (ref.cast (ref $environment32)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function32
     (struct.get $type26 1
      (struct.get $type27 1
       (struct.get $environment32 0
        (ref.cast (ref $environment32)
         (local.get $0)
        )
       )
      )
     )
     (i64.div_s
      (local.get $1)
      (i64.const 2)
     )
     (i64.sub
      (local.get $2)
      (local.get $1)
     )
    )
   )
   (else
    (local.set $4
     (struct.get $environment32 2
      (local.tee $3
       (ref.cast (ref $environment32)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type27 0
       (struct.get $environment32 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function31
     (struct.get $type26 1
      (struct.get $type27 1
       (struct.get $environment32 1
        (local.get $3)
       )
      )
     )
     (i64.add
      (local.get $4)
      (i64.const 2)
     )
     (i64.add
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function33 (type $call21) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment33))
  (local $3 (ref $type29))
  (local $4 f64)
  (local $5 f64)
  (if
   (i64.gt_s
    (struct.get $type19 0
     (struct.get $environment33 0
      (local.tee $2
       (ref.cast (ref $environment33)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready67)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global67)
     )
    )
    (struct.set $type29 1
     (local.tee $3
      (struct.new_default $type29)
     )
     (struct.new $type28
      (struct.new $environment34
       (local.get $1)
       (struct.get $environment33 0
        (local.get $2)
       )
       (struct.get $environment33 2
        (local.get $2)
       )
       (local.get $3)
       (struct.new $type25
        (f64.mul
         (f64.mul
          (local.tee $5
           (call $foreign4
            (f64.mul
             (local.tee $4
              (f64.div
               (struct.get $type25 0
                (struct.get $environment33 1
                 (local.get $2)
                )
               )
               (f64.convert_i64_s
                (local.get $1)
               )
              )
             )
             (f64.const 0.5)
            )
           )
          )
          (local.get $5)
         )
         (f64.const -2)
        )
       )
       (struct.new $type25
        (call $foreign4
         (local.get $4)
        )
       )
      )
     )
    )
    (struct.set $type29 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type29 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function34
      (struct.get $type28 0
       (struct.get $type29 1
        (local.get $3)
       )
      )
      (f64.const 1)
      (f64.const 0)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type22 0
       (struct.get $environment33 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function33
      (struct.get $type21 1
       (struct.get $type22 1
        (struct.get $environment33 3
         (local.get $2)
        )
       )
      )
      (i64.shl
       (local.get $1)
       (i64.const 1)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function34 (type $call28) (param $0 (ref $environment34)) (param $1 f64) (param $2 f64) (param $3 i64) (result i32)
  (local $4 (ref $type22))
  (local $5 (ref $type21))
  (local $6 i64)
  (if
   (i64.gt_s
    (local.tee $6
     (struct.get $environment34 0
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (struct.set $type22 1
     (local.tee $4
      (struct.new_default $type22)
     )
     (struct.new $type21
      (ref.func $function35)
      (struct.new $environment35
       (struct.get $environment34 1
        (local.get $0)
       )
       (local.get $6)
       (local.get $1)
       (struct.get $environment34 2
        (local.get $0)
       )
       (local.get $2)
       (local.get $4)
       (struct.get $environment34 3
        (local.get $0)
       )
       (struct.get $environment34 4
        (local.get $0)
       )
       (struct.get $environment34 5
        (local.get $0)
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type22 0
     (local.get $4)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type22 0
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call21
      (struct.get $type21 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type22 1
          (local.get $4)
         )
        )
       )
      )
      (local.get $3)
      (struct.get $type21 0
       (local.get $5)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function35 (type $call21) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment35))
  (local $3 (ref $type12))
  (local $4 i64)
  (local $5 i64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (if
   (i64.gt_s
    (struct.get $type19 0
     (struct.get $environment35 0
      (local.tee $2
       (ref.cast (ref $environment35)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.gt_u
      (local.tee $4
       (i64.add
        (struct.get $environment35 1
         (local.get $2)
        )
        (local.get $1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (f64.sub
      (f64.mul
       (struct.get $environment35 2
        (local.get $2)
       )
       (array.get $type12
        (local.tee $3
         (struct.get $environment35 3
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (f64.mul
       (struct.get $environment35 4
        (local.get $2)
       )
       (array.get $type12
        (local.get $3)
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (f64.add
      (f64.mul
       (struct.get $environment35 2
        (local.get $2)
       )
       (array.get $type12
        (local.tee $3
         (struct.get $environment35 3
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (f64.mul
       (struct.get $environment35 4
        (local.get $2)
       )
       (array.get $type12
        (local.get $3)
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (f64.sub
      (array.get $type12
       (struct.get $environment35 3
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (local.get $6)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment35 3
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $8)
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (f64.sub
      (array.get $type12
       (struct.get $environment35 3
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
      (local.get $7)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment35 3
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $5)
     )
     (local.get $8)
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (f64.add
      (array.get $type12
       (struct.get $environment35 3
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (local.get $6)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment35 3
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $6)
    )
    (if
     (i64.gt_u
      (local.tee $1
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (f64.add
      (array.get $type12
       (struct.get $environment35 3
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (local.get $7)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $environment35 3
      (local.get $2)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (struct.get $type22 0
       (struct.get $environment35 5
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function35
     (struct.get $type21 1
      (struct.get $type22 1
       (struct.get $environment35 5
        (local.get $2)
       )
      )
     )
     (i64.add
      (struct.get $environment35 1
       (local.get $2)
      )
      (local.get $4)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type29 0
       (struct.get $environment35 6
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function34
     (struct.get $type28 0
      (struct.get $type29 1
       (struct.get $environment35 6
        (local.get $2)
       )
      )
     )
     (f64.add
      (f64.sub
       (f64.mul
        (local.tee $6
         (struct.get $environment35 2
          (local.get $2)
         )
        )
        (local.tee $8
         (struct.get $type25 0
          (struct.get $environment35 7
           (local.get $2)
          )
         )
        )
       )
       (f64.mul
        (local.tee $7
         (struct.get $environment35 4
          (local.get $2)
         )
        )
        (local.tee $9
         (struct.get $type25 0
          (struct.get $environment35 8
           (local.get $2)
          )
         )
        )
       )
      )
      (local.get $6)
     )
     (f64.add
      (f64.add
       (f64.mul
        (local.get $7)
        (local.get $8)
       )
       (f64.mul
        (local.get $6)
        (local.get $9)
       )
      )
      (local.get $7)
     )
     (i64.add
      (struct.get $environment35 9
       (local.get $2)
      )
      (i64.const 2)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function36 (type $call23) (param $0 (ref $environment36)) (param $1 i64) (result i32)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (array.len
       (struct.get $type20 0
        (struct.get $environment36 0
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.get $type12
      (struct.get $type20 0
       (struct.get $environment36 0
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $2
     (call $foreign5
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready69)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global69)
     )
    )
    (if (result i32)
     (f64.ge
      (f64.mul
       (call $foreign2)
       (select
        (f64.const 1)
        (local.tee $4
         (select
          (f64.sub
           (f64.const 0)
           (local.get $2)
          )
          (local.get $2)
          (f64.lt
           (local.get $2)
           (f64.const 0)
          )
         )
        )
        (f64.lt
         (local.get $4)
         (f64.const 1)
        )
       )
      )
      (select
       (f64.sub
        (f64.const 0)
        (local.tee $2
         (f64.sub
          (local.get $3)
          (local.get $2)
         )
        )
       )
       (local.get $2)
       (f64.lt
        (local.get $2)
        (f64.const 0)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type24 0
         (struct.get $environment36 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function36
       (struct.get $type23 0
        (struct.get $type24 1
         (struct.get $environment36 1
          (local.get $0)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function38 (type $call0) (param $0 (ref $environment38)) (param $1 i64) (param $2 f64) (result f64)
  (local $3 (ref $type12))
  (local $4 i64)
  (if (result f64)
   (i64.gt_s
    (struct.get $environment38 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (global.get $global109)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready116)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.new $type12
      (global.get $global110)
      (i32.wrap_i64
       (local.get $4)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i32.eqz
      (call $foreign6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready119)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global119)
     )
    )
    (if
     (i32.eqz
      (global.get $ready78)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global78)
     )
    )
    (drop
     (call $function30
      (local.get $3)
     )
    )
    (local.set $2
     (array.get $type12
      (local.get $3)
      (i32.const 0)
     )
    )
    (if
     (i32.eqz
      (struct.get $type30 0
       (struct.get $environment38 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function38
     (struct.get $type0 0
      (struct.get $type30 1
       (struct.get $environment38 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result f64)
  (local $1 (ref $type30))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready111)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (struct.set $type30 1
   (local.tee $1
    (struct.new_default $type30)
   )
   (struct.new $type0
    (struct.new $environment38
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type30 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type30 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function38
   (struct.get $type0 0
    (struct.get $type30 1
     (local.get $1)
    )
   )
   (i64.const 0)
   (f64.const 0)
  )
 )
 (func $export1 (param $0 i64) (result i64)
  (local $1 (ref $type22))
  (local $2 (ref $type24))
  (local $3 (ref $type20))
  (local $4 (ref $type19))
  (local $5 (ref $type21))
  (local $6 (ref $type12))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready75)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global75)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (struct.get $type19 0
      (local.tee $4
       (struct.new $type19
        (call $foreign0
         (i32.const 2)
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type22 1
   (local.tee $1
    (struct.new_default $type22)
   )
   (struct.new $type21
    (ref.func $function26)
    (struct.new $environment26
     (local.get $4)
     (local.tee $3
      (struct.new $type20
       (array.new_default $type12
        (i32.wrap_i64
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (struct.set $type22 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type22 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call21
    (struct.get $type21 1
     (local.tee $5
      (ref.as_non_null
       (struct.get $type22 1
        (local.get $1)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type21 0
     (local.get $5)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready78)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global78)
   )
  )
  (drop
   (call $function30
    (local.tee $6
     (struct.get $type20 0
      (local.tee $3
       (struct.new $type20
        (struct.get $type20 0
         (local.get $3)
        )
       )
      )
     )
    )
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (i64.eq
      (call $foreign3)
      (i64.extend_i32_u
       (array.len
        (local.get $6)
       )
      )
     )
     (then
      (struct.set $type24 1
       (local.tee $2
        (struct.new_default $type24)
       )
       (struct.new $type23
        (struct.new $environment36
         (local.get $3)
         (local.get $2)
        )
       )
      )
      (struct.set $type24 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type24 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (call $function36
       (struct.get $type23 0
        (struct.get $type24 1
         (local.get $2)
        )
       )
       (i64.const 0)
      )
     )
     (else
      (i32.const 0)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type11)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global67
   (struct.new_default $type13)
  )
  (global.set $ready67
   (i32.const 1)
  )
  (global.set $global69
   (struct.new_default $type14)
  )
  (global.set $ready69
   (i32.const 1)
  )
  (global.set $global75
   (struct.new_default $type15)
  )
  (global.set $ready75
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type16)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global78
   (struct.new_default $type17)
  )
  (global.set $ready78
   (i32.const 1)
  )
  (global.set $global119
   (struct.new_default $type18)
  )
  (global.set $ready119
   (i32.const 1)
  )
  (global.set $global109
   (call $foreign8
    (i32.const 0)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global110
   (call $foreign7
    (i32.const 1)
   )
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type13)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

