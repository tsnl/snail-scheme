(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-fft-20261013/build/strict-fft-probe-a/fft/program.scm" "/tmp/snail-strict-fft-20261013/build/strict-fft-probe-a/fft/program.so"))
