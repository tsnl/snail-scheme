# Neutral FFT behavior brief

Review scope: the FFT additions to benchmarks/strict-suite/measure.py,
host.mjs and fft-math.rs. Explain expected behavior and pseudocode from this
brief before reading those files, diffs or implementation artifacts.

The harness prepares and later measures the pinned upstream FFT workload:
100 repetitions of a fresh 65,536-element F64 vector filled with zero,
allocated inside each timed iteration. Keep the full canonical kernel text,
algorithm, loops, original inputs and original result predicate. Chez must
run the same kernel and original host harness. The strict program needs
ordinary inexact and sine operations supplied outside the kernel.

The mathematical provider must execute sine inside native Wasm and use an
F64-to-F64 scalar boundary. Scheme managed vectors remain owned by their
consumer module and engine. Loading, compilation, instantiation and ordinary
program initialization precede the benchmark timer; repeated allocations,
opacity calls, FFT work, native sine calls and final result checks are timed.
Runtime inputs must prevent compiler specialization to the known zero fill.

Preparation must validate raw and optimized Wasm and Chez at the original
65,536 size with counts 1 and 2, under default stack settings. A separate
nonzero complex-vector check and impulse check must compare every real and
imaginary output component to an independently computed positive-phase DFT,
using 1e-12 times max(1, abs(expected)) tolerance. Wrong, shortened and extended
expected vectors must be rejected by both implementations. These bounded
probes supplement the weak original zero-input first-element predicate.

Preserve the earlier failed default-stack preparation, its sources and binary
hashes. A tested parent compiler fix enables the same source to run without
stack flags. Freeze compiler, host, drivers, sources, input, provider binary,
Rust compiler/linker/libraries, source-preservation proofs and all validation
records. Preserve existing benchmark modes and scheduling. Inspect the exact
optimized Wasm for retained allocation, swaps, butterfly loads/stores, stage
recurrence and sine calls; distinguish static retention from dynamic execution.

No performance runs are authorized yet. Later timing requires independent
review and a coordinated quiet window, with CPU 5, default V8, fresh processes,
one complete discarded pair and three retained alternating pairs at the full
original count. Every observation or failure must be saved; do not replace
inconvenient samples. Make the changed code simple and educational to read.
