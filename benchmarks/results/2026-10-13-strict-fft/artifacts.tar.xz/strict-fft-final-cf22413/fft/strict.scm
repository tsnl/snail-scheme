(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define-extern native-vector-length "benchmark" "vector_length" (-> I32 I64))
(define-extern native-vector-f64 "benchmark" "vector_f64" (-> I32 I64 F64))
(define (input-vector index)
  (let ((n (native-vector-length index)))
    (let ((result (make-vector n 0.0)))
      (let loop ((i 0))
        (when (< i n)
          (vector-set! result i (native-vector-f64 index i))
          (loop (+ i 1))))
      result)))
(define (inexact value) (i64->f64 value))
(define-extern sin "math" "snail_sin" (-> F64 F64))
(define-extern native-expected-length "benchmark" "expected_length" (-> I64))
(define-extern native-expected-f64 "benchmark" "expected_f64" (-> I64 F64))
(define-extern native-tolerance "benchmark" "tolerance" (-> F64))
(: close-f64? (-> F64 F64 Bool))
(define (close-f64? actual expected)
  (let ((difference (- actual expected))
        (scale (if (< expected 0.0) (- 0.0 expected) expected)))
    (let ((error (if (< difference 0.0) (- 0.0 difference) difference)))
      (<= error (* (native-tolerance) (if (< scale 1.0) 1.0 scale))))))
(: fft-probe (-> I64 I64))
(define (fft-probe count)
  (let ((data (input-vector (ann 2 I32))))
    (four1 data)
    (if (and (= (vector-length data) (native-expected-length))
             (let loop ((i 0))
               (or (= i (vector-length data))
                   (and (close-f64? (vector-ref data i) (native-expected-f64 i))
                        (loop (+ i 1))))))
        1 0)))
(define (hide count x) (if (barrier) x (unreachable)))
;;; FFT - Fast Fourier Transform, translated from "Numerical Recipes in C"

(define (four1 data)
  (let ((n (vector-length data))
        (pi*2 6.28318530717959)) ; to compute the inverse, negate this value

    ;; bit-reversal section

    (let loop1 ((i 0) (j 0))
      (when (< i n)
        (when (< i j)
          (let ((temp (vector-ref data i)))
            (vector-set! data i (vector-ref data j))
            (vector-set! data j temp))
          (let ((temp (vector-ref data (+ i 1))))
            (vector-set! data (+ i 1) (vector-ref data (+ j 1)))
            (vector-set! data (+ j 1) temp)))
        (let loop2 ((m (quotient n 2)) (j j))
          (if (and (>= m 2) (>= j m))
            (loop2 (quotient m 2) (- j m))
            (loop1 (+ i 2) (+ j m))))))

    ;; Danielson-Lanczos section

    (let loop3 ((mmax 2))
      (when (< mmax n)
        (let* ((theta
                (/ pi*2 (inexact mmax)))
               (wpr
                (let ((x (sin (* 0.5 theta))))
                  (* -2.0 (* x x))))
               (wpi
                (sin theta)))
          (let loop4 ((wr 1.0) (wi 0.0) (m 0))
            (when (< m mmax)
              (let loop5 ((i m))
                (if (< i n)
                  (let* ((j
                          (+ i mmax))
                         (tempr
                          (-
                            (* wr (vector-ref data j))
                            (* wi (vector-ref data (+ j 1)))))
                         (tempi
                          (+
                            (* wr (vector-ref data (+ j 1)))
                            (* wi (vector-ref data j)))))
                    (vector-set! data j
                      (- (vector-ref data i) tempr))
                    (vector-set! data (+ j 1)
                      (- (vector-ref data (+ i 1)) tempi))
                    (vector-set! data i
                      (+ (vector-ref data i) tempr))
                    (vector-set! data (+ i 1)
                      (+ (vector-ref data (+ i 1)) tempi))
                    (loop5 (+ j mmax)));***))
              (loop4 (+ (- (* wr wpr) (* wi wpi)) wr)
                     (+ (+ (* wi wpr) (* wr wpi)) wi)
                     (+ m 2))))
          ));******
          (loop3 (* mmax 2)))))))

(define data
  (make-vector 1024 0.0))

(define (run data)
  (four1 data)
  (vector-ref data 0))

(define input0 (native-input-i64 (ann 0 I32)))
(define input1 (native-input-f64 (ann 1 I32)))
(: bench (-> I64 F64))
(define (bench count) (let loop ((i 0) (result 0.0))
    (if (< i count) (loop (+ i 1) (run (hide count (make-vector input0 input1)))) result)))
(unit)
