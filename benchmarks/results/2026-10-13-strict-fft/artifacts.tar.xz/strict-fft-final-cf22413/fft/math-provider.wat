(module $math-provider.wasm
 (type $0 (func (param f64) (result f64)))
 (type $1 (func))
 (type $2 (func (param f64 f64 i32) (result f64)))
 (type $3 (func (param f64 i32) (result f64)))
 (type $4 (func (param i32 i32 i32 i32 i32) (result i32)))
 (type $5 (func (param f64 i32) (result i32)))
 (type $6 (func (param f64 f64) (result f64)))
 (global $__stack_pointer (mut i32) (i32.const 1048576))
 (memory $0 17)
 (data $.rodata (i32.const 1048576) "\03\00\00\00\04\00\00\00\04\00\00\00\06\00\00\00\83\f9\a2\00DNn\00\fc)\15\00\d1W\'\00\dd4\f5\00b\db\c0\00<\99\95\00A\90C\00cQ\fe\00\bb\de\ab\00\b7a\c5\00:n$\00\d2MB\00I\06\e0\00\t\ea.\00\1c\92\d1\00\eb\1d\fe\00)\b1\1c\00\e8>\a7\00\f55\82\00D\bb.\00\9c\e9\84\00\b4&p\00A~_\00\d6\919\00S\839\00\9c\f49\00\8b_\84\00(\f9\bd\00\f8\1f;\00\de\ff\97\00\0f\98\05\00\11/\ef\00\nZ\8b\00m\1fm\00\cf~6\00\t\cb\'\00FO\b7\00\9ef?\00-\ea_\00\ba\'u\00\e5\eb\c7\00={\f1\00\f79\07\00\92R\8a\00\fbk\ea\00\1f\b1_\00\08]\8d\000\03V\00{\fcF\00\f0\abk\00 \bc\cf\006\f4\9a\00\e3\a9\1d\00^a\91\00\08\1b\e6\00\85\99e\00\a0\14_\00\8d@h\00\80\d8\ff\00\'sM\00\06\061\00\caV\15\00\c9\a8s\00{\e2`\00k\8c\c0\00\19\c4G\00\cdg\c3\00\t\e8\dc\00Y\83*\00\8bv\c4\00\a6\1c\96\00D\af\dd\00\19W\d1\00\a5>\05\00\05\07\ff\003~?\00\c22\e8\00\98O\de\00\bb}2\00&=\c3\00\1ek\ef\00\9f\f8^\005\1f:\00\7f\f2\ca\00\f1\87\1d\00|\90!\00j$|\00\d5n\fa\000-w\00\15;C\00\b5\14\c6\00\c3\19\9d\00\ad\c4\c2\00,MA\00\0c\00]\00\86}F\00\e3q-\00\9b\c6\9a\003b\00\00\b4\d2|\00\b4\a7\97\007U\d5\00\d7>\f6\00\a3\10\18\00Mv\fc\00d\9d*\00p\d7\ab\00c|\f8\00z\b0W\00\17\15\e7\00\c0IV\00;\d6\d9\00\a7\848\00$#\cb\00\d6\8aw\00ZT#\00\00\1f\b9\00\f1\n\1b\00\19\ce\df\00\9f1\ff\00f\1ej\00\99Wa\00\ac\fbG\00~\7f\d8\00\"e\b7\002\e8\89\00\e6\bf`\00\ef\c4\cd\00l6\t\00]?\d4\00\16\de\d7\00X;\de\00\de\9b\92\00\d2\"(\00(\86\e8\00\e2XM\00\c6\ca2\00\08\e3\16\00\e0}\cb\00\17\c0P\00\f3\1d\a7\00\18\e0[\00.\134\00\83\12b\00\83H\01\00\f5\8e[\00\ad\b0\7f\00\1e\e9\f2\00HJC\00\10g\d3\00\aa\dd\d8\00\ae_B\00ja\ce\00\n(\a4\00\d3\99\b4\00\06\a6\f2\00\\w\7f\00\a3\c2\83\00a<\88\00\8asx\00\af\8cZ\00o\d7\bd\00-\a6c\00\f4\bf\cb\00\8d\81\ef\00&\c1g\00U\caE\00\ca\d96\00(\a8\d2\00\c2a\8d\00\12\c9w\00\04&\14\00\12F\9b\00\c4Y\c4\00\c8\c5D\00M\b2\91\00\00\17\f3\00\d4C\ad\00)I\e5\00\fd\d5\10\00\00\be\fc\00\1e\94\cc\00p\ce\ee\00\13>\f5\00\ec\f1\80\00\b3\e7\c3\00\c7\f8(\00\93\05\94\00\c1q>\00.\t\b3\00\0bE\f3\00\88\12\9c\00\ab {\00.\b5\9f\00G\92\c2\00{2/\00\0cUm\00r\a7\90\00k\e7\1f\001\cb\96\00y\16J\00Ay\e2\00\f4\df\89\00\e8\94\97\00\e2\e6\84\00\991\97\00\88\edk\00__6\00\bb\fd\0e\00H\9a\b4\00g\a4l\00qrB\00\8d]2\00\9f\15\b8\00\bc\e5\t\00\8d1%\00\f7t9\000\05\1c\00\r\0c\01\00K\08h\00,\eeX\00G\aa\90\00t\e7\02\00\bd\d6$\00\f7}\a6\00nHr\00\9f\16\ef\00\8e\94\a6\00\b4\91\f6\00\d1SQ\00\cf\n\f2\00 \983\00\f5K~\00\b2ch\00\dd>_\00@]\03\00\85\89\7f\00UR)\007d\c0\00m\d8\10\002H2\00[Lu\00Nq\d4\00ETn\00\0b\t\c1\00*\f5i\00\14f\d5\00\'\07\9d\00]\04P\00\b4;\db\00\eav\c5\00\87\f9\17\00Ik}\00\1d\'\ba\00\96i)\00\c6\cc\ac\00\ad\14T\00\90\e2j\00\88\d9\89\00,rP\00\04\a4\be\00w\07\94\00\f30p\00\00\fc\'\00\eaq\a8\00f\c2I\00d\e0=\00\97\dd\83\00\a3?\97\00C\94\fd\00\r\86\8c\001A\de\00\929\9d\00\ddp\8c\00\17\b7\e7\00\08\df;\00\157+\00\\\80\a0\00Z\80\93\00\10\11\92\00\0f\e8\d8\00l\80\af\00\db\ffK\008\90\0f\00Y\18v\00b\a5\15\00a\cb\bb\00\c7\89\b9\00\10@\bd\00\d2\f2\04\00Iu\'\00\eb\b6\f6\00\db\"\bb\00\n\14\aa\00\89&/\00d\83v\00\t;3\00\0e\94\1a\00Q:\aa\00\1d\a3\c2\00\af\ed\ae\00\\&\12\00m\c2M\00-z\9c\00\c0V\97\00\03?\83\00\t\f0\f6\00+@\8c\00m1\99\009\b4\07\00\0c \15\00\d8\c3[\00\f5\92\c4\00\c6\adK\00N\ca\a5\00\a77\cd\00\e6\a96\00\ab\92\94\00\ddBh\00\19c\de\00v\8c\ef\00h\8bR\00\fc\db7\00\ae\a1\ab\00\df\151\00\00\ae\a1\00\0c\fb\da\00dMf\00\ed\05\b7\00)e0\00WV\bf\00G\ff:\00j\f9\b9\00u\be\f3\00(\93\df\00\ab\800\00f\8c\f6\00\04\cb\15\00\fa\"\06\00\d9\e4\1d\00=\b3\a4\00W\1b\8f\006\cd\t\00NB\e9\00\13\be\a4\003#\b5\00\f0\aa\1a\00Oe\a8\00\d2\c1\a5\00\0b?\0f\00[x\cd\00#\f9v\00{\8b\04\00\89\17r\00\c6\a6S\00on\e2\00\ef\eb\00\00\9bJX\00\c4\da\b7\00\aaf\ba\00v\cf\cf\00\d1\02\1d\00\b1\f1-\00\8c\99\c1\00\c3\adw\00\86H\da\00\f7]\a0\00\c6\80\f4\00\ac\f0/\00\dd\ec\9a\00?\\\bc\00\d0\dem\00\90\c7\1f\00*\db\b6\00\a3%:\00\00\af\9a\00\adS\93\00\b6W\04\00)-\b4\00K\80~\00\da\07\a7\00v\aa\0e\00{Y\a1\00\16\12*\00\dc\b7-\00\fa\e5\fd\00\89\db\fe\00\89\be\fd\00\e4vl\00\06\a9\fc\00>\80p\00\85n\15\00\fd\87\ff\00(>\07\00ag3\00*\18\86\00M\bd\ea\00\b3\e7\af\00\8fmn\00\95g9\001\bf[\00\84\d7H\000\df\16\00\c7-C\00%a5\00\c9p\ce\000\cb\b8\00\bfl\fd\00\a4\00\a2\00\05l\e4\00Z\dd\a0\00!oG\00b\12\d2\00\b9\\\84\00paI\00kV\e0\00\99R\01\00PU7\00\1e\d5\b7\003\f1\c4\00\13n_\00]0\e4\00\85.\a9\00\1d\b2\c3\00\a126\00\08\b7\a4\00\ea\b1\d4\00\16\f7!\00\8fi\e4\00\'\ffw\00\0c\03\80\00\8d@-\00O\cd\a0\00 \a5\99\00\b3\a2\d3\00/]\n\00\b4\f9B\00\11\da\cb\00}\be\d0\00\9b\db\c1\00\ab\17\bd\00\ca\a2\81\00\08j\\\00.U\17\00\'\00U\00\7f\14\f0\00\e1\07\86\00\14\0bd\00\96A\8d\00\87\be\de\00\da\fd*\00k%\b6\00{\894\00\05\f3\fe\00\b9\bf\9e\00hjO\00J*\a8\00O\c4Z\00-\f8\bc\00\d7Z\98\00\f4\c7\95\00\rM\8d\00 :\a6\00\a4W_\00\14?\b1\00\808\95\00\cc \01\00q\dd\86\00\c9\de\b6\00\bf`\f5\00Me\11\00\01\07k\00\8c\b0\ac\00\b2\c0\d0\00QUH\00\1e\fb\0e\00\95r\c3\00\a3\06;\00\c0@5\00\06\dc{\00\e0E\cc\00N)\fa\00\d6\ca\c8\00\e8\f3A\00|d\de\00\9bd\d8\00\d9\be1\00\a4\97\c3\00wX\d4\00i\e3\c5\00\f0\da\13\00\ba:<\00F\18F\00Uu_\00\d2\bd\f5\00n\92\c6\00\ac.]\00\0eD\ed\00\1c>B\00a\c4\87\00)\fd\e9\00\e7\d6\f3\00\"|\ca\00o\915\00\08\e0\c5\00\ff\d7\8d\00nj\e2\00\b0\fd\c6\00\93\08\c1\00|]t\00k\ad\b2\00\cdn\9d\00>r{\00\c6\11j\00\f7\cf\a9\00)s\df\00\b5\c9\ba\00\b7\00Q\00\e2\b2\r\00t\ba$\00\e5}`\00t\d8\8a\00\r\15,\00\81\18\0c\00~f\94\00\01)\16\00\9fzv\00\fd\fd\be\00VE\ef\00\d9~6\00\ec\d9\13\00\8b\ba\b9\00\c4\97\fc\001\a8\'\00\f1n\c3\00\94\c56\00\d8\a8V\00\b4\a8\b5\00\cf\cc\0e\00\12\89-\00oW4\00,V\89\00\99\ce\e3\00\d6 \b9\00k^\aa\00>*\9c\00\11_\cc\00\fd\0bJ\00\e1\f4\fb\00\8e;m\00\e2\86,\00\e9\d4\84\00\fc\b4\a9\00\ef\ee\d1\00.5\c9\00/9a\008!D\00\1b\d9\c8\00\81\fc\n\00\fbJj\00/\1c\d8\00S\b4\84\00N\99\8c\00T\"\cc\00*U\dc\00\c0\c6\d6\00\0b\19\96\00\1ap\b8\00i\95d\00&Z`\00?R\ee\00\7f\11\0f\00\f4\b5\11\00\fc\cb\f5\004\bc-\004\bc\ee\00\e8]\cc\00\dd^`\00g\8e\9b\00\923\ef\00\c9\17\b8\00aX\9b\00\e1W\bc\00Q\83\c6\00\d8>\10\00\ddqH\00-\1c\dd\00\af\18\a1\00!,F\00Y\f3\d7\00\d9z\98\00\9eT\c0\00O\86\fa\00V\06\fc\00\e5y\ae\00\89\"6\008\ad\"\00g\93\dc\00U\e8\aa\00\82&8\00\ca\e7\9b\00Q\r\a4\00\993\b1\00\a9\d7\0e\00i\05H\00e\b2\f0\00\7f\88\a7\00\88L\97\00\f9\d16\00!\92\b3\00{\82J\00\98\cf!\00@\9f\dc\00\dcGU\00\e1t:\00g\ebB\00\fe\9d\df\00^\d4_\00{g\a4\00\ba\acz\00U\f6\a2\00+\88#\00A\baU\00Yn\08\00!*\86\009G\83\00\89\e3\e6\00\e5\9e\d4\00I\fb@\00\ffV\e9\00\1c\0f\ca\00\c5Y\8a\00\94\fa+\00\d3\c1\c5\00\0f\c5\cf\00\dbZ\ae\00G\c5\86\00\85Cb\00!\86;\00,y\94\00\10a\87\00*L{\00\80,\1a\00C\bf\12\00\88&\90\00x<\89\00\a8\c4\e4\00\e5\db{\00\c4:\c2\00&\f4\ea\00\f7g\8a\00\r\92\bf\00e\a3+\00=\93\b1\00\bd|\0b\00\a4Q\dc\00\'\ddc\00i\e1\dd\00\9a\94\19\00\a8)\95\00h\ce(\00\t\ed\b4\00D\9f \00N\98\ca\00p\82c\00~|#\00\0f\b92\00\a7\f5\8e\00\14V\e7\00!\f1\08\00\b5\9d*\00o~M\00\a5\19Q\00\b5\f9\ab\00\82\df\d6\00\96\dda\00\166\02\00\c4:\9f\00\83\a2\a1\00r\edm\009\8dz\00\82\b8\a9\00k2\\\00F\'[\00\004\ed\00\d2\00w\00\fc\f4U\00\01YM\00\e0q\80\00\00\00\00\00\00\00\00\00\00\00\00@\fb!\f9?\00\00\00\00-Dt>\00\00\00\80\98F\f8<\00\00\00`Q\ccx;\00\00\00\80\83\1b\f09\00\00\00@ %z8\00\00\00\80\"\82\e36\00\00\00\00\1d\f3i5")
 (table $0 1 1 funcref)
 (export "memory" (memory $0))
 (export "snail_sin" (func $snail_sin.command_export))
 (func $snail_sin (param $0 f64) (result f64)
  (call $sin
   (local.get $0)
  )
 )
 (func $__sin (param $0 f64) (param $1 f64) (param $2 i32) (result f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local.set $4
   (f64.add
    (f64.mul
     (f64.mul
      (local.tee $3
       (f64.mul
        (local.get $0)
        (local.get $0)
       )
      )
      (f64.mul
       (local.get $3)
       (local.get $3)
      )
     )
     (f64.add
      (f64.mul
       (local.get $3)
       (f64.const 1.58969099521155e-10)
      )
      (f64.const -2.5050760253406863e-08)
     )
    )
    (f64.add
     (f64.mul
      (local.get $3)
      (f64.add
       (f64.mul
        (local.get $3)
        (f64.const 2.7557313707070068e-06)
       )
       (f64.const -1.984126982985795e-04)
      )
     )
     (f64.const 0.00833333333332249)
    )
   )
  )
  (local.set $5
   (f64.mul
    (local.get $0)
    (local.get $3)
   )
  )
  (block $block
   (br_if $block
    (local.get $2)
   )
   (return
    (f64.add
     (f64.mul
      (local.get $5)
      (f64.add
       (f64.mul
        (local.get $3)
        (local.get $4)
       )
       (f64.const -0.16666666666666632)
      )
     )
     (local.get $0)
    )
   )
  )
  (f64.sub
   (local.get $0)
   (f64.add
    (f64.sub
     (f64.mul
      (local.get $3)
      (f64.sub
       (f64.mul
        (local.get $1)
        (f64.const 0.5)
       )
       (f64.mul
        (local.get $5)
        (local.get $4)
       )
      )
     )
     (local.get $1)
    )
    (f64.mul
     (local.get $5)
     (f64.const 0.16666666666666632)
    )
   )
  )
 )
 (func $scalbn (param $0 f64) (param $1 i32) (result f64)
  (block $block2
   (block $block
    (br_if $block
     (i32.lt_s
      (local.get $1)
      (i32.const 1024)
     )
    )
    (local.set $0
     (f64.mul
      (local.get $0)
      (f64.const 8988465674311579538646525e283)
     )
    )
    (block $block1
     (br_if $block1
      (i32.ge_u
       (local.get $1)
       (i32.const 2047)
      )
     )
     (local.set $1
      (i32.add
       (local.get $1)
       (i32.const -1023)
      )
     )
     (br $block2)
    )
    (local.set $0
     (f64.mul
      (local.get $0)
      (f64.const 8988465674311579538646525e283)
     )
    )
    (local.set $1
     (i32.add
      (select
       (local.get $1)
       (i32.const 3069)
       (i32.lt_u
        (local.get $1)
        (i32.const 3069)
       )
      )
      (i32.const -2046)
     )
    )
    (br $block2)
   )
   (br_if $block2
    (i32.gt_s
     (local.get $1)
     (i32.const -1023)
    )
   )
   (local.set $0
    (f64.mul
     (local.get $0)
     (f64.const 2.004168360008973e-292)
    )
   )
   (block $block3
    (br_if $block3
     (i32.le_u
      (local.get $1)
      (i32.const -1992)
     )
    )
    (local.set $1
     (i32.add
      (local.get $1)
      (i32.const 969)
     )
    )
    (br $block2)
   )
   (local.set $0
    (f64.mul
     (local.get $0)
     (f64.const 2.004168360008973e-292)
    )
   )
   (local.set $1
    (i32.add
     (select
      (local.get $1)
      (i32.const -2960)
      (i32.gt_u
       (local.get $1)
       (i32.const -2960)
      )
     )
     (i32.const 1938)
    )
   )
  )
  (f64.mul
   (local.get $0)
   (f64.reinterpret_i64
    (i64.shl
     (i64.extend_i32_u
      (i32.add
       (local.get $1)
       (i32.const 1023)
      )
     )
     (i64.const 52)
    )
   )
  )
 )
 (func $__rem_pio2_large (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (result i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 f64)
  (local $17 f64)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i32)
  (local $23 i32)
  (local $24 i32)
  (local $25 i32)
  (local $26 i32)
  (local $27 i32)
  (local $28 i32)
  (local $29 i32)
  (local $30 i32)
  (local $31 i32)
  (local $32 i32)
  (local $33 f64)
  (local $34 f64)
  (local $35 f64)
  (local $36 f64)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 560)
    )
   )
  )
  (local.set $6
   (i32.const 0)
  )
  (local.set $9
   (i32.add
    (i32.mul
     (local.tee $8
      (select
       (local.tee $7
        (i32.div_s
         (i32.add
          (local.get $2)
          (i32.const -3)
         )
         (i32.const 24)
        )
       )
       (i32.const 0)
       (i32.gt_s
        (local.get $7)
        (i32.const 0)
       )
      )
     )
     (i32.const -24)
    )
    (local.get $2)
   )
  )
  (block $block
   (br_if $block
    (i32.lt_s
     (local.tee $2
      (i32.add
       (local.tee $10
        (i32.load
         (i32.add
          (i32.shl
           (local.get $4)
           (i32.const 2)
          )
          (i32.const 1048576)
         )
        )
       )
       (local.tee $11
        (i32.add
         (local.get $3)
         (i32.const -1)
        )
       )
      )
     )
     (i32.const 0)
    )
   )
   (local.set $12
    (i32.sub
     (local.get $8)
     (local.get $11)
    )
   )
   (local.set $14
    (i32.and
     (local.tee $13
      (i32.add
       (local.get $10)
       (local.get $3)
      )
     )
     (i32.const 1)
    )
   )
   (block $block1
    (br_if $block1
     (i32.eqz
      (local.get $2)
     )
    )
    (local.set $7
     (i32.add
      (i32.sub
       (i32.shl
        (local.get $8)
        (i32.const 2)
       )
       (i32.shl
        (local.get $3)
        (i32.const 2)
       )
      )
      (i32.const 1048600)
     )
    )
    (local.set $15
     (i32.and
      (local.get $13)
      (i32.const -2)
     )
    )
    (local.set $2
     (i32.add
      (local.get $5)
      (i32.const 320)
     )
    )
    (local.set $6
     (i32.const 0)
    )
    (loop $label
     (local.set $16
      (f64.const 0)
     )
     (local.set $17
      (f64.const 0)
     )
     (block $block2
      (br_if $block2
       (i32.lt_s
        (local.tee $13
         (i32.add
          (local.get $12)
          (local.get $6)
         )
        )
        (i32.const 0)
       )
      )
      (local.set $17
       (f64.convert_i32_s
        (i32.load
         (i32.add
          (local.get $7)
          (i32.const -4)
         )
        )
       )
      )
     )
     (f64.store
      (local.get $2)
      (local.get $17)
     )
     (block $block3
      (br_if $block3
       (i32.lt_s
        (local.get $13)
        (i32.const -1)
       )
      )
      (local.set $16
       (f64.convert_i32_s
        (i32.load
         (local.get $7)
        )
       )
      )
     )
     (f64.store
      (i32.add
       (local.get $2)
       (i32.const 8)
      )
      (local.get $16)
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 16)
      )
     )
     (local.set $7
      (i32.add
       (local.get $7)
       (i32.const 8)
      )
     )
     (br_if $label
      (i32.ne
       (local.get $15)
       (local.tee $6
        (i32.add
         (local.get $6)
         (i32.const 2)
        )
       )
      )
     )
    )
    (local.set $12
     (i32.add
      (local.get $12)
      (local.get $6)
     )
    )
   )
   (br_if $block
    (i32.eqz
     (local.get $14)
    )
   )
   (block $block5
    (block $block4
     (br_if $block4
      (i32.ge_s
       (local.get $12)
       (i32.const 0)
      )
     )
     (local.set $17
      (f64.const 0)
     )
     (br $block5)
    )
    (local.set $17
     (f64.convert_i32_s
      (i32.load offset=1048592
       (i32.shl
        (local.get $12)
        (i32.const 2)
       )
      )
     )
    )
   )
   (f64.store
    (i32.add
     (i32.add
      (local.get $5)
      (i32.const 320)
     )
     (i32.shl
      (local.get $6)
      (i32.const 3)
     )
    )
    (local.get $17)
   )
  )
  (local.set $18
   (i32.add
    (local.get $9)
    (i32.const -24)
   )
  )
  (local.set $2
   (i32.const 0)
  )
  (local.set $14
   (select
    (local.get $10)
    (i32.const 0)
    (i32.gt_s
     (local.get $10)
     (i32.const 0)
    )
   )
  )
  (local.set $13
   (i32.and
    (local.get $3)
    (i32.const 2147483646)
   )
  )
  (local.set $19
   (i32.and
    (local.get $3)
    (i32.const 1)
   )
  )
  (local.set $15
   (i32.add
    (i32.add
     (i32.shl
      (local.get $3)
      (i32.const 3)
     )
     (i32.add
      (local.get $5)
      (i32.const 320)
     )
    )
    (i32.const -16)
   )
  )
  (loop $label2
   (local.set $12
    (local.get $2)
   )
   (block $block7
    (block $block6
     (br_if $block6
      (i32.ge_s
       (local.get $3)
       (i32.const 1)
      )
     )
     (local.set $17
      (f64.const 0)
     )
     (br $block7)
    )
    (local.set $7
     (i32.const 0)
    )
    (local.set $17
     (f64.const 0)
    )
    (block $block8
     (br_if $block8
      (i32.eqz
       (local.get $11)
      )
     )
     (local.set $2
      (local.get $15)
     )
     (local.set $6
      (local.get $0)
     )
     (loop $label1
      (local.set $17
       (f64.add
        (f64.mul
         (f64.load
          (i32.add
           (local.get $6)
           (i32.const 8)
          )
         )
         (f64.load
          (local.get $2)
         )
        )
        (f64.add
         (f64.mul
          (f64.load
           (local.get $6)
          )
          (f64.load
           (i32.add
            (local.get $2)
            (i32.const 8)
           )
          )
         )
         (local.get $17)
        )
       )
      )
      (local.set $2
       (i32.add
        (local.get $2)
        (i32.const -16)
       )
      )
      (local.set $6
       (i32.add
        (local.get $6)
        (i32.const 16)
       )
      )
      (br_if $label1
       (i32.ne
        (local.get $13)
        (local.tee $7
         (i32.add
          (local.get $7)
          (i32.const 2)
         )
        )
       )
      )
     )
    )
    (br_if $block7
     (i32.eqz
      (local.get $19)
     )
    )
    (local.set $17
     (f64.add
      (f64.mul
       (f64.load
        (i32.add
         (local.get $0)
         (i32.shl
          (local.get $7)
          (i32.const 3)
         )
        )
       )
       (f64.load
        (i32.add
         (i32.add
          (local.get $5)
          (i32.const 320)
         )
         (i32.shl
          (i32.sub
           (i32.add
            (local.get $12)
            (local.get $11)
           )
           (local.get $7)
          )
          (i32.const 3)
         )
        )
       )
      )
      (local.get $17)
     )
    )
   )
   (f64.store
    (i32.add
     (local.get $5)
     (i32.shl
      (local.get $12)
      (i32.const 3)
     )
    )
    (local.get $17)
   )
   (local.set $15
    (i32.add
     (local.get $15)
     (i32.const 8)
    )
   )
   (local.set $2
    (i32.add
     (local.get $12)
     (i32.const 1)
    )
   )
   (br_if $label2
    (i32.ne
     (local.get $12)
     (local.get $14)
    )
   )
  )
  (local.set $13
   (i32.and
    (local.get $3)
    (i32.const 2147483646)
   )
  )
  (local.set $20
   (i32.and
    (local.get $3)
    (i32.const 1)
   )
  )
  (local.set $21
   (i32.sub
    (i32.const 47)
    (local.get $9)
   )
  )
  (local.set $22
   (i32.sub
    (i32.const 48)
    (local.get $9)
   )
  )
  (local.set $24
   (i32.add
    (local.tee $23
     (i32.add
      (i32.add
       (local.get $5)
       (i32.const 480)
      )
      (i32.const -4)
     )
    )
    (i32.shl
     (local.get $10)
     (i32.const 2)
    )
   )
  )
  (local.set $25
   (i32.add
    (i32.add
     (local.get $5)
     (i32.const 320)
    )
    (i32.const -8)
   )
  )
  (local.set $26
   (i32.add
    (i32.add
     (local.get $5)
     (i32.const 480)
    )
    (i32.const -16)
   )
  )
  (local.set $27
   (i32.add
    (local.get $5)
    (i32.const -16)
   )
  )
  (local.set $28
   (i32.add
    (local.get $9)
    (i32.const -25)
   )
  )
  (local.set $12
   (local.get $10)
  )
  (block $block37
   (loop $label11
    (local.set $17
     (f64.load
      (i32.add
       (local.get $5)
       (local.tee $2
        (i32.shl
         (local.get $12)
         (i32.const 3)
        )
       )
      )
     )
    )
    (block $block9
     (br_if $block9
      (i32.lt_s
       (local.get $12)
       (i32.const 1)
      )
     )
     (local.set $7
      (i32.const 0)
     )
     (block $block11
      (block $block10
       (br_if $block10
        (i32.ne
         (local.get $12)
         (i32.const 1)
        )
       )
       (local.set $2
        (local.get $12)
       )
       (br $block11)
      )
      (local.set $15
       (i32.and
        (local.get $12)
        (i32.const 2147483646)
       )
      )
      (local.set $2
       (i32.add
        (local.get $27)
        (local.get $2)
       )
      )
      (local.set $7
       (i32.const 0)
      )
      (local.set $6
       (i32.add
        (local.get $5)
        (i32.const 480)
       )
      )
      (loop $label3
       (i32.store
        (local.get $6)
        (i32.trunc_sat_f64_s
         (f64.add
          (f64.mul
           (local.tee $16
            (f64.convert_i32_s
             (i32.trunc_sat_f64_s
              (f64.mul
               (local.get $17)
               (f64.const 5.9604644775390625e-08)
              )
             )
            )
           )
           (f64.const -16777216)
          )
          (local.get $17)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $6)
         (i32.const 4)
        )
        (i32.trunc_sat_f64_s
         (f64.add
          (f64.mul
           (local.tee $16
            (f64.convert_i32_s
             (i32.trunc_sat_f64_s
              (f64.mul
               (local.tee $17
                (f64.add
                 (f64.load
                  (i32.add
                   (local.get $2)
                   (i32.const 8)
                  )
                 )
                 (local.get $16)
                )
               )
               (f64.const 5.9604644775390625e-08)
              )
             )
            )
           )
           (f64.const -16777216)
          )
          (local.get $17)
         )
        )
       )
       (local.set $17
        (f64.add
         (f64.load
          (local.get $2)
         )
         (local.get $16)
        )
       )
       (local.set $6
        (i32.add
         (local.get $6)
         (i32.const 8)
        )
       )
       (local.set $2
        (i32.add
         (local.get $2)
         (i32.const -16)
        )
       )
       (br_if $label3
        (i32.ne
         (local.get $15)
         (local.tee $7
          (i32.add
           (local.get $7)
           (i32.const 2)
          )
         )
        )
       )
      )
      (local.set $2
       (i32.sub
        (local.get $12)
        (local.get $7)
       )
      )
     )
     (br_if $block9
      (i32.eqz
       (i32.and
        (local.get $12)
        (i32.const 1)
       )
      )
     )
     (i32.store
      (i32.add
       (i32.add
        (local.get $5)
        (i32.const 480)
       )
       (i32.shl
        (local.get $7)
        (i32.const 2)
       )
      )
      (i32.trunc_sat_f64_s
       (f64.add
        (f64.mul
         (local.tee $16
          (f64.convert_i32_s
           (i32.trunc_sat_f64_s
            (f64.mul
             (local.get $17)
             (f64.const 5.9604644775390625e-08)
            )
           )
          )
         )
         (f64.const -16777216)
        )
        (local.get $17)
       )
      )
     )
     (local.set $17
      (f64.add
       (f64.load
        (i32.add
         (i32.add
          (i32.shl
           (local.get $2)
           (i32.const 3)
          )
          (local.get $5)
         )
         (i32.const -8)
        )
       )
       (local.get $16)
      )
     )
    )
    (local.set $17
     (f64.sub
      (local.tee $17
       (f64.add
        (f64.mul
         (f64.floor
          (f64.mul
           (local.tee $17
            (call $scalbn
             (local.get $17)
             (local.get $18)
            )
           )
           (f64.const 0.125)
          )
         )
         (f64.const -8)
        )
        (local.get $17)
       )
      )
      (f64.convert_i32_s
       (local.tee $29
        (i32.trunc_sat_f64_s
         (local.get $17)
        )
       )
      )
     )
    )
    (block $block15
     (block $block16
      (block $block14
       (block $block13
        (block $block12
         (br_if $block12
          (local.tee $30
           (i32.lt_s
            (local.get $18)
            (i32.const 1)
           )
          )
         )
         (i32.store
          (local.tee $2
           (i32.add
            (i32.add
             (i32.shl
              (local.get $12)
              (i32.const 2)
             )
             (i32.add
              (local.get $5)
              (i32.const 480)
             )
            )
            (i32.const -4)
           )
          )
          (local.tee $6
           (i32.sub
            (local.tee $2
             (i32.load
              (local.get $2)
             )
            )
            (i32.shl
             (local.tee $2
              (i32.shr_s
               (local.get $2)
               (local.get $22)
              )
             )
             (local.get $22)
            )
           )
          )
         )
         (local.set $31
          (i32.shr_s
           (local.get $6)
           (local.get $21)
          )
         )
         (local.set $29
          (i32.add
           (local.get $2)
           (local.get $29)
          )
         )
         (br $block13)
        )
        (br_if $block14
         (local.get $18)
        )
        (local.set $31
         (i32.shr_s
          (i32.load
           (i32.add
            (i32.add
             (i32.shl
              (local.get $12)
              (i32.const 2)
             )
             (i32.add
              (local.get $5)
              (i32.const 480)
             )
            )
            (i32.const -4)
           )
          )
          (i32.const 23)
         )
        )
       )
       (br_if $block15
        (i32.lt_s
         (local.get $31)
         (i32.const 1)
        )
       )
       (br $block16)
      )
      (local.set $31
       (i32.const 2)
      )
      (br_if $block16
       (f64.ge
        (local.get $17)
        (f64.const 0.5)
       )
      )
      (local.set $31
       (i32.const 0)
      )
      (br $block15)
     )
     (local.set $6
      (i32.const 1)
     )
     (block $block17
      (br_if $block17
       (i32.lt_s
        (local.get $12)
        (i32.const 1)
       )
      )
      (local.set $6
       (i32.const 1)
      )
      (local.set $32
       (i32.and
        (local.get $12)
        (i32.const 1)
       )
      )
      (local.set $7
       (i32.const 0)
      )
      (block $block18
       (br_if $block18
        (i32.eq
         (local.get $12)
         (i32.const 1)
        )
       )
       (local.set $19
        (i32.and
         (local.get $12)
         (i32.const 2147483646)
        )
       )
       (local.set $7
        (i32.const 0)
       )
       (local.set $2
        (i32.add
         (local.get $5)
         (i32.const 480)
        )
       )
       (local.set $15
        (i32.const 0)
       )
       (loop $label4
        (local.set $6
         (i32.load
          (local.get $2)
         )
        )
        (block $block22
         (block $block21
          (block $block20
           (block $block19
            (br_if $block19
             (i32.eqz
              (local.get $15)
             )
            )
            (local.set $15
             (i32.const 16777215)
            )
            (br $block20)
           )
           (br_if $block21
            (i32.eqz
             (local.get $6)
            )
           )
           (local.set $15
            (i32.const 16777216)
           )
          )
          (i32.store
           (local.get $2)
           (i32.sub
            (local.get $15)
            (local.get $6)
           )
          )
          (local.set $15
           (i32.const 0)
          )
          (br $block22)
         )
         (local.set $15
          (i32.const 1)
         )
        )
        (local.set $6
         (i32.load
          (local.tee $14
           (i32.add
            (local.get $2)
            (i32.const 4)
           )
          )
         )
        )
        (block $block26
         (block $block25
          (block $block24
           (block $block23
            (br_if $block23
             (local.get $15)
            )
            (local.set $15
             (i32.const 16777215)
            )
            (br $block24)
           )
           (br_if $block25
            (i32.eqz
             (local.get $6)
            )
           )
           (local.set $15
            (i32.const 16777216)
           )
          )
          (i32.store
           (local.get $14)
           (i32.sub
            (local.get $15)
            (local.get $6)
           )
          )
          (local.set $15
           (i32.const 1)
          )
          (local.set $6
           (i32.const 0)
          )
          (br $block26)
         )
         (local.set $15
          (i32.const 0)
         )
         (local.set $6
          (i32.const 1)
         )
        )
        (local.set $2
         (i32.add
          (local.get $2)
          (i32.const 8)
         )
        )
        (br_if $label4
         (i32.ne
          (local.get $19)
          (local.tee $7
           (i32.add
            (local.get $7)
            (i32.const 2)
           )
          )
         )
        )
       )
      )
      (br_if $block17
       (i32.eqz
        (local.get $32)
       )
      )
      (local.set $2
       (i32.load
        (local.tee $7
         (i32.add
          (i32.add
           (local.get $5)
           (i32.const 480)
          )
          (i32.shl
           (local.get $7)
           (i32.const 2)
          )
         )
        )
       )
      )
      (block $block29
       (block $block28
        (block $block27
         (br_if $block27
          (local.get $6)
         )
         (local.set $6
          (i32.const 16777215)
         )
         (br $block28)
        )
        (br_if $block29
         (i32.eqz
          (local.get $2)
         )
        )
        (local.set $6
         (i32.const 16777216)
        )
       )
       (i32.store
        (local.get $7)
        (i32.sub
         (local.get $6)
         (local.get $2)
        )
       )
       (local.set $6
        (i32.const 0)
       )
       (br $block17)
      )
      (local.set $6
       (i32.const 1)
      )
     )
     (block $block30
      (br_if $block30
       (local.get $30)
      )
      (local.set $2
       (i32.const 8388607)
      )
      (block $block31
       (block $block32
        (br_table $block31 $block32 $block30
         (local.get $28)
        )
       )
       (local.set $2
        (i32.const 4194303)
       )
      )
      (i32.store
       (local.tee $7
        (i32.add
         (i32.add
          (i32.shl
           (local.get $12)
           (i32.const 2)
          )
          (i32.add
           (local.get $5)
           (i32.const 480)
          )
         )
         (i32.const -4)
        )
       )
       (i32.and
        (i32.load
         (local.get $7)
        )
        (local.get $2)
       )
      )
     )
     (local.set $29
      (i32.add
       (local.get $29)
       (i32.const 1)
      )
     )
     (br_if $block15
      (i32.ne
       (local.get $31)
       (i32.const 2)
      )
     )
     (local.set $17
      (f64.sub
       (f64.const 1)
       (local.get $17)
      )
     )
     (local.set $31
      (i32.const 2)
     )
     (br_if $block15
      (i32.and
       (local.get $6)
       (i32.const 1)
      )
     )
     (local.set $17
      (f64.sub
       (local.get $17)
       (call $scalbn
        (f64.const 1)
        (local.get $18)
       )
      )
     )
    )
    (block $block33
     (br_if $block33
      (f64.ne
       (local.get $17)
       (f64.const 0)
      )
     )
     (block $block34
      (br_if $block34
       (i32.le_s
        (local.get $12)
        (local.get $10)
       )
      )
      (local.set $7
       (i32.and
        (local.tee $2
         (i32.sub
          (local.get $12)
          (local.get $10)
         )
        )
        (i32.const 3)
       )
      )
      (local.set $6
       (i32.const 0)
      )
      (local.set $15
       (local.get $12)
      )
      (block $block35
       (br_if $block35
        (i32.gt_u
         (i32.sub
          (local.get $10)
          (local.get $12)
         )
         (i32.const -4)
        )
       )
       (local.set $14
        (i32.and
         (local.get $2)
         (i32.const -4)
        )
       )
       (local.set $2
        (i32.add
         (local.get $26)
         (i32.shl
          (local.get $12)
          (i32.const 2)
         )
        )
       )
       (local.set $6
        (i32.const 0)
       )
       (local.set $15
        (local.get $12)
       )
       (loop $label5
        (local.set $6
         (i32.or
          (i32.load
           (local.get $2)
          )
          (i32.or
           (i32.load
            (i32.add
             (local.get $2)
             (i32.const 4)
            )
           )
           (i32.or
            (i32.load
             (i32.add
              (local.get $2)
              (i32.const 8)
             )
            )
            (i32.or
             (i32.load
              (i32.add
               (local.get $2)
               (i32.const 12)
              )
             )
             (local.get $6)
            )
           )
          )
         )
        )
        (local.set $2
         (i32.add
          (local.get $2)
          (i32.const -16)
         )
        )
        (local.set $15
         (i32.add
          (local.get $15)
          (i32.const -4)
         )
        )
        (br_if $label5
         (local.tee $14
          (i32.add
           (local.get $14)
           (i32.const -4)
          )
         )
        )
       )
      )
      (block $block36
       (br_if $block36
        (i32.eqz
         (local.get $7)
        )
       )
       (local.set $2
        (i32.add
         (local.get $23)
         (i32.shl
          (local.get $15)
          (i32.const 2)
         )
        )
       )
       (loop $label6
        (local.set $6
         (i32.or
          (i32.load
           (local.get $2)
          )
          (local.get $6)
         )
        )
        (local.set $2
         (i32.add
          (local.get $2)
          (i32.const -4)
         )
        )
        (br_if $label6
         (local.tee $7
          (i32.add
           (local.get $7)
           (i32.const -1)
          )
         )
        )
       )
      )
      (br_if $block34
       (i32.eqz
        (local.get $6)
       )
      )
      (local.set $2
       (i32.add
        (i32.add
         (i32.add
          (local.get $5)
          (i32.const 480)
         )
         (i32.shl
          (local.get $12)
          (i32.const 2)
         )
        )
        (i32.const -4)
       )
      )
      (loop $label7
       (local.set $12
        (i32.add
         (local.get $12)
         (i32.const -1)
        )
       )
       (local.set $18
        (i32.add
         (local.get $18)
         (i32.const -24)
        )
       )
       (local.set $6
        (i32.load
         (local.get $2)
        )
       )
       (local.set $2
        (i32.add
         (local.get $2)
         (i32.const -4)
        )
       )
       (br_if $label7
        (i32.eqz
         (local.get $6)
        )
       )
       (br $block37)
      )
     )
     (local.set $2
      (local.get $24)
     )
     (local.set $15
      (local.get $12)
     )
     (loop $label8
      (local.set $15
       (i32.add
        (local.get $15)
        (i32.const 1)
       )
      )
      (local.set $6
       (i32.load
        (local.get $2)
       )
      )
      (local.set $2
       (i32.add
        (local.get $2)
        (i32.const -4)
       )
      )
      (br_if $label8
       (i32.eqz
        (local.get $6)
       )
      )
     )
     (local.set $14
      (i32.add
       (local.get $25)
       (i32.shl
        (i32.add
         (local.get $3)
         (local.get $12)
        )
        (i32.const 3)
       )
      )
     )
     (loop $label10
      (f64.store
       (i32.add
        (i32.add
         (local.get $5)
         (i32.const 320)
        )
        (i32.shl
         (local.tee $19
          (i32.add
           (local.get $12)
           (local.get $3)
          )
         )
         (i32.const 3)
        )
       )
       (f64.convert_i32_s
        (i32.load
         (i32.add
          (i32.shl
           (i32.add
            (local.tee $12
             (i32.add
              (local.get $12)
              (i32.const 1)
             )
            )
            (local.get $8)
           )
           (i32.const 2)
          )
          (i32.const 1048592)
         )
        )
       )
      )
      (block $block39
       (block $block38
        (br_if $block38
         (i32.ge_s
          (local.get $3)
          (i32.const 1)
         )
        )
        (local.set $17
         (f64.const 0)
        )
        (br $block39)
       )
       (local.set $7
        (i32.const 0)
       )
       (local.set $17
        (f64.const 0)
       )
       (block $block40
        (br_if $block40
         (i32.eqz
          (local.get $11)
         )
        )
        (local.set $2
         (local.get $14)
        )
        (local.set $6
         (local.get $0)
        )
        (loop $label9
         (local.set $17
          (f64.add
           (f64.mul
            (f64.load
             (i32.add
              (local.get $6)
              (i32.const 8)
             )
            )
            (f64.load
             (local.get $2)
            )
           )
           (f64.add
            (f64.mul
             (f64.load
              (local.get $6)
             )
             (f64.load
              (i32.add
               (local.get $2)
               (i32.const 8)
              )
             )
            )
            (local.get $17)
           )
          )
         )
         (local.set $2
          (i32.add
           (local.get $2)
           (i32.const -16)
          )
         )
         (local.set $6
          (i32.add
           (local.get $6)
           (i32.const 16)
          )
         )
         (br_if $label9
          (i32.ne
           (local.get $13)
           (local.tee $7
            (i32.add
             (local.get $7)
             (i32.const 2)
            )
           )
          )
         )
        )
       )
       (br_if $block39
        (i32.eqz
         (local.get $20)
        )
       )
       (local.set $17
        (f64.add
         (f64.mul
          (f64.load
           (i32.add
            (local.get $0)
            (i32.shl
             (local.get $7)
             (i32.const 3)
            )
           )
          )
          (f64.load
           (i32.add
            (i32.add
             (local.get $5)
             (i32.const 320)
            )
            (i32.shl
             (i32.sub
              (local.get $19)
              (local.get $7)
             )
             (i32.const 3)
            )
           )
          )
         )
         (local.get $17)
        )
       )
      )
      (f64.store
       (i32.add
        (local.get $5)
        (i32.shl
         (local.get $12)
         (i32.const 3)
        )
       )
       (local.get $17)
      )
      (local.set $14
       (i32.add
        (local.get $14)
        (i32.const 8)
       )
      )
      (br_if $label10
       (i32.lt_s
        (local.get $12)
        (local.get $15)
       )
      )
     )
     (local.set $12
      (local.get $15)
     )
     (br $label11)
    )
   )
   (block $block42
    (block $block41
     (br_if $block41
      (i32.eqz
       (f64.ge
        (local.tee $17
         (call $scalbn
          (local.get $17)
          (i32.sub
           (i32.const 24)
           (local.get $9)
          )
         )
        )
        (f64.const 16777216)
       )
      )
     )
     (i32.store
      (i32.add
       (i32.add
        (local.get $5)
        (i32.const 480)
       )
       (i32.shl
        (local.get $12)
        (i32.const 2)
       )
      )
      (i32.trunc_sat_f64_s
       (f64.add
        (f64.mul
         (f64.convert_i32_s
          (local.tee $2
           (i32.trunc_sat_f64_s
            (f64.mul
             (local.get $17)
             (f64.const 5.9604644775390625e-08)
            )
           )
          )
         )
         (f64.const -16777216)
        )
        (local.get $17)
       )
      )
     )
     (local.set $12
      (i32.add
       (local.get $12)
       (i32.const 1)
      )
     )
     (local.set $18
      (local.get $9)
     )
     (br $block42)
    )
    (local.set $2
     (i32.trunc_sat_f64_s
      (local.get $17)
     )
    )
   )
   (i32.store
    (i32.add
     (i32.add
      (local.get $5)
      (i32.const 480)
     )
     (i32.shl
      (local.get $12)
      (i32.const 2)
     )
    )
    (local.get $2)
   )
  )
  (block $block43
   (br_if $block43
    (i32.lt_s
     (local.get $12)
     (i32.const 0)
    )
   )
   (local.set $17
    (call $scalbn
     (f64.const 1)
     (local.get $18)
    )
   )
   (block $block45
    (block $block44
     (br_if $block44
      (i32.eqz
       (i32.and
        (local.get $12)
        (i32.const 1)
       )
      )
     )
     (local.set $6
      (local.get $12)
     )
     (br $block45)
    )
    (f64.store
     (i32.add
      (local.get $5)
      (i32.shl
       (local.get $12)
       (i32.const 3)
      )
     )
     (f64.mul
      (local.get $17)
      (f64.convert_i32_s
       (i32.load
        (i32.add
         (i32.add
          (local.get $5)
          (i32.const 480)
         )
         (i32.shl
          (local.get $12)
          (i32.const 2)
         )
        )
       )
      )
     )
    )
    (local.set $6
     (i32.add
      (local.get $12)
      (i32.const -1)
     )
    )
    (local.set $17
     (f64.mul
      (local.get $17)
      (f64.const 5.9604644775390625e-08)
     )
    )
   )
   (block $block46
    (br_if $block46
     (i32.eqz
      (local.get $12)
     )
    )
    (local.set $7
     (i32.add
      (local.get $6)
      (i32.const 1)
     )
    )
    (local.set $2
     (i32.add
      (i32.add
       (i32.shl
        (local.get $6)
        (i32.const 2)
       )
       (i32.add
        (local.get $5)
        (i32.const 480)
       )
      )
      (i32.const -4)
     )
    )
    (local.set $6
     (i32.add
      (i32.add
       (i32.shl
        (local.get $6)
        (i32.const 3)
       )
       (local.get $5)
      )
      (i32.const -8)
     )
    )
    (loop $label12
     (f64.store
      (local.get $6)
      (f64.mul
       (local.tee $16
        (f64.mul
         (local.get $17)
         (f64.const 5.9604644775390625e-08)
        )
       )
       (f64.convert_i32_s
        (i32.load
         (local.get $2)
        )
       )
      )
     )
     (f64.store
      (i32.add
       (local.get $6)
       (i32.const 8)
      )
      (f64.mul
       (local.get $17)
       (f64.convert_i32_s
        (i32.load
         (i32.add
          (local.get $2)
          (i32.const 4)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const -8)
      )
     )
     (local.set $6
      (i32.add
       (local.get $6)
       (i32.const -16)
      )
     )
     (local.set $17
      (f64.mul
       (local.get $16)
       (f64.const 5.9604644775390625e-08)
      )
     )
     (br_if $label12
      (local.tee $7
       (i32.add
        (local.get $7)
        (i32.const -2)
       )
      )
     )
    )
   )
   (local.set $13
    (i32.add
     (local.get $5)
     (i32.shl
      (local.get $12)
      (i32.const 3)
     )
    )
   )
   (local.set $2
    (local.get $12)
   )
   (loop $label14
    (block $block48
     (block $block47
      (br_if $block47
       (i32.ge_s
        (local.tee $19
         (select
          (local.get $10)
          (local.tee $3
           (i32.sub
            (local.get $12)
            (local.tee $14
             (local.get $2)
            )
           )
          )
          (i32.lt_s
           (local.get $10)
           (local.get $3)
          )
         )
        )
        (i32.const 0)
       )
      )
      (local.set $17
       (f64.const 0)
      )
      (br $block48)
     )
     (block $block50
      (block $block49
       (br_if $block49
        (local.get $19)
       )
       (local.set $6
        (i32.const 0)
       )
       (local.set $17
        (f64.const 0)
       )
       (br $block50)
      )
      (local.set $15
       (i32.and
        (i32.add
         (local.get $19)
         (i32.const 1)
        )
        (i32.const -2)
       )
      )
      (local.set $17
       (f64.const 0)
      )
      (local.set $2
       (i32.const 0)
      )
      (local.set $6
       (i32.const 0)
      )
      (loop $label13
       (local.set $17
        (f64.add
         (f64.mul
          (f64.load
           (i32.add
            (local.get $2)
            (i32.const 1051368)
           )
          )
          (f64.load
           (i32.add
            (local.tee $7
             (i32.add
              (local.get $13)
              (local.get $2)
             )
            )
            (i32.const 8)
           )
          )
         )
         (f64.add
          (f64.mul
           (f64.load
            (i32.add
             (local.get $2)
             (i32.const 1051360)
            )
           )
           (f64.load
            (local.get $7)
           )
          )
          (local.get $17)
         )
        )
       )
       (local.set $2
        (i32.add
         (local.get $2)
         (i32.const 16)
        )
       )
       (br_if $label13
        (i32.ne
         (local.get $15)
         (local.tee $6
          (i32.add
           (local.get $6)
           (i32.const 2)
          )
         )
        )
       )
      )
     )
     (br_if $block48
      (i32.and
       (local.get $19)
       (i32.const 1)
      )
     )
     (local.set $17
      (f64.add
       (f64.mul
        (f64.load offset=1051360
         (i32.shl
          (local.get $6)
          (i32.const 3)
         )
        )
        (f64.load
         (i32.add
          (local.get $5)
          (i32.shl
           (i32.add
            (local.get $6)
            (local.get $14)
           )
           (i32.const 3)
          )
         )
        )
       )
       (local.get $17)
      )
     )
    )
    (f64.store
     (i32.add
      (i32.add
       (local.get $5)
       (i32.const 160)
      )
      (i32.shl
       (local.get $3)
       (i32.const 3)
      )
     )
     (local.get $17)
    )
    (local.set $13
     (i32.add
      (local.get $13)
      (i32.const -8)
     )
    )
    (local.set $2
     (i32.add
      (local.get $14)
      (i32.const -1)
     )
    )
    (br_if $label14
     (i32.gt_s
      (local.get $14)
      (i32.const 0)
     )
    )
   )
  )
  (block $block54
   (block $block58
    (block $block52
     (block $block51
      (block $block53
       (br_table $block51 $block52 $block52 $block53 $block54
        (local.get $4)
       )
      )
      (local.set $33
       (f64.const 0)
      )
      (block $block55
       (br_if $block55
        (i32.lt_s
         (local.get $12)
         (i32.const 1)
        )
       )
       (local.set $16
        (f64.load
         (local.tee $6
          (i32.add
           (i32.add
            (local.get $5)
            (i32.const 160)
           )
           (i32.shl
            (local.get $12)
            (i32.const 3)
           )
          )
         )
        )
       )
       (block $block57
        (block $block56
         (br_if $block56
          (i32.and
           (local.get $12)
           (i32.const 1)
          )
         )
         (local.set $17
          (local.get $16)
         )
         (local.set $2
          (local.get $12)
         )
         (br $block57)
        )
        (f64.store
         (local.tee $7
          (i32.add
           (i32.add
            (local.get $5)
            (i32.const 160)
           )
           (i32.shl
            (local.tee $2
             (i32.add
              (local.get $12)
              (i32.const -1)
             )
            )
            (i32.const 3)
           )
          )
         )
         (local.tee $17
          (f64.add
           (local.tee $34
            (f64.load
             (local.get $7)
            )
           )
           (local.get $16)
          )
         )
        )
        (f64.store
         (local.get $6)
         (f64.add
          (local.get $16)
          (f64.sub
           (local.get $34)
           (local.get $17)
          )
         )
        )
       )
       (br_if $block55
        (i32.eq
         (local.get $12)
         (i32.const 1)
        )
       )
       (local.set $6
        (i32.add
         (local.get $2)
         (i32.const 1)
        )
       )
       (local.set $2
        (i32.add
         (i32.add
          (i32.shl
           (local.get $2)
           (i32.const 3)
          )
          (i32.add
           (local.get $5)
           (i32.const 160)
          )
         )
         (i32.const -16)
        )
       )
       (loop $label15
        (f64.store
         (local.get $2)
         (local.tee $34
          (f64.add
           (local.tee $35
            (f64.load
             (local.get $2)
            )
           )
           (local.tee $16
            (f64.add
             (local.tee $36
              (f64.load
               (local.tee $7
                (i32.add
                 (local.get $2)
                 (i32.const 8)
                )
               )
              )
             )
             (local.get $17)
            )
           )
          )
         )
        )
        (f64.store
         (i32.add
          (local.get $2)
          (i32.const 16)
         )
         (f64.add
          (local.get $17)
          (f64.sub
           (local.get $36)
           (local.get $16)
          )
         )
        )
        (f64.store
         (local.get $7)
         (f64.add
          (local.get $16)
          (f64.sub
           (local.get $35)
           (local.get $34)
          )
         )
        )
        (local.set $2
         (i32.add
          (local.get $2)
          (i32.const -16)
         )
        )
        (local.set $17
         (local.get $34)
        )
        (br_if $label15
         (i32.gt_u
          (local.tee $6
           (i32.add
            (local.get $6)
            (i32.const -2)
           )
          )
          (i32.const 1)
         )
        )
       )
       (br_if $block55
        (i32.eq
         (local.get $12)
         (i32.const 1)
        )
       )
       (local.set $6
        (i32.add
         (local.get $12)
         (i32.const 1)
        )
       )
       (local.set $2
        (i32.add
         (local.tee $7
          (i32.add
           (i32.add
            (local.get $5)
            (i32.const 160)
           )
           (i32.shl
            (local.get $12)
            (i32.const 3)
           )
          )
         )
         (i32.const -8)
        )
       )
       (local.set $17
        (f64.load
         (local.get $7)
        )
       )
       (loop $label16
        (f64.store
         (local.get $2)
         (local.tee $16
          (f64.add
           (local.tee $34
            (f64.load
             (local.get $2)
            )
           )
           (local.get $17)
          )
         )
        )
        (f64.store
         (i32.add
          (local.get $2)
          (i32.const 8)
         )
         (f64.add
          (local.get $17)
          (f64.sub
           (local.get $34)
           (local.get $16)
          )
         )
        )
        (local.set $2
         (i32.add
          (local.get $2)
          (i32.const -8)
         )
        )
        (local.set $17
         (local.get $16)
        )
        (br_if $label16
         (i32.gt_u
          (local.tee $6
           (i32.add
            (local.get $6)
            (i32.const -1)
           )
          )
          (i32.const 2)
         )
        )
       )
       (local.set $6
        (i32.add
         (local.get $12)
         (i32.const 1)
        )
       )
       (local.set $2
        (i32.add
         (i32.add
          (local.get $5)
          (i32.const 160)
         )
         (i32.shl
          (local.get $12)
          (i32.const 3)
         )
        )
       )
       (local.set $33
        (f64.const 0)
       )
       (loop $label17
        (local.set $33
         (f64.add
          (local.get $33)
          (f64.load
           (local.get $2)
          )
         )
        )
        (local.set $2
         (i32.add
          (local.get $2)
          (i32.const -8)
         )
        )
        (br_if $label17
         (i32.gt_u
          (local.tee $6
           (i32.add
            (local.get $6)
            (i32.const -1)
           )
          )
          (i32.const 2)
         )
        )
       )
      )
      (local.set $17
       (f64.load offset=160
        (local.get $5)
       )
      )
      (br_if $block58
       (local.get $31)
      )
      (f64.store
       (local.get $1)
       (local.get $17)
      )
      (f64.store offset=16
       (local.get $1)
       (local.get $33)
      )
      (f64.store offset=8
       (local.get $1)
       (f64.load offset=168
        (local.get $5)
       )
      )
      (br $block54)
     )
     (block $block60
      (block $block59
       (br_if $block59
        (i32.ge_s
         (local.get $12)
         (i32.const 0)
        )
       )
       (local.set $17
        (f64.const 0)
       )
       (br $block60)
      )
      (block $block62
       (block $block61
        (br_if $block61
         (i32.ne
          (i32.and
           (local.get $12)
           (i32.const 3)
          )
          (i32.const 3)
         )
        )
        (local.set $17
         (f64.const 0)
        )
        (local.set $6
         (local.get $12)
        )
        (br $block62)
       )
       (local.set $7
        (i32.and
         (i32.add
          (local.get $12)
          (i32.const 1)
         )
         (i32.const 3)
        )
       )
       (local.set $2
        (i32.add
         (i32.add
          (local.get $5)
          (i32.const 160)
         )
         (i32.shl
          (local.get $12)
          (i32.const 3)
         )
        )
       )
       (local.set $17
        (f64.const 0)
       )
       (local.set $6
        (local.get $12)
       )
       (loop $label18
        (local.set $6
         (i32.add
          (local.get $6)
          (i32.const -1)
         )
        )
        (local.set $17
         (f64.add
          (local.get $17)
          (f64.load
           (local.get $2)
          )
         )
        )
        (local.set $2
         (i32.add
          (local.get $2)
          (i32.const -8)
         )
        )
        (br_if $label18
         (local.tee $7
          (i32.add
           (local.get $7)
           (i32.const -1)
          )
         )
        )
       )
      )
      (br_if $block60
       (i32.lt_u
        (local.get $12)
        (i32.const 3)
       )
      )
      (local.set $7
       (i32.add
        (local.get $6)
        (i32.const 1)
       )
      )
      (local.set $2
       (i32.add
        (i32.add
         (i32.shl
          (local.get $6)
          (i32.const 3)
         )
         (i32.add
          (local.get $5)
          (i32.const 160)
         )
        )
        (i32.const -24)
       )
      )
      (loop $label19
       (local.set $17
        (f64.add
         (f64.add
          (f64.add
           (f64.add
            (local.get $17)
            (f64.load
             (i32.add
              (local.get $2)
              (i32.const 24)
             )
            )
           )
           (f64.load
            (i32.add
             (local.get $2)
             (i32.const 16)
            )
           )
          )
          (f64.load
           (i32.add
            (local.get $2)
            (i32.const 8)
           )
          )
         )
         (f64.load
          (local.get $2)
         )
        )
       )
       (local.set $2
        (i32.add
         (local.get $2)
         (i32.const -32)
        )
       )
       (br_if $label19
        (local.tee $7
         (i32.add
          (local.get $7)
          (i32.const -4)
         )
        )
       )
      )
     )
     (f64.store
      (local.get $1)
      (select
       (f64.neg
        (local.get $17)
       )
       (local.get $17)
       (local.get $31)
      )
     )
     (br $block54)
    )
    (block $block64
     (block $block63
      (br_if $block63
       (i32.ge_s
        (local.get $12)
        (i32.const 0)
       )
      )
      (local.set $17
       (f64.const 0)
      )
      (br $block64)
     )
     (block $block66
      (block $block65
       (br_if $block65
        (i32.ne
         (i32.and
          (local.get $12)
          (i32.const 3)
         )
         (i32.const 3)
        )
       )
       (local.set $17
        (f64.const 0)
       )
       (local.set $6
        (local.get $12)
       )
       (br $block66)
      )
      (local.set $7
       (i32.and
        (i32.add
         (local.get $12)
         (i32.const 1)
        )
        (i32.const 3)
       )
      )
      (local.set $2
       (i32.add
        (i32.add
         (local.get $5)
         (i32.const 160)
        )
        (i32.shl
         (local.get $12)
         (i32.const 3)
        )
       )
      )
      (local.set $17
       (f64.const 0)
      )
      (local.set $6
       (local.get $12)
      )
      (loop $label20
       (local.set $6
        (i32.add
         (local.get $6)
         (i32.const -1)
        )
       )
       (local.set $17
        (f64.add
         (local.get $17)
         (f64.load
          (local.get $2)
         )
        )
       )
       (local.set $2
        (i32.add
         (local.get $2)
         (i32.const -8)
        )
       )
       (br_if $label20
        (local.tee $7
         (i32.add
          (local.get $7)
          (i32.const -1)
         )
        )
       )
      )
     )
     (br_if $block64
      (i32.lt_u
       (local.get $12)
       (i32.const 3)
      )
     )
     (local.set $7
      (i32.add
       (local.get $6)
       (i32.const 1)
      )
     )
     (local.set $2
      (i32.add
       (i32.add
        (i32.shl
         (local.get $6)
         (i32.const 3)
        )
        (i32.add
         (local.get $5)
         (i32.const 160)
        )
       )
       (i32.const -24)
      )
     )
     (loop $label21
      (local.set $17
       (f64.add
        (f64.add
         (f64.add
          (f64.add
           (local.get $17)
           (f64.load
            (i32.add
             (local.get $2)
             (i32.const 24)
            )
           )
          )
          (f64.load
           (i32.add
            (local.get $2)
            (i32.const 16)
           )
          )
         )
         (f64.load
          (i32.add
           (local.get $2)
           (i32.const 8)
          )
         )
        )
        (f64.load
         (local.get $2)
        )
       )
      )
      (local.set $2
       (i32.add
        (local.get $2)
        (i32.const -32)
       )
      )
      (br_if $label21
       (local.tee $7
        (i32.add
         (local.get $7)
         (i32.const -4)
        )
       )
      )
     )
    )
    (f64.store
     (local.get $1)
     (select
      (f64.neg
       (local.get $17)
      )
      (local.get $17)
      (local.get $31)
     )
    )
    (local.set $17
     (f64.sub
      (f64.load offset=160
       (local.get $5)
      )
      (local.get $17)
     )
    )
    (local.set $2
     (i32.const 1)
    )
    (block $block67
     (br_if $block67
      (i32.lt_s
       (local.get $12)
       (i32.const 1)
      )
     )
     (local.set $6
      (i32.and
       (local.get $12)
       (i32.const 3)
      )
     )
     (block $block68
      (br_if $block68
       (i32.lt_u
        (i32.add
         (local.get $12)
         (i32.const -1)
        )
        (i32.const 3)
       )
      )
      (local.set $13
       (i32.and
        (local.get $12)
        (i32.const 2147483644)
       )
      )
      (local.set $2
       (i32.add
        (i32.add
         (local.get $5)
         (i32.const 160)
        )
        (i32.const 32)
       )
      )
      (local.set $7
       (i32.const 0)
      )
      (loop $label22
       (local.set $17
        (f64.add
         (f64.add
          (f64.add
           (f64.add
            (local.get $17)
            (f64.load
             (i32.add
              (local.get $2)
              (i32.const -24)
             )
            )
           )
           (f64.load
            (i32.add
             (local.get $2)
             (i32.const -16)
            )
           )
          )
          (f64.load
           (i32.add
            (local.get $2)
            (i32.const -8)
           )
          )
         )
         (f64.load
          (local.get $2)
         )
        )
       )
       (local.set $2
        (i32.add
         (local.get $2)
         (i32.const 32)
        )
       )
       (br_if $label22
        (i32.ne
         (local.get $13)
         (local.tee $7
          (i32.add
           (local.get $7)
           (i32.const 4)
          )
         )
        )
       )
      )
      (local.set $2
       (i32.add
        (local.get $7)
        (i32.const 1)
       )
      )
     )
     (br_if $block67
      (i32.eqz
       (local.get $6)
      )
     )
     (local.set $2
      (i32.add
       (i32.add
        (local.get $5)
        (i32.const 160)
       )
       (i32.shl
        (local.get $2)
        (i32.const 3)
       )
      )
     )
     (loop $label23
      (local.set $17
       (f64.add
        (local.get $17)
        (f64.load
         (local.get $2)
        )
       )
      )
      (local.set $2
       (i32.add
        (local.get $2)
        (i32.const 8)
       )
      )
      (br_if $label23
       (local.tee $6
        (i32.add
         (local.get $6)
         (i32.const -1)
        )
       )
      )
     )
    )
    (f64.store offset=8
     (local.get $1)
     (select
      (f64.neg
       (local.get $17)
      )
      (local.get $17)
      (local.get $31)
     )
    )
    (br $block54)
   )
   (f64.store
    (local.get $1)
    (f64.neg
     (local.get $17)
    )
   )
   (f64.store offset=16
    (local.get $1)
    (f64.neg
     (local.get $33)
    )
   )
   (f64.store offset=8
    (local.get $1)
    (f64.neg
     (f64.load offset=168
      (local.get $5)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 560)
   )
  )
  (i32.and
   (local.get $29)
   (i32.const 7)
  )
 )
 (func $__rem_pio2 (param $0 f64) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i64)
  (local $4 i32)
  (local $5 i32)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (local $10 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 48)
    )
   )
  )
  (block $block4
   (block $block10
    (block $block1
     (block $block
      (br_if $block
       (i32.gt_u
        (local.tee $5
         (i32.and
          (local.tee $4
           (i32.wrap_i64
            (i64.shr_u
             (local.tee $3
              (i64.reinterpret_f64
               (local.get $0)
              )
             )
             (i64.const 32)
            )
           )
          )
          (i32.const 2147483647)
         )
        )
        (i32.const 1074752122)
       )
      )
      (br_if $block1
       (i32.eq
        (i32.and
         (local.get $4)
         (i32.const 1048575)
        )
        (i32.const 598523)
       )
      )
      (block $block2
       (br_if $block2
        (i32.gt_u
         (local.get $5)
         (i32.const 1073928572)
        )
       )
       (block $block3
        (br_if $block3
         (i64.lt_s
          (local.get $3)
          (i64.const 0)
         )
        )
        (f64.store
         (local.get $1)
         (local.tee $6
          (f64.add
           (local.tee $0
            (f64.add
             (local.get $0)
             (f64.const -1.5707963267341256)
            )
           )
           (f64.const -6.077100506506192e-11)
          )
         )
        )
        (f64.store offset=8
         (local.get $1)
         (f64.add
          (f64.sub
           (local.get $0)
           (local.get $6)
          )
          (f64.const -6.077100506506192e-11)
         )
        )
        (local.set $4
         (i32.const 1)
        )
        (br $block4)
       )
       (f64.store
        (local.get $1)
        (local.tee $6
         (f64.add
          (local.tee $0
           (f64.add
            (local.get $0)
            (f64.const 1.5707963267341256)
           )
          )
          (f64.const 6.077100506506192e-11)
         )
        )
       )
       (f64.store offset=8
        (local.get $1)
        (f64.add
         (f64.sub
          (local.get $0)
          (local.get $6)
         )
         (f64.const 6.077100506506192e-11)
        )
       )
       (local.set $4
        (i32.const -1)
       )
       (br $block4)
      )
      (block $block5
       (br_if $block5
        (i64.lt_s
         (local.get $3)
         (i64.const 0)
        )
       )
       (f64.store
        (local.get $1)
        (local.tee $6
         (f64.add
          (local.tee $0
           (f64.add
            (local.get $0)
            (f64.const -3.1415926534682512)
           )
          )
          (f64.const -1.2154201013012384e-10)
         )
        )
       )
       (f64.store offset=8
        (local.get $1)
        (f64.add
         (f64.sub
          (local.get $0)
          (local.get $6)
         )
         (f64.const -1.2154201013012384e-10)
        )
       )
       (local.set $4
        (i32.const 2)
       )
       (br $block4)
      )
      (f64.store
       (local.get $1)
       (local.tee $6
        (f64.add
         (local.tee $0
          (f64.add
           (local.get $0)
           (f64.const 3.1415926534682512)
          )
         )
         (f64.const 1.2154201013012384e-10)
        )
       )
      )
      (f64.store offset=8
       (local.get $1)
       (f64.add
        (f64.sub
         (local.get $0)
         (local.get $6)
        )
        (f64.const 1.2154201013012384e-10)
       )
      )
      (local.set $4
       (i32.const -2)
      )
      (br $block4)
     )
     (block $block6
      (br_if $block6
       (i32.gt_u
        (local.get $5)
        (i32.const 1075594811)
       )
      )
      (block $block7
       (br_if $block7
        (i32.gt_u
         (local.get $5)
         (i32.const 1075183036)
        )
       )
       (br_if $block1
        (i32.eq
         (local.get $5)
         (i32.const 1074977148)
        )
       )
       (block $block8
        (br_if $block8
         (i64.lt_s
          (local.get $3)
          (i64.const 0)
         )
        )
        (f64.store
         (local.get $1)
         (local.tee $6
          (f64.add
           (local.tee $0
            (f64.add
             (local.get $0)
             (f64.const -4.712388980202377)
            )
           )
           (f64.const -1.8231301519518578e-10)
          )
         )
        )
        (f64.store offset=8
         (local.get $1)
         (f64.add
          (f64.sub
           (local.get $0)
           (local.get $6)
          )
          (f64.const -1.8231301519518578e-10)
         )
        )
        (local.set $4
         (i32.const 3)
        )
        (br $block4)
       )
       (f64.store
        (local.get $1)
        (local.tee $6
         (f64.add
          (local.tee $0
           (f64.add
            (local.get $0)
            (f64.const 4.712388980202377)
           )
          )
          (f64.const 1.8231301519518578e-10)
         )
        )
       )
       (f64.store offset=8
        (local.get $1)
        (f64.add
         (f64.sub
          (local.get $0)
          (local.get $6)
         )
         (f64.const 1.8231301519518578e-10)
        )
       )
       (local.set $4
        (i32.const -3)
       )
       (br $block4)
      )
      (br_if $block1
       (i32.eq
        (local.get $5)
        (i32.const 1075388923)
       )
      )
      (block $block9
       (br_if $block9
        (i64.lt_s
         (local.get $3)
         (i64.const 0)
        )
       )
       (f64.store
        (local.get $1)
        (local.tee $6
         (f64.add
          (local.tee $0
           (f64.add
            (local.get $0)
            (f64.const -6.2831853069365025)
           )
          )
          (f64.const -2.430840202602477e-10)
         )
        )
       )
       (f64.store offset=8
        (local.get $1)
        (f64.add
         (f64.sub
          (local.get $0)
          (local.get $6)
         )
         (f64.const -2.430840202602477e-10)
        )
       )
       (local.set $4
        (i32.const 4)
       )
       (br $block4)
      )
      (f64.store
       (local.get $1)
       (local.tee $6
        (f64.add
         (local.tee $0
          (f64.add
           (local.get $0)
           (f64.const 6.2831853069365025)
          )
         )
         (f64.const 2.430840202602477e-10)
        )
       )
      )
      (f64.store offset=8
       (local.get $1)
       (f64.add
        (f64.sub
         (local.get $0)
         (local.get $6)
        )
        (f64.const 2.430840202602477e-10)
       )
      )
      (local.set $4
       (i32.const -4)
      )
      (br $block4)
     )
     (br_if $block10
      (i32.gt_u
       (local.get $5)
       (i32.const 1094263290)
      )
     )
    )
    (f64.store
     (local.get $1)
     (local.tee $0
      (f64.sub
       (local.tee $7
        (f64.add
         (local.get $0)
         (f64.mul
          (local.tee $6
           (f64.add
            (f64.add
             (f64.mul
              (local.get $0)
              (f64.const 0.6366197723675814)
             )
             (f64.const 6755399441055744)
            )
            (f64.const -6755399441055744)
           )
          )
          (f64.const -1.5707963267341256)
         )
        )
       )
       (local.tee $8
        (f64.mul
         (local.get $6)
         (f64.const 6.077100506506192e-11)
        )
       )
      )
     )
    )
    (block $block11
     (br_if $block11
      (i32.lt_s
       (i32.sub
        (local.tee $4
         (i32.shr_u
          (local.get $5)
          (i32.const 20)
         )
        )
        (i32.and
         (i32.wrap_i64
          (i64.shr_u
           (i64.reinterpret_f64
            (local.get $0)
           )
           (i64.const 52)
          )
         )
         (i32.const 2047)
        )
       )
       (i32.const 17)
      )
     )
     (f64.store
      (local.get $1)
      (local.tee $0
       (f64.sub
        (local.tee $9
         (f64.sub
          (local.get $7)
          (local.tee $0
           (f64.mul
            (local.get $6)
            (f64.const 6.077100506303966e-11)
           )
          )
         )
        )
        (local.tee $8
         (f64.sub
          (f64.mul
           (local.get $6)
           (f64.const 2.0222662487959506e-21)
          )
          (f64.sub
           (f64.sub
            (local.get $7)
            (local.get $9)
           )
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (block $block12
      (br_if $block12
       (i32.ge_s
        (i32.sub
         (local.get $4)
         (i32.and
          (i32.wrap_i64
           (i64.shr_u
            (i64.reinterpret_f64
             (local.get $0)
            )
            (i64.const 52)
           )
          )
          (i32.const 2047)
         )
        )
        (i32.const 50)
       )
      )
      (local.set $7
       (local.get $9)
      )
      (br $block11)
     )
     (f64.store
      (local.get $1)
      (local.tee $0
       (f64.sub
        (local.tee $7
         (f64.sub
          (local.get $9)
          (local.tee $0
           (f64.mul
            (local.get $6)
            (f64.const 2.0222662487111665e-21)
           )
          )
         )
        )
        (local.tee $8
         (f64.sub
          (f64.mul
           (local.get $6)
           (f64.const 8.4784276603689e-32)
          )
          (f64.sub
           (f64.sub
            (local.get $9)
            (local.get $7)
           )
           (local.get $0)
          )
         )
        )
       )
      )
     )
    )
    (local.set $4
     (i32.trunc_sat_f64_s
      (local.get $6)
     )
    )
    (f64.store offset=8
     (local.get $1)
     (f64.sub
      (f64.sub
       (local.get $7)
       (local.get $0)
      )
      (local.get $8)
     )
    )
    (br $block4)
   )
   (block $block13
    (br_if $block13
     (i32.lt_u
      (local.get $5)
      (i32.const 2146435072)
     )
    )
    (f64.store
     (local.get $1)
     (local.tee $0
      (f64.sub
       (local.get $0)
       (local.get $0)
      )
     )
    )
    (f64.store offset=8
     (local.get $1)
     (local.get $0)
    )
    (local.set $4
     (i32.const 0)
    )
    (br $block4)
   )
   (f64.store offset=16
    (local.get $2)
    (local.tee $6
     (f64.convert_i32_s
      (i32.trunc_sat_f64_s
       (local.tee $0
        (f64.reinterpret_i64
         (i64.or
          (i64.and
           (local.get $3)
           (i64.const 4503599627370495)
          )
          (i64.const 4710765210229538816)
         )
        )
       )
      )
     )
    )
   )
   (f64.store offset=24
    (local.get $2)
    (local.tee $6
     (f64.convert_i32_s
      (i32.trunc_sat_f64_s
       (local.tee $0
        (f64.mul
         (f64.sub
          (local.get $0)
          (local.get $6)
         )
         (f64.const 16777216)
        )
       )
      )
     )
    )
   )
   (f64.store offset=32
    (local.get $2)
    (f64.mul
     (f64.sub
      (local.get $0)
      (local.get $6)
     )
     (f64.const 16777216)
    )
   )
   (local.set $4
    (i32.add
     (local.get $2)
     (i32.const 32)
    )
   )
   (local.set $10
    (i32.const 4)
   )
   (loop $label
    (local.set $10
     (i32.add
      (local.get $10)
      (i32.const -1)
     )
    )
    (local.set $0
     (f64.load
      (local.get $4)
     )
    )
    (local.set $4
     (i32.add
      (local.get $4)
      (i32.const -8)
     )
    )
    (br_if $label
     (f64.eq
      (local.get $0)
      (f64.const 0)
     )
    )
   )
   (local.set $4
    (call $__rem_pio2_large
     (i32.add
      (local.get $2)
      (i32.const 16)
     )
     (local.get $2)
     (i32.add
      (i32.shr_u
       (local.get $5)
       (i32.const 20)
      )
      (i32.const -1046)
     )
     (local.get $10)
     (i32.const 1)
    )
   )
   (local.set $0
    (f64.load
     (local.get $2)
    )
   )
   (block $block14
    (br_if $block14
     (i64.gt_s
      (local.get $3)
      (i64.const -1)
     )
    )
    (f64.store
     (local.get $1)
     (f64.neg
      (local.get $0)
     )
    )
    (f64.store offset=8
     (local.get $1)
     (f64.neg
      (f64.load offset=8
       (local.get $2)
      )
     )
    )
    (local.set $4
     (i32.sub
      (i32.const 0)
      (local.get $4)
     )
    )
    (br $block4)
   )
   (f64.store
    (local.get $1)
    (local.get $0)
   )
   (f64.store offset=8
    (local.get $1)
    (f64.load offset=8
     (local.get $2)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 48)
   )
  )
  (local.get $4)
 )
 (func $__cos (param $0 f64) (param $1 f64) (result f64)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (f64.add
   (local.tee $4
    (f64.sub
     (f64.const 1)
     (local.tee $3
      (f64.mul
       (local.tee $2
        (f64.mul
         (local.get $0)
         (local.get $0)
        )
       )
       (f64.const 0.5)
      )
     )
    )
   )
   (f64.add
    (f64.sub
     (f64.sub
      (f64.const 1)
      (local.get $4)
     )
     (local.get $3)
    )
    (f64.sub
     (f64.mul
      (local.get $2)
      (f64.add
       (f64.mul
        (local.get $2)
        (f64.add
         (f64.mul
          (local.get $2)
          (f64.add
           (f64.mul
            (local.get $2)
            (f64.const 2.480158728947673e-05)
           )
           (f64.const -0.001388888888887411)
          )
         )
         (f64.const 0.0416666666666666)
        )
       )
       (f64.mul
        (f64.mul
         (local.tee $3
          (f64.mul
           (local.get $2)
           (local.get $2)
          )
         )
         (local.get $3)
        )
        (f64.add
         (f64.mul
          (local.get $2)
          (f64.add
           (f64.mul
            (local.get $2)
            (f64.const -1.1359647557788195e-11)
           )
           (f64.const 2.087572321298175e-09)
          )
         )
         (f64.const -2.7557314351390663e-07)
        )
       )
      )
     )
     (f64.mul
      (local.get $0)
      (local.get $1)
     )
    )
   )
  )
 )
 (func $sin (param $0 f64) (result f64)
  (local $1 i32)
  (local $2 i32)
  (local $3 f64)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (i32.gt_u
      (local.tee $2
       (i32.and
        (i32.wrap_i64
         (i64.shr_u
          (i64.reinterpret_f64
           (local.get $0)
          )
          (i64.const 32)
         )
        )
        (i32.const 2147483647)
       )
      )
      (i32.const 1072243195)
     )
    )
    (br_if $block1
     (i32.lt_u
      (local.get $2)
      (i32.const 1045430272)
     )
    )
    (local.set $0
     (call $__sin
      (local.get $0)
      (f64.const 0)
      (i32.const 0)
     )
    )
    (br $block1)
   )
   (block $block2
    (br_if $block2
     (i32.lt_u
      (local.get $2)
      (i32.const 2146435072)
     )
    )
    (local.set $0
     (f64.sub
      (local.get $0)
      (local.get $0)
     )
    )
    (br $block1)
   )
   (local.set $2
    (call $__rem_pio2
     (local.get $0)
     (local.get $1)
    )
   )
   (local.set $0
    (f64.load offset=8
     (local.get $1)
    )
   )
   (local.set $3
    (f64.load
     (local.get $1)
    )
   )
   (block $block6
    (block $block5
     (block $block4
      (block $block3
       (br_table $block3 $block4 $block5 $block6 $block3
        (i32.and
         (local.get $2)
         (i32.const 3)
        )
       )
      )
      (local.set $0
       (call $__sin
        (local.get $3)
        (local.get $0)
        (i32.const 1)
       )
      )
      (br $block1)
     )
     (local.set $0
      (call $__cos
       (local.get $3)
       (local.get $0)
      )
     )
     (br $block1)
    )
    (local.set $0
     (f64.neg
      (call $__sin
       (local.get $3)
       (local.get $0)
       (i32.const 1)
      )
     )
    )
    (br $block1)
   )
   (local.set $0
    (f64.neg
     (call $__cos
      (local.get $3)
      (local.get $0)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $1)
    (i32.const 16)
   )
  )
  (local.get $0)
 )
 (func $dummy
 )
 (func $__wasm_call_dtors
  (call $dummy)
  (call $dummy)
 )
 (func $snail_sin.command_export (param $0 f64) (result f64)
  (local $scratch f64)
  (local.set $scratch
   (call $snail_sin
    (local.get $0)
   )
  )
  (call $__wasm_call_dtors)
  (local.get $scratch)
 )
 ;; custom section ".debug_abbrev", size 5607
 ;; custom section ".debug_info", size 50447
 ;; custom section ".debug_ranges", size 5232
 ;; custom section ".debug_str", size 59216
 ;; custom section ".debug_line", size 34917
 ;; custom section ".debug_loc", size 19400
 ;; custom section "producers", size 174
 ;; features section: mutable-globals, nontrapping-float-to-int, bulk-memory, sign-ext, reference-types, multivalue, extended-const, bulk-memory-opt, call-indirect-overlong
)

