(module
 (rec
  (type $environment3 (struct (field i64) (field (ref $type2))))
  (type $type2 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $environment1 (struct (field (ref $type2))))
  (type $call0 (func (param structref i64 i64) (result i64)))
  (type $type1 (struct))
  (type $type0 (struct (field (ref $call0)) (field structref)))
 )
 (type $6 (func (param i64) (result i64)))
 (type $7 (func (param i32) (result i64)))
 (type $8 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global11 (mut (ref null $type0)) (ref.null none))
 (global $ready11 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type1)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global5 (mut i64) (i64.const 0))
 (global $ready5 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type1)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function1 (type $call0) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type2 0
       (struct.get $environment1 0
        (ref.cast (ref $environment1)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function1
     (struct.get $type0 1
      (struct.get $type2 1
       (struct.get $environment1 0
        (ref.cast (ref $environment1)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (i64.add
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function3 (type $call0) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $type2))
  (local $4 (ref $environment3))
  (local $5 (ref $type0))
  (if (result i64)
   (i64.gt_s
    (struct.get $environment3 0
     (local.tee $4
      (ref.cast (ref $environment3)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready11)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global11)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global5)
     )
    )
    (if
     (i32.eqz
      (global.get $ready0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global0)
     )
    )
    (struct.set $type2 1
     (local.tee $3
      (struct.new_default $type2)
     )
     (struct.new $type0
      (ref.func $function1)
      (struct.new $environment1
       (local.get $3)
      )
     )
    )
    (struct.set $type2 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type2 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call_ref $call0
      (struct.get $type0 1
       (local.tee $5
        (ref.as_non_null
         (struct.get $type2 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $2)
      (i64.const 0)
      (struct.get $type0 0
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type2 0
       (struct.get $environment3 1
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function3
     (struct.get $type0 1
      (struct.get $type2 1
       (struct.get $environment3 1
        (local.get $4)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function4 (type $call0) (param $0 structref) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type2))
  (local $2 (ref $type0))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready6)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global6)
   )
  )
  (struct.set $type2 1
   (local.tee $1
    (struct.new_default $type2)
   )
   (struct.new $type0
    (ref.func $function3)
    (struct.new $environment3
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type2 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type2 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type2 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type0 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global11
   (struct.new $type0
    (ref.func $function4)
    (ref.null none)
   )
  )
  (global.set $ready11
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type1)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global5
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready5
   (i32.const 1)
  )
  (global.set $global6
   (struct.new_default $type1)
  )
  (global.set $ready6
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

