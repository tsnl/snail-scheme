(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-benchmarks-20261013/build/strict-suite-final/sum/program.scm" "/tmp/snail-strict-benchmarks-20261013/build/strict-suite-final/sum/program.so"))
