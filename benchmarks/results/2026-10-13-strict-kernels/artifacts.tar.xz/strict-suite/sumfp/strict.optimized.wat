(module
 (rec
  (type $type5 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $environment3 (struct (field i64) (field (ref $type5))))
  (type $call0 (func (param (ref null $environment3) i64 f64) (result f64)))
  (type $call3 (func (param (ref $environment1) f64 f64) (result f64)))
  (type $type3 (struct (field (ref $environment1))))
  (type $type4 (struct (field (mut i32)) (field (mut (ref null $type3)))))
  (type $environment1 (struct (field (ref $type4))))
  (type $call1 (func (param f64) (result f64)))
  (type $type2 (struct))
  (type $type1 (struct))
  (type $type0 (struct (field (ref $call0)) (field (ref null $environment3))))
 )
 (type $11 (func (param f64) (result f64)))
 (type $12 (func (param i32) (result f64)))
 (type $13 (func (param i64) (result f64)))
 (type $14 (func))
 (import "benchmark" "hide_f64" (func $foreign0 (param f64) (result f64)))
 (import "benchmark" "input_f64" (func $foreign1 (param i32) (result f64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global11 (mut (ref null $type0)) (ref.null none))
 (global $ready11 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type1)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global5 (mut f64) (f64.const 0))
 (global $ready5 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type2)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function0 (type $call1) (param $0 f64) (result f64)
  (local $1 (ref $environment1))
  (local $2 (ref $type4))
  (local $3 f64)
  (struct.set $type4 1
   (local.tee $2
    (struct.new_default $type4)
   )
   (struct.new $type3
    (struct.new $environment1
     (local.get $2)
    )
   )
  )
  (struct.set $type4 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type4 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type3 0
    (struct.get $type4 1
     (local.get $2)
    )
   )
  )
  (if (result f64)
   (f64.lt
    (local.get $0)
    (f64.const 0)
   )
   (then
    (f64.const 0)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type4 0
       (struct.get $environment1 0
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type3 0
      (struct.get $type4 1
       (struct.get $environment1 0
        (local.get $1)
       )
      )
     )
    )
    (local.set $3
     (f64.add
      (local.get $0)
      (f64.const 0)
     )
    )
    (if (result f64)
     (f64.lt
      (local.tee $0
       (f64.add
        (local.get $0)
        (f64.const -1)
       )
      )
      (f64.const 0)
     )
     (then
      (local.get $3)
     )
     (else
      (if
       (i32.eqz
        (struct.get $type4 0
         (struct.get $environment1 0
          (local.get $1)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type3 0
        (struct.get $type4 1
         (struct.get $environment1 0
          (local.get $1)
         )
        )
       )
      )
      (local.set $3
       (f64.add
        (local.get $0)
        (local.get $3)
       )
      )
      (if (result f64)
       (f64.lt
        (local.tee $0
         (f64.add
          (local.get $0)
          (f64.const -1)
         )
        )
        (f64.const 0)
       )
       (then
        (local.get $3)
       )
       (else
        (if
         (i32.eqz
          (struct.get $type4 0
           (struct.get $environment1 0
            (local.get $1)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type3 0
          (struct.get $type4 1
           (struct.get $environment1 0
            (local.get $1)
           )
          )
         )
        )
        (local.set $3
         (f64.add
          (local.get $0)
          (local.get $3)
         )
        )
        (if (result f64)
         (f64.lt
          (local.tee $0
           (f64.add
            (local.get $0)
            (f64.const -1)
           )
          )
          (f64.const 0)
         )
         (then
          (local.get $3)
         )
         (else
          (if
           (i32.eqz
            (struct.get $type4 0
             (struct.get $environment1 0
              (local.get $1)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (struct.get $type3 0
            (struct.get $type4 1
             (struct.get $environment1 0
              (local.get $1)
             )
            )
           )
          )
          (local.set $3
           (f64.add
            (local.get $0)
            (local.get $3)
           )
          )
          (if (result f64)
           (f64.lt
            (local.tee $0
             (f64.add
              (local.get $0)
              (f64.const -1)
             )
            )
            (f64.const 0)
           )
           (then
            (local.get $3)
           )
           (else
            (if
             (i32.eqz
              (struct.get $type4 0
               (struct.get $environment1 0
                (local.get $1)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $1
             (struct.get $type3 0
              (struct.get $type4 1
               (struct.get $environment1 0
                (local.get $1)
               )
              )
             )
            )
            (local.set $3
             (f64.add
              (local.get $0)
              (local.get $3)
             )
            )
            (if (result f64)
             (f64.lt
              (local.tee $0
               (f64.add
                (local.get $0)
                (f64.const -1)
               )
              )
              (f64.const 0)
             )
             (then
              (local.get $3)
             )
             (else
              (if
               (i32.eqz
                (struct.get $type4 0
                 (struct.get $environment1 0
                  (local.get $1)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $1
               (struct.get $type3 0
                (struct.get $type4 1
                 (struct.get $environment1 0
                  (local.get $1)
                 )
                )
               )
              )
              (local.set $3
               (f64.add
                (local.get $0)
                (local.get $3)
               )
              )
              (if (result f64)
               (f64.lt
                (local.tee $0
                 (f64.add
                  (local.get $0)
                  (f64.const -1)
                 )
                )
                (f64.const 0)
               )
               (then
                (local.get $3)
               )
               (else
                (if
                 (i32.eqz
                  (struct.get $type4 0
                   (struct.get $environment1 0
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $1
                 (struct.get $type3 0
                  (struct.get $type4 1
                   (struct.get $environment1 0
                    (local.get $1)
                   )
                  )
                 )
                )
                (local.set $3
                 (f64.add
                  (local.get $0)
                  (local.get $3)
                 )
                )
                (if (result f64)
                 (f64.lt
                  (local.tee $0
                   (f64.add
                    (local.get $0)
                    (f64.const -1)
                   )
                  )
                  (f64.const 0)
                 )
                 (then
                  (local.get $3)
                 )
                 (else
                  (if
                   (i32.eqz
                    (struct.get $type4 0
                     (struct.get $environment1 0
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $1
                   (struct.get $type3 0
                    (struct.get $type4 1
                     (struct.get $environment1 0
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (local.set $3
                   (f64.add
                    (local.get $0)
                    (local.get $3)
                   )
                  )
                  (if (result f64)
                   (f64.lt
                    (local.tee $0
                     (f64.add
                      (local.get $0)
                      (f64.const -1)
                     )
                    )
                    (f64.const 0)
                   )
                   (then
                    (local.get $3)
                   )
                   (else
                    (if
                     (i32.eqz
                      (struct.get $type4 0
                       (struct.get $environment1 0
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $1
                     (struct.get $type3 0
                      (struct.get $type4 1
                       (struct.get $environment1 0
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (local.set $3
                     (f64.add
                      (local.get $0)
                      (local.get $3)
                     )
                    )
                    (if (result f64)
                     (f64.lt
                      (local.tee $0
                       (f64.add
                        (local.get $0)
                        (f64.const -1)
                       )
                      )
                      (f64.const 0)
                     )
                     (then
                      (local.get $3)
                     )
                     (else
                      (if
                       (i32.eqz
                        (struct.get $type4 0
                         (struct.get $environment1 0
                          (local.get $1)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (return_call $function1
                       (struct.get $type3 0
                        (struct.get $type4 1
                         (struct.get $environment1 0
                          (local.get $1)
                         )
                        )
                       )
                       (f64.add
                        (local.get $0)
                        (f64.const -1)
                       )
                       (f64.add
                        (local.get $0)
                        (local.get $3)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function1 (type $call3) (param $0 (ref $environment1)) (param $1 f64) (param $2 f64) (result f64)
  (if (result f64)
   (f64.lt
    (local.get $1)
    (f64.const 0)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type4 0
       (struct.get $environment1 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function1
     (struct.get $type3 0
      (struct.get $type4 1
       (struct.get $environment1 0
        (local.get $0)
       )
      )
     )
     (f64.add
      (local.get $1)
      (f64.const -1)
     )
     (f64.add
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function3 (type $call0) (param $0 (ref null $environment3)) (param $1 i64) (param $2 f64) (result f64)
  (local $scratch f64)
  (if (result f64)
   (i64.gt_s
    (struct.get $environment3 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready11)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global11)
     )
    )
    (local.set $2
     (call $function0
      (block (result f64)
       (local.set $scratch
        (call $foreign0
         (global.get $global5)
        )
       )
       (if
        (i32.eqz
         (global.get $ready0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global0)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type5 0
       (struct.get $environment3 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function3
     (struct.get $type0 1
      (struct.get $type5 1
       (struct.get $environment3 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function4 (type $call0) (param $0 (ref null $environment3)) (param $1 i64) (param $2 f64) (result f64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result f64)
  (local $1 (ref $type5))
  (local $2 (ref $type0))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready6)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global6)
   )
  )
  (struct.set $type5 1
   (local.tee $1
    (struct.new_default $type5)
   )
   (struct.new $type0
    (ref.func $function3)
    (struct.new $environment3
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type5 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type5 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type5 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (f64.const 0)
   (struct.get $type0 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global11
   (struct.new $type0
    (ref.func $function4)
    (ref.null none)
   )
  )
  (global.set $ready11
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type1)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global5
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready5
   (i32.const 1)
  )
  (global.set $global6
   (struct.new_default $type2)
  )
  (global.set $ready6
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

