(module
 (rec
  (type $call0 (func (param (ref null $environment7) i64 i64) (result i64)))
  (type $environment7 (struct (field i64) (field (ref $type5))))
  (type $type5 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $environment5 (struct (field (ref $type3)) (field i64) (field i64) (field (ref $type2))))
  (type $environment4 (struct (field (ref $type3)) (field i64) (field i64) (field i64) (field i64) (field (ref $type2))))
  (type $call4 (func (param (ref $environment2) i64 i64 i64 (ref $type2)) (result i64)))
  (type $call2 (func (param structref i64) (result i64)))
  (type $environment3 (struct (field (ref $type3)) (field i64) (field i64) (field i64) (field (ref $type2))))
  (type $type4 (struct (field (ref $environment2))))
  (type $type3 (struct (field (mut i32)) (field (mut (ref null $type4)))))
  (type $environment2 (struct (field (ref $type3))))
  (type $call1 (func (param i64 i64 i64) (result i64)))
  (type $type2 (struct (field (ref $call2)) (field structref)))
  (type $type1 (struct))
  (type $type0 (struct (field (ref $call0)) (field (ref null $environment7))))
 )
 (type $15 (func (param i64) (result i64)))
 (type $16 (func (param i32) (result i64)))
 (type $17 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global21 (mut (ref null $type0)) (ref.null none))
 (global $ready21 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type1)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global13 (mut i64) (i64.const 0))
 (global $ready13 (mut i32) (i32.const 0))
 (global $global14 (mut i64) (i64.const 0))
 (global $ready14 (mut i32) (i32.const 0))
 (global $global15 (mut i64) (i64.const 0))
 (global $ready15 (mut i32) (i32.const 0))
 (global $global16 (mut (ref null $type2)) (ref.null none))
 (global $ready16 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function0 (type $call1) (param $0 i64) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref $environment2))
  (local $4 (ref $type3))
  (local $5 (ref $type3))
  (local $6 (ref null $type2))
  (local $7 (ref $type2))
  (struct.set $type3 1
   (local.tee $5
    (struct.new_default $type3)
   )
   (struct.new $type4
    (struct.new $environment2
     (local.get $5)
    )
   )
  )
  (struct.set $type3 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type3 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type4 0
    (struct.get $type3 1
     (local.get $5)
    )
   )
  )
  (block $block
   (return
    (if (result i64)
     (i64.gt_s
      (local.get $0)
      (local.get $1)
     )
     (then
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $6
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $1)
         (local.get $2)
         (local.get $0)
         (struct.new $type2
          (ref.func $function1)
          (ref.null none)
         )
        )
       )
      )
      (br_if $block
       (i64.le_s
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $6
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $1)
         (local.get $2)
         (local.get $0)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (br_if $block
       (i64.le_s
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $6
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $1)
         (local.get $2)
         (local.get $0)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (br_if $block
       (i64.le_s
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $6
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $1)
         (local.get $2)
         (local.get $0)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (br_if $block
       (i64.le_s
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $6
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $1)
         (local.get $2)
         (local.get $0)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (br_if $block
       (i64.le_s
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $6
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $1)
         (local.get $2)
         (local.get $0)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (br_if $block
       (i64.le_s
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $6
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $1)
         (local.get $2)
         (local.get $0)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (br_if $block
       (i64.le_s
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $6
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $1)
         (local.get $2)
         (local.get $0)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (br_if $block
       (i64.le_s
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $3)
          )
         )
        )
       )
      )
      (local.set $7
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $1)
         (local.get $2)
         (local.get $0)
         (ref.as_non_null
          (local.get $6)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (local.get $1)
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (if
         (i32.eqz
          (struct.get $type3 0
           (struct.get $environment2 0
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function2
         (struct.get $type4 0
          (struct.get $type3 1
           (local.tee $4
            (struct.get $environment2 0
             (local.get $3)
            )
           )
          )
         )
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
         (local.get $1)
         (local.get $2)
         (struct.new $type2
          (ref.func $function3)
          (struct.new $environment3
           (local.get $4)
           (local.get $1)
           (local.get $2)
           (local.get $0)
           (local.get $7)
          )
         )
        )
       )
       (else
        (return_call_ref $call2
         (struct.get $type2 1
          (local.get $7)
         )
         (local.get $2)
         (struct.get $type2 0
          (local.get $7)
         )
        )
       )
      )
      (unreachable)
     )
     (else
      (local.get $2)
     )
    )
   )
  )
  (return_call_ref $call2
   (struct.get $type2 1
    (local.get $6)
   )
   (local.get $2)
   (struct.get $type2 0
    (local.get $6)
   )
  )
 )
 (func $function1 (type $call2) (param $0 structref) (param $1 i64) (result i64)
  (local.get $1)
 )
 (func $function2 (type $call4) (param $0 (ref $environment2)) (param $1 i64) (param $2 i64) (param $3 i64) (param $4 (ref $type2)) (result i64)
  (local $5 (ref $type3))
  (if
   (i64.gt_s
    (local.get $1)
    (local.get $2)
   )
   (then
    (if
     (i32.eqz
      (struct.get $type3 0
       (struct.get $environment2 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function2
     (struct.get $type4 0
      (struct.get $type3 1
       (local.tee $5
        (struct.get $environment2 0
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
     (local.get $3)
     (struct.new $type2
      (ref.func $function3)
      (struct.new $environment3
       (local.get $5)
       (local.get $2)
       (local.get $3)
       (local.get $1)
       (local.get $4)
      )
     )
    )
   )
   (else
    (return_call_ref $call2
     (struct.get $type2 1
      (local.get $4)
     )
     (local.get $3)
     (struct.get $type2 0
      (local.get $4)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function3 (type $call2) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment2))
  (local $3 (ref null $type2))
  (local $4 (ref $type3))
  (local $5 (ref $environment3))
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local.set $8
   (struct.get $environment3 1
    (local.tee $5
     (ref.cast (ref $environment3)
      (local.get $0)
     )
    )
   )
  )
  (local.set $3
   (struct.new $type2
    (ref.func $function4)
    (struct.new $environment4
     (local.tee $4
      (struct.get $environment3 0
       (local.get $5)
      )
     )
     (local.tee $6
      (struct.get $environment3 2
       (local.get $5)
      )
     )
     (local.tee $7
      (struct.get $environment3 3
       (local.get $5)
      )
     )
     (struct.get $environment3 1
      (local.get $5)
     )
     (local.get $1)
     (struct.get $environment3 4
      (local.get $5)
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type3 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type4 0
    (struct.get $type3 1
     (struct.get $environment3 0
      (local.get $5)
     )
    )
   )
  )
  (block $block
   (br_if $block
    (i64.le_s
     (local.tee $1
      (i64.sub
       (local.get $8)
       (i64.const 1)
      )
     )
     (local.get $6)
    )
   )
   (if
    (i32.eqz
     (struct.get $type3 0
      (struct.get $environment2 0
       (local.get $2)
      )
     )
    )
    (then
     (unreachable)
    )
   )
   (local.set $2
    (struct.get $type4 0
     (struct.get $type3 1
      (local.tee $4
       (struct.get $environment2 0
        (local.get $2)
       )
      )
     )
    )
   )
   (local.set $3
    (struct.new $type2
     (ref.func $function3)
     (struct.new $environment3
      (local.get $4)
      (local.get $6)
      (local.get $7)
      (local.get $1)
      (ref.as_non_null
       (local.get $3)
      )
     )
    )
   )
   (if
    (i64.lt_s
     (local.get $6)
     (local.tee $1
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (then
     (block $block1
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $4
          (struct.get $environment2 0
           (local.get $2)
          )
         )
        )
       )
      )
      (local.set $3
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $4)
         (local.get $6)
         (local.get $7)
         (local.get $1)
         (ref.as_non_null
          (local.get $3)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (local.get $6)
        (local.tee $1
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (then
        (if
         (i32.eqz
          (struct.get $type3 0
           (struct.get $environment2 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type4 0
          (struct.get $type3 1
           (local.tee $4
            (struct.get $environment2 0
             (local.get $2)
            )
           )
          )
         )
        )
        (local.set $3
         (struct.new $type2
          (ref.func $function3)
          (struct.new $environment3
           (local.get $4)
           (local.get $6)
           (local.get $7)
           (local.get $1)
           (ref.as_non_null
            (local.get $3)
           )
          )
         )
        )
        (br_if $block1
         (i64.le_s
          (local.tee $1
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $6)
         )
        )
        (if
         (i32.eqz
          (struct.get $type3 0
           (struct.get $environment2 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type4 0
          (struct.get $type3 1
           (local.tee $4
            (struct.get $environment2 0
             (local.get $2)
            )
           )
          )
         )
        )
        (local.set $3
         (struct.new $type2
          (ref.func $function3)
          (struct.new $environment3
           (local.get $4)
           (local.get $6)
           (local.get $7)
           (local.get $1)
           (ref.as_non_null
            (local.get $3)
           )
          )
         )
        )
        (br_if $block1
         (i64.le_s
          (local.tee $1
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $6)
         )
        )
        (if
         (i32.eqz
          (struct.get $type3 0
           (struct.get $environment2 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type4 0
          (struct.get $type3 1
           (local.tee $4
            (struct.get $environment2 0
             (local.get $2)
            )
           )
          )
         )
        )
        (local.set $3
         (struct.new $type2
          (ref.func $function3)
          (struct.new $environment3
           (local.get $4)
           (local.get $6)
           (local.get $7)
           (local.get $1)
           (ref.as_non_null
            (local.get $3)
           )
          )
         )
        )
        (br_if $block
         (i64.le_s
          (local.tee $1
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
          (local.get $6)
         )
        )
        (if
         (i32.eqz
          (struct.get $type3 0
           (struct.get $environment2 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type4 0
          (struct.get $type3 1
           (local.tee $4
            (struct.get $environment2 0
             (local.get $2)
            )
           )
          )
         )
        )
        (local.set $3
         (struct.new $type2
          (ref.func $function3)
          (struct.new $environment3
           (local.get $4)
           (local.get $6)
           (local.get $7)
           (local.get $1)
           (ref.as_non_null
            (local.get $3)
           )
          )
         )
        )
        (if
         (i64.lt_s
          (local.get $6)
          (local.tee $1
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (then
          (if
           (i32.eqz
            (struct.get $type3 0
             (struct.get $environment2 0
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type4 0
            (struct.get $type3 1
             (local.tee $4
              (struct.get $environment2 0
               (local.get $2)
              )
             )
            )
           )
          )
          (local.set $3
           (struct.new $type2
            (ref.func $function3)
            (struct.new $environment3
             (local.get $4)
             (local.get $6)
             (local.get $7)
             (local.get $1)
             (ref.as_non_null
              (local.get $3)
             )
            )
           )
          )
          (if
           (i64.lt_s
            (local.get $6)
            (local.tee $1
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
           )
           (then
            (if
             (i32.eqz
              (struct.get $type3 0
               (struct.get $environment2 0
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type4 0
              (struct.get $type3 1
               (local.tee $4
                (struct.get $environment2 0
                 (local.get $2)
                )
               )
              )
             )
            )
            (local.set $3
             (struct.new $type2
              (ref.func $function3)
              (struct.new $environment3
               (local.get $4)
               (local.get $6)
               (local.get $7)
               (local.get $1)
               (ref.as_non_null
                (local.get $3)
               )
              )
             )
            )
            (if
             (i64.lt_s
              (local.get $6)
              (local.tee $1
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
             )
             (then
              (if
               (i32.eqz
                (struct.get $type3 0
                 (struct.get $environment2 0
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type4 0
                (struct.get $type3 1
                 (local.tee $4
                  (struct.get $environment2 0
                   (local.get $2)
                  )
                 )
                )
               )
              )
              (local.set $3
               (struct.new $type2
                (ref.func $function3)
                (struct.new $environment3
                 (local.get $4)
                 (local.get $6)
                 (local.get $7)
                 (local.get $1)
                 (ref.as_non_null
                  (local.get $3)
                 )
                )
               )
              )
              (if
               (i64.lt_s
                (local.get $6)
                (local.tee $1
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
               )
               (then
                (if
                 (i32.eqz
                  (struct.get $type3 0
                   (struct.get $environment2 0
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (return_call $function2
                 (struct.get $type4 0
                  (struct.get $type3 1
                   (local.tee $4
                    (struct.get $environment2 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                 (local.get $6)
                 (local.get $7)
                 (struct.new $type2
                  (ref.func $function3)
                  (struct.new $environment3
                   (local.get $4)
                   (local.get $6)
                   (local.get $7)
                   (local.get $1)
                   (ref.as_non_null
                    (local.get $3)
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (return_call_ref $call2
   (struct.get $type2 1
    (local.get $3)
   )
   (local.get $7)
   (struct.get $type2 0
    (local.get $3)
   )
  )
 )
 (func $function4 (type $call2) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $environment2))
  (local $5 (ref null $type2))
  (local $6 (ref $type3))
  (local $7 (ref $environment4))
  (if
   (i64.gt_s
    (local.tee $2
     (i64.sub
      (struct.get $environment4 1
       (local.tee $7
        (ref.cast (ref $environment4)
         (local.get $0)
        )
       )
      )
      (block (result i64)
       (local.set $5
        (struct.new $type2
         (ref.func $function5)
         (struct.new $environment5
          (local.tee $6
           (struct.get $environment4 0
            (local.get $7)
           )
          )
          (struct.get $environment4 4
           (local.get $7)
          )
          (local.get $1)
          (struct.get $environment4 5
           (local.get $7)
          )
         )
        )
       )
       (if
        (i32.eqz
         (struct.get $type3 0
          (local.get $6)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type4 0
         (struct.get $type3 1
          (struct.get $environment4 0
           (local.get $7)
          )
         )
        )
       )
       (local.set $3
        (struct.get $environment4 3
         (local.get $7)
        )
       )
       (i64.const 1)
      )
     )
    )
    (local.tee $1
     (struct.get $environment4 2
      (local.get $7)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (struct.get $type3 0
       (struct.get $environment2 0
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type4 0
      (struct.get $type3 1
       (local.tee $6
        (struct.get $environment2 0
         (local.get $4)
        )
       )
      )
     )
    )
    (local.set $5
     (struct.new $type2
      (ref.func $function3)
      (struct.new $environment3
       (local.get $6)
       (local.get $1)
       (local.get $3)
       (local.get $2)
       (ref.as_non_null
        (local.get $5)
       )
      )
     )
    )
    (if
     (i64.lt_s
      (local.get $1)
      (local.tee $2
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type3 0
         (struct.get $environment2 0
          (local.get $4)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (struct.get $type4 0
        (struct.get $type3 1
         (local.tee $6
          (struct.get $environment2 0
           (local.get $4)
          )
         )
        )
       )
      )
      (local.set $5
       (struct.new $type2
        (ref.func $function3)
        (struct.new $environment3
         (local.get $6)
         (local.get $1)
         (local.get $3)
         (local.get $2)
         (ref.as_non_null
          (local.get $5)
         )
        )
       )
      )
      (if
       (i64.lt_s
        (local.get $1)
        (local.tee $2
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (then
        (if
         (i32.eqz
          (struct.get $type3 0
           (struct.get $environment2 0
            (local.get $4)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (struct.get $type4 0
          (struct.get $type3 1
           (local.tee $6
            (struct.get $environment2 0
             (local.get $4)
            )
           )
          )
         )
        )
        (local.set $5
         (struct.new $type2
          (ref.func $function3)
          (struct.new $environment3
           (local.get $6)
           (local.get $1)
           (local.get $3)
           (local.get $2)
           (ref.as_non_null
            (local.get $5)
           )
          )
         )
        )
        (if
         (i64.lt_s
          (local.get $1)
          (local.tee $2
           (i64.sub
            (local.get $2)
            (i64.const 1)
           )
          )
         )
         (then
          (if
           (i32.eqz
            (struct.get $type3 0
             (struct.get $environment2 0
              (local.get $4)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $4
           (struct.get $type4 0
            (struct.get $type3 1
             (local.tee $6
              (struct.get $environment2 0
               (local.get $4)
              )
             )
            )
           )
          )
          (local.set $5
           (struct.new $type2
            (ref.func $function3)
            (struct.new $environment3
             (local.get $6)
             (local.get $1)
             (local.get $3)
             (local.get $2)
             (ref.as_non_null
              (local.get $5)
             )
            )
           )
          )
          (if
           (i64.lt_s
            (local.get $1)
            (local.tee $2
             (i64.sub
              (local.get $2)
              (i64.const 1)
             )
            )
           )
           (then
            (if
             (i32.eqz
              (struct.get $type3 0
               (struct.get $environment2 0
                (local.get $4)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $4
             (struct.get $type4 0
              (struct.get $type3 1
               (local.tee $6
                (struct.get $environment2 0
                 (local.get $4)
                )
               )
              )
             )
            )
            (local.set $5
             (struct.new $type2
              (ref.func $function3)
              (struct.new $environment3
               (local.get $6)
               (local.get $1)
               (local.get $3)
               (local.get $2)
               (ref.as_non_null
                (local.get $5)
               )
              )
             )
            )
            (if
             (i64.lt_s
              (local.get $1)
              (local.tee $2
               (i64.sub
                (local.get $2)
                (i64.const 1)
               )
              )
             )
             (then
              (if
               (i32.eqz
                (struct.get $type3 0
                 (struct.get $environment2 0
                  (local.get $4)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $4
               (struct.get $type4 0
                (struct.get $type3 1
                 (local.tee $6
                  (struct.get $environment2 0
                   (local.get $4)
                  )
                 )
                )
               )
              )
              (local.set $5
               (struct.new $type2
                (ref.func $function3)
                (struct.new $environment3
                 (local.get $6)
                 (local.get $1)
                 (local.get $3)
                 (local.get $2)
                 (ref.as_non_null
                  (local.get $5)
                 )
                )
               )
              )
              (if
               (i64.lt_s
                (local.get $1)
                (local.tee $2
                 (i64.sub
                  (local.get $2)
                  (i64.const 1)
                 )
                )
               )
               (then
                (if
                 (i32.eqz
                  (struct.get $type3 0
                   (struct.get $environment2 0
                    (local.get $4)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $4
                 (struct.get $type4 0
                  (struct.get $type3 1
                   (local.tee $6
                    (struct.get $environment2 0
                     (local.get $4)
                    )
                   )
                  )
                 )
                )
                (local.set $5
                 (struct.new $type2
                  (ref.func $function3)
                  (struct.new $environment3
                   (local.get $6)
                   (local.get $1)
                   (local.get $3)
                   (local.get $2)
                   (ref.as_non_null
                    (local.get $5)
                   )
                  )
                 )
                )
                (if
                 (i64.lt_s
                  (local.get $1)
                  (local.tee $2
                   (i64.sub
                    (local.get $2)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (if
                   (i32.eqz
                    (struct.get $type3 0
                     (struct.get $environment2 0
                      (local.get $4)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $4
                   (struct.get $type4 0
                    (struct.get $type3 1
                     (local.tee $6
                      (struct.get $environment2 0
                       (local.get $4)
                      )
                     )
                    )
                   )
                  )
                  (local.set $5
                   (struct.new $type2
                    (ref.func $function3)
                    (struct.new $environment3
                     (local.get $6)
                     (local.get $1)
                     (local.get $3)
                     (local.get $2)
                     (ref.as_non_null
                      (local.get $5)
                     )
                    )
                   )
                  )
                  (if
                   (i64.lt_s
                    (local.get $1)
                    (local.tee $2
                     (i64.sub
                      (local.get $2)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (if
                     (i32.eqz
                      (struct.get $type3 0
                       (struct.get $environment2 0
                        (local.get $4)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $4
                     (struct.get $type4 0
                      (struct.get $type3 1
                       (local.tee $6
                        (struct.get $environment2 0
                         (local.get $4)
                        )
                       )
                      )
                     )
                    )
                    (local.set $5
                     (struct.new $type2
                      (ref.func $function3)
                      (struct.new $environment3
                       (local.get $6)
                       (local.get $1)
                       (local.get $3)
                       (local.get $2)
                       (ref.as_non_null
                        (local.get $5)
                       )
                      )
                     )
                    )
                    (if
                     (i64.lt_s
                      (local.get $1)
                      (local.tee $2
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (if
                       (i32.eqz
                        (struct.get $type3 0
                         (struct.get $environment2 0
                          (local.get $4)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (return_call $function2
                       (struct.get $type4 0
                        (struct.get $type3 1
                         (local.tee $6
                          (struct.get $environment2 0
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (i64.sub
                        (local.get $2)
                        (i64.const 1)
                       )
                       (local.get $1)
                       (local.get $3)
                       (struct.new $type2
                        (ref.func $function3)
                        (struct.new $environment3
                         (local.get $6)
                         (local.get $1)
                         (local.get $3)
                         (local.get $2)
                         (ref.as_non_null
                          (local.get $5)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (return_call_ref $call2
   (struct.get $type2 1
    (local.get $5)
   )
   (local.get $3)
   (struct.get $type2 0
    (local.get $5)
   )
  )
 )
 (func $function5 (type $call2) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $environment2))
  (local $5 (ref $type3))
  (local $6 (ref null $type2))
  (local $7 (ref $environment5))
  (local $8 (ref $type2))
  (local $9 (ref $type2))
  (local.set $2
   (struct.get $environment5 1
    (local.tee $7
     (ref.cast (ref $environment5)
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type3 0
     (struct.get $environment5 0
      (local.get $7)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type4 0
    (struct.get $type3 1
     (struct.get $environment5 0
      (local.get $7)
     )
    )
   )
  )
  (local.set $8
   (struct.get $environment5 3
    (local.get $7)
   )
  )
  (if
   (i64.lt_s
    (local.tee $3
     (struct.get $environment5 2
      (local.get $7)
     )
    )
    (local.get $2)
   )
   (then
    (block $block
     (if
      (i32.eqz
       (struct.get $type3 0
        (struct.get $environment2 0
         (local.get $4)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $4
      (struct.get $type4 0
       (struct.get $type3 1
        (local.tee $5
         (struct.get $environment2 0
          (local.get $4)
         )
        )
       )
      )
     )
     (local.set $6
      (struct.new $type2
       (ref.func $function3)
       (struct.new $environment3
        (local.get $5)
        (local.get $3)
        (local.get $1)
        (local.get $2)
        (local.get $8)
       )
      )
     )
     (if
      (i64.lt_s
       (local.get $3)
       (local.tee $2
        (i64.sub
         (local.get $2)
         (i64.const 1)
        )
       )
      )
      (then
       (if
        (i32.eqz
         (struct.get $type3 0
          (struct.get $environment2 0
           (local.get $4)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type4 0
         (struct.get $type3 1
          (local.tee $5
           (struct.get $environment2 0
            (local.get $4)
           )
          )
         )
        )
       )
       (local.set $6
        (struct.new $type2
         (ref.func $function3)
         (struct.new $environment3
          (local.get $5)
          (local.get $3)
          (local.get $1)
          (local.get $2)
          (ref.as_non_null
           (local.get $6)
          )
         )
        )
       )
       (if
        (i64.lt_s
         (local.get $3)
         (local.tee $2
          (i64.sub
           (local.get $2)
           (i64.const 1)
          )
         )
        )
        (then
         (if
          (i32.eqz
           (struct.get $type3 0
            (struct.get $environment2 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type4 0
           (struct.get $type3 1
            (local.tee $5
             (struct.get $environment2 0
              (local.get $4)
             )
            )
           )
          )
         )
         (local.set $6
          (struct.new $type2
           (ref.func $function3)
           (struct.new $environment3
            (local.get $5)
            (local.get $3)
            (local.get $1)
            (local.get $2)
            (ref.as_non_null
             (local.get $6)
            )
           )
          )
         )
         (br_if $block
          (i64.le_s
           (local.tee $2
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
           )
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type3 0
            (struct.get $environment2 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type4 0
           (struct.get $type3 1
            (local.tee $5
             (struct.get $environment2 0
              (local.get $4)
             )
            )
           )
          )
         )
         (local.set $6
          (struct.new $type2
           (ref.func $function3)
           (struct.new $environment3
            (local.get $5)
            (local.get $3)
            (local.get $1)
            (local.get $2)
            (ref.as_non_null
             (local.get $6)
            )
           )
          )
         )
         (br_if $block
          (i64.le_s
           (local.tee $2
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
           )
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type3 0
            (struct.get $environment2 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type4 0
           (struct.get $type3 1
            (local.tee $5
             (struct.get $environment2 0
              (local.get $4)
             )
            )
           )
          )
         )
         (local.set $6
          (struct.new $type2
           (ref.func $function3)
           (struct.new $environment3
            (local.get $5)
            (local.get $3)
            (local.get $1)
            (local.get $2)
            (ref.as_non_null
             (local.get $6)
            )
           )
          )
         )
         (br_if $block
          (i64.le_s
           (local.tee $2
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
           )
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type3 0
            (struct.get $environment2 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type4 0
           (struct.get $type3 1
            (local.tee $5
             (struct.get $environment2 0
              (local.get $4)
             )
            )
           )
          )
         )
         (local.set $6
          (struct.new $type2
           (ref.func $function3)
           (struct.new $environment3
            (local.get $5)
            (local.get $3)
            (local.get $1)
            (local.get $2)
            (ref.as_non_null
             (local.get $6)
            )
           )
          )
         )
         (br_if $block
          (i64.le_s
           (local.tee $2
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
           )
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type3 0
            (struct.get $environment2 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type4 0
           (struct.get $type3 1
            (local.tee $5
             (struct.get $environment2 0
              (local.get $4)
             )
            )
           )
          )
         )
         (local.set $6
          (struct.new $type2
           (ref.func $function3)
           (struct.new $environment3
            (local.get $5)
            (local.get $3)
            (local.get $1)
            (local.get $2)
            (ref.as_non_null
             (local.get $6)
            )
           )
          )
         )
         (br_if $block
          (i64.le_s
           (local.tee $2
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
           )
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type3 0
            (struct.get $environment2 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type4 0
           (struct.get $type3 1
            (local.tee $5
             (struct.get $environment2 0
              (local.get $4)
             )
            )
           )
          )
         )
         (local.set $6
          (struct.new $type2
           (ref.func $function3)
           (struct.new $environment3
            (local.get $5)
            (local.get $3)
            (local.get $1)
            (local.get $2)
            (ref.as_non_null
             (local.get $6)
            )
           )
          )
         )
         (br_if $block
          (i64.le_s
           (local.tee $2
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
           )
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type3 0
            (struct.get $environment2 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type4 0
           (struct.get $type3 1
            (local.tee $5
             (struct.get $environment2 0
              (local.get $4)
             )
            )
           )
          )
         )
         (local.set $9
          (struct.new $type2
           (ref.func $function3)
           (struct.new $environment3
            (local.get $5)
            (local.get $3)
            (local.get $1)
            (local.get $2)
            (ref.as_non_null
             (local.get $6)
            )
           )
          )
         )
         (if
          (i64.lt_s
           (local.get $3)
           (local.tee $2
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
           )
          )
          (then
           (if
            (i32.eqz
             (struct.get $type3 0
              (struct.get $environment2 0
               (local.get $4)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (return_call $function2
            (struct.get $type4 0
             (struct.get $type3 1
              (local.tee $5
               (struct.get $environment2 0
                (local.get $4)
               )
              )
             )
            )
            (i64.sub
             (local.get $2)
             (i64.const 1)
            )
            (local.get $3)
            (local.get $1)
            (struct.new $type2
             (ref.func $function3)
             (struct.new $environment3
              (local.get $5)
              (local.get $3)
              (local.get $1)
              (local.get $2)
              (local.get $9)
             )
            )
           )
          )
          (else
           (return_call_ref $call2
            (struct.get $type2 1
             (local.get $9)
            )
            (local.get $1)
            (struct.get $type2 0
             (local.get $9)
            )
           )
          )
         )
         (unreachable)
        )
       )
      )
     )
    )
   )
   (else
    (return_call_ref $call2
     (struct.get $type2 1
      (local.get $8)
     )
     (local.get $1)
     (struct.get $type2 0
      (local.get $8)
     )
    )
   )
  )
  (return_call_ref $call2
   (struct.get $type2 1
    (local.get $6)
   )
   (local.get $1)
   (struct.get $type2 0
    (local.get $6)
   )
  )
 )
 (func $function6 (type $call2) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type5))
  (local $3 (ref $type0))
  (struct.set $type5 1
   (local.tee $2
    (struct.new_default $type5)
   )
   (struct.new $type0
    (ref.func $function7)
    (struct.new $environment7
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type5 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type5 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type5 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type0 0
    (local.get $3)
   )
  )
 )
 (func $function7 (type $call0) (param $0 (ref null $environment7)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment7 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready13)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready21)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global21)
     )
    )
    (local.set $2
     (call $function0
      (call $foreign0
       (global.get $global13)
      )
      (block (result i64)
       (drop
        (struct.get $environment7 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready14)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready21)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type0 1
         (global.get $global21)
        )
       )
       (call $foreign0
        (global.get $global14)
       )
      )
      (block (result i64)
       (drop
        (struct.get $environment7 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready15)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready21)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type0 1
         (global.get $global21)
        )
       )
       (local.set $scratch
        (call $foreign0
         (global.get $global15)
        )
       )
       (if
        (i32.eqz
         (global.get $ready0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global0)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type5 0
       (struct.get $environment7 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function7
     (struct.get $type0 1
      (struct.get $type5 1
       (struct.get $environment7 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function8 (type $call0) (param $0 (ref null $environment7)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type5))
  (local $2 (ref $type0))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready16)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type2 1
    (global.get $global16)
   )
  )
  (struct.set $type5 1
   (local.tee $1
    (struct.new_default $type5)
   )
   (struct.new $type0
    (ref.func $function7)
    (struct.new $environment7
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type5 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type5 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type5 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type0 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global21
   (struct.new $type0
    (ref.func $function8)
    (ref.null none)
   )
  )
  (global.set $ready21
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type1)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global13
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready13
   (i32.const 1)
  )
  (global.set $global14
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $ready14
   (i32.const 1)
  )
  (global.set $global15
   (call $foreign1
    (i32.const 2)
   )
  )
  (global.set $ready15
   (i32.const 1)
  )
  (global.set $global16
   (struct.new $type2
    (ref.func $function6)
    (ref.null none)
   )
  )
  (global.set $ready16
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

