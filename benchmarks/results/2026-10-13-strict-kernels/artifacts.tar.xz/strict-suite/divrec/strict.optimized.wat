(module
 (rec
  (type $call8 (func (param (ref $environment7) (ref null $type1) i64) (result i64)))
  (type $call0 (func (param (ref null $type1)) (result (ref null $type1))))
  (type $2 (func (param (ref null $type1)) (result (ref null $type1))))
  (type $type8 (struct (field (ref $environment7))))
  (type $environment3 (struct (field i64) (field (ref $type7))))
  (type $type9 (struct (field (mut i32)) (field (mut (ref null $type8)))))
  (type $environment7 (struct (field (ref $type9))))
  (type $call5 (func (param i64) (result i64)))
  (type $type6 (struct (field (ref $call6)) (field (ref struct))))
  (type $type7 (struct (field (mut i32)) (field (mut (ref null $type6)))))
  (type $environment1 (struct (field (ref $type7))))
  (type $call6 (func (param (ref struct) i64 (ref null $type1)) (result (ref null $type1))))
  (type $type5 (struct))
  (type $type1 (struct (field nullref) (field (ref null $type1))))
  (type $type4 (struct))
  (type $type3 (struct))
  (type $type0 (struct))
 )
 (type $17 (func (param i32) (result i64)))
 (type $18 (func (param i64) (result i64)))
 (type $19 (func))
 (import "benchmark" "input_i64" (func $foreign0 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global13 (mut (ref null $type0)) (ref.null none))
 (global $ready13 (mut i32) (i32.const 0))
 (global $global15 (mut (ref null $type3)) (ref.null none))
 (global $ready15 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type4)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global11 (mut (ref null $type0)) (ref.null none))
 (global $ready11 (mut i32) (i32.const 0))
 (global $global5 (mut (ref null $type1)) (ref.null none))
 (global $ready5 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type5)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function1 (type $call6) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (if (result (ref null $type1))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type7 0
       (struct.get $environment1 0
        (ref.cast (ref $environment1)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function1
     (struct.get $type6 1
      (struct.get $type7 1
       (struct.get $environment1 0
        (ref.cast (ref $environment1)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type1
      (ref.null none)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function2 (type $call5) (param $0 i64) (result i64)
  (local $1 (ref null $type1))
  (local $2 (ref $environment7))
  (local $3 (ref $type7))
  (local $4 (ref $type9))
  (local $5 (ref $type6))
  (struct.set $type7 1
   (local.tee $3
    (struct.new_default $type7)
   )
   (struct.new $type6
    (ref.func $function3)
    (struct.new $environment3
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (struct.set $type7 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type7 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call_ref $call6
    (struct.get $type6 1
     (local.tee $5
      (ref.as_non_null
       (struct.get $type7 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (ref.null none)
    (struct.get $type6 0
     (local.get $5)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready15)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global15)
   )
  )
  (struct.set $type9 1
   (local.tee $4
    (struct.new_default $type9)
   )
   (struct.new $type8
    (struct.new $environment7
     (local.get $4)
    )
   )
  )
  (struct.set $type9 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type9 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type8 0
    (struct.get $type9 1
     (local.get $4)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $1
     (struct.get $type1 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type9 0
       (struct.get $environment7 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type8 0
      (struct.get $type9 1
       (struct.get $environment7 0
        (local.get $2)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i64.const 1)
     )
     (else
      (local.set $1
       (struct.get $type1 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type9 0
         (struct.get $environment7 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type8 0
        (struct.get $type9 1
         (struct.get $environment7 0
          (local.get $2)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i64.const 2)
       )
       (else
        (local.set $1
         (struct.get $type1 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type9 0
           (struct.get $environment7 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type8 0
          (struct.get $type9 1
           (struct.get $environment7 0
            (local.get $2)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $1)
         )
         (then
          (i64.const 3)
         )
         (else
          (local.set $1
           (struct.get $type1 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type9 0
             (struct.get $environment7 0
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type8 0
            (struct.get $type9 1
             (struct.get $environment7 0
              (local.get $2)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $1)
           )
           (then
            (i64.const 4)
           )
           (else
            (local.set $1
             (struct.get $type1 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (struct.get $type9 0
               (struct.get $environment7 0
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type8 0
              (struct.get $type9 1
               (struct.get $environment7 0
                (local.get $2)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i64.const 5)
             )
             (else
              (local.set $1
               (struct.get $type1 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (struct.get $type9 0
                 (struct.get $environment7 0
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type8 0
                (struct.get $type9 1
                 (struct.get $environment7 0
                  (local.get $2)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $1)
               )
               (then
                (i64.const 6)
               )
               (else
                (local.set $1
                 (struct.get $type1 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type9 0
                   (struct.get $environment7 0
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.get $type8 0
                  (struct.get $type9 1
                   (struct.get $environment7 0
                    (local.get $2)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (local.set $1
                   (struct.get $type1 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type9 0
                     (struct.get $environment7 0
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type8 0
                    (struct.get $type9 1
                     (struct.get $environment7 0
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (local.set $1
                     (struct.get $type1 1
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type9 0
                       (struct.get $environment7 0
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (return_call $function7
                     (struct.get $type8 0
                      (struct.get $type9 1
                       (struct.get $environment7 0
                        (local.get $2)
                       )
                      )
                     )
                     (local.get $1)
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function3 (type $call6) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (local $3 (ref null $type1))
  (local $4 nullref)
  (local $scratch (ref null $type1))
  (if (result (ref null $type1))
   (i64.gt_s
    (struct.get $environment3 0
     (ref.cast (ref $environment3)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready11)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global11)
     )
    )
    (local.set $2
     (if (result (ref null $type1))
      (ref.is_null
       (local.tee $3
        (global.get $global5)
       )
      )
      (then
       (ref.null none)
      )
      (else
       (struct.new $type1
        (struct.get $type1 0
         (local.get $3)
        )
        (block (result (ref null $type1))
         (if
          (i32.eqz
           (global.get $ready13)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global13)
          )
         )
         (local.set $3
          (struct.get $type1 1
           (struct.get $type1 1
            (local.get $3)
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready11)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global11)
          )
         )
         (if (result (ref null $type1))
          (ref.is_null
           (local.get $3)
          )
          (then
           (ref.null none)
          )
          (else
           (struct.new $type1
            (struct.get $type1 0
             (local.get $3)
            )
            (block (result (ref null $type1))
             (if
              (i32.eqz
               (global.get $ready13)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global13)
              )
             )
             (local.set $3
              (struct.get $type1 1
               (struct.get $type1 1
                (local.get $3)
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready11)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global11)
              )
             )
             (if (result (ref null $type1))
              (ref.is_null
               (local.get $3)
              )
              (then
               (ref.null none)
              )
              (else
               (struct.new $type1
                (struct.get $type1 0
                 (local.get $3)
                )
                (block (result (ref null $type1))
                 (if
                  (i32.eqz
                   (global.get $ready13)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global13)
                  )
                 )
                 (local.set $3
                  (struct.get $type1 1
                   (struct.get $type1 1
                    (local.get $3)
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready11)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global11)
                  )
                 )
                 (if (result (ref null $type1))
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (ref.null none)
                  )
                  (else
                   (struct.new $type1
                    (struct.get $type1 0
                     (local.get $3)
                    )
                    (block (result (ref null $type1))
                     (if
                      (i32.eqz
                       (global.get $ready13)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global13)
                      )
                     )
                     (local.set $3
                      (struct.get $type1 1
                       (struct.get $type1 1
                        (local.get $3)
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready11)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global11)
                      )
                     )
                     (if (result (ref null $type1))
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (struct.new $type1
                        (struct.get $type1 0
                         (local.get $3)
                        )
                        (block (result (ref null $type1))
                         (if
                          (i32.eqz
                           (global.get $ready13)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global13)
                          )
                         )
                         (local.set $3
                          (struct.get $type1 1
                           (struct.get $type1 1
                            (local.get $3)
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready11)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global11)
                          )
                         )
                         (if (result (ref null $type1))
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (struct.new $type1
                            (struct.get $type1 0
                             (local.get $3)
                            )
                            (block (result (ref null $type1))
                             (if
                              (i32.eqz
                               (global.get $ready13)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global13)
                              )
                             )
                             (local.set $3
                              (struct.get $type1 1
                               (struct.get $type1 1
                                (local.get $3)
                               )
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready11)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global11)
                              )
                             )
                             (if (result (ref null $type1))
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (ref.null none)
                              )
                              (else
                               (struct.new $type1
                                (struct.get $type1 0
                                 (local.get $3)
                                )
                                (block (result (ref null $type1))
                                 (if
                                  (i32.eqz
                                   (global.get $ready13)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global13)
                                  )
                                 )
                                 (local.set $3
                                  (struct.get $type1 1
                                   (struct.get $type1 1
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready11)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global11)
                                  )
                                 )
                                 (if (result (ref null $type1))
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (ref.null none)
                                  )
                                  (else
                                   (struct.new $type1
                                    (struct.get $type1 0
                                     (local.get $3)
                                    )
                                    (block (result (ref null $type1))
                                     (if
                                      (i32.eqz
                                       (global.get $ready13)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global13)
                                      )
                                     )
                                     (local.set $3
                                      (struct.get $type1 1
                                       (struct.get $type1 1
                                        (local.get $3)
                                       )
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready11)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global11)
                                      )
                                     )
                                     (if (result (ref null $type1))
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                      (then
                                       (ref.null none)
                                      )
                                      (else
                                       (struct.new $type1
                                        (struct.get $type1 0
                                         (local.get $3)
                                        )
                                        (block (result (ref null $type1))
                                         (if
                                          (i32.eqz
                                           (global.get $ready13)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global13)
                                          )
                                         )
                                         (local.set $3
                                          (struct.get $type1 1
                                           (struct.get $type1 1
                                            (local.get $3)
                                           )
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready11)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global11)
                                          )
                                         )
                                         (if (result (ref null $type1))
                                          (ref.is_null
                                           (local.get $3)
                                          )
                                          (then
                                           (ref.null none)
                                          )
                                          (else
                                           (struct.new $type1
                                            (struct.get $type1 0
                                             (local.get $3)
                                            )
                                            (block (result (ref null $type1))
                                             (if
                                              (i32.eqz
                                               (global.get $ready13)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global13)
                                              )
                                             )
                                             (call $function4
                                              (block (result (ref null $type1))
                                               (local.set $scratch
                                                (call $function5
                                                 (local.get $3)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready11)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global11)
                                                )
                                               )
                                               (local.get $scratch)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type7 0
       (struct.get $environment3 1
        (ref.cast (ref $environment3)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function3
     (struct.get $type6 1
      (struct.get $type7 1
       (struct.get $environment3 1
        (ref.cast (ref $environment3)
         (local.get $0)
        )
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function4 (type $2) (param $0 (ref null $type1)) (result (ref null $type1))
  (local $1 nullref)
  (local $scratch (ref null $type1))
  (if (result (ref null $type1))
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (struct.new $type1
     (struct.get $type1 0
      (local.get $0)
     )
     (block (result (ref null $type1))
      (if
       (i32.eqz
        (global.get $ready13)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global13)
       )
      )
      (call $function4
       (block (result (ref null $type1))
        (local.set $scratch
         (call $function5
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready11)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global11)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function5 (type $call0) (param $0 (ref null $type1)) (result (ref null $type1))
  (struct.get $type1 1
   (struct.get $type1 1
    (local.get $0)
   )
  )
 )
 (func $function7 (type $call8) (param $0 (ref $environment7)) (param $1 (ref null $type1)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type1 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type9 0
       (struct.get $environment7 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function7
     (struct.get $type8 0
      (struct.get $type9 1
       (struct.get $environment7 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready6)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global6)
   )
  )
  (return_call $function2
   (local.get $0)
  )
 )
 (func $main
  (local $0 (ref $type7))
  (local $1 (ref $type6))
  (local $2 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global13
   (struct.new_default $type0)
  )
  (global.set $ready13
   (i32.const 1)
  )
  (global.set $global15
   (struct.new_default $type3)
  )
  (global.set $ready15
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type4)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global11
   (struct.new_default $type0)
  )
  (global.set $ready11
   (i32.const 1)
  )
  (local.set $2
   (call $foreign0
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (struct.set $type7 1
   (local.tee $0
    (struct.new_default $type7)
   )
   (struct.new $type6
    (ref.func $function1)
    (struct.new $environment1
     (local.get $0)
    )
   )
  )
  (struct.set $type7 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type7 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global5
   (call_ref $call6
    (struct.get $type6 1
     (local.tee $1
      (ref.as_non_null
       (struct.get $type7 1
        (local.get $0)
       )
      )
     )
    )
    (local.get $2)
    (ref.null none)
    (struct.get $type6 0
     (local.get $1)
    )
   )
  )
  (global.set $ready5
   (i32.const 1)
  )
  (global.set $global6
   (struct.new_default $type5)
  )
  (global.set $ready6
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

