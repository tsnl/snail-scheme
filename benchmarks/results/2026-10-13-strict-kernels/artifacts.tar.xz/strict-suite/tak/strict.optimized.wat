(module
 (rec
  (type $type3 (struct (field (mut i32)) (field (mut (ref null $type0)))))
  (type $environment2 (struct (field i64) (field (ref $type3))))
  (type $call0 (func (param (ref null $environment2) i64 i64) (result i64)))
  (type $call1 (func (param i64 i64 i64) (result i64)))
  (type $type2 (struct))
  (type $type1 (struct))
  (type $type0 (struct (field (ref $call0)) (field (ref null $environment2))))
 )
 (type $7 (func (param i64) (result i64)))
 (type $8 (func (param i32) (result i64)))
 (type $9 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global12 (mut (ref null $type0)) (ref.null none))
 (global $ready12 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type1)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global4 (mut i64) (i64.const 0))
 (global $ready4 (mut i32) (i32.const 0))
 (global $global5 (mut i64) (i64.const 0))
 (global $ready5 (mut i32) (i32.const 0))
 (global $global6 (mut i64) (i64.const 0))
 (global $ready6 (mut i32) (i32.const 0))
 (global $global7 (mut (ref null $type2)) (ref.null none))
 (global $ready7 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function0 (type $call1) (param $0 i64) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global0)
     )
    )
    (return_call $function0
     (call $function0
      (i64.sub
       (local.get $0)
       (i64.const 1)
      )
      (local.get $1)
      (local.get $2)
     )
     (block (result i64)
      (if
       (i32.eqz
        (global.get $ready0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global0)
       )
      )
      (call $function0
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
       (local.get $2)
       (local.get $0)
      )
     )
     (block (result i64)
      (if
       (i32.eqz
        (global.get $ready0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global0)
       )
      )
      (local.set $scratch
       (call $function0
        (i64.sub
         (local.get $2)
         (i64.const 1)
        )
        (local.get $0)
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready0)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global0)
       )
      )
      (local.get $scratch)
     )
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function2 (type $call0) (param $0 (ref null $environment2)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 i64)
  (local $4 i64)
  (local $scratch i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment2 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready12)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type0 1
      (global.get $global12)
     )
    )
    (local.set $2
     (call $function0
      (call $foreign0
       (global.get $global4)
      )
      (block (result i64)
       (drop
        (struct.get $environment2 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready5)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready12)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type0 1
         (global.get $global12)
        )
       )
       (call $foreign0
        (global.get $global5)
       )
      )
      (block (result i64)
       (drop
        (struct.get $environment2 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready6)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready12)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type0 1
         (global.get $global12)
        )
       )
       (local.set $scratch
        (call $foreign0
         (global.get $global6)
        )
       )
       (if
        (i32.eqz
         (global.get $ready0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global0)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type3 0
       (struct.get $environment2 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function2
     (struct.get $type0 1
      (struct.get $type3 1
       (struct.get $environment2 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function3 (type $call0) (param $0 (ref null $environment2)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type3))
  (local $2 (ref $type0))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready7)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global7)
   )
  )
  (struct.set $type3 1
   (local.tee $1
    (struct.new_default $type3)
   )
   (struct.new $type0
    (ref.func $function2)
    (struct.new $environment2
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type3 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type3 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call0
   (struct.get $type0 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type3 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type0 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global12
   (struct.new $type0
    (ref.func $function3)
    (ref.null none)
   )
  )
  (global.set $ready12
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type1)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (global.set $global4
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready4
   (i32.const 1)
  )
  (global.set $global5
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $ready5
   (i32.const 1)
  )
  (global.set $global6
   (call $foreign1
    (i32.const 2)
   )
  )
  (global.set $ready6
   (i32.const 1)
  )
  (global.set $global7
   (struct.new_default $type2)
  )
  (global.set $ready7
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

