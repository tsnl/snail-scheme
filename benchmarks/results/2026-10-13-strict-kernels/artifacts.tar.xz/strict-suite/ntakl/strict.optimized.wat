(module
 (rec
  (type $call8 (func (param (ref $environment7) (ref null $type1) i64) (result i64)))
  (type $call5 (func (param (ref null $type1) (ref null $type1)) (result i32)))
  (type $call4 (func (param (ref null $type1) (ref null $type1) (ref null $type1)) (result (ref null $type1))))
  (type $type8 (struct (field (ref $environment7))))
  (type $call2 (func (param (ref null $environment2) i64 (ref null $type1)) (result (ref null $type1))))
  (type $environment2 (struct (field i64) (field (ref $type7))))
  (type $type9 (struct (field (mut i32)) (field (mut (ref null $type8)))))
  (type $type7 (struct (field (mut i32)) (field (mut (ref null $type2)))))
  (type $environment7 (struct (field (ref $type9))))
  (type $call6 (func (param i64) (result i64)))
  (type $call3 (func (param i64) (result (ref null $type1))))
  (type $type6 (struct))
  (type $type1 (struct (field (ref null $type1))))
  (type $type5 (struct))
  (type $type4 (struct))
  (type $type3 (struct))
  (type $type2 (struct (field (ref $call2)) (field (ref null $environment2))))
  (type $type0 (struct))
 )
 (type $18 (func (result i32)))
 (type $19 (func (param i32) (result i64)))
 (type $20 (func (param i64) (result i64)))
 (type $21 (func))
 (import "benchmark" "barrier" (func $foreign0 (result i32)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global23 (mut (ref null $type0)) (ref.null none))
 (global $ready23 (mut i32) (i32.const 0))
 (global $global13 (mut (ref null $type2)) (ref.null none))
 (global $ready13 (mut i32) (i32.const 0))
 (global $global0 (mut (ref null $type3)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global16 (mut (ref null $type4)) (ref.null none))
 (global $ready16 (mut i32) (i32.const 0))
 (global $global20 (mut (ref null $type5)) (ref.null none))
 (global $ready20 (mut i32) (i32.const 0))
 (global $global5 (mut (ref null $type1)) (ref.null none))
 (global $ready5 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type1)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (global $global7 (mut (ref null $type1)) (ref.null none))
 (global $ready7 (mut i32) (i32.const 0))
 (global $global8 (mut (ref null $type6)) (ref.null none))
 (global $ready8 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function0 (type $call3) (param $0 i64) (result (ref null $type1))
  (if (result (ref null $type1))
   (i64.eqz
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready0)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global0)
     )
    )
    (struct.new $type1
     (call $function0
      (i64.sub
       (local.get $0)
       (i64.const 1)
      )
     )
    )
   )
  )
 )
 (func $function1 (type $call6) (param $0 i64) (result i64)
  (local $1 (ref null $type1))
  (local $2 (ref $environment7))
  (local $3 (ref $type7))
  (local $4 (ref $type9))
  (local $5 (ref $type2))
  (struct.set $type7 1
   (local.tee $3
    (struct.new_default $type7)
   )
   (struct.new $type2
    (ref.func $function2)
    (struct.new $environment2
     (local.get $0)
     (local.get $3)
    )
   )
  )
  (struct.set $type7 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type7 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call_ref $call2
    (struct.get $type2 1
     (local.tee $5
      (ref.as_non_null
       (struct.get $type7 1
        (local.get $3)
       )
      )
     )
    )
    (i64.const 0)
    (ref.null none)
    (struct.get $type2 0
     (local.get $5)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready23)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global23)
   )
  )
  (struct.set $type9 1
   (local.tee $4
    (struct.new_default $type9)
   )
   (struct.new $type8
    (struct.new $environment7
     (local.get $4)
    )
   )
  )
  (struct.set $type9 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type9 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type8 0
    (struct.get $type9 1
     (local.get $4)
    )
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i64.const 0)
   )
   (else
    (local.set $1
     (struct.get $type1 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type9 0
       (struct.get $environment7 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type8 0
      (struct.get $type9 1
       (struct.get $environment7 0
        (local.get $2)
       )
      )
     )
    )
    (if (result i64)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i64.const 1)
     )
     (else
      (local.set $1
       (struct.get $type1 0
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type9 0
         (struct.get $environment7 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type8 0
        (struct.get $type9 1
         (struct.get $environment7 0
          (local.get $2)
         )
        )
       )
      )
      (if (result i64)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i64.const 2)
       )
       (else
        (local.set $1
         (struct.get $type1 0
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type9 0
           (struct.get $environment7 0
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type8 0
          (struct.get $type9 1
           (struct.get $environment7 0
            (local.get $2)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $1)
         )
         (then
          (i64.const 3)
         )
         (else
          (local.set $1
           (struct.get $type1 0
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type9 0
             (struct.get $environment7 0
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.get $type8 0
            (struct.get $type9 1
             (struct.get $environment7 0
              (local.get $2)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $1)
           )
           (then
            (i64.const 4)
           )
           (else
            (local.set $1
             (struct.get $type1 0
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (struct.get $type9 0
               (struct.get $environment7 0
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type8 0
              (struct.get $type9 1
               (struct.get $environment7 0
                (local.get $2)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i64.const 5)
             )
             (else
              (local.set $1
               (struct.get $type1 0
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (struct.get $type9 0
                 (struct.get $environment7 0
                  (local.get $2)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.get $type8 0
                (struct.get $type9 1
                 (struct.get $environment7 0
                  (local.get $2)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $1)
               )
               (then
                (i64.const 6)
               )
               (else
                (local.set $1
                 (struct.get $type1 0
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type9 0
                   (struct.get $environment7 0
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.get $type8 0
                  (struct.get $type9 1
                   (struct.get $environment7 0
                    (local.get $2)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (local.set $1
                   (struct.get $type1 0
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type9 0
                     (struct.get $environment7 0
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type8 0
                    (struct.get $type9 1
                     (struct.get $environment7 0
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (local.set $1
                     (struct.get $type1 0
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type9 0
                       (struct.get $environment7 0
                        (local.get $2)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (return_call $function7
                     (struct.get $type8 0
                      (struct.get $type9 1
                       (struct.get $environment7 0
                        (local.get $2)
                       )
                      )
                     )
                     (local.get $1)
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function2 (type $call2) (param $0 (ref null $environment2)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (local $3 (ref null $type1))
  (local $4 (ref null $type1))
  (local $5 (ref null $type1))
  (local $scratch (ref null $type1))
  (if (result (ref null $type1))
   (i64.gt_s
    (struct.get $environment2 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready13)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type2 1
      (global.get $global13)
     )
    )
    (local.set $2
     (call $function4
      (global.get $global5)
      (block (result (ref null $type1))
       (if
        (i32.eqz
         (call $foreign0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $environment2 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready6)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready13)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type2 1
         (global.get $global13)
        )
       )
       (global.get $global6)
      )
      (block (result (ref null $type1))
       (if
        (i32.eqz
         (call $foreign0)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $environment2 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready7)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready13)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type2 1
         (global.get $global13)
        )
       )
       (local.set $scratch
        (global.get $global7)
       )
       (if
        (i32.eqz
         (call $foreign0)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.eqz
         (global.get $ready16)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global16)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type7 0
       (struct.get $environment2 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function2
     (struct.get $type2 1
      (struct.get $type7 1
       (struct.get $environment2 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function3 (type $call2) (param $0 (ref null $environment2)) (param $1 i64) (param $2 (ref null $type1)) (result (ref null $type1))
  (if (result (ref null $type1))
   (call $foreign0)
   (then
    (local.get $2)
   )
   (else
    (unreachable)
   )
  )
 )
 (func $function4 (type $call4) (param $0 (ref null $type1)) (param $1 (ref null $type1)) (param $2 (ref null $type1)) (result (ref null $type1))
  (local $3 (ref null $type1))
  (local $4 (ref null $type1))
  (local $scratch (ref null $type1))
  (local $scratch_6 (ref null $type1))
  (if
   (i32.eqz
    (global.get $ready20)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global20)
   )
  )
  (if (result (ref null $type1))
   (if (result i32)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 1)
      )
      (else
       (local.set $3
        (struct.get $type1 0
         (local.get $1)
        )
       )
       (local.set $4
        (struct.get $type1 0
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready20)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global20)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $4)
        )
        (then
         (i32.const 0)
        )
        (else
         (if (result i32)
          (ref.is_null
           (local.get $3)
          )
          (then
           (i32.const 1)
          )
          (else
           (local.set $3
            (struct.get $type1 0
             (local.get $3)
            )
           )
           (local.set $4
            (struct.get $type1 0
             (local.get $4)
            )
           )
           (if
            (i32.eqz
             (global.get $ready20)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global20)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $4)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (ref.is_null
               (local.get $3)
              )
              (then
               (i32.const 1)
              )
              (else
               (local.set $3
                (struct.get $type1 0
                 (local.get $3)
                )
               )
               (local.set $4
                (struct.get $type1 0
                 (local.get $4)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready20)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global20)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if (result i32)
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (i32.const 1)
                  )
                  (else
                   (local.set $3
                    (struct.get $type1 0
                     (local.get $3)
                    )
                   )
                   (local.set $4
                    (struct.get $type1 0
                     (local.get $4)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready20)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global20)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (i32.const 1)
                      )
                      (else
                       (local.set $3
                        (struct.get $type1 0
                         (local.get $3)
                        )
                       )
                       (local.set $4
                        (struct.get $type1 0
                         (local.get $4)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready20)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global20)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $4)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (i32.const 1)
                          )
                          (else
                           (local.set $3
                            (struct.get $type1 0
                             (local.get $3)
                            )
                           )
                           (local.set $4
                            (struct.get $type1 0
                             (local.get $4)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready20)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global20)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $4)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (if (result i32)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (i32.const 1)
                              )
                              (else
                               (local.set $3
                                (struct.get $type1 0
                                 (local.get $3)
                                )
                               )
                               (local.set $4
                                (struct.get $type1 0
                                 (local.get $4)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready20)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global20)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $4)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (i32.const 1)
                                  )
                                  (else
                                   (local.set $3
                                    (struct.get $type1 0
                                     (local.get $3)
                                    )
                                   )
                                   (local.set $4
                                    (struct.get $type1 0
                                     (local.get $4)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready20)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global20)
                                    )
                                   )
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $4)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $3)
                                      )
                                      (then
                                       (i32.const 1)
                                      )
                                      (else
                                       (local.set $3
                                        (struct.get $type1 0
                                         (local.get $3)
                                        )
                                       )
                                       (local.set $4
                                        (struct.get $type1 0
                                         (local.get $4)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready20)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global20)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $4)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (if (result i32)
                                          (ref.is_null
                                           (local.get $3)
                                          )
                                          (then
                                           (i32.const 1)
                                          )
                                          (else
                                           (call $function5
                                            (struct.get $type1 0
                                             (local.get $3)
                                            )
                                            (block (result (ref null $type1))
                                             (local.set $scratch
                                              (struct.get $type1 0
                                               (local.get $4)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready20)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global20)
                                              )
                                             )
                                             (local.get $scratch)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (then
    (return_call $function4
     (call $function4
      (struct.get $type1 0
       (local.get $0)
      )
      (block (result (ref null $type1))
       (if
        (i32.eqz
         (global.get $ready16)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global16)
        )
       )
       (local.get $1)
      )
      (local.get $2)
     )
     (call $function4
      (struct.get $type1 0
       (local.get $1)
      )
      (block (result (ref null $type1))
       (if
        (i32.eqz
         (global.get $ready16)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global16)
        )
       )
       (local.get $2)
      )
      (local.get $0)
     )
     (block (result (ref null $type1))
      (local.set $scratch_6
       (call $function4
        (struct.get $type1 0
         (local.get $2)
        )
        (block (result (ref null $type1))
         (if
          (i32.eqz
           (global.get $ready16)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global16)
          )
         )
         (local.get $0)
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready16)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global16)
       )
      )
      (local.get $scratch_6)
     )
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function5 (type $call5) (param $0 (ref null $type1)) (param $1 (ref null $type1)) (result i32)
  (local $scratch (ref null $type1))
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $0)
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function5
       (struct.get $type1 0
        (local.get $0)
       )
       (block (result (ref null $type1))
        (local.set $scratch
         (struct.get $type1 0
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready20)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global20)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function7 (type $call8) (param $0 (ref $environment7)) (param $1 (ref null $type1)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type1 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type9 0
       (struct.get $environment7 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function7
     (struct.get $type8 0
      (struct.get $type9 1
       (struct.get $environment7 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global8)
   )
  )
  (return_call $function1
   (local.get $0)
  )
 )
 (func $main
  (local $0 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global23
   (struct.new_default $type0)
  )
  (global.set $ready23
   (i32.const 1)
  )
  (global.set $global13
   (struct.new $type2
    (ref.func $function3)
    (ref.null none)
   )
  )
  (global.set $ready13
   (i32.const 1)
  )
  (global.set $global0
   (struct.new_default $type3)
  )
  (global.set $ready0
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (drop
   (call $function0
    (i64.const 8)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (drop
   (call $function0
    (i64.const 2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (global.set $global16
   (struct.new_default $type4)
  )
  (global.set $ready16
   (i32.const 1)
  )
  (global.set $global20
   (struct.new_default $type5)
  )
  (global.set $ready20
   (i32.const 1)
  )
  (local.set $0
   (call $foreign1
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (global.set $global5
   (if (result (ref null $type1))
    (i64.eqz
     (local.get $0)
    )
    (then
     (ref.null none)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global0)
      )
     )
     (struct.new $type1
      (if (result (ref null $type1))
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready0)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global0)
         )
        )
        (struct.new $type1
         (if (result (ref null $type1))
          (i64.eqz
           (local.tee $0
            (i64.sub
             (local.get $0)
             (i64.const 1)
            )
           )
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global0)
            )
           )
           (struct.new $type1
            (if (result (ref null $type1))
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (ref.null none)
             )
             (else
              (if
               (i32.eqz
                (global.get $ready0)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global0)
               )
              )
              (struct.new $type1
               (if (result (ref null $type1))
                (i64.eqz
                 (local.tee $0
                  (i64.sub
                   (local.get $0)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (ref.null none)
                )
                (else
                 (if
                  (i32.eqz
                   (global.get $ready0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global0)
                  )
                 )
                 (struct.new $type1
                  (if (result (ref null $type1))
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (if
                     (i32.eqz
                      (global.get $ready0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global0)
                     )
                    )
                    (struct.new $type1
                     (if (result (ref null $type1))
                      (i64.eqz
                       (local.tee $0
                        (i64.sub
                         (local.get $0)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (if
                        (i32.eqz
                         (global.get $ready0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global0)
                        )
                       )
                       (struct.new $type1
                        (if (result (ref null $type1))
                         (i64.eqz
                          (local.tee $0
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (ref.null none)
                         )
                         (else
                          (if
                           (i32.eqz
                            (global.get $ready0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global0)
                           )
                          )
                          (struct.new $type1
                           (if (result (ref null $type1))
                            (i64.eqz
                             (local.tee $0
                              (i64.sub
                               (local.get $0)
                               (i64.const 1)
                              )
                             )
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (if
                              (i32.eqz
                               (global.get $ready0)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global0)
                              )
                             )
                             (struct.new $type1
                              (if (result (ref null $type1))
                               (i64.eqz
                                (local.tee $0
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (if
                                 (i32.eqz
                                  (global.get $ready0)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global0)
                                 )
                                )
                                (struct.new $type1
                                 (call $function0
                                  (i64.sub
                                   (local.get $0)
                                   (i64.const 1)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $ready5
   (i32.const 1)
  )
  (local.set $0
   (call $foreign1
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (global.set $global6
   (if (result (ref null $type1))
    (i64.eqz
     (local.get $0)
    )
    (then
     (ref.null none)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global0)
      )
     )
     (struct.new $type1
      (if (result (ref null $type1))
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready0)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global0)
         )
        )
        (struct.new $type1
         (if (result (ref null $type1))
          (i64.eqz
           (local.tee $0
            (i64.sub
             (local.get $0)
             (i64.const 1)
            )
           )
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global0)
            )
           )
           (struct.new $type1
            (if (result (ref null $type1))
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (ref.null none)
             )
             (else
              (if
               (i32.eqz
                (global.get $ready0)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global0)
               )
              )
              (struct.new $type1
               (if (result (ref null $type1))
                (i64.eqz
                 (local.tee $0
                  (i64.sub
                   (local.get $0)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (ref.null none)
                )
                (else
                 (if
                  (i32.eqz
                   (global.get $ready0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global0)
                  )
                 )
                 (struct.new $type1
                  (if (result (ref null $type1))
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (if
                     (i32.eqz
                      (global.get $ready0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global0)
                     )
                    )
                    (struct.new $type1
                     (if (result (ref null $type1))
                      (i64.eqz
                       (local.tee $0
                        (i64.sub
                         (local.get $0)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (if
                        (i32.eqz
                         (global.get $ready0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global0)
                        )
                       )
                       (struct.new $type1
                        (if (result (ref null $type1))
                         (i64.eqz
                          (local.tee $0
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (ref.null none)
                         )
                         (else
                          (if
                           (i32.eqz
                            (global.get $ready0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global0)
                           )
                          )
                          (struct.new $type1
                           (if (result (ref null $type1))
                            (i64.eqz
                             (local.tee $0
                              (i64.sub
                               (local.get $0)
                               (i64.const 1)
                              )
                             )
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (if
                              (i32.eqz
                               (global.get $ready0)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global0)
                              )
                             )
                             (struct.new $type1
                              (if (result (ref null $type1))
                               (i64.eqz
                                (local.tee $0
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (if
                                 (i32.eqz
                                  (global.get $ready0)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global0)
                                 )
                                )
                                (struct.new $type1
                                 (call $function0
                                  (i64.sub
                                   (local.get $0)
                                   (i64.const 1)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $ready6
   (i32.const 1)
  )
  (local.set $0
   (call $foreign1
    (i32.const 2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready0)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global0)
   )
  )
  (global.set $global7
   (if (result (ref null $type1))
    (i64.eqz
     (local.get $0)
    )
    (then
     (ref.null none)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready0)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global0)
      )
     )
     (struct.new $type1
      (if (result (ref null $type1))
       (i64.eqz
        (local.tee $0
         (i64.sub
          (local.get $0)
          (i64.const 1)
         )
        )
       )
       (then
        (ref.null none)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready0)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global0)
         )
        )
        (struct.new $type1
         (if (result (ref null $type1))
          (i64.eqz
           (local.tee $0
            (i64.sub
             (local.get $0)
             (i64.const 1)
            )
           )
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready0)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global0)
            )
           )
           (struct.new $type1
            (if (result (ref null $type1))
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (ref.null none)
             )
             (else
              (if
               (i32.eqz
                (global.get $ready0)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global0)
               )
              )
              (struct.new $type1
               (if (result (ref null $type1))
                (i64.eqz
                 (local.tee $0
                  (i64.sub
                   (local.get $0)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (ref.null none)
                )
                (else
                 (if
                  (i32.eqz
                   (global.get $ready0)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global0)
                  )
                 )
                 (struct.new $type1
                  (if (result (ref null $type1))
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (ref.null none)
                   )
                   (else
                    (if
                     (i32.eqz
                      (global.get $ready0)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global0)
                     )
                    )
                    (struct.new $type1
                     (if (result (ref null $type1))
                      (i64.eqz
                       (local.tee $0
                        (i64.sub
                         (local.get $0)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (ref.null none)
                      )
                      (else
                       (if
                        (i32.eqz
                         (global.get $ready0)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global0)
                        )
                       )
                       (struct.new $type1
                        (if (result (ref null $type1))
                         (i64.eqz
                          (local.tee $0
                           (i64.sub
                            (local.get $0)
                            (i64.const 1)
                           )
                          )
                         )
                         (then
                          (ref.null none)
                         )
                         (else
                          (if
                           (i32.eqz
                            (global.get $ready0)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global0)
                           )
                          )
                          (struct.new $type1
                           (if (result (ref null $type1))
                            (i64.eqz
                             (local.tee $0
                              (i64.sub
                               (local.get $0)
                               (i64.const 1)
                              )
                             )
                            )
                            (then
                             (ref.null none)
                            )
                            (else
                             (if
                              (i32.eqz
                               (global.get $ready0)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global0)
                              )
                             )
                             (struct.new $type1
                              (if (result (ref null $type1))
                               (i64.eqz
                                (local.tee $0
                                 (i64.sub
                                  (local.get $0)
                                  (i64.const 1)
                                 )
                                )
                               )
                               (then
                                (ref.null none)
                               )
                               (else
                                (if
                                 (i32.eqz
                                  (global.get $ready0)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global0)
                                 )
                                )
                                (struct.new $type1
                                 (call $function0
                                  (i64.sub
                                   (local.get $0)
                                   (i64.const 1)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (global.set $ready7
   (i32.const 1)
  )
  (global.set $global8
   (struct.new_default $type6)
  )
  (global.set $ready8
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

