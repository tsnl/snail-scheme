const counts = {initialization: {}, setup: {}, workload: {}, cleanup: {}}, files = [], tokens = {};
let phase = 'initialization', pathText = '', currentFile;
const count = name => { counts[phase][name] = (counts[phase][name] ?? 0) + 1; };
const tokenUse = (kind, handle) => {
  const length = tokens[handle];
  assert(Number.isSafeInteger(length));
  const key = 'token-characters-for-' + kind;
  counts[phase][key] = (counts[phase][key] ?? 0) + length;
};
const scalarImports = exports => Object.fromEntries(Object.entries(exports).map(([name, value]) => [name,
  typeof value !== 'function' ? value : (...args) => {
    count(name);
    const result = value(...args);
    if (name === 'snail:io/path-begin') pathText = '';
    if (name === 'snail:io/path-character') pathText += String.fromCodePoint(args[0]);
    if (name === 'snail:io/open-input-file') {
      assert(!currentFile);
      currentFile = {phase, path: pathText, handle: result, reads: 0, peeks: 0, read_eof: 0, peek_eof: 0, closed: false};
      files.push(currentFile);
    }
    if (name === 'snail:io/read-character' || name === 'snail:io/peek-character') {
      assert(currentFile && currentFile.handle === args[0]);
      const key = name === 'snail:io/read-character' ? 'reads' : 'peeks';
      currentFile[key]++;
      if (result === -1) currentFile[key === 'reads' ? 'read_eof' : 'peek_eof']++;
    }
    if (name === 'snail:io/close') {
      assert(currentFile && currentFile.handle === args[0]);
      currentFile.closed = true;
      currentFile = undefined;
    }
    if (name === 'snail:datum/token-open') tokens[result] = 0;
    if (name === 'snail:datum/token-character') tokens[args[0]]++;
    if (name === 'snail:datum/token-parse') tokenUse('parse', args[0]);
    if (name === 'snail:datum/token-identifier') tokenUse('identifier', args[0]);
    if (name === 'snail:datum/token-intern') { tokenUse('intern', args[0]); delete tokens[args[0]]; }
    if (name === 'snail:datum/token-close') delete tokens[args[0]];
    return result;
  }]));
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {WASI} from 'node:wasi';

// ---- Both layouts finish file setup before entering the original clock ----

const [artifact, specification, providerPath] = process.argv.slice(2);
const config = JSON.parse(fs.readFileSync(specification, 'utf8'));
const module = new WebAssembly.Module(fs.readFileSync(artifact));
const wasi = new WASI({version: 'preview1', args: [], env: {}, preopens: {'.': process.cwd()}, returnOnExit: true});
const wasiImports = Object.fromEntries(Object.entries(wasi.wasiImport).map(([name, value]) => [name,
  (...args) => { count('wasi:' + name); return value(...args); }]));
let provider;
if (providerPath) {
  const scalarModule = new WebAssembly.Module(fs.readFileSync(providerPath));
  assert(WebAssembly.Module.imports(scalarModule).every(item => ['snail.platform', 'wasi_snapshot_preview1'].includes(item.module)));
  provider = new WebAssembly.Instance(scalarModule, {wasi_snapshot_preview1: wasiImports,
    'snail.platform': {'diagnostics/report-error': (...args) => provider.exports['snail:report-error'](...args)}});
}
const instance = new WebAssembly.Instance(module, {benchmark: {barrier: () => 1},
                                                  'snail.library': scalarImports(provider.exports),
                                                  wasi_snapshot_preview1: wasiImports});
const close = () => provider ? provider.exports['snail:io/close-all']() : instance.exports['close-resources']();
let result, seconds, failure;
try {
  wasi.initialize(provider ?? instance);
  phase = 'setup';
  instance.exports.main();
  assert.equal(instance.exports['configured-count'](), BigInt(config.count));
  phase = 'workload';
  const start = process.hrtime.bigint();
  result = instance.exports.bench(BigInt(config.count));
  seconds = Number(process.hrtime.bigint() - start) / 1e9;
} catch (error) { failure = error; }
finally {
  phase = 'cleanup';
  try { assert.equal(close(), 0); }
  catch (error) { failure ??= error; }
}
if (failure) throw failure;
assert(!currentFile && Object.keys(tokens).length === 0);
fs.writeFileSync(process.env.SNAIL_DIAGNOSTIC_OUTPUT + '/counts.json', JSON.stringify({counts, files}));

console.log(JSON.stringify({result: Number(result), seconds}));
