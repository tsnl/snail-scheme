import inspector from 'node:inspector';
const session = new inspector.Session();
session.connect();
const markers = {clock_domain: 'process.hrtime.bigint nanoseconds', sampling_interval_us: 1000};
const post = (method, parameters = {}) => new Promise((resolve, reject) => {
  session.post(method, parameters, (error, value) => error ? reject(error) : resolve(value));
});
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {WASI} from 'node:wasi';

// ---- Both layouts finish file setup before entering the original clock ----

const [artifact, specification, providerPath] = process.argv.slice(2);
const config = JSON.parse(fs.readFileSync(specification, 'utf8'));
const module = new WebAssembly.Module(fs.readFileSync(artifact));
const wasi = new WASI({version: 'preview1', args: [], env: {}, preopens: {'.': process.cwd()}, returnOnExit: true});
let provider;
if (providerPath) {
  const scalarModule = new WebAssembly.Module(fs.readFileSync(providerPath));
  assert(WebAssembly.Module.imports(scalarModule).every(item => ['snail.platform', 'wasi_snapshot_preview1'].includes(item.module)));
  provider = new WebAssembly.Instance(scalarModule, {wasi_snapshot_preview1: wasi.wasiImport,
    'snail.platform': {'diagnostics/report-error': (...args) => provider.exports['snail:report-error'](...args)}});
}
const instance = new WebAssembly.Instance(module, {benchmark: {barrier: () => 1},
                                                  'snail.library': provider?.exports,
                                                  wasi_snapshot_preview1: wasi.wasiImport});
const close = () => provider ? provider.exports['snail:io/close-all']() : instance.exports['close-resources']();
let result, seconds, failure;
try {
  wasi.initialize(provider ?? instance);
  instance.exports.main();
  markers.main_return_ns = process.hrtime.bigint().toString();
  assert.equal(instance.exports['configured-count'](), BigInt(config.count));
  await post('Profiler.enable');
await post('Profiler.setSamplingInterval', {interval: 1000});
markers.start_submission_ns = process.hrtime.bigint().toString();
await post('Profiler.start');
markers.start_acknowledgement_ns = process.hrtime.bigint().toString();
  const start = process.hrtime.bigint();
  result = instance.exports.bench(BigInt(config.count));
  seconds = Number(process.hrtime.bigint() - start) / 1e9;
markers.clock_start_ns = start.toString();
markers.clock_stop_ns = process.hrtime.bigint().toString();
markers.stop_submission_ns = process.hrtime.bigint().toString();
const profile = (await post('Profiler.stop')).profile;
markers.stop_completion_ns = process.hrtime.bigint().toString();
session.disconnect();
fs.writeFileSync(process.env.SNAIL_DIAGNOSTIC_OUTPUT + '/profile.cpuprofile', JSON.stringify(profile));
fs.writeFileSync(process.env.SNAIL_DIAGNOSTIC_OUTPUT + '/profile-window.json', JSON.stringify(markers));

} catch (error) { failure = error; }
finally {
  try { assert.equal(close(), 0); }
  catch (error) { failure ??= error; }
}
if (failure) throw failure;
console.log(JSON.stringify({result: Number(result), seconds}));
