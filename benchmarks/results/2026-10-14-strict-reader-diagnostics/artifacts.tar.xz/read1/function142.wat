(func $function142 (type $call60) (param $0 (ref $type58)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local $3 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global466)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $1
   (call $snail:io/read-character
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $1
     (i64.lt_s
      (local.tee $2
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $3
          (if (result (ref $type68))
           (i32.eq
            (local.get $1)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $1)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
    )
    (then
     (local.get $1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global474)
      )
     )
     (if (result i32)
      (local.tee $1
       (i64.eq
        (local.get $2)
        (i64.const 10)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global474)
        )
       )
       (i64.eq
        (local.get $2)
        (i64.const 13)
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready477)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global477)
     )
    )
    (return_call $function142
     (local.get $0)
    )
   )
  )
 )
