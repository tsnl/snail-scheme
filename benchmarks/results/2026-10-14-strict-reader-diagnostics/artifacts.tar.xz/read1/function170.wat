(func $function170 (type $46) (param $0 (ref $type58)) (param $1 (ref $type150)) (param $2 i32) (param $3 i32) (result (ref $type18))
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type68))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global488)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (local.set $5
   (call $snail:io/peek-character
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global579)
   )
  )
  (if (result (ref $type18))
   (call $function167
    (if (result i64)
     (ref.test (ref $type69)
      (local.tee $6
       (if (result (ref $type68))
        (i32.eq
         (local.get $5)
         (i32.const -1)
        )
        (then
         (global.get $empty69)
        )
        (else
         (if
          (i64.gt_u
           (local.tee $4
            (i64.extend_i32_s
             (local.get $5)
            )
           )
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $4)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $4)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.new $type70
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (then
      (i64.const -1)
     )
     (else
      (i64.extend_i32_u
       (struct.get $type70 0
        (ref.cast (ref $type70)
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global504)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global81)
     )
    )
    (local.set $7
     (struct.get $type151 0
      (struct.get $type150 0
       (local.get $1)
      )
     )
    )
    (if (result (ref $type18))
     (if (result i32)
      (local.tee $2
       (i64.lt_s
        (local.tee $4
         (struct.get $type152 0
          (struct.get $type150 1
           (local.get $1)
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $2)
      )
      (else
       (i64.lt_s
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $7)
         )
        )
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $8
        (call $string-new
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (i64.const 0)
       (local.get $7)
       (local.get $4)
      )
      (local.get $8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global466)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (local.set $5
     (call $snail:io/read-character
      (struct.get $type56 0
       (struct.get $type58 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global468)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $6
          (if (result (ref $type68))
           (i32.eq
            (local.get $5)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $4
               (i64.extend_i32_s
                (local.get $5)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $4)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $4)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $4)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $6)
           )
          )
         )
        )
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $4)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $4)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global547)
     )
    )
    (call $function160
     (local.get $1)
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function170
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
