(func $function160 (type $50) (param $0 (ref $type150)) (param $1 i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type151))
  (if
   (i64.eq
    (local.tee $2
     (struct.get $type152 0
      (struct.get $type150 1
       (local.get $0)
      )
     )
    )
    (i64.extend_i32_u
     (struct.get $type18 1
      (struct.get $type151 0
       (struct.get $type150 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready551)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global551)
     )
    )
    (if
     (i64.ge_s
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global323)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global317)
       )
      )
      (call $snail:datum/fail
       (call $function104
        (global.get $string13)
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (select
          (i64.const 4294967294)
          (i64.shl
           (local.get $2)
           (i64.const 1)
          )
          (i64.gt_s
           (local.get $2)
           (i64.const 2147483647)
          )
         )
        )
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $6
        (call $string-new
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i64.const 0)
       (struct.get $type151 0
        (local.tee $7
         (struct.get $type150 0
          (local.get $0)
         )
        )
       )
       (local.get $2)
      )
      (struct.set $type151 0
       (local.get $7)
       (local.get $6)
      )
     )
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (local.tee $5
      (struct.get $type151 0
       (struct.get $type150 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $2)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $5)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type19
   (if (result (ref $type19))
    (i32.lt_u
     (local.tee $4
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type18 2
      (local.get $5)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type20
       (struct.get $type18 3
        (local.get $5)
       )
       (i32.sub
        (i32.shr_u
         (local.get $4)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $4)
    (i32.const 8191)
   )
   (local.get $1)
  )
  (struct.set $type152 0
   (struct.get $type150 1
    (local.get $0)
   )
   (i64.add
    (local.get $2)
    (i64.const 1)
   )
  )
 )
