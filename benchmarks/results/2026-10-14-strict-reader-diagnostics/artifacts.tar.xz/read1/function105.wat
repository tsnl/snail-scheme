(func $function105 (type $102) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $snail:datum/token-character
     (local.get $1)
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function105
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
