(func $function104 (type $call111) (param $0 (ref $type18)) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (local $5 i64)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 96)
    )
   )
  )
  (if
   (i32.ne
    (local.tee $1
     (i32.load8_u
      (i32.const 1138028)
     )
    )
    (i32.const 1)
   )
   (then
    (block $block2
     (block $block
      (block $block1
       (br_table $block $block1 $block2
        (i32.sub
         (local.get $1)
         (i32.const 1)
        )
       )
      )
      (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
       (i32.const 1061080)
       (i32.const 125)
       (i32.const 1061144)
      )
      (unreachable)
     )
     (i32.store8
      (i32.const 1138028)
      (i32.const 2)
     )
     (call $_ZN4core3ptr109drop_in_place$LT$alloc..collections..btree..map..BTreeMap$LT$u32$C$snail_runtime..strict_datum..Token$GT$$GT$17h82df8614fee55166E
      (i32.const 1138016)
     )
    )
    (i32.store8
     (i32.const 1138028)
     (i32.const 1)
    )
    (i64.store align=4
     (i32.const 1138008)
     (i64.const 0)
    )
    (i32.store
     (i32.const 1138024)
     (i32.const 0)
    )
    (i32.store
     (i32.const 1138016)
     (i32.const 0)
    )
   )
  )
  (block $block4
   (block $block5
    (block $block6
     (if
      (i32.eqz
       (i32.load
        (i32.const 1138008)
       )
      )
      (then
       (i32.store
        (i32.const 1138008)
        (i32.const -1)
       )
       (block $block3
        (if
         (i32.le_u
          (local.tee $1
           (i32.load
            (i32.const 1138012)
           )
          )
          (i32.const 2147483646)
         )
         (then
          (i32.store
           (i32.const 1138012)
           (i32.add
            (local.get $1)
            (i32.const 1)
           )
          )
          (i32.store offset=64
           (local.get $2)
           (i32.const 0)
          )
          (i64.store offset=56
           (local.get $2)
           (i64.const 4294967296)
          )
          (i64.store offset=48
           (local.get $2)
           (i64.const 6)
          )
          (call $_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hcc9368b035174f59E
           (local.get $2)
           (local.get $1)
           (i32.add
            (local.get $2)
            (i32.const 48)
           )
          )
          (if
           (i64.le_u
            (local.tee $5
             (i64.sub
              (local.tee $4
               (i64.load
                (local.get $2)
               )
              )
              (i64.const 6)
             )
            )
            (i64.const 1)
           )
           (then
            (br_if $block3
             (i32.sub
              (i32.wrap_i64
               (local.get $5)
              )
              (i32.const 1)
             )
            )
            (br $block4)
           )
          )
          (if
           (i32.load offset=32
            (local.get $2)
           )
           (then
            (call $dlfree
             (i32.load offset=36
              (local.get $2)
             )
            )
           )
          )
          (br_if $block4
           (i64.ne
            (local.get $4)
            (i64.const 5)
           )
          )
          (br_if $block4
           (i32.eqz
            (i32.load offset=8
             (local.get $2)
            )
           )
          )
          (br $block5)
         )
        )
        (br_if $block6
         (i32.eqz
          (local.tee $1
           (call $dlmalloc
            (i32.const 28)
           )
          )
         )
        )
        (i32.store
         (i32.const 1138008)
         (i32.const 0)
        )
        (i32.store offset=24 align=1
         (local.get $1)
         (i32.load align=1
          (i32.const 1055976)
         )
        )
        (i64.store offset=16 align=1
         (local.get $1)
         (i64.load align=1
          (i32.const 1055968)
         )
        )
        (i64.store offset=8 align=1
         (local.get $1)
         (i64.load align=1
          (i32.const 1055960)
         )
        )
        (i64.store align=1
         (local.get $1)
         (i64.load align=1
          (i32.const 1055952)
         )
        )
        (global.set $__stack_pointer
         (local.tee $2
          (i32.sub
           (global.get $__stack_pointer)
           (i32.const 16)
          )
         )
        )
        (call $_ZN13snail_runtime9strict_io11release_all17h60f1fb813a72b702E
         (i32.add
          (local.get $2)
          (i32.const 4)
         )
        )
        (if
         (i32.gt_s
          (i32.load offset=4
           (local.get $2)
          )
          (i32.const 0)
         )
         (then
          (call $dlfree
           (i32.load offset=8
            (local.get $2)
           )
          )
         )
        )
        (global.set $__stack_pointer
         (i32.add
          (local.get $2)
          (i32.const 16)
         )
        )
        (global.set $__stack_pointer
         (local.tee $2
          (i32.sub
           (global.get $__stack_pointer)
           (i32.const 32)
          )
         )
        )
        (call $_RNvMNtCsi9YzqDQQz2q_5alloc6stringNtB2_6String15from_utf8_lossy
         (local.tee $3
          (i32.add
           (local.get $2)
           (i32.const 12)
          )
         )
         (local.get $1)
         (i32.const 28)
        )
        (i64.store offset=24
         (local.get $2)
         (i64.or
          (i64.extend_i32_u
           (local.get $3)
          )
          (i64.const 103079215104)
         )
        )
        (call $_RNvNtNtCset5xJoy1xWQ_3std2io5stdio7__eprint
         (i32.add
          (local.get $2)
          (i32.const 24)
         )
        )
        (local.set $1
         (i32.load offset=16
          (local.get $2)
         )
        )
        (if
         (i32.gt_s
          (i32.load offset=12
           (local.get $2)
          )
          (i32.const 0)
         )
         (then
          (call $dlfree
           (local.get $1)
          )
         )
        )
        (call $_RNvNtCset5xJoy1xWQ_3std7process4exit)
        (unreachable)
       )
       (br_if $block5
        (i32.load offset=8
         (local.get $2)
        )
       )
       (br $block4)
      )
     )
     (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
      (i32.const 1061240)
     )
     (unreachable)
    )
    (call $_RINvNtNtCset5xJoy1xWQ_3std3sys9backtrace26___rust_end_short_backtraceNCNvNtB6_5alloc8rust_oom0zEB6_
     (i32.const 28)
    )
    (unreachable)
   )
   (call $dlfree
    (i32.load offset=12
     (local.get $2)
    )
   )
  )
  (i32.store
   (i32.const 1138008)
   (i32.add
    (i32.load
     (i32.const 1138008)
    )
    (i32.const 1)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 96)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $4
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $snail:datum/token-character
     (local.get $1)
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $4)
      (i64.const 1)
     )
     (then
      (local.get $1)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $snail:datum/token-character
       (local.get $1)
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $4)
        (i64.const 2)
       )
       (then
        (local.get $1)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $snail:datum/token-character
         (local.get $1)
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $4)
          (i64.const 3)
         )
         (then
          (local.get $1)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $snail:datum/token-character
           (local.get $1)
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $4)
            (i64.const 4)
           )
           (then
            (local.get $1)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $snail:datum/token-character
             (local.get $1)
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $4)
              (i64.const 5)
             )
             (then
              (local.get $1)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $snail:datum/token-character
               (local.get $1)
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $4)
                (i64.const 6)
               )
               (then
                (local.get $1)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $snail:datum/token-character
                 (local.get $1)
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $4)
                  (i64.const 7)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $snail:datum/token-character
                   (local.get $1)
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $4)
                    (i64.const 8)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $snail:datum/token-character
                     (local.get $1)
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $4)
                      (i64.const 9)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $snail:datum/token-character
                       (local.get $1)
                       (array.get $type19
                        (struct.get $type18 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $4)
                        (i64.const 10)
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $snail:datum/token-character
                         (local.get $1)
                         (array.get $type19
                          (struct.get $type18 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $4)
                          (i64.const 11)
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type18 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $snail:datum/token-character
                           (local.get $1)
                           (array.get $type19
                            (struct.get $type18 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $4)
                            (i64.const 12)
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $snail:datum/token-character
                             (local.get $1)
                             (array.get $type19
                              (struct.get $type18 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $4)
                              (i64.const 13)
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type18 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $snail:datum/token-character
                               (local.get $1)
                               (array.get $type19
                                (struct.get $type18 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $4)
                                (i64.const 14)
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $snail:datum/token-character
                                 (local.get $1)
                                 (array.get $type19
                                  (struct.get $type18 2
                                   (local.get $0)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $4)
                                  (i64.const 15)
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type18 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $snail:datum/token-character
                                   (local.get $1)
                                   (array.get $type19
                                    (struct.get $type18 2
                                     (local.get $0)
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $4)
                                    (i64.const 16)
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (call $snail:datum/token-character
                                     (local.get $1)
                                     (array.get $type19
                                      (struct.get $type18 2
                                       (local.get $0)
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $4)
                                      (i64.const 17)
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type18 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call $snail:datum/token-character
                                       (local.get $1)
                                       (array.get $type19
                                        (struct.get $type18 2
                                         (local.get $0)
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $4)
                                        (i64.const 18)
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (call $snail:datum/token-character
                                         (local.get $1)
                                         (array.get $type19
                                          (struct.get $type18 2
                                           (local.get $0)
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $4)
                                          (i64.const 19)
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $0)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $snail:datum/token-character
                                           (local.get $1)
                                           (array.get $type19
                                            (struct.get $type18 2
                                             (local.get $0)
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (if (result i32)
                                           (i64.eq
                                            (local.get $4)
                                            (i64.const 20)
                                           )
                                           (then
                                            (local.get $1)
                                           )
                                           (else
                                            (if
                                             (i64.le_u
                                              (i64.extend_i32_u
                                               (struct.get $type18 1
                                                (local.get $0)
                                               )
                                              )
                                              (i64.const 20)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (call $snail:datum/token-character
                                             (local.get $1)
                                             (array.get $type19
                                              (struct.get $type18 2
                                               (local.get $0)
                                              )
                                              (i32.const 20)
                                             )
                                            )
                                            (if (result i32)
                                             (i64.eq
                                              (local.get $4)
                                              (i64.const 21)
                                             )
                                             (then
                                              (local.get $1)
                                             )
                                             (else
                                              (if
                                               (i64.le_u
                                                (i64.extend_i32_u
                                                 (struct.get $type18 1
                                                  (local.get $0)
                                                 )
                                                )
                                                (i64.const 21)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (call $snail:datum/token-character
                                               (local.get $1)
                                               (array.get $type19
                                                (struct.get $type18 2
                                                 (local.get $0)
                                                )
                                                (i32.const 21)
                                               )
                                              )
                                              (if (result i32)
                                               (i64.eq
                                                (local.get $4)
                                                (i64.const 22)
                                               )
                                               (then
                                                (local.get $1)
                                               )
                                               (else
                                                (if
                                                 (i64.le_u
                                                  (i64.extend_i32_u
                                                   (struct.get $type18 1
                                                    (local.get $0)
                                                   )
                                                  )
                                                  (i64.const 22)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (call $snail:datum/token-character
                                                 (local.get $1)
                                                 (array.get $type19
                                                  (struct.get $type18 2
                                                   (local.get $0)
                                                  )
                                                  (i32.const 22)
                                                 )
                                                )
                                                (if (result i32)
                                                 (i64.eq
                                                  (local.get $4)
                                                  (i64.const 23)
                                                 )
                                                 (then
                                                  (local.get $1)
                                                 )
                                                 (else
                                                  (if
                                                   (i64.le_u
                                                    (i64.extend_i32_u
                                                     (struct.get $type18 1
                                                      (local.get $0)
                                                     )
                                                    )
                                                    (i64.const 23)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (call $snail:datum/token-character
                                                   (local.get $1)
                                                   (array.get $type19
                                                    (struct.get $type18 2
                                                     (local.get $0)
                                                    )
                                                    (i32.const 23)
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (i64.eq
                                                    (local.get $4)
                                                    (i64.const 24)
                                                   )
                                                   (then
                                                    (local.get $1)
                                                   )
                                                   (else
                                                    (if
                                                     (i64.le_u
                                                      (i64.extend_i32_u
                                                       (struct.get $type18 1
                                                        (local.get $0)
                                                       )
                                                      )
                                                      (i64.const 24)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (call $snail:datum/token-character
                                                     (local.get $1)
                                                     (array.get $type19
                                                      (call $string-block
                                                       (local.get $0)
                                                       (i32.const 24)
                                                      )
                                                      (i32.const 24)
                                                     )
                                                    )
                                                    (return_call $function105
                                                     (local.get $0)
                                                     (local.get $1)
                                                     (local.get $4)
                                                     (i32.const 0)
                                                     (i32.const 1)
                                                     (i64.const 25)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
