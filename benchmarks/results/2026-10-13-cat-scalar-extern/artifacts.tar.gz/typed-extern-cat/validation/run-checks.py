"""Execute the frozen scalar diagnostic's native port contracts on Node."""

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / "build/typed-extern-tests"
CASE = ROOT / "build/typed-extern-cat/scalar-loop"
FEATURES = ["--enable-gc", "--enable-reference-types", "--enable-tail-call",
            "--enable-mutable-globals", "--enable-sign-ext", "--enable-bulk-memory",
            "--enable-nontrapping-float-to-int"]

# ---- Linked checks and exact diagnostic output ----


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run_check(command, records, code=0, stdout=None, stderr=""):
    run = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=120)
    records.append(dict(command=command, returncode=run.returncode, stdout=run.stdout, stderr=run.stderr))
    if run.returncode != code or run.stderr != stderr or (stdout is not None and run.stdout != stdout):
        raise RuntimeError(f"native scalar check failed: {records[-1]}")


def checks(environment, records):
    probe = BUILD / "probe.wasm"
    wrong = BUILD / "wrong-signature.wasm"
    run_check([environment["WASM_OPT"], "-g", *FEATURES, "--remove-exports",
               "--pass-arg=remove-exports@_start", str(CASE / "program.wasm"), "-o", str(probe)], records)
    run_check([environment["WASM_AS"], str(ROOT / "tests/typed-extern/wrong-signature.wat"),
               "-o", str(wrong)], records)
    node = [environment["NODE"], "--no-warnings", "--expose-gc",
            str(ROOT / "tests/typed-extern/check-scalar-io.mjs"), str(probe)]
    run_check([*node, "success", str(wrong)], records, stdout="Native scalar I/O checks passed\n")
    run_check([*node, "closed"], records, code=1, stdout="", stderr="snail-scheme: port is closed\n")


def main():
    metadata = json.loads((CASE / "prepared.json").read_text())
    if digest(CASE / "program.wasm") != metadata["artifact_sha256"]:
        raise ValueError("frozen scalar diagnostic changed")
    BUILD.mkdir(parents=True, exist_ok=True)
    report = dict(program_sha256=metadata["artifact_sha256"], complete=False, checks=[])
    try:
        checks(metadata["build_environment"], report["checks"])
        report["complete"] = True
    finally:
        (BUILD / "results.json").write_text(json.dumps(report, indent=2) + "\n")
    print("Native scalar declaration/provider/owner checks passed")


if __name__ == "__main__":
    main()
