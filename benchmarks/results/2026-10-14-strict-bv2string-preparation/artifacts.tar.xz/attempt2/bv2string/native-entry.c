#include "native-provider.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
extern void native_host_init(int, char **);
extern void native_module_init(void);
extern int native_finish(int);
extern void guest_main(void) __asm__("wasm.main");
void observation_file(const char *);
uint64_t observation_count(void);
uint64_t barrier_count(void);
extern int64_t bench(int64_t) __asm__("wasm.bench");
int main(int argc, char **argv) {
    native_host_init(argc, argv); native_module_init(); guest_main();
    int64_t count = argc == 2 ? strtoll(argv[1], NULL, 10) : 100;
    struct timespec before, after;
    assert(clock_gettime(CLOCK_MONOTONIC, &before) == 0);
    int64_t result = bench(count);
    assert(clock_gettime(CLOCK_MONOTONIC, &after) == 0);
    double seconds = (double)(after.tv_sec - before.tv_sec) + (double)(after.tv_nsec - before.tv_nsec) / 1e9;
    printf("{\"result\":%" PRId64 ",\"barriers\":%" PRIu64 ",\"seconds\":%.9f}\n", result, barrier_count(), seconds);
    return native_finish(0);
}
