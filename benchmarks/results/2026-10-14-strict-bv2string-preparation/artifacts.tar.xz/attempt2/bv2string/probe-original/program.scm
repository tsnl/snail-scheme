(import (chezscheme))
(define-syntax : (syntax-rules () ((_ . signature) (begin))))
(define-syntax ann (syntax-rules () ((_ value type) value)))
(define (ref value) (vector value))
(define (ref-get cell) (vector-ref cell 0))
(define (ref-set! cell value) (vector-set! cell 0 value))
(define (unit) (if #f #f))
(define bv-display display)
(define bv-newline newline)
(define probe-output (open-file-output-port (cadr (command-line))
                      (file-options no-fail) (buffer-mode block)))
(define (bv-observe value)
  (do ((shift 0 (+ shift 8))) ((= shift 32))
    (put-u8 probe-output (bitwise-and (bitwise-arithmetic-shift-right value shift) 255))))
(define probe-mode (ref 0))
(define (bv-observe-random state value)
  (bv-observe 0) (bv-observe state) (bv-observe value) value)
(define (bv-observe-bytes tag bytes)
  (bv-observe tag) (bv-observe (bytevector-length bytes))
  (let loop ((index 0))
    (unless (= index (bytevector-length bytes))
      (bv-observe (bytevector-u8-ref bytes index)) (loop (+ index 1)))) bytes)
(define (bv-observe-string tag text)
  (bv-observe tag) (bv-observe (string-length text))
  (let loop ((index 0))
    (unless (= index (string-length text))
      (bv-observe (char->integer (string-ref text index))) (loop (+ index 1)))) text)
(define (bv-ascii)
  (let ((bytes (make-bytevector 128)))
    (let loop ((index 0))
      (if (= index 128) bytes
          (begin (bytevector-u8-set! bytes index index) (loop (+ index 1)))))))
(define (bv-observe-failures names)
  (bv-observe 7) (bv-observe (length names))
  (let loop ((names names))
    (unless (null? names)
      (bv-observe-string 8 (car names)) (loop (cdr names)))))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Copyright 2007 William D Clinger.
;;
;; Permission to copy this software, in whole or in part, to use this
;; software for any lawful purpose, and to redistribute this software
;; is granted subject to the restriction that all copies made of this
;; software must include this copyright notice in full.
;;
;; I also request that you send me a copy of any improvements that you
;; make to this software so that they may be incorporated within it to
;; the benefit of the Scheme community.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Tests of string <-> bytevector conversions.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


;; Crude test rig, just for benchmarking.

(define failed-tests '())

(define (test name actual expected)
  (unless (equal? actual expected)
    (display "******** FAILED TEST ******** ")
    (display name)
    (newline)
    (set! failed-tests (cons name failed-tests))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; We're limited to Ascii strings here because the R7RS doesn't
;; actually require anything beyond Ascii.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Basic sanity tests, followed by stress tests on random inputs.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(define (string-bytevector-tests
         *random-stress-tests* *random-stress-test-max-size*)

  (define (test-roundtrip bvec tostring tobvec)
    (let* ((observed (bv-observe-bytes 1 bvec))
           (s1 (bv-observe-string 2 (tostring observed)))
           (b2 (bv-observe-bytes 3 (tobvec s1)))
           (s2 (bv-observe-string 4 (tostring b2))))
      (test "round trip of string conversion" (string=? s1 s2) #t)))

  ;; This random number generator doesn't have to be good.
  ;; It just has to be fast.

  (define random
    (letrec ((random14
              (lambda (n)
                (set! x (remainder (+ (* a x) c) (+ m 1)))
                (bv-observe-random x (remainder (quotient x 8) n))))
             (a 701)
             (x 1)
             (c 743483)
             (m 524287)
             (loop
              (lambda (q r n)
                (if (zero? q)
                    (remainder r n)
                    (loop (quotient q 16384)
                          (+ (* 16384 r) (random14 16384))
                          n)))))
      (lambda (n)
        (if (< n 16384)
            (random14 n)
            (loop (quotient n 16384) (random14 16384) n)))))

  ;; Returns a random bytevector of length up to n,
  ;; with all elements less than 128.

  (define (random-bytevector n)
    (let* ((n (random n))
           (bv (make-bytevector n)))
      (do ((i 0 (+ i 1)))
          ((= i n) bv)
        (bytevector-u8-set! bv i (random 128)))))

  ;; Returns a random bytevector of even length up to n.

  (define (random-bytevector2 n)
    (let* ((n (random n))
           (n (if (odd? n) (+ n 1) n))
           (bv (make-bytevector n)))
      (do ((i 0 (+ i 1)))
          ((= i n) bv)
        (bytevector-u8-set! bv i (random 128)))))

  ;; Returns a random bytevector of multiple-of-4 length up to n.

  (define (random-bytevector4 n)
    (let* ((n (random n))
           (n (* 4 (round (/ n 4))))
           (bv (make-bytevector n)))
      (do ((i 0 (+ i 1)))
          ((= i n) bv)
        (bytevector-u8-set! bv i (random 128)))))

  (define (probe-generate maximum)
    (if (= (ref-get probe-mode) 1) (random-bytevector2 maximum)
        (if (= (ref-get probe-mode) 2) (random-bytevector4 maximum)
            (random-bytevector maximum))))
  (if (= (ref-get probe-mode) 3)
      (do ((i 0 (+ i 1))) ((= i *random-stress-tests*) (unit))
        (let ((value (random *random-stress-test-max-size*)))
          (bv-observe 5) (bv-observe value)))
      (if (= (ref-get probe-mode) 6)
          (test-roundtrip (bv-ascii) utf8->string string->utf8)
          (begin
            (test-roundtrip (probe-generate 10) utf8->string string->utf8)
            (do ((i 0 (+ i 1))) ((= i *random-stress-tests*) (unit))
              (test-roundtrip (probe-generate *random-stress-test-max-size*)
                              utf8->string string->utf8)))))

  )
(define (bv-probe-rounding count)
  (let loop ((value 0))
    (unless (= value count)
      (bv-observe 6) (bv-observe value) (bv-observe (round (/ value 4)))
      (loop (+ value 1)))))
(define (bv-probe-failures)
  (test "first\x0;λ" (string=? "left" "right") #t)
  (test "truth" #t #t)
  (test "second😀" (string=? "same" "same") #f)
  (test "false" #f #f))
(: probe (-> I64 I64 I64 I64))
(define (probe mode tests maximum)
  (ref-set! probe-mode mode)
  (if (= mode 4) (bv-probe-rounding tests)
      (if (= mode 5) (bv-probe-failures)
          (begin
            (string-bytevector-tests tests maximum)
            (when (= mode 7) (string-bytevector-tests tests maximum)))))
  (bv-observe-failures failed-tests)
  (length failed-tests))
(let* ((mode (read)) (tests (read)) (maximum (read))
                  (result (probe mode tests maximum)))
  (close-port probe-output) (display result) (newline))
