#include "native-provider.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
extern void native_host_init(int, char **);
extern void native_module_init(void);
extern int native_finish(int);
extern void guest_main(void) __asm__("wasm.main");
void observation_file(const char *);
uint64_t observation_count(void);
uint64_t barrier_count(void);
extern int64_t probe(int64_t, int64_t, int64_t) __asm__("wasm.probe");
int main(int argc, char **argv) {
    native_host_init(argc, argv); native_module_init(); guest_main();
    if (argc != 5) return 81;
    observation_file(argv[1]);
    int64_t result = probe(strtoll(argv[2], NULL, 10), strtoll(argv[3], NULL, 10), strtoll(argv[4], NULL, 10));
    printf("{\"result\":%" PRId64 ",\"values\":%" PRIu64 "}\n", result, observation_count());
    return native_finish(0);
}
