(module
 (rec
  (type $0 (func (param i64 i32 i32 i64) (result i32)))
  (type $call69 (func (param i64 i64 i64) (result i64)))
  (type $2 (func (param i64 i64 i32 i32 (ref null $type42) i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64) (result i32)))
  (type $3 (func (param i64 i64 (ref $type42) i32 i32 i32 i64) (result i32)))
  (type $4 (func (param (ref null $type42) i32 i32 i32 i32 i64) (result (ref $type28))))
  (type $5 (func (param (ref $type42) i32 i64 (ref $type28) i32 i32 i64) (result (ref $type28))))
  (type $6 (func (param (ref $type70) (ref $type72) (ref $type71) (ref $type71) (ref $type71) (ref $type70) i64 i64 i64) (result i64)))
  (type $7 (func (param (ref $type72) (ref $type71) (ref $type71) (ref $type71) i64) (result i64)))
  (type $8 (func (param (ref $type28)) (result i32)))
  (type $environment101 (struct (field (ref $type70)) (field (ref $type72)) (field (ref $type71)) (field (ref $type71)) (field (ref $type71)) (field (ref $type70))))
  (type $type71 (struct (field i32) (field i64)))
  (type $type72 (struct (field i32) (field (ref $type59))))
  (type $type70 (struct (field i32)))
  (type $call67 (func (param i64 i64) (result i32)))
  (type $14 (func (param (ref $type14) i32 i32) (result i32)))
  (type $15 (func (param i32 i32 (ref null $type23)) (result i32)))
  (type $16 (func (param i32 i32 (ref null $type23) i64) (result i64)))
  (type $type23 (struct (field (ref $type14)) (field (ref null $type23))))
  (type $call64 (func (param (ref null $type23)) (result i32)))
  (type $19 (func (param (ref $type28) i32 i32 i64) (result (ref $type28))))
  (type $call63 (func (result (ref $type28))))
  (type $call62 (func (param i64 (ref $type14)) (result (ref $type14))))
  (type $22 (func (param (ref $type28) i32 i32 i64) (result i32)))
  (type $call61 (func (param i64 (ref $type28)) (result (ref $type28))))
  (type $24 (func (param (ref $type14) i32 i32 i64) (result i32)))
  (type $25 (func (param (ref $type14)) (result i32)))
  (type $26 (func (param (ref $type28) (ref $type14) i64 i32 i32 i64 i64) (result i32)))
  (type $27 (func (param (ref $type14) i64 i32 i32 i64 i64) (result i64)))
  (type $28 (func (param (ref $type14) i64) (result (ref $type28))))
  (type $29 (func (param (ref $type14) (ref $type28) i64 i32 i32 i64 i64) (result i32)))
  (type $30 (func (param (ref $type28) i64 i64 i32 i32 i64 i64) (result i32)))
  (type $call42 (func (param (ref null $environment101) i64) (result i64)))
  (type $type29 (array (mut i8)))
  (type $33 (func (param (ref $type28) i64 i32 i32 i64 i64) (result i64)))
  (type $type28 (struct (field (ref $type29))))
  (type $35 (func (param (ref $type28) i64) (result (ref $type14))))
  (type $36 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $38 (func (param (ref $type14) i32) (result (ref $type15))))
  (type $type69 (struct))
  (type $type68 (struct))
  (type $type67 (struct))
  (type $type66 (struct))
  (type $type65 (struct (field (mut (ref null $type23)))))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type61 (struct))
  (type $type60 (struct))
  (type $type59 (struct (field (mut i64))))
  (type $type10 (struct))
  (type $type58 (struct))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type24 (struct))
  (type $type55 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type50 (struct))
  (type $type49 (struct))
  (type $type47 (struct))
  (type $type46 (struct))
  (type $type45 (struct))
  (type $type44 (struct))
  (type $type43 (struct))
  (type $type42 (struct (field (ref $call42)) (field (ref null $environment101))))
  (type $type33 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type13 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $73 (func (param i32)))
 (type $74 (func (param i64)))
 (type $75 (func (param i64 i64 i64) (result i64)))
 (type $76 (func))
 (import "benchmark" "write_character" (func $foreign0 (param i32)))
 (import "benchmark" "observe" (func $foreign1 (param i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type15 30
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 32)
   (i32.const 70)
   (i32.const 65)
   (i32.const 73)
   (i32.const 76)
   (i32.const 69)
   (i32.const 68)
   (i32.const 32)
   (i32.const 84)
   (i32.const 69)
   (i32.const 83)
   (i32.const 84)
   (i32.const 32)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type15 31
   (i32.const 114)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 112)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 118)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type15 5
   (i32.const 102)
   (i32.const 97)
   (i32.const 108)
   (i32.const 115)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type15 7
   (i32.const 115)
   (i32.const 101)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 100)
   (i32.const 128512)
  )
  (ref.null none)
 ))
 (global $string4 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type15 4
   (i32.const 115)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string5 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type15 5
   (i32.const 116)
   (i32.const 114)
   (i32.const 117)
   (i32.const 116)
   (i32.const 104)
  )
  (ref.null none)
 ))
 (global $string6 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type15 7
   (i32.const 102)
   (i32.const 105)
   (i32.const 114)
   (i32.const 115)
   (i32.const 116)
   (i32.const 0)
   (i32.const 955)
  )
  (ref.null none)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type26)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type33)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global182 (mut (ref null $type42)) (ref.null none))
 (global $ready182 (mut i32) (i32.const 0))
 (global $global188 (mut (ref null $type42)) (ref.null none))
 (global $ready188 (mut i32) (i32.const 0))
 (global $global193 (mut (ref null $type42)) (ref.null none))
 (global $ready193 (mut i32) (i32.const 0))
 (global $global177 (mut (ref null $type43)) (ref.null none))
 (global $ready177 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type44)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global184 (mut (ref null $type45)) (ref.null none))
 (global $ready184 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type43)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global195 (mut (ref null $type46)) (ref.null none))
 (global $ready195 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type47)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $global207 (mut (ref null $type49)) (ref.null none))
 (global $ready207 (mut i32) (i32.const 0))
 (global $global229 (mut (ref null $type42)) (ref.null none))
 (global $ready229 (mut i32) (i32.const 0))
 (global $global222 (mut (ref null $type50)) (ref.null none))
 (global $ready222 (mut i32) (i32.const 0))
 (global $global209 (mut (ref null $type51)) (ref.null none))
 (global $ready209 (mut i32) (i32.const 0))
 (global $global231 (mut (ref null $type52)) (ref.null none))
 (global $ready231 (mut i32) (i32.const 0))
 (global $global217 (mut (ref null $type53)) (ref.null none))
 (global $ready217 (mut i32) (i32.const 0))
 (global $global244 (mut (ref null $type55)) (ref.null none))
 (global $ready244 (mut i32) (i32.const 0))
 (global $global281 (mut (ref null $type24)) (ref.null none))
 (global $ready281 (mut i32) (i32.const 0))
 (global $global246 (mut (ref null $type56)) (ref.null none))
 (global $ready246 (mut i32) (i32.const 0))
 (global $global316 (mut (ref null $type57)) (ref.null none))
 (global $ready316 (mut i32) (i32.const 0))
 (global $global249 (mut (ref null $type57)) (ref.null none))
 (global $ready249 (mut i32) (i32.const 0))
 (global $global251 (mut (ref null $type42)) (ref.null none))
 (global $ready251 (mut i32) (i32.const 0))
 (global $global256 (mut (ref null $type58)) (ref.null none))
 (global $ready256 (mut i32) (i32.const 0))
 (global $global260 (mut (ref null $type10)) (ref.null none))
 (global $ready260 (mut i32) (i32.const 0))
 (global $global261 (mut (ref null $type59)) (ref.null none))
 (global $ready261 (mut i32) (i32.const 0))
 (global $global262 (mut (ref null $type60)) (ref.null none))
 (global $ready262 (mut i32) (i32.const 0))
 (global $global265 (mut (ref null $type61)) (ref.null none))
 (global $ready265 (mut i32) (i32.const 0))
 (global $global270 (mut (ref null $type62)) (ref.null none))
 (global $ready270 (mut i32) (i32.const 0))
 (global $global275 (mut (ref null $type63)) (ref.null none))
 (global $ready275 (mut i32) (i32.const 0))
 (global $global279 (mut (ref null $type64)) (ref.null none))
 (global $ready279 (mut i32) (i32.const 0))
 (global $global288 (mut (ref null $type65)) (ref.null none))
 (global $ready288 (mut i32) (i32.const 0))
 (global $global289 (mut (ref null $type66)) (ref.null none))
 (global $ready289 (mut i32) (i32.const 0))
 (global $global293 (mut (ref null $type67)) (ref.null none))
 (global $ready293 (mut i32) (i32.const 0))
 (global $global350 (mut (ref null $type68)) (ref.null none))
 (global $ready350 (mut i32) (i32.const 0))
 (global $global345 (mut (ref null $type10)) (ref.null none))
 (global $ready345 (mut i32) (i32.const 0))
 (global $global346 (mut (ref null $type69)) (ref.null none))
 (global $ready346 (mut i32) (i32.const 0))
 (export "probe" (func $export0))
 (export "main" (func $main))
 (func $string-block (type $38) (param $0 (ref $type14)) (param $1 i32) (result (ref $type15))
  (if (result (ref $type15))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type14 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type16
      (struct.get $type14 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function40 (type $36) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type15
       (if (result (ref $type15))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type14 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type16
           (struct.get $type14 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type15
        (if (result (ref $type15))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type14 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type16
            (struct.get $type14 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function57 (type $35) (param $0 (ref $type28)) (param $1 i64) (result (ref $type14))
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i64)
  (local $8 (ref null $type16))
  (local $9 (ref $type14))
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $7
   (i64.extend_i32_u
    (array.len
     (struct.get $type28 0
      (local.get $0)
     )
    )
   )
  )
  (if
   (if (result i32)
    (local.tee $2
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $2)
    )
    (else
     (i64.gt_s
      (local.get $1)
      (local.get $7)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready169)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global169)
   )
  )
  (local.set $7
   (call $function59
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $7)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (if
   (local.tee $3
    (i32.sub
     (local.tee $2
      (i32.wrap_i64
       (local.get $7)
      )
     )
     (local.tee $5
      (select
       (i32.const 8192)
       (local.get $2)
       (i32.ge_u
        (local.get $2)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $8
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $2)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $8)
      (local.get $4)
      (array.new_default $type15
       (local.tee $6
        (select
         (i32.const 8192)
         (local.get $3)
         (i32.ge_u
          (local.get $3)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $4
      (i32.add
       (local.get $4)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $3
       (i32.sub
        (local.get $3)
        (local.get $6)
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready195)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global195)
   )
  )
  (drop
   (call $function67
    (local.tee $9
     (struct.new $type14
      (i32.const 1)
      (local.get $2)
      (array.new_default $type15
       (local.get $5)
      )
      (local.get $8)
     )
    )
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (local.get $9)
 )
 (func $function59 (type $33) (param $0 (ref $type28)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i64)
  (local $7 i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready177)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global177)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready182)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global182)
     )
    )
    (if
     (i64.gt_s
      (local.tee $6
       (if (result i64)
        (i64.lt_u
         (local.get $6)
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i32.and
           (i64.lt_u
            (local.get $6)
            (i64.const 224)
           )
           (i64.ge_u
            (local.get $6)
            (i64.const 194)
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (i32.and
             (i64.lt_u
              (local.get $6)
              (i64.const 240)
             )
             (i64.ge_u
              (local.get $6)
              (i64.const 224)
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (i32.and
               (i64.lt_u
                (local.get $6)
                (i64.const 245)
               )
               (i64.ge_u
                (local.get $6)
                (i64.const 240)
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (unreachable)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.sub
       (local.get $1)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready184)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global184)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global188)
     )
    )
    (drop
     (call $function64
      (local.get $0)
      (local.get $4)
      (local.get $6)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (i64.sub
       (local.get $7)
       (if (result i64)
        (i64.eq
         (local.get $6)
         (i64.const 1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (i64.eq
           (local.get $6)
           (i64.const 2)
          )
          (then
           (i64.const 192)
          )
          (else
           (select
            (i64.const 224)
            (i64.const 240)
            (i64.eq
             (local.get $6)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (local.get $6)
     )
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function61 (type $call42) (param $0 (ref null $environment101)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 128)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i32.and
      (i64.lt_s
       (local.get $1)
       (i64.const 224)
      )
      (i64.ge_s
       (local.get $1)
       (i64.const 194)
      )
     )
     (then
      (i64.const 2)
     )
     (else
      (if (result i64)
       (i32.and
        (i64.lt_s
         (local.get $1)
         (i64.const 240)
        )
        (i64.ge_s
         (local.get $1)
         (i64.const 224)
        )
       )
       (then
        (i64.const 3)
       )
       (else
        (if (result i64)
         (i32.and
          (i64.lt_s
           (local.get $1)
           (i64.const 245)
          )
          (i64.ge_s
           (local.get $1)
           (i64.const 240)
          )
         )
         (then
          (i64.const 4)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function63 (type $call42) (param $0 (ref null $environment101)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (i64.const 1)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (i64.const 2)
     )
     (then
      (i64.const 192)
     )
     (else
      (select
       (i64.const 224)
       (i64.const 240)
       (i64.eq
        (local.get $1)
        (i64.const 3)
       )
      )
     )
    )
   )
  )
 )
 (func $function64 (type $30) (param $0 (ref $type28)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready193)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global193)
     )
    )
    (if (result i32)
     (i64.gt_s
      (if (result i64)
       (i64.eq
        (local.get $2)
        (i64.const 1)
       )
       (then
        (i64.const 0)
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $2)
          (i64.const 2)
         )
         (then
          (i64.const 128)
         )
         (else
          (select
           (i64.const 2048)
           (i64.const 65536)
           (i64.eq
            (local.get $2)
            (i64.const 3)
           )
          )
         )
        )
       )
      )
      (local.get $6)
     )
     (then
      (unreachable)
     )
     (else
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $6)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $6)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $6)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready159)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global159)
     )
    )
    (if
     (i64.gt_u
      (local.tee $7
       (i64.add
        (local.get $1)
        (local.get $5)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (if (result i64)
      (if (result i32)
       (local.tee $8
        (i64.lt_u
         (local.tee $7
          (i64.extend_i32_u
           (array.get_u $type29
            (struct.get $type28 0
             (local.get $0)
            )
            (i32.wrap_i64
             (local.get $7)
            )
           )
          )
         )
         (i64.const 128)
        )
       )
       (then
        (local.get $8)
       )
       (else
        (i64.gt_u
         (local.get $7)
         (i64.const 191)
        )
       )
      )
      (then
       (unreachable)
      )
      (else
       (i64.sub
        (local.get $7)
        (i64.const 128)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function64
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
     (i64.add
      (local.get $7)
      (i64.shl
       (local.get $6)
       (i64.const 6)
      )
     )
    )
   )
  )
 )
 (func $function65 (type $call42) (param $0 (ref null $environment101)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (i64.const 1)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (i64.const 2)
     )
     (then
      (i64.const 128)
     )
     (else
      (select
       (i64.const 2048)
       (i64.const 65536)
       (i64.eq
        (local.get $1)
        (i64.const 3)
       )
      )
     )
    )
   )
  )
 )
 (func $function67 (type $29) (param $0 (ref $type14)) (param $1 (ref $type28)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i32)
  (local $10 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready177)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global177)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready182)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global182)
     )
    )
    (if
     (i64.gt_s
      (local.tee $7
       (if (result i64)
        (i64.lt_u
         (local.get $7)
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i32.and
           (i64.lt_u
            (local.get $7)
            (i64.const 224)
           )
           (i64.ge_u
            (local.get $7)
            (i64.const 194)
           )
          )
          (then
           (i64.const 2)
          )
          (else
           (if (result i64)
            (i32.and
             (i64.lt_u
              (local.get $7)
              (i64.const 240)
             )
             (i64.ge_u
              (local.get $7)
              (i64.const 224)
             )
            )
            (then
             (i64.const 3)
            )
            (else
             (if (result i64)
              (i32.and
               (i64.lt_u
                (local.get $7)
                (i64.const 245)
               )
               (i64.ge_u
                (local.get $7)
                (i64.const 240)
               )
              )
              (then
               (i64.const 4)
              )
              (else
               (unreachable)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.sub
       (local.get $2)
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready184)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global184)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global188)
     )
    )
    (local.set $10
     (call $function64
      (local.get $1)
      (local.get $5)
      (local.get $7)
      (i32.const 0)
      (i32.const 1)
      (i64.const 1)
      (i64.sub
       (local.get $8)
       (if (result i64)
        (i64.eq
         (local.get $7)
         (i64.const 1)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (i64.eq
           (local.get $7)
           (i64.const 2)
          )
          (then
           (i64.const 192)
          )
          (else
           (select
            (i64.const 224)
            (i64.const 240)
            (i64.eq
             (local.get $7)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.get $0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $6)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $9
        (i32.wrap_i64
         (local.get $6)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 2
        (local.get $0)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 3
          (local.get $0)
         )
         (i32.sub
          (i32.shr_u
           (local.get $9)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $9)
      (i32.const 8191)
     )
     (local.get $10)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (local.get $7)
     )
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function71 (type $30) (param $0 (ref $type28)) (param $1 i64) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (if (result i32)
   (i64.eq
    (local.get $5)
    (i64.const 1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type42 1
      (global.get $global188)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $2
       (i64.add
        (if (result i64)
         (i64.eq
          (local.get $2)
          (i64.const 1)
         )
         (then
          (i64.const 0)
         )
         (else
          (if (result i64)
           (i64.eq
            (local.get $2)
            (i64.const 2)
           )
           (then
            (i64.const 192)
           )
           (else
            (select
             (i64.const 224)
             (i64.const 240)
             (i64.eq
              (local.get $2)
              (i64.const 3)
             )
            )
           )
          )
         )
        )
        (local.get $6)
       )
      )
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.wrap_i64
      (local.get $2)
     )
    )
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $7
       (i64.add
        (i64.sub
         (local.get $5)
         (i64.const 1)
        )
        (local.get $1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.tee $8
       (i64.add
        (i64.rem_s
         (local.get $6)
         (i64.const 64)
        )
        (i64.const 128)
       )
      )
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $7)
     )
     (i32.wrap_i64
      (local.get $8)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function71
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.sub
      (local.get $5)
      (i64.const 1)
     )
     (i64.div_s
      (local.get $6)
      (i64.const 64)
     )
    )
   )
  )
 )
 (func $function74 (type $27) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result i64)
  (local $6 i32)
  (local $7 i64)
  (local $scratch i32)
  (if (result i64)
   (i64.gt_s
    (local.get $5)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $1)
      (local.get $4)
     )
     (then
      (local.get $5)
     )
     (else
      (if
       (i64.ge_u
        (local.get $4)
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (if (result i64)
        (i64.lt_u
         (local.tee $7
          (i64.extend_i32_u
           (block (result i32)
            (local.set $scratch
             (array.get $type15
              (if (result (ref $type15))
               (i32.lt_u
                (local.tee $6
                 (i32.wrap_i64
                  (local.get $4)
                 )
                )
                (i32.const 8192)
               )
               (then
                (struct.get $type14 2
                 (local.get $0)
                )
               )
               (else
                (ref.as_non_null
                 (array.get $type16
                  (struct.get $type14 3
                   (local.get $0)
                  )
                  (i32.sub
                   (i32.shr_u
                    (local.get $6)
                    (i32.const 13)
                   )
                   (i32.const 1)
                  )
                 )
                )
               )
              )
              (i32.and
               (local.get $6)
               (i32.const 8191)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready229)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (struct.get $type42 1
              (global.get $global229)
             )
            )
            (local.get $scratch)
           )
          )
         )
         (i64.const 128)
        )
        (then
         (i64.const 1)
        )
        (else
         (if (result i64)
          (i64.lt_u
           (local.get $7)
           (i64.const 2048)
          )
          (then
           (i64.const 2)
          )
          (else
           (select
            (i64.const 3)
            (i64.const 4)
            (i64.lt_u
             (local.get $7)
             (i64.const 65536)
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function74
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
       (i64.add
        (local.get $5)
        (local.get $7)
       )
      )
     )
    )
   )
  )
 )
 (func $function75 (type $call42) (param $0 (ref null $environment101)) (param $1 i64) (result i64)
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 128)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.lt_s
      (local.get $1)
      (i64.const 2048)
     )
     (then
      (i64.const 2)
     )
     (else
      (select
       (i64.const 3)
       (i64.const 4)
       (i64.lt_s
        (local.get $1)
        (i64.const 65536)
       )
      )
     )
    )
   )
  )
 )
 (func $function77 (type $26) (param $0 (ref $type28)) (param $1 (ref $type14)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (param $6 i64) (result i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i32)
  (local $scratch i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (if (result i64)
      (i64.lt_u
       (local.tee $7
        (local.tee $8
         (i64.extend_i32_u
          (block (result i32)
           (local.set $scratch
            (array.get $type15
             (if (result (ref $type15))
              (i32.lt_u
               (local.tee $9
                (i32.wrap_i64
                 (local.get $5)
                )
               )
               (i32.const 8192)
              )
              (then
               (struct.get $type14 2
                (local.get $1)
               )
              )
              (else
               (ref.as_non_null
                (array.get $type16
                 (struct.get $type14 3
                  (local.get $1)
                 )
                 (i32.sub
                  (i32.shr_u
                   (local.get $9)
                   (i32.const 13)
                  )
                  (i32.const 1)
                 )
                )
               )
              )
             )
             (i32.and
              (local.get $9)
              (i32.const 8191)
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready229)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (struct.get $type42 1
             (global.get $global229)
            )
           )
           (local.get $scratch)
          )
         )
        )
       )
       (i64.const 128)
      )
      (then
       (i64.const 1)
      )
      (else
       (if (result i64)
        (i64.lt_u
         (local.get $7)
         (i64.const 2048)
        )
        (then
         (i64.const 2)
        )
        (else
         (select
          (i64.const 3)
          (i64.const 4)
          (i64.lt_u
           (local.get $7)
           (i64.const 65536)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready209)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global209)
     )
    )
    (drop
     (call $function71
      (local.get $0)
      (local.get $6)
      (local.get $7)
      (i32.const 0)
      (i32.const 1)
      (local.get $7)
      (local.get $8)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function77
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
     (i64.add
      (local.get $6)
      (local.get $7)
     )
    )
   )
  )
 )
 (func $function82 (type $call42) (param $0 (ref null $environment101)) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i32)
  (select
   (i64.add
    (local.tee $2
     (i64.div_s
      (local.get $1)
      (i64.const 4)
     )
    )
    (i64.const 1)
   )
   (local.get $2)
   (if (result i32)
    (local.tee $3
     (i64.gt_s
      (local.tee $1
       (i64.rem_s
        (local.get $1)
        (i64.const 4)
       )
      )
      (i64.const 2)
     )
    )
    (then
     (local.get $3)
    )
    (else
     (if (result i32)
      (i64.eq
       (local.get $1)
       (i64.const 2)
      )
      (then
       (if
        (i32.eqz
         (global.get $ready249)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global249)
        )
       )
       (i32.wrap_i64
        (i64.and
         (local.get $2)
         (i64.const 1)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
   )
  )
 )
 (func $function83 (type $25) (param $0 (ref $type14)) (result i32)
  (if (result i32)
   (i64.eqz
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign0
     (array.get $type15
      (struct.get $type14 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign0
       (array.get $type15
        (struct.get $type14 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign0
         (array.get $type15
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign0
           (array.get $type15
            (struct.get $type14 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type14 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign0
             (array.get $type15
              (struct.get $type14 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (struct.get $type14 1
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type14 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign0
               (array.get $type15
                (struct.get $type14 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (i64.extend_i32_u
                 (struct.get $type14 1
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type14 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign0
                 (array.get $type15
                  (struct.get $type14 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (i64.extend_i32_u
                   (struct.get $type14 1
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type14 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign0
                   (array.get $type15
                    (struct.get $type14 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (i64.extend_i32_u
                     (struct.get $type14 1
                      (local.get $0)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type14 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign0
                     (array.get $type15
                      (struct.get $type14 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (struct.get $type14 1
                        (local.get $0)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type14 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign0
                       (array.get $type15
                        (call $string-block
                         (local.get $0)
                         (i32.const 9)
                        )
                        (i32.const 9)
                       )
                      )
                      (return_call $function84
                       (local.get $0)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function84 (type $24) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign0
     (array.get $type15
      (call $string-block
       (local.get $0)
       (local.tee $4
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (i32.and
       (local.get $4)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function87 (type $call61) (param $0 i64) (param $1 (ref $type28)) (result (ref $type28))
  (local $2 (ref $type29))
  (call $foreign1
   (local.get $0)
  )
  (call $foreign1
   (local.tee $0
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 0
       (local.get $1)
      )
     )
    )
   )
  )
  (drop
   (if (result i32)
    (i64.eqz
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (call $foreign1
      (i64.extend_i32_u
       (array.get_u $type29
        (local.tee $2
         (struct.get $type28 0
          (local.get $1)
         )
        )
        (i32.const 0)
       )
      )
     )
     (if (result i32)
      (i64.eq
       (i64.extend_i32_u
        (array.len
         (local.get $2)
        )
       )
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $foreign1
        (i64.extend_i32_u
         (array.get_u $type29
          (local.tee $2
           (struct.get $type28 0
            (local.get $1)
           )
          )
          (i32.const 1)
         )
        )
       )
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (array.len
           (local.get $2)
          )
         )
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign1
          (i64.extend_i32_u
           (array.get_u $type29
            (local.tee $2
             (struct.get $type28 0
              (local.get $1)
             )
            )
            (i32.const 2)
           )
          )
         )
         (if (result i32)
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $2)
            )
           )
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign1
            (i64.extend_i32_u
             (array.get_u $type29
              (local.tee $2
               (struct.get $type28 0
                (local.get $1)
               )
              )
              (i32.const 3)
             )
            )
           )
           (if (result i32)
            (i64.eq
             (i64.extend_i32_u
              (array.len
               (local.get $2)
              )
             )
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign1
              (i64.extend_i32_u
               (array.get_u $type29
                (local.tee $2
                 (struct.get $type28 0
                  (local.get $1)
                 )
                )
                (i32.const 4)
               )
              )
             )
             (if (result i32)
              (i64.eq
               (i64.extend_i32_u
                (array.len
                 (local.get $2)
                )
               )
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign1
                (i64.extend_i32_u
                 (array.get_u $type29
                  (local.tee $2
                   (struct.get $type28 0
                    (local.get $1)
                   )
                  )
                  (i32.const 5)
                 )
                )
               )
               (if (result i32)
                (i64.eq
                 (i64.extend_i32_u
                  (array.len
                   (local.get $2)
                  )
                 )
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign1
                  (i64.extend_i32_u
                   (array.get_u $type29
                    (local.tee $2
                     (struct.get $type28 0
                      (local.get $1)
                     )
                    )
                    (i32.const 6)
                   )
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (local.get $2)
                    )
                   )
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign1
                    (i64.extend_i32_u
                     (array.get_u $type29
                      (local.tee $2
                       (struct.get $type28 0
                        (local.get $1)
                       )
                      )
                      (i32.const 7)
                     )
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $2)
                      )
                     )
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (i64.extend_i32_u
                       (array.get_u $type29
                        (local.tee $2
                         (struct.get $type28 0
                          (local.get $1)
                         )
                        )
                        (i32.const 8)
                       )
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $2)
                        )
                       )
                       (i64.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (i64.extend_i32_u
                         (array.get_u $type29
                          (struct.get $type28 0
                           (local.get $1)
                          )
                          (i32.const 9)
                         )
                        )
                       )
                       (call $function88
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 10)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $1)
 )
 (func $function88 (type $22) (param $0 (ref $type28)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 0
       (local.get $0)
      )
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (i64.extend_i32_u
      (array.get_u $type29
       (struct.get $type28 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function88
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function89 (type $call62) (param $0 i64) (param $1 (ref $type14)) (result (ref $type14))
  (call $foreign1
   (local.get $0)
  )
  (call $foreign1
   (local.tee $0
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $1)
     )
    )
   )
  )
  (drop
   (if (result i32)
    (i64.eqz
     (local.get $0)
    )
    (then
     (i32.const 0)
    )
    (else
     (if
      (i64.eqz
       (i64.extend_i32_u
        (struct.get $type14 1
         (local.get $1)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (call $foreign1
      (i64.extend_i32_u
       (array.get $type15
        (struct.get $type14 2
         (local.get $1)
        )
        (i32.const 0)
       )
      )
     )
     (if (result i32)
      (i64.eq
       (i64.extend_i32_u
        (struct.get $type14 1
         (local.get $1)
        )
       )
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (if
        (i64.le_u
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $1)
          )
         )
         (i64.const 1)
        )
        (then
         (unreachable)
        )
       )
       (call $foreign1
        (i64.extend_i32_u
         (array.get $type15
          (struct.get $type14 2
           (local.get $1)
          )
          (i32.const 1)
         )
        )
       )
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (struct.get $type14 1
           (local.get $1)
          )
         )
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (if
          (i64.le_u
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $1)
            )
           )
           (i64.const 2)
          )
          (then
           (unreachable)
          )
         )
         (call $foreign1
          (i64.extend_i32_u
           (array.get $type15
            (struct.get $type14 2
             (local.get $1)
            )
            (i32.const 2)
           )
          )
         )
         (if (result i32)
          (i64.eq
           (i64.extend_i32_u
            (struct.get $type14 1
             (local.get $1)
            )
           )
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (if
            (i64.le_u
             (i64.extend_i32_u
              (struct.get $type14 1
               (local.get $1)
              )
             )
             (i64.const 3)
            )
            (then
             (unreachable)
            )
           )
           (call $foreign1
            (i64.extend_i32_u
             (array.get $type15
              (struct.get $type14 2
               (local.get $1)
              )
              (i32.const 3)
             )
            )
           )
           (if (result i32)
            (i64.eq
             (i64.extend_i32_u
              (struct.get $type14 1
               (local.get $1)
              )
             )
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (if
              (i64.le_u
               (i64.extend_i32_u
                (struct.get $type14 1
                 (local.get $1)
                )
               )
               (i64.const 4)
              )
              (then
               (unreachable)
              )
             )
             (call $foreign1
              (i64.extend_i32_u
               (array.get $type15
                (struct.get $type14 2
                 (local.get $1)
                )
                (i32.const 4)
               )
              )
             )
             (if (result i32)
              (i64.eq
               (i64.extend_i32_u
                (struct.get $type14 1
                 (local.get $1)
                )
               )
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (if
                (i64.le_u
                 (i64.extend_i32_u
                  (struct.get $type14 1
                   (local.get $1)
                  )
                 )
                 (i64.const 5)
                )
                (then
                 (unreachable)
                )
               )
               (call $foreign1
                (i64.extend_i32_u
                 (array.get $type15
                  (struct.get $type14 2
                   (local.get $1)
                  )
                  (i32.const 5)
                 )
                )
               )
               (if (result i32)
                (i64.eq
                 (i64.extend_i32_u
                  (struct.get $type14 1
                   (local.get $1)
                  )
                 )
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (if
                  (i64.le_u
                   (i64.extend_i32_u
                    (struct.get $type14 1
                     (local.get $1)
                    )
                   )
                   (i64.const 6)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (call $foreign1
                  (i64.extend_i32_u
                   (array.get $type15
                    (struct.get $type14 2
                     (local.get $1)
                    )
                    (i32.const 6)
                   )
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (struct.get $type14 1
                     (local.get $1)
                    )
                   )
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if
                    (i64.le_u
                     (i64.extend_i32_u
                      (struct.get $type14 1
                       (local.get $1)
                      )
                     )
                     (i64.const 7)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (call $foreign1
                    (i64.extend_i32_u
                     (array.get $type15
                      (struct.get $type14 2
                       (local.get $1)
                      )
                      (i32.const 7)
                     )
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (struct.get $type14 1
                       (local.get $1)
                      )
                     )
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if
                      (i64.le_u
                       (i64.extend_i32_u
                        (struct.get $type14 1
                         (local.get $1)
                        )
                       )
                       (i64.const 8)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $foreign1
                      (i64.extend_i32_u
                       (array.get $type15
                        (struct.get $type14 2
                         (local.get $1)
                        )
                        (i32.const 8)
                       )
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (struct.get $type14 1
                         (local.get $1)
                        )
                       )
                       (i64.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (if
                        (i64.le_u
                         (i64.extend_i32_u
                          (struct.get $type14 1
                           (local.get $1)
                          )
                         )
                         (i64.const 9)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $foreign1
                        (i64.extend_i32_u
                         (array.get $type15
                          (call $string-block
                           (local.get $1)
                           (i32.const 9)
                          )
                          (i32.const 9)
                         )
                        )
                       )
                       (call $function90
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 10)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $1)
 )
 (func $function90 (type $24) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (i64.extend_i32_u
      (array.get $type15
       (call $string-block
        (local.get $0)
        (local.tee $4
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i32.and
        (local.get $4)
        (i32.const 8191)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function90
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function91 (type $call63) (result (ref $type28))
  (local $0 (ref $type29))
  (local $1 (ref $type28))
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (array.set $type29
   (struct.get $type28 0
    (local.tee $1
     (struct.new $type28
      (array.new_default $type29
       (i32.const 128)
      )
     )
    )
   )
   (i32.const 0)
   (i32.const 0)
  )
  (array.set $type29
   (local.tee $0
    (struct.get $type28 0
     (local.get $1)
    )
   )
   (i32.const 1)
   (i32.const 1)
  )
  (array.set $type29
   (local.get $0)
   (i32.const 2)
   (i32.const 2)
  )
  (array.set $type29
   (local.get $0)
   (i32.const 3)
   (i32.const 3)
  )
  (array.set $type29
   (local.get $0)
   (i32.const 4)
   (i32.const 4)
  )
  (array.set $type29
   (local.get $0)
   (i32.const 5)
   (i32.const 5)
  )
  (array.set $type29
   (local.get $0)
   (i32.const 6)
   (i32.const 6)
  )
  (array.set $type29
   (local.get $0)
   (i32.const 7)
   (i32.const 7)
  )
  (array.set $type29
   (local.get $0)
   (i32.const 8)
   (i32.const 8)
  )
  (array.set $type29
   (local.get $0)
   (i32.const 9)
   (i32.const 9)
  )
  (return_call $function92
   (local.get $1)
   (i32.const 0)
   (i32.const 1)
   (i64.const 10)
  )
 )
 (func $function92 (type $19) (param $0 (ref $type28)) (param $1 i32) (param $2 i32) (param $3 i64) (result (ref $type28))
  (local $4 i32)
  (if (result (ref $type28))
   (i64.eq
    (local.get $3)
    (i64.const 128)
   )
   (then
    (local.get $0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $0)
     )
     (local.tee $4
      (i32.wrap_i64
       (local.get $3)
      )
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function92
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function93 (type $call64) (param $0 (ref null $type23)) (result i32)
  (local $1 (ref $type14))
  (local $2 (ref null $type23))
  (call $foreign1
   (i64.const 7)
  )
  (if
   (i32.eqz
    (global.get $ready281)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global281)
   )
  )
  (call $foreign1
   (if (result i64)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i64.const 0)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $2
        (struct.get $type23 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $2
          (struct.get $type23 1
           (local.get $2)
          )
         )
        )
        (then
         (i64.const 2)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $2
            (struct.get $type23 1
             (local.get $2)
            )
           )
          )
          (then
           (i64.const 3)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $2
              (struct.get $type23 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 4)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $2
                (struct.get $type23 1
                 (local.get $2)
                )
               )
              )
              (then
               (i64.const 5)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $2
                  (struct.get $type23 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (i64.const 6)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type23 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type23 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (call $function95
                      (i32.const 0)
                      (i32.const 1)
                      (struct.get $type23 1
                       (local.get $2)
                      )
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $1
     (struct.get $type23 0
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready270)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global270)
     )
    )
    (drop
     (call $function89
      (i64.const 8)
      (local.get $1)
     )
    )
    (if (result i32)
     (ref.is_null
      (local.tee $0
       (struct.get $type23 1
        (local.get $0)
       )
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $1
       (struct.get $type23 0
        (local.get $0)
       )
      )
      (if
       (i32.eqz
        (global.get $ready270)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global270)
       )
      )
      (drop
       (call $function89
        (i64.const 8)
        (local.get $1)
       )
      )
      (if (result i32)
       (ref.is_null
        (local.tee $0
         (struct.get $type23 1
          (local.get $0)
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (local.set $1
         (struct.get $type23 0
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready270)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global270)
         )
        )
        (drop
         (call $function89
          (i64.const 8)
          (local.get $1)
         )
        )
        (if (result i32)
         (ref.is_null
          (local.tee $0
           (struct.get $type23 1
            (local.get $0)
           )
          )
         )
         (then
          (i32.const 0)
         )
         (else
          (local.set $1
           (struct.get $type23 0
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (global.get $ready270)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global270)
           )
          )
          (drop
           (call $function89
            (i64.const 8)
            (local.get $1)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.tee $0
             (struct.get $type23 1
              (local.get $0)
             )
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (local.set $1
             (struct.get $type23 0
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready270)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global270)
             )
            )
            (drop
             (call $function89
              (i64.const 8)
              (local.get $1)
             )
            )
            (if (result i32)
             (ref.is_null
              (local.tee $0
               (struct.get $type23 1
                (local.get $0)
               )
              )
             )
             (then
              (i32.const 0)
             )
             (else
              (local.set $1
               (struct.get $type23 0
                (local.get $0)
               )
              )
              (if
               (i32.eqz
                (global.get $ready270)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global270)
               )
              )
              (drop
               (call $function89
                (i64.const 8)
                (local.get $1)
               )
              )
              (if (result i32)
               (ref.is_null
                (local.tee $0
                 (struct.get $type23 1
                  (local.get $0)
                 )
                )
               )
               (then
                (i32.const 0)
               )
               (else
                (local.set $1
                 (struct.get $type23 0
                  (local.get $0)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready270)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global270)
                 )
                )
                (drop
                 (call $function89
                  (i64.const 8)
                  (local.get $1)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type23 1
                    (local.get $0)
                   )
                  )
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (local.set $1
                   (struct.get $type23 0
                    (local.get $0)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready270)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global270)
                   )
                  )
                  (drop
                   (call $function89
                    (i64.const 8)
                    (local.get $1)
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type23 1
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (local.set $1
                     (struct.get $type23 0
                      (local.get $0)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready270)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global270)
                     )
                    )
                    (drop
                     (call $function89
                      (i64.const 8)
                      (local.get $1)
                     )
                    )
                    (if (result i32)
                     (ref.is_null
                      (local.tee $0
                       (struct.get $type23 1
                        (local.get $0)
                       )
                      )
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (local.set $1
                       (struct.get $type23 0
                        (local.get $0)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready270)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global270)
                       )
                      )
                      (drop
                       (call $function89
                        (i64.const 8)
                        (local.get $1)
                       )
                      )
                      (return_call $function96
                       (i32.const 0)
                       (i32.const 1)
                       (struct.get $type23 1
                        (local.get $0)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function95 (type $16) (param $0 i32) (param $1 i32) (param $2 (ref null $type23)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type23 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function95
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function96 (type $15) (param $0 i32) (param $1 i32) (param $2 (ref null $type23)) (result i32)
  (local $3 (ref $type14))
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (struct.get $type23 0
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready270)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global270)
     )
    )
    (drop
     (call $function89
      (i64.const 8)
      (local.get $3)
     )
    )
    (local.set $2
     (struct.get $type23 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function96
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $function97 (type $14) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (result i32)
  (local $3 (ref $type65))
  (if
   (i32.eqz
    (global.get $ready246)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (if
   (i32.eqz
    (select
     (local.get $2)
     (i32.eqz
      (local.get $2)
     )
     (local.get $1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready256)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global256)
     )
    )
    (drop
     (call $function83
      (global.get $string0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready256)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global256)
     )
    )
    (drop
     (call $function83
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready260)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global260)
     )
    )
    (call $foreign0
     (i32.const 10)
    )
    (if
     (i32.eqz
      (global.get $ready288)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type65 0
     (ref.as_non_null
      (global.get $global288)
     )
     (block (result (ref (exact $type23)))
      (if
       (i32.eqz
        (global.get $ready288)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type23
       (local.get $0)
       (struct.get $type65 0
        (global.get $global288)
       )
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function98 (type $call67) (param $0 i64) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 (ref $type42))
  (local $4 (ref $type28))
  (local $scratch i64)
  (local $scratch_6 i64)
  (local $scratch_7 i64)
  (local $scratch_8 i64)
  (local $scratch_9 i64)
  (local $scratch_10 i64)
  (local $scratch_11 i64)
  (local $scratch_12 i64)
  (local $scratch_13 i64)
  (local $scratch_14 i64)
  (local $scratch_15 (ref $type28))
  (local $scratch_16 (ref $type28))
  (if
   (i32.eqz
    (global.get $ready261)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.new $type42
    (ref.func $function101)
    (struct.new $environment101
     (struct.new $type70
      (i32.const 1)
     )
     (struct.new $type72
      (i32.const 1)
      (struct.new $type59
       (i64.const 1)
      )
     )
     (struct.new $type71
      (i32.const 1)
      (i64.const 701)
     )
     (struct.new $type71
      (i32.const 1)
      (i64.const 743483)
     )
     (struct.new $type71
      (i32.const 1)
      (i64.const 524287)
     )
     (struct.new $type70
      (i32.const 1)
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (struct.get $type59 0
     (global.get $global261)
    )
    (i64.const 3)
   )
   (then
    (if (result i32)
     (i64.eqz
      (local.get $0)
     )
     (then
      (i32.const 0)
     )
     (else
      (call $foreign1
       (block (result i64)
        (local.set $scratch
         (call $function101
          (struct.get $type42 1
           (local.get $3)
          )
          (local.get $1)
         )
        )
        (call $foreign1
         (i64.const 5)
        )
        (local.get $scratch)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $0)
        (i64.const 1)
       )
       (then
        (i32.const 0)
       )
       (else
        (call $foreign1
         (block (result i64)
          (local.set $scratch_6
           (call $function101
            (struct.get $type42 1
             (local.get $3)
            )
            (local.get $1)
           )
          )
          (call $foreign1
           (i64.const 5)
          )
          (local.get $scratch_6)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $0)
          (i64.const 2)
         )
         (then
          (i32.const 0)
         )
         (else
          (call $foreign1
           (block (result i64)
            (local.set $scratch_7
             (call $function101
              (struct.get $type42 1
               (local.get $3)
              )
              (local.get $1)
             )
            )
            (call $foreign1
             (i64.const 5)
            )
            (local.get $scratch_7)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $0)
            (i64.const 3)
           )
           (then
            (i32.const 0)
           )
           (else
            (call $foreign1
             (block (result i64)
              (local.set $scratch_8
               (call $function101
                (struct.get $type42 1
                 (local.get $3)
                )
                (local.get $1)
               )
              )
              (call $foreign1
               (i64.const 5)
              )
              (local.get $scratch_8)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $0)
              (i64.const 4)
             )
             (then
              (i32.const 0)
             )
             (else
              (call $foreign1
               (block (result i64)
                (local.set $scratch_9
                 (call $function101
                  (struct.get $type42 1
                   (local.get $3)
                  )
                  (local.get $1)
                 )
                )
                (call $foreign1
                 (i64.const 5)
                )
                (local.get $scratch_9)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $0)
                (i64.const 5)
               )
               (then
                (i32.const 0)
               )
               (else
                (call $foreign1
                 (block (result i64)
                  (local.set $scratch_10
                   (call $function101
                    (struct.get $type42 1
                     (local.get $3)
                    )
                    (local.get $1)
                   )
                  )
                  (call $foreign1
                   (i64.const 5)
                  )
                  (local.get $scratch_10)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $0)
                  (i64.const 6)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (call $foreign1
                   (block (result i64)
                    (local.set $scratch_11
                     (call $function101
                      (struct.get $type42 1
                       (local.get $3)
                      )
                      (local.get $1)
                     )
                    )
                    (call $foreign1
                     (i64.const 5)
                    )
                    (local.get $scratch_11)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $0)
                    (i64.const 7)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign1
                     (block (result i64)
                      (local.set $scratch_12
                       (call $function101
                        (struct.get $type42 1
                         (local.get $3)
                        )
                        (local.get $1)
                       )
                      )
                      (call $foreign1
                       (i64.const 5)
                      )
                      (local.get $scratch_12)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $0)
                      (i64.const 8)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign1
                       (block (result i64)
                        (local.set $scratch_13
                         (call $function101
                          (struct.get $type42 1
                           (local.get $3)
                          )
                          (local.get $1)
                         )
                        )
                        (call $foreign1
                         (i64.const 5)
                        )
                        (local.get $scratch_13)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $0)
                        (i64.const 9)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (call $foreign1
                         (block (result i64)
                          (local.set $scratch_14
                           (call $function101
                            (struct.get $type42 1
                             (local.get $3)
                            )
                            (local.get $1)
                           )
                          )
                          (call $foreign1
                           (i64.const 5)
                          )
                          (local.get $scratch_14)
                         )
                        )
                        (return_call $function111
                         (local.get $0)
                         (local.get $1)
                         (local.get $3)
                         (i32.const 1)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.const 10)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready261)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.eq
      (struct.get $type59 0
       (global.get $global261)
      )
      (i64.const 6)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready275)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global275)
       )
      )
      (return_call $function99
       (block (result (ref $type28))
        (local.set $scratch_15
         (call $function91)
        )
        (if
         (i32.eqz
          (global.get $ready207)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global207)
         )
        )
        (if
         (i32.eqz
          (global.get $ready244)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global244)
         )
        )
        (local.get $scratch_15)
       )
      )
     )
     (else
      (drop
       (call $function99
        (block (result (ref $type28))
         (local.set $scratch_16
          (call $function110
           (local.get $3)
           (i32.const 1)
           (i32.const 1)
           (i32.const 1)
           (i32.const 1)
           (i64.const 10)
          )
         )
         (if
          (i32.eqz
           (global.get $ready207)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global207)
          )
         )
         (if
          (i32.eqz
           (global.get $ready244)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global244)
          )
         )
         (local.get $scratch_16)
        )
       )
      )
      (return_call $function112
       (local.get $0)
       (local.get $1)
       (i32.const 0)
       (i32.const 1)
       (local.get $3)
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function99 (type $8) (param $0 (ref $type28)) (result i32)
  (local $1 (ref $type14))
  (local $2 (ref $type14))
  (local $3 (ref $type14))
  (local $4 (ref $type28))
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (if
   (i32.eqz
    (global.get $ready265)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global265)
   )
  )
  (local.set $0
   (call $function87
    (i64.const 1)
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready164)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (local.set $2
   (call $function57
    (local.get $0)
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 0
       (local.get $0)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready270)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global270)
   )
  )
  (local.set $1
   (call $function89
    (i64.const 2)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready217)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global217)
   )
  )
  (local.set $5
   (i64.extend_i32_u
    (struct.get $type14 1
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $6
   (i64.extend_i32_u
    (struct.get $type14 1
     (local.get $1)
    )
   )
  )
  (if
   (i64.gt_s
    (local.get $5)
    (local.get $6)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready222)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global222)
   )
  )
  (local.set $6
   (call $function74
    (local.get $1)
    (local.get $5)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready231)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global231)
   )
  )
  (drop
   (call $function77
    (local.tee $4
     (struct.new $type28
      (array.new_default $type29
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
    )
    (local.get $1)
    (local.get $5)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready265)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global265)
   )
  )
  (local.set $0
   (call $function87
    (i64.const 3)
    (local.get $4)
   )
  )
  (if
   (i32.eqz
    (global.get $ready164)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (local.set $2
   (call $function57
    (local.get $0)
    (i64.extend_i32_u
     (array.len
      (struct.get $type28 0
       (local.get $0)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready270)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global270)
   )
  )
  (local.set $3
   (call $function89
    (i64.const 4)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready103)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global103)
   )
  )
  (local.set $7
   (if (result i32)
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $1)
      )
     )
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $3)
      )
     )
    )
    (then
     (call $function40
      (local.get $1)
      (local.get $3)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready289)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global289)
   )
  )
  (return_call $function97
   (global.get $string1)
   (local.get $7)
   (i32.const 1)
  )
 )
 (func $function100 (type $7) (param $0 (ref $type72)) (param $1 (ref $type71)) (param $2 (ref $type71)) (param $3 (ref $type71)) (param $4 i64) (result i64)
  (local $5 (ref $type59))
  (local $6 i64)
  (local $scratch i64)
  (struct.set $type59 0
   (local.tee $5
    (struct.get $type72 1
     (local.get $0)
    )
   )
   (i64.rem_s
    (i64.add
     (i64.mul
      (struct.get $type71 1
       (local.get $1)
      )
      (struct.get $type59 0
       (local.get $5)
      )
     )
     (struct.get $type71 1
      (local.get $2)
     )
    )
    (i64.add
     (struct.get $type71 1
      (local.get $3)
     )
     (i64.const 1)
    )
   )
  )
  (local.set $4
   (i64.rem_s
    (i64.div_s
     (struct.get $type59 0
      (struct.get $type72 1
       (local.get $0)
      )
     )
     (i64.const 8)
    )
    (local.get $4)
   )
  )
  (if
   (i32.eqz
    (global.get $ready262)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign1
   (block (result i64)
    (local.set $scratch
     (struct.get $type59 0
      (struct.get $type72 1
       (local.get $0)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global262)
     )
    )
    (call $foreign1
     (i64.const 0)
    )
    (local.get $scratch)
   )
  )
  (call $foreign1
   (local.get $4)
  )
  (local.get $4)
 )
 (func $function101 (type $call42) (param $0 (ref null $environment101)) (param $1 i64) (result i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 (ref $type72))
  (local $5 (ref $type71))
  (local $6 (ref $type71))
  (local $7 (ref $type71))
  (local $8 (ref $type70))
  (local $9 (ref $type70))
  (if (result i64)
   (i64.lt_s
    (local.get $1)
    (i64.const 16384)
   )
   (then
    (drop
     (struct.get $environment101 0
      (local.get $0)
     )
    )
    (return_call $function100
     (struct.get $environment101 1
      (local.get $0)
     )
     (struct.get $environment101 2
      (local.get $0)
     )
     (struct.get $environment101 3
      (local.get $0)
     )
     (struct.get $environment101 4
      (local.get $0)
     )
     (local.get $1)
    )
   )
   (else
    (local.set $8
     (struct.get $environment101 0
      (local.get $0)
     )
    )
    (local.set $2
     (call $function100
      (local.tee $4
       (struct.get $environment101 1
        (local.get $0)
       )
      )
      (local.tee $5
       (struct.get $environment101 2
        (local.get $0)
       )
      )
      (local.tee $6
       (struct.get $environment101 3
        (local.get $0)
       )
      )
      (local.tee $7
       (struct.get $environment101 4
        (local.get $0)
       )
      )
      (i64.const 16384)
     )
    )
    (local.set $9
     (struct.get $environment101 5
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready316)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global316)
     )
    )
    (if (result i64)
     (i64.eqz
      (local.tee $3
       (i64.div_s
        (local.get $1)
        (i64.const 16384)
       )
      )
     )
     (then
      (i64.rem_s
       (local.get $2)
       (local.get $1)
      )
     )
     (else
      (local.set $2
       (i64.add
        (call $function100
         (local.get $4)
         (local.get $5)
         (local.get $6)
         (local.get $7)
         (i64.const 16384)
        )
        (i64.shl
         (local.get $2)
         (i64.const 14)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready316)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global316)
       )
      )
      (if (result i64)
       (i64.eqz
        (local.tee $3
         (i64.div_s
          (local.get $3)
          (i64.const 16384)
         )
        )
       )
       (then
        (i64.rem_s
         (local.get $2)
         (local.get $1)
        )
       )
       (else
        (local.set $2
         (i64.add
          (call $function100
           (local.get $4)
           (local.get $5)
           (local.get $6)
           (local.get $7)
           (i64.const 16384)
          )
          (i64.shl
           (local.get $2)
           (i64.const 14)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready316)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global316)
         )
        )
        (if (result i64)
         (i64.eqz
          (local.tee $3
           (i64.div_s
            (local.get $3)
            (i64.const 16384)
           )
          )
         )
         (then
          (i64.rem_s
           (local.get $2)
           (local.get $1)
          )
         )
         (else
          (local.set $2
           (i64.add
            (call $function100
             (local.get $4)
             (local.get $5)
             (local.get $6)
             (local.get $7)
             (i64.const 16384)
            )
            (i64.shl
             (local.get $2)
             (i64.const 14)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready316)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global316)
           )
          )
          (if (result i64)
           (i64.eqz
            (local.tee $3
             (i64.div_s
              (local.get $3)
              (i64.const 16384)
             )
            )
           )
           (then
            (i64.rem_s
             (local.get $2)
             (local.get $1)
            )
           )
           (else
            (local.set $3
             (i64.div_s
              (local.get $3)
              (i64.const 16384)
             )
            )
            (local.set $2
             (i64.add
              (call $function100
               (local.get $4)
               (local.get $5)
               (local.get $6)
               (local.get $7)
               (i64.const 16384)
              )
              (i64.shl
               (local.get $2)
               (i64.const 14)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready316)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global316)
             )
            )
            (if (result i64)
             (i64.eqz
              (local.get $3)
             )
             (then
              (i64.rem_s
               (local.get $2)
               (local.get $1)
              )
             )
             (else
              (return_call $function102
               (local.get $8)
               (local.get $4)
               (local.get $5)
               (local.get $6)
               (local.get $7)
               (local.get $9)
               (i64.div_s
                (local.get $3)
                (i64.const 16384)
               )
               (i64.add
                (call $function100
                 (local.get $4)
                 (local.get $5)
                 (local.get $6)
                 (local.get $7)
                 (i64.const 16384)
                )
                (i64.shl
                 (local.get $2)
                 (i64.const 14)
                )
               )
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function102 (type $6) (param $0 (ref $type70)) (param $1 (ref $type72)) (param $2 (ref $type71)) (param $3 (ref $type71)) (param $4 (ref $type71)) (param $5 (ref $type70)) (param $6 i64) (param $7 i64) (param $8 i64) (result i64)
  (if
   (i32.eqz
    (global.get $ready316)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global316)
   )
  )
  (if (result i64)
   (i64.eqz
    (local.get $6)
   )
   (then
    (i64.rem_s
     (local.get $7)
     (local.get $8)
    )
   )
   (else
    (return_call $function102
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.div_s
      (local.get $6)
      (i64.const 16384)
     )
     (i64.add
      (call $function100
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i64.const 16384)
      )
      (i64.shl
       (local.get $7)
       (i64.const 14)
      )
     )
     (local.get $8)
    )
   )
  )
 )
 (func $function105 (type $5) (param $0 (ref $type42)) (param $1 i32) (param $2 i64) (param $3 (ref $type28)) (param $4 i32) (param $5 i32) (param $6 i64) (result (ref $type28))
  (local $7 i64)
  (if (result (ref $type28))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call_ref $call42
      (struct.get $type42 1
       (local.get $0)
      )
      (i64.const 128)
      (struct.get $type42 0
       (local.get $0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function105
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function107 (type $5) (param $0 (ref $type42)) (param $1 i32) (param $2 i64) (param $3 (ref $type28)) (param $4 i32) (param $5 i32) (param $6 i64) (result (ref $type28))
  (local $7 i64)
  (if (result (ref $type28))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call_ref $call42
      (struct.get $type42 1
       (local.get $0)
      )
      (i64.const 128)
      (struct.get $type42 0
       (local.get $0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function107
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function109 (type $5) (param $0 (ref $type42)) (param $1 i32) (param $2 i64) (param $3 (ref $type28)) (param $4 i32) (param $5 i32) (param $6 i64) (result (ref $type28))
  (local $7 i64)
  (if (result (ref $type28))
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (call_ref $call42
      (struct.get $type42 1
       (local.get $0)
      )
      (i64.const 128)
      (struct.get $type42 0
       (local.get $0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $6)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $7)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type29
     (struct.get $type28 0
      (local.get $3)
     )
     (i32.wrap_i64
      (local.get $6)
     )
     (i32.wrap_i64
      (local.get $7)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function109
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function110 (type $4) (param $0 (ref null $type42)) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type28))
  (local $6 (ref $type42))
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready261)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.eq
    (struct.get $type59 0
     (global.get $global261)
    )
    (i64.const 1)
   )
   (then
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call_ref $call42
      (struct.get $type42 1
       (local.tee $6
        (ref.as_non_null
         (local.get $0)
        )
       )
      )
      (local.get $5)
      (struct.get $type42 0
       (local.get $6)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready249)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global249)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (if
     (i64.gt_u
      (local.tee $5
       (select
        (i64.add
         (local.get $5)
         (i64.const 1)
        )
        (local.get $5)
        (i32.wrap_i64
         (i64.and
          (local.get $5)
          (i64.const 1)
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function107
     (local.get $6)
     (local.get $1)
     (local.get $5)
     (struct.new $type28
      (array.new_default $type29
       (i32.wrap_i64
        (local.get $5)
       )
      )
     )
     (i32.const 0)
     (i32.const 1)
     (i64.const 0)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready261)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.eq
      (struct.get $type59 0
       (global.get $global261)
      )
      (i64.const 2)
     )
     (then
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (call_ref $call42
        (struct.get $type42 1
         (local.tee $6
          (ref.as_non_null
           (local.get $0)
          )
         )
        )
        (local.get $5)
        (struct.get $type42 0
         (local.get $6)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready251)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (struct.get $type42 1
        (global.get $global251)
       )
      )
      (local.set $5
       (select
        (i64.add
         (local.tee $7
          (i64.div_s
           (local.get $5)
           (i64.const 4)
          )
         )
         (i64.const 1)
        )
        (local.get $7)
        (if (result i32)
         (local.tee $2
          (i64.gt_s
           (local.tee $5
            (i64.rem_s
             (local.get $5)
             (i64.const 4)
            )
           )
           (i64.const 2)
          )
         )
         (then
          (local.get $2)
         )
         (else
          (if (result i32)
           (i64.eq
            (local.get $5)
            (i64.const 2)
           )
           (then
            (if
             (i32.eqz
              (global.get $ready249)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global249)
             )
            )
            (i32.wrap_i64
             (i64.and
              (local.get $7)
              (i64.const 1)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global109)
       )
      )
      (return_call $function109
       (local.get $6)
       (local.get $1)
       (local.tee $5
        (i64.shl
         (local.get $5)
         (i64.const 2)
        )
       )
       (block (result (ref (exact $type28)))
        (if
         (i64.gt_u
          (local.get $5)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type28
         (array.new_default $type29
          (i32.wrap_i64
           (local.get $5)
          )
         )
        )
       )
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (call_ref $call42
        (struct.get $type42 1
         (local.tee $6
          (ref.as_non_null
           (local.get $0)
          )
         )
        )
        (local.get $5)
        (struct.get $type42 0
         (local.get $6)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global109)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function105
       (local.get $6)
       (local.get $1)
       (local.get $5)
       (struct.new $type28
        (array.new_default $type29
         (i32.wrap_i64
          (local.get $5)
         )
        )
       )
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
      )
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function111 (type $3) (param $0 i64) (param $1 i64) (param $2 (ref $type42)) (param $3 i32) (param $4 i32) (param $5 i32) (param $6 i64) (result i32)
  (local $7 i64)
  (local $scratch i64)
  (if (result i32)
   (i64.eq
    (local.get $0)
    (local.get $6)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (block (result i64)
      (local.set $scratch
       (call_ref $call42
        (struct.get $type42 1
         (local.get $2)
        )
        (local.get $1)
        (struct.get $type42 0
         (local.get $2)
        )
       )
      )
      (call $foreign1
       (i64.const 5)
      )
      (local.get $scratch)
     )
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function111
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function112 (type $2) (param $0 i64) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 (ref null $type42)) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 i32) (param $10 i32) (param $11 i32) (param $12 i32) (param $13 i32) (param $14 i32) (param $15 i32) (param $16 i64) (result i32)
  (local $17 (ref $type28))
  (local $scratch (ref $type28))
  (if (result i32)
   (i64.eq
    (local.get $0)
    (local.get $16)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $13)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function99
      (block (result (ref $type28))
       (local.set $scratch
        (call $function110
         (local.get $4)
         (local.get $5)
         (local.get $7)
         (local.get $9)
         (local.get $11)
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready207)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global207)
        )
       )
       (if
        (i32.eqz
         (global.get $ready244)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global244)
        )
       )
       (if
        (i32.eqz
         (local.get $3)
        )
        (then
         (unreachable)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $15)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function112
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (local.get $10)
     (local.get $11)
     (local.get $12)
     (local.get $13)
     (local.get $14)
     (local.get $15)
     (i64.add
      (local.get $16)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function114 (type $call69) (param $0 i64) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref null $type23))
  (local $4 (ref $type14))
  (local $5 i32)
  (local $scratch (ref null $type23))
  (if
   (i32.eqz
    (global.get $ready261)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type59 0
   (global.get $global261)
   (local.get $0)
  )
  (drop
   (if (result i32)
    (i64.eq
     (local.get $0)
     (i64.const 4)
    )
    (then
     (if
      (i32.eqz
       (global.get $ready350)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global350)
      )
     )
     (if (result i32)
      (i64.eqz
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $foreign1
        (i64.const 6)
       )
       (call $foreign1
        (i64.const 0)
       )
       (if
        (i32.eqz
         (global.get $ready251)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (struct.get $type42 1
         (global.get $global251)
        )
       )
       (call $foreign1
        (i64.const 0)
       )
       (if (result i32)
        (i64.eq
         (local.get $1)
         (i64.const 1)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign1
          (i64.const 6)
         )
         (call $foreign1
          (i64.const 1)
         )
         (if
          (i32.eqz
           (global.get $ready251)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (struct.get $type42 1
           (global.get $global251)
          )
         )
         (call $foreign1
          (i64.const 0)
         )
         (if (result i32)
          (i64.eq
           (local.get $1)
           (i64.const 2)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign1
            (i64.const 6)
           )
           (call $foreign1
            (i64.const 2)
           )
           (if
            (i32.eqz
             (global.get $ready251)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (struct.get $type42 1
             (global.get $global251)
            )
           )
           (if
            (i32.eqz
             (global.get $ready249)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global249)
            )
           )
           (call $foreign1
            (i64.const 0)
           )
           (if (result i32)
            (i64.eq
             (local.get $1)
             (i64.const 3)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign1
              (i64.const 6)
             )
             (call $foreign1
              (i64.const 3)
             )
             (if
              (i32.eqz
               (global.get $ready251)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (struct.get $type42 1
               (global.get $global251)
              )
             )
             (call $foreign1
              (i64.const 1)
             )
             (if (result i32)
              (i64.eq
               (local.get $1)
               (i64.const 4)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign1
                (i64.const 6)
               )
               (call $foreign1
                (i64.const 4)
               )
               (if
                (i32.eqz
                 (global.get $ready251)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (struct.get $type42 1
                 (global.get $global251)
                )
               )
               (call $foreign1
                (i64.const 1)
               )
               (if (result i32)
                (i64.eq
                 (local.get $1)
                 (i64.const 5)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign1
                  (i64.const 6)
                 )
                 (call $foreign1
                  (i64.const 5)
                 )
                 (if
                  (i32.eqz
                   (global.get $ready251)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (struct.get $type42 1
                   (global.get $global251)
                  )
                 )
                 (call $foreign1
                  (i64.const 1)
                 )
                 (if (result i32)
                  (i64.eq
                   (local.get $1)
                   (i64.const 6)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign1
                    (i64.const 6)
                   )
                   (call $foreign1
                    (i64.const 6)
                   )
                   (if
                    (i32.eqz
                     (global.get $ready251)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (struct.get $type42 1
                     (global.get $global251)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready249)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global249)
                    )
                   )
                   (call $foreign1
                    (i64.const 2)
                   )
                   (if (result i32)
                    (i64.eq
                     (local.get $1)
                     (i64.const 7)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign1
                      (i64.const 6)
                     )
                     (call $foreign1
                      (i64.const 7)
                     )
                     (if
                      (i32.eqz
                       (global.get $ready251)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (struct.get $type42 1
                       (global.get $global251)
                      )
                     )
                     (call $foreign1
                      (i64.const 2)
                     )
                     (if (result i32)
                      (i64.eq
                       (local.get $1)
                       (i64.const 8)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign1
                        (i64.const 6)
                       )
                       (call $foreign1
                        (i64.const 8)
                       )
                       (if
                        (i32.eqz
                         (global.get $ready251)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $foreign1
                        (call $function82
                         (struct.get $type42 1
                          (global.get $global251)
                         )
                         (i64.const 8)
                        )
                       )
                       (call $function116
                        (local.get $1)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (else
     (if (result i32)
      (i64.eq
       (local.get $0)
       (i64.const 5)
      )
      (then
       (if
        (i32.eqz
         (global.get $ready345)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global345)
        )
       )
       (if
        (i32.eqz
         (global.get $ready103)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global103)
        )
       )
       (if
        (i32.eqz
         (global.get $ready289)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global289)
        )
       )
       (drop
        (call $function97
         (global.get $string6)
         (i32.const 0)
         (i32.const 1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready289)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global289)
        )
       )
       (drop
        (call $function97
         (global.get $string5)
         (i32.const 1)
         (i32.const 1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready103)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global103)
        )
       )
       (local.set $5
        (call $function40
         (local.tee $4
          (global.get $string4)
         )
         (local.get $4)
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready289)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global289)
        )
       )
       (drop
        (call $function97
         (global.get $string3)
         (local.get $5)
         (i32.const 0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready289)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global289)
        )
       )
       (call $function97
        (global.get $string2)
        (i32.const 0)
        (i32.const 0)
       )
      )
      (else
       (if
        (i32.eqz
         (global.get $ready293)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global293)
        )
       )
       (drop
        (call $function98
         (local.get $1)
         (local.get $2)
        )
       )
       (if
        (i64.eq
         (local.get $0)
         (i64.const 7)
        )
        (then
         (if
          (i32.eqz
           (global.get $ready293)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global293)
          )
         )
         (drop
          (call $function98
           (local.get $1)
           (local.get $2)
          )
         )
        )
       )
       (i32.const 0)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready288)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call $function93
    (block (result (ref null $type23))
     (local.set $scratch
      (struct.get $type65 0
       (global.get $global288)
      )
     )
     (if
      (i32.eqz
       (global.get $ready279)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global279)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready288)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type65 0
    (global.get $global288)
   )
  )
  (if
   (i32.eqz
    (global.get $ready281)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global281)
   )
  )
  (if (result i64)
   (ref.is_null
    (local.get $3)
   )
   (then
    (i64.const 0)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.tee $3
       (struct.get $type23 1
        (local.get $3)
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (ref.is_null
        (local.tee $3
         (struct.get $type23 1
          (local.get $3)
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (ref.is_null
          (local.tee $3
           (struct.get $type23 1
            (local.get $3)
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (if (result i64)
           (ref.is_null
            (local.tee $3
             (struct.get $type23 1
              (local.get $3)
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (if (result i64)
             (ref.is_null
              (local.tee $3
               (struct.get $type23 1
                (local.get $3)
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (if (result i64)
               (ref.is_null
                (local.tee $3
                 (struct.get $type23 1
                  (local.get $3)
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (ref.is_null
                  (local.tee $3
                   (struct.get $type23 1
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (if (result i64)
                   (ref.is_null
                    (local.tee $3
                     (struct.get $type23 1
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (return_call $function95
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type23 1
                      (local.get $3)
                     )
                     (i64.const 9)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function116 (type $0) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (local.get $0)
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign1
     (i64.const 6)
    )
    (call $foreign1
     (local.get $3)
    )
    (if
     (i32.eqz
      (global.get $ready251)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (call $function82
      (struct.get $type42 1
       (global.get $global251)
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function116
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (param $1 i64) (param $2 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready346)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global346)
   )
  )
  (return_call $function114
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type26)
  )
  (global.set $ready103
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type27)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type33)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global182
   (struct.new $type42
    (ref.func $function61)
    (ref.null none)
   )
  )
  (global.set $ready182
   (i32.const 1)
  )
  (global.set $global188
   (struct.new $type42
    (ref.func $function63)
    (ref.null none)
   )
  )
  (global.set $ready188
   (i32.const 1)
  )
  (global.set $global193
   (struct.new $type42
    (ref.func $function65)
    (ref.null none)
   )
  )
  (global.set $ready193
   (i32.const 1)
  )
  (global.set $global177
   (struct.new_default $type43)
  )
  (global.set $ready177
   (i32.const 1)
  )
  (global.set $global159
   (struct.new_default $type44)
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global184
   (struct.new_default $type45)
  )
  (global.set $ready184
   (i32.const 1)
  )
  (global.set $global169
   (struct.new_default $type43)
  )
  (global.set $ready169
   (i32.const 1)
  )
  (global.set $global195
   (struct.new_default $type46)
  )
  (global.set $ready195
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type47)
  )
  (global.set $ready164
   (i32.const 1)
  )
  (global.set $global207
   (struct.new_default $type49)
  )
  (global.set $ready207
   (i32.const 1)
  )
  (global.set $global229
   (struct.new $type42
    (ref.func $function75)
    (ref.null none)
   )
  )
  (global.set $ready229
   (i32.const 1)
  )
  (global.set $global222
   (struct.new_default $type50)
  )
  (global.set $ready222
   (i32.const 1)
  )
  (global.set $global209
   (struct.new_default $type51)
  )
  (global.set $ready209
   (i32.const 1)
  )
  (global.set $global231
   (struct.new_default $type52)
  )
  (global.set $ready231
   (i32.const 1)
  )
  (global.set $global217
   (struct.new_default $type53)
  )
  (global.set $ready217
   (i32.const 1)
  )
  (global.set $global244
   (struct.new_default $type55)
  )
  (global.set $ready244
   (i32.const 1)
  )
  (global.set $global281
   (struct.new_default $type24)
  )
  (global.set $ready281
   (i32.const 1)
  )
  (global.set $global246
   (struct.new_default $type56)
  )
  (global.set $ready246
   (i32.const 1)
  )
  (global.set $global316
   (struct.new_default $type57)
  )
  (global.set $ready316
   (i32.const 1)
  )
  (global.set $global249
   (struct.new_default $type57)
  )
  (global.set $ready249
   (i32.const 1)
  )
  (global.set $global251
   (struct.new $type42
    (ref.func $function82)
    (ref.null none)
   )
  )
  (global.set $ready251
   (i32.const 1)
  )
  (global.set $global256
   (struct.new_default $type58)
  )
  (global.set $ready256
   (i32.const 1)
  )
  (global.set $global260
   (struct.new_default $type10)
  )
  (global.set $ready260
   (i32.const 1)
  )
  (global.set $global261
   (struct.new_default $type59)
  )
  (global.set $ready261
   (i32.const 1)
  )
  (global.set $global262
   (struct.new_default $type60)
  )
  (global.set $ready262
   (i32.const 1)
  )
  (global.set $global265
   (struct.new_default $type61)
  )
  (global.set $ready265
   (i32.const 1)
  )
  (global.set $global270
   (struct.new_default $type62)
  )
  (global.set $ready270
   (i32.const 1)
  )
  (global.set $global275
   (struct.new_default $type63)
  )
  (global.set $ready275
   (i32.const 1)
  )
  (global.set $global279
   (struct.new_default $type64)
  )
  (global.set $ready279
   (i32.const 1)
  )
  (global.set $global288
   (struct.new_default $type65)
  )
  (global.set $ready288
   (i32.const 1)
  )
  (global.set $global289
   (struct.new_default $type66)
  )
  (global.set $ready289
   (i32.const 1)
  )
  (global.set $global293
   (struct.new_default $type67)
  )
  (global.set $ready293
   (i32.const 1)
  )
  (global.set $global350
   (struct.new_default $type68)
  )
  (global.set $ready350
   (i32.const 1)
  )
  (global.set $global345
   (struct.new_default $type10)
  )
  (global.set $ready345
   (i32.const 1)
  )
  (global.set $global346
   (struct.new_default $type69)
  )
  (global.set $ready346
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

