#include "native-provider.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static uint64_t barriers, observations;
static FILE *expected;
int64_t input_i64(int32_t index) {
    static const int64_t inputs[] = {0, 0, 0};
    assert(index >= 0 && index < 3);
    return inputs[index];
}
int64_t hide_i64(int64_t value) { barriers++; return value; }
uint64_t barrier_count(void) { return barriers; }
void write_character(uint32_t value) {
    if (value < 128) { putchar(value); return; }
    unsigned width = value < 2048 ? 2 : value < 65536 ? 3 : 4;
    unsigned first[] = {0, 0, 192, 224, 240};
    putchar(first[width] | (value >> (6 * (width - 1))));
    for (unsigned index = width - 1; index; index--)
        putchar(128 | ((value >> (6 * (index - 1))) & 63));
}
void observation_file(const char *path) {
    expected = fopen(path, "rb"); assert(expected);
}
void observe(int64_t actual) {
    unsigned char bytes[4];
    size_t size = fread(bytes, 1, 4, expected);
    uint32_t value = size == 4 ? ((uint32_t)bytes[0] | ((uint32_t)bytes[1] << 8)
                      | ((uint32_t)bytes[2] << 16) | ((uint32_t)bytes[3] << 24)) : 0;
    if (size != 4 || actual != value) {
        fprintf(stderr, "observation %llu: actual %lld, expected %u, bytes %zu\n",
                (unsigned long long)observations, (long long)actual, value, size);
        exit(80);
    }
    observations++;
}
uint64_t observation_count(void) {
    assert(fgetc(expected) == EOF); fclose(expected); return observations;
}
