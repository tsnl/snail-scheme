(import (snail strict) (snail bytes))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(: bv-same-bool? (-> Bool Bool Bool))
(define (bv-same-bool? actual expected) (if actual expected (not expected)))
(define (bv-zero? value) (= value 0))
(define (bv-odd? value) (not (= (remainder value 2) 0)))
;; The generator supplies a nonnegative integer. Rational round(n/4) chooses
;; the even quotient at a tie: 2 -> 0, 6 -> 2, 10 -> 2, 14 -> 4.
(define (bv-round-quarter value)
  (let ((whole (quotient value 4)) (part (remainder value 4)))
    (if (or (> part 2) (and (= part 2) (bv-odd? whole))) (+ whole 1) whole)))
(define-extern bv-write-character "benchmark" "write_character" (-> Char Unit))
(: bv-display (-> String Unit))
(define (bv-display text)
  (let loop ((index 0))
    (unless (= index (string-length text))
      (bv-write-character (string-ref text index))
      (loop (+ index 1)))))
(define (bv-newline) (bv-write-character #\newline))
(define-extern bv-observe "benchmark" "observe" (-> I64 Unit))
(define probe-mode (ref 0))
(define (bv-observe-random state value)
  (bv-observe 0) (bv-observe state) (bv-observe value) value)
(define (bv-observe-bytes tag bytes)
  (bv-observe tag) (bv-observe (bytevector-length bytes))
  (let loop ((index 0))
    (unless (= index (bytevector-length bytes))
      (bv-observe (bytevector-u8-ref bytes index)) (loop (+ index 1)))) bytes)
(define (bv-observe-string tag text)
  (bv-observe tag) (bv-observe (string-length text))
  (let loop ((index 0))
    (unless (= index (string-length text))
      (bv-observe (char->integer (string-ref text index))) (loop (+ index 1)))) text)
(define (bv-ascii)
  (let ((bytes (make-bytevector 128)))
    (let loop ((index 0))
      (if (= index 128) bytes
          (begin (bytevector-u8-set! bytes index index) (loop (+ index 1)))))))
(define (bv-observe-failures names)
  (bv-observe 7) (bv-observe (length names))
  (let loop ((names names))
    (unless (null? names)
      (bv-observe-string 8 (car names)) (loop (cdr names)))))
(: test (-> String Bool Bool Unit))
(: string-bytevector-tests (-> I64 I64 Unit))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Copyright 2007 William D Clinger.
;;
;; Permission to copy this software, in whole or in part, to use this
;; software for any lawful purpose, and to redistribute this software
;; is granted subject to the restriction that all copies made of this
;; software must include this copyright notice in full.
;;
;; I also request that you send me a copy of any improvements that you
;; make to this software so that they may be incorporated within it to
;; the benefit of the Scheme community.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Tests of string <-> bytevector conversions.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


;; Crude test rig, just for benchmarking.

(define failed-tests (ref (ann '() (List String))))

(define (test name actual expected)
  (unless (bv-same-bool? actual expected)
    (bv-display "******** FAILED TEST ******** ")
    (bv-display name)
    (bv-newline)
    (ref-set! failed-tests (cons name (ref-get failed-tests)))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; We're limited to Ascii strings here because the R7RS doesn't
;; actually require anything beyond Ascii.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Basic sanity tests, followed by stress tests on random inputs.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(define (string-bytevector-tests
         *random-stress-tests* *random-stress-test-max-size*)

  (define (test-roundtrip bvec tostring tobvec)
    (let* ((observed (bv-observe-bytes 1 bvec))
           (s1 (bv-observe-string 2 (tostring observed)))
           (b2 (bv-observe-bytes 3 (tobvec s1)))
           (s2 (bv-observe-string 4 (tostring b2))))
      (test "round trip of string conversion" (string=? s1 s2) #t)))

  ;; This random number generator doesn't have to be good.
  ;; It just has to be fast.

  (define random
    (letrec ((random14
              (lambda (n)
                (ref-set! x (remainder (+ (* a (ref-get x)) c) (+ m 1)))
                (bv-observe-random (ref-get x) (remainder (quotient (ref-get x) 8) n))))
             (a 701)
             (x (ref 1))
             (c 743483)
             (m 524287)
             (loop
              (lambda (q r n)
                (if (bv-zero? q)
                    (remainder r n)
                    (loop (quotient q 16384)
                          (+ (* 16384 r) (random14 16384))
                          n)))))
      (lambda (n)
        (if (< n 16384)
            (random14 n)
            (loop (quotient n 16384) (random14 16384) n)))))

  ;; Returns a random bytevector of length up to n,
  ;; with all elements less than 128.

  (define (random-bytevector n)
    (let* ((n (random n))
           (bv (make-bytevector n)))
      (do ((i 0 (+ i 1)))
          ((= i n) bv)
        (bytevector-u8-set! bv i (random 128)))))

  ;; Returns a random bytevector of even length up to n.

  (define (random-bytevector2 n)
    (let* ((n (random n))
           (n (if (bv-odd? n) (+ n 1) n))
           (bv (make-bytevector n)))
      (do ((i 0 (+ i 1)))
          ((= i n) bv)
        (bytevector-u8-set! bv i (random 128)))))

  ;; Returns a random bytevector of multiple-of-4 length up to n.

  (define (random-bytevector4 n)
    (let* ((n (random n))
           (n (* 4 (bv-round-quarter n)))
           (bv (make-bytevector n)))
      (do ((i 0 (+ i 1)))
          ((= i n) bv)
        (bytevector-u8-set! bv i (random 128)))))

  (define (probe-generate maximum)
    (if (= (ref-get probe-mode) 1) (random-bytevector2 maximum)
        (if (= (ref-get probe-mode) 2) (random-bytevector4 maximum)
            (random-bytevector maximum))))
  (if (= (ref-get probe-mode) 3)
      (do ((i 0 (+ i 1))) ((= i *random-stress-tests*) (unit))
        (let ((value (random *random-stress-test-max-size*)))
          (bv-observe 5) (bv-observe value)))
      (if (= (ref-get probe-mode) 6)
          (test-roundtrip (bv-ascii) utf8->string string->utf8)
          (begin
            (test-roundtrip (probe-generate 10) utf8->string string->utf8)
            (do ((i 0 (+ i 1))) ((= i *random-stress-tests*) (unit))
              (test-roundtrip (probe-generate *random-stress-test-max-size*)
                              utf8->string string->utf8)))))

  )
(define (bv-probe-rounding count)
  (let loop ((value 0))
    (unless (= value count)
      (bv-observe 6) (bv-observe value) (bv-observe (bv-round-quarter value))
      (loop (+ value 1)))))
(define (bv-probe-failures)
  (test "first\x0;λ" (string=? "left" "right") #t)
  (test "truth" #t #t)
  (test "second😀" (string=? "same" "same") #f)
  (test "false" #f #f))
(: probe (-> I64 I64 I64 I64))
(define (probe mode tests maximum)
  (ref-set! probe-mode mode)
  (if (= mode 4) (bv-probe-rounding tests)
      (if (= mode 5) (bv-probe-failures)
          (begin
            (string-bytevector-tests tests maximum)
            (when (= mode 7) (string-bytevector-tests tests maximum)))))
  (bv-observe-failures (ref-get failed-tests))
  (length (ref-get failed-tests)))
(unit)
