import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const [artifact, expectedPath, mode, tests, maximum] = process.argv.slice(2);
const expected = fs.readFileSync(expectedPath);
let cursor = 0, diagnostics = '';
const imports = {benchmark: {
  observe: value => {
    assert.ok(cursor + 4 <= expected.length, 'unexpected trailing observation');
    assert.equal(value, BigInt(expected.readUInt32LE(cursor)), `observation ${cursor / 4}`);
    cursor += 4;
  },
  write_character: scalar => { diagnostics += String.fromCodePoint(scalar); },
}};
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact), imports);
instance.exports.main();
const result = instance.exports.probe(BigInt(mode), BigInt(tests), BigInt(maximum));
assert.equal(cursor, expected.length, 'missing observation');
console.log(JSON.stringify({result: Number(result), diagnostics, values: cursor / 4,
  sha256: crypto.createHash('sha256').update(expected).digest('hex')}));
