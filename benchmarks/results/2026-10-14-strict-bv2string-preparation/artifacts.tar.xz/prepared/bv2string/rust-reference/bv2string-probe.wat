(module $bv2string_probe-240870552dac5c63.wasm
 (type $0 (func (param i32 i32 i32) (result i32)))
 (type $1 (func (param i32 i32) (result i32)))
 (type $2 (func (param i32)))
 (type $3 (func (param i32 i32)))
 (type $4 (func (param i32 i32 i32)))
 (type $5 (func (param i32) (result i32)))
 (type $6 (func))
 (type $7 (func (param i32 i32 i32 i32)))
 (type $8 (func (param i32 i32 i32 i32) (result i32)))
 (type $9 (func (param i32 i32 i32 i32 i32) (result i32)))
 (type $10 (func (param i32 i32 i32 i32 i32 i32)))
 (type $11 (func (result i32)))
 (type $12 (func (param i32 i32 i32 i32 i32)))
 (type $13 (func (param i32 i32 i32 i32 i32 i64 i64 i32 i32) (result i32)))
 (type $14 (func (param i32 i32 i32 i32 i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "args_sizes_get" (func $_RNvNtNtCs9w8RDfpKrLd_4wasi13lib_generated22wasi_snapshot_preview114args_sizes_get (param i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "args_get" (func $_RNvNtNtCs9w8RDfpKrLd_4wasi13lib_generated22wasi_snapshot_preview18args_get (param i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "environ_get" (func $__imported_wasi_snapshot_preview1_environ_get (param i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "environ_sizes_get" (func $__imported_wasi_snapshot_preview1_environ_sizes_get (param i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "fd_close" (func $__imported_wasi_snapshot_preview1_fd_close (param i32) (result i32)))
 (import "wasi_snapshot_preview1" "fd_fdstat_get" (func $__imported_wasi_snapshot_preview1_fd_fdstat_get (param i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "fd_filestat_get" (func $__imported_wasi_snapshot_preview1_fd_filestat_get (param i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "fd_prestat_get" (func $__imported_wasi_snapshot_preview1_fd_prestat_get (param i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "fd_prestat_dir_name" (func $__imported_wasi_snapshot_preview1_fd_prestat_dir_name (param i32 i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "fd_read" (func $__imported_wasi_snapshot_preview1_fd_read (param i32 i32 i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "fd_write" (func $__imported_wasi_snapshot_preview1_fd_write (param i32 i32 i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "path_open" (func $__imported_wasi_snapshot_preview1_path_open (param i32 i32 i32 i32 i32 i64 i64 i32 i32) (result i32)))
 (import "wasi_snapshot_preview1" "proc_exit" (func $__imported_wasi_snapshot_preview1_proc_exit (param i32)))
 (global $__stack_pointer (mut i32) (i32.const 1048576))
 (memory $0 17)
 (data $.rodata (i32.const 1048576) "ParseIntErrorEmptyInvalidDigitPosOverflowNegOverflowZero\rbegin > end (\c0\03 > \c0\10) when slicing `\c0\01`\c0\00\11start byte index \c0\16 is out of bounds of `\c0\01`\c0\00\0fend byte index \c0\16 is out of bounds of `\c0\01`\c0\00\11start byte index \c0& is not a char boundary; it is inside \c0\08 (bytes \c0\06) of `\c0\01`\c0\00\0fend byte index \c0& is not a char boundary; it is inside \c0\08 (bytes \c0\06) of `\c0\01`\c0\00\c0\01:\c0\01:\c0\00\16slice index starts at \c0\r but ends at \c0\00 index out of bounds: the len is \c0\12 but the index is \c0\00\12range start index \c0\" out of range for slice of length \c0\00\10range end index \c0\" out of range for slice of length \c0\00\10assertion `left \c0\17 right` failed\n  left: \c0\t\n right: \c0\00\10assertion `left \c0\10 right` failed: \c0\t\n  left: \c0\t\n right: \c0\00\13failed printing to \c0\02: \c0\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/core/src/str/lossy.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/core/src/slice/index.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/env.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/rt.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/sys/sync/mutex/no_threads.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/core/src/slice/memchr.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/io/stdio.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/io/buffered/linewritershim.rs\00/home/nti/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/std/src/thread/local.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/sync/reentrant_lock.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/sys/io/error/wasi.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/panicking.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/core/src/unicode/printable.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/sync/once.rs\00src/bin/bv2string-probe.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/core/src/fmt/mod.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/io/mod.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/alloc/src/raw_vec/mod.rs\00/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860/library/std/src/thread/id.rs\00/\00.\00\c0\0b (os error \c0\01)\00\n{\"result\":\c0\n,\"values\":\c0\02}\n\00\15memory allocation of \c0G bytes failed\nskipping backtrace printing to avoid potential recursion\n\00\15memory allocation of \c0\0e bytes failed\n\00\0cpanicked at \c0\02:\n\c03\nthread panicked while processing panic. aborting.\n\00\07Error: \c0\01\n\00\t\nthread \'\c0\03\' (\c0\0e) panicked at \c0\02:\n\c0\01\n\00\19aborting due to panic at \c0\02:\n\c0\01\n\00\00\00\00R\07\10\00\1a\00\00\00P\00\00\00\1a\00\00\00R\07\10\00\1a\00\00\00P\00\00\004\00\00\00R\07\10\00\1a\00\00\00S\00\00\00\05\00\00\00\00\00\00\00\01\00\00\00\01\00\00\00\17\00\00\00R\07\10\00\1a\00\00\00P\00\00\00@\00\00\00R\07\10\00\1a\00\00\00P\00\00\00&\00\00\00R\07\10\00\1a\00\00\00\12\00\00\00\15\00\00\00\00\00\00\00\08\00\00\00\04\00\00\00\18\00\00\00R\07\10\00\1a\00\00\000\00\00\00/\00\00\00R\07\10\00\1a\00\00\00,\00\00\00-\00\00\00D\05\10\00q\00\00\00\d4\02\00\00\"\00\00\00D\05\10\00q\00\00\00\f5\02\00\00&\00\00\00\00\00\00\00\04\00\00\00\04\00\00\00\19\00\00\00\05\00\00\00\0c\00\00\00\0b\00\00\00\0b\00\00\00\04\00\00\00\r\00\10\00\12\00\10\00\1e\00\10\00)\00\10\004\00\10\00capacity overflow\00\00\00\03\08\10\00P\00\00\00\1c\00\00\00\05\00\00\00\00p\00\07\00-\01\01\01\02\01\02\01\01H\0b0\15\10\01e\07\02\06\02\02\01\04#\01\1e\1b[\0b:\t\t\01\18\04\01\t\01\03\01\05+\03;\t*\18\01 7\01\01\01\04\08\04\01\03\07\n\02\1d\01:\01\01\01\02\04\08\01\t\01\n\02\1a\01\02\029\01\04\02\04\02\02\03\03\01\1e\02\03\01\0b\029\01\04\05\01\02\04\01\14\02\16\06\01\01:\01\01\02\01\04\08\01\07\03\n\02\1e\01;\01\01\01\0c\01\t\01(\01\03\017\01\01\03\05\03\01\04\07\02\0b\02\1d\01:\01\02\02\01\01\03\03\01\04\07\02\0b\02\1c\029\02\01\01\02\04\08\01\t\01\n\02\1d\01H\01\04\01\02\03\01\01\08\01Q\01\02\07\0c\08b\01\02\t\0b\07I\02\1b\01\01\01\01\017\0e\01\05\01\02\05\0b\01$\t\01f\04\01\06\01\02\02\02\19\02\04\03\10\04\r\01\02\02\06\01\0f\01\00\03\00\04\1c\03\1d\02\1e\02@\02\01\07\08\01\02\0b\t\01-\03\01\01u\02\"\01v\03\04\02\t\01\06\03\db\02\02\01:\01\01\07\01\01\01\01\02\08\06\n\02\010.\02\0c\14\040\n\04\03&\t\0c\02 \04\02\068\01\01\02\03\01\01\058\08\02\02\98\03\01\r\01\07\04\01\06\01\03\02\c6@\00\01\c3!\00\03\8d\01` \00\06i\02\00\04\01\n \02P\02\00\01\03\01\04\01\19\02\05\01\97\02\1a\12\r\01&\08\19\0b\01\01,\030\01\02\04\02\02\02\01$\01C\06\02\02\02\02\0c\01\08\01/\013\01\01\03\02\02\05\02\01\01*\02\08\01\ee\01\02\01\04\01\00\01\00\10\10\10\00\02\00\01\e2\01\95\05\00\03\01\02\05\04(\03\04\01\a5\02\00\04A\05\00\02M\06F\0b1\04{\016\0f)\01\02\02\n\031\04\02\02\07\01=\03$\05\01\08>\01\0c\024\t\01\01\08\04\02\01_\03\02\04\06\01\02\01\9d\01\03\08\15\029\02\01\01\01\01\0c\01\t\01\0e\07\03\05C\01\02\06\01\01\02\01\01\03\04\03\01\01\0e\02U\08\02\03\01\01\17\01Q\01\02\06\01\01\02\01\01\02\01\02\eb\01\02\04\06\02\01\02\1b\02U\08\02\01\01\02j\01\01\01\02\08e\01\01\01\02\04\01\05\00\t\01\02\f5\01\n\04\04\01\90\04\02\02\04\01 \n(\06\02\04\08\01\t\06\02\03.\r\01\02\c6\01\01\03\01\01\c9\07\01\06\01\01R\16\02\07\01\02\01\02z\06\03\01\01\02\01\07\01\01H\02\03\01\01\01\00\02\0b\024\05\05\03\17\01\00\01\06\0f\00\0c\03\03\00\05;\07\00\01?\04Q\01\0b\02\00\02\00.\02\17\00\05\03\06\08\08\02\07\1e\04\94\03\007\042\08\01\0e\01\16\05\01\0f\00\07\01\11\02\07\01\02\01\05d\01\a0\07\00\01=\04\00\04\fe\02\f3\01\02\01\07\02\05\01\00\07m\07\00`\80\f0\000123456789abcdef { , :  {\n,\n((\n\n})] }\00\00\00\00\0c\00\00\00\04\00\00\00\1a\00\00\00\1b\00\00\00\1c\00\00\00[...]called `Option::unwrap()` on a `None` value==00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899[\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01")
 (data $.rodata.1 (i32.const 1052685) "\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\02\03\03\03\03\03\03\03\03\03\03\03\03\03\03\03\03\04\04\04\04\04")
 (data $.rodata.2 (i32.const 1052748) "I\04\10\00P\00\00\00\a0\00\00\00\t\00\00\00I\04\10\00P\00\00\00\84\00\00\00\1e\00\00\00\00\06\01\01\03\01\04\02\05\07\07\02\08\08\t\02\n\05\0b\02\0e\04\10\01\11\02\12\05\13\1c\14\01\15\02\17\02\19\r\1c\05\1d\08\1f\01$\01j\04k\02n\02\af\03\b1\02\bc\02\cf\02\d1\02\d4\0c\d5\t\d6\02\d7\02\da\01\e0\05\e1\02\e6\01\e7\04\e8\02\ee \f0\04\f8\02\fa\05\fb\01\0c\';>NO\8f\9e\9e\9f{\8b\93\96\a2\b2\ba\86\b1\06\07\t6=>V\f3\d0\d1\04\14\1867VW\7f\aa\ae\af\bd5\e0\12\87\89\8e\9e\04\r\0e\11\12)14:EFIJNOde\8a\8c\8d\8f\b6\c1\c3\c4\c6\cb\d6\\\b6\b7\1b\1c\07\08\n\0b\14\1769:\a8\a9\d8\d9\t7\90\91\a8\07\n;>fi\8f\92\11o_\bf\ee\efZb\b9\ba\f4\fc\ffST\9a\9b./\'(U\9d\a0\a1\a3\a4\a7\a8\ad\ba\bc\c4\06\0b\0c\15\1d:?EQ\a6\a7\cc\cd\a0\07\19\1a\"%>?\df\e7\ec\ef\ff\c5\c6\04 #%&(38:HJLPSUVXZ\\^`cefksx}\7f\8a\a4\aa\af\b0\c0\d0\ae\afno\c7\dd\de\93^\"{\05\03\04-\03f\03\01/.\80\82\1d\031\0f\1c\04$\t\1e\05+\05D\04\0e*\80\aa\06$\04$\04(\084\0bN\034\0c\817\t\16\n\08\18;E9\03c\08\t0\16\05!\03\1b\05\1b&8\04K\05/\04\n\07\t\07@ \'\04\0c\t6\03:\05\1a\07\04\0c\07PI73\r3\07.\08\n\06&\03\1d\08\02\80\d0R\10\06\08\t!.\08*\16\1a&\1c\14\17\tN\04$\tD\r\19\07\n\06H\08\'\tu\0bB>*\06;\05\n\06Q\06\01\05\10\03\05\0bY\08\02\1db\1eH\08\n\80\a6^\"E\0b\n\06\r\13:\06\n\06\14\1c,\04\17\80\b9<dS\0cH\t\nFE\1bH\08S\rI\07\nV\08X\"\0e\n\06F\n\1d\03GI7\03\0e\08\n\069\07\n\06,\04\n\80\f6\19\07;\03\1dU\01\0f2\r\83\9bfu\0b\80\c4\8aLc\r\840\10\16\n\8f\9b\05\82G\9a\b9:\86\c6\829\07*\04\\\06&\nF\n(\05\13\81\b0:\80\c6[\054,K\049\07\11@\05\0b\07\t\9c\d6) as\a1\fd\813\0f\01\1d\06\0e\04\08\81\8c\89\04k\05\r\03\t\07\10\8f`\80\fd\03\81\b4\06\17\0f\11\0fG\tt<\80\f6\ns\08p\15Fz\14\0c\14\0cW\t\19\80\87\81G\03\85B\0f\15\84P\1f\06\06\80\d5+\05>!\01p-\03\1a\04\02\81@\1f\11:\05\01\81\d0*\80\d6+\04\01\80\c06\08\02\80\e0\80\f7)L\04\n\04\02\83\11DL=\80\c2<\06\01\04U\05\1b4\02\81\0e,\04d\0cV\n\80\ae8\1d\r,\04\t\07\02\0e\06\80\9a\83\d9\03\11\03\r\03\80\da\06\0c\04\01\0f\0c\048\08\n\06(\08,\04\02\0e\t\'\81X\08\1d\03\0b\03;\04\1e\04\n\07\80\fb\84\05\00\01\03\05\05\06\06\02\07\06\08\07\t\11\n\1c\0b\19\0c\19\r\10\0e\0c\0f\04\10\03\12\12\13\t\16\01\17\04\18\01\19\03\1a\t\1b\01\1c\02\1f\16 \03+\02-\0b.\010\041\022\01\a9\02\aa\04\ab\08\fa\02\fb\05\fe\03\ff\t\adxy\8b\8d\a20WX\8b\8c\90\1c\dd\0e\0fKL\fb\fc./?\\]_\e2\84\8d\8e\91\92\a9\b1\ba\bb\c5\c6\c9\ca\de\e4\e5\ff\00\04\11\12)147:;=IJ]\84\8e\92\a9\b1\b4\ba\bb\c6\ca\ce\cf\e4\e5\00\04\r\0e\11\12)14:;EFIJ^de\84\91\9b\9d\c9\ce\cf\r\11):;EIW[^_de\8d\91\a9\b4\ba\bb\c5\c9\df\e4\e5\f0\r\11EIde\80\84\b2\bc\be\bf\d5\d7\f0\f1\83\85\8b\a4\a6\be\bf\c5\c7\cf\da\dbH\98\bd\cd\c6\ce\cfINOWY^_\89\8e\8f\b1\b6\b7\bf\c1\c6\c7\d7\11\16\17[\\\f6\f7\fe\ff\80mq\de\df\0e\1fno\1c\1d_}~\ae\af\de\dfM\bb\bc\16\17\1e\1fFGNOXZ\\^~\7f\b5\c5\d4\d5\dc\f0\f1\f5rs\8ftu&./\a7\af\b7\bf\c7\cf\d7\df\9a\00@\97\980\8f\1f\ce\ffNOZ[\07\08\0f\10\'/\ee\efno7=?BESgu\c8\c9\d0\d1\d8\d9\e7\fe\ff\00 _\"\82\df\04\82D\08\1b\04\06\11\81\ac\0e\80\ab\05 \07\81\1c\03\19\08\01\04/\044\04\07\03\01\07\06\07\11\nP\0f\12\07U\07\03\04\1c\n\t\03\08\03\07\03\02\03\03\03\0c\04\05\03\0b\06\01\0e\15\05N\07\1b\07W\07\02\05\18\0cP\04C\03-\03\01\04\11\06\0f\0c:\04\1d%_ m\04j%\80\c8\05\82\b0\03\1a\06\82\fd\03Y\07\16\t\18\t\14\0c\14\0cj\06\n\06\1a\06Y\07+\05F\n,\04\0c\04\01\031\0b,\04\1a\06\0b\03\80\ac\06\n\06L\14\80\f4\08<\03\0f\03>\058\08+\05\82\ff\11\18\08/\11-\03\"\0e!\0f\80\8c\04\82\9a\16\0b\15\88\94\05/\05;\07\02\0e\18\t\80\be\"t\0c\80\d6\1a\81\10\05\80\e1\t\f2\9e\037\t\81\\\14\80\b8\08\80\dd\14<\03\n\068\08F\08\0c\06t\0b\1e\03Z\04Y\t\80\83\18\1c\n\16\tL\04\80\8a\06\ab\a4\0c\17\041\a1\04\81\da&\07\0c\05\05\82\b3 *\06L\04\80\8d\04\80\be\03\1b\03\0f\r\af\06\10\00U\00\00\00\n\00\00\00+\00\00\00\af\06\10\00U\00\00\00\1a\00\00\006\00\00\00attempt to calculate the remainder with a divisor of zero\00\00\00\00\03\00\00\83\04 \00\91\05`\00]\13\a0\00\12\17 \1f\0c `\1f\ef,`+*0\e0+o\a6\a0,\02\a8 -\1e\fb .\00\fe`6\9e\ff\a06\fd\01!7\01\na7$\r!8\ab\0e\a19/\18!:\f3\1e!K@4\a1S\1ea\e1T\f0jaUOo\e1U\9d\bcaV\00\cfaWe\d1\a1W\00\da!X\00\e0\a1Y\ae\e2![\ec\e4\e1\\\d0\e8a] \00\ee^\f0\01\7f_..    \00\00\c1\02\10\00M\00\00\00\8b\00\00\00#\00\00\00\02\\x\c3 \00\00i\02\00\00\00\c1\02\10\00M\00\00\00\84\00\00\00+\00\00\000x0123456789ABCDEFfalsetrue\00m\07\10\00K\00\00\00~\0b\00\00&\00\00\00m\07\10\00K\00\00\00\87\0b\00\00\1a\00\00\00RefCell already mutably borrowedRefCell already borrowed\05\07\10\00L\00\00\00\db\00\00\00\14\00\00\00Once instance has previously been poisonedone-time initialization may not be performed recursively\00\00\00\00\00\00\04\00\00\00\04\00\00\00\1d\00\00\00\1e\00\00\00\0c\00\00\00\04\00\00\00\1f\00\00\00 \00\00\00!\00\00\00a formatting trait implementation returned an error when the underlying stream did not\00\00\b9\07\10\00I\00\00\00\88\02\00\00\11\00\00\00\1e\00\00\00\0c\00\00\00\04\00\00\00\"\00\00\00#\00\00\00$\00\00\00\1e\00\00\00\0c\00\00\00\04\00\00\00%\00\00\00&\00\00\00\'\00\00\00\1e\00\00\00\0c\00\00\00\04\00\00\00(\00\00\00)\00\00\00*\00\00\00\9a\04\10\00K\00\00\00\8d\04\00\00\t\00\00\00file name contained an unexpected NUL byte\00\00\04\19\10\00*\00\00\00\14\00\00\00\00\00\00\00\02\00\00\000\19\10\00\b9\07\10\00I\00\00\00\b2\01\00\001\00\00\00\05\07\10\00L\00\00\00\9f\00\00\002\00\00\00main<unnamed>\00\00\00b\06\10\00L\00\00\00\16\01\00\00.\00\00\00+\00\00\00\0c\00\00\00\04\00\00\00,\00\00\00-\00\00\00.\00\00\00note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n\00\00\00\00\00\00\08\00\00\00\04\00\00\00/\00\00\000\00\00\001\00\00\002\00\00\003\00\00\00\10\00\00\00\04\00\00\004\00\00\005\00\00\006\00\00\007\00\00\008\00\00\00\0c\00\00\00\04\00\00\009\00\00\00called `Result::unwrap()` on an `Err` valuemid > lenm]\cb\d6,P\ebcxA\a6Wq\1b\8b\b9\e4\fd\9e\8f\ba8\e8\93\b7\8acNw\af%\80fatal runtime error: rwlock locked for writing, aborting\nRUST_BACKTRACEentity not foundpermission deniedconnection refusedconnection resethost unreachablenetwork unreachableconnection abortednot connectedaddress in useaddress not availablenetwork downbroken pipeentity already existsoperation would blocknot a directoryis a directorydirectory not emptyread-only filesystem or storage mediumfilesystem loop or indirection limit (e.g. symlink loop)stale network file handleinvalid input parameterinvalid datatimed outwrite zerono storage spaceseek on unseekable filequota exceededfile too largeresource busyexecutable file busydeadlockcross-device link or renametoo many linksinvalid filenameargument list too longoperation interruptedunsupportedunexpected end of fileout of memoryin progressother erroruncategorized errorcannot recursively acquire mutex\ec\03\10\00\\\00\00\00\13\00\00\00\t\00\00\00lock count overflow in reentrant mutex\00\00\b6\05\10\00V\00\00\00#\01\00\00-\00\00\00failed to write the buffered data\00\00\00(\1e\10\00!\00\00\00\17\00\00\00must specify at least one of read, write, or append accesscreating or truncating a file requires write or append access\00\a6\03\10\00E\00\00\00\8d\00\00\00\r\00\00\00Box<dyn Any>thread caused non-unwinding panic. aborting.\n\00\00\00\0f\03\10\00O\00\00\00\fc\03\00\003\00\00\00stdout\00\00\9a\04\10\00K\00\00\00\e3\02\00\00\13\00\00\00failed to write whole bufferD\1f\10\00\1c\00\00\00\17\00\00\00\00\00\00\00\02\00\00\00`\1f\10\00stack backtrace:\nnote: Some details are omitted, run with `RUST_BACKTRACE=full` for a verbose backtrace.\n\00\00\00\00\00\00\00\08\00\00\00\04\00\00\00:\00\00\00\r\06\10\00T\00\00\00N\00\00\006\00\00\00strerror_r failure\00\00\r\06\10\00T\00\00\00L\00\00\00\r\00\00\00failed to generate unique thread ID: bitspace exhausted\00T\08\10\00L\00\00\00&\00\00\00\r\00\00\00WouldBlock\00\00\00\00\00\00\08\00\00\00\04\00\00\00;\00\00\00OscodekindmessageKindErrorCustomerrorUtf8Errorvalid_up_toerror_lenNoneSome\00\00\e6\04\10\00]\00\00\00\16\01\00\00)\00\00\00+\00\00\00\0c\00\00\00\04\00\00\00<\00\00\00_\03\10\00F\00\00\00`\03\00\003\00\00\00NotFoundPermissionDeniedConnectionRefusedConnectionResetHostUnreachableNetworkUnreachableConnectionAbortedNotConnectedAddrInUseAddrNotAvailableNetworkDownBrokenPipeAlreadyExistsNotADirectoryIsADirectoryDirectoryNotEmptyReadOnlyFilesystemFilesystemLoopStaleNetworkFileHandleInvalidInputInvalidDataTimedOutWriteZeroStorageFullNotSeekableQuotaExceededFileTooLargeResourceBusyExecutableFileBusyDeadlockCrossesDevicesTooManyLinksInvalidFilenameArgumentListTooLongInterruptedUnsupportedUnexpectedEofOutOfMemoryInProgressOtherUncategorized\9a\04\10\00K\00\00\00\\\03\00\00\14\00\00\00=\00\00\00\0c\00\00\00\04\00\00\00>\00\00\00=\00\00\00\0c\00\00\00\04\00\00\00?\00\00\00>\00\00\00,#\10\00@\00\00\00A\00\00\00B\00\00\00@\00\00\00C\00\00\00\9a\04\10\00K\00\00\00D\04\00\00\14\00\00\00\b9\07\10\00I\00\00\00Y\07\00\00$\00\00\00description() is deprecated; use Display\f7\a0<\fb?\f5\18:\8bQ\'S\e6T\fdf\"\01\08\t)\r)))\1c))\06\02\03\1e))\1a\0c)\1b\04))\'#\14))\0f\12) ))!\n)\05)))\00)))&))\18$\07\0e)))$))))\01\0b))))\11\19)\13\16\1d\1f\00\08\00\00\00\10\00\00\00\11\00\00\00\0f\00\00\00\0f\00\00\00\12\00\00\00\11\00\00\00\0c\00\00\00\t\00\00\00\10\00\00\00\0b\00\00\00\n\00\00\00\r\00\00\00\n\00\00\00\r\00\00\00\0c\00\00\00\11\00\00\00\12\00\00\00\0e\00\00\00\16\00\00\00\0c\00\00\00\0b\00\00\00\08\00\00\00\t\00\00\00\0b\00\00\00\0b\00\00\00\r\00\00\00\0c\00\00\00\0c\00\00\00\12\00\00\00\08\00\00\00\0e\00\00\00\0c\00\00\00\0f\00\00\00\13\00\00\00\0b\00\00\00\0b\00\00\00\r\00\00\00\0b\00\00\00\n\00\00\00\05\00\00\00\r\00\00\00\08!\10\00\10!\10\00 !\10\001!\10\00@!\10\00O!\10\00a!\10\00r!\10\00~!\10\00\87!\10\00\97!\10\00\a2!\10\00\ac!\10\00p \10\00\b9!\10\00\c6!\10\00\d2!\10\00\e3!\10\00\f5!\10\00\03\"\10\00\19\"\10\00%\"\10\000\"\10\008\"\10\00A\"\10\00L\"\10\00W\"\10\00d\"\10\00p\"\10\00|\"\10\00\8e\"\10\00\96\"\10\00\a4\"\10\00\b0\"\10\00\bf\"\10\00\d2\"\10\00\dd\"\10\00\e8\"\10\00\f5\"\10\00\00#\10\00\n#\10\00\0f#\10\00\08\00\00\00\10\00\00\00\11\00\00\00\0f\00\00\00\0f\00\00\00\12\00\00\00\11\00\00\00\0c\00\00\00\t\00\00\00\10\00\00\00\0b\00\00\00\n\00\00\00\r\00\00\00\n\00\00\00\r\00\00\00\0c\00\00\00\11\00\00\00\12\00\00\00\0e\00\00\00\16\00\00\00\0c\00\00\00\0b\00\00\00\08\00\00\00\t\00\00\00\0b\00\00\00\0b\00\00\00\r\00\00\00\0c\00\00\00\0c\00\00\00\12\00\00\00\08\00\00\00\0e\00\00\00\0c\00\00\00\0f\00\00\00\13\00\00\00\0b\00\00\00\0b\00\00\00\r\00\00\00\0b\00\00\00\n\00\00\00\05\00\00\00\r\00\00\00\08!\10\00\10!\10\00 !\10\001!\10\00@!\10\00O!\10\00a!\10\00r!\10\00~!\10\00\87!\10\00\97!\10\00\a2!\10\00\ac!\10\00p \10\00\b9!\10\00\c6!\10\00\d2!\10\00\e3!\10\00\f5!\10\00\03\"\10\00\19\"\10\00%\"\10\000\"\10\008\"\10\00A\"\10\00L\"\10\00W\"\10\00d\"\10\00p\"\10\00|\"\10\00\8e\"\10\00\96\"\10\00\a4\"\10\00\b0\"\10\00\bf\"\10\00\d2\"\10\00\dd\"\10\00\e8\"\10\00\f5\"\10\00\00#\10\00\n#\10\00\0f#\10\00\08\00\00\00\10\00\00\00\11\00\00\00\0f\00\00\00\0f\00\00\00\12\00\00\00\11\00\00\00\0c\00\00\00\t\00\00\00\10\00\00\00\0b\00\00\00\n\00\00\00\r\00\00\00\n\00\00\00\r\00\00\00\0c\00\00\00\11\00\00\00\12\00\00\00\0e\00\00\00\16\00\00\00\0c\00\00\00\0b\00\00\00\08\00\00\00\t\00\00\00\0b\00\00\00\0b\00\00\00\r\00\00\00\0c\00\00\00\0c\00\00\00\12\00\00\00\08\00\00\00\0e\00\00\00\0c\00\00\00\0f\00\00\00\13\00\00\00\0b\00\00\00\0b\00\00\00\r\00\00\00\0b\00\00\00\n\00\00\00\05\00\00\00\r\00\00\00\08!\10\00\10!\10\00 !\10\001!\10\00@!\10\00O!\10\00a!\10\00r!\10\00~!\10\00\87!\10\00\97!\10\00\a2!\10\00\ac!\10\00p \10\00\b9!\10\00\c6!\10\00\d2!\10\00\e3!\10\00\f5!\10\00\03\"\10\00\19\"\10\00%\"\10\000\"\10\008\"\10\00A\"\10\00L\"\10\00W\"\10\00d\"\10\00p\"\10\00|\"\10\00\8e\"\10\00\96\"\10\00\a4\"\10\00\b0\"\10\00\bf\"\10\00\d2\"\10\00\dd\"\10\00\e8\"\10\00\f5\"\10\00\00#\10\00\n#\10\00\0f#\10\00\10\00\00\00\11\00\00\00\12\00\00\00\10\00\00\00\10\00\00\00\13\00\00\00\12\00\00\00\r\00\00\00\0e\00\00\00\15\00\00\00\0c\00\00\00\0b\00\00\00\15\00\00\00\15\00\00\00\0f\00\00\00\0e\00\00\00\13\00\00\00&\00\00\008\00\00\00\19\00\00\00\17\00\00\00\0c\00\00\00\t\00\00\00\n\00\00\00\10\00\00\00\17\00\00\00\0e\00\00\00\0e\00\00\00\r\00\00\00\14\00\00\00\08\00\00\00\1b\00\00\00\0e\00\00\00\10\00\00\00\16\00\00\00\15\00\00\00\0b\00\00\00\16\00\00\00\r\00\00\00\0b\00\00\00\0b\00\00\00\13\00\00\00\d3\1a\10\00\e3\1a\10\00\f4\1a\10\00\06\1b\10\00\16\1b\10\00&\1b\10\009\1b\10\00K\1b\10\00X\1b\10\00f\1b\10\00{\1b\10\00\87\1b\10\00\92\1b\10\00\a7\1b\10\00\bc\1b\10\00\cb\1b\10\00\d9\1b\10\00\ec\1b\10\00\12\1c\10\00J\1c\10\00c\1c\10\00z\1c\10\00\86\1c\10\00\8f\1c\10\00\99\1c\10\00\a9\1c\10\00\c0\1c\10\00\ce\1c\10\00\dc\1c\10\00\e9\1c\10\00\fd\1c\10\00\05\1d\10\00 \1d\10\00.\1d\10\00>\1d\10\00T\1d\10\00i\1d\10\00t\1d\10\00\8a\1d\10\00\97\1d\10\00\a2\1d\10\00\ad\1d\10\00\00 \00\00\00@\00\00\00\80\00\00\00\c0\00\00\00\c0\00\00\00\a0\00\00Success\00Illegal byte sequence\00Domain error\00Result not representable\00Not a tty\00Permission denied\00Operation not permitted\00No such file or directory\00No such process\00File exists\00Value too large for data type\00No space left on device\00Out of memory\00Resource busy\00Interrupted system call\00Resource temporarily unavailable\00Invalid seek\00Cross-device link\00Read-only file system\00Directory not empty\00Connection reset by peer\00Operation timed out\00Connection refused\00Host is unreachable\00Address in use\00Broken pipe\00I/O error\00No such device or address\00No such device\00Not a directory\00Is a directory\00Text file busy\00Exec format error\00Invalid argument\00Argument list too long\00Symbolic link loop\00Filename too long\00Too many open files in system\00No file descriptors available\00Bad file descriptor\00No child process\00Bad address\00File too large\00Too many links\00No locks available\00Resource deadlock would occur\00State not recoverable\00Previous owner died\00Operation canceled\00Function not implemented\00No message of desired type\00Identifier removed\00Link has been severed\00Protocol error\00Bad message\00Not a socket\00Destination address required\00Message too large\00Protocol wrong type for socket\00Protocol not available\00Protocol not supported\00Not supported\00Address family not supported by protocol\00Address not available\00Network is down\00Network unreachable\00Connection reset by network\00Connection aborted\00No buffer space available\00Socket is connected\00Socket not connected\00Operation already in progress\00Operation in progress\00Stale file handle\00Quota exceeded\00Multihop attempted\00Capabilities insufficient")
 (data $.rodata.3 (i32.const 1060738) "u\02N\00\d6\01\e2\04\b9\04\18\01\8e\05\ed\02\16\04\f2\00\97\03\01\038\05\af\01\82\01O\03/\04\1e\00\d4\05\a2\00\12\03\1e\03\c2\01\de\03\08\00\ac\05\00\01d\02\f1\01e\054\02\8c\02\cf\02-\03L\04\e3\05\9f\02\f8\04\1c\05\08\05\b1\02K\05\15\02x\00R\02<\03\f1\03\e4\00\c3\03}\04\cc\00\aa\03y\05$\02n\01m\03\"\04\ab\04D\00\fb\01\ae\00\83\03`\00\e5\01\07\04\94\04^\04+\00X\019\01\92\00\c2\05\9b\01C\02F\01\f6\05")
 (data $.data (i32.const 1060900) "\04\00\00\00\00\00\00\00\01\00\00\00\a1\08\10\00\ff\ff\ff\ff\00\00\02")
 (table $0 68 68 funcref)
 (elem $0 (i32.const 1) $_RNvXsZ_NtNtCsdHhIpgkcIfN_4core3fmt3numjNtB7_5Debug3fmt $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6790336d5499b618E $_RNvXsr_NtCsdHhIpgkcIfN_4core4cellNtB5_14BorrowMutErrorNtNtB7_3fmt7Display3fmt $_RNvXs8_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3impmNtB9_7Display3fmt $_RNvXs7_NtNtCset5xJoy1xWQ_3std2io5errorNtB5_5ErrorNtNtCsdHhIpgkcIfN_4core3fmt7Display3fmt $_RNvXs1i_NtCsdHhIpgkcIfN_4core3fmtReNtB6_7Display3fmtB8_ $_RNvXs1g_NtCsdHhIpgkcIfN_4core3fmtRDNtB6_5DebugEL_Bx_3fmtB8_ $_RNvXsq_NtCsdHhIpgkcIfN_4core4cellNtB5_11BorrowErrorNtNtB7_3fmt7Display3fmt $_RNvXs9_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3implNtB9_7Display3fmt $_RNvXs_NvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBc_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4fromNtB4_11StringErrorNtNtB11_3fmt7Display3fmt $_RNvXs8_NtCsdHhIpgkcIfN_4core3fmtNtB5_9ArgumentsNtB5_7Display3fmt $_ZN15bv2string_probe4main17h8009ca56fb25b28eE $_RNvXNtNtCset5xJoy1xWQ_3std2io5errorNtB2_5ErrorNtNtCsdHhIpgkcIfN_4core3fmt5Debug3fmt $_RNvXsQ_NtNtCsdHhIpgkcIfN_4core3fmt3numlNtB7_5Debug3fmt $_RNvXs_NtNtCsdHhIpgkcIfN_4core3ops5rangeINtB4_5RangejENtNtB8_3fmt5Debug3fmtB8_ $_RNvXsj_NtCsdHhIpgkcIfN_4core3fmtcNtB5_5Debug3fmt $_RNvXs1i_NtCsdHhIpgkcIfN_4core3fmtRNtNtNtB8_5panic8location8LocationNtB6_7Display3fmtCset5xJoy1xWQ_3std $_RNvXsd_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3impyNtB9_7Display3fmt $_RNvXNvMNtNtCset5xJoy1xWQ_3std3sys9backtraceNtB5_13BacktraceLock5printNtB2_16DisplayBacktraceNtNtCsdHhIpgkcIfN_4core3fmt7Display3fmt $_RNvXsZ_NtNtCsdHhIpgkcIfN_4core3fmt3numjNtB7_5Debug3fmt $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6790336d5499b618E $_RNvXsg_NtNtCsdHhIpgkcIfN_4core3fmt3numhNtB7_8UpperHex3fmt $_RNvXsc_NtNtCsdHhIpgkcIfN_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmt $_RNvXs9_NtNtCsdHhIpgkcIfN_4core3str5errorNtB5_9Utf8ErrorNtNtB9_3fmt5Debug3fmt $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h5ac845b5d188be53E $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write10write_char $_RNvYNtNtNtCsdHhIpgkcIfN_4core3fmt8builders10PadAdapterNtB6_5Write9write_fmtB8_ $_RNvXs1g_NtCsdHhIpgkcIfN_4core3fmtRbNtB6_5Debug3fmtCset5xJoy1xWQ_3std $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterINtNtBL_6cursor6CursorQShEEEBN_ $_RNvXNvNtCset5xJoy1xWQ_3std2io17default_write_fmtINtB2_7AdapterINtNtB4_6cursor6CursorQShEENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_strB6_ $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterINtNtB7_6cursor6CursorQShEENtNtCsdHhIpgkcIfN_4core3fmt5Write10write_charB9_ $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterINtNtB7_6cursor6CursorQShEENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtB9_ $_RNvXNvNtCset5xJoy1xWQ_3std2io17default_write_fmtINtB2_7AdapterNtNtB4_5stdio10StderrLockENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_strB6_ $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtB7_5stdio10StderrLockENtNtCsdHhIpgkcIfN_4core3fmt5Write10write_charB9_ $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtB7_5stdio10StderrLockENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtB9_ $_RNvXNvNtCset5xJoy1xWQ_3std2io17default_write_fmtINtB2_7AdapterNtNtB4_5stdio10StdoutLockENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_strB6_ $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtB7_5stdio10StdoutLockENtNtCsdHhIpgkcIfN_4core3fmt5Write10write_charB9_ $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtB7_5stdio10StdoutLockENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtB9_ $_RNvXNvNtCset5xJoy1xWQ_3std2io17default_write_fmtINtB2_7AdapterNtNtNtNtB6_3sys5stdio4unix6StderrENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_strB6_ $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtNtNtB9_3sys5stdio4unix6StderrENtNtCsdHhIpgkcIfN_4core3fmt5Write10write_charB9_ $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtNtNtB9_3sys5stdio4unix6StderrENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtB9_ $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBQ_3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1W_4SendEL_EINtNtB4_7convert4FromNtNtBS_6string6StringE4from11StringErrorECset5xJoy1xWQ_3std $_RNvXsZ_NtCsi9YzqDQQz2q_5alloc6stringNtB5_6StringNtNtCsdHhIpgkcIfN_4core3fmt5Write9write_str.194 $_RNvXsZ_NtCsi9YzqDQQz2q_5alloc6stringNtB5_6StringNtNtCsdHhIpgkcIfN_4core3fmt5Write10write_char.195 $_RNvYNtNtCsi9YzqDQQz2q_5alloc6string6StringNtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtCset5xJoy1xWQ_3std $_RNvXs2_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCsdHhIpgkcIfN_4core3fmt7Display3fmt $_RNvXs1_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload8take_box $_RNvXs1_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload3get $_RNvXs1_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload6as_str $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeNtNvNtCset5xJoy1xWQ_3std9panicking13panic_handler19FormatStringPayloadEBM_ $_RNvXs0_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_19FormatStringPayloadNtNtCsdHhIpgkcIfN_4core3fmt7Display3fmt $_RNvXs_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload8take_box $_RNvXs_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload3get $_RNvYINtNvNtCset5xJoy1xWQ_3std9panicking11begin_panic7PayloadReENtNtCsdHhIpgkcIfN_4core5panic12PanicPayload6as_strB9_ $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBQ_3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1W_4SendEL_EINtNtB4_7convert4FromNtNtBS_6string6StringE4from11StringErrorECset5xJoy1xWQ_3std $_RNvXs9_NtNtCset5xJoy1xWQ_3std3ffi6os_strNtB5_8OsStringNtNtCsdHhIpgkcIfN_4core3fmt5Debug3fmt $_RNvXs9_NtNtCsdHhIpgkcIfN_4core3str5errorNtB5_9Utf8ErrorNtNtB9_3fmt5Debug3fmt.214 $_RNvXNtCsdHhIpgkcIfN_4core3anyReNtB2_3Any7type_idCset5xJoy1xWQ_3std $_RNvXNtCsdHhIpgkcIfN_4core3anyNtNtCsi9YzqDQQz2q_5alloc6string6StringNtB2_3Any7type_idCset5xJoy1xWQ_3std $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBQ_3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1W_4SendEL_EINtNtB4_7convert4FromNtNtBS_6string6StringE4from11StringErrorECset5xJoy1xWQ_3std $_RNvXs_NvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBc_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4fromNtB4_11StringErrorNtNtB11_3fmt7Display3fmt $_RNvXs0_NvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBd_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB12_6marker4SyncNtB1z_4SendEL_EINtNtB12_7convert4FromNtNtBf_6string6StringE4fromNtB5_11StringErrorNtNtB12_3fmt5Debug3fmt $_RNvYINtNvNtCset5xJoy1xWQ_3std9panicking11begin_panic7PayloadReENtNtCsdHhIpgkcIfN_4core5panic12PanicPayload6as_strB9_ $_RNvYNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBc_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_7type_idCset5xJoy1xWQ_3std $_RNvYNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBc_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_11descriptionCset5xJoy1xWQ_3std $_RNvYNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBc_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_7provideCset5xJoy1xWQ_3std)
 (export "memory" (memory $0))
 (export "_start" (func $_start))
 (export "__main_void" (func $__main_void))
 (func $_start
  (local $0 i32)
  (block $block
   (if
    (i32.eqz
     (i32.load
      (i32.const 1060928)
     )
    )
    (then
     (i32.store
      (i32.const 1060928)
      (i32.const 1)
     )
     (i32.store
      (i32.const 1061096)
      (i32.const 1061096)
     )
     (i32.store
      (i32.const 1061152)
      (i32.const 0)
     )
     (i32.store
      (i32.const 1061148)
      (i32.const 1048576)
     )
     (i32.store
      (i32.const 1061144)
      (i32.const 1048576)
     )
     (i32.store
      (i32.const 1061104)
      (i32.const 1061096)
     )
     (i32.store
      (i32.const 1061100)
      (i32.const 1061096)
     )
     (i32.store
      (i32.const 1061108)
      (i32.load
       (i32.const 1061092)
      )
     )
     (i32.store
      (i32.const 1060920)
      (i32.const 1048576)
     )
     (br_if $block
      (local.tee $0
       (call $__main_void)
      )
     )
     (return)
    )
   )
   (unreachable)
  )
  (call $__wasi_proc_exit
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNvXs9_NtNtCsdHhIpgkcIfN_4core3str5errorNtB5_9Utf8ErrorNtNtB9_3fmt5Debug3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=4
   (local.get $2)
   (i32.add
    (local.get $0)
    (i32.const 4)
   )
  )
  (local.set $3
   (call_indirect $0 (type $0)
    (i32.load
     (local.get $1)
    )
    (i32.const 1056945)
    (i32.const 9)
    (i32.load offset=12
     (i32.load offset=4
      (local.get $1)
     )
    )
   )
  )
  (i32.store8 offset=13
   (local.get $2)
   (i32.const 0)
  )
  (i32.store8 offset=12
   (local.get $2)
   (local.get $3)
  )
  (i32.store offset=8
   (local.get $2)
   (local.get $1)
  )
  (local.set $0
   (call $_RNvMs1_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_11DebugStruct5field
    (call $_RNvMs1_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_11DebugStruct5field
     (i32.add
      (local.get $2)
      (i32.const 8)
     )
     (i32.const 1056954)
     (i32.const 11)
     (local.get $0)
     (i32.const 1)
    )
    (i32.const 1056965)
    (i32.const 9)
    (i32.add
     (local.get $2)
     (i32.const 4)
    )
    (i32.const 2)
   )
  )
  (local.set $1
   (i32.or
    (local.tee $3
     (i32.load8_u offset=13
      (local.get $2)
     )
    )
    (local.tee $4
     (i32.load8_u offset=12
      (local.get $2)
     )
    )
   )
  )
  (block $block
   (br_if $block
    (i32.ne
     (local.get $3)
     (i32.const 1)
    )
   )
   (br_if $block
    (i32.and
     (local.get $4)
     (i32.const 1)
    )
   )
   (if
    (i32.eqz
     (i32.and
      (i32.load8_u offset=10
       (local.tee $0
        (i32.load
         (local.get $0)
        )
       )
      )
      (i32.const 128)
     )
    )
    (then
     (local.set $1
      (call_indirect $0 (type $0)
       (i32.load
        (local.get $0)
       )
       (i32.const 1052214)
       (i32.const 2)
       (i32.load offset=12
        (i32.load offset=4
         (local.get $0)
        )
       )
      )
     )
     (br $block)
    )
   )
   (local.set $1
    (call_indirect $0 (type $0)
     (i32.load
      (local.get $0)
     )
     (i32.const 1052211)
     (i32.const 1)
     (i32.load offset=12
      (i32.load offset=4
       (local.get $0)
      )
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
  (i32.and
   (local.get $1)
   (i32.const 1)
  )
 )
 (func $_RNvXsZ_NtNtCsdHhIpgkcIfN_4core3fmt3numjNtB7_5Debug3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $scratch
   (block $block1 (result i32)
    (block $block
     (if
      (i32.eqz
       (i32.and
        (local.tee $2
         (i32.load offset=8
          (local.get $1)
         )
        )
        (i32.const 33554432)
       )
      )
      (then
       (br_if $block
        (i32.and
         (local.get $2)
         (i32.const 67108864)
        )
       )
       (br $block1
        (call $_RNvXs8_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3impmNtB9_7Display3fmt
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
     (local.set $2
      (i32.load
       (local.get $0)
      )
     )
     (local.set $0
      (i32.const 9)
     )
     (loop $label
      (i32.store8
       (i32.add
        (i32.add
         (local.get $0)
         (local.get $3)
        )
        (i32.const 6)
       )
       (i32.load8_u offset=1052179
        (i32.and
         (local.get $2)
         (i32.const 15)
        )
       )
      )
      (local.set $0
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
      )
      (br_if $label
       (local.tee $2
        (i32.shr_u
         (local.get $2)
         (i32.const 4)
        )
       )
      )
     )
     (br $block1
      (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
       (local.get $1)
       (i32.const 1)
       (i32.const 1054516)
       (i32.const 2)
       (i32.add
        (i32.add
         (local.get $0)
         (local.get $3)
        )
        (i32.const 7)
       )
       (i32.sub
        (i32.const 9)
        (local.get $0)
       )
      )
     )
    )
    (local.set $2
     (i32.load
      (local.get $0)
     )
    )
    (local.set $0
     (i32.const 9)
    )
    (loop $label1
     (i32.store8
      (i32.add
       (i32.add
        (local.get $0)
        (local.get $3)
       )
       (i32.const 6)
      )
      (i32.load8_u offset=1054518
       (i32.and
        (local.get $2)
        (i32.const 15)
       )
      )
     )
     (local.set $0
      (i32.sub
       (local.get $0)
       (i32.const 1)
      )
     )
     (br_if $label1
      (local.tee $2
       (i32.shr_u
        (local.get $2)
        (i32.const 4)
       )
      )
     )
    )
    (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
     (local.get $1)
     (i32.const 1)
     (i32.const 1054516)
     (i32.const 2)
     (i32.add
      (i32.add
       (local.get $0)
       (local.get $3)
      )
      (i32.const 7)
     )
     (i32.sub
      (i32.const 9)
      (local.get $0)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvMs1_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_11DebugStruct5field (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (result i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (local.set $7
   (i32.const 1)
  )
  (block $block
   (br_if $block
    (i32.load8_u offset=4
     (local.get $0)
    )
   )
   (local.set $8
    (i32.load8_u offset=5
     (local.get $0)
    )
   )
   (if
    (i32.eqz
     (i32.and
      (i32.load8_u offset=10
       (local.tee $6
        (i32.load
         (local.get $0)
        )
       )
      )
      (i32.const 128)
     )
    )
    (then
     (br_if $block
      (call_indirect $0 (type $0)
       (i32.load
        (local.get $6)
       )
       (select
        (i32.const 1052198)
        (i32.const 1052195)
        (local.tee $8
         (i32.and
          (local.get $8)
          (i32.const 1)
         )
        )
       )
       (select
        (i32.const 2)
        (i32.const 3)
        (local.get $8)
       )
       (i32.load offset=12
        (i32.load offset=4
         (local.get $6)
        )
       )
      )
     )
     (br_if $block
      (call_indirect $0 (type $0)
       (i32.load
        (local.get $6)
       )
       (local.get $1)
       (local.get $2)
       (i32.load offset=12
        (i32.load offset=4
         (local.get $6)
        )
       )
      )
     )
     (br_if $block
      (call_indirect $0 (type $0)
       (i32.load
        (local.get $6)
       )
       (i32.const 1052200)
       (i32.const 2)
       (i32.load offset=12
        (i32.load offset=4
         (local.get $6)
        )
       )
      )
     )
     (local.set $7
      (call_indirect $0 (type $1)
       (local.get $3)
       (local.get $6)
       (local.get $4)
      )
     )
     (br $block)
    )
   )
   (if
    (i32.eqz
     (i32.and
      (local.get $8)
      (i32.const 1)
     )
    )
    (then
     (br_if $block
      (call_indirect $0 (type $0)
       (i32.load
        (local.get $6)
       )
       (i32.const 1052202)
       (i32.const 3)
       (i32.load offset=12
        (i32.load offset=4
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (i32.store8 offset=15
    (local.get $5)
    (i32.const 1)
   )
   (i32.store offset=20
    (local.get $5)
    (i32.const 1052216)
   )
   (i64.store align=4
    (local.get $5)
    (i64.load align=4
     (local.get $6)
    )
   )
   (i64.store offset=24 align=4
    (local.get $5)
    (i64.load offset=8 align=4
     (local.get $6)
    )
   )
   (i32.store offset=8
    (local.get $5)
    (i32.add
     (local.get $5)
     (i32.const 15)
    )
   )
   (i32.store offset=16
    (local.get $5)
    (local.get $5)
   )
   (br_if $block
    (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
     (local.get $5)
     (local.get $1)
     (local.get $2)
    )
   )
   (br_if $block
    (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
     (local.get $5)
     (i32.const 1052200)
     (i32.const 2)
    )
   )
   (if
    (call_indirect $0 (type $1)
     (local.get $3)
     (i32.add
      (local.get $5)
      (i32.const 16)
     )
     (local.get $4)
    )
    (then
     (br $block)
    )
   )
   (local.set $7
    (call_indirect $0 (type $0)
     (i32.load offset=16
      (local.get $5)
     )
     (i32.const 1052205)
     (i32.const 2)
     (i32.load offset=12
      (i32.load offset=20
       (local.get $5)
      )
     )
    )
   )
  )
  (i32.store8 offset=5
   (local.get $0)
   (i32.const 1)
  )
  (i32.store8 offset=4
   (local.get $0)
   (local.get $7)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 32)
   )
  )
  (local.get $0)
 )
 (func $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6790336d5499b618E (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (local.set $3
   (i32.const 1)
  )
  (block $block
   (if
    (i32.eq
     (i32.load8_u
      (local.tee $4
       (i32.load
        (local.get $0)
       )
      )
     )
     (i32.const 1)
    )
    (then
     (br_if $block
      (call_indirect $0 (type $0)
       (local.tee $0
        (i32.load
         (local.get $1)
        )
       )
       (i32.const 1056978)
       (i32.const 4)
       (local.tee $5
        (i32.load offset=12
         (local.tee $6
          (i32.load offset=4
           (local.get $1)
          )
         )
        )
       )
      )
     )
     (local.set $4
      (i32.add
       (local.get $4)
       (i32.const 1)
      )
     )
     (block $block1
      (if
       (i32.eqz
        (i32.and
         (i32.load8_u offset=10
          (local.get $1)
         )
         (i32.const 128)
        )
       )
       (then
        (br_if $block
         (call_indirect $0 (type $0)
          (local.get $0)
          (i32.const 1052207)
          (i32.const 1)
          (local.get $5)
         )
        )
        (br_if $block
         (call $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6a7a616754267648E
          (local.get $4)
          (local.get $1)
         )
        )
        (local.set $0
         (i32.load
          (local.get $1)
         )
        )
        (local.set $5
         (i32.load offset=12
          (i32.load offset=4
           (local.get $1)
          )
         )
        )
        (br $block1)
       )
      )
      (br_if $block
       (call_indirect $0 (type $0)
        (local.get $0)
        (i32.const 1052208)
        (i32.const 2)
        (local.get $5)
       )
      )
      (i32.store8 offset=15
       (local.get $2)
       (i32.const 1)
      )
      (i32.store offset=4
       (local.get $2)
       (local.get $6)
      )
      (i32.store
       (local.get $2)
       (local.get $0)
      )
      (i32.store offset=20
       (local.get $2)
       (i32.const 1052216)
      )
      (i64.store offset=24 align=4
       (local.get $2)
       (i64.load offset=8 align=4
        (local.get $1)
       )
      )
      (i32.store offset=8
       (local.get $2)
       (i32.add
        (local.get $2)
        (i32.const 15)
       )
      )
      (i32.store offset=16
       (local.get $2)
       (local.get $2)
      )
      (br_if $block
       (call $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6a7a616754267648E
        (local.get $4)
        (i32.add
         (local.get $2)
         (i32.const 16)
        )
       )
      )
      (br_if $block
       (call_indirect $0 (type $0)
        (i32.load offset=16
         (local.get $2)
        )
        (i32.const 1052205)
        (i32.const 2)
        (i32.load offset=12
         (i32.load offset=20
          (local.get $2)
         )
        )
       )
      )
     )
     (local.set $3
      (call_indirect $0 (type $0)
       (local.get $0)
       (i32.const 1052212)
       (i32.const 1)
       (local.get $5)
      )
     )
     (br $block)
    )
   )
   (local.set $3
    (call_indirect $0 (type $0)
     (i32.load
      (local.get $1)
     )
     (i32.const 1056974)
     (i32.const 4)
     (i32.load offset=12
      (i32.load offset=4
       (local.get $1)
      )
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 32)
   )
  )
  (local.get $3)
 )
 (func $_RNvXs8_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3impmNtB9_7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $2
   (i32.const 10)
  )
  (local.set $0
   (local.tee $4
    (i32.load
     (local.get $0)
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $4)
    (i32.const 1000)
   )
   (then
    (loop $label
     (i32.store16 align=1
      (i32.sub
       (local.tee $5
        (i32.add
         (i32.add
          (local.get $3)
          (i32.const 6)
         )
         (local.get $2)
        )
       )
       (i32.const 4)
      )
      (i32.load16_u offset=1052290 align=1
       (i32.shl
        (local.tee $8
         (i32.div_u
          (i32.and
           (local.tee $7
            (i32.sub
             (local.tee $6
              (local.get $0)
             )
             (i32.mul
              (local.tee $0
               (i32.div_u
                (local.get $0)
                (i32.const 10000)
               )
              )
              (i32.const 10000)
             )
            )
           )
           (i32.const 65535)
          )
          (i32.const 100)
         )
        )
        (i32.const 1)
       )
      )
     )
     (i32.store16 align=1
      (i32.sub
       (local.get $5)
       (i32.const 2)
      )
      (i32.load16_u offset=1052290 align=1
       (i32.shl
        (i32.and
         (i32.sub
          (local.get $7)
          (i32.mul
           (local.get $8)
           (i32.const 100)
          )
         )
         (i32.const 65535)
        )
        (i32.const 1)
       )
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (i32.const 4)
      )
     )
     (br_if $label
      (i32.gt_u
       (local.get $6)
       (i32.const 9999999)
      )
     )
    )
   )
  )
  (if
   (i32.gt_u
    (local.get $0)
    (i32.const 9)
   )
   (then
    (i32.store16 align=1
     (i32.add
      (local.tee $2
       (i32.sub
        (local.get $2)
        (i32.const 2)
       )
      )
      (i32.add
       (local.get $3)
       (i32.const 6)
      )
     )
     (i32.load16_u offset=1052290 align=1
      (i32.shl
       (i32.and
        (i32.sub
         (local.get $0)
         (i32.mul
          (local.tee $0
           (i32.div_u
            (i32.and
             (local.get $0)
             (i32.const 65535)
            )
            (i32.const 100)
           )
          )
          (i32.const 100)
         )
        )
        (i32.const 65535)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (select
     (i32.const 0)
     (local.get $4)
     (local.get $0)
    )
   )
   (then
    (i32.store8
     (i32.add
      (local.tee $2
       (i32.sub
        (local.get $2)
        (i32.const 1)
       )
      )
      (i32.add
       (local.get $3)
       (i32.const 6)
      )
     )
     (i32.load8_u offset=1052291
      (i32.shl
       (local.get $0)
       (i32.const 1)
      )
     )
    )
   )
  )
  (local.set $scratch
   (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
    (local.get $1)
    (i32.const 1)
    (i32.const 1)
    (i32.const 0)
    (i32.add
     (i32.add
      (local.get $3)
      (i32.const 6)
     )
     (local.get $2)
    )
    (i32.sub
     (i32.const 10)
     (local.get $2)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i32) (result i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i64)
  (local.set $12
   (select
    (select
     (i32.const 43)
     (i32.const 1114112)
     (local.tee $6
      (i32.and
       (local.tee $8
        (i32.load offset=8
         (local.get $0)
        )
       )
       (i32.const 2097152)
      )
     )
    )
    (block (result i32)
     (local.set $7
      (i32.add
       (select
        (i32.shr_u
         (local.get $6)
         (i32.const 21)
        )
        (i32.const 1)
        (local.get $1)
       )
       (local.get $5)
      )
     )
     (block $block
      (if
       (i32.eqz
        (i32.and
         (local.get $8)
         (i32.const 8388608)
        )
       )
       (then
        (local.set $2
         (i32.const 0)
        )
        (br $block)
       )
      )
      (local.set $7
       (i32.add
        (block $block1 (result i32)
         (drop
          (br_if $block1
           (i32.const 0)
           (i32.eqz
            (local.get $3)
           )
          )
         )
         (drop
          (br_if $block1
           (local.tee $6
            (i32.gt_s
             (i32.load8_s
              (local.get $2)
             )
             (i32.const -65)
            )
           )
           (i32.eq
            (local.get $3)
            (i32.const 1)
           )
          )
         )
         (i32.add
          (local.get $6)
          (i32.gt_s
           (i32.load8_s offset=1
            (local.get $2)
           )
           (i32.const -65)
          )
         )
        )
        (local.get $7)
       )
      )
     )
     (i32.const 45)
    )
    (local.get $1)
   )
  )
  (block $block6
   (if
    (i32.gt_u
     (local.tee $11
      (i32.load16_u offset=12
       (local.get $0)
      )
     )
     (local.get $7)
    )
    (then
     (block $block7
      (block $block5
       (if
        (i32.eqz
         (i32.and
          (local.get $8)
          (i32.const 16777216)
         )
        )
        (then
         (local.set $9
          (i32.sub
           (local.get $11)
           (local.get $7)
          )
         )
         (local.set $1
          (i32.const 0)
         )
         (local.set $6
          (i32.const 0)
         )
         (block $block4
          (block $block3
           (block $block2
            (br_table $block2 $block3 $block2 $block4
             (i32.sub
              (i32.and
               (i32.shr_u
                (local.get $8)
                (i32.const 29)
               )
               (i32.const 3)
              )
              (i32.const 1)
             )
            )
           )
           (local.set $6
            (local.get $9)
           )
           (br $block4)
          )
          (local.set $6
           (i32.shr_u
            (i32.and
             (local.get $9)
             (i32.const 65534)
            )
            (i32.const 1)
           )
          )
         )
         (local.set $11
          (i32.and
           (local.get $8)
           (i32.const 2097151)
          )
         )
         (local.set $7
          (i32.load offset=4
           (local.get $0)
          )
         )
         (local.set $8
          (i32.load
           (local.get $0)
          )
         )
         (loop $label
          (br_if $block5
           (i32.ge_u
            (i32.and
             (local.get $1)
             (i32.const 65535)
            )
            (i32.and
             (local.get $6)
             (i32.const 65535)
            )
           )
          )
          (local.set $10
           (i32.const 1)
          )
          (local.set $1
           (i32.add
            (local.get $1)
            (i32.const 1)
           )
          )
          (br_if $label
           (i32.eqz
            (call_indirect $0 (type $1)
             (local.get $8)
             (local.get $11)
             (i32.load offset=16
              (local.get $7)
             )
            )
           )
          )
         )
         (br $block6)
        )
       )
       (i32.store offset=8
        (local.get $0)
        (i32.or
         (i32.and
          (i32.wrap_i64
           (local.tee $13
            (i64.load offset=8 align=4
             (local.get $0)
            )
           )
          )
          (i32.const -1612709888)
         )
         (i32.const 536870960)
        )
       )
       (local.set $10
        (i32.const 1)
       )
       (br_if $block6
        (call $_RNvNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB7_9Formatter12pad_integral12write_prefix
         (local.tee $6
          (i32.load
           (local.get $0)
          )
         )
         (local.tee $9
          (i32.load offset=4
           (local.get $0)
          )
         )
         (local.get $12)
         (local.get $2)
         (local.get $3)
        )
       )
       (local.set $1
        (i32.const 0)
       )
       (local.set $2
        (i32.and
         (i32.sub
          (local.get $11)
          (local.get $7)
         )
         (i32.const 65535)
        )
       )
       (loop $label1
        (br_if $block7
         (i32.ge_u
          (i32.and
           (local.get $1)
           (i32.const 65535)
          )
          (local.get $2)
         )
        )
        (local.set $1
         (i32.add
          (local.get $1)
          (i32.const 1)
         )
        )
        (br_if $label1
         (i32.eqz
          (call_indirect $0 (type $1)
           (local.get $6)
           (i32.const 48)
           (i32.load offset=16
            (local.get $9)
           )
          )
         )
        )
       )
       (br $block6)
      )
      (local.set $10
       (i32.const 1)
      )
      (br_if $block6
       (call $_RNvNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB7_9Formatter12pad_integral12write_prefix
        (local.get $8)
        (local.get $7)
        (local.get $12)
        (local.get $2)
        (local.get $3)
       )
      )
      (br_if $block6
       (call_indirect $0 (type $0)
        (local.get $8)
        (local.get $4)
        (local.get $5)
        (i32.load offset=12
         (local.get $7)
        )
       )
      )
      (local.set $0
       (i32.and
        (i32.sub
         (local.get $9)
         (local.get $6)
        )
        (i32.const 65535)
       )
      )
      (local.set $1
       (i32.const 0)
      )
      (loop $label2
       (if
        (i32.le_u
         (local.get $0)
         (i32.and
          (local.get $1)
          (i32.const 65535)
         )
        )
        (then
         (return
          (i32.const 0)
         )
        )
       )
       (local.set $1
        (i32.add
         (local.get $1)
         (i32.const 1)
        )
       )
       (br_if $label2
        (i32.eqz
         (call_indirect $0 (type $1)
          (local.get $8)
          (local.get $11)
          (i32.load offset=16
           (local.get $7)
          )
         )
        )
       )
      )
      (br $block6)
     )
     (br_if $block6
      (call_indirect $0 (type $0)
       (local.get $6)
       (local.get $4)
       (local.get $5)
       (i32.load offset=12
        (local.get $9)
       )
      )
     )
     (i64.store offset=8 align=4
      (local.get $0)
      (local.get $13)
     )
     (return
      (i32.const 0)
     )
    )
   )
   (local.set $10
    (i32.const 1)
   )
   (br_if $block6
    (call $_RNvNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB7_9Formatter12pad_integral12write_prefix
     (local.tee $1
      (i32.load
       (local.get $0)
      )
     )
     (local.tee $0
      (i32.load offset=4
       (local.get $0)
      )
     )
     (local.get $12)
     (local.get $2)
     (local.get $3)
    )
   )
   (local.set $10
    (call_indirect $0 (type $0)
     (local.get $1)
     (local.get $4)
     (local.get $5)
     (i32.load offset=12
      (local.get $0)
     )
    )
   )
  )
  (local.get $10)
 )
 (func $_RNvXsc_NtNtCsdHhIpgkcIfN_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $5
   (i32.const 1)
  )
  (block $block
   (br_if $block
    (call_indirect $0 (type $0)
     (local.tee $3
      (i32.load
       (local.get $1)
      )
     )
     (i32.const 1048576)
     (i32.const 13)
     (local.tee $4
      (i32.load offset=12
       (local.tee $6
        (i32.load offset=4
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (if
    (i32.eqz
     (i32.and
      (i32.load8_u offset=10
       (local.get $1)
      )
      (i32.const 128)
     )
    )
    (then
     (br_if $block
      (call_indirect $0 (type $0)
       (local.get $3)
       (i32.const 1052195)
       (i32.const 3)
       (local.get $4)
      )
     )
     (br_if $block
      (call_indirect $0 (type $0)
       (local.get $3)
       (i32.const 1056914)
       (i32.const 4)
       (local.get $4)
      )
     )
     (br_if $block
      (call_indirect $0 (type $0)
       (local.get $3)
       (i32.const 1052200)
       (i32.const 2)
       (local.get $4)
      )
     )
     (br_if $block
      (call_indirect $0 (type $0)
       (local.get $3)
       (i32.load offset=1051356
        (local.tee $0
         (i32.shl
          (i32.load8_u
           (local.get $0)
          )
          (i32.const 2)
         )
        )
       )
       (i32.load offset=1051336
        (local.get $0)
       )
       (local.get $4)
      )
     )
     (local.set $5
      (call_indirect $0 (type $0)
       (local.get $3)
       (i32.const 1052214)
       (i32.const 2)
       (local.get $4)
      )
     )
     (br $block)
    )
   )
   (br_if $block
    (call_indirect $0 (type $0)
     (local.get $3)
     (i32.const 1052202)
     (i32.const 3)
     (local.get $4)
    )
   )
   (i32.store offset=4
    (local.get $2)
    (local.get $6)
   )
   (i32.store
    (local.get $2)
    (local.get $3)
   )
   (i32.store8 offset=15
    (local.get $2)
    (i32.const 1)
   )
   (i32.store offset=8
    (local.get $2)
    (i32.add
     (local.get $2)
     (i32.const 15)
    )
   )
   (br_if $block
    (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
     (local.get $2)
     (i32.const 1056914)
     (i32.const 4)
    )
   )
   (br_if $block
    (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
     (local.get $2)
     (i32.const 1052200)
     (i32.const 2)
    )
   )
   (br_if $block
    (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
     (local.get $2)
     (i32.load offset=1051356
      (local.tee $0
       (i32.shl
        (i32.load8_u
         (local.get $0)
        )
        (i32.const 2)
       )
      )
     )
     (i32.load offset=1051336
      (local.get $0)
     )
    )
   )
   (br_if $block
    (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
     (local.get $2)
     (i32.const 1052205)
     (i32.const 2)
    )
   )
   (local.set $5
    (call_indirect $0 (type $0)
     (local.get $3)
     (i32.const 1052211)
     (i32.const 1)
     (local.get $4)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
  (local.get $5)
 )
 (func $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local.set $9
   (i32.load offset=4
    (local.get $0)
   )
  )
  (local.set $10
   (i32.load
    (local.get $0)
   )
  )
  (local.set $11
   (i32.load offset=8
    (local.get $0)
   )
  )
  (block $block
   (loop $label5
    (br_if $block
     (local.get $6)
    )
    (local.set $0
     (block $block9 (result i32)
      (block $block1
       (br_if $block1
        (i32.lt_u
         (local.get $2)
         (local.get $4)
        )
       )
       (loop $label4
        (local.set $5
         (i32.add
          (local.get $1)
          (local.get $4)
         )
        )
        (block $block4
         (block $block5
          (block $block6
           (block $block3
            (block $block2
             (if
              (i32.le_u
               (local.tee $6
                (i32.sub
                 (local.get $2)
                 (local.get $4)
                )
               )
               (i32.const 7)
              )
              (then
               (br_if $block2
                (i32.ne
                 (local.get $2)
                 (local.get $4)
                )
               )
               (local.set $4
                (local.get $2)
               )
               (br $block1)
              )
             )
             (br_if $block3
              (i32.eq
               (local.tee $0
                (i32.and
                 (i32.add
                  (local.get $5)
                  (i32.const 3)
                 )
                 (i32.const -4)
                )
               )
               (local.get $5)
              )
             )
             (local.set $3
              (i32.sub
               (local.get $0)
               (local.get $5)
              )
             )
             (local.set $0
              (i32.const 0)
             )
             (loop $label
              (br_if $block4
               (i32.eq
                (i32.load8_u
                 (i32.add
                  (local.get $0)
                  (local.get $5)
                 )
                )
                (i32.const 10)
               )
              )
              (br_if $label
               (i32.ne
                (local.get $3)
                (local.tee $0
                 (i32.add
                  (local.get $0)
                  (i32.const 1)
                 )
                )
               )
              )
             )
             (br_if $block5
              (i32.gt_u
               (local.get $3)
               (local.tee $0
                (i32.sub
                 (local.get $6)
                 (i32.const 8)
                )
               )
              )
             )
             (br $block6)
            )
            (local.set $0
             (i32.const 0)
            )
            (loop $label1
             (br_if $block4
              (i32.eq
               (i32.load8_u
                (i32.add
                 (local.get $0)
                 (local.get $5)
                )
               )
               (i32.const 10)
              )
             )
             (br_if $label1
              (i32.ne
               (local.get $6)
               (local.tee $0
                (i32.add
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
             )
            )
            (local.set $4
             (local.get $2)
            )
            (br $block1)
           )
           (local.set $0
            (i32.sub
             (local.get $6)
             (i32.const 8)
            )
           )
           (local.set $3
            (i32.const 0)
           )
          )
          (loop $label2
           (br_if $block5
            (i32.ne
             (i32.and
              (i32.and
               (i32.or
                (i32.sub
                 (i32.const 16843008)
                 (i32.xor
                  (local.tee $13
                   (i32.load
                    (local.tee $7
                     (i32.add
                      (local.get $3)
                      (local.get $5)
                     )
                    )
                   )
                  )
                  (i32.const 168430090)
                 )
                )
                (local.get $13)
               )
               (i32.or
                (i32.sub
                 (i32.const 16843008)
                 (i32.xor
                  (local.tee $7
                   (i32.load
                    (i32.add
                     (local.get $7)
                     (i32.const 4)
                    )
                   )
                  )
                  (i32.const 168430090)
                 )
                )
                (local.get $7)
               )
              )
              (i32.const -2139062144)
             )
             (i32.const -2139062144)
            )
           )
           (br_if $label2
            (i32.le_u
             (local.tee $3
              (i32.add
               (local.get $3)
               (i32.const 8)
              )
             )
             (local.get $0)
            )
           )
          )
         )
         (if
          (i32.eq
           (local.get $3)
           (local.get $6)
          )
          (then
           (local.set $4
            (local.get $2)
           )
           (br $block1)
          )
         )
         (local.set $6
          (i32.add
           (local.get $3)
           (local.get $5)
          )
         )
         (local.set $7
          (i32.sub
           (i32.sub
            (local.get $2)
            (local.get $3)
           )
           (local.get $4)
          )
         )
         (local.set $0
          (i32.const 0)
         )
         (block $block7
          (loop $label3
           (br_if $block7
            (i32.eq
             (i32.load8_u
              (i32.add
               (local.get $0)
               (local.get $6)
              )
             )
             (i32.const 10)
            )
           )
           (br_if $label3
            (i32.ne
             (local.get $7)
             (local.tee $0
              (i32.add
               (local.get $0)
               (i32.const 1)
              )
             )
            )
           )
          )
          (local.set $4
           (local.get $2)
          )
          (br $block1)
         )
         (local.set $0
          (i32.add
           (local.get $0)
           (local.get $3)
          )
         )
        )
        (local.set $4
         (i32.add
          (local.tee $3
           (i32.add
            (local.get $0)
            (local.get $4)
           )
          )
          (i32.const 1)
         )
        )
        (block $block8
         (br_if $block8
          (i32.le_u
           (local.get $2)
           (local.get $3)
          )
         )
         (br_if $block8
          (i32.ne
           (i32.load8_u
            (i32.add
             (local.get $0)
             (local.get $5)
            )
           )
           (i32.const 10)
          )
         )
         (local.set $6
          (i32.const 0)
         )
         (br $block9
          (local.tee $5
           (local.get $4)
          )
         )
        )
        (br_if $label4
         (i32.ge_u
          (local.get $2)
          (local.get $4)
         )
        )
       )
      )
      (br_if $block
       (i32.eq
        (local.get $2)
        (local.get $8)
       )
      )
      (local.set $6
       (i32.const 1)
      )
      (local.set $5
       (local.get $8)
      )
      (local.get $2)
     )
    )
    (block $block10
     (if
      (i32.load8_u
       (local.get $11)
      )
      (then
       (br_if $block10
        (call_indirect $0 (type $0)
         (local.get $10)
         (i32.const 1054466)
         (i32.const 4)
         (i32.load offset=12
          (local.get $9)
         )
        )
       )
      )
     )
     (local.set $3
      (i32.const 0)
     )
     (if
      (i32.ne
       (local.get $0)
       (local.get $8)
      )
      (then
       (local.set $3
        (i32.eq
         (i32.load8_u
          (i32.sub
           (i32.add
            (local.get $0)
            (local.get $1)
           )
           (i32.const 1)
          )
         )
         (i32.const 10)
        )
       )
      )
     )
     (local.set $0
      (i32.sub
       (local.get $0)
       (local.get $8)
      )
     )
     (local.set $7
      (i32.add
       (local.get $1)
       (local.get $8)
      )
     )
     (i32.store8
      (local.get $11)
      (local.get $3)
     )
     (local.set $8
      (local.get $5)
     )
     (br_if $label5
      (i32.eqz
       (call_indirect $0 (type $0)
        (local.get $10)
        (local.get $7)
        (local.get $0)
        (i32.load offset=12
         (local.get $9)
        )
       )
      )
     )
    )
   )
   (local.set $12
    (i32.const 1)
   )
  )
  (local.get $12)
 )
 (func $_ZN15bv2string_probe12observe_text17h4994e761050e0c72E (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (block $block
   (if
    (i32.ge_u
     (local.get $2)
     (i32.const 16)
    )
    (then
     (local.set $5
      (call $_RNvNtNtCsdHhIpgkcIfN_4core3str5count14do_count_chars
       (local.get $1)
       (local.get $2)
      )
     )
     (br $block)
    )
   )
   (if
    (i32.eqz
     (local.get $2)
    )
    (then
     (br $block)
    )
   )
   (local.set $4
    (i32.and
     (local.get $2)
     (i32.const 3)
    )
   )
   (if
    (i32.ge_u
     (local.get $2)
     (i32.const 4)
    )
    (then
     (local.set $7
      (i32.and
       (local.get $2)
       (i32.const 12)
      )
     )
     (loop $label
      (local.set $5
       (i32.add
        (i32.add
         (i32.add
          (i32.add
           (local.get $5)
           (i32.gt_s
            (i32.load8_s
             (local.tee $6
              (i32.add
               (local.get $1)
               (local.get $3)
              )
             )
            )
            (i32.const -65)
           )
          )
          (i32.gt_s
           (i32.load8_s
            (i32.add
             (local.get $6)
             (i32.const 1)
            )
           )
           (i32.const -65)
          )
         )
         (i32.gt_s
          (i32.load8_s
           (i32.add
            (local.get $6)
            (i32.const 2)
           )
          )
          (i32.const -65)
         )
        )
        (i32.gt_s
         (i32.load8_s
          (i32.add
           (local.get $6)
           (i32.const 3)
          )
         )
         (i32.const -65)
        )
       )
      )
      (br_if $label
       (i32.ne
        (local.get $7)
        (local.tee $3
         (i32.add
          (local.get $3)
          (i32.const 4)
         )
        )
       )
      )
     )
     (br_if $block
      (i32.eqz
       (local.get $4)
      )
     )
    )
   )
   (local.set $3
    (i32.add
     (local.get $1)
     (local.get $3)
    )
   )
   (loop $label1
    (local.set $5
     (i32.add
      (local.get $5)
      (i32.gt_s
       (i32.load8_s
        (local.get $3)
       )
       (i32.const -65)
      )
     )
    )
    (local.set $3
     (i32.add
      (local.get $3)
      (i32.const 1)
     )
    )
    (br_if $label1
     (local.tee $4
      (i32.sub
       (local.get $4)
       (i32.const 1)
      )
     )
    )
   )
  )
  (block $block1
   (if
    (i32.eqz
     (i32.load
      (i32.const 1060892)
     )
    )
    (then
     (i32.store
      (i32.const 1060892)
      (i32.const -1)
     )
     (if
      (i32.le_u
       (i32.sub
        (i32.load
         (i32.const 1060896)
        )
        (local.tee $3
         (i32.load
          (i32.const 1060904)
         )
        )
       )
       (i32.const 1)
      )
      (then
       (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
        (i32.const 1060896)
        (local.get $3)
        (i32.const 2)
        (i32.const 4)
       )
       (local.set $3
        (i32.load
         (i32.const 1060904)
        )
       )
      )
     )
     (local.set $4
      (i32.const 0)
     )
     (i32.store offset=4
      (local.tee $6
       (i32.add
        (local.tee $7
         (i32.shl
          (local.get $3)
          (i32.const 2)
         )
        )
        (i32.load
         (i32.const 1060900)
        )
       )
      )
      (local.get $5)
     )
     (i32.store
      (local.get $6)
      (local.get $0)
     )
     (i32.store
      (i32.const 1060904)
      (local.tee $5
       (i32.add
        (local.get $3)
        (i32.const 2)
       )
      )
     )
     (i32.store
      (i32.const 1060892)
      (local.tee $0
       (i32.add
        (i32.load
         (i32.const 1060892)
        )
        (i32.const 1)
       )
      )
     )
     (br_if $block1
      (local.get $0)
     )
     (i32.store
      (i32.const 1060892)
      (i32.const -1)
     )
     (i32.store
      (i32.const 1060892)
      (if (result i32)
       (local.get $2)
       (then
        (local.set $6
         (i32.add
          (local.get $1)
          (local.get $2)
         )
        )
        (local.set $3
         (i32.add
          (local.get $7)
          (i32.const 8)
         )
        )
        (loop $label2
         (block $block3
          (local.set $1
           (block $block2 (result i32)
            (if
             (i32.ge_s
              (local.tee $0
               (i32.load8_s
                (local.get $1)
               )
              )
              (i32.const 0)
             )
             (then
              (local.set $4
               (i32.and
                (local.get $0)
                (i32.const 255)
               )
              )
              (br $block2
               (i32.add
                (local.get $1)
                (i32.const 1)
               )
              )
             )
            )
            (local.set $4
             (i32.and
              (i32.load8_u offset=1
               (local.get $1)
              )
              (i32.const 63)
             )
            )
            (local.set $2
             (i32.and
              (local.get $0)
              (i32.const 31)
             )
            )
            (if
             (i32.le_u
              (local.get $0)
              (i32.const -33)
             )
             (then
              (local.set $4
               (i32.or
                (i32.shl
                 (local.get $2)
                 (i32.const 6)
                )
                (local.get $4)
               )
              )
              (br $block2
               (i32.add
                (local.get $1)
                (i32.const 2)
               )
              )
             )
            )
            (local.set $4
             (i32.or
              (i32.and
               (i32.load8_u offset=2
                (local.get $1)
               )
               (i32.const 63)
              )
              (i32.shl
               (local.get $4)
               (i32.const 6)
              )
             )
            )
            (if
             (i32.lt_u
              (local.get $0)
              (i32.const -16)
             )
             (then
              (local.set $4
               (i32.or
                (local.get $4)
                (i32.shl
                 (local.get $2)
                 (i32.const 12)
                )
               )
              )
              (br $block2
               (i32.add
                (local.get $1)
                (i32.const 3)
               )
              )
             )
            )
            (br_if $block3
             (i32.eq
              (local.tee $4
               (i32.or
                (i32.and
                 (i32.shl
                  (local.get $2)
                  (i32.const 18)
                 )
                 (i32.const 1835008)
                )
                (i32.or
                 (i32.and
                  (i32.load8_u offset=3
                   (local.get $1)
                  )
                  (i32.const 63)
                 )
                 (i32.shl
                  (local.get $4)
                  (i32.const 6)
                 )
                )
               )
              )
              (i32.const 1114112)
             )
            )
            (i32.add
             (local.get $1)
             (i32.const 4)
            )
           )
          )
          (if
           (i32.eq
            (i32.load
             (i32.const 1060896)
            )
            (local.get $5)
           )
           (then
            (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
             (i32.const 1060896)
             (local.get $5)
             (i32.add
              (i32.add
               (i32.shr_u
                (local.tee $0
                 (i32.sub
                  (local.get $6)
                  (local.get $1)
                 )
                )
                (i32.const 2)
               )
               (i32.ne
                (i32.and
                 (local.get $0)
                 (i32.const 3)
                )
                (i32.const 0)
               )
              )
              (i32.const 1)
             )
             (i32.const 4)
            )
           )
          )
          (i32.store
           (i32.const 1060904)
           (local.tee $5
            (i32.add
             (local.get $5)
             (i32.const 1)
            )
           )
          )
          (i32.store
           (i32.add
            (i32.load
             (i32.const 1060900)
            )
            (local.get $3)
           )
           (local.get $4)
          )
          (local.set $3
           (i32.add
            (local.get $3)
            (i32.const 4)
           )
          )
          (br_if $label2
           (i32.ne
            (local.get $1)
            (local.get $6)
           )
          )
         )
        )
        (i32.add
         (i32.load
          (i32.const 1060892)
         )
         (i32.const 1)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (return)
    )
   )
   (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
    (i32.const 1051304)
   )
   (unreachable)
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
   (i32.const 1051304)
  )
  (unreachable)
 )
 (func $_RNvNtNtCsdHhIpgkcIfN_4core3str5count14do_count_chars (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local.set $6
   (i32.and
    (local.tee $8
     (i32.add
      (local.get $1)
      (local.tee $5
       (i32.sub
        (local.get $0)
        (local.tee $7
         (i32.and
          (i32.add
           (local.get $0)
           (i32.const 3)
          )
          (i32.const -4)
         )
        )
       )
      )
     )
    )
    (i32.const 3)
   )
  )
  (local.set $1
   (i32.const 0)
  )
  (if
   (i32.ne
    (local.get $0)
    (local.get $7)
   )
   (then
    (if
     (i32.le_u
      (local.get $5)
      (i32.const -4)
     )
     (then
      (loop $label
       (local.set $1
        (i32.add
         (i32.add
          (i32.add
           (i32.add
            (local.get $1)
            (i32.gt_s
             (i32.load8_s
              (local.tee $2
               (i32.add
                (local.get $0)
                (local.get $4)
               )
              )
             )
             (i32.const -65)
            )
           )
           (i32.gt_s
            (i32.load8_s
             (i32.add
              (local.get $2)
              (i32.const 1)
             )
            )
            (i32.const -65)
           )
          )
          (i32.gt_s
           (i32.load8_s
            (i32.add
             (local.get $2)
             (i32.const 2)
            )
           )
           (i32.const -65)
          )
         )
         (i32.gt_s
          (i32.load8_s
           (i32.add
            (local.get $2)
            (i32.const 3)
           )
          )
          (i32.const -65)
         )
        )
       )
       (br_if $label
        (local.tee $4
         (i32.add
          (local.get $4)
          (i32.const 4)
         )
        )
       )
      )
     )
    )
    (local.set $2
     (i32.add
      (local.get $0)
      (local.get $4)
     )
    )
    (loop $label1
     (local.set $1
      (i32.add
       (local.get $1)
       (i32.gt_s
        (i32.load8_s
         (local.get $2)
        )
        (i32.const -65)
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label1
      (local.tee $5
       (i32.add
        (local.get $5)
        (i32.const 1)
       )
      )
     )
    )
   )
  )
  (block $block
   (br_if $block
    (i32.eqz
     (local.get $6)
    )
   )
   (local.set $3
    (i32.gt_s
     (i32.load8_s
      (local.tee $0
       (i32.add
        (local.get $7)
        (i32.and
         (local.get $8)
         (i32.const 2147483644)
        )
       )
      )
     )
     (i32.const -65)
    )
   )
   (br_if $block
    (i32.eq
     (local.get $6)
     (i32.const 1)
    )
   )
   (local.set $3
    (i32.add
     (local.get $3)
     (i32.gt_s
      (i32.load8_s offset=1
       (local.get $0)
      )
      (i32.const -65)
     )
    )
   )
   (br_if $block
    (i32.eq
     (local.get $6)
     (i32.const 2)
    )
   )
   (local.set $3
    (i32.add
     (local.get $3)
     (i32.gt_s
      (i32.load8_s offset=2
       (local.get $0)
      )
      (i32.const -65)
     )
    )
   )
  )
  (local.set $4
   (i32.shr_u
    (local.get $8)
    (i32.const 2)
   )
  )
  (local.set $3
   (i32.add
    (local.get $1)
    (local.get $3)
   )
  )
  (block $block1
   (loop $label3
    (local.set $0
     (local.get $7)
    )
    (br_if $block1
     (i32.eqz
      (local.get $4)
     )
    )
    (local.set $6
     (i32.and
      (local.tee $5
       (select
        (i32.const 192)
        (local.get $4)
        (i32.ge_u
         (local.get $4)
         (i32.const 192)
        )
       )
      )
      (i32.const 3)
     )
    )
    (block $block2
     (if
      (i32.eqz
       (local.tee $1
        (i32.and
         (local.tee $7
          (i32.shl
           (local.get $5)
           (i32.const 2)
          )
         )
         (i32.const 1008)
        )
       )
      )
      (then
       (local.set $2
        (i32.const 0)
       )
       (br $block2)
      )
     )
     (local.set $8
      (i32.add
       (local.get $0)
       (local.get $1)
      )
     )
     (local.set $2
      (i32.const 0)
     )
     (local.set $1
      (local.get $0)
     )
     (loop $label2
      (local.set $2
       (i32.add
        (i32.add
         (i32.add
          (i32.add
           (local.get $2)
           (i32.and
            (i32.or
             (i32.shr_u
              (i32.xor
               (local.tee $2
                (i32.load
                 (local.get $1)
                )
               )
               (i32.const -1)
              )
              (i32.const 7)
             )
             (i32.shr_u
              (local.get $2)
              (i32.const 6)
             )
            )
            (i32.const 16843009)
           )
          )
          (i32.and
           (i32.or
            (i32.shr_u
             (i32.xor
              (local.tee $2
               (i32.load
                (i32.add
                 (local.get $1)
                 (i32.const 4)
                )
               )
              )
              (i32.const -1)
             )
             (i32.const 7)
            )
            (i32.shr_u
             (local.get $2)
             (i32.const 6)
            )
           )
           (i32.const 16843009)
          )
         )
         (i32.and
          (i32.or
           (i32.shr_u
            (i32.xor
             (local.tee $2
              (i32.load
               (i32.add
                (local.get $1)
                (i32.const 8)
               )
              )
             )
             (i32.const -1)
            )
            (i32.const 7)
           )
           (i32.shr_u
            (local.get $2)
            (i32.const 6)
           )
          )
          (i32.const 16843009)
         )
        )
        (i32.and
         (i32.or
          (i32.shr_u
           (i32.xor
            (local.tee $2
             (i32.load
              (i32.add
               (local.get $1)
               (i32.const 12)
              )
             )
            )
            (i32.const -1)
           )
           (i32.const 7)
          )
          (i32.shr_u
           (local.get $2)
           (i32.const 6)
          )
         )
         (i32.const 16843009)
        )
       )
      )
      (br_if $label2
       (i32.ne
        (local.tee $1
         (i32.add
          (local.get $1)
          (i32.const 16)
         )
        )
        (local.get $8)
       )
      )
     )
    )
    (local.set $4
     (i32.sub
      (local.get $4)
      (local.get $5)
     )
    )
    (local.set $7
     (i32.add
      (local.get $0)
      (local.get $7)
     )
    )
    (local.set $3
     (i32.add
      (i32.shr_u
       (i32.mul
        (i32.add
         (i32.and
          (i32.shr_u
           (local.get $2)
           (i32.const 8)
          )
          (i32.const 16711935)
         )
         (i32.and
          (local.get $2)
          (i32.const 16711935)
         )
        )
        (i32.const 65537)
       )
       (i32.const 16)
      )
      (local.get $3)
     )
    )
    (br_if $label3
     (i32.eqz
      (local.get $6)
     )
    )
   )
   (local.set $3
    (i32.add
     (i32.shr_u
      (i32.mul
       (i32.add
        (i32.and
         (i32.shr_u
          (local.tee $1
           (block $block3 (result i32)
            (drop
             (br_if $block3
              (local.tee $1
               (i32.and
                (i32.or
                 (i32.shr_u
                  (i32.xor
                   (local.tee $1
                    (i32.load
                     (local.tee $0
                      (i32.add
                       (local.get $0)
                       (i32.shl
                        (i32.and
                         (local.get $5)
                         (i32.const 252)
                        )
                        (i32.const 2)
                       )
                      )
                     )
                    )
                   )
                   (i32.const -1)
                  )
                  (i32.const 7)
                 )
                 (i32.shr_u
                  (local.get $1)
                  (i32.const 6)
                 )
                )
                (i32.const 16843009)
               )
              )
              (i32.eq
               (local.get $6)
               (i32.const 1)
              )
             )
            )
            (drop
             (br_if $block3
              (local.tee $1
               (i32.add
                (local.get $1)
                (i32.and
                 (i32.or
                  (i32.shr_u
                   (i32.xor
                    (local.tee $1
                     (i32.load offset=4
                      (local.get $0)
                     )
                    )
                    (i32.const -1)
                   )
                   (i32.const 7)
                  )
                  (i32.shr_u
                   (local.get $1)
                   (i32.const 6)
                  )
                 )
                 (i32.const 16843009)
                )
               )
              )
              (i32.eq
               (local.get $6)
               (i32.const 2)
              )
             )
            )
            (i32.add
             (i32.and
              (i32.or
               (i32.shr_u
                (i32.xor
                 (local.tee $0
                  (i32.load offset=8
                   (local.get $0)
                  )
                 )
                 (i32.const -1)
                )
                (i32.const 7)
               )
               (i32.shr_u
                (local.get $0)
                (i32.const 6)
               )
              )
              (i32.const 16843009)
             )
             (local.get $1)
            )
           )
          )
          (i32.const 8)
         )
         (i32.const 459007)
        )
        (i32.and
         (local.get $1)
         (i32.const 16711935)
        )
       )
       (i32.const 65537)
      )
      (i32.const 16)
     )
     (local.get $3)
    )
   )
  )
  (local.get $3)
 )
 (func $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i64)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (if
   (i32.gt_u
    (local.get $2)
    (local.tee $1
     (i32.add
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
     (i32.const 0)
     (i32.const 0)
    )
    (unreachable)
   )
  )
  (local.set $2
   (i32.add
    (local.get $4)
    (i32.const 4)
   )
  )
  (local.set $7
   (i32.load
    (local.get $0)
   )
  )
  (local.set $9
   (i32.load offset=4
    (local.get $0)
   )
  )
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $8
   (i32.const 1)
  )
  (local.set $6
   (i32.const 4)
  )
  (block $block
   (if
    (i64.ne
     (i64.shr_u
      (local.tee $10
       (i64.mul
        (i64.extend_i32_u
         (local.get $3)
        )
        (i64.extend_i32_u
         (local.tee $3
          (select
           (i32.const 4)
           (local.tee $1
            (select
             (local.get $1)
             (local.tee $3
              (i32.shl
               (local.get $7)
               (i32.const 1)
              )
             )
             (i32.gt_u
              (local.get $1)
              (local.get $3)
             )
            )
           )
           (i32.le_u
            (local.get $1)
            (i32.const 4)
           )
          )
         )
        )
       )
      )
      (i64.const 32)
     )
     (i64.const 0)
    )
    (then
     (local.set $1
      (i32.const 0)
     )
     (br $block)
    )
   )
   (if
    (i32.gt_u
     (local.tee $1
      (i32.wrap_i64
       (local.get $10)
      )
     )
     (i32.const 2147483644)
    )
    (then
     (local.set $1
      (i32.const 0)
     )
     (br $block)
    )
   )
   (block $block4
    (block $block2
     (block $block3
      (br_if $block2
       (local.tee $6
        (block $block1 (result i32)
         (if
          (local.get $7)
          (then
           (br $block1
            (call $realloc
             (local.get $9)
             (local.get $1)
            )
           )
          )
         )
         (br_if $block2
          (i32.eqz
           (local.get $1)
          )
         )
         (if
          (i32.le_u
           (local.get $1)
           (i32.const 3)
          )
          (then
           (i32.store offset=12
            (local.get $5)
            (i32.const 0)
           )
           (br_if $block3
            (call $posix_memalign
             (i32.add
              (local.get $5)
              (i32.const 12)
             )
             (local.get $1)
            )
           )
           (br $block1
            (i32.load offset=12
             (local.get $5)
            )
           )
          )
         )
         (call $dlmalloc
          (local.get $1)
         )
        )
       )
      )
     )
     (i32.store offset=4
      (local.get $2)
      (i32.const 4)
     )
     (br $block4)
    )
    (i32.store offset=4
     (local.get $2)
     (local.get $6)
    )
    (local.set $8
     (i32.const 0)
    )
   )
   (local.set $6
    (i32.const 8)
   )
  )
  (i32.store
   (i32.add
    (local.get $2)
    (local.get $6)
   )
   (local.get $1)
  )
  (i32.store
   (local.get $2)
   (local.get $8)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
  )
  (if
   (i32.eq
    (i32.load offset=4
     (local.get $4)
    )
    (i32.const 1)
   )
   (then
    (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
     (i32.load offset=8
      (local.get $4)
     )
     (i32.load offset=12
      (local.get $4)
     )
    )
    (unreachable)
   )
  )
  (local.set $1
   (i32.load offset=8
    (local.get $4)
   )
  )
  (i32.store
   (local.get $0)
   (local.get $3)
  )
  (i32.store offset=4
   (local.get $0)
   (local.get $1)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $4)
    (i32.const 16)
   )
  )
 )
 (func $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed (param $0 i32)
  (local $1 i32)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i64.store
   (local.get $1)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $1)
      (i32.const 15)
     )
    )
    (i64.const 12884901888)
   )
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1049279)
   (local.get $1)
   (local.get $0)
  )
  (unreachable)
 )
 (func $_ZN15bv2string_probe13observe_bytes17hc459c5ad045d1dd1E (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $scratch i32)
  (i32.store
   (i32.const 1060892)
   (block $block2 (result i32)
    (block $block1
     (block $block
      (if
       (i32.eqz
        (i32.load
         (i32.const 1060892)
        )
       )
       (then
        (i32.store
         (i32.const 1060892)
         (i32.const -1)
        )
        (if
         (i32.le_u
          (i32.sub
           (i32.load
            (i32.const 1060896)
           )
           (local.tee $3
            (i32.load
             (i32.const 1060904)
            )
           )
          )
          (i32.const 1)
         )
         (then
          (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
           (i32.const 1060896)
           (local.get $3)
           (i32.const 2)
           (i32.const 4)
          )
          (local.set $3
           (i32.load
            (i32.const 1060904)
           )
          )
         )
        )
        (i32.store offset=4
         (local.tee $5
          (i32.add
           (i32.load
            (i32.const 1060900)
           )
           (i32.shl
            (local.get $3)
            (i32.const 2)
           )
          )
         )
         (local.get $2)
        )
        (i32.store
         (local.get $5)
         (local.get $0)
        )
        (i32.store
         (i32.const 1060904)
         (local.tee $3
          (i32.add
           (local.get $3)
           (i32.const 2)
          )
         )
        )
        (i32.store
         (i32.const 1060892)
         (local.tee $0
          (i32.add
           (i32.load
            (i32.const 1060892)
           )
           (i32.const 1)
          )
         )
        )
        (br_if $block
         (local.get $0)
        )
        (i32.store
         (i32.const 1060892)
         (i32.const -1)
        )
        (if
         (i32.lt_u
          (i32.sub
           (i32.load
            (i32.const 1060896)
           )
           (local.get $3)
          )
          (local.get $2)
         )
         (then
          (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
           (i32.const 1060896)
           (local.get $3)
           (local.get $2)
           (i32.const 4)
          )
          (local.set $3
           (i32.load
            (i32.const 1060904)
           )
          )
          (br $block1)
         )
        )
        (br_if $block1
         (local.get $2)
        )
        (br $block2
         (i32.const 0)
        )
       )
      )
      (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
       (i32.const 1051304)
      )
      (unreachable)
     )
     (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
      (i32.const 1051304)
     )
     (unreachable)
    )
    (local.set $0
     (i32.and
      (local.get $2)
      (i32.const 3)
     )
    )
    (local.set $7
     (i32.load
      (i32.const 1060900)
     )
    )
    (local.set $3
     (block $block5 (result i32)
      (if
       (i32.ge_u
        (i32.sub
         (local.get $2)
         (i32.const 1)
        )
        (i32.const 3)
       )
       (then
        (drop
         (br_if $block5
          (local.tee $3
           (block $block4 (result i32)
            (block $block3
             (if
              (i32.eqz
               (local.tee $2
                (i32.shr_u
                 (i32.sub
                  (local.get $2)
                  (i32.const 4)
                 )
                 (i32.const 2)
                )
               )
              )
              (then
               (br $block3)
              )
             )
             (local.set $5
              (i32.and
               (local.tee $2
                (i32.add
                 (local.get $2)
                 (i32.const 1)
                )
               )
               (i32.const 1)
              )
             )
             (local.set $8
              (i32.and
               (local.get $2)
               (i32.const 2147483646)
              )
             )
             (local.set $2
              (i32.add
               (local.get $7)
               (i32.shl
                (local.get $3)
                (i32.const 2)
               )
              )
             )
             (loop $label
              (i32.store
               (local.get $2)
               (i32.load8_u
                (local.tee $6
                 (i32.add
                  (local.get $1)
                  (local.get $4)
                 )
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $2)
                (i32.const 4)
               )
               (i32.load8_u
                (i32.add
                 (local.get $6)
                 (i32.const 1)
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $2)
                (i32.const 8)
               )
               (i32.load8_u
                (i32.add
                 (local.get $6)
                 (i32.const 2)
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $2)
                (i32.const 12)
               )
               (i32.load8_u
                (i32.add
                 (local.get $6)
                 (i32.const 3)
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $2)
                (i32.const 16)
               )
               (i32.load8_u
                (i32.add
                 (local.get $6)
                 (i32.const 4)
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $2)
                (i32.const 20)
               )
               (i32.load8_u
                (i32.add
                 (local.get $6)
                 (i32.const 5)
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $2)
                (i32.const 24)
               )
               (i32.load8_u
                (i32.add
                 (local.get $6)
                 (i32.const 6)
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $2)
                (i32.const 28)
               )
               (i32.load8_u
                (i32.add
                 (local.get $6)
                 (i32.const 7)
                )
               )
              )
              (local.set $2
               (i32.add
                (local.get $2)
                (i32.const 32)
               )
              )
              (local.set $4
               (i32.add
                (local.get $4)
                (i32.const 8)
               )
              )
              (br_if $label
               (local.tee $8
                (i32.sub
                 (local.get $8)
                 (i32.const 2)
                )
               )
              )
             )
             (drop
              (br_if $block4
               (local.tee $3
                (i32.add
                 (local.get $3)
                 (local.get $4)
                )
               )
               (i32.eqz
                (local.get $5)
               )
              )
             )
            )
            (i32.store
             (local.tee $5
              (i32.add
               (local.get $7)
               (i32.shl
                (local.get $3)
                (i32.const 2)
               )
              )
             )
             (i32.load8_u
              (local.tee $2
               (i32.add
                (local.get $1)
                (local.get $4)
               )
              )
             )
            )
            (i32.store
             (i32.add
              (local.get $5)
              (i32.const 4)
             )
             (i32.load8_u offset=1
              (local.get $2)
             )
            )
            (i32.store
             (i32.add
              (local.get $5)
              (i32.const 8)
             )
             (i32.load8_u offset=2
              (local.get $2)
             )
            )
            (i32.store
             (i32.add
              (local.get $5)
              (i32.const 12)
             )
             (i32.load8_u offset=3
              (local.get $2)
             )
            )
            (local.set $4
             (i32.add
              (local.get $4)
              (i32.const 4)
             )
            )
            (i32.add
             (local.get $3)
             (i32.const 4)
            )
           )
          )
          (i32.eqz
           (local.get $0)
          )
         )
        )
       )
      )
      (local.set $scratch
       (i32.add
        (local.get $0)
        (local.get $3)
       )
      )
      (local.set $2
       (i32.add
        (local.get $1)
        (local.get $4)
       )
      )
      (local.set $3
       (i32.add
        (local.get $7)
        (i32.shl
         (local.get $3)
         (i32.const 2)
        )
       )
      )
      (loop $label1
       (i32.store
        (local.get $3)
        (i32.load8_u
         (local.get $2)
        )
       )
       (local.set $2
        (i32.add
         (local.get $2)
         (i32.const 1)
        )
       )
       (local.set $3
        (i32.add
         (local.get $3)
         (i32.const 4)
        )
       )
       (br_if $label1
        (local.tee $0
         (i32.sub
          (local.get $0)
          (i32.const 1)
         )
        )
       )
      )
      (local.get $scratch)
     )
    )
    (i32.add
     (i32.load
      (i32.const 1060892)
     )
     (i32.const 1)
    )
   )
  )
  (i32.store
   (i32.const 1060904)
   (local.get $3)
  )
 )
 (func $_ZN15bv2string_probe4main17h8009ca56fb25b28eE (param $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i64)
  (local $21 i64)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $scratch i32)
  (local $scratch_27 i32)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 448)
    )
   )
  )
  (block $block18
   (block $block20
    (block $block12
     (block $block
      (br_if $block
       (call $_RNvNtNtCs9w8RDfpKrLd_4wasi13lib_generated22wasi_snapshot_preview114args_sizes_get
        (i32.add
         (local.get $1)
         (i32.const 32)
        )
        (i32.add
         (local.get $1)
         (i32.const 56)
        )
       )
      )
      (block $block6
       (block $block52
        (block $block53
         (block $block48
          (block $block45
           (block $block46
            (block $block47
             (block $block44
              (block $block37
               (block $block36
                (block $block43
                 (block $block39
                  (block $block42
                   (block $block41
                    (block $block40
                     (block $block38
                      (block $block29
                       (block $block34
                        (block $block33
                         (block $block35
                          (block $block28
                           (block $block32
                            (block $block31
                             (block $block30
                              (block $block21
                               (block $block26
                                (block $block25
                                 (block $block4
                                  (block $block15
                                   (block $block13
                                    (block $block11
                                     (block $block9
                                      (block $block3
                                       (block $block1
                                        (br_if $block1
                                         (i32.gt_u
                                          (local.tee $4
                                           (i32.load offset=32
                                            (local.get $1)
                                           )
                                          )
                                          (i32.const 1073741823)
                                         )
                                        )
                                        (br_if $block1
                                         (i32.ge_u
                                          (local.tee $12
                                           (i32.shl
                                            (local.get $4)
                                            (i32.const 2)
                                           )
                                          )
                                          (i32.const 2147483645)
                                         )
                                        )
                                        (local.set $7
                                         (i32.load offset=56
                                          (local.get $1)
                                         )
                                        )
                                        (block $block2
                                         (if
                                          (i32.eqz
                                           (local.get $12)
                                          )
                                          (then
                                           (local.set $8
                                            (i32.const 4)
                                           )
                                           (br $block2)
                                          )
                                         )
                                         (local.set $6
                                          (local.get $4)
                                         )
                                         (br_if $block3
                                          (i32.eqz
                                           (local.tee $8
                                            (call $dlmalloc
                                             (local.get $12)
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (br_if $block1
                                         (i32.lt_s
                                          (local.get $7)
                                          (i32.const 0)
                                         )
                                        )
                                        (block $block5
                                         (if
                                          (local.get $7)
                                          (then
                                           (br_if $block4
                                            (i32.eqz
                                             (local.tee $9
                                              (call $dlmalloc
                                               (local.get $7)
                                              )
                                             )
                                            )
                                           )
                                           (br_if $block5
                                            (i32.eqz
                                             (call $_RNvNtNtCs9w8RDfpKrLd_4wasi13lib_generated22wasi_snapshot_preview18args_get
                                              (local.get $8)
                                              (local.get $9)
                                             )
                                            )
                                           )
                                           (call $dlfree
                                            (local.get $9)
                                           )
                                           (br $block6)
                                          )
                                         )
                                         (local.set $9
                                          (i32.const 1)
                                         )
                                         (br_if $block6
                                          (call $_RNvNtNtCs9w8RDfpKrLd_4wasi13lib_generated22wasi_snapshot_preview18args_get
                                           (local.get $8)
                                           (i32.const 1)
                                          )
                                         )
                                        )
                                        (br_if $block1
                                         (i32.ge_u
                                          (local.get $4)
                                          (i32.const 178956971)
                                         )
                                        )
                                        (block $block7
                                         (if
                                          (i32.eqz
                                           (local.tee $5
                                            (i32.mul
                                             (local.get $4)
                                             (i32.const 12)
                                            )
                                           )
                                          )
                                          (then
                                           (local.set $10
                                            (i32.const 4)
                                           )
                                           (br $block7)
                                          )
                                         )
                                         (local.set $3
                                          (local.get $4)
                                         )
                                         (global.set $__stack_pointer
                                          (local.tee $13
                                           (i32.sub
                                            (global.get $__stack_pointer)
                                            (i32.const 16)
                                           )
                                          )
                                         )
                                         (local.set $10
                                          (block $block8 (result i32)
                                           (if
                                            (i32.lt_u
                                             (local.get $5)
                                             (i32.const 4)
                                            )
                                            (then
                                             (i32.store offset=12
                                              (local.get $13)
                                              (i32.const 0)
                                             )
                                             (local.set $2
                                              (call $posix_memalign
                                               (i32.add
                                                (local.get $13)
                                                (i32.const 12)
                                               )
                                               (local.get $5)
                                              )
                                             )
                                             (br $block8
                                              (select
                                               (i32.const 0)
                                               (i32.load offset=12
                                                (local.get $13)
                                               )
                                               (local.get $2)
                                              )
                                             )
                                            )
                                           )
                                           (call $dlmalloc
                                            (local.get $5)
                                           )
                                          )
                                         )
                                         (global.set $__stack_pointer
                                          (i32.add
                                           (local.get $13)
                                           (i32.const 16)
                                          )
                                         )
                                         (br_if $block9
                                          (i32.eqz
                                           (local.get $10)
                                          )
                                         )
                                        )
                                        (i32.store offset=64
                                         (local.get $1)
                                         (i32.const 0)
                                        )
                                        (i32.store offset=60
                                         (local.get $1)
                                         (local.get $10)
                                        )
                                        (i32.store offset=56
                                         (local.get $1)
                                         (local.get $3)
                                        )
                                        (if
                                         (local.get $4)
                                         (then
                                          (local.set $2
                                           (i32.const 8)
                                          )
                                          (local.set $3
                                           (local.get $8)
                                          )
                                          (loop $label
                                           (local.set $5
                                            (i32.const 1)
                                           )
                                           (block $block10
                                            (br_if $block10
                                             (i32.eqz
                                              (local.tee $15
                                               (call $strlen
                                                (local.tee $4
                                                 (i32.load
                                                  (local.get $3)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (br_if $block11
                                             (i32.eqz
                                              (local.tee $5
                                               (call $dlmalloc
                                                (local.get $15)
                                               )
                                              )
                                             )
                                            )
                                            (br_if $block10
                                             (i32.eqz
                                              (local.get $15)
                                             )
                                            )
                                            (memory.copy
                                             (local.get $5)
                                             (local.get $4)
                                             (local.get $15)
                                            )
                                           )
                                           (local.set $3
                                            (i32.add
                                             (local.get $3)
                                             (i32.const 4)
                                            )
                                           )
                                           (if
                                            (i32.eq
                                             (i32.load offset=56
                                              (local.get $1)
                                             )
                                             (local.get $14)
                                            )
                                            (then
                                             (global.set $__stack_pointer
                                              (local.tee $11
                                               (i32.sub
                                                (global.get $__stack_pointer)
                                                (i32.const 16)
                                               )
                                              )
                                             )
                                             (call $_RNvMs4_NtCsi9YzqDQQz2q_5alloc7raw_vecNtB5_11RawVecInner11finish_growCset5xJoy1xWQ_3std
                                              (i32.add
                                               (local.get $11)
                                               (i32.const 4)
                                              )
                                              (local.tee $4
                                               (i32.load
                                                (local.tee $10
                                                 (i32.add
                                                  (local.get $1)
                                                  (i32.const 56)
                                                 )
                                                )
                                               )
                                              )
                                              (i32.load offset=4
                                               (local.get $10)
                                              )
                                              (local.tee $13
                                               (select
                                                (i32.const 4)
                                                (local.tee $4
                                                 (i32.shl
                                                  (local.get $4)
                                                  (i32.const 1)
                                                 )
                                                )
                                                (i32.le_u
                                                 (local.get $4)
                                                 (i32.const 4)
                                                )
                                               )
                                              )
                                              (i32.const 4)
                                              (i32.const 12)
                                             )
                                             (if
                                              (i32.eq
                                               (i32.load offset=4
                                                (local.get $11)
                                               )
                                               (i32.const 1)
                                              )
                                              (then
                                               (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
                                                (i32.load offset=8
                                                 (local.get $11)
                                                )
                                                (i32.load offset=12
                                                 (local.get $11)
                                                )
                                               )
                                               (unreachable)
                                              )
                                             )
                                             (local.set $4
                                              (i32.load offset=8
                                               (local.get $11)
                                              )
                                             )
                                             (i32.store
                                              (local.get $10)
                                              (local.get $13)
                                             )
                                             (i32.store offset=4
                                              (local.get $10)
                                              (local.get $4)
                                             )
                                             (global.set $__stack_pointer
                                              (i32.add
                                               (local.get $11)
                                               (i32.const 16)
                                              )
                                             )
                                             (local.set $10
                                              (i32.load offset=60
                                               (local.get $1)
                                              )
                                             )
                                            )
                                           )
                                           (i32.store
                                            (local.tee $4
                                             (i32.add
                                              (local.get $2)
                                              (local.get $10)
                                             )
                                            )
                                            (local.get $15)
                                           )
                                           (i32.store
                                            (i32.sub
                                             (local.get $4)
                                             (i32.const 4)
                                            )
                                            (local.get $5)
                                           )
                                           (i32.store
                                            (i32.sub
                                             (local.get $4)
                                             (i32.const 8)
                                            )
                                            (local.get $15)
                                           )
                                           (i32.store offset=64
                                            (local.get $1)
                                            (local.tee $14
                                             (i32.add
                                              (local.get $14)
                                              (i32.const 1)
                                             )
                                            )
                                           )
                                           (local.set $2
                                            (i32.add
                                             (local.get $2)
                                             (i32.const 12)
                                            )
                                           )
                                           (br_if $label
                                            (local.tee $12
                                             (i32.sub
                                              (local.get $12)
                                              (i32.const 4)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (if
                                         (local.get $6)
                                         (then
                                          (call $dlfree
                                           (local.get $8)
                                          )
                                         )
                                        )
                                        (local.set $2
                                         (i32.load offset=60
                                          (local.get $1)
                                         )
                                        )
                                        (local.set $8
                                         (i32.load offset=56
                                          (local.get $1)
                                         )
                                        )
                                        (if
                                         (local.get $7)
                                         (then
                                          (call $dlfree
                                           (local.get $9)
                                          )
                                         )
                                        )
                                        (br_if $block
                                         (i32.eq
                                          (local.get $8)
                                          (i32.const -2147483648)
                                         )
                                        )
                                        (local.set $9
                                         (i32.add
                                          (local.get $2)
                                          (local.tee $5
                                           (i32.mul
                                            (local.get $14)
                                            (i32.const 12)
                                           )
                                          )
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (local.get $14)
                                         )
                                         (then
                                          (local.set $4
                                           (local.get $2)
                                          )
                                          (br $block12)
                                         )
                                        )
                                        (local.set $4
                                         (i32.add
                                          (local.get $2)
                                          (i32.const 12)
                                         )
                                        )
                                        (br_if $block12
                                         (i32.eq
                                          (local.tee $3
                                           (i32.load
                                            (local.get $2)
                                           )
                                          )
                                          (i32.const -2147483648)
                                         )
                                        )
                                        (local.set $20
                                         (i64.load offset=4 align=4
                                          (local.get $2)
                                         )
                                        )
                                        (i32.store offset=16
                                         (local.get $1)
                                         (local.get $3)
                                        )
                                        (i64.store offset=20 align=4
                                         (local.get $1)
                                         (local.get $20)
                                        )
                                        (local.set $21
                                         (i64.load offset=16
                                          (local.get $1)
                                         )
                                        )
                                        (call $_RNvNtNtCsdHhIpgkcIfN_4core3str8converts9from_utf8
                                         (i32.add
                                          (local.get $1)
                                          (i32.const 32)
                                         )
                                         (i32.wrap_i64
                                          (local.get $20)
                                         )
                                         (local.tee $13
                                          (i32.wrap_i64
                                           (i64.shr_u
                                            (local.get $20)
                                            (i64.const 32)
                                           )
                                          )
                                         )
                                        )
                                        (br_if $block13
                                         (i32.load offset=32
                                          (local.get $1)
                                         )
                                        )
                                        (br_if $block12
                                         (i32.eq
                                          (i32.wrap_i64
                                           (local.get $21)
                                          )
                                          (i32.const -2147483648)
                                         )
                                        )
                                        (local.set $3
                                         (i32.div_u
                                          (local.tee $4
                                           (i32.sub
                                            (local.get $5)
                                            (i32.const 12)
                                           )
                                          )
                                          (i32.const 12)
                                         )
                                        )
                                        (br_if $block1
                                         (i32.ge_u
                                          (local.get $4)
                                          (i32.const 2147483629)
                                         )
                                        )
                                        (local.set $4
                                         (i32.const 0)
                                        )
                                        (block $block14
                                         (if
                                          (i32.eqz
                                           (local.tee $3
                                            (i32.mul
                                             (local.tee $14
                                              (i32.add
                                               (select
                                                (i32.const 3)
                                                (local.get $3)
                                                (i32.le_u
                                                 (local.get $3)
                                                 (i32.const 3)
                                                )
                                               )
                                               (i32.const 1)
                                              )
                                             )
                                             (i32.const 12)
                                            )
                                           )
                                          )
                                          (then
                                           (local.set $12
                                            (i32.const 4)
                                           )
                                           (local.set $14
                                            (i32.const 0)
                                           )
                                           (br $block14)
                                          )
                                         )
                                         (br_if $block15
                                          (i32.eqz
                                           (local.tee $12
                                            (call $dlmalloc
                                             (local.get $3)
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (i32.store offset=8
                                         (local.get $12)
                                         (local.get $13)
                                        )
                                        (i64.store align=4
                                         (local.get $12)
                                         (local.get $21)
                                        )
                                        (i32.store offset=12
                                         (local.get $1)
                                         (i32.const 1)
                                        )
                                        (i32.store offset=8
                                         (local.get $1)
                                         (local.get $12)
                                        )
                                        (i32.store offset=4
                                         (local.get $1)
                                         (local.get $14)
                                        )
                                        (local.set $13
                                         (i32.sub
                                          (local.get $5)
                                          (i32.const 12)
                                         )
                                        )
                                        (local.set $7
                                         (i32.sub
                                          (local.get $5)
                                          (i32.const 24)
                                         )
                                        )
                                        (local.set $14
                                         (i32.const 1)
                                        )
                                        (local.set $3
                                         (i32.div_u
                                          (i32.sub
                                           (local.get $9)
                                           (local.tee $4
                                            (block $block19 (result i32)
                                             (loop $label1
                                              (local.set $6
                                               (i32.add
                                                (local.get $2)
                                                (local.get $4)
                                               )
                                              )
                                              (block $block17
                                               (block $block16
                                                (if
                                                 (i32.ne
                                                  (local.get $4)
                                                  (local.get $13)
                                                 )
                                                 (then
                                                  (br_if $block16
                                                   (i32.eq
                                                    (local.tee $3
                                                     (i32.load
                                                      (i32.add
                                                       (local.get $6)
                                                       (i32.const 12)
                                                      )
                                                     )
                                                    )
                                                    (i32.const -2147483648)
                                                   )
                                                  )
                                                  (i32.store offset=16
                                                   (local.get $1)
                                                   (local.get $3)
                                                  )
                                                  (i64.store offset=20 align=4
                                                   (local.get $1)
                                                   (local.tee $20
                                                    (i64.load align=4
                                                     (i32.add
                                                      (local.get $6)
                                                      (i32.const 16)
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (local.set $21
                                                   (i64.load offset=16
                                                    (local.get $1)
                                                   )
                                                  )
                                                  (call $_RNvNtNtCsdHhIpgkcIfN_4core3str8converts9from_utf8
                                                   (i32.add
                                                    (local.get $1)
                                                    (i32.const 32)
                                                   )
                                                   (i32.wrap_i64
                                                    (local.get $20)
                                                   )
                                                   (local.tee $5
                                                    (i32.wrap_i64
                                                     (i64.shr_u
                                                      (local.get $20)
                                                      (i64.const 32)
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (br_if $block17
                                                   (i32.eqz
                                                    (i32.load offset=32
                                                     (local.get $1)
                                                    )
                                                   )
                                                  )
                                                  (i64.store offset=60 align=4
                                                   (local.get $1)
                                                   (local.get $20)
                                                  )
                                                  (i64.store32 offset=56
                                                   (local.get $1)
                                                   (local.get $21)
                                                  )
                                                  (local.set $20
                                                   (i64.load offset=56
                                                    (local.get $1)
                                                   )
                                                  )
                                                  (i32.store offset=64
                                                   (local.get $1)
                                                   (local.get $5)
                                                  )
                                                  (br $block18)
                                                 )
                                                )
                                                (br $block19
                                                 (i32.add
                                                  (local.get $6)
                                                  (i32.const 12)
                                                 )
                                                )
                                               )
                                               (br $block19
                                                (i32.add
                                                 (local.get $6)
                                                 (i32.const 24)
                                                )
                                               )
                                              )
                                              (if
                                               (i32.ne
                                                (i32.wrap_i64
                                                 (local.get $21)
                                                )
                                                (i32.const -2147483648)
                                               )
                                               (then
                                                (if
                                                 (i32.eq
                                                  (i32.load offset=4
                                                   (local.get $1)
                                                  )
                                                  (local.get $14)
                                                 )
                                                 (then
                                                  (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
                                                   (i32.add
                                                    (local.get $1)
                                                    (i32.const 4)
                                                   )
                                                   (local.get $14)
                                                   (i32.add
                                                    (i32.div_u
                                                     (local.get $7)
                                                     (i32.const 12)
                                                    )
                                                    (i32.const 1)
                                                   )
                                                   (i32.const 12)
                                                  )
                                                  (local.set $12
                                                   (i32.load offset=8
                                                    (local.get $1)
                                                   )
                                                  )
                                                 )
                                                )
                                                (i32.store
                                                 (i32.add
                                                  (local.tee $3
                                                   (i32.add
                                                    (local.get $4)
                                                    (local.get $12)
                                                   )
                                                  )
                                                  (i32.const 20)
                                                 )
                                                 (local.get $5)
                                                )
                                                (i64.store align=4
                                                 (i32.add
                                                  (local.get $3)
                                                  (i32.const 12)
                                                 )
                                                 (local.get $21)
                                                )
                                                (i32.store offset=12
                                                 (local.get $1)
                                                 (local.tee $14
                                                  (i32.add
                                                   (local.get $14)
                                                   (i32.const 1)
                                                  )
                                                 )
                                                )
                                                (local.set $7
                                                 (i32.sub
                                                  (local.get $7)
                                                  (i32.const 12)
                                                 )
                                                )
                                                (local.set $4
                                                 (i32.add
                                                  (local.get $4)
                                                  (i32.const 12)
                                                 )
                                                )
                                                (br $label1)
                                               )
                                              )
                                             )
                                             (i32.add
                                              (local.get $6)
                                              (i32.const 24)
                                             )
                                            )
                                           )
                                          )
                                          (i32.const 12)
                                         )
                                        )
                                        (if
                                         (i32.ne
                                          (local.get $4)
                                          (local.get $9)
                                         )
                                         (then
                                          (loop $label2
                                           (if
                                            (i32.load
                                             (local.get $4)
                                            )
                                            (then
                                             (call $dlfree
                                              (i32.load
                                               (i32.add
                                                (local.get $4)
                                                (i32.const 4)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (local.set $4
                                            (i32.add
                                             (local.get $4)
                                             (i32.const 12)
                                            )
                                           )
                                           (br_if $label2
                                            (local.tee $3
                                             (i32.sub
                                              (local.get $3)
                                              (i32.const 1)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (if
                                         (local.get $8)
                                         (then
                                          (call $dlfree
                                           (local.get $2)
                                          )
                                         )
                                        )
                                        (br_if $block20
                                         (i32.lt_u
                                          (local.get $14)
                                          (i32.const 3)
                                         )
                                        )
                                        (local.set $15
                                         (i32.load offset=4
                                          (local.get $1)
                                         )
                                        )
                                        (local.set $5
                                         (i32.load offset=28
                                          (local.tee $13
                                           (i32.load offset=8
                                            (local.get $1)
                                           )
                                          )
                                         )
                                        )
                                        (local.set $7
                                         (i32.const 0)
                                        )
                                        (block $block24
                                         (block $block23
                                          (block $block22
                                           (br_table $block21 $block22 $block23
                                            (local.tee $3
                                             (i32.load offset=32
                                              (local.get $13)
                                             )
                                            )
                                           )
                                          )
                                          (local.set $7
                                           (i32.const 1)
                                          )
                                          (br_table $block21 $block24 $block21 $block24
                                           (i32.sub
                                            (local.tee $2
                                             (i32.load8_u
                                              (local.get $5)
                                             )
                                            )
                                            (i32.const 43)
                                           )
                                          )
                                         )
                                         (local.set $2
                                          (i32.load8_u
                                           (local.get $5)
                                          )
                                         )
                                        )
                                        (local.set $2
                                         (i32.add
                                          (local.get $5)
                                          (local.tee $4
                                           (i32.eq
                                            (i32.and
                                             (local.get $2)
                                             (i32.const 255)
                                            )
                                            (i32.const 43)
                                           )
                                          )
                                         )
                                        )
                                        (br_if $block25
                                         (i32.lt_u
                                          (local.tee $3
                                           (i32.sub
                                            (local.get $3)
                                            (local.get $4)
                                           )
                                          )
                                          (i32.const 9)
                                         )
                                        )
                                        (local.set $4
                                         (i32.const 0)
                                        )
                                        (block $block27
                                         (loop $label3
                                          (br_if $block26
                                           (i32.eqz
                                            (local.get $3)
                                           )
                                          )
                                          (local.set $5
                                           (i32.load8_u
                                            (local.get $2)
                                           )
                                          )
                                          (br_if $block27
                                           (i32.wrap_i64
                                            (i64.shr_u
                                             (local.tee $21
                                              (i64.mul
                                               (i64.extend_i32_u
                                                (local.get $4)
                                               )
                                               (i64.const 10)
                                              )
                                             )
                                             (i64.const 32)
                                            )
                                           )
                                          )
                                          (if
                                           (i32.ge_u
                                            (local.tee $5
                                             (i32.sub
                                              (local.get $5)
                                              (i32.const 48)
                                             )
                                            )
                                            (i32.const 10)
                                           )
                                           (then
                                            (local.set $7
                                             (i32.const 1)
                                            )
                                            (br $block21)
                                           )
                                          )
                                          (local.set $2
                                           (i32.add
                                            (local.get $2)
                                            (i32.const 1)
                                           )
                                          )
                                          (local.set $3
                                           (i32.sub
                                            (local.get $3)
                                            (i32.const 1)
                                           )
                                          )
                                          (br_if $label3
                                           (i32.le_u
                                            (local.get $5)
                                            (local.tee $4
                                             (i32.add
                                              (local.get $5)
                                              (i32.wrap_i64
                                               (local.get $21)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (local.set $7
                                          (i32.const 2)
                                         )
                                         (br $block21)
                                        )
                                        (local.set $7
                                         (select
                                          (i32.const 2)
                                          (i32.const 1)
                                          (i32.lt_u
                                           (i32.and
                                            (i32.sub
                                             (local.get $5)
                                             (i32.const 48)
                                            )
                                            (i32.const 255)
                                           )
                                           (i32.const 10)
                                          )
                                         )
                                        )
                                        (br $block21)
                                       )
                                       (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec17capacity_overflow)
                                       (unreachable)
                                      )
                                      (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
                                       (i32.const 4)
                                       (local.get $12)
                                      )
                                      (unreachable)
                                     )
                                     (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
                                      (i32.const 4)
                                      (local.get $5)
                                     )
                                     (unreachable)
                                    )
                                    (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
                                     (i32.const 1)
                                     (local.get $15)
                                    )
                                    (unreachable)
                                   )
                                   (i64.store offset=60 align=4
                                    (local.get $1)
                                    (local.get $20)
                                   )
                                   (i64.store32 offset=56
                                    (local.get $1)
                                    (local.get $21)
                                   )
                                   (local.set $20
                                    (i64.load offset=56
                                     (local.get $1)
                                    )
                                   )
                                   (i32.store offset=64
                                    (local.get $1)
                                    (local.get $13)
                                   )
                                   (br $block18)
                                  )
                                  (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
                                   (i32.const 4)
                                   (local.get $3)
                                  )
                                  (unreachable)
                                 )
                                 (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
                                  (i32.const 1)
                                  (local.get $7)
                                 )
                                 (unreachable)
                                )
                                (if
                                 (i32.eqz
                                  (local.get $3)
                                 )
                                 (then
                                  (local.set $4
                                   (i32.const 0)
                                  )
                                  (br $block26)
                                 )
                                )
                                (local.set $7
                                 (i32.const 1)
                                )
                                (br_if $block21
                                 (i32.gt_u
                                  (local.tee $4
                                   (i32.sub
                                    (i32.load8_u
                                     (local.get $2)
                                    )
                                    (i32.const 48)
                                   )
                                  )
                                  (i32.const 9)
                                 )
                                )
                                (br_if $block26
                                 (i32.eq
                                  (local.get $3)
                                  (i32.const 1)
                                 )
                                )
                                (br_if $block21
                                 (i32.gt_u
                                  (local.tee $5
                                   (i32.sub
                                    (i32.load8_u offset=1
                                     (local.get $2)
                                    )
                                    (i32.const 48)
                                   )
                                  )
                                  (i32.const 9)
                                 )
                                )
                                (local.set $4
                                 (i32.add
                                  (local.get $5)
                                  (i32.mul
                                   (local.get $4)
                                   (i32.const 10)
                                  )
                                 )
                                )
                                (br_if $block26
                                 (i32.eq
                                  (local.get $3)
                                  (i32.const 2)
                                 )
                                )
                                (br_if $block21
                                 (i32.gt_u
                                  (local.tee $5
                                   (i32.sub
                                    (i32.load8_u offset=2
                                     (local.get $2)
                                    )
                                    (i32.const 48)
                                   )
                                  )
                                  (i32.const 9)
                                 )
                                )
                                (local.set $4
                                 (i32.add
                                  (local.get $5)
                                  (i32.mul
                                   (local.get $4)
                                   (i32.const 10)
                                  )
                                 )
                                )
                                (br_if $block26
                                 (i32.eq
                                  (local.get $3)
                                  (i32.const 3)
                                 )
                                )
                                (br_if $block21
                                 (i32.gt_u
                                  (local.tee $5
                                   (i32.sub
                                    (i32.load8_u offset=3
                                     (local.get $2)
                                    )
                                    (i32.const 48)
                                   )
                                  )
                                  (i32.const 9)
                                 )
                                )
                                (local.set $4
                                 (i32.add
                                  (local.get $5)
                                  (i32.mul
                                   (local.get $4)
                                   (i32.const 10)
                                  )
                                 )
                                )
                                (br_if $block26
                                 (i32.eq
                                  (local.get $3)
                                  (i32.const 4)
                                 )
                                )
                                (br_if $block21
                                 (i32.gt_u
                                  (local.tee $5
                                   (i32.sub
                                    (i32.load8_u offset=4
                                     (local.get $2)
                                    )
                                    (i32.const 48)
                                   )
                                  )
                                  (i32.const 9)
                                 )
                                )
                                (local.set $4
                                 (i32.add
                                  (local.get $5)
                                  (i32.mul
                                   (local.get $4)
                                   (i32.const 10)
                                  )
                                 )
                                )
                                (br_if $block26
                                 (i32.eq
                                  (local.get $3)
                                  (i32.const 5)
                                 )
                                )
                                (br_if $block21
                                 (i32.gt_u
                                  (local.tee $5
                                   (i32.sub
                                    (i32.load8_u offset=5
                                     (local.get $2)
                                    )
                                    (i32.const 48)
                                   )
                                  )
                                  (i32.const 9)
                                 )
                                )
                                (local.set $4
                                 (i32.add
                                  (local.get $5)
                                  (i32.mul
                                   (local.get $4)
                                   (i32.const 10)
                                  )
                                 )
                                )
                                (br_if $block26
                                 (i32.eq
                                  (local.get $3)
                                  (i32.const 6)
                                 )
                                )
                                (br_if $block21
                                 (i32.gt_u
                                  (local.tee $5
                                   (i32.sub
                                    (i32.load8_u offset=6
                                     (local.get $2)
                                    )
                                    (i32.const 48)
                                   )
                                  )
                                  (i32.const 9)
                                 )
                                )
                                (local.set $4
                                 (i32.add
                                  (local.get $5)
                                  (i32.mul
                                   (local.get $4)
                                   (i32.const 10)
                                  )
                                 )
                                )
                                (br_if $block26
                                 (i32.eq
                                  (local.get $3)
                                  (i32.const 7)
                                 )
                                )
                                (br_if $block21
                                 (i32.gt_u
                                  (local.tee $3
                                   (i32.sub
                                    (i32.load8_u offset=7
                                     (local.get $2)
                                    )
                                    (i32.const 48)
                                   )
                                  )
                                  (i32.const 9)
                                 )
                                )
                                (local.set $4
                                 (i32.add
                                  (local.get $3)
                                  (i32.mul
                                   (local.get $4)
                                   (i32.const 10)
                                  )
                                 )
                                )
                               )
                               (br_if $block28
                                (i32.eq
                                 (local.get $14)
                                 (i32.const 3)
                                )
                               )
                               (local.set $6
                                (i32.load offset=40
                                 (local.get $13)
                                )
                               )
                               (local.set $5
                                (i32.const 0)
                               )
                               (br_table $block29 $block30 $block31
                                (local.tee $2
                                 (i32.load offset=44
                                  (local.get $13)
                                 )
                                )
                               )
                              )
                              (i32.store8 offset=56
                               (local.get $1)
                               (local.get $7)
                              )
                              (call $_RNvNtCsdHhIpgkcIfN_4core6result13unwrap_failed
                               (i32.add
                                (local.get $1)
                                (i32.const 56)
                               )
                               (i32.const 1051176)
                               (i32.const 1051208)
                              )
                              (unreachable)
                             )
                             (local.set $5
                              (i32.const 1)
                             )
                             (br_table $block29 $block32 $block29 $block32
                              (i32.sub
                               (local.tee $7
                                (i32.load8_u
                                 (local.get $6)
                                )
                               )
                               (i32.const 43)
                              )
                             )
                            )
                            (local.set $7
                             (i32.load8_u
                              (local.get $6)
                             )
                            )
                           )
                           (local.set $7
                            (i32.add
                             (local.get $6)
                             (local.tee $3
                              (i32.eq
                               (i32.and
                                (local.get $7)
                                (i32.const 255)
                               )
                               (i32.const 43)
                              )
                             )
                            )
                           )
                           (br_if $block33
                            (i32.lt_u
                             (local.tee $2
                              (i32.sub
                               (local.get $2)
                               (local.get $3)
                              )
                             )
                             (i32.const 9)
                            )
                           )
                           (local.set $3
                            (i32.const 0)
                           )
                           (loop $label4
                            (br_if $block34
                             (i32.eqz
                              (local.get $2)
                             )
                            )
                            (local.set $5
                             (i32.load8_u
                              (local.get $7)
                             )
                            )
                            (br_if $block35
                             (i32.wrap_i64
                              (i64.shr_u
                               (local.tee $21
                                (i64.mul
                                 (i64.extend_i32_u
                                  (local.get $3)
                                 )
                                 (i64.const 10)
                                )
                               )
                               (i64.const 32)
                              )
                             )
                            )
                            (if
                             (i32.ge_u
                              (local.tee $5
                               (i32.sub
                                (local.get $5)
                                (i32.const 48)
                               )
                              )
                              (i32.const 10)
                             )
                             (then
                              (local.set $5
                               (i32.const 1)
                              )
                              (br $block29)
                             )
                            )
                            (local.set $7
                             (i32.add
                              (local.get $7)
                              (i32.const 1)
                             )
                            )
                            (local.set $2
                             (i32.sub
                              (local.get $2)
                              (i32.const 1)
                             )
                            )
                            (br_if $label4
                             (i32.le_u
                              (local.get $5)
                              (local.tee $3
                               (i32.add
                                (local.get $5)
                                (i32.wrap_i64
                                 (local.get $21)
                                )
                               )
                              )
                             )
                            )
                           )
                           (local.set $5
                            (i32.const 2)
                           )
                           (br $block29)
                          )
                          (call $_RNvNtCsdHhIpgkcIfN_4core9panicking18panic_bounds_check
                           (i32.const 3)
                           (i32.const 3)
                           (i32.const 1051144)
                          )
                          (unreachable)
                         )
                         (local.set $5
                          (select
                           (i32.const 2)
                           (i32.const 1)
                           (i32.lt_u
                            (i32.and
                             (i32.sub
                              (local.get $5)
                              (i32.const 48)
                             )
                             (i32.const 255)
                            )
                            (i32.const 10)
                           )
                          )
                         )
                         (br $block29)
                        )
                        (if
                         (i32.eqz
                          (local.get $2)
                         )
                         (then
                          (local.set $3
                           (i32.const 0)
                          )
                          (br $block34)
                         )
                        )
                        (local.set $5
                         (i32.const 1)
                        )
                        (br_if $block29
                         (i32.gt_u
                          (local.tee $3
                           (i32.sub
                            (i32.load8_u
                             (local.get $7)
                            )
                            (i32.const 48)
                           )
                          )
                          (i32.const 9)
                         )
                        )
                        (br_if $block34
                         (i32.eq
                          (local.get $2)
                          (i32.const 1)
                         )
                        )
                        (br_if $block29
                         (i32.gt_u
                          (local.tee $6
                           (i32.sub
                            (i32.load8_u offset=1
                             (local.get $7)
                            )
                            (i32.const 48)
                           )
                          )
                          (i32.const 9)
                         )
                        )
                        (local.set $3
                         (i32.add
                          (local.get $6)
                          (i32.mul
                           (local.get $3)
                           (i32.const 10)
                          )
                         )
                        )
                        (br_if $block34
                         (i32.eq
                          (local.get $2)
                          (i32.const 2)
                         )
                        )
                        (br_if $block29
                         (i32.gt_u
                          (local.tee $6
                           (i32.sub
                            (i32.load8_u offset=2
                             (local.get $7)
                            )
                            (i32.const 48)
                           )
                          )
                          (i32.const 9)
                         )
                        )
                        (local.set $3
                         (i32.add
                          (local.get $6)
                          (i32.mul
                           (local.get $3)
                           (i32.const 10)
                          )
                         )
                        )
                        (br_if $block34
                         (i32.eq
                          (local.get $2)
                          (i32.const 3)
                         )
                        )
                        (br_if $block29
                         (i32.gt_u
                          (local.tee $6
                           (i32.sub
                            (i32.load8_u offset=3
                             (local.get $7)
                            )
                            (i32.const 48)
                           )
                          )
                          (i32.const 9)
                         )
                        )
                        (local.set $3
                         (i32.add
                          (local.get $6)
                          (i32.mul
                           (local.get $3)
                           (i32.const 10)
                          )
                         )
                        )
                        (br_if $block34
                         (i32.eq
                          (local.get $2)
                          (i32.const 4)
                         )
                        )
                        (br_if $block29
                         (i32.gt_u
                          (local.tee $6
                           (i32.sub
                            (i32.load8_u offset=4
                             (local.get $7)
                            )
                            (i32.const 48)
                           )
                          )
                          (i32.const 9)
                         )
                        )
                        (local.set $3
                         (i32.add
                          (local.get $6)
                          (i32.mul
                           (local.get $3)
                           (i32.const 10)
                          )
                         )
                        )
                        (br_if $block34
                         (i32.eq
                          (local.get $2)
                          (i32.const 5)
                         )
                        )
                        (br_if $block29
                         (i32.gt_u
                          (local.tee $6
                           (i32.sub
                            (i32.load8_u offset=5
                             (local.get $7)
                            )
                            (i32.const 48)
                           )
                          )
                          (i32.const 9)
                         )
                        )
                        (local.set $3
                         (i32.add
                          (local.get $6)
                          (i32.mul
                           (local.get $3)
                           (i32.const 10)
                          )
                         )
                        )
                        (br_if $block34
                         (i32.eq
                          (local.get $2)
                          (i32.const 6)
                         )
                        )
                        (br_if $block29
                         (i32.gt_u
                          (local.tee $6
                           (i32.sub
                            (i32.load8_u offset=6
                             (local.get $7)
                            )
                            (i32.const 48)
                           )
                          )
                          (i32.const 9)
                         )
                        )
                        (local.set $3
                         (i32.add
                          (local.get $6)
                          (i32.mul
                           (local.get $3)
                           (i32.const 10)
                          )
                         )
                        )
                        (br_if $block34
                         (i32.eq
                          (local.get $2)
                          (i32.const 7)
                         )
                        )
                        (br_if $block29
                         (i32.gt_u
                          (local.tee $2
                           (i32.sub
                            (i32.load8_u offset=7
                             (local.get $7)
                            )
                            (i32.const 48)
                           )
                          )
                          (i32.const 9)
                         )
                        )
                        (local.set $3
                         (i32.add
                          (local.get $2)
                          (i32.mul
                           (local.get $3)
                           (i32.const 10)
                          )
                         )
                        )
                       )
                       (i32.store offset=32
                        (local.get $1)
                        (i32.const 1)
                       )
                       (call $_ZN15bv2string_probe6Random10bytevector17hf452b417a2a79d91E
                        (local.tee $2
                         (i32.add
                          (local.get $1)
                          (i32.const 56)
                         )
                        )
                        (i32.add
                         (local.get $1)
                         (i32.const 32)
                        )
                        (i32.const 10)
                       )
                       (local.set $2
                        (i32.xor
                         (call $_ZN15bv2string_probe9roundtrip17hb593ecb86af6a62dE
                          (local.get $2)
                         )
                         (i32.const 1)
                        )
                       )
                       (if
                        (local.get $4)
                        (then
                         (loop $label5
                          (call $_ZN15bv2string_probe6Random10bytevector17hf452b417a2a79d91E
                           (local.tee $5
                            (i32.add
                             (local.get $1)
                             (i32.const 56)
                            )
                           )
                           (i32.add
                            (local.get $1)
                            (i32.const 32)
                           )
                           (local.get $3)
                          )
                          (local.set $2
                           (i32.add
                            (local.get $2)
                            (i32.xor
                             (call $_ZN15bv2string_probe9roundtrip17hb593ecb86af6a62dE
                              (local.get $5)
                             )
                             (i32.const 1)
                            )
                           )
                          )
                          (br_if $label5
                           (local.tee $4
                            (i32.sub
                             (local.get $4)
                             (i32.const 1)
                            )
                           )
                          )
                         )
                        )
                       )
                       (i32.store
                        (local.get $1)
                        (local.get $2)
                       )
                       (br_if $block36
                        (i32.load
                         (i32.const 1060892)
                        )
                       )
                       (i32.store
                        (i32.const 1060892)
                        (i32.const -1)
                       )
                       (if
                        (i32.le_u
                         (i32.sub
                          (i32.load
                           (i32.const 1060896)
                          )
                          (local.tee $3
                           (i32.load
                            (i32.const 1060904)
                           )
                          )
                         )
                         (i32.const 1)
                        )
                        (then
                         (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
                          (i32.const 1060896)
                          (local.get $3)
                          (i32.const 2)
                          (i32.const 4)
                         )
                         (local.set $3
                          (i32.load
                           (i32.const 1060904)
                          )
                         )
                        )
                       )
                       (i32.store offset=4
                        (local.tee $4
                         (i32.add
                          (i32.load
                           (i32.const 1060900)
                          )
                          (i32.shl
                           (local.get $3)
                           (i32.const 2)
                          )
                         )
                        )
                        (local.get $2)
                       )
                       (i32.store
                        (local.get $4)
                        (i32.const 7)
                       )
                       (i32.store
                        (i32.const 1060904)
                        (local.tee $6
                         (i32.add
                          (local.get $3)
                          (i32.const 2)
                         )
                        )
                       )
                       (i32.store
                        (i32.const 1060892)
                        (local.tee $4
                         (i32.add
                          (local.tee $5
                           (i32.load
                            (i32.const 1060892)
                           )
                          )
                          (i32.const 1)
                         )
                        )
                       )
                       (br_if $block37
                        (i32.ge_u
                         (local.get $4)
                         (i32.const 2147483647)
                        )
                       )
                       (i32.store
                        (i32.const 1060892)
                        (i32.add
                         (local.get $5)
                         (i32.const 2)
                        )
                       )
                       (local.set $10
                        (i32.load
                         (i32.const 1060900)
                        )
                       )
                       (br_if $block38
                        (i32.eqz
                         (local.tee $16
                          (call $dlmalloc
                           (local.tee $2
                            (i32.shl
                             (local.get $6)
                             (i32.const 2)
                            )
                           )
                          )
                         )
                        )
                       )
                       (local.set $7
                        (i32.and
                         (local.get $6)
                         (i32.const 3)
                        )
                       )
                       (local.set $4
                        (i32.const 0)
                       )
                       (local.set $8
                        (i32.const 0)
                       )
                       (br_if $block39
                        (i32.lt_u
                         (local.get $3)
                         (i32.const 2)
                        )
                       )
                       (br_if $block40
                        (local.tee $4
                         (i32.shr_u
                          (i32.sub
                           (local.get $3)
                           (i32.const 2)
                          )
                          (i32.const 2)
                         )
                        )
                       )
                       (local.set $4
                        (i32.const 0)
                       )
                       (br $block41)
                      )
                      (i32.store8 offset=56
                       (local.get $1)
                       (local.get $5)
                      )
                      (call $_RNvNtCsdHhIpgkcIfN_4core6result13unwrap_failed
                       (i32.add
                        (local.get $1)
                        (i32.const 56)
                       )
                       (i32.const 1051176)
                       (i32.const 1051192)
                      )
                      (unreachable)
                     )
                     (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
                      (i32.const 1)
                      (local.get $2)
                     )
                     (unreachable)
                    )
                    (br_if $block42
                     (i32.eqz
                      (block (result i32)
                       (local.set $scratch
                        (i32.and
                         (local.tee $4
                          (i32.add
                           (local.get $4)
                           (i32.const 1)
                          )
                         )
                         (i32.const 1)
                        )
                       )
                       (local.set $8
                        (i32.shl
                         (local.tee $12
                          (i32.and
                           (local.get $4)
                           (i32.const 2147483646)
                          )
                         )
                         (i32.const 2)
                        )
                       )
                       (local.set $4
                        (i32.const 0)
                       )
                       (loop $label6
                        (i32.store align=1
                         (local.tee $11
                          (i32.add
                           (local.get $4)
                           (local.get $16)
                          )
                         )
                         (i32.load
                          (local.tee $6
                           (i32.add
                            (local.get $4)
                            (local.get $10)
                           )
                          )
                         )
                        )
                        (i32.store align=1
                         (i32.add
                          (local.get $11)
                          (i32.const 4)
                         )
                         (i32.load
                          (i32.add
                           (local.get $6)
                           (i32.const 4)
                          )
                         )
                        )
                        (i32.store align=1
                         (i32.add
                          (local.get $11)
                          (i32.const 8)
                         )
                         (i32.load
                          (i32.add
                           (local.get $6)
                           (i32.const 8)
                          )
                         )
                        )
                        (i32.store align=1
                         (i32.add
                          (local.get $11)
                          (i32.const 12)
                         )
                         (i32.load
                          (i32.add
                           (local.get $6)
                           (i32.const 12)
                          )
                         )
                        )
                        (i32.store align=1
                         (i32.add
                          (local.get $11)
                          (i32.const 16)
                         )
                         (i32.load
                          (i32.add
                           (local.get $6)
                           (i32.const 16)
                          )
                         )
                        )
                        (i32.store align=1
                         (i32.add
                          (local.get $11)
                          (i32.const 20)
                         )
                         (i32.load
                          (i32.add
                           (local.get $6)
                           (i32.const 20)
                          )
                         )
                        )
                        (i32.store align=1
                         (i32.add
                          (local.get $11)
                          (i32.const 24)
                         )
                         (i32.load
                          (i32.add
                           (local.get $6)
                           (i32.const 24)
                          )
                         )
                        )
                        (i32.store align=1
                         (i32.add
                          (local.get $11)
                          (i32.const 28)
                         )
                         (i32.load
                          (i32.add
                           (local.get $6)
                           (i32.const 28)
                          )
                         )
                        )
                        (local.set $4
                         (i32.add
                          (local.get $4)
                          (i32.const 32)
                         )
                        )
                        (br_if $label6
                         (local.tee $12
                          (i32.sub
                           (local.get $12)
                           (i32.const 2)
                          )
                         )
                        )
                       )
                       (local.get $scratch)
                      )
                     )
                    )
                   )
                   (i32.store align=1
                    (local.tee $6
                     (i32.add
                      (local.get $4)
                      (local.get $16)
                     )
                    )
                    (i32.load
                     (local.tee $3
                      (i32.add
                       (local.get $10)
                       (i32.shl
                        (local.get $8)
                        (i32.const 2)
                       )
                      )
                     )
                    )
                   )
                   (i32.store offset=4 align=1
                    (local.get $6)
                    (i32.load offset=4
                     (local.get $3)
                    )
                   )
                   (i32.store offset=8 align=1
                    (local.get $6)
                    (i32.load offset=8
                     (local.get $3)
                    )
                   )
                   (i32.store offset=12 align=1
                    (local.get $6)
                    (i32.load offset=12
                     (local.get $3)
                    )
                   )
                   (local.set $8
                    (i32.add
                     (local.get $8)
                     (i32.const 4)
                    )
                   )
                   (local.set $4
                    (i32.add
                     (local.get $4)
                     (i32.const 16)
                    )
                   )
                  )
                  (br_if $block43
                   (i32.eqz
                    (local.get $7)
                   )
                  )
                 )
                 (local.set $3
                  (i32.add
                   (local.get $10)
                   (i32.shl
                    (local.get $8)
                    (i32.const 2)
                   )
                  )
                 )
                 (loop $label7
                  (i32.store align=1
                   (i32.add
                    (local.get $4)
                    (local.get $16)
                   )
                   (i32.load
                    (local.get $3)
                   )
                  )
                  (local.set $3
                   (i32.add
                    (local.get $3)
                    (i32.const 4)
                   )
                  )
                  (local.set $4
                   (i32.add
                    (local.get $4)
                    (i32.const 4)
                   )
                  )
                  (br_if $label7
                   (local.tee $7
                    (i32.sub
                     (local.get $7)
                     (i32.const 1)
                    )
                   )
                  )
                 )
                )
                (i32.store
                 (i32.const 1060892)
                 (i32.add
                  (local.get $5)
                  (i32.const 1)
                 )
                )
                (i32.store offset=12
                 (local.get $1)
                 (local.get $4)
                )
                (i32.store offset=8
                 (local.get $1)
                 (local.get $16)
                )
                (i32.store offset=4
                 (local.get $1)
                 (local.get $2)
                )
                (local.set $3
                 (i32.load offset=16
                  (local.get $13)
                 )
                )
                (local.set $9
                 (i32.load offset=20
                  (local.get $13)
                 )
                )
                (i32.store offset=40
                 (local.get $1)
                 (i32.const 0)
                )
                (i64.store offset=32 align=4
                 (local.get $1)
                 (i64.const 1881195675648)
                )
                (i32.store16 offset=44
                 (local.get $1)
                 (i32.const 0)
                )
                (i32.store8 offset=40
                 (local.get $1)
                 (i32.const 1)
                )
                (i32.store offset=52
                 (local.get $1)
                 (i32.add
                  (local.get $1)
                  (i32.const 32)
                 )
                )
                (if
                 (i32.le_u
                  (local.get $9)
                  (i32.const 383)
                 )
                 (then
                  (if
                   (local.get $9)
                   (then
                    (memory.copy
                     (i32.add
                      (local.get $1)
                      (i32.const 56)
                     )
                     (local.get $3)
                     (local.get $9)
                    )
                   )
                  )
                  (local.set $2
                   (i32.const 0)
                  )
                  (i32.store8
                   (i32.add
                    (local.tee $5
                     (i32.add
                      (local.get $1)
                      (i32.const 56)
                     )
                    )
                    (local.get $9)
                   )
                   (i32.const 0)
                  )
                  (if
                   (i32.ge_u
                    (local.get $9)
                    (i32.const 7)
                   )
                   (then
                    (br_if $block44
                     (i32.eq
                      (local.get $5)
                      (local.tee $3
                       (i32.and
                        (i32.add
                         (local.get $1)
                         (i32.const 59)
                        )
                        (i32.const -4)
                       )
                      )
                     )
                    )
                    (local.set $3
                     (i32.sub
                      (local.get $3)
                      (local.get $5)
                     )
                    )
                    (loop $label8
                     (br_if $block45
                      (i32.eqz
                       (i32.load8_u
                        (i32.add
                         (i32.add
                          (local.get $1)
                          (i32.const 56)
                         )
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (br_if $label8
                      (i32.ne
                       (local.get $3)
                       (local.tee $2
                        (i32.add
                         (local.get $2)
                         (i32.const 1)
                        )
                       )
                      )
                     )
                    )
                    (br_if $block46
                     (i32.gt_u
                      (local.get $3)
                      (local.tee $10
                       (i32.sub
                        (local.get $9)
                        (i32.const 7)
                       )
                      )
                     )
                    )
                    (br $block47)
                   )
                  )
                  (br_if $block45
                   (i32.eqz
                    (i32.load8_u offset=56
                     (local.get $1)
                    )
                   )
                  )
                  (br_if $block48
                   (i32.eqz
                    (local.get $9)
                   )
                  )
                  (if
                   (i32.eqz
                    (i32.load8_u offset=57
                     (local.get $1)
                    )
                   )
                   (then
                    (local.set $2
                     (i32.const 1)
                    )
                    (br $block45)
                   )
                  )
                  (br_if $block48
                   (i32.eq
                    (local.get $9)
                    (i32.const 1)
                   )
                  )
                  (if
                   (i32.eqz
                    (i32.load8_u offset=58
                     (local.get $1)
                    )
                   )
                   (then
                    (local.set $2
                     (i32.const 2)
                    )
                    (br $block45)
                   )
                  )
                  (br_if $block48
                   (i32.eq
                    (local.get $9)
                    (i32.const 2)
                   )
                  )
                  (if
                   (i32.eqz
                    (i32.load8_u offset=59
                     (local.get $1)
                    )
                   )
                   (then
                    (local.set $2
                     (i32.const 3)
                    )
                    (br $block45)
                   )
                  )
                  (br_if $block48
                   (i32.eq
                    (local.get $9)
                    (i32.const 3)
                   )
                  )
                  (if
                   (i32.eqz
                    (i32.load8_u offset=60
                     (local.get $1)
                    )
                   )
                   (then
                    (local.set $2
                     (i32.const 4)
                    )
                    (br $block45)
                   )
                  )
                  (br_if $block48
                   (i32.eq
                    (local.get $9)
                    (i32.const 4)
                   )
                  )
                  (if
                   (i32.eqz
                    (i32.load8_u offset=61
                     (local.get $1)
                    )
                   )
                   (then
                    (local.set $2
                     (i32.const 5)
                    )
                    (br $block45)
                   )
                  )
                  (br_if $block48
                   (i32.eq
                    (local.get $9)
                    (i32.const 5)
                   )
                  )
                  (br_if $block48
                   (i32.load8_u offset=62
                    (local.get $1)
                   )
                  )
                  (local.set $2
                   (i32.const 6)
                  )
                  (br $block45)
                 )
                )
                (local.set $7
                 (i32.add
                  (local.get $1)
                  (i32.const 440)
                 )
                )
                (local.set $10
                 (i32.add
                  (local.get $1)
                  (i32.const 52)
                 )
                )
                (local.set $8
                 (i32.const 0)
                )
                (block $block51
                 (block $block49
                  (block $block50
                   (if
                    (i32.ge_s
                     (local.tee $2
                      (i32.add
                       (local.get $9)
                       (i32.const 1)
                      )
                     )
                     (i32.const 0)
                    )
                    (then
                     (if
                      (local.tee $11
                       (call $dlmalloc
                        (local.get $2)
                       )
                      )
                      (then
                       (if
                        (local.get $9)
                        (then
                         (memory.copy
                          (local.get $11)
                          (local.get $3)
                          (local.get $9)
                         )
                        )
                       )
                       (if
                        (i32.ne
                         (local.get $3)
                         (local.tee $2
                          (i32.and
                           (i32.add
                            (local.get $3)
                            (i32.const 3)
                           )
                           (i32.const -4)
                          )
                         )
                        )
                        (then
                         (local.set $8
                          (i32.sub
                           (local.get $2)
                           (local.get $3)
                          )
                         )
                         (local.set $6
                          (i32.sub
                           (local.get $3)
                           (local.get $2)
                          )
                         )
                         (local.set $2
                          (local.get $3)
                         )
                         (loop $label9
                          (br_if $block49
                           (i32.eqz
                            (i32.load8_u
                             (local.get $2)
                            )
                           )
                          )
                          (local.set $2
                           (i32.add
                            (local.get $2)
                            (i32.const 1)
                           )
                          )
                          (br_if $label9
                           (local.tee $6
                            (i32.add
                             (local.get $6)
                             (i32.const 1)
                            )
                           )
                          )
                         )
                        )
                       )
                       (local.set $6
                        (i32.sub
                         (local.get $9)
                         (i32.const 8)
                        )
                       )
                       (loop $label10
                        (br_if $block50
                         (i32.ne
                          (i32.and
                           (i32.and
                            (i32.or
                             (i32.sub
                              (i32.const 16843008)
                              (local.tee $2
                               (i32.load
                                (local.tee $5
                                 (i32.add
                                  (local.get $3)
                                  (local.get $8)
                                 )
                                )
                               )
                              )
                             )
                             (local.get $2)
                            )
                            (i32.or
                             (i32.sub
                              (i32.const 16843008)
                              (local.tee $2
                               (i32.load
                                (i32.add
                                 (local.get $5)
                                 (i32.const 4)
                                )
                               )
                              )
                             )
                             (local.get $2)
                            )
                           )
                           (i32.const -2139062144)
                          )
                          (i32.const -2139062144)
                         )
                        )
                        (br_if $label10
                         (i32.le_u
                          (local.tee $8
                           (i32.add
                            (local.get $8)
                            (i32.const 8)
                           )
                          )
                          (local.get $6)
                         )
                        )
                       )
                       (br $block50)
                      )
                     )
                     (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
                      (i32.const 1)
                      (local.get $2)
                     )
                     (unreachable)
                    )
                   )
                   (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec17capacity_overflow)
                   (unreachable)
                  )
                  (if
                   (i32.ne
                    (local.get $8)
                    (local.get $9)
                   )
                   (then
                    (local.set $2
                     (i32.sub
                      (local.get $9)
                      (local.get $8)
                     )
                    )
                    (local.set $8
                     (i32.add
                      (local.get $3)
                      (local.get $8)
                     )
                    )
                    (loop $label11
                     (br_if $block49
                      (i32.eqz
                       (i32.load8_u
                        (local.get $8)
                       )
                      )
                     )
                     (local.set $8
                      (i32.add
                       (local.get $8)
                       (i32.const 1)
                      )
                     )
                     (br_if $label11
                      (local.tee $2
                       (i32.sub
                        (local.get $2)
                        (i32.const 1)
                       )
                      )
                     )
                    )
                   )
                  )
                  (i32.store8
                   (i32.add
                    (local.get $9)
                    (local.get $11)
                   )
                   (i32.const 0)
                  )
                  (call $_RNCNvMsi_NtNtNtCset5xJoy1xWQ_3std3sys2fs4unixNtB7_4File4open0Bd_
                   (local.get $7)
                   (i32.load
                    (local.get $10)
                   )
                   (local.get $11)
                  )
                  (br $block51)
                 )
                 (i64.store align=4
                  (local.get $7)
                  (i64.load
                   (i32.const 1055040)
                  )
                 )
                )
                (call $dlfree
                 (local.get $11)
                )
                (br $block52)
               )
               (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
                (i32.const 1051304)
               )
               (unreachable)
              )
              (global.set $__stack_pointer
               (local.tee $0
                (i32.sub
                 (global.get $__stack_pointer)
                 (i32.const 16)
                )
               )
              )
              (i64.store
               (local.get $0)
               (i64.or
                (i64.extend_i32_u
                 (i32.add
                  (local.get $0)
                  (i32.const 15)
                 )
                )
                (i64.const 34359738368)
               )
              )
              (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
               (i32.const 1049279)
               (local.get $0)
               (i32.const 1051288)
              )
              (unreachable)
             )
             (local.set $10
              (i32.sub
               (local.get $9)
               (i32.const 7)
              )
             )
             (local.set $3
              (i32.const 0)
             )
            )
            (loop $label12
             (br_if $block46
              (i32.ne
               (i32.and
                (i32.and
                 (i32.or
                  (i32.sub
                   (i32.const 16843008)
                   (local.tee $2
                    (i32.load
                     (local.tee $5
                      (i32.add
                       (i32.add
                        (local.get $1)
                        (i32.const 56)
                       )
                       (local.get $3)
                      )
                     )
                    )
                   )
                  )
                  (local.get $2)
                 )
                 (i32.or
                  (i32.sub
                   (i32.const 16843008)
                   (local.tee $2
                    (i32.load
                     (i32.add
                      (local.get $5)
                      (i32.const 4)
                     )
                    )
                   )
                  )
                  (local.get $2)
                 )
                )
                (i32.const -2139062144)
               )
               (i32.const -2139062144)
              )
             )
             (br_if $label12
              (i32.le_u
               (local.tee $3
                (i32.add
                 (local.get $3)
                 (i32.const 8)
                )
               )
               (local.get $10)
              )
             )
            )
           )
           (br_if $block48
            (i32.eq
             (local.tee $2
              (i32.add
               (local.get $9)
               (i32.const 1)
              )
             )
             (local.get $3)
            )
           )
           (local.set $6
            (i32.sub
             (local.get $2)
             (local.get $3)
            )
           )
           (local.set $5
            (i32.add
             (i32.add
              (local.get $1)
              (i32.const 56)
             )
             (local.get $3)
            )
           )
           (local.set $2
            (i32.const 0)
           )
           (loop $label13
            (if
             (i32.load8_u
              (i32.add
               (local.get $2)
               (local.get $5)
              )
             )
             (then
              (br_if $label13
               (i32.ne
                (local.get $6)
                (local.tee $2
                 (i32.add
                  (local.get $2)
                  (i32.const 1)
                 )
                )
               )
              )
              (br $block48)
             )
            )
           )
           (local.set $2
            (i32.add
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (br_if $block53
           (i32.eq
            (local.get $2)
            (local.get $9)
           )
          )
         )
         (i64.store offset=440
          (local.get $1)
          (i64.load
           (i32.const 1055040)
          )
         )
         (br $block52)
        )
        (call $_RNCNvMsi_NtNtNtCset5xJoy1xWQ_3std3sys2fs4unixNtB7_4File4open0Bd_
         (i32.add
          (local.get $1)
          (i32.const 440)
         )
         (i32.add
          (local.get $1)
          (i32.const 32)
         )
         (i32.add
          (local.get $1)
          (i32.const 56)
         )
        )
       )
       (block $block78
        (block $block55
         (local.set $17
          (block $block54 (result i32)
           (if
            (i32.eq
             (i32.load8_u offset=440
              (local.get $1)
             )
             (i32.const 4)
            )
            (then
             (br $block54
              (i32.load offset=444
               (local.get $1)
              )
             )
            )
           )
           (br_if $block55
            (i64.ne
             (i64.and
              (local.tee $20
               (i64.load offset=440
                (local.get $1)
               )
              )
              (i64.const 255)
             )
             (i64.const 4)
            )
           )
           (i32.wrap_i64
            (i64.shr_u
             (local.get $20)
             (i64.const 32)
            )
           )
          )
         )
         (memory.fill
          (local.tee $5
           (i32.add
            (local.get $1)
            (i32.const 56)
           )
          )
          (i32.const 0)
          (i32.const 144)
         )
         (block $block57
          (local.set $20
           (i64.or
            (block $block65 (result i64)
             (global.set $__stack_pointer
              (local.tee $2
               (i32.add
                (global.get $__stack_pointer)
                (i32.const -64)
               )
              )
             )
             (block $block56
              (if
               (local.tee $3
                (i32.and
                 (call $__imported_wasi_snapshot_preview1_fd_filestat_get
                  (local.get $17)
                  (local.get $2)
                 )
                 (i32.const 65535)
                )
               )
               (then
                (i32.store
                 (i32.const 1061060)
                 (local.get $3)
                )
                (local.set $7
                 (i32.const -1)
                )
                (br $block56)
               )
              )
              (i64.store offset=24
               (local.get $5)
               (i64.const 0)
              )
              (i64.store offset=16
               (local.get $5)
               (i64.load offset=24
                (local.get $2)
               )
              )
              (i64.store offset=8
               (local.get $5)
               (i64.load offset=8
                (local.get $2)
               )
              )
              (i64.store
               (local.get $5)
               (i64.load
                (local.get $2)
               )
              )
              (i64.store offset=56
               (local.get $5)
               (i64.const 0)
              )
              (i64.store offset=48
               (local.get $5)
               (i64.load offset=32
                (local.get $2)
               )
              )
              (local.set $7
               (i32.const 0)
              )
              (i32.store offset=100
               (local.get $5)
               (i32.const 0)
              )
              (i32.store offset=84
               (local.get $5)
               (i32.const 0)
              )
              (i64.store
               (i32.add
                (local.get $5)
                (i32.const 32)
               )
               (i64.const 0)
              )
              (i64.store
               (i32.add
                (local.get $5)
                (i32.const 40)
               )
               (i64.const 0)
              )
              (i64.store
               (i32.sub
                (local.get $5)
                (i32.const -64)
               )
               (i64.const 0)
              )
              (i64.store offset=104
               (local.get $5)
               (local.tee $24
                (i64.div_u
                 (local.tee $23
                  (i64.load offset=56
                   (local.get $2)
                  )
                 )
                 (i64.const 1000000000)
                )
               )
              )
              (i64.store offset=88
               (local.get $5)
               (local.tee $22
                (i64.div_u
                 (local.tee $25
                  (i64.load offset=48
                   (local.get $2)
                  )
                 )
                 (i64.const 1000000000)
                )
               )
              )
              (i64.store offset=72
               (local.get $5)
               (local.tee $21
                (i64.div_u
                 (local.tee $20
                  (i64.load offset=40
                   (local.get $2)
                  )
                 )
                 (i64.const 1000000000)
                )
               )
              )
              (i64.store32 offset=80
               (local.get $5)
               (i64.sub
                (local.get $20)
                (i64.mul
                 (local.get $21)
                 (i64.const 1000000000)
                )
               )
              )
              (i64.store32 offset=96
               (local.get $5)
               (i64.sub
                (local.get $25)
                (i64.mul
                 (local.get $22)
                 (i64.const 1000000000)
                )
               )
              )
              (i64.store32 offset=112
               (local.get $5)
               (i64.sub
                (local.get $23)
                (i64.mul
                 (local.get $24)
                 (i64.const 1000000000)
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $5)
                (i32.const 140)
               )
               (i32.const 0)
              )
              (i64.store align=4
               (i32.add
                (local.get $5)
                (i32.const 132)
               )
               (i64.const 0)
              )
              (i64.store align=4
               (i32.add
                (local.get $5)
                (i32.const 124)
               )
               (i64.const 0)
              )
              (i64.store offset=116 align=4
               (local.get $5)
               (i64.const 0)
              )
              (br_if $block56
               (i32.gt_u
                (local.tee $3
                 (i32.and
                  (i32.sub
                   (i32.load8_u offset=16
                    (local.get $2)
                   )
                   (i32.const 2)
                  )
                  (i32.const 255)
                 )
                )
                (i32.const 5)
               )
              )
              (i32.store
               (i32.add
                (local.get $5)
                (i32.const 24)
               )
               (i32.load offset=1059148
                (i32.shl
                 (local.get $3)
                 (i32.const 2)
                )
               )
              )
             )
             (global.set $__stack_pointer
              (i32.sub
               (local.get $2)
               (i32.const -64)
              )
             )
             (block $block61
              (block $block62
               (block $block60
                (block $block59
                 (if
                  (i32.eqz
                   (local.tee $3
                    (i32.eq
                     (local.get $7)
                     (i32.const -1)
                    )
                   )
                  )
                  (then
                   (local.set $20
                    (i64.const 9729)
                   )
                   (br_if $block57
                    (i64.gt_u
                     (local.tee $21
                      (i64.load offset=104
                       (local.get $1)
                      )
                     )
                     (i64.const 2147483647)
                    )
                   )
                   (local.set $6
                    (i32.const 0)
                   )
                   (block $block58
                    (if
                     (i64.eqz
                      (local.get $21)
                     )
                     (then
                      (local.set $2
                       (i32.const 1)
                      )
                      (local.set $10
                       (i32.const 0)
                      )
                      (br $block58)
                     )
                    )
                    (br_if $block57
                     (i32.eqz
                      (local.tee $2
                       (call $dlmalloc
                        (local.tee $10
                         (i32.wrap_i64
                          (local.get $21)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (i32.store offset=40
                    (local.get $1)
                    (i32.const 0)
                   )
                   (i32.store offset=36
                    (local.get $1)
                    (local.get $2)
                   )
                   (i32.store offset=32
                    (local.get $1)
                    (local.get $10)
                   )
                   (local.set $8
                    (select
                     (select
                      (i32.const 8192)
                      (local.tee $2
                       (i32.add
                        (i32.sub
                         (local.get $10)
                         (local.tee $5
                          (i32.and
                           (local.tee $8
                            (i32.add
                             (local.get $10)
                             (i32.const 1024)
                            )
                           )
                           (i32.const 8191)
                          )
                         )
                        )
                        (i32.const 9216)
                       )
                      )
                      (i32.lt_u
                       (local.get $2)
                       (local.get $8)
                      )
                     )
                     (local.get $8)
                     (local.get $5)
                    )
                   )
                   (local.set $5
                    (i32.const 0)
                   )
                   (br_if $block59
                    (i32.eqz
                     (local.tee $7
                      (local.get $10)
                     )
                    )
                   )
                   (br $block60)
                  )
                 )
                 (i32.store offset=40
                  (local.get $1)
                  (i32.const 0)
                 )
                 (i64.store offset=32 align=4
                  (local.get $1)
                  (i64.const 4294967296)
                 )
                 (local.set $8
                  (i32.const 8192)
                 )
                )
                (i64.store offset=80
                 (local.get $1)
                 (i64.const 0)
                )
                (i64.store offset=72
                 (local.get $1)
                 (i64.const 0)
                )
                (i64.store offset=64
                 (local.get $1)
                 (i64.const 0)
                )
                (i64.store offset=56
                 (local.get $1)
                 (i64.const 0)
                )
                (loop $label14
                 (if
                  (i32.eq
                   (local.tee $5
                    (call $read
                     (local.get $17)
                     (i32.add
                      (local.get $1)
                      (i32.const 56)
                     )
                     (i32.const 32)
                    )
                   )
                   (i32.const -1)
                  )
                  (then
                   (br_if $label14
                    (i32.eq
                     (local.tee $2
                      (i32.load
                       (i32.const 1061060)
                      )
                     )
                     (i32.const 27)
                    )
                   )
                   (br $block61)
                  )
                 )
                )
                (if
                 (i32.lt_u
                  (local.get $5)
                  (i32.const 33)
                 )
                 (then
                  (br_if $block62
                   (i32.eqz
                    (local.get $5)
                   )
                  )
                  (local.set $10
                   (i32.const 0)
                  )
                  (call $_RINvNvMs2_NtCsi9YzqDQQz2q_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECset5xJoy1xWQ_3std
                   (i32.add
                    (local.get $1)
                    (i32.const 32)
                   )
                   (i32.const 0)
                   (local.get $5)
                  )
                  (local.set $2
                   (i32.load offset=40
                    (local.get $1)
                   )
                  )
                  (local.set $7
                   (i32.load offset=32
                    (local.get $1)
                   )
                  )
                  (if
                   (local.get $5)
                   (then
                    (memory.copy
                     (i32.add
                      (i32.load offset=36
                       (local.get $1)
                      )
                      (local.get $2)
                     )
                     (i32.add
                      (local.get $1)
                      (i32.const 56)
                     )
                     (local.get $5)
                    )
                   )
                  )
                  (i32.store offset=40
                   (local.get $1)
                   (local.tee $6
                    (i32.add
                     (local.get $2)
                     (local.get $5)
                    )
                   )
                  )
                  (local.set $5
                   (local.get $3)
                  )
                  (br $block60)
                 )
                )
                (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
                 (i32.const 0)
                 (local.get $5)
                 (i32.const 32)
                 (i32.const 1055048)
                )
                (unreachable)
               )
               (loop $label17
                (block $block63
                 (if
                  (i32.eqz
                   (i32.and
                    (i32.eq
                     (local.get $6)
                     (local.get $7)
                    )
                    (i32.eq
                     (local.get $7)
                     (local.get $10)
                    )
                   )
                  )
                  (then
                   (local.set $12
                    (i32.load offset=36
                     (local.get $1)
                    )
                   )
                   (br $block63)
                  )
                 )
                 (i64.store offset=80
                  (local.get $1)
                  (i64.const 0)
                 )
                 (i64.store offset=72
                  (local.get $1)
                  (i64.const 0)
                 )
                 (i64.store offset=64
                  (local.get $1)
                  (i64.const 0)
                 )
                 (i64.store offset=56
                  (local.get $1)
                  (i64.const 0)
                 )
                 (loop $label15
                  (if
                   (i32.eq
                    (local.tee $2
                     (call $read
                      (local.get $17)
                      (i32.add
                       (local.get $1)
                       (i32.const 56)
                      )
                      (i32.const 32)
                     )
                    )
                    (i32.const -1)
                   )
                   (then
                    (br_if $label15
                     (i32.eq
                      (local.tee $2
                       (i32.load
                        (i32.const 1061060)
                       )
                      )
                      (i32.const 27)
                     )
                    )
                    (br $block61)
                   )
                  )
                 )
                 (if
                  (i32.lt_u
                   (local.get $2)
                   (i32.const 33)
                  )
                  (then
                   (if
                    (local.get $2)
                    (then
                     (call $_RINvNvMs2_NtCsi9YzqDQQz2q_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECset5xJoy1xWQ_3std
                      (i32.add
                       (local.get $1)
                       (i32.const 32)
                      )
                      (local.get $10)
                      (local.get $2)
                     )
                     (local.set $3
                      (i32.load offset=40
                       (local.get $1)
                      )
                     )
                     (local.set $12
                      (i32.load offset=36
                       (local.get $1)
                      )
                     )
                     (if
                      (local.get $2)
                      (then
                       (memory.copy
                        (i32.add
                         (local.get $3)
                         (local.get $12)
                        )
                        (i32.add
                         (local.get $1)
                         (i32.const 56)
                        )
                        (local.get $2)
                       )
                      )
                     )
                     (i32.store offset=40
                      (local.get $1)
                      (local.tee $6
                       (i32.add
                        (local.get $2)
                        (local.get $3)
                       )
                      )
                     )
                     (local.set $7
                      (i32.load offset=32
                       (local.get $1)
                      )
                     )
                     (br $block63)
                    )
                   )
                   (i32.store offset=40
                    (local.get $1)
                    (local.get $10)
                   )
                   (br $block62)
                  )
                 )
                 (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
                  (i32.const 0)
                  (local.get $2)
                  (i32.const 32)
                  (i32.const 1055048)
                 )
                 (unreachable)
                )
                (block $block64
                 (if
                  (i32.ne
                   (local.get $6)
                   (local.get $7)
                  )
                  (then
                   (local.set $7
                    (i32.load offset=32
                     (local.get $1)
                    )
                   )
                   (br $block64)
                  )
                 )
                 (call $_RNvMs4_NtCsi9YzqDQQz2q_5alloc7raw_vecNtB5_11RawVecInner11finish_growCset5xJoy1xWQ_3std
                  (i32.add
                   (local.get $1)
                   (i32.const 56)
                  )
                  (local.get $7)
                  (local.get $12)
                  (local.tee $7
                   (select
                    (local.tee $2
                     (i32.add
                      (local.get $7)
                      (i32.const 32)
                     )
                    )
                    (local.tee $3
                     (i32.shl
                      (local.get $7)
                      (i32.const 1)
                     )
                    )
                    (i32.gt_u
                     (local.get $2)
                     (local.get $3)
                    )
                   )
                  )
                  (i32.const 1)
                  (i32.const 1)
                 )
                 (if
                  (i32.eq
                   (i32.load offset=56
                    (local.get $1)
                   )
                   (i32.const 1)
                  )
                  (then
                   (local.set $2
                    (i32.const 0)
                   )
                   (br $block65
                    (i64.const 9729)
                   )
                  )
                 )
                 (i32.store offset=36
                  (local.get $1)
                  (local.tee $12
                   (i32.load offset=60
                    (local.get $1)
                   )
                  )
                 )
                 (i32.store offset=32
                  (local.get $1)
                  (local.get $7)
                 )
                )
                (local.set $11
                 (select
                  (i32.const 2147483647)
                  (local.tee $9
                   (select
                    (local.get $8)
                    (local.tee $3
                     (i32.sub
                      (local.get $7)
                      (local.get $6)
                     )
                    )
                    (i32.gt_u
                     (local.get $3)
                     (local.get $8)
                    )
                   )
                  )
                  (i32.ge_u
                   (local.get $9)
                   (i32.const 2147483647)
                  )
                 )
                )
                (local.set $3
                 (i32.add
                  (local.get $6)
                  (local.get $12)
                 )
                )
                (block $block66
                 (loop $label16
                  (br_if $block66
                   (i32.ne
                    (local.tee $2
                     (call $read
                      (local.get $17)
                      (local.get $3)
                      (local.get $11)
                     )
                    )
                    (i32.const -1)
                   )
                  )
                  (br_if $label16
                   (i32.eq
                    (local.tee $2
                     (i32.load
                      (i32.const 1061060)
                     )
                    )
                    (i32.const 27)
                   )
                  )
                 )
                 (i32.store offset=40
                  (local.get $1)
                  (local.get $6)
                 )
                 (br $block61)
                )
                (i32.store offset=40
                 (local.get $1)
                 (local.tee $6
                  (i32.add
                   (local.get $2)
                   (local.get $6)
                  )
                 )
                )
                (br_if $block62
                 (i32.eqz
                  (local.get $2)
                 )
                )
                (local.set $18
                 (i32.sub
                  (local.tee $3
                   (select
                    (local.get $2)
                    (local.get $18)
                    (i32.gt_u
                     (local.get $2)
                     (local.get $18)
                    )
                   )
                  )
                  (local.get $2)
                 )
                )
                (local.set $19
                 (select
                  (i32.add
                   (local.get $19)
                   (i32.const 1)
                  )
                  (i32.const 0)
                  (i32.lt_u
                   (local.get $2)
                   (local.get $9)
                  )
                 )
                )
                (br_if $label17
                 (i32.eqz
                  (local.get $5)
                 )
                )
                (local.set $8
                 (select
                  (select
                   (i32.const -1)
                   (local.get $8)
                   (i32.gt_s
                    (local.get $19)
                    (i32.const 1)
                   )
                  )
                  (local.get $8)
                  (i32.ne
                   (local.get $3)
                   (local.get $9)
                  )
                 )
                )
                (br_if $label17
                 (i32.ne
                  (local.get $2)
                  (local.get $9)
                 )
                )
                (br_if $label17
                 (i32.gt_u
                  (local.get $8)
                  (local.get $9)
                 )
                )
                (br_if $label17
                 (i32.eqz
                  (block (result i32)
                   (local.set $scratch_27
                    (i32.lt_s
                     (local.get $8)
                     (i32.const 0)
                    )
                   )
                   (local.set $8
                    (i32.shl
                     (local.get $8)
                     (i32.const 1)
                    )
                   )
                   (local.get $scratch_27)
                  )
                 )
                )
                (local.set $8
                 (i32.const -1)
                )
                (br $label17)
               )
               (unreachable)
              )
              (local.set $20
               (i64.load offset=36 align=4
                (local.get $1)
               )
              )
              (local.set $2
               (i32.load offset=32
                (local.get $1)
               )
              )
              (call $close
               (local.get $17)
              )
              (br_if $block55
               (i32.eq
                (local.get $2)
                (i32.const -2147483648)
               )
              )
              (i32.store offset=16
               (local.get $1)
               (local.get $2)
              )
              (i64.store offset=20 align=4
               (local.get $1)
               (local.get $20)
              )
              (block $block77
               (block $block74
                (block $block72
                 (block $block71
                  (block $block67
                   (br_if $block67
                    (i32.ne
                     (local.get $4)
                     (i32.wrap_i64
                      (i64.shr_u
                       (local.get $20)
                       (i64.const 32)
                      )
                     )
                    )
                   )
                   (br_if $block67
                    (call $memcmp
                     (local.get $16)
                     (local.tee $3
                      (i32.wrap_i64
                       (local.get $20)
                      )
                     )
                     (local.get $4)
                    )
                   )
                   (if
                    (local.get $2)
                    (then
                     (call $dlfree
                      (local.get $3)
                     )
                    )
                   )
                   (i32.store offset=52
                    (local.get $1)
                    (i32.shr_u
                     (local.get $4)
                     (i32.const 2)
                    )
                   )
                   (i64.store offset=40
                    (local.get $1)
                    (i64.or
                     (i64.extend_i32_u
                      (i32.add
                       (local.get $1)
                       (i32.const 52)
                      )
                     )
                     (i64.const 17179869184)
                    )
                   )
                   (i64.store offset=32
                    (local.get $1)
                    (i64.or
                     (i64.extend_i32_u
                      (local.get $1)
                     )
                     (i64.const 17179869184)
                    )
                   )
                   (i32.store offset=444
                    (local.get $1)
                    (i32.const 6)
                   )
                   (i32.store offset=440
                    (local.get $1)
                    (i32.const 1056556)
                   )
                   (if
                    (i32.ne
                     (local.tee $4
                      (i32.load8_u
                       (i32.const 1060984)
                      )
                     )
                     (i32.const 3)
                    )
                    (then
                     (block $block69
                      (block $block68
                       (block $block70
                        (br_table $block68 $block69 $block70
                         (i32.sub
                          (local.get $4)
                          (i32.const 2)
                         )
                        )
                       )
                       (i32.store8
                        (i32.const 1060984)
                        (i32.const 2)
                       )
                       (if
                        (local.tee $4
                         (call $dlmalloc
                          (i32.const 1024)
                         )
                        )
                        (then
                         (i32.store8
                          (i32.const 1060984)
                          (i32.const 3)
                         )
                         (i32.store
                          (i32.const 1060968)
                          (local.get $4)
                         )
                         (i64.store
                          (i32.const 1060960)
                          (i64.const 4398046511104)
                         )
                         (i64.store
                          (i32.const 1060944)
                          (i64.const 0)
                         )
                         (i32.store8
                          (i32.const 1060976)
                          (i32.const 0)
                         )
                         (i32.store
                          (i32.const 1060972)
                          (i32.const 0)
                         )
                         (i32.store8
                          (i32.const 1060956)
                          (i32.const 0)
                         )
                         (i32.store
                          (i32.const 1060952)
                          (i32.const 0)
                         )
                         (br $block69)
                        )
                       )
                       (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
                        (i32.const 1)
                        (i32.const 1024)
                       )
                       (unreachable)
                      )
                      (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
                       (i32.const 1054690)
                       (i32.const 113)
                       (i32.const 1054632)
                      )
                      (unreachable)
                     )
                    )
                   )
                   (if
                    (i64.eqz
                     (local.tee $22
                      (i64.load
                       (i32.const 1061008)
                      )
                     )
                    )
                    (then
                     (local.set $20
                      (i64.load
                       (i32.const 1061016)
                      )
                     )
                     (loop $label18
                      (br_if $block71
                       (i64.eq
                        (local.get $20)
                        (i64.const -1)
                       )
                      )
                      (i64.store
                       (i32.const 1061016)
                       (select
                        (local.tee $22
                         (i64.add
                          (local.get $20)
                          (i64.const 1)
                         )
                        )
                        (local.tee $21
                         (i64.load
                          (i32.const 1061016)
                         )
                        )
                        (local.tee $4
                         (i64.eq
                          (local.get $20)
                          (local.get $21)
                         )
                        )
                       )
                      )
                      (local.set $20
                       (local.get $21)
                      )
                      (br_if $label18
                       (i32.eqz
                        (local.get $4)
                       )
                      )
                     )
                     (i64.store
                      (i32.const 1061008)
                      (local.get $22)
                     )
                    )
                   )
                   (block $block73
                    (if
                     (i64.ne
                      (i64.load
                       (i32.const 1060944)
                      )
                      (local.get $22)
                     )
                     (then
                      (local.set $3
                       (i32.load8_u
                        (i32.const 1060956)
                       )
                      )
                      (local.set $4
                       (i32.const 1)
                      )
                      (i32.store8
                       (i32.const 1060956)
                       (i32.const 1)
                      )
                      (i32.store8 offset=56
                       (local.get $1)
                       (local.get $3)
                      )
                      (br_if $block72
                       (local.get $3)
                      )
                      (i64.store
                       (i32.const 1060944)
                       (local.get $22)
                      )
                      (br $block73)
                     )
                    )
                    (br_if $block74
                     (i32.eq
                      (local.tee $4
                       (i32.load
                        (i32.const 1060952)
                       )
                      )
                      (i32.const -1)
                     )
                    )
                    (local.set $4
                     (i32.add
                      (local.get $4)
                      (i32.const 1)
                     )
                    )
                   )
                   (i32.store
                    (i32.const 1060952)
                    (local.get $4)
                   )
                   (i32.store offset=16
                    (local.get $1)
                    (i32.const 1060944)
                   )
                   (i64.store offset=56
                    (local.get $1)
                    (i64.const 4)
                   )
                   (i32.store offset=64
                    (local.get $1)
                    (i32.add
                     (local.get $1)
                     (i32.const 16)
                    )
                   )
                   (local.set $4
                    (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
                     (i32.add
                      (local.get $1)
                      (i32.const 56)
                     )
                     (i32.const 1054916)
                     (i32.const 1050806)
                     (i32.add
                      (local.get $1)
                      (i32.const 32)
                     )
                    )
                   )
                   (local.set $3
                    (i32.load8_u offset=56
                     (local.get $1)
                    )
                   )
                   (local.set $3
                    (block $block76 (result i32)
                     (block $block75
                      (if
                       (local.get $4)
                       (then
                        (br_if $block75
                         (i32.ne
                          (local.get $3)
                          (i32.const 4)
                         )
                        )
                        (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
                         (i32.const 1054788)
                         (i32.const 173)
                         (i32.const 1054876)
                        )
                        (unreachable)
                       )
                      )
                      (local.set $20
                       (i64.const 0)
                      )
                      (drop
                       (br_if $block76
                        (i32.const 4)
                        (i32.ne
                         (local.get $3)
                         (i32.const 3)
                        )
                       )
                      )
                      (local.set $2
                       (i32.load
                        (local.tee $5
                         (i32.load offset=60
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (if
                       (local.tee $4
                        (i32.load
                         (local.tee $3
                          (i32.load
                           (i32.add
                            (local.get $5)
                            (i32.const 4)
                           )
                          )
                         )
                        )
                       )
                       (then
                        (call_indirect $0 (type $2)
                         (local.get $2)
                         (local.get $4)
                        )
                       )
                      )
                      (if
                       (i32.load offset=4
                        (local.get $3)
                       )
                       (then
                        (call $dlfree
                         (local.get $2)
                        )
                       )
                      )
                      (call $dlfree
                       (local.get $5)
                      )
                      (br $block76
                       (i32.const 4)
                      )
                     )
                     (local.set $20
                      (i64.and
                       (local.tee $21
                        (i64.load offset=56
                         (local.get $1)
                        )
                       )
                       (i64.const -256)
                      )
                     )
                     (i32.wrap_i64
                      (local.get $21)
                     )
                    )
                   )
                   (i32.store offset=8
                    (local.tee $2
                     (i32.load offset=16
                      (local.get $1)
                     )
                    )
                    (local.tee $4
                     (i32.sub
                      (i32.load offset=8
                       (local.get $2)
                      )
                      (i32.const 1)
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (local.get $4)
                    )
                    (then
                     (i32.store8 offset=12
                      (local.get $2)
                      (i32.const 0)
                     )
                     (i64.store
                      (local.get $2)
                      (i64.const 0)
                     )
                    )
                   )
                   (br_if $block77
                    (i32.ne
                     (i32.and
                      (local.get $3)
                      (i32.const 255)
                     )
                     (i32.const 4)
                    )
                   )
                   (i32.store8
                    (local.get $0)
                    (i32.const 4)
                   )
                   (br $block78)
                  )
                  (global.set $__stack_pointer
                   (local.tee $0
                    (i32.sub
                     (global.get $__stack_pointer)
                     (i32.const 16)
                    )
                   )
                  )
                  (i32.store offset=12
                   (local.get $0)
                   (i32.add
                    (local.get $1)
                    (i32.const 16)
                   )
                  )
                  (i32.store offset=8
                   (local.get $0)
                   (i32.add
                    (local.get $1)
                    (i32.const 4)
                   )
                  )
                  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking19assert_failed_inner
                   (i32.add
                    (local.get $0)
                    (i32.const 8)
                   )
                   (i32.const 1051320)
                   (i32.add
                    (local.get $0)
                    (i32.const 12)
                   )
                   (i32.const 1051320)
                   (i32.const 0)
                   (i32.const 1051160)
                  )
                  (unreachable)
                 )
                 (call $_RNvNvMNtNtCset5xJoy1xWQ_3std6thread2idNtB4_8ThreadId3new9exhausted)
                 (unreachable)
                )
                (call $_RINvNtCsdHhIpgkcIfN_4core9panicking13assert_failedbbECset5xJoy1xWQ_3std
                 (i32.add
                  (local.get $1)
                  (i32.const 56)
                 )
                )
                (unreachable)
               )
               (call $_RNvNtCsdHhIpgkcIfN_4core6option13expect_failed)
               (unreachable)
              )
              (i64.store offset=16
               (local.get $1)
               (i64.or
                (local.get $20)
                (i64.and
                 (i64.extend_i32_u
                  (local.get $3)
                 )
                 (i64.const 255)
                )
               )
              )
              (i64.store offset=64
               (local.get $1)
               (i64.or
                (i64.extend_i32_u
                 (i32.add
                  (local.get $1)
                  (i32.const 16)
                 )
                )
                (i64.const 21474836480)
               )
              )
              (i64.store offset=56
               (local.get $1)
               (i64.or
                (i64.extend_i32_u
                 (i32.add
                  (local.get $1)
                  (i32.const 440)
                 )
                )
                (i64.const 25769803776)
               )
              )
              (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
               (i32.const 1049255)
               (i32.add
                (local.get $1)
                (i32.const 56)
               )
               (i32.const 1054964)
              )
              (unreachable)
             )
             (i64.const 0)
            )
            (i64.shl
             (i64.extend_i32_u
              (local.get $2)
             )
             (i64.const 32)
            )
           )
          )
          (br_if $block57
           (i32.eqz
            (i32.load offset=32
             (local.get $1)
            )
           )
          )
          (call $dlfree
           (i32.load offset=36
            (local.get $1)
           )
          )
         )
         (call $close
          (local.get $17)
         )
        )
        (i64.store align=4
         (local.get $0)
         (local.get $20)
        )
       )
       (call $dlfree
        (local.get $16)
       )
       (local.set $4
        (local.get $13)
       )
       (loop $label19
        (if
         (i32.load
          (local.get $4)
         )
         (then
          (call $dlfree
           (i32.load
            (i32.add
             (local.get $4)
             (i32.const 4)
            )
           )
          )
         )
        )
        (local.set $4
         (i32.add
          (local.get $4)
          (i32.const 12)
         )
        )
        (br_if $label19
         (local.tee $14
          (i32.sub
           (local.get $14)
           (i32.const 1)
          )
         )
        )
       )
       (if
        (local.get $15)
        (then
         (call $dlfree
          (local.get $13)
         )
        )
       )
       (global.set $__stack_pointer
        (i32.add
         (local.get $1)
         (i32.const 448)
        )
       )
       (return)
      )
      (br_if $block
       (i32.eqz
        (local.get $6)
       )
      )
      (call $dlfree
       (local.get $8)
      )
     )
     (local.set $8
      (i32.const 0)
     )
     (local.set $9
      (i32.const 4)
     )
     (local.set $2
      (i32.const 4)
     )
     (local.set $4
      (i32.const 4)
     )
    )
    (local.set $0
     (i32.div_u
      (i32.sub
       (local.get $9)
       (local.get $4)
      )
      (i32.const 12)
     )
    )
    (if
     (i32.ne
      (local.get $4)
      (local.get $9)
     )
     (then
      (loop $label20
       (if
        (i32.load
         (local.get $4)
        )
        (then
         (call $dlfree
          (i32.load
           (i32.add
            (local.get $4)
            (i32.const 4)
           )
          )
         )
        )
       )
       (local.set $4
        (i32.add
         (local.get $4)
         (i32.const 12)
        )
       )
       (br_if $label20
        (local.tee $0
         (i32.sub
          (local.get $0)
          (i32.const 1)
         )
        )
       )
      )
     )
    )
    (local.set $14
     (i32.const 0)
    )
    (br_if $block20
     (i32.eqz
      (local.get $8)
     )
    )
    (call $dlfree
     (local.get $2)
    )
   )
   (call $_RNvNtCsdHhIpgkcIfN_4core9panicking18panic_bounds_check
    (i32.const 2)
    (local.get $14)
    (i32.const 1051128)
   )
   (unreachable)
  )
  (i64.store offset=56
   (local.get $1)
   (local.get $20)
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core6result13unwrap_failed
   (i32.add
    (local.get $1)
    (i32.const 56)
   )
   (i32.const 1055272)
   (i32.const 1057016)
  )
  (unreachable)
 )
 (func $_RNvNtNtCsdHhIpgkcIfN_4core3str8converts9from_utf8 (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i64)
  (block $block
   (br_if $block
    (i32.eqz
     (local.get $2)
    )
   )
   (local.set $7
    (select
     (local.tee $3
      (i32.sub
       (local.get $2)
       (i32.const 7)
      )
     )
     (i32.const 0)
     (i32.ge_u
      (local.get $2)
      (local.get $3)
     )
    )
   )
   (local.set $8
    (i32.sub
     (i32.and
      (i32.add
       (local.get $1)
       (i32.const 3)
      )
      (i32.const -4)
     )
     (local.get $1)
    )
   )
   (local.set $3
    (i32.const 0)
   )
   (loop $label2
    (block $block19
     (block $block2
      (block $block1
       (if
        (i32.ge_s
         (local.tee $6
          (i32.extend8_s
           (local.tee $5
            (i32.load8_u
             (i32.add
              (local.get $1)
              (local.get $3)
             )
            )
           )
          )
         )
         (i32.const 0)
        )
        (then
         (br_if $block1
          (i32.and
           (i32.sub
            (local.get $8)
            (local.get $3)
           )
           (i32.const 3)
          )
         )
         (br_if $block2
          (i32.ge_u
           (local.get $3)
           (local.get $7)
          )
         )
         (loop $label
          (br_if $block2
           (i32.and
            (i32.or
             (i32.load
              (i32.add
               (local.tee $4
                (i32.add
                 (local.get $1)
                 (local.get $3)
                )
               )
               (i32.const 4)
              )
             )
             (i32.load
              (local.get $4)
             )
            )
            (i32.const -2139062144)
           )
          )
          (br_if $label
           (i32.lt_u
            (local.tee $3
             (i32.add
              (local.get $3)
              (i32.const 8)
             )
            )
            (local.get $7)
           )
          )
         )
         (br $block2)
        )
       )
       (local.set $9
        (i64.const 1103806595072)
       )
       (block $block10
        (block $block6
         (block $block14
          (block $block9
           (block $block8
            (block $block7
             (block $block5
              (block $block4
               (block $block3
                (br_table $block3 $block4 $block5 $block6
                 (i32.sub
                  (i32.load8_u offset=1052491
                   (local.get $5)
                  )
                  (i32.const 2)
                 )
                )
               )
               (br_if $block7
                (i32.lt_u
                 (local.tee $4
                  (i32.add
                   (local.get $3)
                   (i32.const 1)
                  )
                 )
                 (local.get $2)
                )
               )
               (local.set $9
                (i64.const 0)
               )
               (br $block6)
              )
              (br_if $block8
               (i32.lt_u
                (local.tee $4
                 (i32.add
                  (local.get $3)
                  (i32.const 1)
                 )
                )
                (local.get $2)
               )
              )
              (local.set $9
               (i64.const 0)
              )
              (br $block6)
             )
             (br_if $block9
              (i32.lt_u
               (local.tee $4
                (i32.add
                 (local.get $3)
                 (i32.const 1)
                )
               )
               (local.get $2)
              )
             )
             (local.set $9
              (i64.const 0)
             )
             (br $block6)
            )
            (br_if $block6
             (i32.gt_s
              (i32.load8_s
               (i32.add
                (local.get $1)
                (local.get $4)
               )
              )
              (i32.const -65)
             )
            )
            (br $block10)
           )
           (local.set $4
            (i32.load8_s
             (i32.add
              (local.get $1)
              (local.get $4)
             )
            )
           )
           (block $block12
            (block $block13
             (block $block11
              (br_table $block11 $block12 $block12 $block12 $block12 $block12 $block12 $block12 $block12 $block12 $block12 $block12 $block12 $block13 $block12
               (i32.sub
                (local.get $5)
                (i32.const 224)
               )
              )
             )
             (br_if $block14
              (i32.eq
               (i32.and
                (local.get $4)
                (i32.const -32)
               )
               (i32.const -96)
              )
             )
             (br $block6)
            )
            (br_if $block6
             (i32.gt_s
              (local.get $4)
              (i32.const -97)
             )
            )
            (br $block14)
           )
           (if
            (i32.ge_u
             (i32.and
              (i32.add
               (local.get $6)
               (i32.const 31)
              )
              (i32.const 255)
             )
             (i32.const 12)
            )
            (then
             (br_if $block6
              (i32.ne
               (i32.and
                (local.get $6)
                (i32.const -2)
               )
               (i32.const -18)
              )
             )
             (br_if $block14
              (i32.lt_s
               (local.get $4)
               (i32.const -64)
              )
             )
             (br $block6)
            )
           )
           (br_if $block14
            (i32.lt_s
             (local.get $4)
             (i32.const -64)
            )
           )
           (br $block6)
          )
          (local.set $4
           (i32.load8_s
            (i32.add
             (local.get $1)
             (local.get $4)
            )
           )
          )
          (block $block18
           (block $block17
            (block $block15
             (block $block16
              (br_table $block15 $block16 $block16 $block16 $block17 $block16
               (i32.sub
                (local.get $5)
                (i32.const 240)
               )
              )
             )
             (br_if $block6
              (i32.gt_u
               (i32.and
                (i32.add
                 (local.get $6)
                 (i32.const 15)
                )
                (i32.const 255)
               )
               (i32.const 2)
              )
             )
             (br_if $block18
              (i32.lt_s
               (local.get $4)
               (i32.const -64)
              )
             )
             (br $block6)
            )
            (br_if $block18
             (i32.lt_u
              (i32.and
               (i32.add
                (local.get $4)
                (i32.const 112)
               )
               (i32.const 255)
              )
              (i32.const 48)
             )
            )
            (br $block6)
           )
           (br_if $block6
            (i32.gt_s
             (local.get $4)
             (i32.const -113)
            )
           )
          )
          (if
           (i32.le_u
            (local.get $2)
            (local.tee $4
             (i32.add
              (local.get $3)
              (i32.const 2)
             )
            )
           )
           (then
            (local.set $9
             (i64.const 0)
            )
            (br $block6)
           )
          )
          (if
           (i32.gt_s
            (i32.load8_s
             (i32.add
              (local.get $1)
              (local.get $4)
             )
            )
            (i32.const -65)
           )
           (then
            (local.set $9
             (i64.const 2203318222848)
            )
            (br $block6)
           )
          )
          (local.set $9
           (i64.const 0)
          )
          (br_if $block6
           (i32.ge_u
            (local.tee $4
             (i32.add
              (local.get $3)
              (i32.const 3)
             )
            )
            (local.get $2)
           )
          )
          (br_if $block10
           (i32.lt_s
            (i32.load8_s
             (i32.add
              (local.get $1)
              (local.get $4)
             )
            )
            (i32.const -64)
           )
          )
          (local.set $9
           (i64.const 3302829850624)
          )
          (br $block6)
         )
         (local.set $9
          (i64.const 0)
         )
         (br_if $block6
          (i32.ge_u
           (local.tee $4
            (i32.add
             (local.get $3)
             (i32.const 2)
            )
           )
           (local.get $2)
          )
         )
         (br_if $block10
          (i32.le_s
           (i32.load8_s
            (i32.add
             (local.get $1)
             (local.get $4)
            )
           )
           (i32.const -65)
          )
         )
         (local.set $9
          (i64.const 2203318222848)
         )
        )
        (i64.store offset=4 align=4
         (local.get $0)
         (i64.or
          (local.get $9)
          (i64.extend_i32_u
           (local.get $3)
          )
         )
        )
        (i32.store
         (local.get $0)
         (i32.const 1)
        )
        (return)
       )
       (local.set $3
        (i32.add
         (local.get $4)
         (i32.const 1)
        )
       )
       (br $block19)
      )
      (local.set $3
       (i32.add
        (local.get $3)
        (i32.const 1)
       )
      )
      (br $block19)
     )
     (br_if $block19
      (i32.le_u
       (local.get $2)
       (local.get $3)
      )
     )
     (loop $label1
      (br_if $block19
       (i32.lt_s
        (i32.load8_s
         (i32.add
          (local.get $1)
          (local.get $3)
         )
        )
        (i32.const 0)
       )
      )
      (br_if $label1
       (i32.ne
        (local.get $2)
        (local.tee $3
         (i32.add
          (local.get $3)
          (i32.const 1)
         )
        )
       )
      )
     )
     (br $block)
    )
    (br_if $label2
     (i32.gt_u
      (local.get $2)
      (local.get $3)
     )
    )
   )
  )
  (i32.store offset=8
   (local.get $0)
   (local.get $2)
  )
  (i32.store offset=4
   (local.get $0)
   (local.get $1)
  )
  (i32.store
   (local.get $0)
   (i32.const 0)
  )
 )
 (func $_RNvNtCsdHhIpgkcIfN_4core6result13unwrap_failed (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (i32.store offset=4
   (local.get $3)
   (i32.const 43)
  )
  (i32.store
   (local.get $3)
   (i32.const 1055288)
  )
  (i32.store offset=12
   (local.get $3)
   (local.get $1)
  )
  (i32.store offset=8
   (local.get $3)
   (local.get $0)
  )
  (i64.store offset=24
   (local.get $3)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $3)
      (i32.const 8)
     )
    )
    (i64.const 30064771072)
   )
  )
  (i64.store offset=16
   (local.get $3)
   (i64.or
    (i64.extend_i32_u
     (local.get $3)
    )
    (i64.const 25769803776)
   )
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1049275)
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
   (local.get $2)
  )
  (unreachable)
 )
 (func $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec17capacity_overflow
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1051376)
   (i32.const 35)
   (i32.const 1051396)
  )
  (unreachable)
 )
 (func $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error (param $0 i32) (param $1 i32)
  (if
   (local.get $0)
   (then
    (call $_RNvNtCsi9YzqDQQz2q_5alloc5alloc18handle_alloc_error
     (local.get $0)
     (local.get $1)
    )
    (unreachable)
   )
  )
  (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec17capacity_overflow)
  (unreachable)
 )
 (func $_RNvNtCsdHhIpgkcIfN_4core9panicking18panic_bounds_check (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (i32.store offset=12
   (local.get $3)
   (local.get $1)
  )
  (i32.store offset=8
   (local.get $3)
   (local.get $0)
  )
  (i64.store offset=24
   (local.get $3)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $3)
      (i32.const 8)
     )
    )
    (i64.const 17179869184)
   )
  )
  (i64.store offset=16
   (local.get $3)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $3)
      (i32.const 12)
     )
    )
    (i64.const 17179869184)
   )
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1048974)
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
   (local.get $2)
  )
  (unreachable)
 )
 (func $_ZN15bv2string_probe6Random10bytevector17hf452b417a2a79d91E (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (block $block
   (block $block4
    (block $block2
     (block $block1
      (if
       (i32.ge_u
        (local.get $2)
        (i32.const 16384)
       )
       (then
        (br_if $block
         (i32.load
          (i32.const 1060892)
         )
        )
        (local.set $7
         (i32.and
          (local.tee $5
           (i32.add
            (i32.mul
             (i32.load
              (local.get $1)
             )
             (i32.const 701)
            )
            (i32.const 219195)
           )
          )
          (i32.const 524287)
         )
        )
        (i32.store
         (i32.const 1060892)
         (i32.const -1)
        )
        (if
         (i32.le_u
          (i32.sub
           (i32.load
            (i32.const 1060896)
           )
           (local.tee $3
            (i32.load
             (i32.const 1060904)
            )
           )
          )
          (i32.const 2)
         )
         (then
          (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
           (i32.const 1060896)
           (local.get $3)
           (i32.const 3)
           (i32.const 4)
          )
          (local.set $3
           (i32.load
            (i32.const 1060904)
           )
          )
         )
        )
        (i32.store offset=8
         (local.tee $4
          (i32.add
           (i32.load
            (i32.const 1060900)
           )
           (i32.shl
            (local.get $3)
            (i32.const 2)
           )
          )
         )
         (local.tee $5
          (i32.and
           (i32.shr_u
            (local.get $5)
            (i32.const 3)
           )
           (i32.const 16383)
          )
         )
        )
        (i32.store offset=4
         (local.get $4)
         (local.get $7)
        )
        (i32.store
         (local.get $4)
         (i32.const 0)
        )
        (i32.store
         (i32.const 1060904)
         (local.tee $3
          (i32.add
           (local.get $3)
           (i32.const 3)
          )
         )
        )
        (i32.store
         (i32.const 1060892)
         (local.tee $6
          (i32.add
           (i32.load
            (i32.const 1060892)
           )
           (i32.const 1)
          )
         )
        )
        (local.set $4
         (i32.shr_u
          (local.get $2)
          (i32.const 14)
         )
        )
        (loop $label
         (i32.store
          (local.get $1)
          (local.tee $7
           (i32.and
            (local.tee $8
             (i32.add
              (i32.mul
               (local.get $7)
               (i32.const 701)
              )
              (i32.const 219195)
             )
            )
            (i32.const 524287)
           )
          )
         )
         (br_if $block
          (local.get $6)
         )
         (i32.store
          (i32.const 1060892)
          (i32.const -1)
         )
         (if
          (i32.le_u
           (i32.sub
            (i32.load
             (i32.const 1060896)
            )
            (local.get $3)
           )
           (i32.const 2)
          )
          (then
           (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
            (i32.const 1060896)
            (local.get $3)
            (i32.const 3)
            (i32.const 4)
           )
           (local.set $3
            (i32.load
             (i32.const 1060904)
            )
           )
          )
         )
         (i32.store offset=8
          (local.tee $6
           (i32.add
            (i32.load
             (i32.const 1060900)
            )
            (i32.shl
             (local.get $3)
             (i32.const 2)
            )
           )
          )
          (local.tee $8
           (i32.and
            (i32.shr_u
             (local.get $8)
             (i32.const 3)
            )
            (i32.const 16383)
           )
          )
         )
         (i32.store offset=4
          (local.get $6)
          (local.get $7)
         )
         (i32.store
          (local.get $6)
          (i32.const 0)
         )
         (i32.store
          (i32.const 1060904)
          (local.tee $3
           (i32.add
            (local.get $3)
            (i32.const 3)
           )
          )
         )
         (i32.store
          (i32.const 1060892)
          (local.tee $6
           (i32.add
            (i32.load
             (i32.const 1060892)
            )
            (i32.const 1)
           )
          )
         )
         (local.set $5
          (i32.or
           (local.get $8)
           (i32.shl
            (local.get $5)
            (i32.const 14)
           )
          )
         )
         (br_if $label
          (local.tee $4
           (i32.shr_u
            (local.get $4)
            (i32.const 14)
           )
          )
         )
        )
        (br_if $block1
         (i32.ge_s
          (local.tee $4
           (i32.rem_u
            (local.get $5)
            (local.get $2)
           )
          )
          (i32.const 0)
         )
        )
        (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec17capacity_overflow)
        (unreachable)
       )
      )
      (i32.store
       (local.get $1)
       (local.tee $7
        (i32.and
         (local.tee $5
          (i32.add
           (i32.mul
            (i32.load
             (local.get $1)
            )
            (i32.const 701)
           )
           (i32.const 219195)
          )
         )
         (i32.const 524287)
        )
       )
      )
      (br_if $block2
       (i32.eqz
        (local.get $2)
       )
      )
      (br_if $block
       (i32.load
        (i32.const 1060892)
       )
      )
      (i32.store
       (i32.const 1060892)
       (i32.const -1)
      )
      (if
       (i32.le_u
        (i32.sub
         (i32.load
          (i32.const 1060896)
         )
         (local.tee $3
          (i32.load
           (i32.const 1060904)
          )
         )
        )
        (i32.const 2)
       )
       (then
        (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
         (i32.const 1060896)
         (local.get $3)
         (i32.const 3)
         (i32.const 4)
        )
        (local.set $3
         (i32.load
          (i32.const 1060904)
         )
        )
       )
      )
      (i32.store offset=4
       (local.tee $4
        (i32.add
         (i32.load
          (i32.const 1060900)
         )
         (i32.shl
          (local.get $3)
          (i32.const 2)
         )
        )
       )
       (local.get $7)
      )
      (i32.store
       (local.get $4)
       (i32.const 0)
      )
      (i32.store offset=8
       (local.get $4)
       (local.tee $4
        (i32.rem_u
         (i32.and
          (i32.shr_u
           (local.get $5)
           (i32.const 3)
          )
          (i32.const 65535)
         )
         (i32.and
          (local.get $2)
          (i32.const 65535)
         )
        )
       )
      )
      (i32.store
       (i32.const 1060904)
       (local.tee $3
        (i32.add
         (local.get $3)
         (i32.const 3)
        )
       )
      )
      (i32.store
       (i32.const 1060892)
       (local.tee $6
        (i32.add
         (i32.load
          (i32.const 1060892)
         )
         (i32.const 1)
        )
       )
      )
     )
     (block $block3
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (local.set $2
         (i32.const 1)
        )
        (br $block3)
       )
      )
      (br_if $block4
       (i32.eqz
        (local.tee $2
         (call $dlmalloc
          (local.get $4)
         )
        )
       )
      )
      (local.set $5
       (i32.const 0)
      )
      (loop $label1
       (i32.store
        (local.get $1)
        (local.tee $7
         (i32.and
          (local.tee $8
           (i32.add
            (i32.mul
             (local.get $7)
             (i32.const 701)
            )
            (i32.const 219195)
           )
          )
          (i32.const 524287)
         )
        )
       )
       (br_if $block
        (local.get $6)
       )
       (i32.store
        (i32.const 1060892)
        (i32.const -1)
       )
       (if
        (i32.le_u
         (i32.sub
          (i32.load
           (i32.const 1060896)
          )
          (local.get $3)
         )
         (i32.const 2)
        )
        (then
         (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
          (i32.const 1060896)
          (local.get $3)
          (i32.const 3)
          (i32.const 4)
         )
         (local.set $3
          (i32.load
           (i32.const 1060904)
          )
         )
        )
       )
       (i32.store offset=8
        (local.tee $6
         (i32.add
          (i32.load
           (i32.const 1060900)
          )
          (i32.shl
           (local.get $3)
           (i32.const 2)
          )
         )
        )
        (local.tee $8
         (i32.and
          (i32.shr_u
           (local.get $8)
           (i32.const 3)
          )
          (i32.const 127)
         )
        )
       )
       (i32.store offset=4
        (local.get $6)
        (local.get $7)
       )
       (i32.store
        (local.get $6)
        (i32.const 0)
       )
       (i32.store
        (i32.const 1060904)
        (local.tee $3
         (i32.add
          (local.get $3)
          (i32.const 3)
         )
        )
       )
       (i32.store8
        (i32.add
         (local.get $2)
         (local.get $5)
        )
        (local.get $8)
       )
       (i32.store
        (i32.const 1060892)
        (local.tee $6
         (i32.add
          (i32.load
           (i32.const 1060892)
          )
          (i32.const 1)
         )
        )
       )
       (br_if $label1
        (i32.ne
         (local.tee $5
          (i32.add
           (local.get $5)
           (i32.const 1)
          )
         )
         (local.get $4)
        )
       )
      )
     )
     (i32.store offset=8
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=4
      (local.get $0)
      (local.get $2)
     )
     (i32.store
      (local.get $0)
      (local.get $4)
     )
     (return)
    )
    (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
     (i32.const 1054272)
     (i32.const 115)
     (i32.const 1051224)
    )
    (unreachable)
   )
   (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
    (i32.const 1)
    (local.get $4)
   )
   (unreachable)
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
   (i32.const 1051304)
  )
  (unreachable)
 )
 (func $_ZN15bv2string_probe9roundtrip17hb593ecb86af6a62dE (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (call $_ZN15bv2string_probe13observe_bytes17hc459c5ad045d1dd1E
   (i32.const 1)
   (local.tee $8
    (i32.load offset=4
     (local.get $0)
    )
   )
   (local.tee $1
    (i32.load offset=8
     (local.get $0)
    )
   )
  )
  (call $_RNvNtNtCsdHhIpgkcIfN_4core3str8converts9from_utf8
   (i32.add
    (local.get $2)
    (i32.const 12)
   )
   (local.get $8)
   (local.get $1)
  )
  (block $block2
   (block $block6
    (block $block7
     (block $block5
      (block $block4
       (block $block
        (if
         (i32.ne
          (i32.load offset=12
           (local.get $2)
          )
          (i32.const 1)
         )
         (then
          (br_if $block
           (i32.lt_s
            (local.tee $3
             (i32.load offset=20
              (local.get $2)
             )
            )
            (i32.const 0)
           )
          )
          (block $block3
           (block $block1
            (if
             (local.get $3)
             (then
              (local.set $1
               (i32.load offset=16
                (local.get $2)
               )
              )
              (br_if $block1
               (local.tee $5
                (call $dlmalloc
                 (local.get $3)
                )
               )
              )
              (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
               (i32.const 1)
               (local.get $3)
              )
              (unreachable)
             )
            )
            (br_if $block2
             (i32.load
              (i32.const 1060892)
             )
            )
            (i32.store
             (i32.const 1060892)
             (i32.const -1)
            )
            (if
             (i32.le_u
              (i32.sub
               (i32.load
                (i32.const 1060896)
               )
               (local.tee $1
                (i32.load
                 (i32.const 1060904)
                )
               )
              )
              (i32.const 1)
             )
             (then
              (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
               (i32.const 1060896)
               (local.get $1)
               (i32.const 2)
               (i32.const 4)
              )
              (local.set $1
               (i32.load
                (i32.const 1060904)
               )
              )
             )
            )
            (i64.store align=4
             (i32.add
              (i32.load
               (i32.const 1060900)
              )
              (i32.shl
               (local.get $1)
               (i32.const 2)
              )
             )
             (i64.const 2)
            )
            (i32.store
             (i32.const 1060904)
             (i32.add
              (local.get $1)
              (i32.const 2)
             )
            )
            (i32.store
             (i32.const 1060892)
             (local.tee $1
              (i32.add
               (i32.load
                (i32.const 1060892)
               )
               (i32.const 1)
              )
             )
            )
            (br_if $block2
             (local.get $1)
            )
            (i32.store
             (i32.const 1060892)
             (i32.const 0)
            )
            (local.set $5
             (i32.const 1)
            )
            (call $_ZN15bv2string_probe13observe_bytes17hc459c5ad045d1dd1E
             (i32.const 3)
             (i32.const 1)
             (i32.const 0)
            )
            (i64.store offset=16 align=4
             (local.get $2)
             (i64.const 1)
            )
            (local.set $6
             (i32.const 1)
            )
            (br $block3)
           )
           (if
            (i32.eqz
             (local.tee $4
              (i32.eqz
               (local.get $3)
              )
             )
            )
            (then
             (memory.copy
              (local.get $5)
              (local.get $1)
              (local.get $3)
             )
            )
           )
           (call $_ZN15bv2string_probe12observe_text17h4994e761050e0c72E
            (i32.const 2)
            (local.get $5)
            (local.get $3)
           )
           (br_if $block4
            (i32.eqz
             (local.tee $6
              (call $dlmalloc
               (local.get $3)
              )
             )
            )
           )
           (if
            (i32.eqz
             (local.get $4)
            )
            (then
             (memory.copy
              (local.get $6)
              (local.get $5)
              (local.get $3)
             )
            )
           )
           (call $_ZN15bv2string_probe13observe_bytes17hc459c5ad045d1dd1E
            (i32.const 3)
            (local.get $6)
            (local.get $3)
           )
           (call $_RNvNtNtCsdHhIpgkcIfN_4core3str8converts9from_utf8
            (i32.add
             (local.get $2)
             (i32.const 12)
            )
            (local.get $6)
            (local.get $3)
           )
           (br_if $block5
            (i32.eq
             (i32.load offset=12
              (local.get $2)
             )
             (i32.const 1)
            )
           )
          )
          (br_if $block
           (i32.lt_s
            (local.tee $4
             (i32.load offset=20
              (local.get $2)
             )
            )
            (i32.const 0)
           )
          )
          (if
           (i32.eqz
            (local.get $4)
           )
           (then
            (br_if $block2
             (i32.load
              (i32.const 1060892)
             )
            )
            (i32.store
             (i32.const 1060892)
             (i32.const -1)
            )
            (if
             (i32.le_u
              (i32.sub
               (i32.load
                (i32.const 1060896)
               )
               (local.tee $1
                (i32.load
                 (i32.const 1060904)
                )
               )
              )
              (i32.const 1)
             )
             (then
              (call $_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h048e198e13d89f44E
               (i32.const 1060896)
               (local.get $1)
               (i32.const 2)
               (i32.const 4)
              )
              (local.set $1
               (i32.load
                (i32.const 1060904)
               )
              )
             )
            )
            (i64.store align=4
             (i32.add
              (i32.load
               (i32.const 1060900)
              )
              (i32.shl
               (local.get $1)
               (i32.const 2)
              )
             )
             (i64.const 4)
            )
            (i32.store
             (i32.const 1060904)
             (i32.add
              (local.get $1)
              (i32.const 2)
             )
            )
            (i32.store
             (i32.const 1060892)
             (local.tee $1
              (i32.add
               (i32.load
                (i32.const 1060892)
               )
               (i32.const 1)
              )
             )
            )
            (br_if $block2
             (local.get $1)
            )
            (i32.store
             (i32.const 1060892)
             (i32.const 0)
            )
            (local.set $1
             (i32.const 1)
            )
            (br $block6)
           )
          )
          (local.set $7
           (i32.load offset=16
            (local.get $2)
           )
          )
          (br_if $block7
           (i32.eqz
            (local.tee $1
             (call $dlmalloc
              (local.get $4)
             )
            )
           )
          )
          (if
           (local.get $4)
           (then
            (memory.copy
             (local.get $1)
             (local.get $7)
             (local.get $4)
            )
           )
          )
          (call $_ZN15bv2string_probe12observe_text17h4994e761050e0c72E
           (i32.const 4)
           (local.get $1)
           (local.get $4)
          )
          (br $block6)
         )
        )
        (i64.store offset=24
         (local.get $2)
         (i64.load offset=16 align=4
          (local.get $2)
         )
        )
        (call $_RNvNtCsdHhIpgkcIfN_4core6result13unwrap_failed
         (i32.add
          (local.get $2)
          (i32.const 24)
         )
         (i32.const 1051240)
         (i32.const 1051272)
        )
        (unreachable)
       )
       (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec17capacity_overflow)
       (unreachable)
      )
      (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
       (i32.const 1)
       (local.get $3)
      )
      (unreachable)
     )
     (i64.store offset=24
      (local.get $2)
      (i64.load offset=16 align=4
       (local.get $2)
      )
     )
     (call $_RNvNtCsdHhIpgkcIfN_4core6result13unwrap_failed
      (i32.add
       (local.get $2)
       (i32.const 24)
      )
      (i32.const 1051240)
      (i32.const 1051256)
     )
     (unreachable)
    )
    (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
     (i32.const 1)
     (local.get $4)
    )
    (unreachable)
   )
   (local.set $7
    (i32.const 0)
   )
   (if
    (i32.eq
     (local.get $3)
     (local.get $4)
    )
    (then
     (local.set $7
      (i32.eqz
       (call $memcmp
        (local.get $5)
        (local.get $1)
        (local.get $3)
       )
      )
     )
    )
   )
   (if
    (local.get $4)
    (then
     (call $dlfree
      (local.get $1)
     )
    )
   )
   (if
    (local.get $3)
    (then
     (call $dlfree
      (local.get $6)
     )
     (call $dlfree
      (local.get $5)
     )
    )
   )
   (if
    (i32.load
     (local.get $0)
    )
    (then
     (call $dlfree
      (local.get $8)
     )
    )
   )
   (global.set $__stack_pointer
    (i32.add
     (local.get $2)
     (i32.const 32)
    )
   )
   (return
    (local.get $7)
   )
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
   (i32.const 1051304)
  )
  (unreachable)
 )
 (func $_RNCNvMsi_NtNtNtCset5xJoy1xWQ_3std3sys2fs4unixNtB7_4File4open0Bd_ (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i64)
  (local $20 i64)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $4
   (i32.load8_u offset=10
    (local.get $1)
   )
  )
  (local.set $3
   (i32.load8_u offset=9
    (local.get $1)
   )
  )
  (block $block10
   (local.set $4
    (block $block12 (result i32)
     (block $block8
      (block $block11
       (local.set $6
        (block $block9 (result i32)
         (block $block5
          (local.set $6
           (block $block6 (result i32)
            (block $block
             (block $block3
              (block $block2
               (block $block7
                (local.set $6
                 (block $block4 (result i32)
                  (if
                   (i32.eqz
                    (i32.load8_u offset=8
                     (local.get $1)
                    )
                   )
                   (then
                    (if
                     (i32.eqz
                      (i32.and
                       (local.get $3)
                       (i32.const 1)
                      )
                     )
                     (then
                      (br_if $block
                       (i32.and
                        (local.get $4)
                        (i32.const 1)
                       )
                      )
                      (local.set $3
                       (i32.load8_u offset=11
                        (local.get $1)
                       )
                      )
                      (local.set $4
                       (i32.load8_u offset=13
                        (local.get $1)
                       )
                      )
                      (block $block1
                       (br_if $block1
                        (local.tee $8
                         (i32.load8_u offset=12
                          (local.get $1)
                         )
                        )
                       )
                       (br_if $block1
                        (i32.and
                         (local.get $4)
                         (i32.const 1)
                        )
                       )
                       (br_if $block2
                        (i32.eqz
                         (i32.and
                          (local.get $3)
                          (i32.const 1)
                         )
                        )
                       )
                      )
                      (call $_RINvMs5_NtNtCset5xJoy1xWQ_3std2io5errorNtB6_5Error3newReEBa_
                       (i32.add
                        (local.get $5)
                        (i32.const 8)
                       )
                       (i32.const 1056402)
                       (i32.const 61)
                      )
                      (br $block3)
                     )
                    )
                    (br_if $block
                     (i32.and
                      (local.get $4)
                      (i32.const 1)
                     )
                    )
                    (br $block4
                     (i32.const 268435456)
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (i32.and
                     (local.get $3)
                     (i32.const 1)
                    )
                   )
                   (then
                    (br_if $block5
                     (i32.eqz
                      (i32.and
                       (local.get $4)
                       (i32.const 1)
                      )
                     )
                    )
                    (br $block6
                     (i32.const 335544321)
                    )
                   )
                  )
                  (br_if $block7
                   (i32.and
                    (local.get $4)
                    (i32.const 1)
                   )
                  )
                  (i32.const 335544320)
                 )
                )
                (local.set $4
                 (i32.load8_u offset=11
                  (local.get $1)
                 )
                )
                (local.set $3
                 (i32.load8_u offset=13
                  (local.get $1)
                 )
                )
                (br $block8)
               )
               (br $block6
                (i32.const 335544321)
               )
              )
              (call $_RINvMs5_NtNtCset5xJoy1xWQ_3std2io5errorNtB6_5Error3newReEBa_
               (i32.add
                (local.get $5)
                (i32.const 8)
               )
               (i32.const 1056344)
               (i32.const 58)
              )
             )
             (if
              (i32.eq
               (i32.load8_u offset=8
                (local.get $5)
               )
               (i32.const 4)
              )
              (then
               (br $block9
                (i32.load offset=12
                 (local.get $5)
                )
               )
              )
             )
             (i64.store align=4
              (local.get $0)
              (i64.load offset=8
               (local.get $5)
              )
             )
             (br $block10)
            )
            (i32.const 268435457)
           )
          )
          (local.set $3
           (i32.load8_u offset=13
            (local.get $1)
           )
          )
          (br_if $block8
           (i32.ne
            (local.tee $4
             (i32.load8_u offset=11
              (local.get $1)
             )
            )
            (i32.const 1)
           )
          )
          (br_if $block8
           (i32.and
            (local.get $3)
            (i32.const 1)
           )
          )
          (br $block11)
         )
         (local.set $4
          (i32.load8_u offset=13
           (local.get $1)
          )
         )
         (local.set $8
          (i32.load8_u offset=12
           (local.get $1)
          )
         )
         (local.set $3
          (i32.load8_u offset=11
           (local.get $1)
          )
         )
         (i32.const 67108864)
        )
       )
       (br_if $block11
        (i32.and
         (local.get $3)
         (i32.const 1)
        )
       )
       (br_if $block11
        (i32.and
         (local.get $8)
         (i32.const 1)
        )
       )
       (drop
        (br_if $block12
         (i32.const 0)
         (i32.eqz
          (i32.and
           (local.get $4)
           (i32.const 1)
          )
         )
        )
       )
      )
      (call $_RINvMs5_NtNtCset5xJoy1xWQ_3std2io5errorNtB6_5Error3newReEBa_
       (i32.add
        (local.get $5)
        (i32.const 8)
       )
       (i32.const 1056402)
       (i32.const 61)
      )
      (if
       (i32.eq
        (i32.load8_u offset=8
         (local.get $5)
        )
        (i32.const 4)
       )
       (then
        (br $block12
         (i32.load offset=12
          (local.get $5)
         )
        )
       )
      )
      (i64.store align=4
       (local.get $0)
       (i64.load offset=8
        (local.get $5)
       )
      )
      (br $block10)
     )
     (block $block13
      (if
       (i32.eqz
        (i32.load8_u offset=12
         (local.get $1)
        )
       )
       (then
        (br_if $block13
         (i32.and
          (local.get $3)
          (i32.const 1)
         )
        )
        (br $block12
         (select
          (i32.const 32768)
          (i32.const 0)
          (i32.and
           (local.get $4)
           (i32.const 1)
          )
         )
        )
       )
      )
      (br_if $block13
       (i32.and
        (local.get $3)
        (i32.const 1)
       )
      )
      (br $block12
       (select
        (i32.const 36864)
        (i32.const 4096)
        (i32.and
         (local.get $4)
         (i32.const 1)
        )
       )
      )
     )
     (i32.const 20480)
    )
   )
   (local.set $8
    (i32.or
     (i32.and
      (i32.load
       (local.get $1)
      )
      (i32.const -503316481)
     )
     (i32.or
      (local.get $4)
      (local.get $6)
     )
    )
   )
   (local.set $14
    (i32.load offset=4
     (local.get $1)
    )
   )
   (block $block23
    (loop $label4
     (i32.store
      (local.get $5)
      (local.get $14)
     )
     (global.set $__stack_pointer
      (local.tee $12
       (i32.sub
        (global.get $__stack_pointer)
        (i32.const 16)
       )
      )
     )
     (local.set $4
      (i32.const -1)
     )
     (local.set $15
      (i32.add
       (local.get $12)
       (i32.const 12)
      )
     )
     (local.set $1
      (i32.load
       (i32.const 1061068)
      )
     )
     (global.set $__stack_pointer
      (local.tee $13
       (i32.sub
        (global.get $__stack_pointer)
        (i32.const 16)
       )
      )
     )
     (i32.store offset=12
      (local.get $13)
      (local.get $1)
     )
     (local.set $1
      (block $block18 (result i32)
       (local.set $6
        (i32.const 0)
       )
       (local.set $7
        (i32.sub
         (local.get $2)
         (i32.const 1)
        )
       )
       (call $__wasilibc_populate_preopens)
       (loop $label
        (br_if $label
         (i32.eq
          (i32.load8_u
           (local.tee $7
            (i32.add
             (local.get $7)
             (i32.const 1)
            )
           )
          )
          (i32.const 47)
         )
        )
       )
       (block $block17
        (if
         (local.tee $10
          (i32.load
           (i32.const 1061072)
          )
         )
         (then
          (local.set $16
           (i32.load
            (i32.const 1061076)
           )
          )
          (local.set $9
           (i32.const -1)
          )
          (loop $label2
           (block $block14
            (br_if $block14
             (i32.and
              (i32.ne
               (local.get $9)
               (i32.const -1)
              )
              (i32.le_u
               (local.tee $1
                (call $strlen
                 (local.tee $11
                  (i32.load
                   (i32.sub
                    (local.tee $17
                     (i32.add
                      (local.get $16)
                      (i32.shl
                       (local.get $10)
                       (i32.const 3)
                      )
                     )
                    )
                    (i32.const 8)
                   )
                  )
                 )
                )
               )
               (local.get $6)
              )
             )
            )
            (block $block15
             (br_if $block15
              (i32.and
               (i32.eqz
                (local.get $1)
               )
               (i32.ne
                (local.tee $3
                 (i32.load8_u
                  (local.get $7)
                 )
                )
                (i32.const 47)
               )
              )
             )
             (br_if $block14
              (call $memcmp
               (local.get $7)
               (local.get $11)
               (local.get $1)
              )
             )
             (br_if $block15
              (i32.eq
               (local.tee $3
                (i32.and
                 (if (result i32)
                  (local.get $1)
                  (then
                   (local.set $18
                    (i32.sub
                     (local.get $11)
                     (i32.const 1)
                    )
                   )
                   (local.set $3
                    (local.get $1)
                   )
                   (block $block16
                    (loop $label1
                     (br_if $block16
                      (i32.ne
                       (i32.load8_u
                        (i32.add
                         (local.get $3)
                         (local.get $18)
                        )
                       )
                       (i32.const 47)
                      )
                     )
                     (br_if $label1
                      (local.tee $3
                       (i32.sub
                        (local.get $3)
                        (i32.const 1)
                       )
                      )
                     )
                    )
                    (local.set $3
                     (i32.const 0)
                    )
                   )
                   (i32.load8_u
                    (i32.add
                     (local.get $3)
                     (local.get $7)
                    )
                   )
                  )
                  (else
                   (local.get $3)
                  )
                 )
                 (i32.const 255)
                )
               )
               (i32.const 47)
              )
             )
             (br_if $block14
              (local.get $3)
             )
            )
            (i32.store
             (local.get $15)
             (local.get $11)
            )
            (local.set $9
             (i32.load
              (i32.sub
               (local.get $17)
               (i32.const 4)
              )
             )
            )
            (local.set $6
             (local.get $1)
            )
           )
           (br_if $label2
            (local.tee $10
             (i32.sub
              (local.get $10)
              (i32.const 1)
             )
            )
           )
          )
          (br_if $block17
           (i32.ne
            (local.get $9)
            (i32.const -1)
           )
          )
         )
        )
        (i32.store
         (i32.const 1061060)
         (i32.const 44)
        )
        (br $block18
         (i32.const -1)
        )
       )
       (local.set $7
        (i32.sub
         (i32.add
          (local.get $6)
          (local.get $7)
         )
         (i32.const 1)
        )
       )
       (loop $label3
        (br_if $label3
         (i32.eq
          (local.tee $1
           (i32.load8_u
            (local.tee $7
             (i32.add
              (local.get $7)
              (i32.const 1)
             )
            )
           )
          )
          (i32.const 47)
         )
        )
       )
       (i32.store
        (i32.const 1061064)
        (select
         (local.get $7)
         (i32.const 1050787)
         (local.get $1)
        )
       )
       (local.get $9)
      )
     )
     (global.set $__stack_pointer
      (i32.add
       (local.get $13)
       (i32.const 16)
      )
     )
     (block $block19
      (if
       (i32.eq
        (local.get $1)
        (i32.const -1)
       )
       (then
        (i32.store
         (i32.const 1061060)
         (i32.const 44)
        )
        (br $block19)
       )
      )
      (local.set $6
       (i32.load
        (i32.const 1061064)
       )
      )
      (global.set $__stack_pointer
       (local.tee $4
        (i32.sub
         (global.get $__stack_pointer)
         (i32.const 32)
        )
       )
      )
      (block $block22
       (local.set $19
        (i64.and
         (block $block21 (result i64)
          (block $block20
           (if
            (i32.le_u
             (local.tee $3
              (i32.shr_u
               (i32.sub
                (i32.and
                 (local.get $8)
                 (i32.const 503316480)
                )
                (i32.const 33554432)
               )
               (i32.const 25)
              )
             )
             (i32.const 9)
            )
            (then
             (br_if $block20
              (i32.and
               (local.tee $3
                (i32.shl
                 (i32.const 1)
                 (local.get $3)
                )
               )
               (i32.const 642)
              )
             )
             (drop
              (br_if $block21
               (i64.const -4211012)
               (i32.and
                (local.get $3)
                (i32.const 9)
               )
              )
             )
            )
           )
           (i32.store
            (i32.const 1061060)
            (i32.const 28)
           )
           (local.set $3
            (i32.const -1)
           )
           (br $block22)
          )
          (select
           (i64.or
            (local.tee $19
             (select
              (i64.const -4194626)
              (i64.const -4211012)
              (i32.and
               (local.get $8)
               (i32.const 67108864)
              )
             )
            )
            (i64.const 4194625)
           )
           (local.get $19)
           (i32.and
            (local.get $8)
            (i32.const 268435456)
           )
          )
         )
         (block (result i64)
          (if
           (local.tee $3
            (i32.and
             (call $__imported_wasi_snapshot_preview1_fd_fdstat_get
              (local.get $1)
              (i32.add
               (local.get $4)
               (i32.const 8)
              )
             )
             (i32.const 65535)
            )
           )
           (then
            (i32.store
             (i32.const 1061060)
             (local.get $3)
            )
            (local.set $3
             (i32.const -1)
            )
            (br $block22)
           )
          )
          (local.set $3
           (i32.const -1)
          )
          (local.tee $20
           (i64.load offset=24
            (local.get $4)
           )
          )
         )
        )
       )
       (if
        (local.tee $1
         (i32.and
          (call $__imported_wasi_snapshot_preview1_path_open
           (local.get $1)
           (i32.and
            (i32.shr_u
             (i32.xor
              (local.get $8)
              (i32.const -1)
             )
             (i32.const 24)
            )
            (i32.const 1)
           )
           (local.get $6)
           (call $strlen
            (local.get $6)
           )
           (i32.and
            (i32.shr_u
             (local.get $8)
             (i32.const 12)
            )
            (i32.const 4095)
           )
           (local.get $19)
           (local.get $20)
           (i32.and
            (local.get $8)
            (i32.const 4095)
           )
           (i32.add
            (local.get $4)
            (i32.const 4)
           )
          )
          (i32.const 65535)
         )
        )
        (then
         (i32.store
          (i32.const 1061060)
          (local.get $1)
         )
         (br $block22)
        )
       )
       (local.set $3
        (i32.load offset=4
         (local.get $4)
        )
       )
      )
      (global.set $__stack_pointer
       (i32.add
        (local.get $4)
        (i32.const 32)
       )
      )
      (local.set $4
       (local.get $3)
      )
     )
     (global.set $__stack_pointer
      (i32.add
       (local.get $12)
       (i32.const 16)
      )
     )
     (br_if $block23
      (i32.ne
       (local.get $4)
       (i32.const -1)
      )
     )
     (br_if $label4
      (i32.eq
       (local.tee $1
        (i32.load
         (i32.const 1061060)
        )
       )
       (i32.const 27)
      )
     )
    )
    (i32.store16 offset=1 align=1
     (local.get $0)
     (i32.const 0)
    )
    (i32.store offset=4
     (local.get $0)
     (local.get $1)
    )
    (i32.store8
     (local.get $0)
     (i32.const 0)
    )
    (i32.store8
     (i32.add
      (local.get $0)
      (i32.const 3)
     )
     (i32.const 0)
    )
    (br $block10)
   )
   (i32.store8
    (local.get $0)
    (i32.const 4)
   )
   (i32.store offset=4
    (local.get $0)
    (local.get $4)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
  )
 )
 (func $_RINvNvMs2_NtCsi9YzqDQQz2q_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECset5xJoy1xWQ_3std (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (if
   (i32.gt_u
    (local.get $2)
    (local.tee $1
     (i32.add
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
     (i32.const 0)
     (i32.const 0)
    )
    (unreachable)
   )
  )
  (call $_RNvMs4_NtCsi9YzqDQQz2q_5alloc7raw_vecNtB5_11RawVecInner11finish_growCset5xJoy1xWQ_3std
   (i32.add
    (local.get $3)
    (i32.const 4)
   )
   (local.tee $2
    (i32.load
     (local.get $0)
    )
   )
   (i32.load offset=4
    (local.get $0)
   )
   (local.tee $1
    (select
     (i32.const 8)
     (local.tee $1
      (select
       (local.get $1)
       (local.tee $2
        (i32.shl
         (local.get $2)
         (i32.const 1)
        )
       )
       (i32.gt_u
        (local.get $1)
        (local.get $2)
       )
      )
     )
     (i32.le_u
      (local.get $1)
      (i32.const 8)
     )
    )
   )
   (i32.const 1)
   (i32.const 1)
  )
  (if
   (i32.eq
    (i32.load offset=4
     (local.get $3)
    )
    (i32.const 1)
   )
   (then
    (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
     (i32.load offset=8
      (local.get $3)
     )
     (i32.load offset=12
      (local.get $3)
     )
    )
    (unreachable)
   )
  )
  (local.set $2
   (i32.load offset=8
    (local.get $3)
   )
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
  (i32.store offset=4
   (local.get $0)
   (local.get $2)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
 )
 (func $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32)
  (local $4 i32)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (block $block2
   (block $block1
    (block $block
     (if
      (i32.le_u
       (local.get $0)
       (local.get $2)
      )
      (then
       (br_if $block
        (i32.gt_u
         (local.get $1)
         (local.get $2)
        )
       )
       (br_if $block1
        (i32.le_u
         (local.get $0)
         (local.get $1)
        )
       )
       (i32.store offset=8
        (local.get $4)
        (local.get $0)
       )
       (i32.store offset=12
        (local.get $4)
        (local.get $1)
       )
       (i64.store offset=24
        (local.get $4)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $4)
           (i32.const 12)
          )
         )
         (i64.const 17179869184)
        )
       )
       (i64.store offset=16
        (local.get $4)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $4)
           (i32.const 8)
          )
         )
         (i64.const 17179869184)
        )
       )
       (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
        (i32.const 1048934)
        (i32.add
         (local.get $4)
         (i32.const 16)
        )
        (local.get $3)
       )
       (unreachable)
      )
     )
     (i32.store offset=8
      (local.get $4)
      (local.get $0)
     )
     (i32.store offset=12
      (local.get $4)
      (local.get $2)
     )
     (i64.store offset=24
      (local.get $4)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $4)
         (i32.const 12)
        )
       )
       (i64.const 17179869184)
      )
     )
     (i64.store offset=16
      (local.get $4)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $4)
         (i32.const 8)
        )
       )
       (i64.const 17179869184)
      )
     )
     (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
      (i32.const 1049029)
      (i32.add
       (local.get $4)
       (i32.const 16)
      )
      (local.get $3)
     )
     (unreachable)
    )
    (i32.store offset=8
     (local.get $4)
     (local.get $1)
    )
    (i32.store offset=12
     (local.get $4)
     (local.get $2)
    )
    (i64.store offset=24
     (local.get $4)
     (i64.or
      (i64.extend_i32_u
       (i32.add
        (local.get $4)
        (i32.const 12)
       )
      )
      (i64.const 17179869184)
     )
    )
    (br $block2)
   )
   (i32.store offset=8
    (local.get $4)
    (local.get $1)
   )
   (i32.store offset=12
    (local.get $4)
    (local.get $2)
   )
   (i64.store offset=24
    (local.get $4)
    (i64.or
     (i64.extend_i32_u
      (i32.add
       (local.get $4)
       (i32.const 12)
      )
     )
     (i64.const 17179869184)
    )
   )
  )
  (i64.store offset=16
   (local.get $4)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $4)
      (i32.const 8)
     )
    )
    (i64.const 17179869184)
   )
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1049086)
   (i32.add
    (local.get $4)
    (i32.const 16)
   )
   (local.get $3)
  )
  (unreachable)
 )
 (func $_RNvMs4_NtCsi9YzqDQQz2q_5alloc7raw_vecNtB5_11RawVecInner11finish_growCset5xJoy1xWQ_3std (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i64)
  (global.set $__stack_pointer
   (local.tee $6
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $8
   (i32.const 1)
  )
  (local.set $7
   (i32.const 4)
  )
  (block $block
   (if
    (i64.ne
     (i64.shr_u
      (local.tee $9
       (i64.mul
        (i64.extend_i32_u
         (local.get $5)
        )
        (i64.extend_i32_u
         (local.get $3)
        )
       )
      )
      (i64.const 32)
     )
     (i64.const 0)
    )
    (then
     (local.set $3
      (i32.const 0)
     )
     (br $block)
    )
   )
   (if
    (i32.gt_u
     (local.tee $3
      (i32.wrap_i64
       (local.get $9)
      )
     )
     (i32.sub
      (i32.const -2147483648)
      (local.get $4)
     )
    )
    (then
     (local.set $3
      (i32.const 0)
     )
     (br $block)
    )
   )
   (block $block4
    (block $block2
     (block $block1
      (br_if $block2
       (local.tee $7
        (block $block3 (result i32)
         (if
          (local.get $1)
          (then
           (if
            (i32.lt_u
             (local.get $3)
             (local.get $4)
            )
            (then
             (i32.store offset=8
              (local.get $6)
              (i32.const 0)
             )
             (br_if $block1
              (call $posix_memalign
               (i32.add
                (local.get $6)
                (i32.const 8)
               )
               (local.get $3)
              )
             )
             (br_if $block1
              (i32.eqz
               (local.tee $7
                (i32.load offset=8
                 (local.get $6)
                )
               )
              )
             )
             (if
              (local.tee $1
               (i32.mul
                (local.get $1)
                (local.get $5)
               )
              )
              (then
               (memory.copy
                (local.get $7)
                (local.get $2)
                (local.get $1)
               )
              )
             )
             (call $dlfree
              (local.get $2)
             )
             (br $block2)
            )
           )
           (br $block3
            (call $realloc
             (local.get $2)
             (local.get $3)
            )
           )
          )
         )
         (if
          (i32.eqz
           (local.get $3)
          )
          (then
           (local.set $7
            (local.get $4)
           )
           (br $block2)
          )
         )
         (if
          (i32.lt_u
           (local.get $3)
           (local.get $4)
          )
          (then
           (i32.store offset=12
            (local.get $6)
            (i32.const 0)
           )
           (br_if $block1
            (call $posix_memalign
             (i32.add
              (local.get $6)
              (i32.const 12)
             )
             (local.get $3)
            )
           )
           (br $block3
            (i32.load offset=12
             (local.get $6)
            )
           )
          )
         )
         (call $dlmalloc
          (local.get $3)
         )
        )
       )
      )
     )
     (i32.store offset=4
      (local.get $0)
      (local.get $4)
     )
     (br $block4)
    )
    (i32.store offset=4
     (local.get $0)
     (local.get $7)
    )
    (local.set $8
     (i32.const 0)
    )
   )
   (local.set $7
    (i32.const 8)
   )
  )
  (i32.store
   (i32.add
    (local.get $0)
    (local.get $7)
   )
   (local.get $3)
  )
  (i32.store
   (local.get $0)
   (local.get $8)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $6)
    (i32.const 16)
   )
  )
 )
 (func $_RNvNtCsdHhIpgkcIfN_4core3fmt5write (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (result i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $6
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $scratch
   (block $block1 (result i32)
    (block $block
     (if
      (i32.eqz
       (i32.and
        (local.get $3)
        (i32.const 1)
       )
      )
      (then
       (br_if $block
        (local.tee $5
         (i32.load8_u
          (local.get $2)
         )
        )
       )
       (br $block1
        (i32.const 0)
       )
      )
     )
     (br $block1
      (call_indirect $0 (type $0)
       (local.get $0)
       (local.get $2)
       (i32.shr_u
        (local.get $3)
        (i32.const 1)
       )
       (i32.load offset=12
        (local.get $1)
       )
      )
     )
    )
    (local.set $10
     (i32.load offset=12
      (local.get $1)
     )
    )
    (loop $label
     (local.set $4
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (block $block5
      (block $block3
       (block $block4
        (block $block2
         (if
          (i32.lt_s
           (i32.extend8_s
            (local.get $5)
           )
           (i32.const 0)
          )
          (then
           (br_if $block2
            (i32.eq
             (local.tee $8
              (i32.and
               (local.get $5)
               (i32.const 255)
              )
             )
             (i32.const 128)
            )
           )
           (br_if $block3
            (i32.ne
             (local.get $8)
             (i32.const 192)
            )
           )
           (i32.store offset=4
            (local.get $6)
            (local.get $1)
           )
           (i32.store
            (local.get $6)
            (local.get $0)
           )
           (i64.store offset=8 align=4
            (local.get $6)
            (i64.const 1610612768)
           )
           (br_if $block4
            (i32.eqz
             (call_indirect $0 (type $1)
              (i32.load
               (local.tee $2
                (i32.add
                 (local.get $3)
                 (i32.shl
                  (local.get $7)
                  (i32.const 3)
                 )
                )
               )
              )
              (local.get $6)
              (i32.load offset=4
               (local.get $2)
              )
             )
            )
           )
           (br $block1
            (i32.const 1)
           )
          )
         )
         (if
          (i32.eqz
           (call_indirect $0 (type $0)
            (local.get $0)
            (local.get $4)
            (local.tee $2
             (i32.and
              (local.get $5)
              (i32.const 255)
             )
            )
            (local.get $10)
           )
          )
          (then
           (local.set $2
            (i32.add
             (local.get $2)
             (local.get $4)
            )
           )
           (br $block5)
          )
         )
         (br $block1
          (i32.const 1)
         )
        )
        (if
         (i32.eqz
          (call_indirect $0 (type $0)
           (local.get $0)
           (local.tee $4
            (i32.add
             (local.get $2)
             (i32.const 3)
            )
           )
           (local.tee $2
            (i32.load16_u offset=1 align=1
             (local.get $2)
            )
           )
           (local.get $10)
          )
         )
         (then
          (local.set $2
           (i32.add
            (local.get $2)
            (local.get $4)
           )
          )
          (br $block5)
         )
        )
        (br $block1
         (i32.const 1)
        )
       )
       (local.set $7
        (i32.add
         (local.get $7)
         (i32.const 1)
        )
       )
       (local.set $2
        (local.get $4)
       )
       (br $block5)
      )
      (local.set $11
       (i32.const 1610612768)
      )
      (if
       (i32.and
        (local.get $5)
        (i32.const 1)
       )
       (then
        (local.set $11
         (i32.load offset=1 align=1
          (local.get $2)
         )
        )
        (local.set $4
         (i32.add
          (local.get $2)
          (i32.const 5)
         )
        )
       )
      )
      (local.set $8
       (i32.const 0)
      )
      (local.set $2
       (block $block6 (result i32)
        (if
         (i32.eqz
          (i32.and
           (local.get $5)
           (i32.const 2)
          )
         )
         (then
          (local.set $9
           (i32.const 0)
          )
          (br $block6
           (local.get $4)
          )
         )
        )
        (local.set $9
         (i32.load16_u align=1
          (local.get $4)
         )
        )
        (i32.add
         (local.get $4)
         (i32.const 2)
        )
       )
      )
      (local.set $4
       (if (result i32)
        (i32.and
         (local.get $5)
         (i32.const 4)
        )
        (then
         (local.set $8
          (i32.load16_u align=1
           (local.get $2)
          )
         )
         (i32.add
          (local.get $2)
          (i32.const 2)
         )
        )
        (else
         (local.get $2)
        )
       )
      )
      (local.set $2
       (if (result i32)
        (i32.and
         (local.get $5)
         (i32.const 8)
        )
        (then
         (local.set $7
          (i32.load16_u align=1
           (local.get $4)
          )
         )
         (i32.add
          (local.get $4)
          (i32.const 2)
         )
        )
        (else
         (local.get $4)
        )
       )
      )
      (if
       (i32.and
        (local.get $5)
        (i32.const 16)
       )
       (then
        (local.set $9
         (i32.load16_u offset=4
          (i32.add
           (local.get $3)
           (i32.shl
            (local.get $9)
            (i32.const 3)
           )
          )
         )
        )
       )
      )
      (i32.store16 offset=14
       (local.get $6)
       (if (result i32)
        (i32.and
         (local.get $5)
         (i32.const 32)
        )
        (then
         (i32.load16_u offset=4
          (i32.add
           (local.get $3)
           (i32.shl
            (local.get $8)
            (i32.const 3)
           )
          )
         )
        )
        (else
         (local.get $8)
        )
       )
      )
      (i32.store16 offset=12
       (local.get $6)
       (local.get $9)
      )
      (i32.store offset=8
       (local.get $6)
       (local.get $11)
      )
      (i32.store offset=4
       (local.get $6)
       (local.get $1)
      )
      (i32.store
       (local.get $6)
       (local.get $0)
      )
      (drop
       (br_if $block1
        (i32.const 1)
        (call_indirect $0 (type $1)
         (i32.load
          (local.tee $4
           (i32.add
            (local.get $3)
            (i32.shl
             (local.get $7)
             (i32.const 3)
            )
           )
          )
         )
         (local.get $6)
         (i32.load offset=4
          (local.get $4)
         )
        )
       )
      )
      (local.set $7
       (i32.add
        (local.get $7)
        (i32.const 1)
       )
      )
     )
     (br_if $label
      (local.tee $5
       (i32.load8_u
        (local.get $2)
       )
      )
     )
    )
    (i32.const 0)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $6)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i64)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (i32.store offset=16
   (local.get $3)
   (local.get $1)
  )
  (i32.store offset=12
   (local.get $3)
   (local.get $0)
  )
  (i32.store16 offset=28
   (local.get $3)
   (i32.const 1)
  )
  (i32.store offset=24
   (local.get $3)
   (local.get $2)
  )
  (i32.store offset=20
   (local.get $3)
   (i32.add
    (local.get $3)
    (i32.const 12)
   )
  )
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $4
   (i64.load align=4
    (local.tee $0
     (i32.add
      (local.get $3)
      (i32.const 20)
     )
    )
   )
  )
  (i32.store offset=12
   (local.get $1)
   (local.get $0)
  )
  (i64.store offset=4 align=4
   (local.get $1)
   (local.get $4)
  )
  (global.set $__stack_pointer
   (local.tee $0
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (if
   (i32.and
    (local.tee $3
     (i32.load offset=4
      (local.tee $2
       (i32.load
        (local.tee $1
         (i32.add
          (local.get $1)
          (i32.const 4)
         )
        )
       )
      )
     )
    )
    (i32.const 1)
   )
   (then
    (local.set $2
     (i32.load
      (local.get $2)
     )
    )
    (i32.store offset=4
     (local.get $0)
     (i32.shr_u
      (local.get $3)
      (i32.const 1)
     )
    )
    (i32.store
     (local.get $0)
     (local.get $2)
    )
    (call $_RNvNtCset5xJoy1xWQ_3std9panicking15panic_with_hook
     (local.get $0)
     (i32.const 1055216)
     (i32.load offset=4
      (local.get $1)
     )
     (i32.load8_u offset=8
      (local.tee $0
       (i32.load offset=8
        (local.get $1)
       )
      )
     )
     (i32.load8_u offset=9
      (local.get $0)
     )
    )
    (unreachable)
   )
  )
  (i32.store
   (local.get $0)
   (i32.const -2147483648)
  )
  (i32.store offset=12
   (local.get $0)
   (local.get $1)
  )
  (call $_RNvNtCset5xJoy1xWQ_3std9panicking15panic_with_hook
   (local.get $0)
   (i32.const 1055244)
   (i32.load offset=4
    (local.get $1)
   )
   (i32.load8_u offset=8
    (local.tee $0
     (i32.load offset=8
      (local.get $1)
     )
    )
   )
   (i32.load8_u offset=9
    (local.get $0)
   )
  )
  (unreachable)
 )
 (func $_RNvNvMNtNtCset5xJoy1xWQ_3std6thread2idNtB4_8ThreadId3new9exhausted
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1056808)
   (i32.const 111)
   (i32.const 1056864)
  )
  (unreachable)
 )
 (func $_RINvNtCsdHhIpgkcIfN_4core9panicking13assert_failedbbECset5xJoy1xWQ_3std (param $0 i32)
  (local $1 i32)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=12
   (local.get $1)
   (i32.const 1051124)
  )
  (i32.store offset=8
   (local.get $1)
   (local.get $0)
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking19assert_failed_inner
   (i32.add
    (local.get $1)
    (i32.const 8)
   )
   (i32.const 1054748)
   (i32.add
    (local.get $1)
    (i32.const 12)
   )
   (i32.const 1054748)
   (i32.const 1056192)
   (i32.const 1056224)
  )
  (unreachable)
 )
 (func $_RNvNtCsdHhIpgkcIfN_4core6option13expect_failed
  (local $0 i32)
  (global.set $__stack_pointer
   (local.tee $0
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 38)
  )
  (i32.store
   (local.get $0)
   (i32.const 1056240)
  )
  (i64.store offset=8
   (local.get $0)
   (i64.or
    (i64.extend_i32_u
     (local.get $0)
    )
    (i64.const 25769803776)
   )
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1049279)
   (i32.add
    (local.get $0)
    (i32.const 8)
   )
   (i32.const 1056280)
  )
  (unreachable)
 )
 (func $_RNvXs7_NtNtCset5xJoy1xWQ_3std2io5errorNtB5_5ErrorNtNtCsdHhIpgkcIfN_4core3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (block $block4
   (block $block3
    (block $block2
     (block $block1
      (block $block
       (br_table $block $block1 $block2 $block3
        (i32.sub
         (i32.load8_u
          (local.get $0)
         )
         (i32.const 1)
        )
       )
      )
      (i32.store offset=8
       (local.get $2)
       (i32.load offset=1058812
        (local.tee $0
         (i32.shl
          (i32.load8_u offset=1
           (local.get $0)
          )
          (i32.const 2)
         )
        )
       )
      )
      (i32.store offset=4
       (local.get $2)
       (i32.load offset=1058980
        (local.get $0)
       )
      )
      (i64.store offset=16
       (local.get $2)
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 4)
         )
        )
        (i64.const 25769803776)
       )
      )
      (local.set $0
       (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
        (i32.load
         (local.get $1)
        )
        (i32.load offset=4
         (local.get $1)
        )
        (i32.const 1049279)
        (i32.add
         (local.get $2)
         (i32.const 16)
        )
       )
      )
      (br $block4)
     )
     (local.set $0
      (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter3pad
       (local.get $1)
       (i32.load
        (local.tee $0
         (i32.load offset=4
          (local.get $0)
         )
        )
       )
       (i32.load offset=4
        (local.get $0)
       )
      )
     )
     (br $block4)
    )
    (local.set $0
     (call_indirect $0 (type $1)
      (i32.load
       (local.tee $0
        (i32.load offset=4
         (local.get $0)
        )
       )
      )
      (local.get $1)
      (i32.load offset=16
       (i32.load offset=4
        (local.get $0)
       )
      )
     )
    )
    (br $block4)
   )
   (i32.store
    (local.get $2)
    (local.tee $0
     (i32.load offset=4
      (local.get $0)
     )
    )
   )
   (call $_RNvNtNtNtNtCset5xJoy1xWQ_3std3sys2io5error4wasi12error_string
    (local.tee $3
     (i32.add
      (local.get $2)
      (i32.const 4)
     )
    )
    (local.get $0)
   )
   (i64.store offset=24
    (local.get $2)
    (i64.or
     (i64.extend_i32_u
      (local.get $2)
     )
     (i64.const 38654705664)
    )
   )
   (i64.store offset=16
    (local.get $2)
    (i64.or
     (i64.extend_i32_u
      (local.get $3)
     )
     (i64.const 42949672960)
    )
   )
   (local.set $0
    (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
     (i32.load
      (local.get $1)
     )
     (i32.load offset=4
      (local.get $1)
     )
     (i32.const 1050789)
     (i32.add
      (local.get $2)
      (i32.const 16)
     )
    )
   )
   (br_if $block4
    (i32.eqz
     (i32.load offset=4
      (local.get $2)
     )
    )
   )
   (call $dlfree
    (i32.load offset=8
     (local.get $2)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 32)
   )
  )
  (local.get $0)
 )
 (func $_RNvXs1i_NtCsdHhIpgkcIfN_4core3fmtReNtB6_7Display3fmtB8_ (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter3pad
   (local.get $1)
   (i32.load
    (local.get $0)
   )
   (i32.load offset=4
    (local.get $0)
   )
  )
 )
 (func $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h5ac845b5d188be53E (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (local.set $4
   (i32.load
    (i32.add
     (local.tee $0
      (i32.load
       (local.get $0)
      )
     )
     (i32.const 8)
    )
   )
  )
  (local.set $5
   (i32.load
    (i32.add
     (local.get $0)
     (i32.const 4)
    )
   )
  )
  (local.set $3
   (call_indirect $0 (type $0)
    (i32.load
     (local.get $1)
    )
    (i32.const 1052490)
    (i32.const 1)
    (i32.load offset=12
     (i32.load offset=4
      (local.get $1)
     )
    )
   )
  )
  (block $block
   (if
    (i32.eqz
     (local.get $4)
    )
    (then
     (local.set $0
      (local.get $3)
     )
     (br $block)
    )
   )
   (local.set $0
    (block $block1 (result i32)
     (drop
      (br_if $block1
       (i32.const 1)
       (local.get $3)
      )
     )
     (if
      (i32.and
       (i32.load8_u offset=10
        (local.get $1)
       )
       (i32.const 128)
      )
      (then
       (drop
        (br_if $block1
         (i32.const 1)
         (call_indirect $0 (type $0)
          (local.tee $3
           (i32.load
            (local.get $1)
           )
          )
          (i32.const 1052210)
          (i32.const 1)
          (i32.load offset=12
           (local.tee $0
            (i32.load offset=4
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (i32.store8 offset=15
        (local.get $2)
        (i32.const 1)
       )
       (i32.store offset=4
        (local.get $2)
        (local.get $0)
       )
       (i32.store
        (local.get $2)
        (local.get $3)
       )
       (i32.store offset=20
        (local.get $2)
        (i32.const 1052216)
       )
       (i64.store offset=24 align=4
        (local.get $2)
        (i64.load offset=8 align=4
         (local.get $1)
        )
       )
       (i32.store offset=8
        (local.get $2)
        (i32.add
         (local.get $2)
         (i32.const 15)
        )
       )
       (i32.store offset=16
        (local.get $2)
        (local.get $2)
       )
       (drop
        (br_if $block1
         (i32.const 1)
         (call $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6a7a616754267648E
          (local.get $5)
          (i32.add
           (local.get $2)
           (i32.const 16)
          )
         )
        )
       )
       (br $block1
        (call_indirect $0 (type $0)
         (i32.load offset=16
          (local.get $2)
         )
         (i32.const 1052205)
         (i32.const 2)
         (i32.load offset=12
          (i32.load offset=20
           (local.get $2)
          )
         )
        )
       )
      )
     )
     (call $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6a7a616754267648E
      (local.get $5)
      (local.get $1)
     )
    )
   )
   (br_if $block
    (i32.eq
     (local.get $4)
     (i32.const 1)
    )
   )
   (local.set $3
    (i32.add
     (local.get $5)
     (i32.const 1)
    )
   )
   (local.set $4
    (i32.sub
     (local.get $4)
     (i32.const 1)
    )
   )
   (loop $label
    (local.set $5
     (i32.and
      (local.get $0)
      (i32.const 1)
     )
    )
    (local.set $0
     (block $block2 (result i32)
      (drop
       (br_if $block2
        (i32.const 1)
        (local.get $5)
       )
      )
      (block $block3
       (if
        (i32.and
         (i32.load8_u offset=10
          (local.get $1)
         )
         (i32.const 128)
        )
        (then
         (local.set $6
          (i64.load align=4
           (local.get $1)
          )
         )
         (i32.store8 offset=15
          (local.get $2)
          (i32.const 1)
         )
         (i64.store align=4
          (local.get $2)
          (local.get $6)
         )
         (i32.store offset=20
          (local.get $2)
          (i32.const 1052216)
         )
         (i64.store offset=24 align=4
          (local.get $2)
          (i64.load offset=8 align=4
           (local.get $1)
          )
         )
         (i32.store offset=8
          (local.get $2)
          (i32.add
           (local.get $2)
           (i32.const 15)
          )
         )
         (i32.store offset=16
          (local.get $2)
          (local.get $2)
         )
         (br_if $block3
          (i32.eqz
           (call $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6a7a616754267648E
            (local.get $3)
            (i32.add
             (local.get $2)
             (i32.const 16)
            )
           )
          )
         )
         (br $block2
          (i32.const 1)
         )
        )
       )
       (drop
        (br_if $block2
         (i32.const 1)
         (call_indirect $0 (type $0)
          (i32.load
           (local.get $1)
          )
          (i32.const 1052198)
          (i32.const 2)
          (i32.load offset=12
           (i32.load offset=4
            (local.get $1)
           )
          )
         )
        )
       )
       (br $block2
        (call $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6a7a616754267648E
         (local.get $3)
         (local.get $1)
        )
       )
      )
      (call_indirect $0 (type $0)
       (i32.load offset=16
        (local.get $2)
       )
       (i32.const 1052205)
       (i32.const 2)
       (i32.load offset=12
        (i32.load offset=20
         (local.get $2)
        )
       )
      )
     )
    )
    (local.set $3
     (i32.add
      (local.get $3)
      (i32.const 1)
     )
    )
    (br_if $label
     (local.tee $4
      (i32.sub
       (local.get $4)
       (i32.const 1)
      )
     )
    )
   )
  )
  (local.set $3
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (local.set $3
     (call_indirect $0 (type $0)
      (i32.load
       (local.get $1)
      )
      (i32.const 1052213)
      (i32.const 1)
      (i32.load offset=12
       (i32.load offset=4
        (local.get $1)
       )
      )
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 32)
   )
  )
  (local.get $3)
 )
 (func $_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h6a7a616754267648E (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $scratch
   (block $block1 (result i32)
    (block $block
     (if
      (i32.eqz
       (i32.and
        (local.tee $2
         (i32.load offset=8
          (local.get $1)
         )
        )
        (i32.const 33554432)
       )
      )
      (then
       (br_if $block
        (i32.and
         (local.get $2)
         (i32.const 67108864)
        )
       )
       (local.set $2
        (i32.const 3)
       )
       (local.set $4
        (local.tee $0
         (i32.load8_u
          (local.get $0)
         )
        )
       )
       (if
        (i32.ge_u
         (local.get $0)
         (i32.const 10)
        )
        (then
         (i32.store16 offset=12 align=1
          (local.get $3)
          (i32.load16_u offset=1052290 align=1
           (i32.shl
            (i32.and
             (i32.sub
              (local.get $0)
              (i32.mul
               (local.tee $4
                (i32.div_u
                 (local.get $0)
                 (i32.const 100)
                )
               )
               (i32.const 100)
              )
             )
             (i32.const 255)
            )
            (i32.const 1)
           )
          )
         )
         (local.set $2
          (i32.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (select
          (i32.const 0)
          (local.get $0)
          (local.get $4)
         )
        )
        (then
         (i32.store8
          (i32.add
           (local.tee $2
            (i32.sub
             (local.get $2)
             (i32.const 1)
            )
           )
           (i32.add
            (local.get $3)
            (i32.const 11)
           )
          )
          (i32.load8_u offset=1052291
           (i32.shl
            (local.get $4)
            (i32.const 1)
           )
          )
         )
        )
       )
       (br $block1
        (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
         (local.get $1)
         (i32.const 1)
         (i32.const 1)
         (i32.const 0)
         (i32.add
          (i32.add
           (local.get $3)
           (i32.const 11)
          )
          (local.get $2)
         )
         (i32.sub
          (i32.const 3)
          (local.get $2)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.load8_u
       (local.get $0)
      )
     )
     (local.set $0
      (i32.const 3)
     )
     (loop $label
      (i32.store8
       (i32.add
        (i32.add
         (local.get $0)
         (local.get $3)
        )
        (i32.const 7)
       )
       (i32.load8_u
        (i32.add
         (i32.and
          (local.get $2)
          (i32.const 15)
         )
         (i32.const 1052179)
        )
       )
      )
      (local.set $0
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
      )
      (br_if $label
       (local.tee $2
        (i32.and
         (i32.shr_u
          (local.get $2)
          (i32.const 4)
         )
         (i32.const 15)
        )
       )
      )
     )
     (br $block1
      (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
       (local.get $1)
       (i32.const 1)
       (i32.const 1054516)
       (i32.const 2)
       (i32.add
        (i32.add
         (local.get $0)
         (local.get $3)
        )
        (i32.const 8)
       )
       (i32.sub
        (i32.const 3)
        (local.get $0)
       )
      )
     )
    )
    (local.set $2
     (i32.load8_u
      (local.get $0)
     )
    )
    (local.set $0
     (i32.const 3)
    )
    (loop $label1
     (i32.store8
      (i32.add
       (i32.add
        (local.get $0)
        (local.get $3)
       )
       (i32.const 12)
      )
      (i32.load8_u
       (i32.add
        (i32.and
         (local.get $2)
         (i32.const 15)
        )
        (i32.const 1054518)
       )
      )
     )
     (local.set $0
      (i32.sub
       (local.get $0)
       (i32.const 1)
      )
     )
     (br_if $label1
      (local.tee $2
       (i32.and
        (i32.shr_u
         (local.get $2)
         (i32.const 4)
        )
        (i32.const 15)
       )
      )
     )
    )
    (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
     (local.get $1)
     (i32.const 1)
     (i32.const 1054516)
     (i32.const 2)
     (i32.add
      (i32.add
       (local.get $0)
       (local.get $3)
      )
      (i32.const 13)
     )
     (i32.sub
      (i32.const 3)
      (local.get $0)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvNtCsdHhIpgkcIfN_4core9panicking19assert_failed_inner (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i32)
  (local $6 i32)
  (global.set $__stack_pointer
   (local.tee $6
    (i32.add
     (global.get $__stack_pointer)
     (i32.const -64)
    )
   )
  )
  (i32.store offset=4
   (local.get $6)
   (local.get $1)
  )
  (i32.store
   (local.get $6)
   (local.get $0)
  )
  (i32.store offset=12
   (local.get $6)
   (local.get $3)
  )
  (i32.store offset=8
   (local.get $6)
   (local.get $2)
  )
  (i32.store offset=20
   (local.get $6)
   (i32.const 2)
  )
  (i32.store offset=16
   (local.get $6)
   (i32.const 1052288)
  )
  (if
   (local.get $4)
   (then
    (i32.store offset=28
     (local.get $6)
     (i32.const 65)
    )
    (i32.store offset=24
     (local.get $6)
     (local.get $4)
    )
    (i64.store offset=56
     (local.get $6)
     (i64.or
      (i64.extend_i32_u
       (i32.add
        (local.get $6)
        (i32.const 8)
       )
      )
      (i64.const 30064771072)
     )
    )
    (i64.store offset=48
     (local.get $6)
     (i64.or
      (i64.extend_i32_u
       (local.get $6)
      )
      (i64.const 30064771072)
     )
    )
    (i64.store offset=40
     (local.get $6)
     (i64.or
      (i64.extend_i32_u
       (i32.add
        (local.get $6)
        (i32.const 24)
       )
      )
      (i64.const 47244640256)
     )
    )
    (i64.store offset=32
     (local.get $6)
     (i64.or
      (i64.extend_i32_u
       (i32.add
        (local.get $6)
        (i32.const 16)
       )
      )
      (i64.const 25769803776)
     )
    )
    (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
     (i32.const 1049196)
     (i32.add
      (local.get $6)
      (i32.const 32)
     )
     (local.get $5)
    )
    (unreachable)
   )
  )
  (i64.store offset=48
   (local.get $6)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $6)
      (i32.const 8)
     )
    )
    (i64.const 30064771072)
   )
  )
  (i64.store offset=40
   (local.get $6)
   (i64.or
    (i64.extend_i32_u
     (local.get $6)
    )
    (i64.const 30064771072)
   )
  )
  (i64.store offset=32
   (local.get $6)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $6)
      (i32.const 16)
     )
    )
    (i64.const 25769803776)
   )
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1049141)
   (i32.add
    (local.get $6)
    (i32.const 32)
   )
   (local.get $5)
  )
  (unreachable)
 )
 (func $__main_void (result i32)
  (local $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 48)
    )
   )
  )
  (block $block3
   (block $block1
    (block $block
     (if
      (i64.eqz
       (local.tee $8
        (i64.load
         (i32.const 1061008)
        )
       )
      )
      (then
       (local.set $7
        (i64.load
         (i32.const 1061016)
        )
       )
       (loop $label
        (br_if $block
         (i64.eq
          (local.get $7)
          (i64.const -1)
         )
        )
        (i64.store
         (i32.const 1061016)
         (select
          (local.tee $8
           (i64.add
            (local.get $7)
            (i64.const 1)
           )
          )
          (local.tee $9
           (i64.load
            (i32.const 1061016)
           )
          )
          (local.tee $1
           (i64.eq
            (local.get $7)
            (local.get $9)
           )
          )
         )
        )
        (local.set $7
         (local.get $9)
        )
        (br_if $label
         (i32.eqz
          (local.get $1)
         )
        )
       )
       (i64.store
        (i32.const 1061008)
        (local.get $8)
       )
      )
     )
     (i64.store
      (i32.const 1060992)
      (local.get $8)
     )
     (call $_ZN15bv2string_probe4main17h8009ca56fb25b28eE
      (i32.add
       (local.get $2)
       (i32.const 8)
      )
     )
     (if
      (i32.ne
       (i32.load8_u offset=8
        (local.get $2)
       )
       (i32.const 4)
      )
      (then
       (i64.store offset=16
        (local.get $2)
        (i64.load offset=8
         (local.get $2)
        )
       )
       (i64.store offset=24
        (local.get $2)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $2)
           (i32.const 16)
          )
         )
         (i64.const 55834574848)
        )
       )
       (if
        (i64.eqz
         (local.tee $8
          (i64.load
           (i32.const 1061008)
          )
         )
        )
        (then
         (local.set $7
          (i64.load
           (i32.const 1061016)
          )
         )
         (loop $label1
          (br_if $block
           (i64.eq
            (local.get $7)
            (i64.const -1)
           )
          )
          (i64.store
           (i32.const 1061016)
           (select
            (local.tee $8
             (i64.add
              (local.get $7)
              (i64.const 1)
             )
            )
            (local.tee $9
             (i64.load
              (i32.const 1061016)
             )
            )
            (local.tee $1
             (i64.eq
              (local.get $7)
              (local.get $9)
             )
            )
           )
          )
          (local.set $7
           (local.get $9)
          )
          (br_if $label1
           (i32.eqz
            (local.get $1)
           )
          )
         )
         (i64.store
          (i32.const 1061008)
          (local.get $8)
         )
        )
       )
       (block $block2
        (if
         (i64.ne
          (i64.load
           (i32.const 1061032)
          )
          (local.get $8)
         )
         (then
          (local.set $1
           (i32.load8_u
            (i32.const 1061044)
           )
          )
          (local.set $0
           (i32.const 1)
          )
          (i32.store8
           (i32.const 1061044)
           (i32.const 1)
          )
          (i32.store8 offset=36
           (local.get $2)
           (local.get $1)
          )
          (br_if $block1
           (local.get $1)
          )
          (i64.store
           (i32.const 1061032)
           (local.get $8)
          )
          (br $block2)
         )
        )
        (br_if $block3
         (i32.eq
          (local.tee $1
           (i32.load
            (i32.const 1061040)
           )
          )
          (i32.const -1)
         )
        )
        (local.set $0
         (i32.add
          (local.get $1)
          (i32.const 1)
         )
        )
       )
       (i32.store
        (i32.const 1061040)
        (local.get $0)
       )
       (i32.store offset=32
        (local.get $2)
        (i32.const 1061032)
       )
       (i32.store offset=36
        (local.get $2)
        (i32.const 4)
       )
       (i32.store offset=44
        (local.get $2)
        (i32.add
         (local.get $2)
         (i32.const 32)
        )
       )
       (local.set $0
        (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
         (i32.add
          (local.get $2)
          (i32.const 36)
         )
         (i32.const 1054892)
         (i32.const 1051040)
         (i32.add
          (local.get $2)
          (i32.const 24)
         )
        )
       )
       (local.set $1
        (i32.load8_u offset=36
         (local.get $2)
        )
       )
       (block $block5
        (block $block4
         (if
          (local.get $0)
          (then
           (br_if $block4
            (i32.ne
             (i32.and
              (local.get $1)
              (i32.const 255)
             )
             (i32.const 4)
            )
           )
           (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
            (i32.const 1054788)
            (i32.const 173)
            (i32.const 1054876)
           )
           (unreachable)
          )
         )
         (br_if $block5
          (i32.ne
           (i32.and
            (local.get $1)
            (i32.const 255)
           )
           (i32.const 3)
          )
         )
         (local.set $1
          (i32.load
           (local.tee $0
            (i32.load offset=40
             (local.get $2)
            )
           )
          )
         )
         (if
          (local.tee $5
           (i32.load
            (local.tee $3
             (i32.load
              (i32.add
               (local.get $0)
               (i32.const 4)
              )
             )
            )
           )
          )
          (then
           (call_indirect $0 (type $2)
            (local.get $1)
            (local.get $5)
           )
          )
         )
         (if
          (i32.load offset=4
           (local.get $3)
          )
          (then
           (call $dlfree
            (local.get $1)
           )
          )
         )
         (call $dlfree
          (local.get $0)
         )
         (br $block5)
        )
        (local.set $4
         (i32.eq
          (i32.load8_u offset=36
           (local.get $2)
          )
          (i32.const 3)
         )
        )
        (local.set $1
         (i32.load offset=40
          (local.get $2)
         )
        )
       )
       (i32.store offset=8
        (local.tee $0
         (i32.load offset=32
          (local.get $2)
         )
        )
        (local.tee $3
         (i32.sub
          (i32.load offset=8
           (local.get $0)
          )
          (i32.const 1)
         )
        )
       )
       (if
        (i32.eqz
         (local.get $3)
        )
        (then
         (i32.store8 offset=12
          (local.get $0)
          (i32.const 0)
         )
         (i64.store
          (local.get $0)
          (i64.const 0)
         )
        )
       )
       (if
        (local.get $4)
        (then
         (local.set $0
          (i32.load
           (local.get $1)
          )
         )
         (if
          (local.tee $3
           (i32.load
            (local.tee $4
             (i32.load
              (i32.add
               (local.get $1)
               (i32.const 4)
              )
             )
            )
           )
          )
          (then
           (call_indirect $0 (type $2)
            (local.get $0)
            (local.get $3)
           )
          )
         )
         (if
          (i32.load offset=4
           (local.get $4)
          )
          (then
           (call $dlfree
            (local.get $0)
           )
          )
         )
         (call $dlfree
          (local.get $1)
         )
        )
       )
       (if
        (i32.eq
         (i32.load8_u offset=16
          (local.get $2)
         )
         (i32.const 3)
        )
        (then
         (local.set $0
          (i32.load
           (local.tee $1
            (i32.load offset=20
             (local.get $2)
            )
           )
          )
         )
         (if
          (local.tee $3
           (i32.load
            (local.tee $4
             (i32.load
              (i32.add
               (local.get $1)
               (i32.const 4)
              )
             )
            )
           )
          )
          (then
           (call_indirect $0 (type $2)
            (local.get $0)
            (local.get $3)
           )
          )
         )
         (if
          (i32.load offset=4
           (local.get $4)
          )
          (then
           (call $dlfree
            (local.get $0)
           )
          )
         )
         (call $dlfree
          (local.get $1)
         )
        )
       )
       (local.set $4
        (i32.const 1)
       )
      )
     )
     (if
      (i32.ne
       (i32.load8_u
        (i32.const 1061024)
       )
       (i32.const 3)
      )
      (then
       (i32.store8 offset=36
        (local.get $2)
        (i32.const 1)
       )
       (local.set $0
        (i32.add
         (local.get $2)
         (i32.const 36)
        )
       )
       (global.set $__stack_pointer
        (local.tee $1
         (i32.sub
          (global.get $__stack_pointer)
          (i32.const 16)
         )
        )
       )
       (block $block20
        (block $block18
         (block $block8
          (block $block13
           (block $block16
            (block $block17
             (block $block7
              (block $block14
               (block $block6
                (block $block9
                 (br_table $block6 $block7 $block8 $block9
                  (i32.sub
                   (i32.load8_u
                    (i32.const 1061024)
                   )
                   (i32.const 1)
                  )
                 )
                )
                (i32.store8
                 (i32.const 1061024)
                 (i32.const 2)
                )
                (local.set $3
                 (i32.load8_u
                  (local.get $0)
                 )
                )
                (i32.store8
                 (local.get $0)
                 (i32.const 0)
                )
                (block $block15
                 (if
                  (i32.eq
                   (local.get $3)
                   (i32.const 1)
                  )
                  (then
                   (i32.store8 offset=7
                    (local.get $1)
                    (i32.const 0)
                   )
                   (if
                    (i32.ne
                     (local.tee $3
                      (i32.load8_u
                       (i32.const 1060984)
                      )
                     )
                     (i32.const 3)
                    )
                    (then
                     (local.set $0
                      (i32.add
                       (local.get $1)
                       (i32.const 7)
                      )
                     )
                     (block $block11
                      (block $block12
                       (block $block10
                        (br_table $block10 $block11 $block12
                         (i32.sub
                          (local.get $3)
                          (i32.const 2)
                         )
                        )
                       )
                       (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
                        (i32.const 1054690)
                        (i32.const 113)
                        (i32.const 1054632)
                       )
                       (unreachable)
                      )
                      (i32.store8
                       (i32.const 1060984)
                       (i32.const 3)
                      )
                      (i64.store
                       (i32.const 1060968)
                       (i64.const 1)
                      )
                      (i64.store
                       (i32.const 1060960)
                       (i64.const 0)
                      )
                      (i64.store
                       (i32.const 1060944)
                       (i64.const 0)
                      )
                      (i32.store8
                       (local.get $0)
                       (i32.const 1)
                      )
                      (i32.store8
                       (i32.const 1060976)
                       (i32.const 0)
                      )
                      (i32.store8
                       (i32.const 1060956)
                       (i32.const 0)
                      )
                      (i32.store
                       (i32.const 1060952)
                       (i32.const 0)
                      )
                     )
                     (br_if $block13
                      (i32.load8_u offset=7
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if
                    (i64.eqz
                     (local.tee $8
                      (i64.load
                       (i32.const 1061008)
                      )
                     )
                    )
                    (then
                     (local.set $7
                      (i64.load
                       (i32.const 1061016)
                      )
                     )
                     (loop $label2
                      (br_if $block14
                       (i64.eq
                        (local.get $7)
                        (i64.const -1)
                       )
                      )
                      (i64.store
                       (i32.const 1061016)
                       (select
                        (local.tee $8
                         (i64.add
                          (local.get $7)
                          (i64.const 1)
                         )
                        )
                        (local.tee $9
                         (i64.load
                          (i32.const 1061016)
                         )
                        )
                        (local.tee $0
                         (i64.eq
                          (local.get $7)
                          (local.get $9)
                         )
                        )
                       )
                      )
                      (local.set $7
                       (local.get $9)
                      )
                      (br_if $label2
                       (i32.eqz
                        (local.get $0)
                       )
                      )
                     )
                     (i64.store
                      (i32.const 1061008)
                      (local.get $8)
                     )
                    )
                   )
                   (br_if $block15
                    (i64.eq
                     (local.get $8)
                     (i64.load
                      (i32.const 1060944)
                     )
                    )
                   )
                   (br_if $block13
                    (block (result i32)
                     (local.set $scratch
                      (i32.load8_u
                       (i32.const 1060956)
                      )
                     )
                     (local.set $0
                      (i32.const 1)
                     )
                     (i32.store8
                      (i32.const 1060956)
                      (i32.const 1)
                     )
                     (local.get $scratch)
                    )
                   )
                   (i64.store
                    (i32.const 1060944)
                    (local.get $8)
                   )
                   (br $block16)
                  )
                 )
                 (call $_RNvNtCsdHhIpgkcIfN_4core6option13unwrap_failed
                  (i32.const 1055064)
                 )
                 (unreachable)
                )
                (br_if $block17
                 (i32.ne
                  (local.tee $0
                   (i32.load
                    (i32.const 1060952)
                   )
                  )
                  (i32.const -1)
                 )
                )
                (br $block13)
               )
               (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
                (i32.const 1054648)
                (i32.const 85)
                (i32.const 1056464)
               )
               (unreachable)
              )
              (call $_RNvNvMNtNtCset5xJoy1xWQ_3std6thread2idNtB4_8ThreadId3new9exhausted)
              (unreachable)
             )
             (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
              (i32.const 1054690)
              (i32.const 113)
              (i32.const 1056464)
             )
             (unreachable)
            )
            (local.set $0
             (i32.add
              (local.get $0)
              (i32.const 1)
             )
            )
           )
           (i32.store
            (i32.const 1060952)
            (local.get $0)
           )
           (br_if $block18
            (i32.load
             (i32.const 1060960)
            )
           )
           (i32.store
            (i32.const 1060960)
            (i32.const -1)
           )
           (block $block19
            (br_if $block19
             (i32.load8_u
              (i32.const 1060976)
             )
            )
            (call $_RNvMs_NtNtNtCset5xJoy1xWQ_3std2io8buffered9bufwriterINtB4_9BufWriterNtNtB8_5stdio9StdoutRawE9flush_bufBa_
             (i32.add
              (local.get $1)
              (i32.const 8)
             )
             (i32.const 1060964)
            )
            (br_if $block19
             (i32.ne
              (i32.load8_u offset=8
               (local.get $1)
              )
              (i32.const 3)
             )
            )
            (local.set $3
             (i32.load
              (local.tee $0
               (i32.load offset=12
                (local.get $1)
               )
              )
             )
            )
            (if
             (local.tee $6
              (i32.load
               (local.tee $5
                (i32.load
                 (i32.add
                  (local.get $0)
                  (i32.const 4)
                 )
                )
               )
              )
             )
             (then
              (call_indirect $0 (type $2)
               (local.get $3)
               (local.get $6)
              )
             )
            )
            (if
             (i32.load offset=4
              (local.get $5)
             )
             (then
              (call $dlfree
               (local.get $3)
              )
             )
            )
            (call $dlfree
             (local.get $0)
            )
           )
           (if
            (i32.load
             (i32.const 1060964)
            )
            (then
             (call $dlfree
              (i32.load
               (i32.const 1060968)
              )
             )
            )
           )
           (i64.store align=4
            (i32.const 1060964)
            (i64.const 4294967296)
           )
           (i32.store
            (i32.const 1060960)
            (i32.add
             (i32.load
              (i32.const 1060960)
             )
             (i32.const 1)
            )
           )
           (i32.store
            (i32.const 1060952)
            (local.tee $0
             (i32.sub
              (i32.load
               (i32.const 1060952)
              )
              (i32.const 1)
             )
            )
           )
           (i32.store8
            (i32.const 1060976)
            (i32.const 0)
           )
           (i32.store
            (i32.const 1060972)
            (i32.const 0)
           )
           (br_if $block13
            (local.get $0)
           )
           (i64.store
            (i32.const 1060944)
            (i64.const 0)
           )
           (i32.store8
            (i32.const 1060956)
            (i32.const 0)
           )
          )
          (i32.store8
           (i32.const 1061024)
           (i32.const 3)
          )
         )
         (global.set $__stack_pointer
          (i32.add
           (local.get $1)
           (i32.const 16)
          )
         )
         (br $block20)
        )
        (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
         (i32.const 1056564)
        )
        (unreachable)
       )
      )
     )
     (global.set $__stack_pointer
      (i32.add
       (local.get $2)
       (i32.const 48)
      )
     )
     (return
      (local.get $4)
     )
    )
    (call $_RNvNvMNtNtCset5xJoy1xWQ_3std6thread2idNtB4_8ThreadId3new9exhausted)
    (unreachable)
   )
   (call $_RINvNtCsdHhIpgkcIfN_4core9panicking13assert_failedbbECset5xJoy1xWQ_3std
    (i32.add
     (local.get $2)
     (i32.const 36)
    )
   )
   (unreachable)
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core6option13expect_failed)
  (unreachable)
 )
 (func $_RNvXNtNtCset5xJoy1xWQ_3std2io5errorNtB2_5ErrorNtNtCsdHhIpgkcIfN_4core3fmt5Debug3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (local $7 i64)
  (local $scratch i32)
  (local $scratch_9 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 48)
    )
   )
  )
  (block $block9
   (block $block6
    (block $block7
     (block $block2
      (block $block1
       (block $block
        (block $block3
         (br_table $block $block1 $block2 $block3
          (i32.sub
           (i32.load8_u
            (local.get $0)
           )
           (i32.const 1)
          )
         )
        )
        (i32.store offset=4
         (local.get $2)
         (i32.load offset=4
          (local.get $0)
         )
        )
        (local.set $0
         (call_indirect $0 (type $0)
          (i32.load
           (local.get $1)
          )
          (i32.const 1056908)
          (i32.const 2)
          (i32.load offset=12
           (i32.load offset=4
            (local.get $1)
           )
          )
         )
        )
        (i32.store8 offset=13
         (local.get $2)
         (i32.const 0)
        )
        (i32.store8 offset=12
         (local.get $2)
         (local.get $0)
        )
        (i32.store offset=8
         (local.get $2)
         (local.get $1)
        )
        (local.set $4
         (call $_RNvMs1_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_11DebugStruct5field
          (i32.add
           (local.get $2)
           (i32.const 8)
          )
          (i32.const 1056910)
          (i32.const 4)
          (i32.add
           (local.get $2)
           (i32.const 4)
          )
          (i32.const 14)
         )
        )
        (local.set $0
         (i32.const 41)
        )
        (if
         (i32.le_u
          (local.tee $1
           (i32.sub
            (i32.load offset=4
             (local.get $2)
            )
            (i32.const 1)
           )
          )
          (i32.const 74)
         )
         (then
          (local.set $0
           (i32.load8_u offset=1057728
            (local.get $1)
           )
          )
         )
        )
        (block $block8
         (block $block4
          (br_if $block4
           (i32.load8_u offset=12
            (local.get $2)
           )
          )
          (local.set $3
           (i32.load8_u offset=13
            (local.get $2)
           )
          )
          (block $block5
           (if
            (i32.eqz
             (i32.and
              (i32.load8_u offset=10
               (local.tee $1
                (i32.load
                 (local.get $4)
                )
               )
              )
              (i32.const 128)
             )
            )
            (then
             (br_if $block4
              (call_indirect $0 (type $0)
               (i32.load
                (local.get $1)
               )
               (select
                (i32.const 1052198)
                (i32.const 1052195)
                (local.tee $3
                 (i32.and
                  (local.get $3)
                  (i32.const 1)
                 )
                )
               )
               (select
                (i32.const 2)
                (i32.const 3)
                (local.get $3)
               )
               (i32.load offset=12
                (i32.load
                 (local.tee $3
                  (i32.add
                   (local.get $1)
                   (i32.const 4)
                  )
                 )
                )
               )
              )
             )
             (br_if $block4
              (call_indirect $0 (type $0)
               (i32.load
                (local.get $1)
               )
               (i32.const 1056914)
               (i32.const 4)
               (i32.load offset=12
                (i32.load
                 (local.get $3)
                )
               )
              )
             )
             (br_if $block4
              (call_indirect $0 (type $0)
               (i32.load
                (local.get $1)
               )
               (i32.const 1052200)
               (i32.const 2)
               (i32.load offset=12
                (i32.load
                 (local.get $3)
                )
               )
              )
             )
             (br_if $block5
              (i32.eqz
               (block (result i32)
                (local.set $scratch
                 (call_indirect $0 (type $0)
                  (i32.load
                   (local.get $1)
                  )
                  (i32.load offset=1058644
                   (local.tee $0
                    (i32.shl
                     (i32.and
                      (local.get $0)
                      (i32.const 255)
                     )
                     (i32.const 2)
                    )
                   )
                  )
                  (i32.load offset=1058476
                   (local.get $0)
                  )
                  (i32.load offset=12
                   (i32.load
                    (local.get $3)
                   )
                  )
                 )
                )
                (call $_RNvNtNtNtNtCset5xJoy1xWQ_3std3sys2io5error4wasi12error_string
                 (i32.add
                  (local.get $2)
                  (i32.const 20)
                 )
                 (i32.load offset=4
                  (local.get $2)
                 )
                )
                (local.get $scratch)
               )
              )
             )
             (local.set $0
              (i32.const 1)
             )
             (br $block6)
            )
           )
           (if
            (i32.eqz
             (i32.and
              (local.get $3)
              (i32.const 1)
             )
            )
            (then
             (br_if $block4
              (call_indirect $0 (type $0)
               (i32.load
                (local.get $1)
               )
               (i32.const 1052202)
               (i32.const 3)
               (i32.load offset=12
                (i32.load offset=4
                 (local.get $1)
                )
               )
              )
             )
            )
           )
           (i32.store8 offset=20
            (local.get $2)
            (i32.const 1)
           )
           (i64.store offset=32 align=4
            (local.get $2)
            (i64.load align=4
             (local.get $1)
            )
           )
           (i32.store offset=40
            (local.get $2)
            (local.tee $3
             (i32.add
              (local.get $2)
              (i32.const 20)
             )
            )
           )
           (br_if $block4
            (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
             (local.tee $1
              (i32.add
               (local.get $2)
               (i32.const 32)
              )
             )
             (i32.const 1056914)
             (i32.const 4)
            )
           )
           (br_if $block4
            (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
             (local.get $1)
             (i32.const 1052200)
             (i32.const 2)
            )
           )
           (br_if $block4
            (call_indirect $0 (type $0)
             (local.get $1)
             (i32.load offset=1058644
              (local.tee $0
               (i32.shl
                (i32.and
                 (local.get $0)
                 (i32.const 255)
                )
                (i32.const 2)
               )
              )
             )
             (i32.load offset=1058476
              (local.get $0)
             )
             (i32.load
              (i32.const 1052228)
             )
            )
           )
           (br_if $block5
            (i32.eqz
             (block (result i32)
              (local.set $scratch_9
               (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
                (local.get $1)
                (i32.const 1052205)
                (i32.const 2)
               )
              )
              (call $_RNvNtNtNtNtCset5xJoy1xWQ_3std3sys2io5error4wasi12error_string
               (local.get $3)
               (i32.load offset=4
                (local.get $2)
               )
              )
              (local.get $scratch_9)
             )
            )
           )
           (local.set $0
            (i32.const 1)
           )
           (br $block6)
          )
          (if
           (i32.eqz
            (i32.and
             (i32.load8_u offset=10
              (local.tee $1
               (i32.load
                (local.get $4)
               )
              )
             )
             (i32.const 128)
            )
           )
           (then
            (local.set $0
             (i32.const 1)
            )
            (br_if $block6
             (call_indirect $0 (type $0)
              (i32.load
               (local.get $1)
              )
              (i32.const 1052198)
              (i32.const 2)
              (i32.load offset=12
               (i32.load offset=4
                (local.get $1)
               )
              )
             )
            )
            (br_if $block6
             (call_indirect $0 (type $0)
              (i32.load
               (local.get $1)
              )
              (i32.const 1056918)
              (i32.const 7)
              (i32.load offset=12
               (i32.load offset=4
                (local.get $1)
               )
              )
             )
            )
            (br_if $block6
             (call_indirect $0 (type $0)
              (i32.load
               (local.get $1)
              )
              (i32.const 1052200)
              (i32.const 2)
              (i32.load offset=12
               (i32.load offset=4
                (local.get $1)
               )
              )
             )
            )
            (br_if $block6
             (call $_RNvXsh_NtCsdHhIpgkcIfN_4core3fmteNtB5_5Debug3fmt
              (i32.load offset=24
               (local.get $2)
              )
              (i32.load offset=28
               (local.get $2)
              )
              (i32.load
               (local.get $1)
              )
              (i32.load offset=4
               (local.get $1)
              )
             )
            )
            (br $block7)
           )
          )
          (i64.store offset=32 align=4
           (local.get $2)
           (i64.load align=4
            (local.get $1)
           )
          )
          (local.set $0
           (i32.const 1)
          )
          (i32.store8 offset=19
           (local.get $2)
           (i32.const 1)
          )
          (i32.store offset=40
           (local.get $2)
           (i32.add
            (local.get $2)
            (i32.const 19)
           )
          )
          (br_if $block6
           (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
            (local.tee $3
             (i32.add
              (local.get $2)
              (i32.const 32)
             )
            )
            (i32.const 1056918)
            (i32.const 7)
           )
          )
          (br_if $block6
           (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
            (local.get $3)
            (i32.const 1052200)
            (i32.const 2)
           )
          )
          (br_if $block8
           (i32.eqz
            (call $_RNvXsh_NtCsdHhIpgkcIfN_4core3fmteNtB5_5Debug3fmt
             (i32.load offset=24
              (local.get $2)
             )
             (i32.load offset=28
              (local.get $2)
             )
             (local.get $3)
             (i32.const 1052216)
            )
           )
          )
          (br $block6)
         )
         (call $_RNvNtNtNtNtCset5xJoy1xWQ_3std3sys2io5error4wasi12error_string
          (i32.add
           (local.get $2)
           (i32.const 20)
          )
          (i32.load offset=4
           (local.get $2)
          )
         )
         (local.set $0
          (i32.const 1)
         )
         (br $block6)
        )
        (br_if $block7
         (i32.eqz
          (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
           (i32.add
            (local.get $2)
            (i32.const 32)
           )
           (i32.const 1052205)
           (i32.const 2)
          )
         )
        )
        (br $block6)
       )
       (local.set $3
        (i32.load8_u offset=1
         (local.get $0)
        )
       )
       (local.set $0
        (i32.const 1)
       )
       (br_if $block9
        (call_indirect $0 (type $0)
         (i32.load
          (local.get $1)
         )
         (i32.const 1056925)
         (i32.const 4)
         (i32.load offset=12
          (i32.load offset=4
           (local.get $1)
          )
         )
        )
       )
       (block $block10
        (if
         (i32.eqz
          (i32.and
           (i32.load8_u offset=10
            (local.get $1)
           )
           (i32.const 128)
          )
         )
         (then
          (br_if $block9
           (call_indirect $0 (type $0)
            (i32.load
             (local.get $1)
            )
            (i32.const 1052207)
            (i32.const 1)
            (i32.load offset=12
             (i32.load offset=4
              (local.get $1)
             )
            )
           )
          )
          (br_if $block10
           (i32.eqz
            (call_indirect $0 (type $0)
             (i32.load
              (local.get $1)
             )
             (i32.load offset=1057972
              (local.tee $3
               (i32.shl
                (local.get $3)
                (i32.const 2)
               )
              )
             )
             (i32.load offset=1057804
              (local.get $3)
             )
             (i32.load offset=12
              (i32.load offset=4
               (local.get $1)
              )
             )
            )
           )
          )
          (br $block9)
         )
        )
        (br_if $block9
         (call_indirect $0 (type $0)
          (i32.load
           (local.get $1)
          )
          (i32.const 1052208)
          (i32.const 2)
          (i32.load offset=12
           (i32.load offset=4
            (local.get $1)
           )
          )
         )
        )
        (i32.store8 offset=20
         (local.get $2)
         (i32.const 1)
        )
        (i64.store offset=32 align=4
         (local.get $2)
         (i64.load align=4
          (local.get $1)
         )
        )
        (local.set $4
         (i32.load offset=1058140
          (local.tee $3
           (i32.shl
            (local.get $3)
            (i32.const 2)
           )
          )
         )
        )
        (local.set $3
         (i32.load offset=1058308
          (local.get $3)
         )
        )
        (i32.store offset=40
         (local.get $2)
         (i32.add
          (local.get $2)
          (i32.const 20)
         )
        )
        (br_if $block9
         (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
          (local.tee $5
           (i32.add
            (local.get $2)
            (i32.const 32)
           )
          )
          (local.get $3)
          (local.get $4)
         )
        )
        (br_if $block9
         (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
          (local.get $5)
          (i32.const 1052205)
          (i32.const 2)
         )
        )
       )
       (local.set $0
        (call_indirect $0 (type $0)
         (i32.load
          (local.get $1)
         )
         (i32.const 1052212)
         (i32.const 1)
         (i32.load offset=12
          (i32.load offset=4
           (local.get $1)
          )
         )
        )
       )
       (br $block9)
      )
      (local.set $3
       (i32.load offset=4
        (local.get $0)
       )
      )
      (if
       (call_indirect $0 (type $0)
        (i32.load
         (local.get $1)
        )
        (i32.const 1056929)
        (i32.const 5)
        (i32.load offset=12
         (i32.load offset=4
          (local.get $1)
         )
        )
       )
       (then
        (local.set $0
         (i32.const 1)
        )
        (br $block9)
       )
      )
      (block $block11
       (if
        (i32.eqz
         (i32.and
          (i32.load8_u offset=10
           (local.get $1)
          )
          (i32.const 128)
         )
        )
        (then
         (if
          (call_indirect $0 (type $0)
           (i32.load
            (local.get $1)
           )
           (i32.const 1052195)
           (i32.const 3)
           (i32.load offset=12
            (i32.load offset=4
             (local.get $1)
            )
           )
          )
          (then
           (local.set $0
            (i32.const 1)
           )
           (br $block9)
          )
         )
         (if
          (call_indirect $0 (type $0)
           (i32.load
            (local.get $1)
           )
           (i32.const 1056914)
           (i32.const 4)
           (i32.load offset=12
            (i32.load offset=4
             (local.get $1)
            )
           )
          )
          (then
           (local.set $0
            (i32.const 1)
           )
           (br $block9)
          )
         )
         (if
          (call_indirect $0 (type $0)
           (i32.load
            (local.get $1)
           )
           (i32.const 1052200)
           (i32.const 2)
           (i32.load offset=12
            (i32.load offset=4
             (local.get $1)
            )
           )
          )
          (then
           (local.set $0
            (i32.const 1)
           )
           (br $block9)
          )
         )
         (br_if $block11
          (i32.eqz
           (call_indirect $0 (type $0)
            (i32.load
             (local.get $1)
            )
            (i32.load offset=1058644
             (local.tee $0
              (i32.shl
               (i32.load8_u offset=8
                (local.get $3)
               )
               (i32.const 2)
              )
             )
            )
            (i32.load offset=1058476
             (local.get $0)
            )
            (i32.load offset=12
             (i32.load offset=4
              (local.get $1)
             )
            )
           )
          )
         )
         (local.set $0
          (i32.const 1)
         )
         (br $block9)
        )
       )
       (if
        (call_indirect $0 (type $0)
         (i32.load
          (local.get $1)
         )
         (i32.const 1052202)
         (i32.const 3)
         (i32.load offset=12
          (i32.load offset=4
           (local.get $1)
          )
         )
        )
        (then
         (local.set $0
          (i32.const 1)
         )
         (br $block9)
        )
       )
       (local.set $0
        (i32.const 1)
       )
       (i32.store8 offset=20
        (local.get $2)
        (i32.const 1)
       )
       (i64.store offset=32 align=4
        (local.get $2)
        (i64.load align=4
         (local.get $1)
        )
       )
       (i32.store offset=40
        (local.get $2)
        (i32.add
         (local.get $2)
         (i32.const 20)
        )
       )
       (br_if $block9
        (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
         (local.tee $4
          (i32.add
           (local.get $2)
           (i32.const 32)
          )
         )
         (i32.const 1056914)
         (i32.const 4)
        )
       )
       (br_if $block9
        (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
         (local.get $4)
         (i32.const 1052200)
         (i32.const 2)
        )
       )
       (br_if $block9
        (call_indirect $0 (type $0)
         (local.get $4)
         (i32.load offset=1058644
          (local.tee $5
           (i32.shl
            (i32.load8_u offset=8
             (local.get $3)
            )
            (i32.const 2)
           )
          )
         )
         (i32.load offset=1058476
          (local.get $5)
         )
         (i32.load
          (i32.const 1052228)
         )
        )
       )
       (br_if $block11
        (i32.eqz
         (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
          (local.get $4)
          (i32.const 1052205)
          (i32.const 2)
         )
        )
       )
       (br $block9)
      )
      (block $block13
       (block $block12
        (if
         (i32.eqz
          (i32.and
           (i32.load8_u offset=10
            (local.get $1)
           )
           (i32.const 128)
          )
         )
         (then
          (if
           (call_indirect $0 (type $0)
            (i32.load
             (local.get $1)
            )
            (i32.const 1052198)
            (i32.const 2)
            (i32.load offset=12
             (i32.load offset=4
              (local.get $1)
             )
            )
           )
           (then
            (local.set $0
             (i32.const 1)
            )
            (br $block9)
           )
          )
          (if
           (call_indirect $0 (type $0)
            (i32.load
             (local.get $1)
            )
            (i32.const 1056918)
            (i32.const 7)
            (i32.load offset=12
             (i32.load offset=4
              (local.get $1)
             )
            )
           )
           (then
            (local.set $0
             (i32.const 1)
            )
            (br $block9)
           )
          )
          (br_if $block12
           (i32.eqz
            (call_indirect $0 (type $0)
             (i32.load
              (local.get $1)
             )
             (i32.const 1052200)
             (i32.const 2)
             (i32.load offset=12
              (i32.load offset=4
               (local.get $1)
              )
             )
            )
           )
          )
          (local.set $0
           (i32.const 1)
          )
          (br $block9)
         )
        )
        (i64.store offset=32 align=4
         (local.get $2)
         (i64.load align=4
          (local.get $1)
         )
        )
        (local.set $0
         (i32.const 1)
        )
        (i32.store8 offset=20
         (local.get $2)
         (i32.const 1)
        )
        (i32.store offset=40
         (local.get $2)
         (i32.add
          (local.get $2)
          (i32.const 20)
         )
        )
        (br_if $block9
         (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
          (local.tee $4
           (i32.add
            (local.get $2)
            (i32.const 32)
           )
          )
          (i32.const 1056918)
          (i32.const 7)
         )
        )
        (br_if $block9
         (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
          (local.get $4)
          (i32.const 1052200)
          (i32.const 2)
         )
        )
        (br_if $block9
         (call $_RNvXsh_NtCsdHhIpgkcIfN_4core3fmteNtB5_5Debug3fmt
          (i32.load
           (local.get $3)
          )
          (i32.load offset=4
           (local.get $3)
          )
          (local.get $4)
          (i32.const 1052216)
         )
        )
        (br_if $block13
         (i32.eqz
          (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
           (local.get $4)
           (i32.const 1052205)
           (i32.const 2)
          )
         )
        )
        (br $block9)
       )
       (local.set $0
        (i32.const 1)
       )
       (br_if $block9
        (call $_RNvXsh_NtCsdHhIpgkcIfN_4core3fmteNtB5_5Debug3fmt
         (i32.load
          (local.get $3)
         )
         (i32.load offset=4
          (local.get $3)
         )
         (i32.load
          (local.get $1)
         )
         (i32.load offset=4
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (i32.and
         (i32.load8_u offset=10
          (local.get $1)
         )
         (i32.const 128)
        )
       )
       (then
        (local.set $0
         (call_indirect $0 (type $0)
          (i32.load
           (local.get $1)
          )
          (i32.const 1052214)
          (i32.const 2)
          (i32.load offset=12
           (i32.load offset=4
            (local.get $1)
           )
          )
         )
        )
        (br $block9)
       )
      )
      (local.set $0
       (call_indirect $0 (type $0)
        (i32.load
         (local.get $1)
        )
        (i32.const 1052211)
        (i32.const 1)
        (i32.load offset=12
         (i32.load offset=4
          (local.get $1)
         )
        )
       )
      )
      (br $block9)
     )
     (local.set $3
      (i32.load offset=4
       (local.get $0)
      )
     )
     (if
      (call_indirect $0 (type $0)
       (i32.load
        (local.get $1)
       )
       (i32.const 1056934)
       (i32.const 6)
       (i32.load offset=12
        (i32.load offset=4
         (local.get $1)
        )
       )
      )
      (then
       (local.set $0
        (i32.const 1)
       )
       (br $block9)
      )
     )
     (block $block14
      (if
       (i32.eqz
        (i32.and
         (i32.load8_u offset=10
          (local.get $1)
         )
         (i32.const 128)
        )
       )
       (then
        (if
         (call_indirect $0 (type $0)
          (i32.load
           (local.get $1)
          )
          (i32.const 1052195)
          (i32.const 3)
          (i32.load offset=12
           (i32.load offset=4
            (local.get $1)
           )
          )
         )
         (then
          (local.set $0
           (i32.const 1)
          )
          (br $block9)
         )
        )
        (if
         (call_indirect $0 (type $0)
          (i32.load
           (local.get $1)
          )
          (i32.const 1056914)
          (i32.const 4)
          (i32.load offset=12
           (i32.load offset=4
            (local.get $1)
           )
          )
         )
         (then
          (local.set $0
           (i32.const 1)
          )
          (br $block9)
         )
        )
        (if
         (call_indirect $0 (type $0)
          (i32.load
           (local.get $1)
          )
          (i32.const 1052200)
          (i32.const 2)
          (i32.load offset=12
           (i32.load offset=4
            (local.get $1)
           )
          )
         )
         (then
          (local.set $0
           (i32.const 1)
          )
          (br $block9)
         )
        )
        (br_if $block14
         (i32.eqz
          (call_indirect $0 (type $0)
           (i32.load
            (local.get $1)
           )
           (i32.load offset=1058644
            (local.tee $0
             (i32.shl
              (i32.load8_u offset=8
               (local.get $3)
              )
              (i32.const 2)
             )
            )
           )
           (i32.load offset=1058476
            (local.get $0)
           )
           (i32.load offset=12
            (i32.load offset=4
             (local.get $1)
            )
           )
          )
         )
        )
        (local.set $0
         (i32.const 1)
        )
        (br $block9)
       )
      )
      (if
       (call_indirect $0 (type $0)
        (i32.load
         (local.get $1)
        )
        (i32.const 1052202)
        (i32.const 3)
        (i32.load offset=12
         (i32.load offset=4
          (local.get $1)
         )
        )
       )
       (then
        (local.set $0
         (i32.const 1)
        )
        (br $block9)
       )
      )
      (local.set $0
       (i32.const 1)
      )
      (i32.store8 offset=20
       (local.get $2)
       (i32.const 1)
      )
      (i64.store offset=32 align=4
       (local.get $2)
       (i64.load align=4
        (local.get $1)
       )
      )
      (i32.store offset=40
       (local.get $2)
       (i32.add
        (local.get $2)
        (i32.const 20)
       )
      )
      (br_if $block9
       (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
        (local.tee $4
         (i32.add
          (local.get $2)
          (i32.const 32)
         )
        )
        (i32.const 1056914)
        (i32.const 4)
       )
      )
      (br_if $block9
       (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
        (local.get $4)
        (i32.const 1052200)
        (i32.const 2)
       )
      )
      (br_if $block9
       (call_indirect $0 (type $0)
        (local.get $4)
        (i32.load offset=1058644
         (local.tee $5
          (i32.shl
           (i32.load8_u offset=8
            (local.get $3)
           )
           (i32.const 2)
          )
         )
        )
        (i32.load offset=1058476
         (local.get $5)
        )
        (i32.load
         (i32.const 1052228)
        )
       )
      )
      (br_if $block14
       (i32.eqz
        (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
         (local.get $4)
         (i32.const 1052205)
         (i32.const 2)
        )
       )
      )
      (br $block9)
     )
     (block $block16
      (block $block15
       (if
        (i32.eqz
         (i32.and
          (i32.load8_u offset=10
           (local.get $1)
          )
          (i32.const 128)
         )
        )
        (then
         (if
          (call_indirect $0 (type $0)
           (i32.load
            (local.get $1)
           )
           (i32.const 1052198)
           (i32.const 2)
           (i32.load offset=12
            (i32.load offset=4
             (local.get $1)
            )
           )
          )
          (then
           (local.set $0
            (i32.const 1)
           )
           (br $block9)
          )
         )
         (if
          (call_indirect $0 (type $0)
           (i32.load
            (local.get $1)
           )
           (i32.const 1056940)
           (i32.const 5)
           (i32.load offset=12
            (i32.load offset=4
             (local.get $1)
            )
           )
          )
          (then
           (local.set $0
            (i32.const 1)
           )
           (br $block9)
          )
         )
         (br_if $block15
          (i32.eqz
           (call_indirect $0 (type $0)
            (i32.load
             (local.get $1)
            )
            (i32.const 1052200)
            (i32.const 2)
            (i32.load offset=12
             (i32.load offset=4
              (local.get $1)
             )
            )
           )
          )
         )
         (local.set $0
          (i32.const 1)
         )
         (br $block9)
        )
       )
       (local.set $6
        (i64.load offset=8 align=4
         (local.get $1)
        )
       )
       (local.set $7
        (i64.load align=4
         (local.get $1)
        )
       )
       (local.set $0
        (i32.const 1)
       )
       (i32.store8 offset=8
        (local.get $2)
        (i32.const 1)
       )
       (i64.store offset=20 align=4
        (local.get $2)
        (local.get $7)
       )
       (i64.store offset=40 align=4
        (local.get $2)
        (local.get $6)
       )
       (i32.store offset=36
        (local.get $2)
        (i32.const 1052216)
       )
       (i32.store offset=28
        (local.get $2)
        (i32.add
         (local.get $2)
         (i32.const 8)
        )
       )
       (i32.store offset=32
        (local.get $2)
        (local.tee $4
         (i32.add
          (local.get $2)
          (i32.const 20)
         )
        )
       )
       (br_if $block9
        (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
         (local.get $4)
         (i32.const 1056940)
         (i32.const 5)
        )
       )
       (br_if $block9
        (call $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write9write_str
         (local.get $4)
         (i32.const 1052200)
         (i32.const 2)
        )
       )
       (br_if $block9
        (call_indirect $0 (type $1)
         (i32.load
          (local.get $3)
         )
         (i32.add
          (local.get $2)
          (i32.const 32)
         )
         (i32.load offset=12
          (i32.load
           (i32.add
            (local.get $3)
            (i32.const 4)
           )
          )
         )
        )
       )
       (br_if $block16
        (i32.eqz
         (call_indirect $0 (type $0)
          (i32.load offset=32
           (local.get $2)
          )
          (i32.const 1052205)
          (i32.const 2)
          (i32.load offset=12
           (i32.load offset=36
            (local.get $2)
           )
          )
         )
        )
       )
       (br $block9)
      )
      (local.set $0
       (i32.const 1)
      )
      (br_if $block9
       (call_indirect $0 (type $1)
        (i32.load
         (local.get $3)
        )
        (local.get $1)
        (i32.load offset=12
         (i32.load
          (i32.add
           (local.get $3)
           (i32.const 4)
          )
         )
        )
       )
      )
     )
     (if
      (i32.eqz
       (i32.and
        (i32.load8_u offset=10
         (local.get $1)
        )
        (i32.const 128)
       )
      )
      (then
       (local.set $0
        (call_indirect $0 (type $0)
         (i32.load
          (local.get $1)
         )
         (i32.const 1052214)
         (i32.const 2)
         (i32.load offset=12
          (i32.load offset=4
           (local.get $1)
          )
         )
        )
       )
       (br $block9)
      )
     )
     (local.set $0
      (call_indirect $0 (type $0)
       (i32.load
        (local.get $1)
       )
       (i32.const 1052211)
       (i32.const 1)
       (i32.load offset=12
        (i32.load offset=4
         (local.get $1)
        )
       )
      )
     )
     (br $block9)
    )
    (if
     (i32.eqz
      (i32.and
       (i32.load8_u offset=10
        (local.get $1)
       )
       (i32.const 128)
      )
     )
     (then
      (local.set $0
       (call_indirect $0 (type $0)
        (i32.load
         (local.get $1)
        )
        (i32.const 1052214)
        (i32.const 2)
        (i32.load offset=12
         (i32.load offset=4
          (local.get $1)
         )
        )
       )
      )
      (br $block6)
     )
    )
    (local.set $0
     (call_indirect $0 (type $0)
      (i32.load
       (local.get $1)
      )
      (i32.const 1052211)
      (i32.const 1)
      (i32.load offset=12
       (i32.load offset=4
        (local.get $1)
       )
      )
     )
    )
   )
   (br_if $block9
    (i32.eqz
     (i32.load offset=20
      (local.get $2)
     )
    )
   )
   (call $dlfree
    (i32.load offset=24
     (local.get $2)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 48)
   )
  )
  (local.get $0)
 )
 (func $_RNvNtCsi9YzqDQQz2q_5alloc5alloc18handle_alloc_error (param $0 i32) (param $1 i32)
  (local $2 i32)
  (global.set $__stack_pointer
   (local.tee $0
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (local.set $2
   (i32.load8_u
    (i32.const 1061025)
   )
  )
  (i32.store8
   (i32.const 1061025)
   (i32.const 1)
  )
  (block $block4
   (if
    (i32.eqz
     (local.get $2)
    )
    (then
     (i32.store offset=12
      (local.get $0)
      (local.get $1)
     )
     (i64.store offset=16
      (local.get $0)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $0)
         (i32.const 12)
        )
       )
       (i64.const 17179869184)
      )
     )
     (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
      (i32.add
       (local.get $0)
       (i32.const 4)
      )
      (i32.add
       (local.get $0)
       (i32.const 31)
      )
      (i32.const 1050930)
      (i32.add
       (local.get $0)
       (i32.const 16)
      )
     )
     (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
      (i32.load8_u offset=4
       (local.get $0)
      )
      (i32.load offset=8
       (local.get $0)
      )
     )
     (call $_RNvNtNtCset5xJoy1xWQ_3std3sys9backtrace4lock)
     (block $block2
      (block $block1
       (block $block
        (block $block3
         (br_table $block $block1 $block2 $block3
          (i32.sub
           (i32.and
            (call $_RNvNtCset5xJoy1xWQ_3std5panic19get_backtrace_style)
            (i32.const 255)
           )
           (i32.const 1)
          )
         )
        )
        (call $_RNvMNtNtCset5xJoy1xWQ_3std3sys9backtraceNtB2_13BacktraceLock5print
         (i32.add
          (local.get $0)
          (i32.const 16)
         )
         (i32.add
          (local.get $0)
          (i32.const 31)
         )
         (i32.const 0)
        )
        (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
         (i32.load8_u offset=16
          (local.get $0)
         )
         (i32.load offset=20
          (local.get $0)
         )
        )
        (br $block2)
       )
       (call $_RNvMNtNtCset5xJoy1xWQ_3std3sys9backtraceNtB2_13BacktraceLock5print
        (i32.add
         (local.get $0)
         (i32.const 16)
        )
        (i32.add
         (local.get $0)
         (i32.const 31)
        )
        (i32.const 1)
       )
       (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
        (i32.load8_u offset=16
         (local.get $0)
        )
        (i32.load offset=20
         (local.get $0)
        )
       )
       (br $block2)
      )
      (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
       (i32.add
        (local.get $0)
        (i32.const 16)
       )
       (i32.add
        (local.get $0)
        (i32.const 31)
       )
       (i32.const 1055136)
       (i32.const 157)
      )
      (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
       (i32.load8_u offset=16
        (local.get $0)
       )
       (i32.load offset=20
        (local.get $0)
       )
      )
     )
     (i32.store8
      (i32.const 1061056)
      (i32.const 0)
     )
     (br $block4)
    )
   )
   (i32.store offset=12
    (local.get $0)
    (local.get $1)
   )
   (i64.store offset=16
    (local.get $0)
    (i64.or
     (i64.extend_i32_u
      (i32.add
       (local.get $0)
       (i32.const 12)
      )
     )
     (i64.const 17179869184)
    )
   )
   (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
    (i32.add
     (local.get $0)
     (i32.const 4)
    )
    (i32.add
     (local.get $0)
     (i32.const 31)
    )
    (i32.const 1050834)
    (i32.add
     (local.get $0)
     (i32.const 16)
    )
   )
   (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
    (i32.load8_u offset=4
     (local.get $0)
    )
    (i32.load offset=8
     (local.get $0)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $0)
    (i32.const 32)
   )
  )
  (unreachable)
 )
 (func $_RNvXs0_NvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBd_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB12_6marker4SyncNtB1z_4SendEL_EINtNtB12_7convert4FromNtNtBf_6string6StringE4fromNtB5_11StringErrorNtNtB12_3fmt5Debug3fmt (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvXsh_NtCsdHhIpgkcIfN_4core3fmteNtB5_5Debug3fmt
   (i32.load offset=4
    (local.get $0)
   )
   (i32.load offset=8
    (local.get $0)
   )
   (i32.load
    (local.get $1)
   )
   (i32.load offset=4
    (local.get $1)
   )
  )
 )
 (func $_RNvXsh_NtCsdHhIpgkcIfN_4core3fmteNtB5_5Debug3fmt (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (result i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (global.set $__stack_pointer
   (local.tee $11
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $12
   (i32.const 1)
  )
  (block $block
   (br_if $block
    (call_indirect $0 (type $1)
     (local.get $2)
     (i32.const 34)
     (local.tee $13
      (i32.load offset=16
       (local.get $3)
      )
     )
    )
   )
   (block $block13
    (block $block1
     (if
      (i32.eqz
       (local.get $1)
      )
      (then
       (local.set $1
        (i32.const 0)
       )
       (br $block1)
      )
     )
     (local.set $6
      (local.get $1)
     )
     (local.set $10
      (local.get $0)
     )
     (loop $label1
      (local.set $14
       (i32.add
        (local.get $6)
        (local.get $10)
       )
      )
      (local.set $4
       (i32.const 0)
      )
      (block $block3
       (block $block2
        (loop $label
         (br_if $block2
          (i32.lt_u
           (i32.and
            (i32.sub
             (local.tee $9
              (i32.load8_u
               (local.tee $8
                (i32.add
                 (local.get $4)
                 (local.get $10)
                )
               )
              )
             )
             (i32.const 127)
            )
            (i32.const 255)
           )
           (i32.const 161)
          )
         )
         (br_if $block2
          (i32.eq
           (local.get $9)
           (i32.const 34)
          )
         )
         (br_if $block2
          (i32.eq
           (local.get $9)
           (i32.const 92)
          )
         )
         (br_if $label
          (i32.ne
           (local.get $6)
           (local.tee $4
            (i32.add
             (local.get $4)
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.set $7
         (i32.add
          (local.get $6)
          (local.get $7)
         )
        )
        (br $block3)
       )
       (local.set $10
        (block $block4 (result i32)
         (if
          (i32.ge_s
           (local.tee $6
            (i32.load8_s
             (local.get $8)
            )
           )
           (i32.const 0)
          )
          (then
           (local.set $6
            (i32.and
             (local.get $6)
             (i32.const 255)
            )
           )
           (br $block4
            (i32.add
             (local.get $8)
             (i32.const 1)
            )
           )
          )
         )
         (local.set $9
          (i32.and
           (i32.load8_u offset=1
            (local.get $8)
           )
           (i32.const 63)
          )
         )
         (local.set $10
          (i32.and
           (local.get $6)
           (i32.const 31)
          )
         )
         (if
          (i32.le_u
           (local.get $6)
           (i32.const -33)
          )
          (then
           (local.set $6
            (i32.or
             (i32.shl
              (local.get $10)
              (i32.const 6)
             )
             (local.get $9)
            )
           )
           (br $block4
            (i32.add
             (local.get $8)
             (i32.const 2)
            )
           )
          )
         )
         (local.set $9
          (i32.or
           (i32.and
            (i32.load8_u offset=2
             (local.get $8)
            )
            (i32.const 63)
           )
           (i32.shl
            (local.get $9)
            (i32.const 6)
           )
          )
         )
         (if
          (i32.lt_u
           (local.get $6)
           (i32.const -16)
          )
          (then
           (local.set $6
            (i32.or
             (local.get $9)
             (i32.shl
              (local.get $10)
              (i32.const 12)
             )
            )
           )
           (br $block4
            (i32.add
             (local.get $8)
             (i32.const 3)
            )
           )
          )
         )
         (local.set $6
          (i32.or
           (i32.and
            (i32.shl
             (local.get $10)
             (i32.const 18)
            )
            (i32.const 1835008)
           )
           (i32.or
            (i32.and
             (i32.load8_u offset=3
              (local.get $8)
             )
             (i32.const 63)
            )
            (i32.shl
             (local.get $9)
             (i32.const 6)
            )
           )
          )
         )
         (i32.add
          (local.get $8)
          (i32.const 4)
         )
        )
       )
       (local.set $4
        (i32.add
         (local.get $4)
         (local.get $7)
        )
       )
       (call $_RNvMNtNtCsdHhIpgkcIfN_4core4char7methodsc16escape_debug_ext
        (local.get $11)
        (local.get $6)
        (i32.const 65537)
       )
       (block $block5
        (br_if $block5
         (i32.eq
          (i32.and
           (local.tee $9
            (i32.sub
             (local.tee $7
              (i32.load8_u offset=13
               (local.get $11)
              )
             )
             (local.tee $8
              (i32.load8_u offset=12
               (local.get $11)
              )
             )
            )
           )
           (i32.const 255)
          )
          (i32.const 1)
         )
        )
        (block $block10
         (block $block9
          (block $block6
           (br_if $block6
            (i32.lt_u
             (local.get $4)
             (local.get $5)
            )
           )
           (block $block7
            (br_if $block7
             (i32.eqz
              (local.get $5)
             )
            )
            (if
             (i32.le_u
              (local.get $1)
              (local.get $5)
             )
             (then
              (br_if $block6
               (i32.ne
                (local.get $1)
                (local.get $5)
               )
              )
              (br $block7)
             )
            )
            (br_if $block6
             (i32.le_s
              (i32.load8_s
               (i32.add
                (local.get $0)
                (local.get $5)
               )
              )
              (i32.const -65)
             )
            )
           )
           (block $block8
            (br_if $block8
             (i32.eqz
              (local.get $4)
             )
            )
            (if
             (i32.le_u
              (local.get $1)
              (local.get $4)
             )
             (then
              (br_if $block8
               (i32.eq
                (local.get $1)
                (local.get $4)
               )
              )
              (br $block6)
             )
            )
            (br_if $block6
             (i32.le_s
              (i32.load8_s
               (i32.add
                (local.get $0)
                (local.get $4)
               )
              )
              (i32.const -65)
             )
            )
           )
           (br_if $block9
            (i32.eqz
             (call_indirect $0 (type $0)
              (local.get $2)
              (i32.add
               (local.get $0)
               (local.get $5)
              )
              (i32.sub
               (local.get $4)
               (local.get $5)
              )
              (local.tee $5
               (i32.load offset=12
                (local.get $3)
               )
              )
             )
            )
           )
           (br $block10)
          )
          (call $_RNvNtCsdHhIpgkcIfN_4core3str16slice_error_fail
           (local.get $0)
           (local.get $1)
           (local.get $5)
           (local.get $4)
           (i32.const 1054544)
          )
          (unreachable)
         )
         (block $block11
          (if
           (i32.ge_u
            (local.get $7)
            (i32.const 129)
           )
           (then
            (br_if $block10
             (call_indirect $0 (type $1)
              (local.get $2)
              (i32.load
               (local.get $11)
              )
              (local.get $13)
             )
            )
            (br $block11)
           )
          )
          (br_if $block10
           (call_indirect $0 (type $0)
            (local.get $2)
            (i32.add
             (local.get $8)
             (local.get $11)
            )
            (local.get $9)
            (local.get $5)
           )
          )
         )
         (if
          (i32.lt_u
           (local.get $6)
           (i32.const 128)
          )
          (then
           (local.set $5
            (i32.add
             (local.get $4)
             (i32.const 1)
            )
           )
           (br $block5)
          )
         )
         (if
          (i32.lt_u
           (local.get $6)
           (i32.const 2048)
          )
          (then
           (local.set $5
            (i32.add
             (local.get $4)
             (i32.const 2)
            )
           )
           (br $block5)
          )
         )
         (local.set $5
          (i32.add
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $6)
             (i32.const 65536)
            )
           )
           (local.get $4)
          )
         )
         (br $block5)
        )
        (br $block)
       )
       (local.set $7
        (i32.add
         (block $block12 (result i32)
          (drop
           (br_if $block12
            (i32.const 1)
            (i32.lt_u
             (local.get $6)
             (i32.const 128)
            )
           )
          )
          (drop
           (br_if $block12
            (i32.const 2)
            (i32.lt_u
             (local.get $6)
             (i32.const 2048)
            )
           )
          )
          (select
           (i32.const 3)
           (i32.const 4)
           (i32.lt_u
            (local.get $6)
            (i32.const 65536)
           )
          )
         )
         (local.get $4)
        )
       )
       (br_if $label1
        (local.tee $6
         (i32.sub
          (local.get $14)
          (local.get $10)
         )
        )
       )
      )
     )
     (br_if $block13
      (i32.gt_u
       (local.get $5)
       (local.get $7)
      )
     )
     (local.set $4
      (i32.const 0)
     )
     (block $block14
      (br_if $block14
       (i32.eqz
        (local.get $5)
       )
      )
      (if
       (i32.le_u
        (local.get $1)
        (local.get $5)
       )
       (then
        (br_if $block13
         (i32.ne
          (local.get $5)
          (local.tee $4
           (local.get $1)
          )
         )
        )
        (br $block14)
       )
      )
      (br_if $block13
       (i32.le_s
        (i32.load8_s
         (i32.add
          (local.tee $4
           (local.get $5)
          )
          (local.get $0)
         )
        )
        (i32.const -65)
       )
      )
     )
     (if
      (i32.eqz
       (local.get $7)
      )
      (then
       (local.set $1
        (i32.const 0)
       )
       (br $block1)
      )
     )
     (if
      (i32.le_u
       (local.get $1)
       (local.get $7)
      )
      (then
       (br_if $block1
        (i32.eq
         (local.get $1)
         (local.get $7)
        )
       )
       (local.set $5
        (local.get $4)
       )
       (br $block13)
      )
     )
     (if
      (i32.le_s
       (i32.load8_s
        (i32.add
         (local.get $0)
         (local.get $7)
        )
       )
       (i32.const -65)
      )
      (then
       (local.set $5
        (local.get $4)
       )
       (br $block13)
      )
     )
     (local.set $1
      (local.get $7)
     )
    )
    (br_if $block
     (call_indirect $0 (type $0)
      (local.get $2)
      (i32.add
       (local.get $0)
       (local.get $4)
      )
      (i32.sub
       (local.get $1)
       (local.get $4)
      )
      (i32.load offset=12
       (local.get $3)
      )
     )
    )
    (local.set $12
     (call_indirect $0 (type $1)
      (local.get $2)
      (i32.const 34)
      (local.get $13)
     )
    )
    (br $block)
   )
   (call $_RNvNtCsdHhIpgkcIfN_4core3str16slice_error_fail
    (local.get $0)
    (local.get $1)
    (local.get $5)
    (local.get $7)
    (i32.const 1054560)
   )
   (unreachable)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $11)
    (i32.const 16)
   )
  )
  (local.get $12)
 )
 (func $_RNvXs_NvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBc_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4fromNtB4_11StringErrorNtNtB11_3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter3pad
   (local.get $1)
   (i32.load offset=4
    (local.get $0)
   )
   (i32.load offset=8
    (local.get $0)
   )
  )
 )
 (func $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter3pad (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (block $block9
   (block $block
    (br_if $block
     (i32.eqz
      (i32.and
       (local.tee $7
        (i32.load offset=8
         (local.get $0)
        )
       )
       (i32.const 402653184)
      )
     )
    )
    (block $block3
     (block $block4
      (block $block2
       (block $block1
        (if
         (i32.and
          (local.get $7)
          (i32.const 268435456)
         )
         (then
          (br_if $block1
           (local.tee $4
            (i32.load16_u offset=14
             (local.get $0)
            )
           )
          )
          (local.set $2
           (i32.const 0)
          )
          (br $block2)
         )
        )
        (if
         (i32.ge_u
          (local.get $2)
          (i32.const 16)
         )
         (then
          (local.set $4
           (call $_RNvNtNtCsdHhIpgkcIfN_4core3str5count14do_count_chars
            (local.get $1)
            (local.get $2)
           )
          )
          (br $block3)
         )
        )
        (if
         (i32.eqz
          (local.get $2)
         )
         (then
          (br $block3)
         )
        )
        (local.set $5
         (i32.and
          (local.get $2)
          (i32.const 3)
         )
        )
        (if
         (i32.ge_u
          (local.get $2)
          (i32.const 4)
         )
         (then
          (local.set $8
           (i32.and
            (local.get $2)
            (i32.const 12)
           )
          )
          (loop $label
           (local.set $4
            (i32.add
             (i32.add
              (i32.add
               (i32.add
                (local.get $4)
                (i32.gt_s
                 (i32.load8_s
                  (local.tee $6
                   (i32.add
                    (local.get $1)
                    (local.get $3)
                   )
                  )
                 )
                 (i32.const -65)
                )
               )
               (i32.gt_s
                (i32.load8_s
                 (i32.add
                  (local.get $6)
                  (i32.const 1)
                 )
                )
                (i32.const -65)
               )
              )
              (i32.gt_s
               (i32.load8_s
                (i32.add
                 (local.get $6)
                 (i32.const 2)
                )
               )
               (i32.const -65)
              )
             )
             (i32.gt_s
              (i32.load8_s
               (i32.add
                (local.get $6)
                (i32.const 3)
               )
              )
              (i32.const -65)
             )
            )
           )
           (br_if $label
            (i32.ne
             (local.get $8)
             (local.tee $3
              (i32.add
               (local.get $3)
               (i32.const 4)
              )
             )
            )
           )
          )
          (br_if $block3
           (i32.eqz
            (local.get $5)
           )
          )
         )
        )
        (local.set $3
         (i32.add
          (local.get $1)
          (local.get $3)
         )
        )
        (loop $label1
         (local.set $4
          (i32.add
           (local.get $4)
           (i32.gt_s
            (i32.load8_s
             (local.get $3)
            )
            (i32.const -65)
           )
          )
         )
         (local.set $3
          (i32.add
           (local.get $3)
           (i32.const 1)
          )
         )
         (br_if $label1
          (local.tee $5
           (i32.sub
            (local.get $5)
            (i32.const 1)
           )
          )
         )
        )
        (br $block3)
       )
       (local.set $8
        (i32.add
         (local.get $1)
         (local.get $2)
        )
       )
       (local.set $2
        (i32.const 0)
       )
       (local.set $3
        (local.get $1)
       )
       (local.set $5
        (local.get $4)
       )
       (loop $label2
        (br_if $block4
         (i32.eq
          (local.tee $6
           (local.get $3)
          )
          (local.get $8)
         )
        )
        (local.set $2
         (i32.add
          (i32.sub
           (local.tee $3
            (block $block5 (result i32)
             (drop
              (br_if $block5
               (i32.add
                (local.get $6)
                (i32.const 1)
               )
               (i32.ge_s
                (local.tee $3
                 (i32.load8_s
                  (local.get $6)
                 )
                )
                (i32.const 0)
               )
              )
             )
             (drop
              (br_if $block5
               (i32.add
                (local.get $6)
                (i32.const 2)
               )
               (i32.lt_u
                (local.get $3)
                (i32.const -32)
               )
              )
             )
             (i32.add
              (local.get $6)
              (select
               (i32.const 4)
               (i32.const 3)
               (i32.gt_u
                (local.get $3)
                (i32.const -17)
               )
              )
             )
            )
           )
           (local.get $6)
          )
          (local.get $2)
         )
        )
        (br_if $label2
         (local.tee $5
          (i32.sub
           (local.get $5)
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.set $5
       (i32.const 0)
      )
     )
     (local.set $4
      (i32.sub
       (local.get $4)
       (local.get $5)
      )
     )
    )
    (br_if $block
     (i32.ge_u
      (local.get $4)
      (local.tee $3
       (i32.load16_u offset=12
        (local.get $0)
       )
      )
     )
    )
    (local.set $6
     (i32.sub
      (local.get $3)
      (local.get $4)
     )
    )
    (local.set $4
     (i32.const 0)
    )
    (local.set $5
     (i32.const 0)
    )
    (block $block8
     (block $block7
      (block $block6
       (br_table $block6 $block7 $block8
        (i32.sub
         (i32.and
          (i32.shr_u
           (local.get $7)
           (i32.const 29)
          )
          (i32.const 3)
         )
         (i32.const 1)
        )
       )
      )
      (local.set $5
       (local.get $6)
      )
      (br $block8)
     )
     (local.set $5
      (i32.shr_u
       (i32.and
        (local.get $6)
        (i32.const 65534)
       )
       (i32.const 1)
      )
     )
    )
    (local.set $8
     (i32.and
      (local.get $7)
      (i32.const 2097151)
     )
    )
    (local.set $7
     (i32.load offset=4
      (local.get $0)
     )
    )
    (local.set $0
     (i32.load
      (local.get $0)
     )
    )
    (loop $label3
     (if
      (i32.lt_u
       (i32.and
        (local.get $4)
        (i32.const 65535)
       )
       (i32.and
        (local.get $5)
        (i32.const 65535)
       )
      )
      (then
       (local.set $3
        (i32.const 1)
       )
       (local.set $4
        (i32.add
         (local.get $4)
         (i32.const 1)
        )
       )
       (br_if $label3
        (i32.eqz
         (call_indirect $0 (type $1)
          (local.get $0)
          (local.get $8)
          (i32.load offset=16
           (local.get $7)
          )
         )
        )
       )
       (br $block9)
      )
     )
    )
    (local.set $3
     (i32.const 1)
    )
    (br_if $block9
     (call_indirect $0 (type $0)
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (i32.load offset=12
       (local.get $7)
      )
     )
    )
    (local.set $1
     (i32.and
      (i32.sub
       (local.get $6)
       (local.get $5)
      )
      (i32.const 65535)
     )
    )
    (local.set $4
     (i32.const 0)
    )
    (loop $label4
     (if
      (i32.le_u
       (local.get $1)
       (i32.and
        (local.get $4)
        (i32.const 65535)
       )
      )
      (then
       (return
        (i32.const 0)
       )
      )
     )
     (local.set $4
      (i32.add
       (local.get $4)
       (i32.const 1)
      )
     )
     (br_if $label4
      (i32.eqz
       (call_indirect $0 (type $1)
        (local.get $0)
        (local.get $8)
        (i32.load offset=16
         (local.get $7)
        )
       )
      )
     )
    )
    (br $block9)
   )
   (local.set $3
    (call_indirect $0 (type $0)
     (i32.load
      (local.get $0)
     )
     (local.get $1)
     (local.get $2)
     (i32.load offset=12
      (i32.load offset=4
       (local.get $0)
      )
     )
    )
   )
  )
  (local.get $3)
 )
 (func $_RNvXs1g_NtCsdHhIpgkcIfN_4core3fmtRDNtB6_5DebugEL_Bx_3fmtB8_ (param $0 i32) (param $1 i32) (result i32)
  (call_indirect $0 (type $1)
   (i32.load
    (local.get $0)
   )
   (local.get $1)
   (i32.load offset=12
    (i32.load offset=4
     (local.get $0)
    )
   )
  )
 )
 (func $_RNvXs8_NtCsdHhIpgkcIfN_4core3fmtNtB5_9ArgumentsNtB5_7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
   (i32.load
    (local.get $1)
   )
   (i32.load offset=4
    (local.get $1)
   )
   (i32.load
    (local.get $0)
   )
   (i32.load offset=4
    (local.get $0)
   )
  )
 )
 (func $_RNvXs0_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_10PadAdapterNtB7_5Write10write_char (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local.set $2
   (i32.load offset=4
    (local.get $0)
   )
  )
  (local.set $3
   (i32.load
    (local.get $0)
   )
  )
  (block $block
   (br_if $block
    (i32.eqz
     (i32.load8_u
      (local.tee $0
       (i32.load offset=8
        (local.get $0)
       )
      )
     )
    )
   )
   (br_if $block
    (i32.eqz
     (call_indirect $0 (type $0)
      (local.get $3)
      (i32.const 1054466)
      (i32.const 4)
      (i32.load offset=12
       (local.get $2)
      )
     )
    )
   )
   (return
    (i32.const 1)
   )
  )
  (i32.store8
   (local.get $0)
   (i32.eq
    (local.get $1)
    (i32.const 10)
   )
  )
  (call_indirect $0 (type $1)
   (local.get $3)
   (local.get $1)
   (i32.load offset=16
    (local.get $2)
   )
  )
 )
 (func $_RNvYNtNtNtCsdHhIpgkcIfN_4core3fmt8builders10PadAdapterNtB6_5Write9write_fmtB8_ (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
   (local.get $0)
   (i32.const 1052216)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $_RNvNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB7_9Formatter12pad_integral12write_prefix (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (result i32)
  (block $block
   (br_if $block
    (i32.eq
     (local.get $2)
     (i32.const 1114112)
    )
   )
   (br_if $block
    (i32.eqz
     (call_indirect $0 (type $1)
      (local.get $0)
      (local.get $2)
      (i32.load offset=16
       (local.get $1)
      )
     )
    )
   )
   (return
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (return
     (i32.const 0)
    )
   )
  )
  (call_indirect $0 (type $0)
   (local.get $0)
   (local.get $3)
   (local.get $4)
   (i32.load offset=12
    (local.get $1)
   )
  )
 )
 (func $_RNvXsd_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3impyNtB9_7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (local.set $2
   (i32.const 20)
  )
  (local.set $6
   (local.tee $7
    (i64.load
     (local.get $0)
    )
   )
  )
  (if
   (i64.ge_u
    (local.get $7)
    (i64.const 1000)
   )
   (then
    (loop $label
     (i32.store16 align=1
      (i32.sub
       (local.tee $0
        (i32.add
         (i32.add
          (local.get $3)
          (i32.const 12)
         )
         (local.get $2)
        )
       )
       (i32.const 4)
      )
      (i32.load16_u offset=1052290 align=1
       (i32.shl
        (local.tee $5
         (i32.div_u
          (i32.and
           (local.tee $4
            (i32.wrap_i64
             (i64.sub
              (local.tee $8
               (local.get $6)
              )
              (i64.mul
               (local.tee $6
                (i64.div_u
                 (local.get $6)
                 (i64.const 10000)
                )
               )
               (i64.const 10000)
              )
             )
            )
           )
           (i32.const 65535)
          )
          (i32.const 100)
         )
        )
        (i32.const 1)
       )
      )
     )
     (i32.store16 align=1
      (i32.sub
       (local.get $0)
       (i32.const 2)
      )
      (i32.load16_u offset=1052290 align=1
       (i32.shl
        (i32.and
         (i32.sub
          (local.get $4)
          (i32.mul
           (local.get $5)
           (i32.const 100)
          )
         )
         (i32.const 65535)
        )
        (i32.const 1)
       )
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (i32.const 4)
      )
     )
     (br_if $label
      (i64.gt_u
       (local.get $8)
       (i64.const 9999999)
      )
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 9)
   )
   (then
    (i32.store16 align=1
     (i32.add
      (local.tee $2
       (i32.sub
        (local.get $2)
        (i32.const 2)
       )
      )
      (i32.add
       (local.get $3)
       (i32.const 12)
      )
     )
     (i32.load16_u offset=1052290 align=1
      (i32.shl
       (i32.and
        (i32.sub
         (local.tee $0
          (i32.wrap_i64
           (local.get $6)
          )
         )
         (i32.mul
          (local.tee $0
           (i32.div_u
            (i32.and
             (local.get $0)
             (i32.const 65535)
            )
            (i32.const 100)
           )
          )
          (i32.const 100)
         )
        )
        (i32.const 65535)
       )
       (i32.const 1)
      )
     )
    )
    (local.set $6
     (i64.extend_i32_u
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (i32.and
     (i64.eqz
      (local.get $6)
     )
     (i64.ne
      (local.get $7)
      (i64.const 0)
     )
    )
   )
   (then
    (i32.store8
     (i32.add
      (local.tee $2
       (i32.sub
        (local.get $2)
        (i32.const 1)
       )
      )
      (i32.add
       (local.get $3)
       (i32.const 12)
      )
     )
     (i32.load8_u offset=1052291
      (i32.shl
       (i32.wrap_i64
        (local.get $6)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
  (local.set $scratch
   (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
    (local.get $1)
    (i32.const 1)
    (i32.const 1)
    (i32.const 0)
    (i32.add
     (i32.add
      (local.get $3)
      (i32.const 12)
     )
     (local.get $2)
    )
    (i32.sub
     (i32.const 20)
     (local.get $2)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 32)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvMNtNtCsdHhIpgkcIfN_4core4char7methodsc16escape_debug_ext (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (i32.store8 offset=13
   (local.get $0)
   (block $block17 (result i32)
    (block $block16
     (block $block10
      (block $block11
       (block $block12
        (block $block13
         (block $block5
          (block $block9
           (block $block6
            (block $block8
             (block $block3
              (block $block4
               (block $block2
                (block $block
                 (block $block1
                  (block $block7
                   (br_table $block $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block2 $block3 $block1 $block1 $block4 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block5 $block1 $block1 $block1 $block1 $block6 $block7
                    (local.get $1)
                   )
                  )
                  (br_if $block8
                   (i32.eq
                    (local.get $1)
                    (i32.const 92)
                   )
                  )
                 )
                 (br_if $block9
                  (i32.and
                   (i32.and
                    (local.get $2)
                    (i32.const 1)
                   )
                   (i32.gt_u
                    (local.get $1)
                    (i32.const 767)
                   )
                  )
                 )
                 (br_if $block10
                  (i32.lt_u
                   (local.get $1)
                   (i32.const 32)
                  )
                 )
                 (br_if $block11
                  (i32.lt_u
                   (local.get $1)
                   (i32.const 127)
                  )
                 )
                 (br $block12)
                )
                (i64.store offset=2 align=2
                 (local.get $0)
                 (i64.const 0)
                )
                (i32.store16
                 (local.get $0)
                 (i32.const 12380)
                )
                (br $block13)
               )
               (i64.store offset=2 align=2
                (local.get $0)
                (i64.const 0)
               )
               (i32.store16
                (local.get $0)
                (i32.const 29788)
               )
               (br $block13)
              )
              (i64.store offset=2 align=2
               (local.get $0)
               (i64.const 0)
              )
              (i32.store16
               (local.get $0)
               (i32.const 29276)
              )
              (br $block13)
             )
             (i64.store offset=2 align=2
              (local.get $0)
              (i64.const 0)
             )
             (i32.store16
              (local.get $0)
              (i32.const 28252)
             )
             (br $block13)
            )
            (i64.store offset=2 align=2
             (local.get $0)
             (i64.const 0)
            )
            (i32.store16
             (local.get $0)
             (i32.const 23644)
            )
            (br $block13)
           )
           (br_if $block11
            (i32.eqz
             (i32.and
              (local.get $2)
              (i32.const 256)
             )
            )
           )
           (i64.store offset=2 align=2
            (local.get $0)
            (i64.const 0)
           )
           (i32.store16
            (local.get $0)
            (i32.const 10076)
           )
           (br $block13)
          )
          (local.set $8
           (i32.add
            (local.tee $2
             (i32.shl
              (local.tee $5
               (i32.add
                (i32.add
                 (i32.eq
                  (local.tee $5
                   (i32.shl
                    (i32.load offset=1054332
                     (i32.shl
                      (local.tee $3
                       (select
                        (local.tee $3
                         (select
                          (local.tee $3
                           (select
                            (local.tee $3
                             (select
                              (local.tee $3
                               (select
                                (local.tee $2
                                 (select
                                  (i32.const 16)
                                  (i32.const 0)
                                  (i32.ge_u
                                   (local.get $1)
                                   (i32.const 69291)
                                  )
                                 )
                                )
                                (local.tee $3
                                 (i32.or
                                  (local.get $2)
                                  (i32.const 8)
                                 )
                                )
                                (i32.lt_u
                                 (local.tee $2
                                  (i32.shl
                                   (local.get $1)
                                   (i32.const 11)
                                  )
                                 )
                                 (i32.shl
                                  (i32.load offset=1054332
                                   (i32.shl
                                    (local.get $3)
                                    (i32.const 2)
                                   )
                                  )
                                  (i32.const 11)
                                 )
                                )
                               )
                              )
                              (local.tee $3
                               (i32.or
                                (local.get $3)
                                (i32.const 4)
                               )
                              )
                              (i32.gt_u
                               (i32.shl
                                (i32.load offset=1054332
                                 (i32.shl
                                  (local.get $3)
                                  (i32.const 2)
                                 )
                                )
                                (i32.const 11)
                               )
                               (local.get $2)
                              )
                             )
                            )
                            (local.tee $3
                             (i32.or
                              (local.get $3)
                              (i32.const 2)
                             )
                            )
                            (i32.gt_u
                             (i32.shl
                              (i32.load offset=1054332
                               (i32.shl
                                (local.get $3)
                                (i32.const 2)
                               )
                              )
                              (i32.const 11)
                             )
                             (local.get $2)
                            )
                           )
                          )
                          (local.tee $3
                           (i32.add
                            (local.get $3)
                            (i32.const 1)
                           )
                          )
                          (i32.gt_u
                           (i32.shl
                            (i32.load offset=1054332
                             (i32.shl
                              (local.get $3)
                              (i32.const 2)
                             )
                            )
                            (i32.const 11)
                           )
                           (local.get $2)
                          )
                         )
                        )
                        (local.tee $3
                         (i32.add
                          (local.get $3)
                          (i32.const 1)
                         )
                        )
                        (i32.gt_u
                         (i32.shl
                          (i32.load offset=1054332
                           (i32.shl
                            (local.get $3)
                            (i32.const 2)
                           )
                          )
                          (i32.const 11)
                         )
                         (local.get $2)
                        )
                       )
                      )
                      (i32.const 2)
                     )
                    )
                    (i32.const 11)
                   )
                  )
                  (local.get $2)
                 )
                 (i32.gt_u
                  (local.get $2)
                  (local.get $5)
                 )
                )
                (local.get $3)
               )
              )
              (i32.const 2)
             )
            )
            (i32.const 1054332)
           )
          )
          (local.set $2
           (i32.shr_u
            (i32.load offset=1054332
             (local.get $2)
            )
            (i32.const 21)
           )
          )
          (local.set $3
           (i32.const 767)
          )
          (block $block14
           (if
            (i32.le_u
             (local.get $5)
             (i32.const 31)
            )
            (then
             (local.set $3
              (i32.shr_u
               (i32.load offset=4
                (local.get $8)
               )
               (i32.const 21)
              )
             )
             (br_if $block14
              (i32.eqz
               (local.get $5)
              )
             )
            )
           )
           (local.set $7
            (i32.and
             (i32.load
              (i32.sub
               (local.get $8)
               (i32.const 4)
              )
             )
             (i32.const 2097151)
            )
           )
          )
          (block $block15
           (br_if $block15
            (i32.eqz
             (i32.add
              (local.get $3)
              (i32.xor
               (local.get $2)
               (i32.const -1)
              )
             )
            )
           )
           (local.set $7
            (i32.sub
             (local.get $1)
             (local.get $7)
            )
           )
           (local.set $5
            (i32.sub
             (local.get $3)
             (i32.const 1)
            )
           )
           (local.set $3
            (i32.const 0)
           )
           (loop $label
            (br_if $block15
             (i32.gt_u
              (local.tee $3
               (i32.add
                (local.get $3)
                (i32.load8_u
                 (i32.add
                  (local.get $2)
                  (i32.const 1051412)
                 )
                )
               )
              )
              (local.get $7)
             )
            )
            (br_if $label
             (i32.ne
              (local.get $5)
              (local.tee $2
               (i32.add
                (local.get $2)
                (i32.const 1)
               )
              )
             )
            )
           )
          )
          (br_if $block12
           (i32.eqz
            (i32.and
             (local.get $2)
             (i32.const 1)
            )
           )
          )
          (i32.store8 offset=14
           (local.get $4)
           (i32.const 0)
          )
          (i32.store16 offset=12
           (local.get $4)
           (i32.const 0)
          )
          (i32.store8 offset=15
           (local.get $4)
           (i32.load8_u offset=1052179
            (i32.shr_u
             (local.get $1)
             (i32.const 20)
            )
           )
          )
          (i32.store8 offset=19
           (local.get $4)
           (i32.load8_u offset=1052179
            (i32.and
             (i32.shr_u
              (local.get $1)
              (i32.const 4)
             )
             (i32.const 15)
            )
           )
          )
          (i32.store8 offset=18
           (local.get $4)
           (i32.load8_u offset=1052179
            (i32.and
             (i32.shr_u
              (local.get $1)
              (i32.const 8)
             )
             (i32.const 15)
            )
           )
          )
          (i32.store8 offset=17
           (local.get $4)
           (i32.load8_u offset=1052179
            (i32.and
             (i32.shr_u
              (local.get $1)
              (i32.const 12)
             )
             (i32.const 15)
            )
           )
          )
          (i32.store8 offset=16
           (local.get $4)
           (i32.load8_u offset=1052179
            (i32.and
             (i32.shr_u
              (local.get $1)
              (i32.const 16)
             )
             (i32.const 15)
            )
           )
          )
          (i32.store8
           (local.tee $3
            (i32.add
             (local.tee $2
              (i32.shr_u
               (i32.clz
                (i32.or
                 (local.get $1)
                 (i32.const 1)
                )
               )
               (i32.const 2)
              )
             )
             (local.tee $6
              (i32.add
               (local.get $4)
               (i32.const 12)
              )
             )
            )
           )
           (i32.const 123)
          )
          (i32.store8
           (i32.sub
            (local.get $3)
            (i32.const 1)
           )
           (i32.const 117)
          )
          (i32.store8
           (i32.add
            (local.get $6)
            (local.tee $2
             (i32.sub
              (local.get $2)
              (i32.const 2)
             )
            )
           )
           (i32.const 92)
          )
          (i64.store align=1
           (local.get $0)
           (i64.load offset=12 align=2
            (local.get $4)
           )
          )
          (i32.store8 offset=21
           (local.get $4)
           (i32.const 125)
          )
          (i32.store8 offset=20
           (local.get $4)
           (i32.load8_u offset=1052179
            (i32.and
             (local.get $1)
             (i32.const 15)
            )
           )
          )
          (i32.store16 offset=8 align=1
           (local.get $0)
           (i32.load16_u offset=20
            (local.get $4)
           )
          )
          (br $block16)
         )
         (br_if $block11
          (i32.lt_u
           (i32.and
            (local.get $2)
            (i32.const 16777215)
           )
           (i32.const 65536)
          )
         )
         (i64.store offset=2 align=2
          (local.get $0)
          (i64.const 0)
         )
         (i32.store16
          (local.get $0)
          (i32.const 8796)
         )
        )
        (local.set $2
         (i32.const 0)
        )
        (br $block17
         (i32.const 2)
        )
       )
       (block $block28
        (block $block19
         (block $block18
          (if
           (i32.ge_u
            (local.get $1)
            (i32.const 65536)
           )
           (then
            (br_if $block18
             (i32.lt_u
              (local.get $1)
              (i32.const 131072)
             )
            )
            (br_if $block10
             (i32.eq
              (local.tee $2
               (i32.and
                (local.get $1)
                (i32.const 2097150)
               )
              )
              (i32.const 183982)
             )
            )
            (br_if $block10
             (i32.eq
              (i32.and
               (local.get $1)
               (i32.const 2097120)
              )
              (i32.const 173792)
             )
            )
            (br_if $block10
             (i32.eq
              (local.get $2)
              (i32.const 178206)
             )
            )
            (br_if $block10
             (i32.gt_u
              (i32.sub
               (local.get $1)
               (i32.const 191472)
              )
              (i32.const -16)
             )
            )
            (br_if $block10
             (i32.gt_u
              (i32.sub
               (local.get $1)
               (i32.const 194560)
              )
              (i32.const -2467)
             )
            )
            (br_if $block10
             (i32.gt_u
              (i32.sub
               (local.get $1)
               (i32.const 196608)
              )
              (i32.const -1507)
             )
            )
            (br_if $block10
             (i32.gt_u
              (i32.sub
               (local.get $1)
               (i32.const 201552)
              )
              (i32.const -6)
             )
            )
            (br_if $block10
             (i32.gt_u
              (i32.sub
               (local.get $1)
               (i32.const 917760)
              )
              (i32.const -707719)
             )
            )
            (br_if $block11
             (i32.lt_u
              (local.get $1)
              (i32.const 918000)
             )
            )
            (br $block10)
           )
          )
          (local.set $8
           (i32.and
            (i32.shr_u
             (local.get $1)
             (i32.const 8)
            )
            (i32.const 255)
           )
          )
          (local.set $2
           (i32.const 0)
          )
          (loop $label1
           (local.set $7
            (i32.add
             (local.get $2)
             (i32.const 2)
            )
           )
           (local.set $3
            (i32.add
             (local.get $6)
             (local.tee $5
              (i32.load8_u offset=1053589
               (local.get $2)
              )
             )
            )
           )
           (if
            (i32.ne
             (local.get $8)
             (local.tee $2
              (i32.load8_u offset=1053588
               (local.get $2)
              )
             )
            )
            (then
             (br_if $block19
              (i32.gt_u
               (local.get $2)
               (local.get $8)
              )
             )
             (local.set $6
              (local.get $3)
             )
             (br_if $label1
              (i32.ne
               (local.tee $2
                (local.get $7)
               )
               (i32.const 76)
              )
             )
             (br $block19)
            )
           )
           (block $block21
            (block $block22
             (block $block20
              (br_if $block20
               (i32.lt_u
                (local.get $3)
                (local.get $6)
               )
              )
              (br_if $block20
               (i32.gt_u
                (local.get $3)
                (i32.const 284)
               )
              )
              (br_if $block21
               (i32.eqz
                (local.get $5)
               )
              )
              (local.set $2
               (i32.add
                (local.get $6)
                (i32.const 1053664)
               )
              )
              (br $block22)
             )
             (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
              (local.get $6)
              (local.get $3)
              (i32.const 284)
              (i32.const 1054240)
             )
             (unreachable)
            )
            (loop $label2
             (br_if $block10
              (i32.eq
               (i32.load8_u
                (local.get $2)
               )
               (i32.and
                (local.get $1)
                (i32.const 255)
               )
              )
             )
             (local.set $2
              (i32.add
               (local.get $2)
               (i32.const 1)
              )
             )
             (br_if $label2
              (local.tee $5
               (i32.sub
                (local.get $5)
                (i32.const 1)
               )
              )
             )
            )
           )
           (local.set $6
            (local.get $3)
           )
           (br_if $label1
            (i32.ne
             (local.tee $2
              (local.get $7)
             )
             (i32.const 76)
            )
           )
          )
          (br $block19)
         )
         (local.set $8
          (i32.and
           (i32.shr_u
            (local.get $1)
            (i32.const 8)
           )
           (i32.const 255)
          )
         )
         (local.set $2
          (i32.const 0)
         )
         (loop $label3
          (block $block23
           (local.set $7
            (i32.add
             (local.get $2)
             (i32.const 2)
            )
           )
           (local.set $3
            (i32.add
             (local.get $6)
             (local.tee $5
              (i32.load8_u offset=1052781
               (local.get $2)
              )
             )
            )
           )
           (if
            (i32.ne
             (local.get $8)
             (local.tee $2
              (i32.load8_u offset=1052780
               (local.get $2)
              )
             )
            )
            (then
             (br_if $block23
              (i32.gt_u
               (local.get $2)
               (local.get $8)
              )
             )
             (local.set $6
              (local.get $3)
             )
             (br_if $label3
              (i32.ne
               (local.tee $2
                (local.get $7)
               )
               (i32.const 92)
              )
             )
             (br $block23)
            )
           )
           (block $block25
            (block $block26
             (block $block24
              (br_if $block24
               (i32.lt_u
                (local.get $3)
                (local.get $6)
               )
              )
              (br_if $block24
               (i32.gt_u
                (local.get $3)
                (i32.const 212)
               )
              )
              (br_if $block25
               (i32.eqz
                (local.get $5)
               )
              )
              (local.set $2
               (i32.add
                (local.get $6)
                (i32.const 1052872)
               )
              )
              (br $block26)
             )
             (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
              (local.get $6)
              (local.get $3)
              (i32.const 212)
              (i32.const 1054240)
             )
             (unreachable)
            )
            (loop $label4
             (br_if $block10
              (i32.eq
               (i32.load8_u
                (local.get $2)
               )
               (i32.and
                (local.get $1)
                (i32.const 255)
               )
              )
             )
             (local.set $2
              (i32.add
               (local.get $2)
               (i32.const 1)
              )
             )
             (br_if $label4
              (local.tee $5
               (i32.sub
                (local.get $5)
                (i32.const 1)
               )
              )
             )
            )
           )
           (local.set $6
            (local.get $3)
           )
           (br_if $label3
            (i32.ne
             (local.tee $2
              (local.get $7)
             )
             (i32.const 92)
            )
           )
          )
         )
         (local.set $6
          (i32.and
           (local.get $1)
           (i32.const 65535)
          )
         )
         (local.set $5
          (i32.const 1)
         )
         (local.set $2
          (i32.const 0)
         )
         (loop $label5
          (local.set $3
           (i32.add
            (local.get $2)
            (i32.const 1)
           )
          )
          (block $block27
           (if
            (i32.ge_s
             (local.tee $7
              (i32.load8_s offset=1053084
               (local.get $2)
              )
             )
             (i32.const 0)
            )
            (then
             (local.set $2
              (local.get $3)
             )
             (br $block27)
            )
           )
           (if
            (i32.ne
             (local.get $3)
             (i32.const 504)
            )
            (then
             (local.set $7
              (i32.or
               (i32.load8_u
                (i32.add
                 (local.get $2)
                 (i32.const 1053085)
                )
               )
               (i32.shl
                (i32.and
                 (local.get $7)
                 (i32.const 127)
                )
                (i32.const 8)
               )
              )
             )
             (local.set $2
              (i32.add
               (local.get $2)
               (i32.const 2)
              )
             )
             (br $block27)
            )
           )
           (call $_RNvNtCsdHhIpgkcIfN_4core6option13unwrap_failed
            (i32.const 1054256)
           )
           (unreachable)
          )
          (br_if $block28
           (i32.lt_s
            (local.tee $6
             (i32.sub
              (local.get $6)
              (local.get $7)
             )
            )
            (i32.const 0)
           )
          )
          (local.set $5
           (i32.xor
            (local.get $5)
            (i32.const 1)
           )
          )
          (br_if $label5
           (i32.ne
            (local.get $2)
            (i32.const 504)
           )
          )
         )
         (br $block28)
        )
        (local.set $5
         (i32.const 1)
        )
        (local.set $6
         (local.get $1)
        )
        (local.set $2
         (i32.const 0)
        )
        (loop $label6
         (local.set $3
          (i32.add
           (local.get $2)
           (i32.const 1)
          )
         )
         (block $block29
          (if
           (i32.ge_s
            (local.tee $7
             (i32.load8_s offset=1053948
              (local.get $2)
             )
            )
            (i32.const 0)
           )
           (then
            (local.set $2
             (local.get $3)
            )
            (br $block29)
           )
          )
          (if
           (i32.ne
            (local.get $3)
            (i32.const 292)
           )
           (then
            (local.set $7
             (i32.or
              (i32.load8_u
               (i32.add
                (local.get $2)
                (i32.const 1053949)
               )
              )
              (i32.shl
               (i32.and
                (local.get $7)
                (i32.const 127)
               )
               (i32.const 8)
              )
             )
            )
            (local.set $2
             (i32.add
              (local.get $2)
              (i32.const 2)
             )
            )
            (br $block29)
           )
          )
          (call $_RNvNtCsdHhIpgkcIfN_4core6option13unwrap_failed
           (i32.const 1054256)
          )
          (unreachable)
         )
         (br_if $block28
          (i32.lt_s
           (local.tee $6
            (i32.sub
             (local.get $6)
             (local.get $7)
            )
           )
           (i32.const 0)
          )
         )
         (local.set $5
          (i32.xor
           (local.get $5)
           (i32.const 1)
          )
         )
         (br_if $label6
          (i32.ne
           (local.get $2)
           (i32.const 292)
          )
         )
        )
       )
       (br_if $block10
        (i32.eqz
         (i32.and
          (local.get $5)
          (i32.const 1)
         )
        )
       )
      )
      (i32.store
       (local.get $0)
       (local.get $1)
      )
      (local.set $2
       (i32.const 128)
      )
      (br $block17
       (i32.const 129)
      )
     )
     (i32.store8 offset=24
      (local.get $4)
      (i32.const 0)
     )
     (i32.store16 offset=22
      (local.get $4)
      (i32.const 0)
     )
     (i32.store8 offset=25
      (local.get $4)
      (i32.load8_u offset=1052179
       (i32.shr_u
        (local.get $1)
        (i32.const 20)
       )
      )
     )
     (i32.store8 offset=29
      (local.get $4)
      (i32.load8_u offset=1052179
       (i32.and
        (i32.shr_u
         (local.get $1)
         (i32.const 4)
        )
        (i32.const 15)
       )
      )
     )
     (i32.store8 offset=28
      (local.get $4)
      (i32.load8_u offset=1052179
       (i32.and
        (i32.shr_u
         (local.get $1)
         (i32.const 8)
        )
        (i32.const 15)
       )
      )
     )
     (i32.store8 offset=27
      (local.get $4)
      (i32.load8_u offset=1052179
       (i32.and
        (i32.shr_u
         (local.get $1)
         (i32.const 12)
        )
        (i32.const 15)
       )
      )
     )
     (i32.store8 offset=26
      (local.get $4)
      (i32.load8_u offset=1052179
       (i32.and
        (i32.shr_u
         (local.get $1)
         (i32.const 16)
        )
        (i32.const 15)
       )
      )
     )
     (i32.store8
      (local.tee $3
       (i32.add
        (local.tee $2
         (i32.shr_u
          (i32.clz
           (i32.or
            (local.get $1)
            (i32.const 1)
           )
          )
          (i32.const 2)
         )
        )
        (local.tee $6
         (i32.add
          (local.get $4)
          (i32.const 22)
         )
        )
       )
      )
      (i32.const 123)
     )
     (i32.store8
      (i32.sub
       (local.get $3)
       (i32.const 1)
      )
      (i32.const 117)
     )
     (i32.store8
      (i32.add
       (local.get $6)
       (local.tee $2
        (i32.sub
         (local.get $2)
         (i32.const 2)
        )
       )
      )
      (i32.const 92)
     )
     (i64.store align=1
      (local.get $0)
      (i64.load offset=22 align=2
       (local.get $4)
      )
     )
     (i32.store8 offset=31
      (local.get $4)
      (i32.const 125)
     )
     (i32.store8 offset=30
      (local.get $4)
      (i32.load8_u offset=1052179
       (i32.and
        (local.get $1)
        (i32.const 15)
       )
      )
     )
     (i32.store16 offset=8 align=1
      (local.get $0)
      (i32.load16_u offset=30
       (local.get $4)
      )
     )
    )
    (i32.const 10)
   )
  )
  (i32.store8 offset=12
   (local.get $0)
   (local.get $2)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $4)
    (i32.const 32)
   )
  )
 )
 (func $_RNvNtCsdHhIpgkcIfN_4core6option13unwrap_failed (param $0 i32)
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1052245)
   (i32.const 87)
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNvNtCsdHhIpgkcIfN_4core3str16slice_error_fail (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local.set $6
   (local.get $0)
  )
  (local.set $0
   (i32.const 0)
  )
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 80)
    )
   )
  )
  (i32.store offset=8
   (local.get $5)
   (local.get $3)
  )
  (i32.store offset=4
   (local.get $5)
   (local.get $2)
  )
  (local.set $7
   (block $block3 (result i32)
    (block $block1
     (block $block2
      (if
       (i32.ge_u
        (local.get $1)
        (i32.const 257)
       )
       (then
        (local.set $0
         (i32.const 253)
        )
        (loop $label
         (block $block
          (if
           (i32.le_s
            (i32.load8_s
             (i32.add
              (local.tee $7
               (i32.add
                (local.get $0)
                (local.get $6)
               )
              )
              (i32.const 3)
             )
            )
            (i32.const -65)
           )
           (then
            (br_if $block
             (i32.le_s
              (i32.load8_s
               (i32.add
                (local.get $7)
                (i32.const 2)
               )
              )
              (i32.const -65)
             )
            )
            (local.set $0
             (i32.add
              (local.get $0)
              (i32.const 2)
             )
            )
            (br $block1)
           )
          )
          (local.set $0
           (i32.add
            (local.get $0)
            (i32.const 3)
           )
          )
          (br $block1)
         )
         (br_if $block2
          (i32.gt_s
           (i32.load8_s
            (i32.add
             (local.get $7)
             (i32.const 1)
            )
           )
           (i32.const -65)
          )
         )
         (br_if $block1
          (i32.gt_s
           (i32.load8_s
            (local.get $7)
           )
           (i32.const -65)
          )
         )
         (br_if $label
          (i32.ne
           (local.tee $0
            (i32.sub
             (local.get $0)
             (i32.const 4)
            )
           )
           (i32.const -3)
          )
         )
        )
        (local.set $0
         (i32.const 0)
        )
        (br $block1)
       )
      )
      (i32.store offset=16
       (local.get $5)
       (local.get $1)
      )
      (i32.store offset=12
       (local.get $5)
       (local.get $6)
      )
      (br $block3
       (i32.const 1)
      )
     )
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
    )
    (i32.store offset=12
     (local.get $5)
     (local.get $6)
    )
    (i32.store offset=16
     (local.get $5)
     (local.get $0)
    )
    (local.set $0
     (select
      (i32.const 5)
      (i32.const 0)
      (local.tee $7
       (i32.lt_u
        (local.get $0)
        (local.get $1)
       )
      )
     )
    )
    (select
     (i32.const 1052240)
     (i32.const 1)
     (local.get $7)
    )
   )
  )
  (i32.store offset=24
   (local.get $5)
   (local.get $0)
  )
  (i32.store offset=20
   (local.get $5)
   (local.get $7)
  )
  (block $block4
   (block $block16
    (block $block12
     (block $block6
      (block $block8
       (block $block5
        (if
         (i32.ge_u
          (local.get $1)
          (local.get $2)
         )
         (then
          (br_if $block4
           (i32.lt_u
            (local.get $1)
            (local.get $3)
           )
          )
          (br_if $block5
           (i32.gt_u
            (local.get $2)
            (local.get $3)
           )
          )
          (br_if $block6
           (i32.eqz
            (local.get $2)
           )
          )
          (br_if $block6
           (i32.le_u
            (local.get $1)
            (local.get $2)
           )
          )
          (br_if $block6
           (i32.gt_s
            (i32.load8_s
             (i32.add
              (local.get $2)
              (local.get $6)
             )
            )
            (i32.const -65)
           )
          )
          (local.set $0
           (local.get $2)
          )
          (block $block7
           (loop $label1
            (br_if $block7
             (i32.gt_s
              (i32.load8_s
               (i32.add
                (local.get $0)
                (local.get $6)
               )
              )
              (i32.const -65)
             )
            )
            (br_if $label1
             (local.tee $0
              (i32.sub
               (local.get $0)
               (i32.const 1)
              )
             )
            )
           )
           (local.set $0
            (i32.const 0)
           )
          )
          (loop $label2
           (br_if $block8
            (i32.gt_s
             (i32.load8_s
              (i32.add
               (local.get $2)
               (local.get $6)
              )
             )
             (i32.const -65)
            )
           )
           (br_if $label2
            (i32.ne
             (local.get $1)
             (local.tee $2
              (i32.add
               (local.get $2)
               (i32.const 1)
              )
             )
            )
           )
          )
          (local.set $2
           (local.get $1)
          )
          (br $block8)
         )
        )
        (i64.store offset=56
         (local.get $5)
         (i64.or
          (i64.extend_i32_u
           (i32.add
            (local.get $5)
            (i32.const 20)
           )
          )
          (i64.const 25769803776)
         )
        )
        (i64.store offset=48
         (local.get $5)
         (i64.or
          (i64.extend_i32_u
           (i32.add
            (local.get $5)
            (i32.const 12)
           )
          )
          (i64.const 25769803776)
         )
        )
        (i64.store offset=40
         (local.get $5)
         (i64.or
          (i64.extend_i32_u
           (i32.add
            (local.get $5)
            (i32.const 4)
           )
          )
          (i64.const 17179869184)
         )
        )
        (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
         (i32.const 1048674)
         (i32.add
          (local.get $5)
          (i32.const 40)
         )
         (local.get $4)
        )
        (unreachable)
       )
       (i64.store offset=64
        (local.get $5)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $5)
           (i32.const 20)
          )
         )
         (i64.const 25769803776)
        )
       )
       (i64.store offset=56
        (local.get $5)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $5)
           (i32.const 12)
          )
         )
         (i64.const 25769803776)
        )
       )
       (i64.store offset=48
        (local.get $5)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $5)
           (i32.const 8)
          )
         )
         (i64.const 17179869184)
        )
       )
       (i64.store offset=40
        (local.get $5)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $5)
           (i32.const 4)
          )
         )
         (i64.const 17179869184)
        )
       )
       (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
        (i32.const 1048632)
        (i32.add
         (local.get $5)
         (i32.const 40)
        )
        (local.get $4)
       )
       (unreachable)
      )
      (i32.store offset=28
       (local.get $5)
       (local.get $0)
      )
      (i32.store offset=32
       (local.get $5)
       (local.get $2)
      )
      (block $block9
       (br_if $block9
        (i32.gt_u
         (local.get $0)
         (local.get $2)
        )
       )
       (block $block10
        (br_if $block10
         (i32.eqz
          (local.get $0)
         )
        )
        (if
         (i32.ge_u
          (local.get $0)
          (local.get $1)
         )
         (then
          (br_if $block10
           (i32.eq
            (local.get $0)
            (local.get $1)
           )
          )
          (br $block9)
         )
        )
        (br_if $block9
         (i32.lt_s
          (i32.load8_s
           (i32.add
            (local.get $0)
            (local.get $6)
           )
          )
          (i32.const -64)
         )
        )
       )
       (block $block11
        (if
         (i32.le_u
          (local.get $1)
          (local.get $2)
         )
         (then
          (br_if $block9
           (i32.ne
            (local.get $1)
            (local.get $2)
           )
          )
          (br $block11)
         )
        )
        (br_if $block9
         (i32.le_s
          (i32.load8_s
           (i32.add
            (local.get $2)
            (local.get $6)
           )
          )
          (i32.const -65)
         )
        )
       )
       (br_if $block12
        (i32.eq
         (local.get $0)
         (local.get $2)
        )
       )
       (i32.store offset=36
        (local.get $5)
        (block $block13 (result i32)
         (if
          (i32.ge_s
           (local.tee $0
            (i32.load8_s
             (local.tee $1
              (i32.add
               (local.get $0)
               (local.get $6)
              )
             )
            )
           )
           (i32.const 0)
          )
          (then
           (br $block13
            (i32.and
             (local.get $0)
             (i32.const 255)
            )
           )
          )
         )
         (drop
          (br_if $block13
           (i32.or
            (local.tee $3
             (i32.and
              (i32.load8_u offset=1
               (local.get $1)
              )
              (i32.const 63)
             )
            )
            (i32.shl
             (local.tee $2
              (i32.and
               (local.get $0)
               (i32.const 31)
              )
             )
             (i32.const 6)
            )
           )
           (i32.le_u
            (local.get $0)
            (i32.const -33)
           )
          )
         )
         (drop
          (br_if $block13
           (i32.or
            (local.tee $3
             (i32.or
              (i32.and
               (i32.load8_u offset=2
                (local.get $1)
               )
               (i32.const 63)
              )
              (i32.shl
               (local.get $3)
               (i32.const 6)
              )
             )
            )
            (i32.shl
             (local.get $2)
             (i32.const 12)
            )
           )
           (i32.lt_u
            (local.get $0)
            (i32.const -16)
           )
          )
         )
         (i32.or
          (i32.and
           (i32.shl
            (local.get $2)
            (i32.const 18)
           )
           (i32.const 1835008)
          )
          (i32.or
           (i32.and
            (i32.load8_u offset=3
             (local.get $1)
            )
            (i32.const 63)
           )
           (i32.shl
            (local.get $3)
            (i32.const 6)
           )
          )
         )
        )
       )
       (i64.store offset=72
        (local.get $5)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $5)
           (i32.const 20)
          )
         )
         (i64.const 25769803776)
        )
       )
       (i64.store offset=64
        (local.get $5)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $5)
           (i32.const 12)
          )
         )
         (i64.const 25769803776)
        )
       )
       (i64.store offset=56
        (local.get $5)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $5)
           (i32.const 28)
          )
         )
         (i64.const 64424509440)
        )
       )
       (i64.store offset=48
        (local.get $5)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $5)
           (i32.const 36)
          )
         )
         (i64.const 68719476736)
        )
       )
       (i64.store offset=40
        (local.get $5)
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $5)
           (i32.const 4)
          )
         )
         (i64.const 17179869184)
        )
       )
       (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
        (i32.const 1048766)
        (i32.add
         (local.get $5)
         (i32.const 40)
        )
        (local.get $4)
       )
       (unreachable)
      )
      (call $_RNvNtCsdHhIpgkcIfN_4core3str16slice_error_fail
       (local.get $6)
       (local.get $1)
       (local.get $0)
       (local.get $2)
       (local.get $4)
      )
      (unreachable)
     )
     (br_if $block4
      (i32.eqz
       (local.get $3)
      )
     )
     (br_if $block4
      (i32.le_u
       (local.get $1)
       (local.get $3)
      )
     )
     (br_if $block4
      (i32.gt_s
       (i32.load8_s
        (i32.add
         (local.get $3)
         (local.get $6)
        )
       )
       (i32.const -65)
      )
     )
     (local.set $0
      (local.get $3)
     )
     (block $block14
      (loop $label3
       (br_if $block14
        (i32.gt_s
         (i32.load8_s
          (i32.add
           (local.get $0)
           (local.get $6)
          )
         )
         (i32.const -65)
        )
       )
       (br_if $label3
        (local.tee $0
         (i32.sub
          (local.get $0)
          (i32.const 1)
         )
        )
       )
      )
      (local.set $0
       (i32.const 0)
      )
     )
     (block $block15
      (loop $label4
       (br_if $block15
        (i32.gt_s
         (i32.load8_s
          (i32.add
           (local.get $3)
           (local.get $6)
          )
         )
         (i32.const -65)
        )
       )
       (br_if $label4
        (i32.ne
         (local.get $1)
         (local.tee $3
          (i32.add
           (local.get $3)
           (i32.const 1)
          )
         )
        )
       )
      )
      (local.set $3
       (local.get $1)
      )
     )
     (i32.store offset=28
      (local.get $5)
      (local.get $0)
     )
     (i32.store offset=32
      (local.get $5)
      (local.get $3)
     )
     (br_if $block16
      (i32.gt_u
       (local.get $0)
       (local.get $3)
      )
     )
     (block $block17
      (br_if $block17
       (i32.eqz
        (local.get $0)
       )
      )
      (if
       (i32.ge_u
        (local.get $0)
        (local.get $1)
       )
       (then
        (br_if $block17
         (i32.eq
          (local.get $0)
          (local.get $1)
         )
        )
        (br $block16)
       )
      )
      (br_if $block16
       (i32.lt_s
        (i32.load8_s
         (i32.add
          (local.get $0)
          (local.get $6)
         )
        )
        (i32.const -64)
       )
      )
     )
     (block $block18
      (if
       (i32.le_u
        (local.get $1)
        (local.get $3)
       )
       (then
        (br_if $block16
         (i32.ne
          (local.get $1)
          (local.get $3)
         )
        )
        (br $block18)
       )
      )
      (br_if $block16
       (i32.le_s
        (i32.load8_s
         (i32.add
          (local.get $3)
          (local.get $6)
         )
        )
        (i32.const -65)
       )
      )
     )
     (br_if $block12
      (i32.eq
       (local.get $0)
       (local.get $3)
      )
     )
     (i32.store offset=36
      (local.get $5)
      (block $block19 (result i32)
       (if
        (i32.ge_s
         (local.tee $0
          (i32.load8_s
           (local.tee $1
            (i32.add
             (local.get $0)
             (local.get $6)
            )
           )
          )
         )
         (i32.const 0)
        )
        (then
         (br $block19
          (i32.and
           (local.get $0)
           (i32.const 255)
          )
         )
        )
       )
       (drop
        (br_if $block19
         (i32.or
          (local.tee $3
           (i32.and
            (i32.load8_u offset=1
             (local.get $1)
            )
            (i32.const 63)
           )
          )
          (i32.shl
           (local.tee $2
            (i32.and
             (local.get $0)
             (i32.const 31)
            )
           )
           (i32.const 6)
          )
         )
         (i32.le_u
          (local.get $0)
          (i32.const -33)
         )
        )
       )
       (drop
        (br_if $block19
         (i32.or
          (local.tee $3
           (i32.or
            (i32.and
             (i32.load8_u offset=2
              (local.get $1)
             )
             (i32.const 63)
            )
            (i32.shl
             (local.get $3)
             (i32.const 6)
            )
           )
          )
          (i32.shl
           (local.get $2)
           (i32.const 12)
          )
         )
         (i32.lt_u
          (local.get $0)
          (i32.const -16)
         )
        )
       )
       (i32.or
        (i32.and
         (i32.shl
          (local.get $2)
          (i32.const 18)
         )
         (i32.const 1835008)
        )
        (i32.or
         (i32.and
          (i32.load8_u offset=3
           (local.get $1)
          )
          (i32.const 63)
         )
         (i32.shl
          (local.get $3)
          (i32.const 6)
         )
        )
       )
      )
     )
     (i64.store offset=72
      (local.get $5)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $5)
         (i32.const 20)
        )
       )
       (i64.const 25769803776)
      )
     )
     (i64.store offset=64
      (local.get $5)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $5)
         (i32.const 12)
        )
       )
       (i64.const 25769803776)
      )
     )
     (i64.store offset=56
      (local.get $5)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $5)
         (i32.const 28)
        )
       )
       (i64.const 64424509440)
      )
     )
     (i64.store offset=48
      (local.get $5)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $5)
         (i32.const 36)
        )
       )
       (i64.const 68719476736)
      )
     )
     (i64.store offset=40
      (local.get $5)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $5)
         (i32.const 8)
        )
       )
       (i64.const 17179869184)
      )
     )
     (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
      (i32.const 1048847)
      (i32.add
       (local.get $5)
       (i32.const 40)
      )
      (local.get $4)
     )
     (unreachable)
    )
    (call $_RNvNtCsdHhIpgkcIfN_4core6option13unwrap_failed
     (local.get $4)
    )
    (unreachable)
   )
   (call $_RNvNtCsdHhIpgkcIfN_4core3str16slice_error_fail
    (local.get $6)
    (local.get $1)
    (local.get $0)
    (local.get $3)
    (local.get $4)
   )
   (unreachable)
  )
  (i64.store offset=56
   (local.get $5)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $5)
      (i32.const 20)
     )
    )
    (i64.const 25769803776)
   )
  )
  (i64.store offset=48
   (local.get $5)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $5)
      (i32.const 12)
     )
    )
    (i64.const 25769803776)
   )
  )
  (i64.store offset=40
   (local.get $5)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $5)
      (i32.const 8)
     )
    )
    (i64.const 17179869184)
   )
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
   (i32.const 1048721)
   (i32.add
    (local.get $5)
    (i32.const 40)
   )
   (local.get $4)
  )
  (unreachable)
 )
 (func $_RNvXs_NtNtCsdHhIpgkcIfN_4core3ops5rangeINtB4_5RangejENtNtB8_3fmt5Debug3fmtB8_ (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block2
   (block $block1
    (block $block
     (if
      (i32.eqz
       (i32.and
        (local.tee $2
         (i32.load offset=8
          (local.get $1)
         )
        )
        (i32.const 33554432)
       )
      )
      (then
       (br_if $block
        (i32.and
         (local.get $2)
         (i32.const 67108864)
        )
       )
       (br_if $block1
        (i32.eqz
         (call $_RNvXs8_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3impmNtB9_7Display3fmt
          (local.get $0)
          (local.get $1)
         )
        )
       )
       (local.set $2
        (i32.const 1)
       )
       (br $block2)
      )
     )
     (local.set $2
      (i32.load
       (local.get $0)
      )
     )
     (local.set $3
      (i32.const 9)
     )
     (loop $label
      (i32.store8
       (i32.add
        (i32.add
         (local.get $3)
         (local.get $4)
        )
        (i32.const 6)
       )
       (i32.load8_u offset=1052179
        (i32.and
         (local.get $2)
         (i32.const 15)
        )
       )
      )
      (local.set $3
       (i32.sub
        (local.get $3)
        (i32.const 1)
       )
      )
      (br_if $label
       (local.tee $2
        (i32.shr_u
         (local.get $2)
         (i32.const 4)
        )
       )
      )
     )
     (local.set $2
      (i32.const 1)
     )
     (br_if $block1
      (i32.eqz
       (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
        (local.get $1)
        (i32.const 1)
        (i32.const 1054516)
        (i32.const 2)
        (i32.add
         (i32.add
          (local.get $3)
          (local.get $4)
         )
         (i32.const 7)
        )
        (i32.sub
         (i32.const 9)
         (local.get $3)
        )
       )
      )
     )
     (br $block2)
    )
    (local.set $2
     (i32.load
      (local.get $0)
     )
    )
    (local.set $3
     (i32.const 9)
    )
    (loop $label1
     (i32.store8
      (i32.add
       (i32.add
        (local.get $3)
        (local.get $4)
       )
       (i32.const 6)
      )
      (i32.load8_u offset=1054518
       (i32.and
        (local.get $2)
        (i32.const 15)
       )
      )
     )
     (local.set $3
      (i32.sub
       (local.get $3)
       (i32.const 1)
      )
     )
     (br_if $label1
      (local.tee $2
       (i32.shr_u
        (local.get $2)
        (i32.const 4)
       )
      )
     )
    )
    (local.set $2
     (i32.const 1)
    )
    (br_if $block2
     (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
      (local.get $1)
      (i32.const 1)
      (i32.const 1054516)
      (i32.const 2)
      (i32.add
       (i32.add
        (local.get $3)
        (local.get $4)
       )
       (i32.const 7)
      )
      (i32.sub
       (i32.const 9)
       (local.get $3)
      )
     )
    )
   )
   (if
    (call_indirect $0 (type $0)
     (i32.load
      (local.get $1)
     )
     (i32.const 1054464)
     (i32.const 2)
     (i32.load offset=12
      (i32.load offset=4
       (local.get $1)
      )
     )
    )
    (then
     (local.set $2
      (i32.const 1)
     )
     (br $block2)
    )
   )
   (local.set $0
    (i32.add
     (local.get $0)
     (i32.const 4)
    )
   )
   (block $block3
    (if
     (i32.eqz
      (i32.and
       (local.tee $2
        (i32.load offset=8
         (local.get $1)
        )
       )
       (i32.const 33554432)
      )
     )
     (then
      (br_if $block3
       (i32.and
        (local.get $2)
        (i32.const 67108864)
       )
      )
      (local.set $2
       (call $_RNvXs8_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3impmNtB9_7Display3fmt
        (local.get $0)
        (local.get $1)
       )
      )
      (br $block2)
     )
    )
    (local.set $2
     (i32.load
      (local.get $0)
     )
    )
    (local.set $3
     (i32.const 9)
    )
    (loop $label2
     (i32.store8
      (i32.add
       (i32.add
        (local.get $3)
        (local.get $4)
       )
       (i32.const 6)
      )
      (i32.load8_u offset=1052179
       (i32.and
        (local.get $2)
        (i32.const 15)
       )
      )
     )
     (local.set $3
      (i32.sub
       (local.get $3)
       (i32.const 1)
      )
     )
     (br_if $label2
      (local.tee $2
       (i32.shr_u
        (local.get $2)
        (i32.const 4)
       )
      )
     )
    )
    (local.set $2
     (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
      (local.get $1)
      (i32.const 1)
      (i32.const 1054516)
      (i32.const 2)
      (i32.add
       (i32.add
        (local.get $3)
        (local.get $4)
       )
       (i32.const 7)
      )
      (i32.sub
       (i32.const 9)
       (local.get $3)
      )
     )
    )
    (br $block2)
   )
   (local.set $2
    (i32.load
     (local.get $0)
    )
   )
   (local.set $3
    (i32.const 9)
   )
   (loop $label3
    (i32.store8
     (i32.add
      (i32.add
       (local.get $3)
       (local.get $4)
      )
      (i32.const 6)
     )
     (i32.load8_u offset=1054518
      (i32.and
       (local.get $2)
       (i32.const 15)
      )
     )
    )
    (local.set $3
     (i32.sub
      (local.get $3)
      (i32.const 1)
     )
    )
    (br_if $label3
     (local.tee $2
      (i32.shr_u
       (local.get $2)
       (i32.const 4)
      )
     )
    )
   )
   (local.set $2
    (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
     (local.get $1)
     (i32.const 1)
     (i32.const 1054516)
     (i32.const 2)
     (i32.add
      (i32.add
       (local.get $3)
       (local.get $4)
      )
      (i32.const 7)
     )
     (i32.sub
      (i32.const 9)
      (local.get $3)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $4)
    (i32.const 16)
   )
  )
  (local.get $2)
 )
 (func $_RNvXsj_NtCsdHhIpgkcIfN_4core3fmtcNtB5_5Debug3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $scratch
   (block $block (result i32)
    (drop
     (br_if $block
      (i32.const 1)
      (call_indirect $0 (type $1)
       (local.tee $3
        (i32.load
         (local.get $1)
        )
       )
       (i32.const 39)
       (local.tee $1
        (i32.load offset=16
         (local.tee $5
          (i32.load offset=4
           (local.get $1)
          )
         )
        )
       )
      )
     )
    )
    (call $_RNvMNtNtCsdHhIpgkcIfN_4core4char7methodsc16escape_debug_ext
     (local.get $2)
     (i32.load
      (local.get $0)
     )
     (i32.const 257)
    )
    (block $block1
     (if
      (i32.ge_u
       (local.tee $0
        (i32.load8_u offset=13
         (local.get $2)
        )
       )
       (i32.const 129)
      )
      (then
       (br_if $block1
        (i32.eqz
         (call_indirect $0 (type $1)
          (local.get $3)
          (i32.load
           (local.get $2)
          )
          (local.get $1)
         )
        )
       )
       (br $block
        (i32.const 1)
       )
      )
     )
     (br_if $block1
      (i32.eqz
       (call_indirect $0 (type $0)
        (local.get $3)
        (i32.add
         (local.get $2)
         (local.tee $4
          (i32.load8_u offset=12
           (local.get $2)
          )
         )
        )
        (i32.sub
         (local.get $0)
         (local.get $4)
        )
        (i32.load offset=12
         (local.get $5)
        )
       )
      )
     )
     (br $block
      (i32.const 1)
     )
    )
    (call_indirect $0 (type $1)
     (local.get $3)
     (i32.const 39)
     (local.get $1)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvXsr_NtCsdHhIpgkcIfN_4core4cellNtB5_14BorrowMutErrorNtNtB7_3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter3pad
   (local.get $1)
   (i32.const 1054608)
   (i32.const 24)
  )
 )
 (func $_RNvXsq_NtCsdHhIpgkcIfN_4core4cellNtB5_11BorrowErrorNtNtB7_3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter3pad
   (local.get $1)
   (i32.const 1054576)
   (i32.const 32)
  )
 )
 (func $_RNvXsg_NtNtCsdHhIpgkcIfN_4core3fmt3numhNtB7_8UpperHex3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $3
   (i32.load8_u
    (local.get $0)
   )
  )
  (local.set $0
   (i32.const 3)
  )
  (loop $label
   (i32.store8
    (i32.add
     (i32.add
      (local.get $0)
      (local.get $2)
     )
     (i32.const 12)
    )
    (i32.load8_u
     (i32.add
      (i32.and
       (local.get $3)
       (i32.const 15)
      )
      (i32.const 1054518)
     )
    )
   )
   (local.set $0
    (i32.sub
     (local.get $0)
     (i32.const 1)
    )
   )
   (br_if $label
    (local.tee $3
     (i32.shr_u
      (local.get $3)
      (i32.const 4)
     )
    )
   )
  )
  (local.set $scratch
   (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
    (local.get $1)
    (i32.const 1)
    (i32.const 1054516)
    (i32.const 2)
    (i32.add
     (i32.add
      (local.get $0)
      (local.get $2)
     )
     (i32.const 13)
    )
    (i32.sub
     (i32.const 3)
     (local.get $0)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvXs9_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3implNtB9_7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $2
   (i32.const 10)
  )
  (if
   (i32.ge_u
    (local.tee $0
     (i32.sub
      (i32.xor
       (local.tee $4
        (i32.load
         (local.get $0)
        )
       )
       (local.tee $0
        (i32.shr_s
         (local.get $4)
         (i32.const 31)
        )
       )
      )
      (local.get $0)
     )
    )
    (i32.const 1000)
   )
   (then
    (loop $label
     (i32.store16 align=1
      (i32.sub
       (local.tee $5
        (i32.add
         (i32.add
          (local.get $3)
          (i32.const 6)
         )
         (local.get $2)
        )
       )
       (i32.const 4)
      )
      (i32.load16_u offset=1052290 align=1
       (i32.shl
        (local.tee $8
         (i32.div_u
          (i32.and
           (local.tee $7
            (i32.sub
             (local.tee $6
              (local.get $0)
             )
             (i32.mul
              (local.tee $0
               (i32.div_u
                (local.get $0)
                (i32.const 10000)
               )
              )
              (i32.const 10000)
             )
            )
           )
           (i32.const 65535)
          )
          (i32.const 100)
         )
        )
        (i32.const 1)
       )
      )
     )
     (i32.store16 align=1
      (i32.sub
       (local.get $5)
       (i32.const 2)
      )
      (i32.load16_u offset=1052290 align=1
       (i32.shl
        (i32.and
         (i32.sub
          (local.get $7)
          (i32.mul
           (local.get $8)
           (i32.const 100)
          )
         )
         (i32.const 65535)
        )
        (i32.const 1)
       )
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (i32.const 4)
      )
     )
     (br_if $label
      (i32.gt_u
       (local.get $6)
       (i32.const 9999999)
      )
     )
    )
   )
  )
  (if
   (i32.gt_u
    (local.get $0)
    (i32.const 9)
   )
   (then
    (i32.store16 align=1
     (i32.add
      (local.tee $2
       (i32.sub
        (local.get $2)
        (i32.const 2)
       )
      )
      (i32.add
       (local.get $3)
       (i32.const 6)
      )
     )
     (i32.load16_u offset=1052290 align=1
      (i32.shl
       (i32.and
        (i32.sub
         (local.get $0)
         (i32.mul
          (local.tee $0
           (i32.div_u
            (i32.and
             (local.get $0)
             (i32.const 65535)
            )
            (i32.const 100)
           )
          )
          (i32.const 100)
         )
        )
        (i32.const 65535)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (select
     (i32.const 0)
     (local.get $4)
     (local.get $0)
    )
   )
   (then
    (i32.store8
     (i32.add
      (local.tee $2
       (i32.sub
        (local.get $2)
        (i32.const 1)
       )
      )
      (i32.add
       (local.get $3)
       (i32.const 6)
      )
     )
     (i32.load8_u offset=1052291
      (i32.shl
       (local.get $0)
       (i32.const 1)
      )
     )
    )
   )
  )
  (local.set $scratch
   (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
    (local.get $1)
    (i32.shr_u
     (i32.xor
      (local.get $4)
      (i32.const -1)
     )
     (i32.const 31)
    )
    (i32.const 1)
    (i32.const 0)
    (i32.add
     (i32.add
      (local.get $3)
      (i32.const 6)
     )
     (local.get $2)
    )
    (i32.sub
     (i32.const 10)
     (local.get $2)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvNtCset5xJoy1xWQ_3std9panicking15panic_with_hook (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $scratch i32)
  (local $scratch_13 i32)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 640)
    )
   )
  )
  (i32.store
   (i32.const 1061000)
   (i32.add
    (local.tee $6
     (i32.load
      (i32.const 1061000)
     )
    )
    (i32.const 1)
   )
  )
  (i32.store offset=28
   (local.get $5)
   (local.get $1)
  )
  (i32.store offset=24
   (local.get $5)
   (local.get $0)
  )
  (i32.store offset=32
   (local.get $5)
   (local.get $2)
  )
  (block $block1
   (block $block
    (if
     (i32.ge_s
      (local.get $6)
      (i32.const 0)
     )
     (then
      (if
       (i32.eqz
        (i32.load8_u
         (i32.const 1060936)
        )
       )
       (then
        (i32.store8
         (i32.const 1060936)
         (i32.const 1)
        )
        (i32.store
         (i32.const 1060932)
         (i32.add
          (i32.load
           (i32.const 1060932)
          )
          (i32.const 1)
         )
        )
        (br_if $block
         (i32.ge_s
          (local.tee $6
           (i32.load
            (i32.const 1060940)
           )
          )
          (i32.const 0)
         )
        )
        (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
         (i32.sub
          (local.get $5)
          (i32.const -64)
         )
         (i32.add
          (local.get $5)
          (i32.const 639)
         )
         (i32.const 1055372)
         (i32.const 115)
        )
        (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
         (i32.load8_u offset=64
          (local.get $5)
         )
         (i32.load offset=68
          (local.get $5)
         )
        )
        (br $block1)
       )
      )
      (call_indirect $0 (type $3)
       (i32.add
        (local.get $5)
        (i32.const 8)
       )
       (local.get $0)
       (i32.load offset=24
        (local.get $1)
       )
      )
      (i32.store offset=580
       (local.get $5)
       (select
        (i32.load offset=12
         (local.get $5)
        )
        (i32.const 0)
        (local.tee $0
         (i32.load offset=8
          (local.get $5)
         )
        )
       )
      )
      (i32.store offset=576
       (local.get $5)
       (select
        (local.get $0)
        (i32.const 1)
        (local.get $0)
       )
      )
      (i64.store offset=72
       (local.get $5)
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $5)
          (i32.const 576)
         )
        )
        (i64.const 25769803776)
       )
      )
      (i64.store offset=64
       (local.get $5)
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $5)
          (i32.const 32)
         )
        )
        (i64.const 73014444032)
       )
      )
      (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
       (i32.add
        (local.get $5)
        (i32.const 592)
       )
       (i32.add
        (local.get $5)
        (i32.const 639)
       )
       (i32.const 1050969)
       (i32.sub
        (local.get $5)
        (i32.const -64)
       )
      )
      (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
       (i32.load8_u offset=592
        (local.get $5)
       )
       (i32.load offset=596
        (local.get $5)
       )
      )
      (br $block1)
     )
    )
    (i64.store offset=72
     (local.get $5)
     (i64.or
      (i64.extend_i32_u
       (i32.add
        (local.get $5)
        (i32.const 24)
       )
      )
      (i64.const 30064771072)
     )
    )
    (i64.store offset=64
     (local.get $5)
     (i64.or
      (i64.extend_i32_u
       (i32.add
        (local.get $5)
        (i32.const 32)
       )
      )
      (i64.const 73014444032)
     )
    )
    (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
     (i32.add
      (local.get $5)
      (i32.const 592)
     )
     (i32.add
      (local.get $5)
      (i32.const 639)
     )
     (i32.const 1051091)
     (i32.sub
      (local.get $5)
      (i32.const -64)
     )
    )
    (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
     (i32.load8_u offset=592
      (local.get $5)
     )
     (i32.load offset=596
      (local.get $5)
     )
    )
    (br $block1)
   )
   (i32.store
    (i32.const 1060940)
    (i32.add
     (local.get $6)
     (i32.const 1)
    )
   )
   (call_indirect $0 (type $3)
    (i32.add
     (local.get $5)
     (i32.const 16)
    )
    (local.get $0)
    (i32.load offset=20
     (local.get $1)
    )
   )
   (local.set $6
    (i32.load offset=20
     (local.get $5)
    )
   )
   (local.set $1
    (i32.load offset=16
     (local.get $5)
    )
   )
   (local.set $7
    (block $block2 (result i32)
     (drop
      (br_if $block2
       (i32.const 3)
       (local.get $4)
      )
     )
     (drop
      (br_if $block2
       (i32.const 1)
       (i32.gt_u
        (i32.load
         (i32.const 1060932)
        )
        (i32.const 1)
       )
      )
     )
     (i32.and
      (call $_RNvNtCset5xJoy1xWQ_3std5panic19get_backtrace_style)
      (i32.const 255)
     )
    )
   )
   (i32.store offset=36
    (local.get $5)
    (local.get $2)
   )
   (local.set $0
    (i32.const 12)
   )
   (call_indirect $0 (type $3)
    (local.tee $2
     (i32.sub
      (local.get $5)
      (i32.const -64)
     )
    )
    (local.get $1)
    (local.tee $6
     (i32.load
      (i32.add
       (local.get $6)
       (i32.const 12)
      )
     )
    )
   )
   (local.set $4
    (local.get $1)
   )
   (local.set $1
    (block $block3 (result i32)
     (local.set $0
      (i32.load
       (i32.add
        (if (result i32)
         (i64.ne
          (i64.or
           (i64.xor
            (i64.load offset=64
             (local.get $5)
            )
            (i64.const 7199936582794304877)
           )
           (i64.xor
            (i64.load offset=72
             (local.get $5)
            )
            (i64.const -5076933981314334344)
           )
          )
          (i64.const 0)
         )
         (then
          (call_indirect $0 (type $3)
           (local.get $2)
           (local.get $1)
           (local.get $6)
          )
          (drop
           (br_if $block3
            (i32.const 1056480)
            (i64.ne
             (i64.or
              (i64.xor
               (i64.load offset=64
                (local.get $5)
               )
               (i64.const -7788913181612638748)
              )
              (i64.xor
               (i64.load offset=72
                (local.get $5)
               )
               (i64.const -9212764535765366089)
              )
             )
             (i64.const 0)
            )
           )
          )
          (local.set $4
           (i32.add
            (local.get $1)
            (i32.const 4)
           )
          )
          (i32.const 8)
         )
         (else
          (i32.const 4)
         )
        )
        (local.get $1)
       )
      )
     )
     (i32.load
      (local.get $4)
     )
    )
   )
   (i32.store offset=44
    (local.get $5)
    (local.get $0)
   )
   (i32.store offset=40
    (local.get $5)
    (local.get $1)
   )
   (call $_RNvNtNtCset5xJoy1xWQ_3std3sys9backtrace4lock)
   (i32.store offset=52
    (local.get $5)
    (select
     (i32.const 4)
     (i32.const 9)
     (local.tee $0
      (select
       (i32.const 0)
       (select
        (i32.const 1055080)
        (i32.const 0)
        (i64.eq
         (local.tee $9
          (i64.load
           (i32.const 1061008)
          )
         )
         (local.tee $8
          (i64.load
           (i32.const 1060992)
          )
         )
        )
       )
       (i64.eqz
        (local.get $8)
       )
      )
     )
    )
   )
   (i32.store offset=48
    (local.get $5)
    (select
     (local.get $0)
     (i32.const 1055084)
     (local.get $0)
    )
   )
   (block $block9
    (block $block6
     (block $block5
      (block $block4
       (if
        (i64.eqz
         (local.get $9)
        )
        (then
         (local.set $8
          (i64.load
           (i32.const 1061016)
          )
         )
         (loop $label
          (br_if $block4
           (i64.eq
            (local.get $8)
            (i64.const -1)
           )
          )
          (i64.store
           (i32.const 1061016)
           (select
            (local.tee $9
             (i64.add
              (local.get $8)
              (i64.const 1)
             )
            )
            (local.tee $10
             (i64.load
              (i32.const 1061016)
             )
            )
            (local.tee $0
             (i64.eq
              (local.get $8)
              (local.get $10)
             )
            )
           )
          )
          (local.set $8
           (local.get $10)
          )
          (br_if $label
           (i32.eqz
            (local.get $0)
           )
          )
         )
         (i64.store
          (i32.const 1061008)
          (local.get $9)
         )
        )
       )
       (i64.store offset=56
        (local.get $5)
        (local.get $9)
       )
       (memory.fill
        (local.tee $0
         (i32.sub
          (local.get $5)
          (i32.const -64)
         )
        )
        (i32.const 0)
        (i32.const 512)
       )
       (i64.store offset=584
        (local.get $5)
        (i64.const 0)
       )
       (i32.store offset=580
        (local.get $5)
        (i32.const 512)
       )
       (i32.store offset=576
        (local.get $5)
        (local.get $0)
       )
       (i64.store offset=616
        (local.get $5)
        (local.tee $8
         (i64.or
          (i64.extend_i32_u
           (i32.add
            (local.get $5)
            (i32.const 40)
           )
          )
          (i64.const 25769803776)
         )
        )
       )
       (i64.store offset=608
        (local.get $5)
        (local.tee $10
         (i64.or
          (i64.extend_i32_u
           (i32.add
            (local.get $5)
            (i32.const 36)
           )
          )
          (i64.const 73014444032)
         )
        )
       )
       (i64.store offset=600
        (local.get $5)
        (local.tee $9
         (i64.or
          (i64.extend_i32_u
           (i32.add
            (local.get $5)
            (i32.const 56)
           )
          )
          (i64.const 77309411328)
         )
        )
       )
       (i64.store offset=592
        (local.get $5)
        (local.tee $11
         (i64.or
          (i64.extend_i32_u
           (i32.add
            (local.get $5)
            (i32.const 48)
           )
          )
          (i64.const 25769803776)
         )
        )
       )
       (i32.store offset=624
        (local.get $5)
        (i32.const 4)
       )
       (i32.store offset=632
        (local.get $5)
        (i32.add
         (local.get $5)
         (i32.const 576)
        )
       )
       (if
        (block (result i32)
         (local.set $scratch
          (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
           (i32.add
            (local.get $5)
            (i32.const 624)
           )
           (i32.const 1054764)
           (i32.const 1051052)
           (i32.add
            (local.get $5)
            (i32.const 592)
           )
          )
         )
         (local.set $0
          (i32.load8_u offset=624
           (local.get $5)
          )
         )
         (local.get $scratch)
        )
        (then
         (br_if $block5
          (i32.ne
           (local.get $0)
           (i32.const 4)
          )
         )
         (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
          (i32.const 1054788)
          (i32.const 173)
          (i32.const 1054876)
         )
         (unreachable)
        )
       )
       (br_if $block6
        (i32.ne
         (local.get $0)
         (i32.const 3)
        )
       )
       (local.set $1
        (i32.load
         (local.tee $0
          (i32.load offset=628
           (local.get $5)
          )
         )
        )
       )
       (if
        (local.tee $4
         (i32.load
          (local.tee $2
           (i32.load
            (i32.add
             (local.get $0)
             (i32.const 4)
            )
           )
          )
         )
        )
        (then
         (call_indirect $0 (type $2)
          (local.get $1)
          (local.get $4)
         )
        )
       )
       (if
        (i32.load offset=4
         (local.get $2)
        )
        (then
         (call $dlfree
          (local.get $1)
         )
        )
       )
       (call $dlfree
        (local.get $0)
       )
       (br $block6)
      )
      (call $_RNvNvMNtNtCset5xJoy1xWQ_3std6thread2idNtB4_8ThreadId3new9exhausted)
      (unreachable)
     )
     (block $block8
      (block $block7
       (br_table $block7 $block6 $block8
        (i32.sub
         (i32.load8_u offset=624
          (local.get $5)
         )
         (i32.const 3)
        )
       )
      )
      (local.set $1
       (i32.load
        (local.tee $0
         (i32.load offset=628
          (local.get $5)
         )
        )
       )
      )
      (if
       (local.tee $4
        (i32.load
         (local.tee $2
          (i32.load
           (i32.add
            (local.get $0)
            (i32.const 4)
           )
          )
         )
        )
       )
       (then
        (call_indirect $0 (type $2)
         (local.get $1)
         (local.get $4)
        )
       )
      )
      (if
       (i32.load offset=4
        (local.get $2)
       )
       (then
        (call $dlfree
         (local.get $1)
        )
       )
      )
      (call $dlfree
       (local.get $0)
      )
     )
     (i64.store offset=616
      (local.get $5)
      (local.get $8)
     )
     (i64.store offset=608
      (local.get $5)
      (local.get $10)
     )
     (i64.store offset=600
      (local.get $5)
      (local.get $9)
     )
     (i64.store offset=592
      (local.get $5)
      (local.get $11)
     )
     (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
      (i32.add
       (local.get $5)
       (i32.const 624)
      )
      (i32.add
       (local.get $5)
       (i32.const 639)
      )
      (i32.const 1051052)
      (i32.add
       (local.get $5)
       (i32.const 592)
      )
     )
     (br_if $block9
      (i32.ne
       (i32.load8_u offset=624
        (local.get $5)
       )
       (i32.const 3)
      )
     )
     (local.set $1
      (i32.load
       (local.tee $0
        (i32.load offset=628
         (local.get $5)
        )
       )
      )
     )
     (if
      (local.tee $4
       (i32.load
        (local.tee $2
         (i32.load
          (i32.add
           (local.get $0)
           (i32.const 4)
          )
         )
        )
       )
      )
      (then
       (call_indirect $0 (type $2)
        (local.get $1)
        (local.get $4)
       )
      )
     )
     (if
      (i32.load offset=4
       (local.get $2)
      )
      (then
       (call $dlfree
        (local.get $1)
       )
      )
     )
     (call $dlfree
      (local.get $0)
     )
     (br $block9)
    )
    (if
     (i32.ge_u
      (local.tee $0
       (i32.load offset=584
        (local.get $5)
       )
      )
      (i32.const 513)
     )
     (then
      (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
       (i32.const 0)
       (local.get $0)
       (i32.const 512)
       (i32.const 1055096)
      )
      (unreachable)
     )
    )
    (local.set $6
     (i32.add
      (local.get $5)
      (i32.const 592)
     )
    )
    (local.set $4
     (i32.sub
      (local.get $5)
      (i32.const -64)
     )
    )
    (global.set $__stack_pointer
     (local.tee $1
      (i32.sub
       (global.get $__stack_pointer)
       (i32.const 16)
      )
     )
    )
    (block $block13
     (block $block14
      (if
       (local.get $0)
       (then
        (loop $label1
         (block $block10
          (block $block12
           (i64.store align=4
            (local.get $6)
            (i64.load
             (block $block11 (result i32)
              (if
               (i32.eq
                (local.tee $2
                 (call $write
                  (i32.const 2)
                  (local.get $4)
                  (local.get $0)
                 )
                )
                (i32.const -1)
               )
               (then
                (i32.store8 offset=11
                 (local.get $1)
                 (i32.const 0)
                )
                (i32.store16 offset=9 align=1
                 (local.get $1)
                 (i32.const 0)
                )
                (i32.store8 offset=8
                 (local.get $1)
                 (i32.const 0)
                )
                (i32.store offset=12
                 (local.get $1)
                 (local.tee $2
                  (i32.load
                   (i32.const 1061060)
                  )
                 )
                )
                (br_if $block10
                 (i32.eq
                  (local.get $2)
                  (i32.const 27)
                 )
                )
                (br $block11
                 (i32.add
                  (local.get $1)
                  (i32.const 8)
                 )
                )
               )
              )
              (i32.store offset=12
               (local.get $1)
               (local.get $2)
              )
              (i32.store8 offset=8
               (local.get $1)
               (i32.const 4)
              )
              (br_if $block12
               (local.get $2)
              )
              (i32.const 1056624)
             )
            )
           )
           (br $block13)
          )
          (br_if $block14
           (i32.lt_u
            (local.get $0)
            (local.get $2)
           )
          )
          (local.set $4
           (i32.add
            (local.get $2)
            (local.get $4)
           )
          )
          (local.set $0
           (i32.sub
            (local.get $0)
            (local.get $2)
           )
          )
         )
         (br_if $label1
          (local.get $0)
         )
        )
       )
      )
      (i32.store8
       (local.get $6)
       (i32.const 4)
      )
      (br $block13)
     )
     (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
      (local.get $2)
      (local.get $0)
      (local.get $0)
      (i32.const 1057656)
     )
     (unreachable)
    )
    (global.set $__stack_pointer
     (i32.add
      (local.get $1)
      (i32.const 16)
     )
    )
    (br_if $block9
     (i32.ne
      (i32.load8_u offset=592
       (local.get $5)
      )
      (i32.const 3)
     )
    )
    (local.set $1
     (i32.load
      (local.tee $0
       (i32.load offset=596
        (local.get $5)
       )
      )
     )
    )
    (if
     (local.tee $4
      (i32.load
       (local.tee $2
        (i32.load
         (i32.add
          (local.get $0)
          (i32.const 4)
         )
        )
       )
      )
     )
     (then
      (call_indirect $0 (type $2)
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (if
     (i32.load offset=4
      (local.get $2)
     )
     (then
      (call $dlfree
       (local.get $1)
      )
     )
    )
    (call $dlfree
     (local.get $0)
    )
   )
   (block $block17
    (block $block16
     (block $block15
      (block $block18
       (br_table $block15 $block16 $block17 $block18
        (i32.sub
         (local.get $7)
         (i32.const 1)
        )
       )
      )
      (call $_RNvMNtNtCset5xJoy1xWQ_3std3sys9backtraceNtB2_13BacktraceLock5print
       (i32.sub
        (local.get $5)
        (i32.const -64)
       )
       (i32.add
        (local.get $5)
        (i32.const 639)
       )
       (i32.const 0)
      )
      (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
       (i32.load8_u offset=64
        (local.get $5)
       )
       (i32.load offset=68
        (local.get $5)
       )
      )
      (br $block17)
     )
     (call $_RNvMNtNtCset5xJoy1xWQ_3std3sys9backtraceNtB2_13BacktraceLock5print
      (i32.sub
       (local.get $5)
       (i32.const -64)
      )
      (i32.add
       (local.get $5)
       (i32.const 639)
      )
      (i32.const 1)
     )
     (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
      (i32.load8_u offset=64
       (local.get $5)
      )
      (i32.load offset=68
       (local.get $5)
      )
     )
     (br $block17)
    )
    (br_if $block17
     (i32.eqz
      (block (result i32)
       (local.set $scratch_13
        (i32.load8_u
         (i32.const 1060908)
        )
       )
       (i32.store8
        (i32.const 1060908)
        (i32.const 0)
       )
       (local.get $scratch_13)
      )
     )
    )
    (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
     (i32.sub
      (local.get $5)
      (i32.const -64)
     )
     (i32.add
      (local.get $5)
      (i32.const 639)
     )
     (i32.const 1055136)
     (i32.const 157)
    )
    (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
     (i32.load8_u offset=64
      (local.get $5)
     )
     (i32.load offset=68
      (local.get $5)
     )
    )
   )
   (i32.store
    (i32.const 1060940)
    (i32.sub
     (i32.load
      (i32.const 1060940)
     )
     (i32.const 1)
    )
   )
   (i32.store8
    (i32.const 1061056)
    (i32.const 0)
   )
   (i32.store8
    (i32.const 1060936)
    (i32.const 0)
   )
   (if
    (i32.eqz
     (local.get $3)
    )
    (then
     (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
      (i32.sub
       (local.get $5)
       (i32.const -64)
      )
      (i32.add
       (local.get $5)
       (i32.const 639)
      )
      (i32.const 1056492)
      (i32.const 91)
     )
     (call $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_
      (i32.load8_u offset=64
       (local.get $5)
      )
      (i32.load offset=68
       (local.get $5)
      )
     )
     (br $block1)
    )
   )
   (unreachable)
  )
  (unreachable)
 )
 (func $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_ (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32)
  (local $4 i32)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (i32.store8
   (local.get $0)
   (i32.const 4)
  )
  (i32.store offset=24
   (local.get $4)
   (local.get $1)
  )
  (i64.store offset=16
   (local.get $4)
   (i64.load align=4
    (local.get $0)
   )
  )
  (local.set $2
   (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
    (i32.add
     (local.get $4)
     (i32.const 16)
    )
    (i32.const 1054940)
    (local.get $2)
    (local.get $3)
   )
  )
  (local.set $1
   (i32.load8_u offset=16
    (local.get $4)
   )
  )
  (block $block1
   (block $block
    (if
     (local.get $2)
     (then
      (br_if $block
       (i32.ne
        (local.get $1)
        (i32.const 4)
       )
      )
      (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
       (i32.const 1054788)
       (i32.const 173)
       (i32.const 1054876)
      )
      (unreachable)
     )
    )
    (br_if $block1
     (i32.ne
      (local.get $1)
      (i32.const 3)
     )
    )
    (local.set $1
     (i32.load
      (local.tee $0
       (i32.load offset=20
        (local.get $4)
       )
      )
     )
    )
    (if
     (local.tee $3
      (i32.load
       (local.tee $2
        (i32.load
         (i32.add
          (local.get $0)
          (i32.const 4)
         )
        )
       )
      )
     )
     (then
      (call_indirect $0 (type $2)
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (if
     (i32.load offset=4
      (local.get $2)
     )
     (then
      (call $dlfree
       (local.get $1)
      )
     )
    )
    (call $dlfree
     (local.get $0)
    )
    (br $block1)
   )
   (i64.store align=4
    (local.get $0)
    (i64.load offset=16
     (local.get $4)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $4)
    (i32.const 32)
   )
  )
 )
 (func $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNtB4_6result6ResultuNtNtNtCset5xJoy1xWQ_3std2io5error5ErrorEEB19_ (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (if
   (i32.eq
    (i32.and
     (local.get $0)
     (i32.const 255)
    )
    (i32.const 3)
   )
   (then
    (local.set $0
     (i32.load
      (local.get $1)
     )
    )
    (if
     (local.tee $3
      (i32.load
       (local.tee $2
        (i32.load
         (i32.add
          (local.get $1)
          (i32.const 4)
         )
        )
       )
      )
     )
     (then
      (call_indirect $0 (type $2)
       (local.get $0)
       (local.get $3)
      )
     )
    )
    (if
     (i32.load offset=4
      (local.get $2)
     )
     (then
      (call $dlfree
       (local.get $0)
      )
     )
    )
    (call $dlfree
     (local.get $1)
    )
   )
  )
 )
 (func $_RNvXs1i_NtCsdHhIpgkcIfN_4core3fmtRNtNtNtB8_5panic8location8LocationNtB6_7Display3fmtCset5xJoy1xWQ_3std (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (local.set $3
   (i32.load offset=4
    (local.get $1)
   )
  )
  (local.set $scratch
   (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
    (i32.load
     (local.get $1)
    )
    (block (result i32)
     (i64.store align=4
      (local.get $2)
      (i64.load align=4
       (local.tee $0
        (i32.load
         (local.get $0)
        )
       )
      )
     )
     (i64.store offset=24
      (local.get $2)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $0)
         (i32.const 12)
        )
       )
       (i64.const 17179869184)
      )
     )
     (i64.store offset=16
      (local.get $2)
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $0)
         (i32.const 8)
        )
       )
       (i64.const 17179869184)
      )
     )
     (i64.store offset=8
      (local.get $2)
      (i64.or
       (i64.extend_i32_u
        (local.get $2)
       )
       (i64.const 25769803776)
      )
     )
     (local.get $3)
    )
    (i32.const 1048926)
    (i32.add
     (local.get $2)
     (i32.const 8)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 32)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvNtCset5xJoy1xWQ_3std5panic19get_backtrace_style (result i32)
  (local $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 384)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.lt_u
     (i32.and
      (local.tee $1
       (i32.sub
        (i32.load8_u
         (i32.const 1060937)
        )
        (i32.const 1)
       )
      )
      (i32.const 255)
     )
     (i32.const 3)
    )
   )
   (i32.store8 offset=14
    (local.get $3)
    (i32.const 0)
   )
   (i64.store offset=6 align=2
    (local.get $3)
    (i64.load align=1
     (i32.const 1055435)
    )
   )
   (i64.store
    (local.get $3)
    (i64.load align=1
     (i32.const 1055429)
    )
   )
   (local.set $1
    (i32.const 0)
   )
   (local.set $2
    (i32.add
     (local.get $3)
     (local.tee $0
      (select
       (i32.const 8)
       (i32.const 0)
       (i32.eq
        (i32.and
         (i32.or
          (i32.sub
           (i32.const 16843008)
           (local.tee $0
            (i32.load offset=4
             (local.get $3)
            )
           )
          )
          (local.get $0)
         )
         (i32.const -2139062144)
        )
        (i32.const -2139062144)
       )
      )
     )
    )
   )
   (block $block16
    (block $block1
     (loop $label
      (if
       (i32.load8_u
        (i32.add
         (local.get $1)
         (local.get $2)
        )
       )
       (then
        (br_if $label
         (i32.ne
          (i32.xor
           (local.get $0)
           (local.tee $1
            (i32.add
             (local.get $1)
             (i32.const 1)
            )
           )
          )
          (i32.const 15)
         )
        )
        (br $block1)
       )
      )
     )
     (br_if $block1
      (i32.ne
       (i32.add
        (local.get $0)
        (local.get $1)
       )
       (i32.const 14)
      )
     )
     (br_if $block1
      (i32.eqz
       (local.tee $1
        (block $block9 (result i32)
         (if
          (i32.eq
           (i32.load
            (i32.const 1060916)
           )
           (i32.const -1)
          )
          (then
           (global.set $__stack_pointer
            (local.tee $1
             (i32.sub
              (global.get $__stack_pointer)
              (i32.const 16)
             )
            )
           )
           (block $block2
            (if
             (i32.eqz
              (i32.and
               (call $__imported_wasi_snapshot_preview1_environ_sizes_get
                (i32.add
                 (local.get $1)
                 (i32.const 12)
                )
                (i32.add
                 (local.get $1)
                 (i32.const 8)
                )
               )
               (i32.const 65535)
              )
             )
             (then
              (if
               (i32.eqz
                (local.tee $0
                 (i32.load offset=12
                  (local.get $1)
                 )
                )
               )
               (then
                (local.set $0
                 (i32.const 1061088)
                )
                (br $block2)
               )
              )
              (block $block4
               (block $block3
                (br_if $block3
                 (i32.eqz
                  (local.tee $0
                   (i32.add
                    (local.get $0)
                    (i32.const 1)
                   )
                  )
                 )
                )
                (br_if $block3
                 (i32.eqz
                  (local.tee $2
                   (call $dlmalloc
                    (i32.load offset=8
                     (local.get $1)
                    )
                   )
                  )
                 )
                )
                (br_if $block4
                 (local.tee $0
                  (call $calloc
                   (local.get $0)
                   (i32.const 4)
                  )
                 )
                )
                (call $dlfree
                 (local.get $2)
                )
               )
               (call $_Exit
                (i32.const 70)
               )
               (unreachable)
              )
              (br_if $block2
               (i32.eqz
                (i32.and
                 (call $__imported_wasi_snapshot_preview1_environ_get
                  (local.get $0)
                  (local.get $2)
                 )
                 (i32.const 65535)
                )
               )
              )
              (call $dlfree
               (local.get $2)
              )
              (call $dlfree
               (local.get $0)
              )
             )
            )
            (call $_Exit
             (i32.const 71)
            )
            (unreachable)
           )
           (i32.store
            (i32.const 1060916)
            (local.get $0)
           )
           (global.set $__stack_pointer
            (i32.add
             (local.get $1)
             (i32.const 16)
            )
           )
          )
         )
         (drop
          (br_if $block9
           (i32.const 0)
           (i32.eq
            (local.get $3)
            (local.tee $1
             (block $block6 (result i32)
              (block $block7
               (block $block5
                (br_if $block5
                 (i32.eqz
                  (i32.and
                   (local.tee $1
                    (local.get $3)
                   )
                   (i32.const 3)
                  )
                 )
                )
                (drop
                 (br_if $block6
                  (local.get $1)
                  (i32.eqz
                   (local.tee $0
                    (i32.load8_u
                     (local.get $1)
                    )
                   )
                  )
                 )
                )
                (drop
                 (br_if $block6
                  (local.get $1)
                  (i32.eq
                   (local.get $0)
                   (i32.const 61)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (i32.and
                   (local.tee $0
                    (i32.add
                     (local.get $1)
                     (i32.const 1)
                    )
                   )
                   (i32.const 3)
                  )
                 )
                 (then
                  (local.set $1
                   (local.get $0)
                  )
                  (br $block5)
                 )
                )
                (br_if $block7
                 (i32.eqz
                  (local.tee $2
                   (i32.load8_u
                    (local.get $0)
                   )
                  )
                 )
                )
                (br_if $block7
                 (i32.eq
                  (local.get $2)
                  (i32.const 61)
                 )
                )
                (if
                 (i32.eqz
                  (i32.and
                   (local.tee $0
                    (i32.add
                     (local.get $1)
                     (i32.const 2)
                    )
                   )
                   (i32.const 3)
                  )
                 )
                 (then
                  (local.set $1
                   (local.get $0)
                  )
                  (br $block5)
                 )
                )
                (br_if $block7
                 (i32.eqz
                  (local.tee $2
                   (i32.load8_u
                    (local.get $0)
                   )
                  )
                 )
                )
                (br_if $block7
                 (i32.eq
                  (local.get $2)
                  (i32.const 61)
                 )
                )
                (if
                 (i32.eqz
                  (i32.and
                   (local.tee $0
                    (i32.add
                     (local.get $1)
                     (i32.const 3)
                    )
                   )
                   (i32.const 3)
                  )
                 )
                 (then
                  (local.set $1
                   (local.get $0)
                  )
                  (br $block5)
                 )
                )
                (br_if $block7
                 (i32.eqz
                  (local.tee $2
                   (i32.load8_u
                    (local.get $0)
                   )
                  )
                 )
                )
                (br_if $block7
                 (i32.eq
                  (local.get $2)
                  (i32.const 61)
                 )
                )
                (local.set $1
                 (i32.add
                  (local.get $1)
                  (i32.const 4)
                 )
                )
               )
               (block $block8
                (br_if $block8
                 (i32.ne
                  (i32.and
                   (i32.or
                    (i32.sub
                     (i32.const 16843008)
                     (local.tee $0
                      (i32.load
                       (local.get $1)
                      )
                     )
                    )
                    (local.get $0)
                   )
                   (i32.const -2139062144)
                  )
                  (i32.const -2139062144)
                 )
                )
                (loop $label1
                 (br_if $block8
                  (i32.ne
                   (i32.and
                    (i32.or
                     (i32.sub
                      (i32.const 16843008)
                      (local.tee $0
                       (i32.xor
                        (local.get $0)
                        (i32.const 1027423549)
                       )
                      )
                     )
                     (local.get $0)
                    )
                    (i32.const -2139062144)
                   )
                   (i32.const -2139062144)
                  )
                 )
                 (br_if $label1
                  (i32.eq
                   (i32.and
                    (i32.or
                     (i32.sub
                      (i32.const 16843008)
                      (local.tee $0
                       (i32.load
                        (local.tee $1
                         (i32.add
                          (local.get $1)
                          (i32.const 4)
                         )
                        )
                       )
                      )
                     )
                     (local.get $0)
                    )
                    (i32.const -2139062144)
                   )
                   (i32.const -2139062144)
                  )
                 )
                )
               )
               (local.set $0
                (i32.sub
                 (local.get $1)
                 (i32.const 1)
                )
               )
               (loop $label2
                (br_if $block7
                 (i32.eqz
                  (local.tee $1
                   (i32.load8_u
                    (local.tee $0
                     (i32.add
                      (local.get $0)
                      (i32.const 1)
                     )
                    )
                   )
                  )
                 )
                )
                (br_if $label2
                 (i32.ne
                  (local.get $1)
                  (i32.const 61)
                 )
                )
               )
              )
              (local.get $0)
             )
            )
           )
          )
         )
         (block $block10
          (br_if $block10
           (i32.load8_u
            (i32.add
             (local.get $3)
             (local.tee $4
              (i32.sub
               (local.get $1)
               (local.get $3)
              )
             )
            )
           )
          )
          (br_if $block10
           (i32.eqz
            (local.tee $0
             (i32.load
              (i32.const 1060916)
             )
            )
           )
          )
          (br_if $block10
           (i32.eqz
            (local.tee $1
             (i32.load
              (local.get $0)
             )
            )
           )
          )
          (local.set $5
           (i32.add
            (local.get $0)
            (i32.const 4)
           )
          )
          (loop $label4
           (block $block14
            (if
             (i32.eqz
              (block $block11 (result i32)
               (local.set $0
                (local.get $1)
               )
               (drop
                (br_if $block11
                 (i32.const 0)
                 (i32.eqz
                  (local.get $4)
                 )
                )
               )
               (block $block12
                (if
                 (i32.eqz
                  (local.tee $2
                   (i32.load8_u
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (local.set $2
                   (i32.const 0)
                  )
                  (br $block12)
                 )
                )
                (local.set $6
                 (i32.add
                  (local.get $3)
                  (i32.const 1)
                 )
                )
                (local.set $7
                 (i32.sub
                  (local.get $4)
                  (i32.const 1)
                 )
                )
                (block $block13
                 (loop $label3
                  (br_if $block13
                   (i32.ne
                    (local.get $2)
                    (local.tee $8
                     (i32.load8_u
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (br_if $block13
                   (i32.eqz
                    (local.get $8)
                   )
                  )
                  (br_if $block13
                   (i32.eqz
                    (local.get $7)
                   )
                  )
                  (local.set $7
                   (i32.sub
                    (local.get $7)
                    (i32.const 1)
                   )
                  )
                  (local.set $0
                   (i32.add
                    (local.get $0)
                    (i32.const 1)
                   )
                  )
                  (local.set $2
                   (i32.load8_u
                    (local.get $6)
                   )
                  )
                  (local.set $6
                   (i32.add
                    (local.get $6)
                    (i32.const 1)
                   )
                  )
                  (br_if $label3
                   (local.get $2)
                  )
                 )
                 (local.set $2
                  (i32.const 0)
                 )
                )
               )
               (i32.sub
                (local.get $2)
                (i32.load8_u
                 (local.get $0)
                )
               )
              )
             )
             (then
              (br_if $block14
               (i32.eq
                (i32.load8_u
                 (local.tee $1
                  (i32.add
                   (local.get $1)
                   (local.get $4)
                  )
                 )
                )
                (i32.const 61)
               )
              )
             )
            )
            (local.set $1
             (i32.load
              (local.get $5)
             )
            )
            (local.set $5
             (i32.add
              (local.get $5)
              (i32.const 4)
             )
            )
            (br_if $label4
             (local.get $1)
            )
            (br $block10)
           )
          )
          (local.set $9
           (i32.add
            (local.get $1)
            (i32.const 1)
           )
          )
         )
         (local.get $9)
        )
       )
      )
     )
     (block $block15
      (local.set $1
       (block $block22 (result i32)
        (block $block20
         (if
          (local.tee $0
           (call $strlen
            (local.get $1)
           )
          )
          (then
           (br_if $block15
            (i32.eqz
             (local.tee $4
              (call $dlmalloc
               (local.get $0)
              )
             )
            )
           )
           (if
            (local.get $0)
            (then
             (memory.copy
              (local.get $4)
              (local.get $1)
              (local.get $0)
             )
            )
           )
           (local.set $2
            (i32.const 3)
           )
           (local.set $1
            (i32.const 2)
           )
           (block $block18
            (block $block17
             (br_table $block16 $block17 $block18
              (i32.sub
               (local.get $0)
               (i32.const -2147483648)
              )
             )
            )
            (br_if $block16
             (i32.ne
              (i32.and
               (local.get $4)
               (i32.const 255)
              )
              (i32.const 3)
             )
            )
            (local.set $4
             (i32.load
              (local.get $0)
             )
            )
            (if
             (local.tee $6
              (i32.load
               (local.tee $5
                (i32.load
                 (i32.add
                  (local.get $0)
                  (i32.const 4)
                 )
                )
               )
              )
             )
             (then
              (call_indirect $0 (type $2)
               (local.get $4)
               (local.get $6)
              )
             )
            )
            (if
             (i32.load offset=4
              (local.get $5)
             )
             (then
              (call $dlfree
               (local.get $4)
              )
             )
            )
            (call $dlfree
             (local.get $0)
            )
            (br $block16)
           )
           (block $block21
            (block $block19
             (br_table $block19 $block20 $block20 $block21 $block20
              (i32.sub
               (local.get $0)
               (i32.const 1)
              )
             )
            )
            (br_if $block20
             (i32.ne
              (i32.load8_u
               (local.get $4)
              )
              (i32.const 48)
             )
            )
            (br $block22
             (i32.const 2)
            )
           )
           (br_if $block20
            (i32.ne
             (i32.load align=1
              (local.get $4)
             )
             (i32.const 1819047270)
            )
           )
           (local.set $2
            (i32.const 2)
           )
           (br $block22
            (i32.const 1)
           )
          )
         )
         (local.set $2
          (i32.const 1)
         )
         (local.set $1
          (i32.const 0)
         )
         (br $block16)
        )
        (local.set $2
         (i32.const 1)
        )
        (i32.const 0)
       )
      )
      (call $dlfree
       (local.get $4)
      )
      (br $block16)
     )
     (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
      (i32.const 1)
      (local.get $0)
     )
     (unreachable)
    )
    (local.set $2
     (i32.const 3)
    )
    (local.set $1
     (i32.const 2)
    )
   )
   (i32.store8
    (i32.const 1060937)
    (select
     (local.tee $0
      (i32.load8_u
       (i32.const 1060937)
      )
     )
     (local.get $2)
     (local.get $0)
    )
   )
   (br_if $block
    (i32.eqz
     (local.get $0)
    )
   )
   (local.set $1
    (i32.const 3)
   )
   (br_if $block
    (i32.ge_u
     (local.get $0)
     (i32.const 4)
    )
   )
   (local.set $1
    (i32.shr_u
     (i32.const 33619971)
     (i32.and
      (i32.shl
       (local.get $0)
       (i32.const 3)
      )
      (i32.const 248)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 384)
   )
  )
  (local.get $1)
 )
 (func $_RNvNtNtCset5xJoy1xWQ_3std3sys9backtrace4lock
  (local $0 i32)
  (local $1 i32)
  (global.set $__stack_pointer
   (local.tee $0
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $1
   (i32.load8_u
    (i32.const 1061056)
   )
  )
  (i32.store8
   (i32.const 1061056)
   (i32.const 1)
  )
  (i32.store8 offset=15
   (local.get $0)
   (local.get $1)
  )
  (if
   (local.get $1)
   (then
    (call $_RINvNtCsdHhIpgkcIfN_4core9panicking13assert_failedbbECset5xJoy1xWQ_3std
     (i32.add
      (local.get $0)
      (i32.const 15)
     )
    )
    (unreachable)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $0)
    (i32.const 16)
   )
  )
 )
 (func $_RNvMNtNtCset5xJoy1xWQ_3std3sys9backtraceNtB2_13BacktraceLock5print (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store8 offset=7
   (local.get $3)
   (local.get $2)
  )
  (i64.store offset=8
   (local.get $3)
   (i64.or
    (i64.extend_i32_u
     (i32.add
      (local.get $3)
      (i32.const 7)
     )
    )
    (i64.const 81604378624)
   )
  )
  (call $_RNvYNtNtNtNtCset5xJoy1xWQ_3std3sys5stdio4unix6StderrNtNtBa_2io5Write9write_fmtBa_
   (local.get $0)
   (local.get $1)
   (i32.const 1049279)
   (i32.add
    (local.get $3)
    (i32.const 8)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
 )
 (func $_RNvXs1g_NtCsdHhIpgkcIfN_4core3fmtRbNtB6_5Debug3fmtCset5xJoy1xWQ_3std (param $0 i32) (param $1 i32) (result i32)
  (if
   (i32.eqz
    (i32.load8_u
     (i32.load
      (local.get $0)
     )
    )
   )
   (then
    (return
     (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter3pad
      (local.get $1)
      (i32.const 1054534)
      (i32.const 5)
     )
    )
   )
  )
  (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter3pad
   (local.get $1)
   (i32.const 1054539)
   (i32.const 4)
  )
 )
 (func $_RNvXNvMNtNtCset5xJoy1xWQ_3std3sys9backtraceNtB5_13BacktraceLock5printNtB2_16DisplayBacktraceNtNtCsdHhIpgkcIfN_4core3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i64)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $8
   (i32.load offset=4
    (local.get $1)
   )
  )
  (local.set $7
   (i32.load
    (local.get $1)
   )
  )
  (local.set $9
   (i32.load8_u
    (local.get $0)
   )
  )
  (local.set $1
   (i32.const 512)
  )
  (block $block6
   (block $block8
    (block $block7
     (if
      (local.tee $0
       (call $dlmalloc
        (i32.const 512)
       )
      )
      (then
       (i32.store offset=8
        (local.get $5)
        (local.get $0)
       )
       (i32.store offset=4
        (local.get $5)
        (i32.const 512)
       )
       (block $block5
        (loop $label2
         (br_if $block5
          (block $block1 (result i32)
           (local.set $2
            (i32.load
             (i32.const 1060912)
            )
           )
           (block $block
            (if
             (i32.eqz
              (local.get $0)
             )
             (then
              (br_if $block
               (local.tee $2
                (call $strdup
                 (local.get $2)
                )
               )
              )
              (i32.store
               (i32.const 1061060)
               (i32.const 48)
              )
              (br $block1
               (i32.const 0)
              )
             )
            )
            (if
             (i32.gt_u
              (i32.add
               (call $strlen
                (local.get $2)
               )
               (i32.const 1)
              )
              (local.get $1)
             )
             (then
              (i32.store
               (i32.const 1061060)
               (i32.const 68)
              )
              (br $block1
               (i32.const 0)
              )
             )
            )
            (block $block4
             (block $block2
              (if
               (i32.and
                (i32.xor
                 (local.get $2)
                 (local.tee $4
                  (local.get $0)
                 )
                )
                (i32.const 3)
               )
               (then
                (local.set $3
                 (i32.load8_u
                  (local.get $2)
                 )
                )
                (br $block2)
               )
              )
              (block $block3
               (br_if $block3
                (i32.eqz
                 (i32.and
                  (local.get $2)
                  (i32.const 3)
                 )
                )
               )
               (i32.store8
                (local.get $4)
                (local.tee $3
                 (i32.load8_u
                  (local.get $2)
                 )
                )
               )
               (br_if $block4
                (i32.eqz
                 (local.get $3)
                )
               )
               (local.set $3
                (i32.add
                 (local.get $4)
                 (i32.const 1)
                )
               )
               (if
                (i32.eqz
                 (i32.and
                  (local.tee $6
                   (i32.add
                    (local.get $2)
                    (i32.const 1)
                   )
                  )
                  (i32.const 3)
                 )
                )
                (then
                 (local.set $4
                  (local.get $3)
                 )
                 (local.set $2
                  (local.get $6)
                 )
                 (br $block3)
                )
               )
               (i32.store8
                (local.get $3)
                (local.tee $3
                 (i32.load8_u
                  (local.get $6)
                 )
                )
               )
               (br_if $block4
                (i32.eqz
                 (local.get $3)
                )
               )
               (local.set $3
                (i32.add
                 (local.get $4)
                 (i32.const 2)
                )
               )
               (if
                (i32.eqz
                 (i32.and
                  (local.tee $6
                   (i32.add
                    (local.get $2)
                    (i32.const 2)
                   )
                  )
                  (i32.const 3)
                 )
                )
                (then
                 (local.set $4
                  (local.get $3)
                 )
                 (local.set $2
                  (local.get $6)
                 )
                 (br $block3)
                )
               )
               (i32.store8
                (local.get $3)
                (local.tee $3
                 (i32.load8_u
                  (local.get $6)
                 )
                )
               )
               (br_if $block4
                (i32.eqz
                 (local.get $3)
                )
               )
               (local.set $3
                (i32.add
                 (local.get $4)
                 (i32.const 3)
                )
               )
               (if
                (i32.eqz
                 (i32.and
                  (local.tee $6
                   (i32.add
                    (local.get $2)
                    (i32.const 3)
                   )
                  )
                  (i32.const 3)
                 )
                )
                (then
                 (local.set $4
                  (local.get $3)
                 )
                 (local.set $2
                  (local.get $6)
                 )
                 (br $block3)
                )
               )
               (i32.store8
                (local.get $3)
                (local.tee $3
                 (i32.load8_u
                  (local.get $6)
                 )
                )
               )
               (br_if $block4
                (i32.eqz
                 (local.get $3)
                )
               )
               (local.set $4
                (i32.add
                 (local.get $4)
                 (i32.const 4)
                )
               )
               (local.set $2
                (i32.add
                 (local.get $2)
                 (i32.const 4)
                )
               )
              )
              (br_if $block2
               (i32.ne
                (i32.and
                 (i32.or
                  (i32.sub
                   (i32.const 16843008)
                   (local.tee $3
                    (i32.load
                     (local.get $2)
                    )
                   )
                  )
                  (local.get $3)
                 )
                 (i32.const -2139062144)
                )
                (i32.const -2139062144)
               )
              )
              (loop $label
               (i32.store
                (local.get $4)
                (local.get $3)
               )
               (local.set $4
                (i32.add
                 (local.get $4)
                 (i32.const 4)
                )
               )
               (br_if $label
                (i32.eq
                 (i32.and
                  (i32.or
                   (i32.sub
                    (i32.const 16843008)
                    (local.tee $3
                     (i32.load
                      (local.tee $2
                       (i32.add
                        (local.get $2)
                        (i32.const 4)
                       )
                      )
                     )
                    )
                   )
                   (local.get $3)
                  )
                  (i32.const -2139062144)
                 )
                 (i32.const -2139062144)
                )
               )
              )
             )
             (i32.store8
              (local.get $4)
              (local.get $3)
             )
             (br_if $block4
              (i32.eqz
               (i32.and
                (local.get $3)
                (i32.const 255)
               )
              )
             )
             (local.set $3
              (i32.add
               (local.get $2)
               (i32.const 1)
              )
             )
             (loop $label1
              (i32.store8
               (local.tee $4
                (i32.add
                 (local.get $4)
                 (i32.const 1)
                )
               )
               (local.tee $2
                (i32.load8_u
                 (local.get $3)
                )
               )
              )
              (local.set $3
               (i32.add
                (local.get $3)
                (i32.const 1)
               )
              )
              (br_if $label1
               (local.get $2)
              )
             )
            )
            (local.set $2
             (local.get $0)
            )
           )
           (local.get $2)
          )
         )
         (if
          (i32.eq
           (local.tee $2
            (i32.load
             (i32.const 1061060)
            )
           )
           (i32.const 68)
          )
          (then
           (i32.store offset=12
            (local.get $5)
            (local.get $1)
           )
           (call $_RINvNvMs2_NtCsi9YzqDQQz2q_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECset5xJoy1xWQ_3std
            (i32.add
             (local.get $5)
             (i32.const 4)
            )
            (local.get $1)
            (i32.const 1)
           )
           (local.set $0
            (i32.load offset=8
             (local.get $5)
            )
           )
           (local.set $1
            (i32.load offset=4
             (local.get $5)
            )
           )
           (br $label2)
          )
         )
        )
        (local.set $10
         (i64.shl
          (i64.extend_i32_u
           (local.get $2)
          )
          (i64.const 32)
         )
        )
        (if
         (local.get $1)
         (then
          (call $dlfree
           (local.get $0)
          )
         )
        )
        (local.set $1
         (i32.const -2147483648)
        )
        (br $block6)
       )
       (i32.store offset=12
        (local.get $5)
        (local.tee $2
         (call $strlen
          (local.get $0)
         )
        )
       )
       (br_if $block7
        (i32.gt_u
         (local.get $1)
         (local.get $2)
        )
       )
       (br $block8)
      )
     )
     (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
      (i32.const 1)
      (i32.const 512)
     )
     (unreachable)
    )
    (block $block9
     (if
      (i32.eqz
       (local.get $2)
      )
      (then
       (call $dlfree
        (local.get $0)
       )
       (local.set $1
        (i32.const 1)
       )
       (br $block9)
      )
     )
     (br_if $block9
      (local.tee $1
       (call $realloc
        (local.get $0)
        (local.get $2)
       )
      )
     )
     (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
      (i32.const 1)
      (local.get $2)
     )
     (unreachable)
    )
    (i32.store offset=8
     (local.get $5)
     (local.get $1)
    )
    (local.set $1
     (local.get $2)
    )
   )
   (local.set $10
    (i64.load offset=8 align=4
     (local.get $5)
    )
   )
  )
  (block $block10
   (br_if $block10
    (i32.ne
     (local.get $1)
     (i32.const -2147483648)
    )
   )
   (br_if $block10
    (i64.ne
     (i64.and
      (local.get $10)
      (i64.const 255)
     )
     (i64.const 3)
    )
   )
   (local.set $2
    (i32.load
     (local.tee $0
      (i32.wrap_i64
       (i64.shr_u
        (local.get $10)
        (i64.const 32)
       )
      )
     )
    )
   )
   (if
    (local.tee $3
     (i32.load
      (local.tee $4
       (i32.load
        (i32.add
         (local.get $0)
         (i32.const 4)
        )
       )
      )
     )
    )
    (then
     (call_indirect $0 (type $2)
      (local.get $2)
      (local.get $3)
     )
    )
   )
   (if
    (i32.load offset=4
     (local.get $4)
    )
    (then
     (call $dlfree
      (local.get $2)
     )
    )
   )
   (call $dlfree
    (local.get $0)
   )
  )
  (block $block13
   (block $block12
    (block $block11
     (if
      (i32.eqz
       (call_indirect $0 (type $0)
        (local.get $7)
        (i32.const 1056632)
        (i32.const 17)
        (local.tee $0
         (i32.load offset=12
          (local.get $8)
         )
        )
       )
      )
      (then
       (br_if $block11
        (i32.and
         (local.get $9)
         (i32.const 1)
        )
       )
       (br_if $block11
        (i32.eqz
         (call_indirect $0 (type $0)
          (local.get $7)
          (i32.const 1056649)
          (i32.const 88)
          (local.get $0)
         )
        )
       )
      )
     )
     (local.set $0
      (i32.const 1)
     )
     (br_if $block12
      (i32.gt_s
       (local.get $1)
       (i32.const 0)
      )
     )
     (br $block13)
    )
    (local.set $0
     (i32.const 0)
    )
    (br_if $block13
     (i32.le_s
      (local.get $1)
      (i32.const 0)
     )
    )
   )
   (call $dlfree
    (i32.wrap_i64
     (local.get $10)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
  )
  (local.get $0)
 )
 (func $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterINtNtBL_6cursor6CursorQShEEEBN_ (param $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (if
   (i32.eq
    (i32.load8_u
     (local.get $0)
    )
    (i32.const 3)
   )
   (then
    (local.set $1
     (i32.load
      (local.tee $0
       (i32.load offset=4
        (local.get $0)
       )
      )
     )
    )
    (if
     (local.tee $3
      (i32.load
       (local.tee $2
        (i32.load
         (i32.add
          (local.get $0)
          (i32.const 4)
         )
        )
       )
      )
     )
     (then
      (call_indirect $0 (type $2)
       (local.get $1)
       (local.get $3)
      )
     )
    )
    (if
     (i32.load offset=4
      (local.get $2)
     )
     (then
      (call $dlfree
       (local.get $1)
      )
     )
    )
    (call $dlfree
     (local.get $0)
    )
   )
  )
 )
 (func $_RNvXNvNtCset5xJoy1xWQ_3std2io17default_write_fmtINtB2_7AdapterINtNtB4_6cursor6CursorQShEENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_strB6_ (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (if
   (local.tee $8
    (select
     (local.tee $7
      (select
       (local.tee $7
        (i32.sub
         (local.tee $6
          (i32.load offset=4
           (local.tee $5
            (i32.load offset=8
             (local.get $0)
            )
           )
          )
         )
         (i32.wrap_i64
          (select
           (i64.const 4294967295)
           (local.tee $3
            (i64.load offset=8
             (local.get $5)
            )
           )
           (i64.ge_u
            (local.get $3)
            (i64.const 4294967295)
           )
          )
         )
        )
       )
       (i32.const 0)
       (i32.ge_u
        (local.get $6)
        (local.get $7)
       )
      )
     )
     (local.get $2)
     (i32.gt_u
      (local.get $2)
      (local.get $7)
     )
    )
   )
   (then
    (memory.copy
     (i32.add
      (i32.load
       (local.get $5)
      )
      (i32.wrap_i64
       (select
        (local.get $3)
        (local.tee $4
         (i64.extend_i32_u
          (local.get $6)
         )
        )
        (i64.lt_u
         (local.get $3)
         (local.get $4)
        )
       )
      )
     )
     (local.get $1)
     (local.get $8)
    )
   )
  )
  (i64.store offset=8
   (local.get $5)
   (i64.add
    (local.get $3)
    (i64.extend_i32_u
     (local.get $8)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.le_u
     (local.get $2)
     (local.get $7)
    )
   )
   (br_if $block
    (i64.eq
     (i64.and
      (local.tee $3
       (i64.load
        (i32.const 1056624)
       )
      )
      (i64.const 255)
     )
     (i64.const 4)
    )
   )
   (if
    (i32.eq
     (i32.load8_u
      (local.get $0)
     )
     (i32.const 3)
    )
    (then
     (local.set $2
      (i32.load
       (local.tee $1
        (i32.load offset=4
         (local.get $0)
        )
       )
      )
     )
     (if
      (local.tee $6
       (i32.load
        (local.tee $5
         (i32.load
          (i32.add
           (local.get $1)
           (i32.const 4)
          )
         )
        )
       )
      )
      (then
       (call_indirect $0 (type $2)
        (local.get $2)
        (local.get $6)
       )
      )
     )
     (if
      (i32.load offset=4
       (local.get $5)
      )
      (then
       (call $dlfree
        (local.get $2)
       )
      )
     )
     (call $dlfree
      (local.get $1)
     )
    )
   )
   (i64.store align=4
    (local.get $0)
    (local.get $3)
   )
   (local.set $9
    (i32.const 1)
   )
  )
  (local.get $9)
 )
 (func $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterINtNtB7_6cursor6CursorQShEENtNtCsdHhIpgkcIfN_4core3fmt5Write10write_charB9_ (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i64)
  (local $9 i64)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=12
   (local.get $2)
   (i32.const 0)
  )
  (local.set $1
   (block $block (result i32)
    (if
     (i32.ge_u
      (local.get $1)
      (i32.const 128)
     )
     (then
      (local.set $3
       (i32.or
        (i32.and
         (local.get $1)
         (i32.const 63)
        )
        (i32.const -128)
       )
      )
      (local.set $4
       (i32.shr_u
        (local.get $1)
        (i32.const 6)
       )
      )
      (if
       (i32.lt_u
        (local.get $1)
        (i32.const 2048)
       )
       (then
        (i32.store8 offset=13
         (local.get $2)
         (local.get $3)
        )
        (i32.store8 offset=12
         (local.get $2)
         (i32.or
          (local.get $4)
          (i32.const 192)
         )
        )
        (br $block
         (i32.const 2)
        )
       )
      )
      (local.set $5
       (i32.shr_u
        (local.get $1)
        (i32.const 12)
       )
      )
      (local.set $4
       (i32.or
        (i32.and
         (local.get $4)
         (i32.const 63)
        )
        (i32.const -128)
       )
      )
      (if
       (i32.le_u
        (local.get $1)
        (i32.const 65535)
       )
       (then
        (i32.store8 offset=14
         (local.get $2)
         (local.get $3)
        )
        (i32.store8 offset=13
         (local.get $2)
         (local.get $4)
        )
        (i32.store8 offset=12
         (local.get $2)
         (i32.or
          (local.get $5)
          (i32.const 224)
         )
        )
        (br $block
         (i32.const 3)
        )
       )
      )
      (i32.store8 offset=15
       (local.get $2)
       (local.get $3)
      )
      (i32.store8 offset=14
       (local.get $2)
       (local.get $4)
      )
      (i32.store8 offset=13
       (local.get $2)
       (i32.or
        (i32.and
         (local.get $5)
         (i32.const 63)
        )
        (i32.const -128)
       )
      )
      (i32.store8 offset=12
       (local.get $2)
       (i32.or
        (i32.shr_u
         (local.get $1)
         (i32.const 18)
        )
        (i32.const -16)
       )
      )
      (br $block
       (i32.const 4)
      )
     )
    )
    (i32.store8 offset=12
     (local.get $2)
     (local.get $1)
    )
    (i32.const 1)
   )
  )
  (local.set $4
   (i32.const 0)
  )
  (if
   (local.tee $7
    (select
     (local.tee $6
      (select
       (local.tee $6
        (i32.sub
         (local.tee $5
          (i32.load offset=4
           (local.tee $3
            (i32.load offset=8
             (local.get $0)
            )
           )
          )
         )
         (i32.wrap_i64
          (select
           (i64.const 4294967295)
           (local.tee $8
            (i64.load offset=8
             (local.get $3)
            )
           )
           (i64.ge_u
            (local.get $8)
            (i64.const 4294967295)
           )
          )
         )
        )
       )
       (i32.const 0)
       (i32.ge_u
        (local.get $5)
        (local.get $6)
       )
      )
     )
     (local.get $1)
     (i32.gt_u
      (local.get $1)
      (local.get $6)
     )
    )
   )
   (then
    (memory.copy
     (i32.add
      (i32.load
       (local.get $3)
      )
      (i32.wrap_i64
       (select
        (local.get $8)
        (local.tee $9
         (i64.extend_i32_u
          (local.get $5)
         )
        )
        (i64.lt_u
         (local.get $8)
         (local.get $9)
        )
       )
      )
     )
     (i32.add
      (local.get $2)
      (i32.const 12)
     )
     (local.get $7)
    )
   )
  )
  (i64.store offset=8
   (local.get $3)
   (i64.add
    (local.get $8)
    (i64.extend_i32_u
     (local.get $7)
    )
   )
  )
  (block $block1
   (br_if $block1
    (i32.le_u
     (local.get $1)
     (local.get $6)
    )
   )
   (br_if $block1
    (i64.eq
     (i64.and
      (local.tee $8
       (i64.load
        (i32.const 1056624)
       )
      )
      (i64.const 255)
     )
     (i64.const 4)
    )
   )
   (if
    (i32.eq
     (i32.load8_u
      (local.get $0)
     )
     (i32.const 3)
    )
    (then
     (local.set $3
      (i32.load
       (local.tee $1
        (i32.load offset=4
         (local.get $0)
        )
       )
      )
     )
     (if
      (local.tee $5
       (i32.load
        (local.tee $4
         (i32.load
          (i32.add
           (local.get $1)
           (i32.const 4)
          )
         )
        )
       )
      )
      (then
       (call_indirect $0 (type $2)
        (local.get $3)
        (local.get $5)
       )
      )
     )
     (if
      (i32.load offset=4
       (local.get $4)
      )
      (then
       (call $dlfree
        (local.get $3)
       )
      )
     )
     (call $dlfree
      (local.get $1)
     )
    )
   )
   (i64.store align=4
    (local.get $0)
    (local.get $8)
   )
   (local.set $4
    (i32.const 1)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
  (local.get $4)
 )
 (func $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterINtNtB7_6cursor6CursorQShEENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtB9_ (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
   (local.get $0)
   (i32.const 1054764)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $_RNvXNvNtCset5xJoy1xWQ_3std2io17default_write_fmtINtB2_7AdapterNtNtNtNtB6_3sys5stdio4unix6StderrENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_strB6_ (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $scratch
   (block $block (result i32)
    (drop
     (br_if $block
      (i32.const 0)
      (i32.eqz
       (local.get $2)
      )
     )
    )
    (block $block2
     (block $block3
      (loop $label
       (block $block1
        (if
         (i32.eq
          (local.tee $3
           (call $write
            (i32.const 2)
            (local.get $1)
            (local.get $2)
           )
          )
          (i32.const -1)
         )
         (then
          (i32.store8 offset=11
           (local.get $4)
           (i32.const 0)
          )
          (i32.store16 offset=9 align=1
           (local.get $4)
           (i32.const 0)
          )
          (i32.store8 offset=8
           (local.get $4)
           (i32.const 0)
          )
          (i32.store offset=12
           (local.get $4)
           (local.tee $3
            (i32.load
             (i32.const 1061060)
            )
           )
          )
          (br_if $block1
           (i32.eq
            (local.get $3)
            (i32.const 27)
           )
          )
          (local.set $1
           (i32.add
            (local.get $4)
            (i32.const 8)
           )
          )
          (br $block2)
         )
        )
        (i32.store offset=12
         (local.get $4)
         (local.get $3)
        )
        (i32.store8 offset=8
         (local.get $4)
         (i32.const 4)
        )
        (if
         (i32.eqz
          (local.get $3)
         )
         (then
          (local.set $1
           (i32.const 1056624)
          )
          (br $block2)
         )
        )
        (br_if $block3
         (i32.lt_u
          (local.get $2)
          (local.get $3)
         )
        )
        (local.set $1
         (i32.add
          (local.get $1)
          (local.get $3)
         )
        )
        (local.set $2
         (i32.sub
          (local.get $2)
          (local.get $3)
         )
        )
       )
       (br_if $label
        (local.get $2)
       )
      )
      (br $block
       (i32.const 0)
      )
     )
     (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
      (local.get $3)
      (local.get $2)
      (local.get $2)
      (i32.const 1057656)
     )
     (unreachable)
    )
    (drop
     (br_if $block
      (i32.const 0)
      (i64.eq
       (i64.and
        (local.tee $6
         (i64.load
          (local.get $1)
         )
        )
        (i64.const 255)
       )
       (i64.const 4)
      )
     )
    )
    (if
     (i32.eq
      (i32.load8_u
       (local.get $0)
      )
      (i32.const 3)
     )
     (then
      (local.set $2
       (i32.load
        (local.tee $1
         (i32.load offset=4
          (local.get $0)
         )
        )
       )
      )
      (if
       (local.tee $5
        (i32.load
         (local.tee $3
          (i32.load
           (i32.add
            (local.get $1)
            (i32.const 4)
           )
          )
         )
        )
       )
       (then
        (call_indirect $0 (type $2)
         (local.get $2)
         (local.get $5)
        )
       )
      )
      (if
       (i32.load offset=4
        (local.get $3)
       )
       (then
        (call $dlfree
         (local.get $2)
        )
       )
      )
      (call $dlfree
       (local.get $1)
      )
     )
    )
    (i64.store align=4
     (local.get $0)
     (local.get $6)
    )
    (i32.const 1)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $4)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtNtNtB9_3sys5stdio4unix6StderrENtNtCsdHhIpgkcIfN_4core3fmt5Write10write_charB9_ (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=12
   (local.get $2)
   (i32.const 0)
  )
  (local.set $scratch
   (call $_RNvXNvNtCset5xJoy1xWQ_3std2io17default_write_fmtINtB2_7AdapterNtNtNtNtB6_3sys5stdio4unix6StderrENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_strB6_
    (local.get $0)
    (i32.add
     (local.get $2)
     (i32.const 12)
    )
    (block $block (result i32)
     (if
      (i32.ge_u
       (local.get $1)
       (i32.const 128)
      )
      (then
       (local.set $3
        (i32.or
         (i32.and
          (local.get $1)
          (i32.const 63)
         )
         (i32.const -128)
        )
       )
       (local.set $0
        (i32.shr_u
         (local.get $1)
         (i32.const 6)
        )
       )
       (if
        (i32.lt_u
         (local.get $1)
         (i32.const 2048)
        )
        (then
         (i32.store8 offset=13
          (local.get $2)
          (local.get $3)
         )
         (i32.store8 offset=12
          (local.get $2)
          (i32.or
           (local.get $0)
           (i32.const 192)
          )
         )
         (br $block
          (i32.const 2)
         )
        )
       )
       (local.set $4
        (i32.shr_u
         (local.get $1)
         (i32.const 12)
        )
       )
       (local.set $0
        (i32.or
         (i32.and
          (local.get $0)
          (i32.const 63)
         )
         (i32.const -128)
        )
       )
       (if
        (i32.le_u
         (local.get $1)
         (i32.const 65535)
        )
        (then
         (i32.store8 offset=14
          (local.get $2)
          (local.get $3)
         )
         (i32.store8 offset=13
          (local.get $2)
          (local.get $0)
         )
         (i32.store8 offset=12
          (local.get $2)
          (i32.or
           (local.get $4)
           (i32.const 224)
          )
         )
         (br $block
          (i32.const 3)
         )
        )
       )
       (i32.store8 offset=15
        (local.get $2)
        (local.get $3)
       )
       (i32.store8 offset=14
        (local.get $2)
        (local.get $0)
       )
       (i32.store8 offset=13
        (local.get $2)
        (i32.or
         (i32.and
          (local.get $4)
          (i32.const 63)
         )
         (i32.const -128)
        )
       )
       (i32.store8 offset=12
        (local.get $2)
        (i32.or
         (i32.shr_u
          (local.get $1)
          (i32.const 18)
         )
         (i32.const -16)
        )
       )
       (br $block
        (i32.const 4)
       )
      )
     )
     (i32.store8 offset=12
      (local.get $2)
      (local.get $1)
     )
     (i32.const 1)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtNtNtB9_3sys5stdio4unix6StderrENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtB9_ (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
   (local.get $0)
   (i32.const 1054940)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $_RNvYINtNvNtCset5xJoy1xWQ_3std9panicking11begin_panic7PayloadReENtNtCsdHhIpgkcIfN_4core5panic12PanicPayload6as_strB9_ (param $0 i32) (param $1 i32)
  (i32.store
   (local.get $0)
   (i32.const 0)
  )
 )
 (func $_RNvXNtCsdHhIpgkcIfN_4core3anyReNtB2_3Any7type_idCset5xJoy1xWQ_3std (param $0 i32) (param $1 i32)
  (i64.store offset=8 align=4
   (local.get $0)
   (i64.load align=4
    (i32.const 1055348)
   )
  )
  (i64.store align=4
   (local.get $0)
   (i64.load align=4
    (i32.const 1055340)
   )
  )
 )
 (func $_RINvMs5_NtNtCset5xJoy1xWQ_3std2io5errorNtB6_5Error3newReEBa_ (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (block $block1
   (block $block
    (if
     (local.tee $3
      (call $dlmalloc
       (local.get $2)
      )
     )
     (then
      (if
       (local.get $2)
       (then
        (memory.copy
         (local.get $3)
         (local.get $1)
         (local.get $2)
        )
       )
      )
      (br_if $block
       (i32.eqz
        (local.tee $1
         (call $dlmalloc
          (i32.const 12)
         )
        )
       )
      )
      (i32.store offset=8
       (local.get $1)
       (local.get $2)
      )
      (i32.store offset=4
       (local.get $1)
       (local.get $3)
      )
      (i32.store
       (local.get $1)
       (local.get $2)
      )
      (br_if $block1
       (i32.eqz
        (local.tee $2
         (call $dlmalloc
          (i32.const 12)
         )
        )
       )
      )
      (i32.store8 offset=8
       (local.get $2)
       (i32.const 20)
      )
      (i32.store offset=4
       (local.get $2)
       (i32.const 1057596)
      )
      (i32.store
       (local.get $2)
       (local.get $1)
      )
      (i64.store align=4
       (local.get $0)
       (i64.or
        (i64.shl
         (i64.extend_i32_u
          (local.get $2)
         )
         (i64.const 32)
        )
        (i64.const 3)
       )
      )
      (return)
     )
    )
    (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
     (i32.const 1)
     (local.get $2)
    )
    (unreachable)
   )
   (call $_RNvNtCsi9YzqDQQz2q_5alloc5alloc18handle_alloc_error
    (i32.const 4)
    (i32.const 12)
   )
   (unreachable)
  )
  (call $_RNvNtCsi9YzqDQQz2q_5alloc5alloc18handle_alloc_error
   (i32.const 4)
   (i32.const 12)
  )
  (unreachable)
 )
 (func $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBQ_3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1W_4SendEL_EINtNtB4_7convert4FromNtNtBS_6string6StringE4from11StringErrorECset5xJoy1xWQ_3std (param $0 i32)
  (if
   (i32.load
    (local.get $0)
   )
   (then
    (call $dlfree
     (i32.load offset=4
      (local.get $0)
     )
    )
   )
  )
 )
 (func $_RNvYNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBc_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_7type_idCset5xJoy1xWQ_3std (param $0 i32) (param $1 i32)
  (i64.store offset=8 align=4
   (local.get $0)
   (i64.load align=4
    (i32.const 1057720)
   )
  )
  (i64.store align=4
   (local.get $0)
   (i64.load align=4
    (i32.const 1057712)
   )
  )
 )
 (func $_RNvYNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBc_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_11descriptionCset5xJoy1xWQ_3std (param $0 i32) (param $1 i32)
  (i32.store offset=4
   (local.get $0)
   (i32.const 40)
  )
  (i32.store
   (local.get $0)
   (i32.const 1057672)
  )
 )
 (func $_RNvYNtNvXsf_NtNtCsi9YzqDQQz2q_5alloc5boxed7convertINtBc_3BoxDNtNtCsdHhIpgkcIfN_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_7provideCset5xJoy1xWQ_3std (param $0 i32) (param $1 i32) (param $2 i32)
  (unreachable)
 )
 (func $_RINvNtCsdHhIpgkcIfN_4core3ptr13drop_in_placeNtNvNtCset5xJoy1xWQ_3std9panicking13panic_handler19FormatStringPayloadEBM_ (param $0 i32)
  (if
   (i32.gt_s
    (i32.load
     (local.get $0)
    )
    (i32.const 0)
   )
   (then
    (call $dlfree
     (i32.load offset=4
      (local.get $0)
     )
    )
   )
  )
 )
 (func $_RNvXs0_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_19FormatStringPayloadNtNtCsdHhIpgkcIfN_4core3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (if
   (i32.ne
    (i32.load
     (local.get $0)
    )
    (i32.const -2147483648)
   )
   (then
    (return
     (call_indirect $0 (type $0)
      (i32.load
       (local.get $1)
      )
      (i32.load offset=4
       (local.get $0)
      )
      (i32.load offset=8
       (local.get $0)
      )
      (i32.load offset=12
       (i32.load offset=4
        (local.get $1)
       )
      )
     )
    )
   )
  )
  (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
   (i32.load
    (local.get $1)
   )
   (i32.load offset=4
    (local.get $1)
   )
   (i32.load
    (local.tee $0
     (i32.load
      (i32.load offset=12
       (local.get $0)
      )
     )
    )
   )
   (i32.load offset=4
    (local.get $0)
   )
  )
 )
 (func $_RNvXs_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload8take_box (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 48)
    )
   )
  )
  (if
   (i32.eq
    (i32.load
     (local.get $1)
    )
    (i32.const -2147483648)
   )
   (then
    (local.set $3
     (i32.load offset=12
      (local.get $1)
     )
    )
    (i32.store offset=44
     (local.get $2)
     (i32.const 0)
    )
    (i64.store offset=36 align=4
     (local.get $2)
     (i64.const 4294967296)
    )
    (drop
     (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
      (i32.add
       (local.get $2)
       (i32.const 36)
      )
      (i32.const 1055112)
      (i32.load
       (local.tee $3
        (i32.load
         (local.get $3)
        )
       )
      )
      (i32.load offset=4
       (local.get $3)
      )
     )
    )
    (i32.store offset=32
     (local.get $2)
     (local.tee $3
      (i32.load offset=44
       (local.get $2)
      )
     )
    )
    (i64.store offset=24
     (local.get $2)
     (local.tee $4
      (i64.load offset=36 align=4
       (local.get $2)
      )
     )
    )
    (i32.store offset=8
     (local.get $1)
     (local.get $3)
    )
    (i64.store align=4
     (local.get $1)
     (local.get $4)
    )
   )
  )
  (local.set $3
   (i32.load offset=8
    (local.get $1)
   )
  )
  (i32.store offset=8
   (local.get $1)
   (i32.const 0)
  )
  (local.set $4
   (i64.load align=4
    (local.get $1)
   )
  )
  (i64.store align=4
   (local.get $1)
   (i64.const 4294967296)
  )
  (i32.store offset=16
   (local.get $2)
   (local.get $3)
  )
  (i64.store offset=8
   (local.get $2)
   (local.get $4)
  )
  (if
   (i32.eqz
    (local.tee $1
     (call $dlmalloc
      (i32.const 12)
     )
    )
   )
   (then
    (call $_RNvNtCsi9YzqDQQz2q_5alloc5alloc18handle_alloc_error
     (i32.const 4)
     (i32.const 12)
    )
    (unreachable)
   )
  )
  (i32.store offset=8
   (local.get $1)
   (i32.load offset=16
    (local.get $2)
   )
  )
  (i64.store align=4
   (local.get $1)
   (i64.load offset=8
    (local.get $2)
   )
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 1057000)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 48)
   )
  )
 )
 (func $_RNvXs_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload3get (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (if
   (i32.eq
    (i32.load
     (local.get $1)
    )
    (i32.const -2147483648)
   )
   (then
    (local.set $3
     (i32.load offset=12
      (local.get $1)
     )
    )
    (i32.store offset=28
     (local.get $2)
     (i32.const 0)
    )
    (i64.store offset=20 align=4
     (local.get $2)
     (i64.const 4294967296)
    )
    (drop
     (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
      (i32.add
       (local.get $2)
       (i32.const 20)
      )
      (i32.const 1055112)
      (i32.load
       (local.tee $3
        (i32.load
         (local.get $3)
        )
       )
      )
      (i32.load offset=4
       (local.get $3)
      )
     )
    )
    (i32.store offset=16
     (local.get $2)
     (local.tee $3
      (i32.load offset=28
       (local.get $2)
      )
     )
    )
    (i64.store offset=8
     (local.get $2)
     (local.tee $4
      (i64.load offset=20 align=4
       (local.get $2)
      )
     )
    )
    (i32.store offset=8
     (local.get $1)
     (local.get $3)
    )
    (i64.store align=4
     (local.get $1)
     (local.get $4)
    )
   )
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 1057000)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 32)
   )
  )
 )
 (func $_RNvXNtCsdHhIpgkcIfN_4core3anyNtNtCsi9YzqDQQz2q_5alloc6string6StringNtB2_3Any7type_idCset5xJoy1xWQ_3std (param $0 i32) (param $1 i32)
  (i64.store offset=8 align=4
   (local.get $0)
   (i64.load align=4
    (i32.const 1055364)
   )
  )
  (i64.store align=4
   (local.get $0)
   (i64.load align=4
    (i32.const 1055356)
   )
  )
 )
 (func $_RNvXsZ_NtCsi9YzqDQQz2q_5alloc6stringNtB5_6StringNtNtCsdHhIpgkcIfN_4core3fmt5Write9write_str.194 (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (block $block1
   (block $block
    (if
     (i32.lt_u
      (i32.sub
       (i32.load
        (local.get $0)
       )
       (local.tee $3
        (i32.load offset=8
         (local.get $0)
        )
       )
      )
      (local.get $2)
     )
     (then
      (call $_RINvNvMs2_NtCsi9YzqDQQz2q_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECset5xJoy1xWQ_3std
       (local.get $0)
       (local.get $3)
       (local.get $2)
      )
      (local.set $3
       (i32.load offset=8
        (local.get $0)
       )
      )
      (br $block)
     )
    )
    (br_if $block1
     (i32.eqz
      (local.get $2)
     )
    )
   )
   (br_if $block1
    (i32.eqz
     (local.get $2)
    )
   )
   (memory.copy
    (i32.add
     (i32.load offset=4
      (local.get $0)
     )
     (local.get $3)
    )
    (local.get $1)
    (local.get $2)
   )
  )
  (i32.store offset=8
   (local.get $0)
   (i32.add
    (local.get $2)
    (local.get $3)
   )
  )
  (i32.const 0)
 )
 (func $_RNvXsZ_NtCsi9YzqDQQz2q_5alloc6stringNtB5_6StringNtNtCsdHhIpgkcIfN_4core3fmt5Write10write_char.195 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local.set $2
   (local.tee $4
    (i32.load offset=8
     (local.get $0)
    )
   )
  )
  (local.set $2
   (i32.add
    (if (result i32)
     (i32.gt_u
      (local.tee $6
       (block $block (result i32)
        (drop
         (br_if $block
          (i32.const 1)
          (i32.lt_u
           (local.get $1)
           (i32.const 128)
          )
         )
        )
        (drop
         (br_if $block
          (i32.const 2)
          (i32.lt_u
           (local.get $1)
           (i32.const 2048)
          )
         )
        )
        (select
         (i32.const 3)
         (i32.const 4)
         (i32.lt_u
          (local.get $1)
          (i32.const 65536)
         )
        )
       )
      )
      (i32.sub
       (i32.load
        (local.get $0)
       )
       (local.get $4)
      )
     )
     (then
      (call $_RINvNvMs2_NtCsi9YzqDQQz2q_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECset5xJoy1xWQ_3std
       (local.get $0)
       (local.get $4)
       (local.get $6)
      )
      (i32.load offset=8
       (local.get $0)
      )
     )
     (else
      (local.get $2)
     )
    )
    (i32.load offset=4
     (local.get $0)
    )
   )
  )
  (block $block1
   (if
    (i32.ge_u
     (local.get $1)
     (i32.const 128)
    )
    (then
     (local.set $5
      (i32.or
       (i32.and
        (local.get $1)
        (i32.const 63)
       )
       (i32.const -128)
      )
     )
     (local.set $3
      (i32.shr_u
       (local.get $1)
       (i32.const 6)
      )
     )
     (if
      (i32.lt_u
       (local.get $1)
       (i32.const 2048)
      )
      (then
       (i32.store8 offset=1
        (local.get $2)
        (local.get $5)
       )
       (i32.store8
        (local.get $2)
        (i32.or
         (local.get $3)
         (i32.const 192)
        )
       )
       (br $block1)
      )
     )
     (local.set $7
      (i32.shr_u
       (local.get $1)
       (i32.const 12)
      )
     )
     (local.set $3
      (i32.or
       (i32.and
        (local.get $3)
        (i32.const 63)
       )
       (i32.const -128)
      )
     )
     (if
      (i32.le_u
       (local.get $1)
       (i32.const 65535)
      )
      (then
       (i32.store8 offset=2
        (local.get $2)
        (local.get $5)
       )
       (i32.store8 offset=1
        (local.get $2)
        (local.get $3)
       )
       (i32.store8
        (local.get $2)
        (i32.or
         (local.get $7)
         (i32.const 224)
        )
       )
       (br $block1)
      )
     )
     (i32.store8 offset=3
      (local.get $2)
      (local.get $5)
     )
     (i32.store8 offset=2
      (local.get $2)
      (local.get $3)
     )
     (i32.store8 offset=1
      (local.get $2)
      (i32.or
       (i32.and
        (local.get $7)
        (i32.const 63)
       )
       (i32.const -128)
      )
     )
     (i32.store8
      (local.get $2)
      (i32.or
       (i32.shr_u
        (local.get $1)
        (i32.const 18)
       )
       (i32.const -16)
      )
     )
     (br $block1)
    )
   )
   (i32.store8
    (local.get $2)
    (local.get $1)
   )
  )
  (i32.store offset=8
   (local.get $0)
   (i32.add
    (local.get $4)
    (local.get $6)
   )
  )
  (i32.const 0)
 )
 (func $_RNvYNtNtCsi9YzqDQQz2q_5alloc6string6StringNtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtCset5xJoy1xWQ_3std (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
   (local.get $0)
   (i32.const 1055112)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $_RNvXs2_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCsdHhIpgkcIfN_4core3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (call_indirect $0 (type $0)
   (i32.load
    (local.get $1)
   )
   (i32.load
    (local.get $0)
   )
   (i32.load offset=4
    (local.get $0)
   )
   (i32.load offset=12
    (i32.load offset=4
     (local.get $1)
    )
   )
  )
 )
 (func $_RNvXs1_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload8take_box (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local.set $2
   (i32.load offset=4
    (local.get $1)
   )
  )
  (local.set $3
   (i32.load
    (local.get $1)
   )
  )
  (if
   (i32.eqz
    (local.tee $1
     (call $dlmalloc
      (i32.const 8)
     )
    )
   )
   (then
    (call $_RNvNtCsi9YzqDQQz2q_5alloc5alloc18handle_alloc_error
     (i32.const 4)
     (i32.const 8)
    )
    (unreachable)
   )
  )
  (i32.store offset=4
   (local.get $1)
   (local.get $2)
  )
  (i32.store
   (local.get $1)
   (local.get $3)
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 1056892)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
 )
 (func $_RNvXs1_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload3get (param $0 i32) (param $1 i32)
  (i32.store offset=4
   (local.get $0)
   (i32.const 1056892)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
 )
 (func $_RNvXs1_NvNtCset5xJoy1xWQ_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCsdHhIpgkcIfN_4core5panic12PanicPayload6as_str (param $0 i32) (param $1 i32)
  (i64.store
   (local.get $0)
   (i64.load align=4
    (local.get $1)
   )
  )
 )
 (func $_RNvXsQ_NtNtCsdHhIpgkcIfN_4core3fmt3numlNtB7_5Debug3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $scratch
   (block $block1 (result i32)
    (block $block
     (if
      (i32.eqz
       (i32.and
        (local.tee $2
         (i32.load offset=8
          (local.get $1)
         )
        )
        (i32.const 33554432)
       )
      )
      (then
       (br_if $block
        (i32.and
         (local.get $2)
         (i32.const 67108864)
        )
       )
       (br $block1
        (call $_RNvXs9_NtNtNtCsdHhIpgkcIfN_4core3fmt3num3implNtB9_7Display3fmt
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
     (local.set $2
      (i32.load
       (local.get $0)
      )
     )
     (local.set $0
      (i32.const 9)
     )
     (loop $label
      (i32.store8
       (i32.add
        (i32.add
         (local.get $0)
         (local.get $3)
        )
        (i32.const 6)
       )
       (i32.load8_u offset=1052179
        (i32.and
         (local.get $2)
         (i32.const 15)
        )
       )
      )
      (local.set $0
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
      )
      (br_if $label
       (local.tee $2
        (i32.shr_u
         (local.get $2)
         (i32.const 4)
        )
       )
      )
     )
     (br $block1
      (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
       (local.get $1)
       (i32.const 1)
       (i32.const 1054516)
       (i32.const 2)
       (i32.add
        (i32.add
         (local.get $0)
         (local.get $3)
        )
        (i32.const 7)
       )
       (i32.sub
        (i32.const 9)
        (local.get $0)
       )
      )
     )
    )
    (local.set $2
     (i32.load
      (local.get $0)
     )
    )
    (local.set $0
     (i32.const 9)
    )
    (loop $label1
     (i32.store8
      (i32.add
       (i32.add
        (local.get $0)
        (local.get $3)
       )
       (i32.const 6)
      )
      (i32.load8_u offset=1054518
       (i32.and
        (local.get $2)
        (i32.const 15)
       )
      )
     )
     (local.set $0
      (i32.sub
       (local.get $0)
       (i32.const 1)
      )
     )
     (br_if $label1
      (local.tee $2
       (i32.shr_u
        (local.get $2)
        (i32.const 4)
       )
      )
     )
    )
    (call $_RNvMsa_NtCsdHhIpgkcIfN_4core3fmtNtB5_9Formatter12pad_integral
     (local.get $1)
     (i32.const 1)
     (i32.const 1054516)
     (i32.const 2)
     (i32.add
      (i32.add
       (local.get $0)
       (local.get $3)
      )
      (i32.const 7)
     )
     (i32.sub
      (i32.const 9)
      (local.get $0)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvNtNtNtNtCset5xJoy1xWQ_3std3sys2io5error4wasi12error_string (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 1056)
    )
   )
  )
  (memory.fill
   (local.tee $3
    (i32.add
     (local.get $2)
     (i32.const 12)
    )
   )
   (i32.const 0)
   (i32.const 1024)
  )
  (block $block3
   (block $block1
    (if
     (i32.ge_s
      (block $block (result i32)
       (drop
        (i32.load offset=20
         (if (result i32)
          (local.tee $4
           (i32.load
            (i32.const 1061228)
           )
          )
          (then
           (local.get $4)
          )
          (else
           (i32.store
            (i32.const 1061228)
            (i32.const 1061204)
           )
           (i32.const 1061204)
          )
         )
        )
       )
       (if
        (i32.ge_u
         (local.tee $4
          (call $strlen
           (local.tee $1
            (i32.add
             (i32.load16_u offset=1060736
              (i32.shl
               (select
                (local.get $1)
                (i32.const 0)
                (i32.le_u
                 (local.get $1)
                 (i32.const 76)
                )
               )
               (i32.const 1)
              )
             )
             (i32.const 1059172)
            )
           )
          )
         )
         (i32.const 1024)
        )
        (then
         (memory.copy
          (local.get $3)
          (local.get $1)
          (i32.const 1023)
         )
         (i32.store8
          (i32.add
           (local.get $3)
           (i32.const 1023)
          )
          (i32.const 0)
         )
         (br $block
          (i32.const 68)
         )
        )
       )
       (if
        (local.tee $4
         (i32.add
          (local.get $4)
          (i32.const 1)
         )
        )
        (then
         (memory.copy
          (local.get $3)
          (local.get $1)
          (local.get $4)
         )
        )
       )
       (i32.const 0)
      )
      (i32.const 0)
     )
     (then
      (call $_RNvNtNtCsdHhIpgkcIfN_4core3str8converts9from_utf8
       (i32.add
        (local.get $2)
        (i32.const 1036)
       )
       (local.get $3)
       (call $strlen
        (local.get $3)
       )
      )
      (br_if $block1
       (i32.load offset=1036
        (local.get $2)
       )
      )
      (block $block2
       (if
        (i32.eqz
         (local.tee $1
          (i32.load offset=1044
           (local.get $2)
          )
         )
        )
        (then
         (local.set $3
          (i32.const 1)
         )
         (br $block2)
        )
       )
       (local.set $4
        (i32.load offset=1040
         (local.get $2)
        )
       )
       (br_if $block3
        (i32.eqz
         (local.tee $3
          (call $dlmalloc
           (local.get $1)
          )
         )
        )
       )
       (br_if $block2
        (i32.eqz
         (local.get $1)
        )
       )
       (memory.copy
        (local.get $3)
        (local.get $4)
        (local.get $1)
       )
      )
      (i32.store offset=8
       (local.get $0)
       (local.get $1)
      )
      (i32.store offset=4
       (local.get $0)
       (local.get $3)
      )
      (i32.store
       (local.get $0)
       (local.get $1)
      )
      (global.set $__stack_pointer
       (i32.add
        (local.get $2)
        (i32.const 1056)
       )
      )
      (return)
     )
    )
    (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
     (i32.const 1056772)
     (i32.const 37)
     (i32.const 1056792)
    )
    (unreachable)
   )
   (i64.store offset=1048
    (local.get $2)
    (i64.load offset=1040 align=4
     (local.get $2)
    )
   )
   (call $_RNvNtCsdHhIpgkcIfN_4core6result13unwrap_failed
    (i32.add
     (local.get $2)
     (i32.const 1048)
    )
    (i32.const 1056740)
    (i32.const 1056756)
   )
   (unreachable)
  )
  (call $_RNvNtCsi9YzqDQQz2q_5alloc7raw_vec12handle_error
   (i32.const 1)
   (local.get $1)
  )
  (unreachable)
 )
 (func $_RNvXs9_NtNtCsdHhIpgkcIfN_4core3str5errorNtB5_9Utf8ErrorNtNtB9_3fmt5Debug3fmt.214 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=4
   (local.get $2)
   (i32.add
    (local.get $0)
    (i32.const 4)
   )
  )
  (local.set $3
   (call_indirect $0 (type $0)
    (i32.load
     (local.get $1)
    )
    (i32.const 1056945)
    (i32.const 9)
    (i32.load offset=12
     (i32.load offset=4
      (local.get $1)
     )
    )
   )
  )
  (i32.store8 offset=13
   (local.get $2)
   (i32.const 0)
  )
  (i32.store8 offset=12
   (local.get $2)
   (local.get $3)
  )
  (i32.store offset=8
   (local.get $2)
   (local.get $1)
  )
  (local.set $0
   (call $_RNvMs1_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_11DebugStruct5field
    (call $_RNvMs1_NtNtCsdHhIpgkcIfN_4core3fmt8buildersNtB5_11DebugStruct5field
     (i32.add
      (local.get $2)
      (i32.const 8)
     )
     (i32.const 1056954)
     (i32.const 11)
     (local.get $0)
     (i32.const 20)
    )
    (i32.const 1056965)
    (i32.const 9)
    (i32.add
     (local.get $2)
     (i32.const 4)
    )
    (i32.const 21)
   )
  )
  (local.set $1
   (i32.or
    (local.tee $3
     (i32.load8_u offset=13
      (local.get $2)
     )
    )
    (local.tee $4
     (i32.load8_u offset=12
      (local.get $2)
     )
    )
   )
  )
  (block $block
   (br_if $block
    (i32.ne
     (local.get $3)
     (i32.const 1)
    )
   )
   (br_if $block
    (i32.and
     (local.get $4)
     (i32.const 1)
    )
   )
   (if
    (i32.eqz
     (i32.and
      (i32.load8_u offset=10
       (local.tee $0
        (i32.load
         (local.get $0)
        )
       )
      )
      (i32.const 128)
     )
    )
    (then
     (local.set $1
      (call_indirect $0 (type $0)
       (i32.load
        (local.get $0)
       )
       (i32.const 1052214)
       (i32.const 2)
       (i32.load offset=12
        (i32.load offset=4
         (local.get $0)
        )
       )
      )
     )
     (br $block)
    )
   )
   (local.set $1
    (call_indirect $0 (type $0)
     (i32.load
      (local.get $0)
     )
     (i32.const 1052211)
     (i32.const 1)
     (i32.load offset=12
      (i32.load offset=4
       (local.get $0)
      )
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
  (i32.and
   (local.get $1)
   (i32.const 1)
  )
 )
 (func $_RNvMs_NtNtNtCset5xJoy1xWQ_3std2io8buffered9bufwriterINtB4_9BufWriterNtNtB8_5stdio9StdoutRawE9flush_bufBa_ (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i64)
  (if
   (i32.eqz
    (local.tee $3
     (i32.load offset=8
      (local.get $1)
     )
    )
   )
   (then
    (i32.store8
     (local.get $0)
     (i32.const 4)
    )
    (return)
   )
  )
  (local.set $6
   (i32.load offset=4
    (local.get $1)
   )
  )
  (loop $label
   (block $block2
    (block $block3
     (block $block1
      (block $block
       (if
        (i32.eq
         (local.tee $5
          (call $write
           (i32.const 1)
           (local.tee $8
            (i32.add
             (local.get $2)
             (local.get $6)
            )
           )
           (local.tee $4
            (i32.sub
             (local.get $3)
             (local.get $2)
            )
           )
          )
         )
         (i32.const -1)
        )
        (then
         (i32.store8 offset=12
          (local.get $1)
          (i32.const 0)
         )
         (local.set $5
          (local.get $4)
         )
         (br_table $block $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block1 $block2 $block1
          (i32.sub
           (local.tee $7
            (i32.load
             (i32.const 1061060)
            )
           )
           (i32.const 8)
          )
         )
        )
       )
       (i32.store8 offset=12
        (local.get $1)
        (i32.const 0)
       )
      )
      (br_if $block3
       (local.get $5)
      )
      (local.set $9
       (i64.const 2)
      )
      (local.set $7
       (i32.const 1056332)
      )
     )
     (i64.store align=4
      (local.get $0)
      (i64.or
       (i64.shl
        (i64.extend_i32_u
         (local.get $7)
        )
        (i64.const 32)
       )
       (local.get $9)
      )
     )
     (if
      (local.get $2)
      (then
       (if
        (local.get $4)
        (then
         (memory.copy
          (local.get $6)
          (local.get $8)
          (local.get $4)
         )
        )
       )
       (i32.store offset=8
        (local.get $1)
        (local.get $4)
       )
      )
     )
     (return)
    )
    (local.set $2
     (i32.add
      (local.get $2)
      (local.get $5)
     )
    )
   )
   (br_if $label
    (i32.lt_u
     (local.get $2)
     (local.get $3)
    )
   )
  )
  (i32.store8
   (local.get $0)
   (i32.const 4)
  )
  (if
   (i32.le_u
    (local.get $2)
    (local.get $3)
   )
   (then
    (i32.store offset=8
     (local.get $1)
     (i32.const 0)
    )
    (return)
   )
  )
  (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
   (i32.const 0)
   (local.get $2)
   (local.get $3)
   (i32.const 1056540)
  )
  (unreachable)
 )
 (func $_RNvMs_NtNtNtCset5xJoy1xWQ_3std2io8buffered9bufwriterINtB4_9BufWriterNtNtB8_5stdio9StdoutRawE14write_all_coldBa_ (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block
   (if
    (i32.gt_u
     (if (result i32)
      (i32.lt_u
       (i32.sub
        (local.tee $4
         (i32.load
          (local.get $1)
         )
        )
        (i32.load offset=8
         (local.get $1)
        )
       )
       (local.get $3)
      )
      (then
       (call $_RNvMs_NtNtNtCset5xJoy1xWQ_3std2io8buffered9bufwriterINtB4_9BufWriterNtNtB8_5stdio9StdoutRawE9flush_bufBa_
        (i32.add
         (local.get $5)
         (i32.const 8)
        )
        (local.get $1)
       )
       (if
        (i32.ne
         (i32.load8_u offset=8
          (local.get $5)
         )
         (i32.const 4)
        )
        (then
         (i64.store align=4
          (local.get $0)
          (i64.load offset=8
           (local.get $5)
          )
         )
         (br $block)
        )
       )
       (i32.load
        (local.get $1)
       )
      )
      (else
       (local.get $4)
      )
     )
     (local.get $3)
    )
    (then
     (local.set $4
      (i32.load offset=8
       (local.get $1)
      )
     )
     (if
      (local.get $3)
      (then
       (memory.copy
        (i32.add
         (i32.load offset=4
          (local.get $1)
         )
         (local.get $4)
        )
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (i32.store8
      (local.get $0)
      (i32.const 4)
     )
     (i32.store offset=8
      (local.get $1)
      (i32.add
       (local.get $3)
       (local.get $4)
      )
     )
     (br $block)
    )
   )
   (i32.store8 offset=12
    (local.get $1)
    (i32.const 1)
   )
   (local.set $6
    (i64.const 4)
   )
   (block $block6
    (block $block5
     (block $block1
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (br $block1)
       )
      )
      (block $block3
       (block $block4
        (loop $label
         (block $block2
          (if
           (i32.eq
            (local.tee $4
             (call $write
              (i32.const 1)
              (local.get $2)
              (local.get $3)
             )
            )
            (i32.const -1)
           )
           (then
            (i32.store8 offset=11
             (local.get $5)
             (i32.const 0)
            )
            (i32.store16 offset=9 align=1
             (local.get $5)
             (i32.const 0)
            )
            (i32.store8 offset=8
             (local.get $5)
             (i32.const 0)
            )
            (i32.store offset=12
             (local.get $5)
             (local.tee $4
              (i32.load
               (i32.const 1061060)
              )
             )
            )
            (br_if $block2
             (i32.eq
              (local.get $4)
              (i32.const 27)
             )
            )
            (local.set $3
             (i32.add
              (local.get $5)
              (i32.const 8)
             )
            )
            (br $block3)
           )
          )
          (i32.store offset=12
           (local.get $5)
           (local.get $4)
          )
          (i32.store8 offset=8
           (local.get $5)
           (i32.const 4)
          )
          (if
           (i32.eqz
            (local.get $4)
           )
           (then
            (local.set $3
             (i32.const 1056624)
            )
            (br $block3)
           )
          )
          (br_if $block4
           (i32.lt_u
            (local.get $3)
            (local.get $4)
           )
          )
          (local.set $2
           (i32.add
            (local.get $2)
            (local.get $4)
           )
          )
          (local.set $3
           (i32.sub
            (local.get $3)
            (local.get $4)
           )
          )
         )
         (br_if $label
          (local.get $3)
         )
        )
        (br $block1)
       )
       (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
        (local.get $4)
        (local.get $3)
        (local.get $3)
        (i32.const 1057656)
       )
       (unreachable)
      )
      (local.set $8
       (i64.shr_u
        (local.tee $6
         (i64.load
          (local.get $3)
         )
        )
        (i64.const 32)
       )
      )
      (if
       (i64.ne
        (i64.and
         (local.get $6)
         (i64.const 255)
        )
        (i64.const 0)
       )
       (then
        (local.set $7
         (local.get $6)
        )
        (br $block1)
       )
      )
      (local.set $7
       (local.get $6)
      )
      (br_if $block5
       (i64.eq
        (local.get $8)
        (i64.const 8)
       )
      )
     )
     (i64.store align=4
      (local.get $0)
      (i64.or
       (i64.and
        (local.get $6)
        (i64.const 255)
       )
       (i64.or
        (i64.and
         (local.get $7)
         (i64.const 4294967040)
        )
        (i64.shl
         (local.get $8)
         (i64.const 32)
        )
       )
      )
     )
     (br $block6)
    )
    (i32.store8
     (local.get $0)
     (i32.const 4)
    )
   )
   (i32.store8 offset=12
    (local.get $1)
    (i32.const 0)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
  )
 )
 (func $_RNvXsr_NtNtCset5xJoy1xWQ_3std2io5stdioNtB5_10StderrLockNtB7_5Write9write_all (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block5
   (block $block4
    (block $block
     (block $block2
      (block $block3
       (if
        (i32.eqz
         (i32.load offset=16
          (local.get $1)
         )
        )
        (then
         (i32.store offset=16
          (local.get $1)
          (i32.const -1)
         )
         (local.set $6
          (i64.const 4)
         )
         (if
          (i32.eqz
           (local.get $3)
          )
          (then
           (br $block)
          )
         )
         (loop $label
          (block $block1
           (if
            (i32.eq
             (local.tee $5
              (call $write
               (i32.const 2)
               (local.get $2)
               (local.get $3)
              )
             )
             (i32.const -1)
            )
            (then
             (i32.store8 offset=11
              (local.get $4)
              (i32.const 0)
             )
             (i32.store16 offset=9 align=1
              (local.get $4)
              (i32.const 0)
             )
             (i32.store8 offset=8
              (local.get $4)
              (i32.const 0)
             )
             (i32.store offset=12
              (local.get $4)
              (local.tee $5
               (i32.load
                (i32.const 1061060)
               )
              )
             )
             (br_if $block1
              (i32.eq
               (local.get $5)
               (i32.const 27)
              )
             )
             (local.set $2
              (i32.add
               (local.get $4)
               (i32.const 8)
              )
             )
             (br $block2)
            )
           )
           (i32.store offset=12
            (local.get $4)
            (local.get $5)
           )
           (i32.store8 offset=8
            (local.get $4)
            (i32.const 4)
           )
           (if
            (i32.eqz
             (local.get $5)
            )
            (then
             (local.set $2
              (i32.const 1056624)
             )
             (br $block2)
            )
           )
           (br_if $block3
            (i32.lt_u
             (local.get $3)
             (local.get $5)
            )
           )
           (local.set $2
            (i32.add
             (local.get $2)
             (local.get $5)
            )
           )
           (local.set $3
            (i32.sub
             (local.get $3)
             (local.get $5)
            )
           )
          )
          (br_if $label
           (local.get $3)
          )
         )
         (br $block)
        )
       )
       (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
        (i32.const 1057640)
       )
       (unreachable)
      )
      (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
       (local.get $5)
       (local.get $3)
       (local.get $3)
       (i32.const 1057656)
      )
      (unreachable)
     )
     (local.set $8
      (i64.shr_u
       (local.tee $6
        (i64.load
         (local.get $2)
        )
       )
       (i64.const 32)
      )
     )
     (if
      (i64.ne
       (i64.and
        (local.get $6)
        (i64.const 255)
       )
       (i64.const 0)
      )
      (then
       (local.set $7
        (local.get $6)
       )
       (br $block)
      )
     )
     (local.set $7
      (local.get $6)
     )
     (br_if $block4
      (i64.eq
       (local.get $8)
       (i64.const 8)
      )
     )
    )
    (i64.store align=4
     (local.get $0)
     (i64.or
      (i64.and
       (local.get $6)
       (i64.const 255)
      )
      (i64.or
       (i64.and
        (local.get $7)
        (i64.const 4294967040)
       )
       (i64.shl
        (local.get $8)
        (i64.const 32)
       )
      )
     )
    )
    (br $block5)
   )
   (i32.store8
    (local.get $0)
    (i32.const 4)
   )
  )
  (i32.store offset=16
   (local.get $1)
   (i32.add
    (i32.load offset=16
     (local.get $1)
    )
    (i32.const 1)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $4)
    (i32.const 16)
   )
  )
 )
 (func $_RNvXNvNtCset5xJoy1xWQ_3std2io17default_write_fmtINtB2_7AdapterNtNtB4_5stdio10StderrLockENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_strB6_ (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (call $_RNvXsr_NtNtCset5xJoy1xWQ_3std2io5stdioNtB5_10StderrLockNtB7_5Write9write_all
   (i32.add
    (local.get $3)
    (i32.const 8)
   )
   (i32.load
    (i32.load offset=8
     (local.get $0)
    )
   )
   (local.get $1)
   (local.get $2)
  )
  (if
   (i32.ne
    (local.tee $4
     (i32.load8_u offset=8
      (local.get $3)
     )
    )
    (i32.const 4)
   )
   (then
    (if
     (i32.eq
      (i32.load8_u
       (local.get $0)
      )
      (i32.const 3)
     )
     (then
      (local.set $2
       (i32.load
        (local.tee $1
         (i32.load offset=4
          (local.get $0)
         )
        )
       )
      )
      (if
       (local.tee $6
        (i32.load
         (local.tee $5
          (i32.load
           (i32.add
            (local.get $1)
            (i32.const 4)
           )
          )
         )
        )
       )
       (then
        (call_indirect $0 (type $2)
         (local.get $2)
         (local.get $6)
        )
       )
      )
      (if
       (i32.load offset=4
        (local.get $5)
       )
       (then
        (call $dlfree
         (local.get $2)
        )
       )
      )
      (call $dlfree
       (local.get $1)
      )
     )
    )
    (i64.store align=4
     (local.get $0)
     (i64.load offset=8
      (local.get $3)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (i32.ne
   (local.get $4)
   (i32.const 4)
  )
 )
 (func $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtB7_5stdio10StderrLockENtNtCsdHhIpgkcIfN_4core3fmt5Write10write_charB9_ (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=4
   (local.get $2)
   (i32.const 0)
  )
  (local.set $1
   (block $block (result i32)
    (if
     (i32.ge_u
      (local.get $1)
      (i32.const 128)
     )
     (then
      (local.set $4
       (i32.or
        (i32.and
         (local.get $1)
         (i32.const 63)
        )
        (i32.const -128)
       )
      )
      (local.set $3
       (i32.shr_u
        (local.get $1)
        (i32.const 6)
       )
      )
      (if
       (i32.lt_u
        (local.get $1)
        (i32.const 2048)
       )
       (then
        (i32.store8 offset=5
         (local.get $2)
         (local.get $4)
        )
        (i32.store8 offset=4
         (local.get $2)
         (i32.or
          (local.get $3)
          (i32.const 192)
         )
        )
        (br $block
         (i32.const 2)
        )
       )
      )
      (local.set $5
       (i32.shr_u
        (local.get $1)
        (i32.const 12)
       )
      )
      (local.set $3
       (i32.or
        (i32.and
         (local.get $3)
         (i32.const 63)
        )
        (i32.const -128)
       )
      )
      (if
       (i32.le_u
        (local.get $1)
        (i32.const 65535)
       )
       (then
        (i32.store8 offset=6
         (local.get $2)
         (local.get $4)
        )
        (i32.store8 offset=5
         (local.get $2)
         (local.get $3)
        )
        (i32.store8 offset=4
         (local.get $2)
         (i32.or
          (local.get $5)
          (i32.const 224)
         )
        )
        (br $block
         (i32.const 3)
        )
       )
      )
      (i32.store8 offset=7
       (local.get $2)
       (local.get $4)
      )
      (i32.store8 offset=6
       (local.get $2)
       (local.get $3)
      )
      (i32.store8 offset=5
       (local.get $2)
       (i32.or
        (i32.and
         (local.get $5)
         (i32.const 63)
        )
        (i32.const -128)
       )
      )
      (i32.store8 offset=4
       (local.get $2)
       (i32.or
        (i32.shr_u
         (local.get $1)
         (i32.const 18)
        )
        (i32.const -16)
       )
      )
      (br $block
       (i32.const 4)
      )
     )
    )
    (i32.store8 offset=4
     (local.get $2)
     (local.get $1)
    )
    (i32.const 1)
   )
  )
  (call $_RNvXsr_NtNtCset5xJoy1xWQ_3std2io5stdioNtB5_10StderrLockNtB7_5Write9write_all
   (i32.add
    (local.get $2)
    (i32.const 8)
   )
   (i32.load
    (i32.load offset=8
     (local.get $0)
    )
   )
   (i32.add
    (local.get $2)
    (i32.const 4)
   )
   (local.get $1)
  )
  (if
   (i32.ne
    (local.tee $3
     (i32.load8_u offset=8
      (local.get $2)
     )
    )
    (i32.const 4)
   )
   (then
    (if
     (i32.eq
      (i32.load8_u
       (local.get $0)
      )
      (i32.const 3)
     )
     (then
      (local.set $4
       (i32.load
        (local.tee $1
         (i32.load offset=4
          (local.get $0)
         )
        )
       )
      )
      (if
       (local.tee $6
        (i32.load
         (local.tee $5
          (i32.load
           (i32.add
            (local.get $1)
            (i32.const 4)
           )
          )
         )
        )
       )
       (then
        (call_indirect $0 (type $2)
         (local.get $4)
         (local.get $6)
        )
       )
      )
      (if
       (i32.load offset=4
        (local.get $5)
       )
       (then
        (call $dlfree
         (local.get $4)
        )
       )
      )
      (call $dlfree
       (local.get $1)
      )
     )
    )
    (i64.store align=4
     (local.get $0)
     (i64.load offset=8
      (local.get $2)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
  (i32.ne
   (local.get $3)
   (i32.const 4)
  )
 )
 (func $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtB7_5stdio10StderrLockENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtB9_ (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $scratch
   (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
    (local.get $0)
    (i32.const 1054892)
    (local.get $1)
    (local.get $2)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvXsh_NtNtCset5xJoy1xWQ_3std2io5stdioNtB5_10StdoutLockNtB7_5Write9write_all (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i64)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $6
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block
   (block $block10
    (block $block5
     (block $block7
      (block $block2
       (block $block8
        (block $block4
         (block $block1
          (if
           (i32.eqz
            (i32.load offset=16
             (local.get $1)
            )
           )
           (then
            (i32.store offset=16
             (local.get $1)
             (i32.const -1)
            )
            (local.set $7
             (local.tee $5
              (local.get $3)
             )
            )
            (if
             (i32.le_u
              (local.tee $4
               (i32.sub
                (i32.and
                 (i32.add
                  (local.get $2)
                  (i32.const 3)
                 )
                 (i32.const -4)
                )
                (local.get $2)
               )
              )
              (local.get $3)
             )
             (then
              (local.set $5
               (i32.sub
                (local.get $3)
                (local.tee $7
                 (i32.and
                  (i32.sub
                   (local.get $3)
                   (local.get $4)
                  )
                  (i32.const 7)
                 )
                )
               )
              )
              (br_if $block
               (i32.lt_u
                (local.get $3)
                (local.get $7)
               )
              )
              (local.set $7
               (local.get $4)
              )
             )
            )
            (local.set $9
             (i32.add
              (local.get $1)
              (i32.const 20)
             )
            )
            (local.set $8
             (i32.sub
              (i32.const 0)
              (local.get $5)
             )
            )
            (local.set $10
             (i32.sub
              (local.get $2)
              (i32.const 1)
             )
            )
            (local.set $4
             (local.get $3)
            )
            (block $block3
             (loop $label2
              (if
               (i32.eqz
                (i32.add
                 (local.get $4)
                 (local.get $8)
                )
               )
               (then
                (loop $label
                 (if
                  (i32.lt_u
                   (local.get $7)
                   (local.tee $4
                    (local.get $5)
                   )
                  )
                  (then
                   (local.set $5
                    (i32.sub
                     (local.get $4)
                     (i32.const 8)
                    )
                   )
                   (br_if $label
                    (i32.eq
                     (i32.and
                      (i32.and
                       (i32.or
                        (i32.sub
                         (i32.const 16843008)
                         (i32.xor
                          (local.tee $10
                           (i32.load
                            (i32.sub
                             (local.tee $8
                              (i32.add
                               (local.get $2)
                               (local.get $4)
                              )
                             )
                             (i32.const 8)
                            )
                           )
                          )
                          (i32.const 168430090)
                         )
                        )
                        (local.get $10)
                       )
                       (i32.or
                        (i32.sub
                         (i32.const 16843008)
                         (i32.xor
                          (local.tee $8
                           (i32.load
                            (i32.sub
                             (local.get $8)
                             (i32.const 4)
                            )
                           )
                          )
                          (i32.const 168430090)
                         )
                        )
                        (local.get $8)
                       )
                      )
                      (i32.const -2139062144)
                     )
                     (i32.const -2139062144)
                    )
                   )
                  )
                 )
                )
                (br_if $block1
                 (i32.lt_u
                  (local.get $3)
                  (local.get $4)
                 )
                )
                (loop $label1
                 (br_if $block2
                  (i32.eqz
                   (local.tee $7
                    (local.get $4)
                   )
                  )
                 )
                 (br_if $label1
                  (i32.ne
                   (i32.load8_u
                    (i32.add
                     (local.tee $4
                      (i32.sub
                       (local.get $4)
                       (i32.const 1)
                      )
                     )
                     (local.get $2)
                    )
                   )
                   (i32.const 10)
                  )
                 )
                )
                (br $block3)
               )
              )
              (br_if $label2
               (i32.ne
                (i32.load8_u
                 (block (result i32)
                  (local.set $scratch
                   (i32.add
                    (local.get $4)
                    (local.get $10)
                   )
                  )
                  (local.set $4
                   (i32.sub
                    (local.get $4)
                    (i32.const 1)
                   )
                  )
                  (local.get $scratch)
                 )
                )
                (i32.const 10)
               )
              )
             )
             (local.set $7
              (i32.add
               (i32.add
                (i32.add
                 (local.get $4)
                 (local.get $8)
                )
                (i32.const 1)
               )
               (local.get $5)
              )
             )
            )
            (br_if $block4
             (i32.lt_u
              (local.get $3)
              (local.get $7)
             )
            )
            (if
             (i32.eqz
              (local.tee $5
               (i32.load offset=28
                (local.get $1)
               )
              )
             )
             (then
              (br_if $block5
               (i32.eqz
                (local.get $7)
               )
              )
              (local.set $4
               (local.get $2)
              )
              (local.set $5
               (local.get $7)
              )
              (loop $label3
               (block $block6
                (if
                 (i32.eq
                  (local.tee $8
                   (call $write
                    (i32.const 1)
                    (local.get $4)
                    (local.get $5)
                   )
                  )
                  (i32.const -1)
                 )
                 (then
                  (i32.store8 offset=11
                   (local.get $6)
                   (i32.const 0)
                  )
                  (i32.store16 offset=9 align=1
                   (local.get $6)
                   (i32.const 0)
                  )
                  (i32.store8 offset=8
                   (local.get $6)
                   (i32.const 0)
                  )
                  (i32.store offset=12
                   (local.get $6)
                   (local.tee $8
                    (i32.load
                     (i32.const 1061060)
                    )
                   )
                  )
                  (br_if $block6
                   (i32.eq
                    (local.get $8)
                    (i32.const 27)
                   )
                  )
                  (local.set $4
                   (i32.add
                    (local.get $6)
                    (i32.const 8)
                   )
                  )
                  (br $block7)
                 )
                )
                (i32.store offset=12
                 (local.get $6)
                 (local.get $8)
                )
                (i32.store8 offset=8
                 (local.get $6)
                 (i32.const 4)
                )
                (if
                 (i32.eqz
                  (local.get $8)
                 )
                 (then
                  (local.set $4
                   (i32.const 1056624)
                  )
                  (br $block7)
                 )
                )
                (br_if $block8
                 (i32.lt_u
                  (local.get $5)
                  (local.get $8)
                 )
                )
                (local.set $4
                 (i32.add
                  (local.get $4)
                  (local.get $8)
                 )
                )
                (local.set $5
                 (i32.sub
                  (local.get $5)
                  (local.get $8)
                 )
                )
               )
               (br_if $label3
                (local.get $5)
               )
              )
              (br $block5)
             )
            )
            (block $block9
             (if
              (i32.le_u
               (i32.sub
                (i32.load
                 (local.get $9)
                )
                (local.get $5)
               )
               (local.get $7)
              )
              (then
               (call $_RNvMs_NtNtNtCset5xJoy1xWQ_3std2io8buffered9bufwriterINtB4_9BufWriterNtNtB8_5stdio9StdoutRawE14write_all_coldBa_
                (i32.add
                 (local.get $6)
                 (i32.const 8)
                )
                (local.get $9)
                (local.get $2)
                (local.get $7)
               )
               (br_if $block9
                (i32.eq
                 (i32.load8_u offset=8
                  (local.get $6)
                 )
                 (i32.const 4)
                )
               )
               (i64.store align=4
                (local.get $0)
                (i64.load offset=8
                 (local.get $6)
                )
               )
               (br $block10)
              )
             )
             (if
              (local.get $7)
              (then
               (memory.copy
                (i32.add
                 (i32.load offset=24
                  (local.get $1)
                 )
                 (local.get $5)
                )
                (local.get $2)
                (local.get $7)
               )
              )
             )
             (i32.store offset=28
              (local.get $1)
              (i32.add
               (local.get $5)
               (local.get $7)
              )
             )
            )
            (call $_RNvMs_NtNtNtCset5xJoy1xWQ_3std2io8buffered9bufwriterINtB4_9BufWriterNtNtB8_5stdio9StdoutRawE9flush_bufBa_
             (i32.add
              (local.get $6)
              (i32.const 8)
             )
             (local.get $9)
            )
            (br_if $block5
             (i32.eq
              (i32.load8_u offset=8
               (local.get $6)
              )
              (i32.const 4)
             )
            )
            (i64.store align=4
             (local.get $0)
             (i64.load offset=8
              (local.get $6)
             )
            )
            (br $block10)
           )
          )
          (call $_RNvNtCsdHhIpgkcIfN_4core4cell22panic_already_borrowed
           (i32.const 1057564)
          )
          (unreachable)
         )
         (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
          (i32.const 0)
          (local.get $4)
          (local.get $3)
          (i32.const 1052748)
         )
         (unreachable)
        )
        (call $_RNvNtCsdHhIpgkcIfN_4core9panicking9panic_fmt
         (i32.const 1055331)
         (i32.const 19)
         (i32.const 1056984)
        )
        (unreachable)
       )
       (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
        (local.get $8)
        (local.get $5)
        (local.get $5)
        (i32.const 1057656)
       )
       (unreachable)
      )
      (block $block12
       (block $block11
        (if
         (i32.eqz
          (local.tee $4
           (i32.load offset=28
            (local.get $1)
           )
          )
         )
         (then
          (local.set $4
           (i32.const 0)
          )
          (br $block11)
         )
        )
        (br_if $block11
         (i32.ne
          (i32.load8_u
           (i32.sub
            (i32.add
             (i32.load offset=24
              (local.get $1)
             )
             (local.get $4)
            )
            (i32.const 1)
           )
          )
          (i32.const 10)
         )
        )
        (call $_RNvMs_NtNtNtCset5xJoy1xWQ_3std2io8buffered9bufwriterINtB4_9BufWriterNtNtB8_5stdio9StdoutRawE9flush_bufBa_
         (i32.add
          (local.get $6)
          (i32.const 8)
         )
         (local.get $9)
        )
        (br_if $block12
         (i32.ne
          (i32.load8_u offset=8
           (local.get $6)
          )
          (i32.const 4)
         )
        )
        (local.set $4
         (i32.load offset=28
          (local.get $1)
         )
        )
       )
       (if
        (i32.le_u
         (i32.sub
          (i32.load
           (local.get $9)
          )
          (local.get $4)
         )
         (local.get $3)
        )
        (then
         (call $_RNvMs_NtNtNtCset5xJoy1xWQ_3std2io8buffered9bufwriterINtB4_9BufWriterNtNtB8_5stdio9StdoutRawE14write_all_coldBa_
          (local.get $0)
          (local.get $9)
          (local.get $2)
          (local.get $3)
         )
         (br $block10)
        )
       )
       (if
        (local.get $3)
        (then
         (memory.copy
          (i32.add
           (i32.load offset=24
            (local.get $1)
           )
           (local.get $4)
          )
          (local.get $2)
          (local.get $3)
         )
        )
       )
       (i32.store8
        (local.get $0)
        (i32.const 4)
       )
       (i32.store offset=28
        (local.get $1)
        (i32.add
         (local.get $3)
         (local.get $4)
        )
       )
       (br $block10)
      )
      (i64.store align=4
       (local.get $0)
       (i64.load offset=8
        (local.get $6)
       )
      )
      (br $block10)
     )
     (br_if $block5
      (i64.eq
       (i64.and
        (local.tee $12
         (i64.load
          (local.get $4)
         )
        )
        (i64.const -4294967041)
       )
       (i64.const 34359738368)
      )
     )
     (br_if $block5
      (i64.eq
       (i64.and
        (local.get $12)
        (i64.const 255)
       )
       (i64.const 4)
      )
     )
     (i64.store align=4
      (local.get $0)
      (local.get $12)
     )
     (br $block10)
    )
    (local.set $5
     (i32.add
      (local.get $2)
      (local.get $7)
     )
    )
    (if
     (i32.ge_u
      (local.tee $2
       (i32.sub
        (local.get $3)
        (local.get $7)
       )
      )
      (i32.sub
       (i32.load offset=20
        (local.get $1)
       )
       (local.tee $3
        (i32.load offset=28
         (local.get $1)
        )
       )
      )
     )
     (then
      (call $_RNvMs_NtNtNtCset5xJoy1xWQ_3std2io8buffered9bufwriterINtB4_9BufWriterNtNtB8_5stdio9StdoutRawE14write_all_coldBa_
       (local.get $0)
       (local.get $9)
       (local.get $5)
       (local.get $2)
      )
      (br $block10)
     )
    )
    (if
     (local.get $2)
     (then
      (memory.copy
       (i32.add
        (i32.load offset=24
         (local.get $1)
        )
        (local.get $3)
       )
       (local.get $5)
       (local.get $2)
      )
     )
    )
    (i32.store8
     (local.get $0)
     (i32.const 4)
    )
    (i32.store offset=28
     (local.get $1)
     (i32.add
      (local.get $2)
      (local.get $3)
     )
    )
   )
   (i32.store offset=16
    (local.get $1)
    (i32.add
     (i32.load offset=16
      (local.get $1)
     )
     (i32.const 1)
    )
   )
   (global.set $__stack_pointer
    (i32.add
     (local.get $6)
     (i32.const 16)
    )
   )
   (return)
  )
  (call $_RNvNtNtCsdHhIpgkcIfN_4core5slice5index16slice_index_fail
   (local.get $5)
   (local.get $3)
   (local.get $3)
   (i32.const 1052764)
  )
  (unreachable)
 )
 (func $_RNvXNvNtCset5xJoy1xWQ_3std2io17default_write_fmtINtB2_7AdapterNtNtB4_5stdio10StdoutLockENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_strB6_ (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (call $_RNvXsh_NtNtCset5xJoy1xWQ_3std2io5stdioNtB5_10StdoutLockNtB7_5Write9write_all
   (i32.add
    (local.get $3)
    (i32.const 8)
   )
   (i32.load
    (i32.load offset=8
     (local.get $0)
    )
   )
   (local.get $1)
   (local.get $2)
  )
  (if
   (i32.ne
    (local.tee $4
     (i32.load8_u offset=8
      (local.get $3)
     )
    )
    (i32.const 4)
   )
   (then
    (if
     (i32.eq
      (i32.load8_u
       (local.get $0)
      )
      (i32.const 3)
     )
     (then
      (local.set $2
       (i32.load
        (local.tee $1
         (i32.load offset=4
          (local.get $0)
         )
        )
       )
      )
      (if
       (local.tee $6
        (i32.load
         (local.tee $5
          (i32.load
           (i32.add
            (local.get $1)
            (i32.const 4)
           )
          )
         )
        )
       )
       (then
        (call_indirect $0 (type $2)
         (local.get $2)
         (local.get $6)
        )
       )
      )
      (if
       (i32.load offset=4
        (local.get $5)
       )
       (then
        (call $dlfree
         (local.get $2)
        )
       )
      )
      (call $dlfree
       (local.get $1)
      )
     )
    )
    (i64.store align=4
     (local.get $0)
     (i64.load offset=8
      (local.get $3)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (i32.ne
   (local.get $4)
   (i32.const 4)
  )
 )
 (func $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtB7_5stdio10StdoutLockENtNtCsdHhIpgkcIfN_4core3fmt5Write10write_charB9_ (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=4
   (local.get $2)
   (i32.const 0)
  )
  (local.set $1
   (block $block (result i32)
    (if
     (i32.ge_u
      (local.get $1)
      (i32.const 128)
     )
     (then
      (local.set $4
       (i32.or
        (i32.and
         (local.get $1)
         (i32.const 63)
        )
        (i32.const -128)
       )
      )
      (local.set $3
       (i32.shr_u
        (local.get $1)
        (i32.const 6)
       )
      )
      (if
       (i32.lt_u
        (local.get $1)
        (i32.const 2048)
       )
       (then
        (i32.store8 offset=5
         (local.get $2)
         (local.get $4)
        )
        (i32.store8 offset=4
         (local.get $2)
         (i32.or
          (local.get $3)
          (i32.const 192)
         )
        )
        (br $block
         (i32.const 2)
        )
       )
      )
      (local.set $5
       (i32.shr_u
        (local.get $1)
        (i32.const 12)
       )
      )
      (local.set $3
       (i32.or
        (i32.and
         (local.get $3)
         (i32.const 63)
        )
        (i32.const -128)
       )
      )
      (if
       (i32.le_u
        (local.get $1)
        (i32.const 65535)
       )
       (then
        (i32.store8 offset=6
         (local.get $2)
         (local.get $4)
        )
        (i32.store8 offset=5
         (local.get $2)
         (local.get $3)
        )
        (i32.store8 offset=4
         (local.get $2)
         (i32.or
          (local.get $5)
          (i32.const 224)
         )
        )
        (br $block
         (i32.const 3)
        )
       )
      )
      (i32.store8 offset=7
       (local.get $2)
       (local.get $4)
      )
      (i32.store8 offset=6
       (local.get $2)
       (local.get $3)
      )
      (i32.store8 offset=5
       (local.get $2)
       (i32.or
        (i32.and
         (local.get $5)
         (i32.const 63)
        )
        (i32.const -128)
       )
      )
      (i32.store8 offset=4
       (local.get $2)
       (i32.or
        (i32.shr_u
         (local.get $1)
         (i32.const 18)
        )
        (i32.const -16)
       )
      )
      (br $block
       (i32.const 4)
      )
     )
    )
    (i32.store8 offset=4
     (local.get $2)
     (local.get $1)
    )
    (i32.const 1)
   )
  )
  (call $_RNvXsh_NtNtCset5xJoy1xWQ_3std2io5stdioNtB5_10StdoutLockNtB7_5Write9write_all
   (i32.add
    (local.get $2)
    (i32.const 8)
   )
   (i32.load
    (i32.load offset=8
     (local.get $0)
    )
   )
   (i32.add
    (local.get $2)
    (i32.const 4)
   )
   (local.get $1)
  )
  (if
   (i32.ne
    (local.tee $3
     (i32.load8_u offset=8
      (local.get $2)
     )
    )
    (i32.const 4)
   )
   (then
    (if
     (i32.eq
      (i32.load8_u
       (local.get $0)
      )
      (i32.const 3)
     )
     (then
      (local.set $4
       (i32.load
        (local.tee $1
         (i32.load offset=4
          (local.get $0)
         )
        )
       )
      )
      (if
       (local.tee $6
        (i32.load
         (local.tee $5
          (i32.load
           (i32.add
            (local.get $1)
            (i32.const 4)
           )
          )
         )
        )
       )
       (then
        (call_indirect $0 (type $2)
         (local.get $4)
         (local.get $6)
        )
       )
      )
      (if
       (i32.load offset=4
        (local.get $5)
       )
       (then
        (call $dlfree
         (local.get $4)
        )
       )
      )
      (call $dlfree
       (local.get $1)
      )
     )
    )
    (i64.store align=4
     (local.get $0)
     (i64.load offset=8
      (local.get $2)
     )
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
  (i32.ne
   (local.get $3)
   (i32.const 4)
  )
 )
 (func $_RNvYINtNvNtCset5xJoy1xWQ_3std2io17default_write_fmt7AdapterNtNtB7_5stdio10StdoutLockENtNtCsdHhIpgkcIfN_4core3fmt5Write9write_fmtB9_ (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $scratch
   (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
    (local.get $0)
    (i32.const 1054916)
    (local.get $1)
    (local.get $2)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $_RNvXs9_NtNtCset5xJoy1xWQ_3std3ffi6os_strNtB5_8OsStringNtNtCsdHhIpgkcIfN_4core3fmt5Debug3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i64)
  (local $19 i64)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 48)
    )
   )
  )
  (local.set $6
   (i32.load offset=8
    (local.get $0)
   )
  )
  (local.set $10
   (i32.load offset=4
    (local.get $0)
   )
  )
  (local.set $15
   (i32.const 1)
  )
  (block $block
   (br_if $block
    (call_indirect $0 (type $1)
     (local.tee $13
      (i32.load
       (local.get $1)
      )
     )
     (i32.const 34)
     (local.tee $17
      (i32.load offset=16
       (local.tee $16
        (i32.load offset=4
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (local.set $18
    (i64.or
     (i64.extend_i32_u
      (i32.add
       (local.get $4)
       (i32.const 47)
      )
     )
     (i64.const 94489280512)
    )
   )
   (block $block1
    (loop $label4
     (local.set $2
      (local.get $10)
     )
     (br_if $block1
      (i32.eqz
       (local.get $6)
      )
     )
     (local.set $0
      (i32.const 0)
     )
     (block $block25
      (block $block17
       (local.set $10
        (block $block16 (result i32)
         (loop $label
          (local.set $3
           (i32.add
            (local.get $0)
            (i32.const 1)
           )
          )
          (br_if $label
           (i32.lt_u
            (local.tee $0
             (block $block2 (result i32)
              (drop
               (br_if $block2
                (local.get $3)
                (i32.ge_s
                 (local.tee $5
                  (i32.extend8_s
                   (local.tee $10
                    (i32.load8_u
                     (local.tee $14
                      (i32.add
                       (local.get $0)
                       (local.get $2)
                      )
                     )
                    )
                   )
                  )
                 )
                 (i32.const 0)
                )
               )
              )
              (block $block15
               (block $block6
                (block $block13
                 (block $block3
                  (block $block14
                   (block $block12
                    (block $block10
                     (block $block11
                      (block $block8
                       (block $block9
                        (block $block7
                         (block $block5
                          (block $block4
                           (br_table $block3 $block4 $block5 $block6
                            (i32.sub
                             (i32.load8_u offset=1052491
                              (local.get $10)
                             )
                             (i32.const 2)
                            )
                           )
                          )
                          (local.set $1
                           (i32.load8_s
                            (select
                             (i32.const 1051124)
                             (i32.add
                              (local.get $2)
                              (local.get $3)
                             )
                             (i32.ge_u
                              (local.get $3)
                              (local.get $6)
                             )
                            )
                           )
                          )
                          (br_table $block7 $block8 $block8 $block8 $block8 $block8 $block8 $block8 $block8 $block8 $block8 $block8 $block8 $block9 $block8
                           (i32.sub
                            (local.get $10)
                            (i32.const 224)
                           )
                          )
                         )
                         (local.set $1
                          (i32.load8_s
                           (select
                            (i32.const 1051124)
                            (i32.add
                             (local.get $2)
                             (local.get $3)
                            )
                            (i32.ge_u
                             (local.get $3)
                             (local.get $6)
                            )
                           )
                          )
                         )
                         (br_table $block10 $block11 $block11 $block11 $block12 $block11
                          (i32.sub
                           (local.get $10)
                           (i32.const 240)
                          )
                         )
                        )
                        (br_if $block13
                         (i32.eq
                          (i32.and
                           (local.get $1)
                           (i32.const -32)
                          )
                          (i32.const -96)
                         )
                        )
                        (br $block6)
                       )
                       (br_if $block6
                        (i32.gt_s
                         (local.get $1)
                         (i32.const -97)
                        )
                       )
                       (br $block13)
                      )
                      (if
                       (i32.ge_u
                        (i32.and
                         (i32.add
                          (local.get $5)
                          (i32.const 31)
                         )
                         (i32.const 255)
                        )
                        (i32.const 12)
                       )
                       (then
                        (br_if $block6
                         (i32.ne
                          (i32.and
                           (local.get $5)
                           (i32.const -2)
                          )
                          (i32.const -18)
                         )
                        )
                        (br_if $block13
                         (i32.lt_s
                          (local.get $1)
                          (i32.const -64)
                         )
                        )
                        (br $block6)
                       )
                      )
                      (br_if $block13
                       (i32.lt_s
                        (local.get $1)
                        (i32.const -64)
                       )
                      )
                      (br $block6)
                     )
                     (br_if $block6
                      (i32.gt_u
                       (i32.and
                        (i32.add
                         (local.get $5)
                         (i32.const 15)
                        )
                        (i32.const 255)
                       )
                       (i32.const 2)
                      )
                     )
                     (br_if $block14
                      (i32.lt_s
                       (local.get $1)
                       (i32.const -64)
                      )
                     )
                     (br $block6)
                    )
                    (br_if $block14
                     (i32.lt_u
                      (i32.and
                       (i32.add
                        (local.get $1)
                        (i32.const 112)
                       )
                       (i32.const 255)
                      )
                      (i32.const 48)
                     )
                    )
                    (br $block6)
                   )
                   (br_if $block6
                    (i32.gt_s
                     (local.get $1)
                     (i32.const -113)
                    )
                   )
                  )
                  (br_if $block6
                   (i32.gt_s
                    (i32.load8_s
                     (select
                      (i32.const 1051124)
                      (i32.add
                       (local.get $2)
                       (local.tee $3
                        (i32.add
                         (local.get $0)
                         (i32.const 2)
                        )
                       )
                      )
                      (i32.ge_u
                       (local.get $3)
                       (local.get $6)
                      )
                     )
                    )
                    (i32.const -65)
                   )
                  )
                  (br_if $block6
                   (i32.gt_s
                    (i32.load8_s
                     (select
                      (i32.const 1051124)
                      (i32.add
                       (local.get $2)
                       (local.tee $3
                        (i32.add
                         (local.get $0)
                         (i32.const 3)
                        )
                       )
                      )
                      (i32.ge_u
                       (local.get $3)
                       (local.get $6)
                      )
                     )
                    )
                    (i32.const -65)
                   )
                  )
                  (br $block2
                   (i32.add
                    (local.get $0)
                    (i32.const 4)
                   )
                  )
                 )
                 (br_if $block15
                  (i32.lt_s
                   (i32.load8_s
                    (select
                     (i32.const 1051124)
                     (i32.add
                      (local.get $2)
                      (local.get $3)
                     )
                     (i32.ge_u
                      (local.get $3)
                      (local.get $6)
                     )
                    )
                   )
                   (i32.const -64)
                  )
                 )
                 (br $block6)
                )
                (br_if $block6
                 (i32.ge_s
                  (i32.load8_s
                   (select
                    (i32.const 1051124)
                    (i32.add
                     (local.get $2)
                     (local.tee $3
                      (i32.add
                       (local.get $0)
                       (i32.const 2)
                      )
                     )
                    )
                    (i32.ge_u
                     (local.get $3)
                     (local.get $6)
                    )
                   )
                  )
                  (i32.const -64)
                 )
                )
                (br $block2
                 (i32.add
                  (local.get $0)
                  (i32.const 3)
                 )
                )
               )
               (local.set $6
                (i32.sub
                 (local.get $6)
                 (local.get $3)
                )
               )
               (drop
                (br_if $block16
                 (local.tee $10
                  (i32.add
                   (local.get $2)
                   (local.get $3)
                  )
                 )
                 (local.get $0)
                )
               )
               (local.set $1
                (i32.const 0)
               )
               (br $block17)
              )
              (i32.add
               (local.get $0)
               (i32.const 2)
              )
             )
            )
            (local.get $6)
           )
          )
         )
         (local.set $6
          (i32.sub
           (local.get $6)
           (local.get $0)
          )
         )
         (local.set $3
          (local.get $0)
         )
         (local.tee $14
          (i32.add
           (local.get $0)
           (local.get $2)
          )
         )
        )
       )
       (local.set $1
        (i32.const 0)
       )
       (local.set $5
        (local.get $2)
       )
       (local.set $7
        (i32.const 0)
       )
       (loop $label3
        (local.set $9
         (block $block18 (result i32)
          (if
           (i32.ge_s
            (local.tee $8
             (i32.load8_s
              (local.get $5)
             )
            )
            (i32.const 0)
           )
           (then
            (local.set $11
             (i32.and
              (local.get $8)
              (i32.const 255)
             )
            )
            (br $block18
             (i32.add
              (local.get $5)
              (i32.const 1)
             )
            )
           )
          )
          (local.set $9
           (i32.and
            (i32.load8_u offset=1
             (local.get $5)
            )
            (i32.const 63)
           )
          )
          (local.set $12
           (i32.and
            (local.get $8)
            (i32.const 31)
           )
          )
          (if
           (i32.le_u
            (local.get $8)
            (i32.const -33)
           )
           (then
            (local.set $11
             (i32.or
              (i32.shl
               (local.get $12)
               (i32.const 6)
              )
              (local.get $9)
             )
            )
            (br $block18
             (i32.add
              (local.get $5)
              (i32.const 2)
             )
            )
           )
          )
          (local.set $9
           (i32.or
            (i32.and
             (i32.load8_u offset=2
              (local.get $5)
             )
             (i32.const 63)
            )
            (i32.shl
             (local.get $9)
             (i32.const 6)
            )
           )
          )
          (if
           (i32.lt_u
            (local.get $8)
            (i32.const -16)
           )
           (then
            (local.set $11
             (i32.or
              (local.get $9)
              (i32.shl
               (local.get $12)
               (i32.const 12)
              )
             )
            )
            (br $block18
             (i32.add
              (local.get $5)
              (i32.const 3)
             )
            )
           )
          )
          (local.set $11
           (i32.or
            (i32.and
             (i32.shl
              (local.get $12)
              (i32.const 18)
             )
             (i32.const 1835008)
            )
            (i32.or
             (i32.and
              (i32.load8_u offset=3
               (local.get $5)
              )
              (i32.const 63)
             )
             (i32.shl
              (local.get $9)
              (i32.const 6)
             )
            )
           )
          )
          (i32.add
           (local.get $5)
           (i32.const 4)
          )
         )
        )
        (call $_RNvMNtNtCsdHhIpgkcIfN_4core4char7methodsc16escape_debug_ext
         (i32.add
          (local.get $4)
          (i32.const 8)
         )
         (local.get $11)
         (i32.const 65537)
        )
        (if
         (i32.ne
          (i32.and
           (i32.sub
            (i32.load8_u offset=21
             (local.get $4)
            )
            (i32.load8_u offset=20
             (local.get $4)
            )
           )
           (i32.const 255)
          )
          (i32.const 1)
         )
         (then
          (block $block23
           (block $block22
            (block $block19
             (br_if $block19
              (i32.gt_u
               (local.get $1)
               (local.get $7)
              )
             )
             (block $block20
              (br_if $block20
               (i32.eqz
                (local.get $1)
               )
              )
              (if
               (i32.le_u
                (local.get $0)
                (local.get $1)
               )
               (then
                (br_if $block19
                 (i32.ne
                  (local.get $0)
                  (local.get $1)
                 )
                )
                (br $block20)
               )
              )
              (br_if $block19
               (i32.le_s
                (i32.load8_s
                 (i32.add
                  (local.get $1)
                  (local.get $2)
                 )
                )
                (i32.const -65)
               )
              )
             )
             (block $block21
              (br_if $block21
               (i32.eqz
                (local.get $7)
               )
              )
              (if
               (i32.le_u
                (local.get $0)
                (local.get $7)
               )
               (then
                (br_if $block21
                 (i32.eq
                  (local.get $0)
                  (local.get $7)
                 )
                )
                (br $block19)
               )
              )
              (br_if $block19
               (i32.le_s
                (i32.load8_s
                 (i32.add
                  (local.get $2)
                  (local.get $7)
                 )
                )
                (i32.const -65)
               )
              )
             )
             (br_if $block
              (call_indirect $0 (type $0)
               (local.get $13)
               (i32.add
                (local.get $1)
                (local.get $2)
               )
               (i32.sub
                (local.get $7)
                (local.get $1)
               )
               (i32.load offset=12
                (local.get $16)
               )
              )
             )
             (i64.store offset=32
              (local.get $4)
              (i64.load offset=16 align=4
               (local.get $4)
              )
             )
             (i64.store offset=24
              (local.get $4)
              (local.tee $19
               (i64.load offset=8 align=4
                (local.get $4)
               )
              )
             )
             (local.set $1
              (i32.load8_u offset=36
               (local.get $4)
              )
             )
             (br_if $block22
              (i32.lt_u
               (local.tee $8
                (i32.load8_u offset=37
                 (local.get $4)
                )
               )
               (i32.const 129)
              )
             )
             (local.set $12
              (i32.wrap_i64
               (local.get $19)
              )
             )
             (loop $label1
              (br_if $block23
               (i32.ge_u
                (i32.and
                 (local.get $1)
                 (i32.const 255)
                )
                (local.get $8)
               )
              )
              (local.set $1
               (i32.add
                (local.get $1)
                (i32.const 1)
               )
              )
              (br_if $label1
               (i32.eqz
                (call_indirect $0 (type $1)
                 (local.get $13)
                 (local.get $12)
                 (local.get $17)
                )
               )
              )
             )
             (br $block)
            )
            (call $_RNvNtCsdHhIpgkcIfN_4core3str16slice_error_fail
             (local.get $2)
             (local.get $0)
             (local.get $1)
             (local.get $7)
             (i32.const 1054500)
            )
            (unreachable)
           )
           (local.set $8
            (select
             (local.get $1)
             (local.get $8)
             (i32.gt_u
              (local.get $1)
              (local.get $8)
             )
            )
           )
           (loop $label2
            (br_if $block23
             (i32.eq
              (local.get $1)
              (local.get $8)
             )
            )
            (local.set $12
             (i32.add
              (i32.add
               (local.get $4)
               (i32.const 24)
              )
              (local.get $1)
             )
            )
            (local.set $1
             (i32.add
              (local.get $1)
              (i32.const 1)
             )
            )
            (br_if $label2
             (i32.eqz
              (call_indirect $0 (type $1)
               (local.get $13)
               (i32.load8_u
                (local.get $12)
               )
               (local.get $17)
              )
             )
            )
           )
           (br $block)
          )
          (local.set $1
           (i32.add
            (block $block24 (result i32)
             (drop
              (br_if $block24
               (i32.const 1)
               (i32.lt_u
                (local.get $11)
                (i32.const 128)
               )
              )
             )
             (drop
              (br_if $block24
               (i32.const 2)
               (i32.lt_u
                (local.get $11)
                (i32.const 2048)
               )
              )
             )
             (select
              (i32.const 3)
              (i32.const 4)
              (i32.lt_u
               (local.get $11)
               (i32.const 65536)
              )
             )
            )
            (local.get $7)
           )
          )
         )
        )
        (local.set $7
         (i32.add
          (i32.sub
           (local.get $7)
           (local.get $5)
          )
          (local.get $9)
         )
        )
        (br_if $label3
         (i32.ne
          (local.tee $5
           (local.get $9)
          )
          (local.get $14)
         )
        )
       )
       (if
        (i32.eqz
         (local.get $1)
        )
        (then
         (local.set $1
          (i32.const 0)
         )
         (br $block17)
        )
       )
       (if
        (i32.le_u
         (local.get $0)
         (local.get $1)
        )
        (then
         (br_if $block25
          (i32.ne
           (local.get $0)
           (local.get $1)
          )
         )
         (local.set $1
          (local.get $0)
         )
         (br $block17)
        )
       )
       (br_if $block25
        (i32.lt_s
         (i32.load8_s
          (i32.add
           (local.get $1)
           (local.get $2)
          )
         )
         (i32.const -64)
        )
       )
      )
      (br_if $block
       (call_indirect $0 (type $0)
        (local.get $13)
        (i32.add
         (local.get $1)
         (local.get $2)
        )
        (i32.sub
         (local.get $0)
         (local.get $1)
        )
        (i32.load offset=12
         (local.get $16)
        )
       )
      )
      (br_if $label4
       (i32.eq
        (local.get $0)
        (local.get $3)
       )
      )
      (local.set $0
       (i32.add
        (local.get $2)
        (local.get $3)
       )
      )
      (loop $label5
       (i32.store8 offset=47
        (local.get $4)
        (i32.load8_u
         (local.get $14)
        )
       )
       (i64.store offset=24
        (local.get $4)
        (local.get $18)
       )
       (br_if $block
        (call $_RNvNtCsdHhIpgkcIfN_4core3fmt5write
         (local.get $13)
         (local.get $16)
         (i32.const 1054488)
         (i32.add
          (local.get $4)
          (i32.const 24)
         )
        )
       )
       (br_if $label5
        (i32.ne
         (local.get $0)
         (local.tee $14
          (i32.add
           (local.get $14)
           (i32.const 1)
          )
         )
        )
       )
      )
      (br $label4)
     )
    )
    (call $_RNvNtCsdHhIpgkcIfN_4core3str16slice_error_fail
     (local.get $2)
     (local.get $0)
     (local.get $1)
     (local.get $0)
     (i32.const 1054472)
    )
    (unreachable)
   )
   (local.set $15
    (call_indirect $0 (type $1)
     (local.get $13)
     (i32.const 34)
     (local.get $17)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $4)
    (i32.const 48)
   )
  )
  (local.get $15)
 )
 (func $read (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=12
   (local.get $3)
   (local.get $2)
  )
  (i32.store offset=8
   (local.get $3)
   (local.get $1)
  )
  (local.set $scratch
   (block $block (result i32)
    (if
     (local.tee $0
      (i32.and
       (call $__imported_wasi_snapshot_preview1_fd_read
        (local.get $0)
        (i32.add
         (local.get $3)
         (i32.const 8)
        )
        (i32.const 1)
        (i32.add
         (local.get $3)
         (i32.const 4)
        )
       )
       (i32.const 65535)
      )
     )
     (then
      (i32.store
       (i32.const 1061060)
       (select
        (i32.const 8)
        (local.get $0)
        (i32.eq
         (local.get $0)
         (i32.const 76)
        )
       )
      )
      (br $block
       (i32.const -1)
      )
     )
    )
    (i32.load offset=4
     (local.get $3)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $write (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=12
   (local.get $3)
   (local.get $2)
  )
  (i32.store offset=8
   (local.get $3)
   (local.get $1)
  )
  (local.set $scratch
   (block $block (result i32)
    (if
     (local.tee $0
      (i32.and
       (call $__imported_wasi_snapshot_preview1_fd_write
        (local.get $0)
        (i32.add
         (local.get $3)
         (i32.const 8)
        )
        (i32.const 1)
        (i32.add
         (local.get $3)
         (i32.const 4)
        )
       )
       (i32.const 65535)
      )
     )
     (then
      (i32.store
       (i32.const 1061060)
       (select
        (i32.const 8)
        (local.get $0)
        (i32.eq
         (local.get $0)
         (i32.const 76)
        )
       )
      )
      (br $block
       (i32.const -1)
      )
     )
    )
    (i32.load offset=4
     (local.get $3)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $3)
    (i32.const 16)
   )
  )
  (local.get $scratch)
 )
 (func $close (param $0 i32)
  (call $__wasilibc_populate_preopens)
  (if
   (i32.eqz
    (local.tee $0
     (i32.and
      (call $__imported_wasi_snapshot_preview1_fd_close
       (local.get $0)
      )
      (i32.const 65535)
     )
    )
   )
   (then
    (return)
   )
  )
  (i32.store
   (i32.const 1061060)
   (local.get $0)
  )
 )
 (func $__wasi_proc_exit (param $0 i32)
  (call $__imported_wasi_snapshot_preview1_proc_exit
   (local.get $0)
  )
  (unreachable)
 )
 (func $_Exit (param $0 i32)
  (call $__wasi_proc_exit
   (local.get $0)
  )
  (unreachable)
 )
 (func $__wasilibc_populate_preopens
  (local $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $scratch i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block
   (br_if $block
    (local.tee $0
     (i32.and
      (i32.load8_u
       (i32.const 1061080)
      )
      (i32.const 1)
     )
    )
   )
   (br_if $block
    (local.get $0)
   )
   (local.set $3
    (i32.const 3)
   )
   (block $block2
    (loop $label1
     (block $block1
      (if
       (local.tee $0
        (i32.and
         (call $__imported_wasi_snapshot_preview1_fd_prestat_get
          (local.get $3)
          (i32.add
           (local.get $2)
           (i32.const 8)
          )
         )
         (i32.const 65535)
        )
       )
       (then
        (br_if $block1
         (i32.ne
          (local.get $0)
          (i32.const 8)
         )
        )
        (i32.store8
         (i32.const 1061080)
         (i32.const 1)
        )
        (br $block)
       )
      )
      (if
       (i32.eqz
        (i32.load8_u offset=8
         (local.get $2)
        )
       )
       (then
        (br_if $block2
         (i32.eqz
          (local.tee $5
           (call $dlmalloc
            (i32.add
             (local.tee $0
              (i32.load offset=12
               (local.get $2)
              )
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (br_if $block1
         (i32.and
          (call $__imported_wasi_snapshot_preview1_fd_prestat_dir_name
           (local.get $3)
           (local.get $5)
           (local.get $0)
          )
          (i32.const 65535)
         )
        )
        (i32.store8
         (i32.add
          (local.get $5)
          (i32.load offset=12
           (local.get $2)
          )
         )
         (i32.const 0)
        )
        (br_if $block2
         (block (result i32)
          (local.set $scratch
           (block $block3 (result i32)
            (local.set $0
             (local.get $5)
            )
            (if
             (i32.eq
              (local.tee $4
               (i32.load
                (i32.const 1061072)
               )
              )
              (i32.load
               (i32.const 1061084)
              )
             )
             (then
              (local.set $1
               (i32.load
                (i32.const 1061076)
               )
              )
              (drop
               (br_if $block3
                (i32.const -1)
                (i32.eqz
                 (local.tee $6
                  (call $calloc
                   (i32.const 8)
                   (local.tee $7
                    (select
                     (i32.shl
                      (local.get $4)
                      (i32.const 1)
                     )
                     (i32.const 4)
                     (local.get $4)
                    )
                   )
                  )
                 )
                )
               )
              )
              (if
               (local.tee $8
                (i32.shl
                 (local.get $4)
                 (i32.const 3)
                )
               )
               (then
                (memory.copy
                 (local.get $6)
                 (local.get $1)
                 (local.get $8)
                )
               )
              )
              (i32.store
               (i32.const 1061084)
               (local.get $7)
              )
              (i32.store
               (i32.const 1061076)
               (local.get $6)
              )
              (call $dlfree
               (local.get $1)
              )
             )
            )
            (loop $label
             (block $block6
              (block $block4
               (block $block5
                (br_table $block4 $block5 $block6
                 (i32.sub
                  (i32.load8_u
                   (local.tee $1
                    (local.get $0)
                   )
                  )
                  (i32.const 46)
                 )
                )
               )
               (local.set $0
                (i32.add
                 (local.get $1)
                 (i32.const 1)
                )
               )
               (br $label)
              )
              (local.set $0
               (i32.add
                (local.get $1)
                (i32.const 1)
               )
              )
              (br_if $label
               (i32.eqz
                (local.tee $6
                 (i32.load8_u offset=1
                  (local.get $1)
                 )
                )
               )
              )
              (br_if $block6
               (i32.ne
                (local.get $6)
                (i32.const 47)
               )
              )
              (local.set $0
               (i32.add
                (local.get $1)
                (i32.const 2)
               )
              )
              (br $label)
             )
            )
            (drop
             (br_if $block3
              (i32.const -1)
              (i32.eqz
               (local.tee $0
                (call $strdup
                 (local.get $1)
                )
               )
              )
             )
            )
            (i32.store
             (i32.const 1061072)
             (i32.add
              (local.get $4)
              (i32.const 1)
             )
            )
            (i32.store offset=4
             (local.tee $1
              (i32.add
               (i32.load
                (i32.const 1061076)
               )
               (i32.shl
                (local.get $4)
                (i32.const 3)
               )
              )
             )
             (local.get $3)
            )
            (i32.store
             (local.get $1)
             (local.get $0)
            )
            (i32.const 0)
           )
          )
          (call $dlfree
           (local.get $5)
          )
          (local.get $scratch)
         )
        )
       )
      )
      (local.set $3
       (i32.add
        (local.get $3)
        (i32.const 1)
       )
      )
      (br $label1)
     )
    )
    (call $_Exit
     (i32.const 71)
    )
    (unreachable)
   )
   (call $_Exit
    (i32.const 70)
   )
   (unreachable)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 16)
   )
  )
 )
 (func $memcmp (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (block $block
   (br_if $block
    (i32.eqz
     (local.get $2)
    )
   )
   (loop $label
    (if
     (i32.eq
      (local.tee $4
       (i32.load8_u
        (local.get $0)
       )
      )
      (local.tee $5
       (i32.load8_u
        (local.get $1)
       )
      )
     )
     (then
      (local.set $1
       (i32.add
        (local.get $1)
        (i32.const 1)
       )
      )
      (local.set $0
       (i32.add
        (local.get $0)
        (i32.const 1)
       )
      )
      (br_if $label
       (local.tee $2
        (i32.sub
         (local.get $2)
         (i32.const 1)
        )
       )
      )
      (br $block)
     )
    )
   )
   (local.set $3
    (i32.sub
     (local.get $4)
     (local.get $5)
    )
   )
  )
  (local.get $3)
 )
 (func $strdup (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (block $block
   (br_if $block
    (i32.eqz
     (local.tee $2
      (call $dlmalloc
       (local.tee $1
        (i32.add
         (call $strlen
          (local.get $0)
         )
         (i32.const 1)
        )
       )
      )
     )
    )
   )
   (br_if $block
    (i32.eqz
     (local.get $1)
    )
   )
   (memory.copy
    (local.get $2)
    (local.get $0)
    (local.get $1)
   )
  )
  (local.get $2)
 )
 (func $strlen (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $scratch i32)
  (block $block1
   (block $block
    (br_if $block
     (i32.eqz
      (i32.and
       (local.tee $1
        (local.get $0)
       )
       (i32.const 3)
      )
     )
    )
    (if
     (i32.eqz
      (i32.load8_u
       (local.get $1)
      )
     )
     (then
      (return
       (i32.const 0)
      )
     )
    )
    (br_if $block
     (i32.eqz
      (i32.and
       (local.tee $1
        (i32.add
         (local.get $0)
         (i32.const 1)
        )
       )
       (i32.const 3)
      )
     )
    )
    (br_if $block1
     (i32.eqz
      (i32.load8_u
       (local.get $1)
      )
     )
    )
    (br_if $block
     (i32.eqz
      (i32.and
       (local.tee $1
        (i32.add
         (local.get $0)
         (i32.const 2)
        )
       )
       (i32.const 3)
      )
     )
    )
    (br_if $block1
     (i32.eqz
      (i32.load8_u
       (local.get $1)
      )
     )
    )
    (br_if $block
     (i32.eqz
      (i32.and
       (local.tee $1
        (i32.add
         (local.get $0)
         (i32.const 3)
        )
       )
       (i32.const 3)
      )
     )
    )
    (br_if $block1
     (i32.eqz
      (i32.load8_u
       (local.get $1)
      )
     )
    )
    (br_if $block1
     (i32.and
      (local.tee $1
       (i32.add
        (local.get $0)
        (i32.const 4)
       )
      )
      (i32.const 3)
     )
    )
   )
   (local.set $2
    (i32.sub
     (local.get $1)
     (i32.const 4)
    )
   )
   (local.set $1
    (i32.sub
     (local.get $1)
     (i32.const 5)
    )
   )
   (loop $label
    (local.set $1
     (i32.add
      (local.get $1)
      (i32.const 4)
     )
    )
    (br_if $label
     (i32.eq
      (i32.and
       (i32.or
        (i32.sub
         (i32.const 16843008)
         (local.tee $3
          (i32.load
           (local.tee $2
            (i32.add
             (local.get $2)
             (i32.const 4)
            )
           )
          )
         )
        )
        (local.get $3)
       )
       (i32.const -2139062144)
      )
      (i32.const -2139062144)
     )
    )
   )
   (loop $label1
    (local.set $1
     (i32.add
      (local.get $1)
      (i32.const 1)
     )
    )
    (br_if $label1
     (block (result i32)
      (local.set $scratch
       (i32.load8_u
        (local.get $2)
       )
      )
      (local.set $2
       (i32.add
        (local.get $2)
        (i32.const 1)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
  (i32.sub
   (local.get $1)
   (local.get $0)
  )
 )
 (func $sbrk (param $0 i32) (result i32)
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (return
     (i32.shl
      (memory.size)
      (i32.const 16)
     )
    )
   )
  )
  (block $block
   (br_if $block
    (i32.and
     (local.get $0)
     (i32.const 65535)
    )
   )
   (br_if $block
    (i32.lt_s
     (local.get $0)
     (i32.const 0)
    )
   )
   (if
    (i32.eq
     (local.tee $0
      (memory.grow
       (i32.shr_u
        (local.get $0)
        (i32.const 16)
       )
      )
     )
     (i32.const -1)
    )
    (then
     (i32.store
      (i32.const 1061060)
      (i32.const 48)
     )
     (return
      (i32.const -1)
     )
    )
   )
   (return
    (i32.shl
     (local.get $0)
     (i32.const 16)
    )
   )
  )
  (unreachable)
 )
 (func $dlmalloc (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (global.set $__stack_pointer
   (local.tee $10
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (if
   (i32.eqz
    (local.tee $7
     (i32.load
      (i32.const 1061256)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (local.tee $3
       (i32.load
        (i32.const 1061704)
       )
      )
     )
     (then
      (i64.store align=4
       (i32.const 1061716)
       (i64.const -1)
      )
      (i64.store align=4
       (i32.const 1061708)
       (i64.const 281474976776192)
      )
      (i32.store
       (i32.const 1061704)
       (local.tee $3
        (i32.xor
         (i32.and
          (i32.add
           (local.get $10)
           (i32.const 8)
          )
          (i32.const -16)
         )
         (i32.const 1431655768)
        )
       )
      )
      (i32.store
       (i32.const 1061724)
       (i32.const 0)
      )
      (i32.store
       (i32.const 1061676)
       (i32.const 0)
      )
     )
    )
    (i32.store
     (i32.const 1061680)
     (i32.const 1061728)
    )
    (i32.store
     (i32.const 1061248)
     (i32.const 1061728)
    )
    (i32.store
     (i32.const 1061268)
     (local.get $3)
    )
    (i32.store
     (i32.const 1061264)
     (i32.const -1)
    )
    (i32.store
     (i32.const 1061684)
     (i32.const 52384)
    )
    (i32.store
     (i32.const 1061668)
     (i32.const 52384)
    )
    (i32.store
     (i32.const 1061664)
     (i32.const 52384)
    )
    (loop $label
     (i32.store
      (i32.add
       (local.get $1)
       (i32.const 1061292)
      )
      (local.tee $2
       (i32.add
        (local.get $1)
        (i32.const 1061280)
       )
      )
     )
     (i32.store
      (local.get $2)
      (local.tee $5
       (i32.add
        (local.get $1)
        (i32.const 1061272)
       )
      )
     )
     (i32.store
      (i32.add
       (local.get $1)
       (i32.const 1061284)
      )
      (local.get $5)
     )
     (i32.store
      (i32.add
       (local.get $1)
       (i32.const 1061300)
      )
      (local.tee $5
       (i32.add
        (local.get $1)
        (i32.const 1061288)
       )
      )
     )
     (i32.store
      (local.get $5)
      (local.get $2)
     )
     (i32.store
      (i32.add
       (local.get $1)
       (i32.const 1061308)
      )
      (local.tee $2
       (i32.add
        (local.get $1)
        (i32.const 1061296)
       )
      )
     )
     (i32.store
      (local.get $2)
      (local.get $5)
     )
     (i32.store
      (i32.add
       (local.get $1)
       (i32.const 1061304)
      )
      (local.get $2)
     )
     (br_if $label
      (i32.ne
       (local.tee $1
        (i32.add
         (local.get $1)
         (i32.const 32)
        )
       )
       (i32.const 256)
      )
     )
    )
    (i32.store
     (i32.const 1114060)
     (i32.const 56)
    )
    (i32.store
     (i32.const 1061260)
     (i32.load
      (i32.const 1061720)
     )
    )
    (i32.store
     (i32.const 1061256)
     (local.tee $7
      (i32.const 1061736)
     )
    )
    (i32.store
     (i32.const 1061244)
     (i32.const 52320)
    )
    (i32.store
     (i32.const 1061740)
     (i32.const 52321)
    )
   )
  )
  (block $block1
   (block $block6
    (block $block12
     (block $block29
      (block $block24
       (block $block21
        (block $block17
         (block $block19
          (block $block22
           (block $block13
            (block $block7
             (block $block2
              (if
               (i32.le_u
                (local.get $0)
                (i32.const 236)
               )
               (then
                (if
                 (i32.and
                  (local.tee $1
                   (i32.shr_u
                    (local.tee $4
                     (i32.load
                      (i32.const 1061232)
                     )
                    )
                    (local.tee $0
                     (i32.shr_u
                      (local.tee $6
                       (select
                        (i32.const 16)
                        (i32.and
                         (i32.add
                          (local.get $0)
                          (i32.const 19)
                         )
                         (i32.const 496)
                        )
                        (i32.lt_u
                         (local.get $0)
                         (i32.const 11)
                        )
                       )
                      )
                      (i32.const 3)
                     )
                    )
                   )
                  )
                  (i32.const 3)
                 )
                 (then
                  (block $block
                   (if
                    (i32.eq
                     (local.tee $1
                      (i32.add
                       (local.tee $0
                        (i32.shl
                         (local.tee $2
                          (i32.xor
                           (i32.or
                            (i32.and
                             (local.get $1)
                             (i32.const 1)
                            )
                            (local.get $0)
                           )
                           (i32.const 1)
                          )
                         )
                         (i32.const 3)
                        )
                       )
                       (i32.const 1061272)
                      )
                     )
                     (local.tee $5
                      (i32.load offset=8
                       (local.tee $0
                        (i32.load offset=1061280
                         (local.get $0)
                        )
                       )
                      )
                     )
                    )
                    (then
                     (i32.store
                      (i32.const 1061232)
                      (i32.and
                       (local.get $4)
                       (i32.rotl
                        (i32.const -2)
                        (local.get $2)
                       )
                      )
                     )
                     (br $block)
                    )
                   )
                   (i32.store offset=8
                    (local.get $1)
                    (local.get $5)
                   )
                   (i32.store offset=12
                    (local.get $5)
                    (local.get $1)
                   )
                  )
                  (local.set $1
                   (i32.add
                    (local.get $0)
                    (i32.const 8)
                   )
                  )
                  (i32.store offset=4
                   (local.get $0)
                   (i32.or
                    (local.tee $2
                     (i32.shl
                      (local.get $2)
                      (i32.const 3)
                     )
                    )
                    (i32.const 3)
                   )
                  )
                  (i32.store offset=4
                   (local.tee $0
                    (i32.add
                     (local.get $0)
                     (local.get $2)
                    )
                   )
                   (i32.or
                    (i32.load offset=4
                     (local.get $0)
                    )
                    (i32.const 1)
                   )
                  )
                  (br $block1)
                 )
                )
                (br_if $block2
                 (i32.le_u
                  (local.get $6)
                  (local.tee $8
                   (i32.load
                    (i32.const 1061240)
                   )
                  )
                 )
                )
                (if
                 (local.get $1)
                 (then
                  (block $block3
                   (if
                    (i32.eq
                     (local.tee $2
                      (i32.add
                       (local.tee $0
                        (i32.shl
                         (local.tee $1
                          (i32.ctz
                           (i32.and
                            (i32.or
                             (local.tee $2
                              (i32.shl
                               (i32.const 2)
                               (local.get $0)
                              )
                             )
                             (i32.sub
                              (i32.const 0)
                              (local.get $2)
                             )
                            )
                            (i32.shl
                             (local.get $1)
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (i32.const 3)
                        )
                       )
                       (i32.const 1061272)
                      )
                     )
                     (local.tee $5
                      (i32.load offset=8
                       (local.tee $0
                        (i32.load offset=1061280
                         (local.get $0)
                        )
                       )
                      )
                     )
                    )
                    (then
                     (i32.store
                      (i32.const 1061232)
                      (local.tee $4
                       (i32.and
                        (local.get $4)
                        (i32.rotl
                         (i32.const -2)
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (br $block3)
                    )
                   )
                   (i32.store offset=8
                    (local.get $2)
                    (local.get $5)
                   )
                   (i32.store offset=12
                    (local.get $5)
                    (local.get $2)
                   )
                  )
                  (i32.store offset=4
                   (local.get $0)
                   (i32.or
                    (local.get $6)
                    (i32.const 3)
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (local.tee $1
                     (i32.shl
                      (local.get $1)
                      (i32.const 3)
                     )
                    )
                   )
                   (local.tee $5
                    (i32.sub
                     (local.get $1)
                     (local.get $6)
                    )
                   )
                  )
                  (i32.store offset=4
                   (local.tee $3
                    (i32.add
                     (local.get $0)
                     (local.get $6)
                    )
                   )
                   (i32.or
                    (local.get $5)
                    (i32.const 1)
                   )
                  )
                  (if
                   (local.get $8)
                   (then
                    (local.set $1
                     (i32.add
                      (i32.and
                       (local.get $8)
                       (i32.const -8)
                      )
                      (i32.const 1061272)
                     )
                    )
                    (local.set $2
                     (i32.load
                      (i32.const 1061252)
                     )
                    )
                    (i32.store offset=12
                     (local.tee $4
                      (block $block4 (result i32)
                       (if
                        (i32.eqz
                         (i32.and
                          (local.get $4)
                          (local.tee $7
                           (i32.shl
                            (i32.const 1)
                            (i32.shr_u
                             (local.get $8)
                             (i32.const 3)
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i32.store
                          (i32.const 1061232)
                          (i32.or
                           (local.get $4)
                           (local.get $7)
                          )
                         )
                         (br $block4
                          (local.get $1)
                         )
                        )
                       )
                       (i32.load offset=8
                        (local.get $1)
                       )
                      )
                     )
                     (local.get $2)
                    )
                    (i32.store offset=8
                     (local.get $1)
                     (local.get $2)
                    )
                    (i32.store offset=12
                     (local.get $2)
                     (local.get $1)
                    )
                    (i32.store offset=8
                     (local.get $2)
                     (local.get $4)
                    )
                   )
                  )
                  (local.set $1
                   (i32.add
                    (local.get $0)
                    (i32.const 8)
                   )
                  )
                  (i32.store
                   (i32.const 1061252)
                   (local.get $3)
                  )
                  (i32.store
                   (i32.const 1061240)
                   (local.get $5)
                  )
                  (br $block1)
                 )
                )
                (br_if $block2
                 (i32.eqz
                  (local.tee $11
                   (i32.load
                    (i32.const 1061236)
                   )
                  )
                 )
                )
                (local.set $3
                 (i32.sub
                  (i32.and
                   (i32.load offset=4
                    (local.tee $2
                     (i32.load offset=1061536
                      (i32.shl
                       (i32.ctz
                        (local.get $11)
                       )
                       (i32.const 2)
                      )
                     )
                    )
                   )
                   (i32.const -8)
                  )
                  (local.get $6)
                 )
                )
                (local.set $0
                 (local.get $2)
                )
                (loop $label1
                 (block $block5
                  (if
                   (i32.eqz
                    (local.tee $1
                     (i32.load offset=16
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (br_if $block5
                     (i32.eqz
                      (local.tee $1
                       (i32.load offset=20
                        (local.get $0)
                       )
                      )
                     )
                    )
                   )
                  )
                  (local.set $3
                   (select
                    (local.tee $0
                     (i32.sub
                      (i32.and
                       (i32.load offset=4
                        (local.get $1)
                       )
                       (i32.const -8)
                      )
                      (local.get $6)
                     )
                    )
                    (local.get $3)
                    (local.tee $0
                     (i32.lt_u
                      (local.get $0)
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (local.set $2
                   (select
                    (local.get $1)
                    (local.get $2)
                    (local.get $0)
                   )
                  )
                  (local.set $0
                   (local.get $1)
                  )
                  (br $label1)
                 )
                )
                (local.set $9
                 (i32.load offset=24
                  (local.get $2)
                 )
                )
                (if
                 (i32.ne
                  (local.get $2)
                  (local.tee $1
                   (i32.load offset=12
                    (local.get $2)
                   )
                  )
                 )
                 (then
                  (i32.store offset=12
                   (local.tee $0
                    (i32.load offset=8
                     (local.get $2)
                    )
                   )
                   (local.get $1)
                  )
                  (i32.store offset=8
                   (local.get $1)
                   (local.get $0)
                  )
                  (br $block6)
                 )
                )
                (local.set $5
                 (if (result i32)
                  (local.tee $0
                   (i32.load offset=20
                    (local.get $2)
                   )
                  )
                  (then
                   (i32.add
                    (local.get $2)
                    (i32.const 20)
                   )
                  )
                  (else
                   (br_if $block7
                    (i32.eqz
                     (local.tee $0
                      (i32.load offset=16
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (i32.add
                    (local.get $2)
                    (i32.const 16)
                   )
                  )
                 )
                )
                (loop $label2
                 (local.set $7
                  (local.get $5)
                 )
                 (local.set $5
                  (i32.add
                   (local.tee $1
                    (local.get $0)
                   )
                   (i32.const 20)
                  )
                 )
                 (br_if $label2
                  (local.tee $0
                   (i32.load offset=20
                    (local.get $1)
                   )
                  )
                 )
                 (local.set $5
                  (i32.add
                   (local.get $1)
                   (i32.const 16)
                  )
                 )
                 (br_if $label2
                  (local.tee $0
                   (i32.load offset=16
                    (local.get $1)
                   )
                  )
                 )
                )
                (i32.store
                 (local.get $7)
                 (i32.const 0)
                )
                (br $block6)
               )
              )
              (local.set $6
               (i32.const -1)
              )
              (br_if $block2
               (i32.gt_u
                (local.get $0)
                (i32.const -65)
               )
              )
              (local.set $6
               (i32.and
                (local.tee $1
                 (i32.add
                  (local.get $0)
                  (i32.const 19)
                 )
                )
                (i32.const -16)
               )
              )
              (br_if $block2
               (i32.eqz
                (local.tee $8
                 (i32.load
                  (i32.const 1061236)
                 )
                )
               )
              )
              (local.set $9
               (i32.const 31)
              )
              (local.set $3
               (i32.sub
                (i32.const 0)
                (local.get $6)
               )
              )
              (if
               (i32.le_u
                (local.get $0)
                (i32.const 16777196)
               )
               (then
                (local.set $9
                 (i32.add
                  (i32.sub
                   (i32.and
                    (i32.shr_u
                     (local.get $6)
                     (i32.sub
                      (i32.const 38)
                      (local.tee $0
                       (i32.clz
                        (i32.shr_u
                         (local.get $1)
                         (i32.const 8)
                        )
                       )
                      )
                     )
                    )
                    (i32.const 1)
                   )
                   (i32.shl
                    (local.get $0)
                    (i32.const 1)
                   )
                  )
                  (i32.const 62)
                 )
                )
               )
              )
              (block $block11
               (block $block10
                (block $block8
                 (if
                  (i32.eqz
                   (local.tee $0
                    (i32.load offset=1061536
                     (i32.shl
                      (local.get $9)
                      (i32.const 2)
                     )
                    )
                   )
                  )
                  (then
                   (local.set $1
                    (i32.const 0)
                   )
                   (local.set $5
                    (i32.const 0)
                   )
                   (br $block8)
                  )
                 )
                 (local.set $1
                  (i32.const 0)
                 )
                 (local.set $2
                  (i32.shl
                   (local.get $6)
                   (select
                    (i32.sub
                     (i32.const 25)
                     (i32.shr_u
                      (local.get $9)
                      (i32.const 1)
                     )
                    )
                    (i32.const 0)
                    (i32.ne
                     (local.get $9)
                     (i32.const 31)
                    )
                   )
                  )
                 )
                 (local.set $5
                  (i32.const 0)
                 )
                 (loop $label3
                  (block $block9
                   (br_if $block9
                    (i32.ge_u
                     (local.tee $4
                      (i32.sub
                       (i32.and
                        (i32.load offset=4
                         (local.get $0)
                        )
                        (i32.const -8)
                       )
                       (local.get $6)
                      )
                     )
                     (local.get $3)
                    )
                   )
                   (local.set $5
                    (local.get $0)
                   )
                   (br_if $block9
                    (local.tee $3
                     (local.get $4)
                    )
                   )
                   (local.set $3
                    (i32.const 0)
                   )
                   (local.set $1
                    (local.get $0)
                   )
                   (br $block10)
                  )
                  (local.set $1
                   (select
                    (select
                     (local.get $1)
                     (local.tee $4
                      (i32.load offset=20
                       (local.get $0)
                      )
                     )
                     (i32.eq
                      (local.get $4)
                      (local.tee $0
                       (i32.load offset=16
                        (i32.add
                         (local.get $0)
                         (i32.and
                          (i32.shr_u
                           (local.get $2)
                           (i32.const 29)
                          )
                          (i32.const 4)
                         )
                        )
                       )
                      )
                     )
                    )
                    (local.get $1)
                    (local.get $4)
                   )
                  )
                  (local.set $2
                   (i32.shl
                    (local.get $2)
                    (i32.const 1)
                   )
                  )
                  (br_if $label3
                   (local.get $0)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (i32.or
                   (local.get $1)
                   (local.get $5)
                  )
                 )
                 (then
                  (local.set $5
                   (i32.const 0)
                  )
                  (br_if $block2
                   (i32.eqz
                    (local.tee $0
                     (i32.and
                      (i32.or
                       (local.tee $0
                        (i32.shl
                         (i32.const 2)
                         (local.get $9)
                        )
                       )
                       (i32.sub
                        (i32.const 0)
                        (local.get $0)
                       )
                      )
                      (local.get $8)
                     )
                    )
                   )
                  )
                  (local.set $1
                   (i32.load offset=1061536
                    (i32.shl
                     (i32.ctz
                      (local.get $0)
                     )
                     (i32.const 2)
                    )
                   )
                  )
                 )
                )
                (br_if $block11
                 (i32.eqz
                  (local.get $1)
                 )
                )
               )
               (loop $label4
                (local.set $0
                 (i32.lt_u
                  (local.tee $2
                   (i32.sub
                    (i32.and
                     (i32.load offset=4
                      (local.get $1)
                     )
                     (i32.const -8)
                    )
                    (local.get $6)
                   )
                  )
                  (local.get $3)
                 )
                )
                (local.set $3
                 (select
                  (local.get $2)
                  (local.get $3)
                  (local.get $0)
                 )
                )
                (local.set $5
                 (select
                  (local.get $1)
                  (local.get $5)
                  (local.get $0)
                 )
                )
                (br_if $label4
                 (local.tee $1
                  (if (result i32)
                   (local.tee $0
                    (i32.load offset=16
                     (local.get $1)
                    )
                   )
                   (then
                    (local.get $0)
                   )
                   (else
                    (i32.load offset=20
                     (local.get $1)
                    )
                   )
                  )
                 )
                )
               )
              )
              (br_if $block2
               (i32.eqz
                (local.get $5)
               )
              )
              (br_if $block2
               (i32.ge_u
                (local.get $3)
                (i32.sub
                 (i32.load
                  (i32.const 1061240)
                 )
                 (local.get $6)
                )
               )
              )
              (local.set $7
               (i32.load offset=24
                (local.get $5)
               )
              )
              (if
               (i32.ne
                (local.get $5)
                (local.tee $1
                 (i32.load offset=12
                  (local.get $5)
                 )
                )
               )
               (then
                (i32.store offset=12
                 (local.tee $0
                  (i32.load offset=8
                   (local.get $5)
                  )
                 )
                 (local.get $1)
                )
                (i32.store offset=8
                 (local.get $1)
                 (local.get $0)
                )
                (br $block12)
               )
              )
              (local.set $2
               (if (result i32)
                (local.tee $0
                 (i32.load offset=20
                  (local.get $5)
                 )
                )
                (then
                 (i32.add
                  (local.get $5)
                  (i32.const 20)
                 )
                )
                (else
                 (br_if $block13
                  (i32.eqz
                   (local.tee $0
                    (i32.load offset=16
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (i32.add
                  (local.get $5)
                  (i32.const 16)
                 )
                )
               )
              )
              (loop $label5
               (local.set $4
                (local.get $2)
               )
               (local.set $2
                (i32.add
                 (local.tee $1
                  (local.get $0)
                 )
                 (i32.const 20)
                )
               )
               (br_if $label5
                (local.tee $0
                 (i32.load offset=20
                  (local.get $1)
                 )
                )
               )
               (local.set $2
                (i32.add
                 (local.get $1)
                 (i32.const 16)
                )
               )
               (br_if $label5
                (local.tee $0
                 (i32.load offset=16
                  (local.get $1)
                 )
                )
               )
              )
              (i32.store
               (local.get $4)
               (i32.const 0)
              )
              (br $block12)
             )
             (if
              (i32.le_u
               (local.get $6)
               (local.tee $5
                (i32.load
                 (i32.const 1061240)
                )
               )
              )
              (then
               (local.set $1
                (i32.load
                 (i32.const 1061252)
                )
               )
               (block $block14
                (if
                 (i32.ge_u
                  (local.tee $0
                   (i32.sub
                    (local.get $5)
                    (local.get $6)
                   )
                  )
                  (i32.const 16)
                 )
                 (then
                  (i32.store offset=4
                   (local.tee $2
                    (i32.add
                     (local.get $1)
                     (local.get $6)
                    )
                   )
                   (i32.or
                    (local.get $0)
                    (i32.const 1)
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $1)
                    (local.get $5)
                   )
                   (local.get $0)
                  )
                  (i32.store offset=4
                   (local.get $1)
                   (i32.or
                    (local.get $6)
                    (i32.const 3)
                   )
                  )
                  (br $block14)
                 )
                )
                (i32.store offset=4
                 (local.get $1)
                 (i32.or
                  (local.get $5)
                  (i32.const 3)
                 )
                )
                (i32.store offset=4
                 (local.tee $0
                  (i32.add
                   (local.get $1)
                   (local.get $5)
                  )
                 )
                 (i32.or
                  (i32.load offset=4
                   (local.get $0)
                  )
                  (i32.const 1)
                 )
                )
                (local.set $2
                 (i32.const 0)
                )
                (local.set $0
                 (i32.const 0)
                )
               )
               (i32.store
                (i32.const 1061240)
                (local.get $0)
               )
               (i32.store
                (i32.const 1061252)
                (local.get $2)
               )
               (local.set $1
                (i32.add
                 (local.get $1)
                 (i32.const 8)
                )
               )
               (br $block1)
              )
             )
             (if
              (i32.lt_u
               (local.get $6)
               (local.tee $2
                (i32.load
                 (i32.const 1061244)
                )
               )
              )
              (then
               (i32.store offset=4
                (local.tee $0
                 (i32.add
                  (local.get $6)
                  (local.get $7)
                 )
                )
                (i32.or
                 (local.tee $1
                  (i32.sub
                   (local.get $2)
                   (local.get $6)
                  )
                 )
                 (i32.const 1)
                )
               )
               (i32.store
                (i32.const 1061256)
                (local.get $0)
               )
               (i32.store
                (i32.const 1061244)
                (local.get $1)
               )
               (i32.store offset=4
                (local.get $7)
                (i32.or
                 (local.get $6)
                 (i32.const 3)
                )
               )
               (local.set $1
                (i32.add
                 (local.get $7)
                 (i32.const 8)
                )
               )
               (br $block1)
              )
             )
             (local.set $1
              (i32.const 0)
             )
             (if
              (i32.ge_u
               (local.get $6)
               (local.tee $0
                (i32.and
                 (local.tee $3
                  (i32.add
                   (local.tee $5
                    (i32.add
                     (local.get $6)
                     (i32.const 71)
                    )
                   )
                   (local.tee $0
                    (block $block15 (result i32)
                     (if
                      (i32.load
                       (i32.const 1061704)
                      )
                      (then
                       (br $block15
                        (i32.load
                         (i32.const 1061712)
                        )
                       )
                      )
                     )
                     (i64.store align=4
                      (i32.const 1061716)
                      (i64.const -1)
                     )
                     (i64.store align=4
                      (i32.const 1061708)
                      (i64.const 281474976776192)
                     )
                     (i32.store
                      (i32.const 1061704)
                      (i32.xor
                       (i32.and
                        (i32.add
                         (local.get $10)
                         (i32.const 12)
                        )
                        (i32.const -16)
                       )
                       (i32.const 1431655768)
                      )
                     )
                     (i32.store
                      (i32.const 1061724)
                      (i32.const 0)
                     )
                     (i32.store
                      (i32.const 1061676)
                      (i32.const 0)
                     )
                     (i32.const 65536)
                    )
                   )
                  )
                 )
                 (local.tee $4
                  (i32.sub
                   (i32.const 0)
                   (local.get $0)
                  )
                 )
                )
               )
              )
              (then
               (i32.store
                (i32.const 1061060)
                (i32.const 48)
               )
               (br $block1)
              )
             )
             (block $block16
              (br_if $block16
               (i32.eqz
                (local.tee $1
                 (i32.load
                  (i32.const 1061672)
                 )
                )
               )
              )
              (br_if $block16
               (i32.and
                (i32.gt_u
                 (local.tee $9
                  (i32.add
                   (local.tee $8
                    (i32.load
                     (i32.const 1061664)
                    )
                   )
                   (local.get $0)
                  )
                 )
                 (local.get $8)
                )
                (i32.ge_u
                 (local.get $1)
                 (local.get $9)
                )
               )
              )
              (local.set $1
               (i32.const 0)
              )
              (i32.store
               (i32.const 1061060)
               (i32.const 48)
              )
              (br $block1)
             )
             (br_if $block17
              (i32.and
               (i32.load8_u
                (i32.const 1061676)
               )
               (i32.const 4)
              )
             )
             (block $block20
              (block $block18
               (if
                (local.get $7)
                (then
                 (local.set $1
                  (i32.const 1061680)
                 )
                 (loop $label6
                  (if
                   (i32.le_u
                    (local.tee $8
                     (i32.load
                      (local.get $1)
                     )
                    )
                    (local.get $7)
                   )
                   (then
                    (br_if $block18
                     (i32.lt_u
                      (local.get $7)
                      (i32.add
                       (local.get $8)
                       (i32.load offset=4
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                  )
                  (br_if $label6
                   (local.tee $1
                    (i32.load offset=8
                     (local.get $1)
                    )
                   )
                  )
                 )
                )
               )
               (br_if $block19
                (i32.eq
                 (local.tee $2
                  (call $sbrk
                   (i32.const 0)
                  )
                 )
                 (i32.const -1)
                )
               )
               (local.set $4
                (local.get $0)
               )
               (if
                (i32.and
                 (local.tee $3
                  (i32.sub
                   (local.tee $1
                    (i32.load
                     (i32.const 1061708)
                    )
                   )
                   (i32.const 1)
                  )
                 )
                 (local.get $2)
                )
                (then
                 (local.set $4
                  (i32.add
                   (i32.sub
                    (local.get $0)
                    (local.get $2)
                   )
                   (i32.and
                    (i32.add
                     (local.get $2)
                     (local.get $3)
                    )
                    (i32.sub
                     (i32.const 0)
                     (local.get $1)
                    )
                   )
                  )
                 )
                )
               )
               (br_if $block19
                (i32.le_u
                 (local.get $4)
                 (local.get $6)
                )
               )
               (br_if $block19
                (i32.gt_u
                 (local.get $4)
                 (i32.const 2147483646)
                )
               )
               (if
                (local.tee $1
                 (i32.load
                  (i32.const 1061672)
                 )
                )
                (then
                 (br_if $block19
                  (i32.le_u
                   (local.tee $7
                    (i32.add
                     (local.tee $3
                      (i32.load
                       (i32.const 1061664)
                      )
                     )
                     (local.get $4)
                    )
                   )
                   (local.get $3)
                  )
                 )
                 (br_if $block19
                  (i32.lt_u
                   (local.get $1)
                   (local.get $7)
                  )
                 )
                )
               )
               (br_if $block20
                (i32.ne
                 (local.tee $1
                  (call $sbrk
                   (local.get $4)
                  )
                 )
                 (local.get $2)
                )
               )
               (br $block21)
              )
              (br_if $block19
               (i32.gt_u
                (local.tee $4
                 (i32.and
                  (i32.sub
                   (local.get $3)
                   (local.get $2)
                  )
                  (local.get $4)
                 )
                )
                (i32.const 2147483646)
               )
              )
              (br_if $block22
               (i32.eq
                (local.tee $2
                 (call $sbrk
                  (local.get $4)
                 )
                )
                (i32.add
                 (i32.load
                  (local.get $1)
                 )
                 (i32.load offset=4
                  (local.get $1)
                 )
                )
               )
              )
              (local.set $1
               (local.get $2)
              )
             )
             (block $block23
              (br_if $block23
               (i32.ge_u
                (local.get $4)
                (i32.add
                 (local.get $6)
                 (i32.const 72)
                )
               )
              )
              (br_if $block23
               (i32.eq
                (local.get $1)
                (i32.const -1)
               )
              )
              (if
               (i32.gt_u
                (local.tee $2
                 (i32.and
                  (i32.add
                   (local.tee $2
                    (i32.load
                     (i32.const 1061712)
                    )
                   )
                   (i32.sub
                    (local.get $5)
                    (local.get $4)
                   )
                  )
                  (i32.sub
                   (i32.const 0)
                   (local.get $2)
                  )
                 )
                )
                (i32.const 2147483646)
               )
               (then
                (local.set $2
                 (local.get $1)
                )
                (br $block21)
               )
              )
              (if
               (i32.ne
                (call $sbrk
                 (local.get $2)
                )
                (i32.const -1)
               )
               (then
                (local.set $4
                 (i32.add
                  (local.get $2)
                  (local.get $4)
                 )
                )
                (local.set $2
                 (local.get $1)
                )
                (br $block21)
               )
              )
              (drop
               (call $sbrk
                (i32.sub
                 (i32.const 0)
                 (local.get $4)
                )
               )
              )
              (br $block19)
             )
             (br_if $block21
              (i32.ne
               (local.tee $2
                (local.get $1)
               )
               (i32.const -1)
              )
             )
             (br $block19)
            )
            (local.set $1
             (i32.const 0)
            )
            (br $block6)
           )
           (local.set $1
            (i32.const 0)
           )
           (br $block12)
          )
          (br_if $block21
           (i32.ne
            (local.get $2)
            (i32.const -1)
           )
          )
         )
         (i32.store
          (i32.const 1061676)
          (i32.or
           (i32.load
            (i32.const 1061676)
           )
           (i32.const 4)
          )
         )
        )
        (br_if $block24
         (i32.gt_u
          (local.get $0)
          (i32.const 2147483646)
         )
        )
        (local.set $2
         (call $sbrk
          (local.get $0)
         )
        )
        (local.set $0
         (call $sbrk
          (i32.const 0)
         )
        )
        (br_if $block24
         (i32.eq
          (local.get $2)
          (i32.const -1)
         )
        )
        (br_if $block24
         (i32.eq
          (local.get $0)
          (i32.const -1)
         )
        )
        (br_if $block24
         (i32.le_u
          (local.get $0)
          (local.get $2)
         )
        )
        (br_if $block24
         (i32.le_u
          (local.tee $4
           (i32.sub
            (local.get $0)
            (local.get $2)
           )
          )
          (i32.add
           (local.get $6)
           (i32.const 56)
          )
         )
        )
       )
       (i32.store
        (i32.const 1061664)
        (local.tee $0
         (i32.add
          (i32.load
           (i32.const 1061664)
          )
          (local.get $4)
         )
        )
       )
       (if
        (i32.lt_u
         (i32.load
          (i32.const 1061668)
         )
         (local.get $0)
        )
        (then
         (i32.store
          (i32.const 1061668)
          (local.get $0)
         )
        )
       )
       (block $block27
        (block $block26
         (block $block25
          (if
           (local.tee $3
            (i32.load
             (i32.const 1061256)
            )
           )
           (then
            (local.set $1
             (i32.const 1061680)
            )
            (loop $label7
             (br_if $block25
              (i32.eq
               (local.get $2)
               (i32.add
                (local.tee $0
                 (i32.load
                  (local.get $1)
                 )
                )
                (local.tee $5
                 (i32.load offset=4
                  (local.get $1)
                 )
                )
               )
              )
             )
             (br_if $label7
              (local.tee $1
               (i32.load offset=8
                (local.get $1)
               )
              )
             )
            )
            (br $block26)
           )
          )
          (if
           (i32.eqz
            (select
             (local.tee $0
              (i32.load
               (i32.const 1061248)
              )
             )
             (i32.const 0)
             (i32.le_u
              (local.get $0)
              (local.get $2)
             )
            )
           )
           (then
            (i32.store
             (i32.const 1061248)
             (local.get $2)
            )
           )
          )
          (local.set $1
           (i32.const 0)
          )
          (i32.store
           (i32.const 1061684)
           (local.get $4)
          )
          (i32.store
           (i32.const 1061680)
           (local.get $2)
          )
          (i32.store
           (i32.const 1061264)
           (i32.const -1)
          )
          (i32.store
           (i32.const 1061268)
           (i32.load
            (i32.const 1061704)
           )
          )
          (i32.store
           (i32.const 1061692)
           (i32.const 0)
          )
          (loop $label8
           (i32.store
            (i32.add
             (local.get $1)
             (i32.const 1061292)
            )
            (local.tee $0
             (i32.add
              (local.get $1)
              (i32.const 1061280)
             )
            )
           )
           (i32.store
            (local.get $0)
            (local.tee $5
             (i32.add
              (local.get $1)
              (i32.const 1061272)
             )
            )
           )
           (i32.store
            (i32.add
             (local.get $1)
             (i32.const 1061284)
            )
            (local.get $5)
           )
           (i32.store
            (i32.add
             (local.get $1)
             (i32.const 1061300)
            )
            (local.tee $5
             (i32.add
              (local.get $1)
              (i32.const 1061288)
             )
            )
           )
           (i32.store
            (local.get $5)
            (local.get $0)
           )
           (i32.store
            (i32.add
             (local.get $1)
             (i32.const 1061308)
            )
            (local.tee $0
             (i32.add
              (local.get $1)
              (i32.const 1061296)
             )
            )
           )
           (i32.store
            (local.get $0)
            (local.get $5)
           )
           (i32.store
            (i32.add
             (local.get $1)
             (i32.const 1061304)
            )
            (local.get $0)
           )
           (br_if $label8
            (i32.ne
             (local.tee $1
              (i32.add
               (local.get $1)
               (i32.const 32)
              )
             )
             (i32.const 256)
            )
           )
          )
          (i32.store offset=4
           (local.tee $1
            (i32.add
             (local.get $2)
             (local.tee $0
              (i32.and
               (i32.sub
                (i32.const -8)
                (local.get $2)
               )
               (i32.const 15)
              )
             )
            )
           )
           (i32.or
            (local.tee $0
             (i32.sub
              (local.tee $5
               (i32.sub
                (local.get $4)
                (i32.const 56)
               )
              )
              (local.get $0)
             )
            )
            (i32.const 1)
           )
          )
          (i32.store
           (i32.const 1061260)
           (i32.load
            (i32.const 1061720)
           )
          )
          (i32.store
           (i32.const 1061244)
           (local.get $0)
          )
          (i32.store
           (i32.const 1061256)
           (local.get $1)
          )
          (i32.store offset=4
           (i32.add
            (local.get $2)
            (local.get $5)
           )
           (i32.const 56)
          )
          (br $block27)
         )
         (br_if $block26
          (i32.le_u
           (local.get $2)
           (local.get $3)
          )
         )
         (br_if $block26
          (i32.gt_u
           (local.get $0)
           (local.get $3)
          )
         )
         (br_if $block26
          (i32.and
           (i32.load offset=12
            (local.get $1)
           )
           (i32.const 8)
          )
         )
         (i32.store offset=4
          (local.tee $2
           (i32.add
            (local.get $3)
            (local.tee $0
             (i32.and
              (i32.sub
               (i32.const -8)
               (local.get $3)
              )
              (i32.const 15)
             )
            )
           )
          )
          (i32.or
           (local.tee $0
            (i32.sub
             (local.tee $7
              (i32.add
               (i32.load
                (i32.const 1061244)
               )
               (local.get $4)
              )
             )
             (local.get $0)
            )
           )
           (i32.const 1)
          )
         )
         (i32.store offset=4
          (local.get $1)
          (i32.add
           (local.get $4)
           (local.get $5)
          )
         )
         (i32.store
          (i32.const 1061260)
          (i32.load
           (i32.const 1061720)
          )
         )
         (i32.store
          (i32.const 1061244)
          (local.get $0)
         )
         (i32.store
          (i32.const 1061256)
          (local.get $2)
         )
         (i32.store offset=4
          (i32.add
           (local.get $3)
           (local.get $7)
          )
          (i32.const 56)
         )
         (br $block27)
        )
        (if
         (i32.gt_u
          (i32.load
           (i32.const 1061248)
          )
          (local.get $2)
         )
         (then
          (i32.store
           (i32.const 1061248)
           (local.get $2)
          )
         )
        )
        (local.set $5
         (i32.add
          (local.get $2)
          (local.get $4)
         )
        )
        (local.set $1
         (i32.const 1061680)
        )
        (block $block28
         (loop $label9
          (if
           (i32.ne
            (local.get $5)
            (local.tee $0
             (i32.load
              (local.get $1)
             )
            )
           )
           (then
            (br_if $label9
             (local.tee $1
              (i32.load offset=8
               (local.get $1)
              )
             )
            )
            (br $block28)
           )
          )
         )
         (br_if $block29
          (i32.eqz
           (i32.and
            (i32.load8_u offset=12
             (local.get $1)
            )
            (i32.const 8)
           )
          )
         )
        )
        (local.set $1
         (i32.const 1061680)
        )
        (loop $label10
         (block $block30
          (if
           (i32.le_u
            (local.tee $0
             (i32.load
              (local.get $1)
             )
            )
            (local.get $3)
           )
           (then
            (br_if $block30
             (i32.lt_u
              (local.get $3)
              (local.tee $5
               (i32.add
                (local.get $0)
                (i32.load offset=4
                 (local.get $1)
                )
               )
              )
             )
            )
           )
          )
          (local.set $1
           (i32.load offset=8
            (local.get $1)
           )
          )
          (br $label10)
         )
        )
        (i32.store offset=4
         (local.tee $1
          (i32.add
           (local.get $2)
           (local.tee $0
            (i32.and
             (i32.sub
              (i32.const -8)
              (local.get $2)
             )
             (i32.const 15)
            )
           )
          )
         )
         (i32.or
          (local.tee $8
           (i32.sub
            (local.tee $7
             (i32.sub
              (local.get $4)
              (i32.const 56)
             )
            )
            (local.get $0)
           )
          )
          (i32.const 1)
         )
        )
        (i32.store offset=4
         (i32.add
          (local.get $2)
          (local.get $7)
         )
         (i32.const 56)
        )
        (i32.store offset=4
         (local.tee $0
          (select
           (local.get $3)
           (local.tee $0
            (i32.sub
             (i32.add
              (local.get $5)
              (i32.and
               (i32.sub
                (i32.const 55)
                (local.get $5)
               )
               (i32.const 15)
              )
             )
             (i32.const 63)
            )
           )
           (i32.lt_u
            (local.get $0)
            (i32.add
             (local.get $3)
             (i32.const 16)
            )
           )
          )
         )
         (i32.const 35)
        )
        (i32.store
         (i32.const 1061260)
         (i32.load
          (i32.const 1061720)
         )
        )
        (i32.store
         (i32.const 1061244)
         (local.get $8)
        )
        (i32.store
         (i32.const 1061256)
         (local.get $1)
        )
        (i64.store align=4
         (i32.add
          (local.get $0)
          (i32.const 16)
         )
         (i64.load align=4
          (i32.const 1061688)
         )
        )
        (i64.store offset=8 align=4
         (local.get $0)
         (i64.load align=4
          (i32.const 1061680)
         )
        )
        (i32.store
         (i32.const 1061688)
         (i32.add
          (local.get $0)
          (i32.const 8)
         )
        )
        (i32.store
         (i32.const 1061684)
         (local.get $4)
        )
        (i32.store
         (i32.const 1061680)
         (local.get $2)
        )
        (i32.store
         (i32.const 1061692)
         (i32.const 0)
        )
        (local.set $1
         (i32.add
          (local.get $0)
          (i32.const 36)
         )
        )
        (loop $label11
         (i32.store
          (local.get $1)
          (i32.const 7)
         )
         (br_if $label11
          (i32.lt_u
           (local.tee $1
            (i32.add
             (local.get $1)
             (i32.const 4)
            )
           )
           (local.get $5)
          )
         )
        )
        (br_if $block27
         (i32.eq
          (local.get $0)
          (local.get $3)
         )
        )
        (i32.store offset=4
         (local.get $0)
         (i32.and
          (i32.load offset=4
           (local.get $0)
          )
          (i32.const -2)
         )
        )
        (i32.store
         (local.get $0)
         (local.tee $2
          (i32.sub
           (local.get $0)
           (local.get $3)
          )
         )
        )
        (i32.store offset=4
         (local.get $3)
         (i32.or
          (local.get $2)
          (i32.const 1)
         )
        )
        (i32.store
         (i32.add
          (block $block32 (result i32)
           (if
            (i32.le_u
             (local.get $2)
             (i32.const 255)
            )
            (then
             (local.set $1
              (i32.add
               (i32.and
                (local.get $2)
                (i32.const -8)
               )
               (i32.const 1061272)
              )
             )
             (i32.store offset=12
              (local.tee $0
               (block $block31 (result i32)
                (if
                 (i32.eqz
                  (i32.and
                   (local.tee $0
                    (i32.load
                     (i32.const 1061232)
                    )
                   )
                   (local.tee $2
                    (i32.shl
                     (i32.const 1)
                     (i32.shr_u
                      (local.get $2)
                      (i32.const 3)
                     )
                    )
                   )
                  )
                 )
                 (then
                  (i32.store
                   (i32.const 1061232)
                   (i32.or
                    (local.get $0)
                    (local.get $2)
                   )
                  )
                  (br $block31
                   (local.get $1)
                  )
                 )
                )
                (i32.load offset=8
                 (local.get $1)
                )
               )
              )
              (local.get $3)
             )
             (i32.store offset=8
              (local.get $1)
              (local.get $3)
             )
             (local.set $5
              (i32.const 8)
             )
             (br $block32
              (i32.const 12)
             )
            )
           )
           (local.set $1
            (i32.const 31)
           )
           (if
            (i32.le_u
             (local.get $2)
             (i32.const 16777215)
            )
            (then
             (local.set $1
              (i32.add
               (i32.sub
                (i32.and
                 (i32.shr_u
                  (local.get $2)
                  (i32.sub
                   (i32.const 38)
                   (local.tee $0
                    (i32.clz
                     (i32.shr_u
                      (local.get $2)
                      (i32.const 8)
                     )
                    )
                   )
                  )
                 )
                 (i32.const 1)
                )
                (i32.shl
                 (local.get $0)
                 (i32.const 1)
                )
               )
               (i32.const 62)
              )
             )
            )
           )
           (i32.store offset=28
            (local.get $3)
            (local.get $1)
           )
           (i64.store offset=16 align=4
            (local.get $3)
            (i64.const 0)
           )
           (local.set $0
            (i32.add
             (i32.shl
              (local.get $1)
              (i32.const 2)
             )
             (i32.const 1061536)
            )
           )
           (block $block34
            (block $block33
             (if
              (i32.eqz
               (i32.and
                (local.tee $5
                 (i32.load
                  (i32.const 1061236)
                 )
                )
                (local.tee $4
                 (i32.shl
                  (i32.const 1)
                  (local.get $1)
                 )
                )
               )
              )
              (then
               (i32.store
                (local.get $0)
                (local.get $3)
               )
               (i32.store
                (i32.const 1061236)
                (i32.or
                 (local.get $4)
                 (local.get $5)
                )
               )
               (br $block33)
              )
             )
             (local.set $1
              (i32.shl
               (local.get $2)
               (select
                (i32.sub
                 (i32.const 25)
                 (i32.shr_u
                  (local.get $1)
                  (i32.const 1)
                 )
                )
                (i32.const 0)
                (i32.ne
                 (local.get $1)
                 (i32.const 31)
                )
               )
              )
             )
             (local.set $5
              (i32.load
               (local.get $0)
              )
             )
             (loop $label12
              (br_if $block34
               (i32.eq
                (i32.and
                 (i32.load offset=4
                  (local.tee $0
                   (local.get $5)
                  )
                 )
                 (i32.const -8)
                )
                (local.get $2)
               )
              )
              (local.set $5
               (i32.shr_u
                (local.get $1)
                (i32.const 29)
               )
              )
              (local.set $1
               (i32.shl
                (local.get $1)
                (i32.const 1)
               )
              )
              (br_if $label12
               (local.tee $5
                (i32.load offset=16
                 (local.tee $4
                  (i32.add
                   (local.get $0)
                   (i32.and
                    (local.get $5)
                    (i32.const 4)
                   )
                  )
                 )
                )
               )
              )
             )
             (i32.store
              (i32.add
               (local.get $4)
               (i32.const 16)
              )
              (local.get $3)
             )
            )
            (i32.store offset=24
             (local.get $3)
             (local.get $0)
            )
            (local.set $5
             (i32.const 12)
            )
            (local.set $1
             (local.tee $0
              (local.get $3)
             )
            )
            (br $block32
             (i32.const 8)
            )
           )
           (local.set $1
            (i32.load offset=8
             (local.get $0)
            )
           )
           (i32.store offset=8
            (local.get $0)
            (local.get $3)
           )
           (i32.store offset=12
            (local.get $1)
            (local.get $3)
           )
           (i32.store offset=8
            (local.get $3)
            (local.get $1)
           )
           (local.set $1
            (i32.const 0)
           )
           (local.set $5
            (i32.const 12)
           )
           (i32.const 24)
          )
          (block (result i32)
           (i32.store
            (i32.add
             (local.get $3)
             (local.get $5)
            )
            (local.get $0)
           )
           (local.get $3)
          )
         )
         (local.get $1)
        )
       )
       (br_if $block24
        (i32.le_u
         (local.tee $1
          (i32.load
           (i32.const 1061244)
          )
         )
         (local.get $6)
        )
       )
       (i32.store offset=4
        (local.tee $2
         (i32.add
          (local.tee $0
           (i32.load
            (i32.const 1061256)
           )
          )
          (local.get $6)
         )
        )
        (i32.or
         (local.tee $1
          (i32.sub
           (local.get $1)
           (local.get $6)
          )
         )
         (i32.const 1)
        )
       )
       (i32.store
        (i32.const 1061244)
        (local.get $1)
       )
       (i32.store
        (i32.const 1061256)
        (local.get $2)
       )
       (i32.store offset=4
        (local.get $0)
        (i32.or
         (local.get $6)
         (i32.const 3)
        )
       )
       (local.set $1
        (i32.add
         (local.get $0)
         (i32.const 8)
        )
       )
       (br $block1)
      )
      (local.set $1
       (i32.const 0)
      )
      (i32.store
       (i32.const 1061060)
       (i32.const 48)
      )
      (br $block1)
     )
     (i32.store
      (local.get $1)
      (local.get $2)
     )
     (i32.store offset=4
      (local.get $1)
      (i32.add
       (i32.load offset=4
        (local.get $1)
       )
       (local.get $4)
      )
     )
     (i32.store offset=4
      (local.tee $8
       (i32.add
        (local.get $2)
        (i32.and
         (i32.sub
          (i32.const -8)
          (local.get $2)
         )
         (i32.const 15)
        )
       )
      )
      (i32.or
       (local.get $6)
       (i32.const 3)
      )
     )
     (local.set $7
      (i32.sub
       (local.tee $4
        (i32.add
         (local.get $0)
         (i32.and
          (i32.sub
           (i32.const -8)
           (local.get $0)
          )
          (i32.const 15)
         )
        )
       )
       (local.tee $3
        (i32.add
         (local.get $6)
         (local.get $8)
        )
       )
      )
     )
     (block $block35
      (if
       (i32.eq
        (i32.load
         (i32.const 1061256)
        )
        (local.get $4)
       )
       (then
        (i32.store
         (i32.const 1061256)
         (local.get $3)
        )
        (i32.store
         (i32.const 1061244)
         (local.tee $0
          (i32.add
           (i32.load
            (i32.const 1061244)
           )
           (local.get $7)
          )
         )
        )
        (i32.store offset=4
         (local.get $3)
         (i32.or
          (local.get $0)
          (i32.const 1)
         )
        )
        (br $block35)
       )
      )
      (if
       (i32.eq
        (i32.load
         (i32.const 1061252)
        )
        (local.get $4)
       )
       (then
        (i32.store
         (i32.const 1061252)
         (local.get $3)
        )
        (i32.store
         (i32.const 1061240)
         (local.tee $0
          (i32.add
           (i32.load
            (i32.const 1061240)
           )
           (local.get $7)
          )
         )
        )
        (i32.store offset=4
         (local.get $3)
         (i32.or
          (local.get $0)
          (i32.const 1)
         )
        )
        (i32.store
         (i32.add
          (local.get $0)
          (local.get $3)
         )
         (local.get $0)
        )
        (br $block35)
       )
      )
      (if
       (i32.eq
        (i32.and
         (local.tee $2
          (i32.load offset=4
           (local.get $4)
          )
         )
         (i32.const 3)
        )
        (i32.const 1)
       )
       (then
        (local.set $9
         (i32.and
          (local.get $2)
          (i32.const -8)
         )
        )
        (local.set $1
         (i32.load offset=12
          (local.get $4)
         )
        )
        (block $block36
         (if
          (i32.le_u
           (local.get $2)
           (i32.const 255)
          )
          (then
           (if
            (i32.eq
             (local.tee $0
              (i32.load offset=8
               (local.get $4)
              )
             )
             (local.get $1)
            )
            (then
             (i32.store
              (i32.const 1061232)
              (i32.and
               (i32.load
                (i32.const 1061232)
               )
               (i32.rotl
                (i32.const -2)
                (i32.shr_u
                 (local.get $2)
                 (i32.const 3)
                )
               )
              )
             )
             (br $block36)
            )
           )
           (i32.store offset=8
            (local.get $1)
            (local.get $0)
           )
           (i32.store offset=12
            (local.get $0)
            (local.get $1)
           )
           (br $block36)
          )
         )
         (local.set $6
          (i32.load offset=24
           (local.get $4)
          )
         )
         (block $block37
          (if
           (i32.ne
            (local.get $1)
            (local.get $4)
           )
           (then
            (i32.store offset=12
             (local.tee $0
              (i32.load offset=8
               (local.get $4)
              )
             )
             (local.get $1)
            )
            (i32.store offset=8
             (local.get $1)
             (local.get $0)
            )
            (br $block37)
           )
          )
          (block $block38
           (local.set $0
            (if (result i32)
             (local.tee $2
              (i32.load offset=20
               (local.get $4)
              )
             )
             (then
              (i32.add
               (local.get $4)
               (i32.const 20)
              )
             )
             (else
              (br_if $block38
               (i32.eqz
                (local.tee $2
                 (i32.load offset=16
                  (local.get $4)
                 )
                )
               )
              )
              (i32.add
               (local.get $4)
               (i32.const 16)
              )
             )
            )
           )
           (loop $label13
            (local.set $5
             (local.get $0)
            )
            (local.set $0
             (i32.add
              (local.tee $1
               (local.get $2)
              )
              (i32.const 20)
             )
            )
            (br_if $label13
             (local.tee $2
              (i32.load offset=20
               (local.get $1)
              )
             )
            )
            (local.set $0
             (i32.add
              (local.get $1)
              (i32.const 16)
             )
            )
            (br_if $label13
             (local.tee $2
              (i32.load offset=16
               (local.get $1)
              )
             )
            )
           )
           (i32.store
            (local.get $5)
            (i32.const 0)
           )
           (br $block37)
          )
          (local.set $1
           (i32.const 0)
          )
         )
         (br_if $block36
          (i32.eqz
           (local.get $6)
          )
         )
         (block $block39
          (if
           (i32.eq
            (i32.load offset=1061536
             (local.tee $2
              (i32.shl
               (local.tee $0
                (i32.load offset=28
                 (local.get $4)
                )
               )
               (i32.const 2)
              )
             )
            )
            (local.get $4)
           )
           (then
            (i32.store
             (i32.add
              (local.get $2)
              (i32.const 1061536)
             )
             (local.get $1)
            )
            (br_if $block39
             (local.get $1)
            )
            (i32.store
             (i32.const 1061236)
             (i32.and
              (i32.load
               (i32.const 1061236)
              )
              (i32.rotl
               (i32.const -2)
               (local.get $0)
              )
             )
            )
            (br $block36)
           )
          )
          (block $block40
           (if
            (i32.eq
             (local.get $4)
             (i32.load offset=16
              (local.get $6)
             )
            )
            (then
             (i32.store offset=16
              (local.get $6)
              (local.get $1)
             )
             (br $block40)
            )
           )
           (i32.store offset=20
            (local.get $6)
            (local.get $1)
           )
          )
          (br_if $block36
           (i32.eqz
            (local.get $1)
           )
          )
         )
         (i32.store offset=24
          (local.get $1)
          (local.get $6)
         )
         (if
          (local.tee $0
           (i32.load offset=16
            (local.get $4)
           )
          )
          (then
           (i32.store offset=16
            (local.get $1)
            (local.get $0)
           )
           (i32.store offset=24
            (local.get $0)
            (local.get $1)
           )
          )
         )
         (br_if $block36
          (i32.eqz
           (local.tee $0
            (i32.load offset=20
             (local.get $4)
            )
           )
          )
         )
         (i32.store offset=20
          (local.get $1)
          (local.get $0)
         )
         (i32.store offset=24
          (local.get $0)
          (local.get $1)
         )
        )
        (local.set $7
         (i32.add
          (local.get $7)
          (local.get $9)
         )
        )
        (local.set $2
         (i32.load offset=4
          (local.tee $4
           (i32.add
            (local.get $4)
            (local.get $9)
           )
          )
         )
        )
       )
      )
      (i32.store offset=4
       (local.get $4)
       (i32.and
        (local.get $2)
        (i32.const -2)
       )
      )
      (i32.store
       (i32.add
        (local.get $3)
        (local.get $7)
       )
       (local.get $7)
      )
      (i32.store offset=4
       (local.get $3)
       (i32.or
        (local.get $7)
        (i32.const 1)
       )
      )
      (if
       (i32.le_u
        (local.get $7)
        (i32.const 255)
       )
       (then
        (local.set $0
         (i32.add
          (i32.and
           (local.get $7)
           (i32.const -8)
          )
          (i32.const 1061272)
         )
        )
        (i32.store offset=12
         (local.tee $1
          (block $block41 (result i32)
           (if
            (i32.eqz
             (i32.and
              (local.tee $1
               (i32.load
                (i32.const 1061232)
               )
              )
              (local.tee $2
               (i32.shl
                (i32.const 1)
                (i32.shr_u
                 (local.get $7)
                 (i32.const 3)
                )
               )
              )
             )
            )
            (then
             (i32.store
              (i32.const 1061232)
              (i32.or
               (local.get $1)
               (local.get $2)
              )
             )
             (br $block41
              (local.get $0)
             )
            )
           )
           (i32.load offset=8
            (local.get $0)
           )
          )
         )
         (local.get $3)
        )
        (i32.store offset=8
         (local.get $0)
         (local.get $3)
        )
        (i32.store offset=12
         (local.get $3)
         (local.get $0)
        )
        (i32.store offset=8
         (local.get $3)
         (local.get $1)
        )
        (br $block35)
       )
      )
      (local.set $1
       (i32.const 31)
      )
      (if
       (i32.le_u
        (local.get $7)
        (i32.const 16777215)
       )
       (then
        (local.set $1
         (i32.add
          (i32.sub
           (i32.and
            (i32.shr_u
             (local.get $7)
             (i32.sub
              (i32.const 38)
              (local.tee $0
               (i32.clz
                (i32.shr_u
                 (local.get $7)
                 (i32.const 8)
                )
               )
              )
             )
            )
            (i32.const 1)
           )
           (i32.shl
            (local.get $0)
            (i32.const 1)
           )
          )
          (i32.const 62)
         )
        )
       )
      )
      (i32.store offset=28
       (local.get $3)
       (local.get $1)
      )
      (i64.store offset=16 align=4
       (local.get $3)
       (i64.const 0)
      )
      (local.set $0
       (i32.add
        (i32.shl
         (local.get $1)
         (i32.const 2)
        )
        (i32.const 1061536)
       )
      )
      (if
       (i32.eqz
        (i32.and
         (local.tee $2
          (i32.load
           (i32.const 1061236)
          )
         )
         (local.tee $5
          (i32.shl
           (i32.const 1)
           (local.get $1)
          )
         )
        )
       )
       (then
        (i32.store
         (local.get $0)
         (local.get $3)
        )
        (i32.store
         (i32.const 1061236)
         (i32.or
          (local.get $2)
          (local.get $5)
         )
        )
        (i32.store offset=24
         (local.get $3)
         (local.get $0)
        )
        (i32.store offset=8
         (local.get $3)
         (local.get $3)
        )
        (i32.store offset=12
         (local.get $3)
         (local.get $3)
        )
        (br $block35)
       )
      )
      (local.set $1
       (i32.shl
        (local.get $7)
        (select
         (i32.sub
          (i32.const 25)
          (i32.shr_u
           (local.get $1)
           (i32.const 1)
          )
         )
         (i32.const 0)
         (i32.ne
          (local.get $1)
          (i32.const 31)
         )
        )
       )
      )
      (local.set $0
       (i32.load
        (local.get $0)
       )
      )
      (block $block42
       (loop $label14
        (br_if $block42
         (i32.eq
          (i32.and
           (i32.load offset=4
            (local.tee $2
             (local.get $0)
            )
           )
           (i32.const -8)
          )
          (local.get $7)
         )
        )
        (local.set $0
         (i32.shr_u
          (local.get $1)
          (i32.const 29)
         )
        )
        (local.set $1
         (i32.shl
          (local.get $1)
          (i32.const 1)
         )
        )
        (br_if $label14
         (local.tee $0
          (i32.load offset=16
           (local.tee $5
            (i32.add
             (local.get $2)
             (i32.and
              (local.get $0)
              (i32.const 4)
             )
            )
           )
          )
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $5)
         (i32.const 16)
        )
        (local.get $3)
       )
       (i32.store offset=24
        (local.get $3)
        (local.get $2)
       )
       (i32.store offset=12
        (local.get $3)
        (local.get $3)
       )
       (i32.store offset=8
        (local.get $3)
        (local.get $3)
       )
       (br $block35)
      )
      (i32.store offset=12
       (local.tee $0
        (i32.load offset=8
         (local.get $2)
        )
       )
       (local.get $3)
      )
      (i32.store offset=8
       (local.get $2)
       (local.get $3)
      )
      (i32.store offset=24
       (local.get $3)
       (i32.const 0)
      )
      (i32.store offset=12
       (local.get $3)
       (local.get $2)
      )
      (i32.store offset=8
       (local.get $3)
       (local.get $0)
      )
     )
     (local.set $1
      (i32.add
       (local.get $8)
       (i32.const 8)
      )
     )
     (br $block1)
    )
    (block $block43
     (br_if $block43
      (i32.eqz
       (local.get $7)
      )
     )
     (block $block44
      (if
       (i32.eq
        (i32.load offset=1061536
         (local.tee $2
          (i32.shl
           (local.tee $0
            (i32.load offset=28
             (local.get $5)
            )
           )
           (i32.const 2)
          )
         )
        )
        (local.get $5)
       )
       (then
        (i32.store
         (i32.add
          (local.get $2)
          (i32.const 1061536)
         )
         (local.get $1)
        )
        (br_if $block44
         (local.get $1)
        )
        (i32.store
         (i32.const 1061236)
         (local.tee $8
          (i32.and
           (local.get $8)
           (i32.rotl
            (i32.const -2)
            (local.get $0)
           )
          )
         )
        )
        (br $block43)
       )
      )
      (block $block45
       (if
        (i32.eq
         (local.get $5)
         (i32.load offset=16
          (local.get $7)
         )
        )
        (then
         (i32.store offset=16
          (local.get $7)
          (local.get $1)
         )
         (br $block45)
        )
       )
       (i32.store offset=20
        (local.get $7)
        (local.get $1)
       )
      )
      (br_if $block43
       (i32.eqz
        (local.get $1)
       )
      )
     )
     (i32.store offset=24
      (local.get $1)
      (local.get $7)
     )
     (if
      (local.tee $0
       (i32.load offset=16
        (local.get $5)
       )
      )
      (then
       (i32.store offset=16
        (local.get $1)
        (local.get $0)
       )
       (i32.store offset=24
        (local.get $0)
        (local.get $1)
       )
      )
     )
     (br_if $block43
      (i32.eqz
       (local.tee $0
        (i32.load offset=20
         (local.get $5)
        )
       )
      )
     )
     (i32.store offset=20
      (local.get $1)
      (local.get $0)
     )
     (i32.store offset=24
      (local.get $0)
      (local.get $1)
     )
    )
    (block $block46
     (if
      (i32.le_u
       (local.get $3)
       (i32.const 15)
      )
      (then
       (i32.store offset=4
        (local.get $5)
        (i32.or
         (local.tee $0
          (i32.or
           (local.get $3)
           (local.get $6)
          )
         )
         (i32.const 3)
        )
       )
       (i32.store offset=4
        (local.tee $0
         (i32.add
          (local.get $0)
          (local.get $5)
         )
        )
        (i32.or
         (i32.load offset=4
          (local.get $0)
         )
         (i32.const 1)
        )
       )
       (br $block46)
      )
     )
     (i32.store offset=4
      (local.tee $4
       (i32.add
        (local.get $5)
        (local.get $6)
       )
      )
      (i32.or
       (local.get $3)
       (i32.const 1)
      )
     )
     (i32.store offset=4
      (local.get $5)
      (i32.or
       (local.get $6)
       (i32.const 3)
      )
     )
     (i32.store
      (i32.add
       (local.get $3)
       (local.get $4)
      )
      (local.get $3)
     )
     (if
      (i32.le_u
       (local.get $3)
       (i32.const 255)
      )
      (then
       (local.set $0
        (i32.add
         (i32.and
          (local.get $3)
          (i32.const -8)
         )
         (i32.const 1061272)
        )
       )
       (i32.store offset=12
        (local.tee $1
         (block $block47 (result i32)
          (if
           (i32.eqz
            (i32.and
             (local.tee $1
              (i32.load
               (i32.const 1061232)
              )
             )
             (local.tee $2
              (i32.shl
               (i32.const 1)
               (i32.shr_u
                (local.get $3)
                (i32.const 3)
               )
              )
             )
            )
           )
           (then
            (i32.store
             (i32.const 1061232)
             (i32.or
              (local.get $1)
              (local.get $2)
             )
            )
            (br $block47
             (local.get $0)
            )
           )
          )
          (i32.load offset=8
           (local.get $0)
          )
         )
        )
        (local.get $4)
       )
       (i32.store offset=8
        (local.get $0)
        (local.get $4)
       )
       (i32.store offset=12
        (local.get $4)
        (local.get $0)
       )
       (i32.store offset=8
        (local.get $4)
        (local.get $1)
       )
       (br $block46)
      )
     )
     (local.set $1
      (i32.const 31)
     )
     (if
      (i32.le_u
       (local.get $3)
       (i32.const 16777215)
      )
      (then
       (local.set $1
        (i32.add
         (i32.sub
          (i32.and
           (i32.shr_u
            (local.get $3)
            (i32.sub
             (i32.const 38)
             (local.tee $0
              (i32.clz
               (i32.shr_u
                (local.get $3)
                (i32.const 8)
               )
              )
             )
            )
           )
           (i32.const 1)
          )
          (i32.shl
           (local.get $0)
           (i32.const 1)
          )
         )
         (i32.const 62)
        )
       )
      )
     )
     (i32.store offset=28
      (local.get $4)
      (local.get $1)
     )
     (i64.store offset=16 align=4
      (local.get $4)
      (i64.const 0)
     )
     (local.set $0
      (i32.add
       (i32.shl
        (local.get $1)
        (i32.const 2)
       )
       (i32.const 1061536)
      )
     )
     (if
      (i32.eqz
       (i32.and
        (local.get $8)
        (local.tee $2
         (i32.shl
          (i32.const 1)
          (local.get $1)
         )
        )
       )
      )
      (then
       (i32.store
        (local.get $0)
        (local.get $4)
       )
       (i32.store
        (i32.const 1061236)
        (i32.or
         (local.get $2)
         (local.get $8)
        )
       )
       (i32.store offset=24
        (local.get $4)
        (local.get $0)
       )
       (i32.store offset=8
        (local.get $4)
        (local.get $4)
       )
       (i32.store offset=12
        (local.get $4)
        (local.get $4)
       )
       (br $block46)
      )
     )
     (local.set $1
      (i32.shl
       (local.get $3)
       (select
        (i32.sub
         (i32.const 25)
         (i32.shr_u
          (local.get $1)
          (i32.const 1)
         )
        )
        (i32.const 0)
        (i32.ne
         (local.get $1)
         (i32.const 31)
        )
       )
      )
     )
     (local.set $0
      (i32.load
       (local.get $0)
      )
     )
     (block $block48
      (loop $label15
       (br_if $block48
        (i32.eq
         (i32.and
          (i32.load offset=4
           (local.tee $2
            (local.get $0)
           )
          )
          (i32.const -8)
         )
         (local.get $3)
        )
       )
       (local.set $0
        (i32.shr_u
         (local.get $1)
         (i32.const 29)
        )
       )
       (local.set $1
        (i32.shl
         (local.get $1)
         (i32.const 1)
        )
       )
       (br_if $label15
        (local.tee $0
         (i32.load offset=16
          (local.tee $7
           (i32.add
            (local.get $2)
            (i32.and
             (local.get $0)
             (i32.const 4)
            )
           )
          )
         )
        )
       )
      )
      (i32.store
       (i32.add
        (local.get $7)
        (i32.const 16)
       )
       (local.get $4)
      )
      (i32.store offset=24
       (local.get $4)
       (local.get $2)
      )
      (i32.store offset=12
       (local.get $4)
       (local.get $4)
      )
      (i32.store offset=8
       (local.get $4)
       (local.get $4)
      )
      (br $block46)
     )
     (i32.store offset=12
      (local.tee $0
       (i32.load offset=8
        (local.get $2)
       )
      )
      (local.get $4)
     )
     (i32.store offset=8
      (local.get $2)
      (local.get $4)
     )
     (i32.store offset=24
      (local.get $4)
      (i32.const 0)
     )
     (i32.store offset=12
      (local.get $4)
      (local.get $2)
     )
     (i32.store offset=8
      (local.get $4)
      (local.get $0)
     )
    )
    (local.set $1
     (i32.add
      (local.get $5)
      (i32.const 8)
     )
    )
    (br $block1)
   )
   (block $block49
    (br_if $block49
     (i32.eqz
      (local.get $9)
     )
    )
    (block $block50
     (if
      (i32.eq
       (i32.load offset=1061536
        (local.tee $5
         (i32.shl
          (local.tee $0
           (i32.load offset=28
            (local.get $2)
           )
          )
          (i32.const 2)
         )
        )
       )
       (local.get $2)
      )
      (then
       (i32.store
        (i32.add
         (local.get $5)
         (i32.const 1061536)
        )
        (local.get $1)
       )
       (br_if $block50
        (local.get $1)
       )
       (i32.store
        (i32.const 1061236)
        (i32.and
         (local.get $11)
         (i32.rotl
          (i32.const -2)
          (local.get $0)
         )
        )
       )
       (br $block49)
      )
     )
     (block $block51
      (if
       (i32.eq
        (local.get $2)
        (i32.load offset=16
         (local.get $9)
        )
       )
       (then
        (i32.store offset=16
         (local.get $9)
         (local.get $1)
        )
        (br $block51)
       )
      )
      (i32.store offset=20
       (local.get $9)
       (local.get $1)
      )
     )
     (br_if $block49
      (i32.eqz
       (local.get $1)
      )
     )
    )
    (i32.store offset=24
     (local.get $1)
     (local.get $9)
    )
    (if
     (local.tee $0
      (i32.load offset=16
       (local.get $2)
      )
     )
     (then
      (i32.store offset=16
       (local.get $1)
       (local.get $0)
      )
      (i32.store offset=24
       (local.get $0)
       (local.get $1)
      )
     )
    )
    (br_if $block49
     (i32.eqz
      (local.tee $0
       (i32.load offset=20
        (local.get $2)
       )
      )
     )
    )
    (i32.store offset=20
     (local.get $1)
     (local.get $0)
    )
    (i32.store offset=24
     (local.get $0)
     (local.get $1)
    )
   )
   (block $block52
    (if
     (i32.le_u
      (local.get $3)
      (i32.const 15)
     )
     (then
      (i32.store offset=4
       (local.get $2)
       (i32.or
        (local.tee $0
         (i32.or
          (local.get $3)
          (local.get $6)
         )
        )
        (i32.const 3)
       )
      )
      (i32.store offset=4
       (local.tee $0
        (i32.add
         (local.get $0)
         (local.get $2)
        )
       )
       (i32.or
        (i32.load offset=4
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (br $block52)
     )
    )
    (i32.store offset=4
     (local.tee $5
      (i32.add
       (local.get $2)
       (local.get $6)
      )
     )
     (i32.or
      (local.get $3)
      (i32.const 1)
     )
    )
    (i32.store offset=4
     (local.get $2)
     (i32.or
      (local.get $6)
      (i32.const 3)
     )
    )
    (i32.store
     (i32.add
      (local.get $3)
      (local.get $5)
     )
     (local.get $3)
    )
    (if
     (local.get $8)
     (then
      (local.set $0
       (i32.add
        (i32.and
         (local.get $8)
         (i32.const -8)
        )
        (i32.const 1061272)
       )
      )
      (local.set $1
       (i32.load
        (i32.const 1061252)
       )
      )
      (i32.store offset=12
       (local.tee $4
        (block $block53 (result i32)
         (if
          (i32.eqz
           (i32.and
            (local.tee $7
             (i32.shl
              (i32.const 1)
              (i32.shr_u
               (local.get $8)
               (i32.const 3)
              )
             )
            )
            (local.get $4)
           )
          )
          (then
           (i32.store
            (i32.const 1061232)
            (i32.or
             (local.get $4)
             (local.get $7)
            )
           )
           (br $block53
            (local.get $0)
           )
          )
         )
         (i32.load offset=8
          (local.get $0)
         )
        )
       )
       (local.get $1)
      )
      (i32.store offset=8
       (local.get $0)
       (local.get $1)
      )
      (i32.store offset=12
       (local.get $1)
       (local.get $0)
      )
      (i32.store offset=8
       (local.get $1)
       (local.get $4)
      )
     )
    )
    (i32.store
     (i32.const 1061252)
     (local.get $5)
    )
    (i32.store
     (i32.const 1061240)
     (local.get $3)
    )
   )
   (local.set $1
    (i32.add
     (local.get $2)
     (i32.const 8)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $10)
    (i32.const 16)
   )
  )
  (local.get $1)
 )
 (func $dlfree (param $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (block $block
   (br_if $block
    (i32.eqz
     (local.get $0)
    )
   )
   (local.set $5
    (i32.add
     (local.tee $3
      (i32.sub
       (local.get $0)
       (i32.const 8)
      )
     )
     (local.tee $0
      (i32.and
       (local.tee $2
        (i32.load
         (i32.sub
          (local.get $0)
          (i32.const 4)
         )
        )
       )
       (i32.const -8)
      )
     )
    )
   )
   (block $block1
    (br_if $block1
     (i32.and
      (local.get $2)
      (i32.const 1)
     )
    )
    (br_if $block
     (i32.eqz
      (i32.and
       (local.get $2)
       (i32.const 2)
      )
     )
    )
    (br_if $block
     (i32.lt_u
      (local.tee $3
       (i32.sub
        (local.get $3)
        (local.tee $4
         (i32.load
          (local.get $3)
         )
        )
       )
      )
      (i32.load
       (i32.const 1061248)
      )
     )
    )
    (local.set $0
     (i32.add
      (local.get $0)
      (local.get $4)
     )
    )
    (block $block3
     (block $block4
      (block $block2
       (if
        (i32.ne
         (i32.load
          (i32.const 1061252)
         )
         (local.get $3)
        )
        (then
         (local.set $1
          (i32.load offset=12
           (local.get $3)
          )
         )
         (if
          (i32.le_u
           (local.get $4)
           (i32.const 255)
          )
          (then
           (br_if $block2
            (i32.ne
             (local.get $1)
             (local.tee $2
              (i32.load offset=8
               (local.get $3)
              )
             )
            )
           )
           (i32.store
            (i32.const 1061232)
            (i32.and
             (i32.load
              (i32.const 1061232)
             )
             (i32.rotl
              (i32.const -2)
              (i32.shr_u
               (local.get $4)
               (i32.const 3)
              )
             )
            )
           )
           (br $block1)
          )
         )
         (local.set $7
          (i32.load offset=24
           (local.get $3)
          )
         )
         (if
          (i32.ne
           (local.get $1)
           (local.get $3)
          )
          (then
           (i32.store offset=12
            (local.tee $2
             (i32.load offset=8
              (local.get $3)
             )
            )
            (local.get $1)
           )
           (i32.store offset=8
            (local.get $1)
            (local.get $2)
           )
           (br $block3)
          )
         )
         (local.set $4
          (if (result i32)
           (local.tee $2
            (i32.load offset=20
             (local.get $3)
            )
           )
           (then
            (i32.add
             (local.get $3)
             (i32.const 20)
            )
           )
           (else
            (br_if $block4
             (i32.eqz
              (local.tee $2
               (i32.load offset=16
                (local.get $3)
               )
              )
             )
            )
            (i32.add
             (local.get $3)
             (i32.const 16)
            )
           )
          )
         )
         (loop $label
          (local.set $6
           (local.get $4)
          )
          (local.set $4
           (i32.add
            (local.tee $1
             (local.get $2)
            )
            (i32.const 20)
           )
          )
          (br_if $label
           (local.tee $2
            (i32.load offset=20
             (local.get $1)
            )
           )
          )
          (local.set $4
           (i32.add
            (local.get $1)
            (i32.const 16)
           )
          )
          (br_if $label
           (local.tee $2
            (i32.load offset=16
             (local.get $1)
            )
           )
          )
         )
         (i32.store
          (local.get $6)
          (i32.const 0)
         )
         (br $block3)
        )
       )
       (br_if $block1
        (i32.ne
         (i32.and
          (local.tee $2
           (i32.load offset=4
            (local.get $5)
           )
          )
          (i32.const 3)
         )
         (i32.const 3)
        )
       )
       (i32.store offset=4
        (local.get $5)
        (i32.and
         (local.get $2)
         (i32.const -2)
        )
       )
       (i32.store
        (i32.const 1061240)
        (local.get $0)
       )
       (i32.store
        (local.get $5)
        (local.get $0)
       )
       (i32.store offset=4
        (local.get $3)
        (i32.or
         (local.get $0)
         (i32.const 1)
        )
       )
       (return)
      )
      (i32.store offset=8
       (local.get $1)
       (local.get $2)
      )
      (i32.store offset=12
       (local.get $2)
       (local.get $1)
      )
      (br $block1)
     )
     (local.set $1
      (i32.const 0)
     )
    )
    (br_if $block1
     (i32.eqz
      (local.get $7)
     )
    )
    (block $block5
     (if
      (i32.eq
       (i32.load offset=1061536
        (local.tee $2
         (i32.shl
          (local.tee $4
           (i32.load offset=28
            (local.get $3)
           )
          )
          (i32.const 2)
         )
        )
       )
       (local.get $3)
      )
      (then
       (i32.store
        (i32.add
         (local.get $2)
         (i32.const 1061536)
        )
        (local.get $1)
       )
       (br_if $block5
        (local.get $1)
       )
       (i32.store
        (i32.const 1061236)
        (i32.and
         (i32.load
          (i32.const 1061236)
         )
         (i32.rotl
          (i32.const -2)
          (local.get $4)
         )
        )
       )
       (br $block1)
      )
     )
     (block $block6
      (if
       (i32.eq
        (local.get $3)
        (i32.load offset=16
         (local.get $7)
        )
       )
       (then
        (i32.store offset=16
         (local.get $7)
         (local.get $1)
        )
        (br $block6)
       )
      )
      (i32.store offset=20
       (local.get $7)
       (local.get $1)
      )
     )
     (br_if $block1
      (i32.eqz
       (local.get $1)
      )
     )
    )
    (i32.store offset=24
     (local.get $1)
     (local.get $7)
    )
    (if
     (local.tee $2
      (i32.load offset=16
       (local.get $3)
      )
     )
     (then
      (i32.store offset=16
       (local.get $1)
       (local.get $2)
      )
      (i32.store offset=24
       (local.get $2)
       (local.get $1)
      )
     )
    )
    (br_if $block1
     (i32.eqz
      (local.tee $2
       (i32.load offset=20
        (local.get $3)
       )
      )
     )
    )
    (i32.store offset=20
     (local.get $1)
     (local.get $2)
    )
    (i32.store offset=24
     (local.get $2)
     (local.get $1)
    )
   )
   (br_if $block
    (i32.ge_u
     (local.get $3)
     (local.get $5)
    )
   )
   (br_if $block
    (i32.eqz
     (i32.and
      (local.tee $4
       (i32.load offset=4
        (local.get $5)
       )
      )
      (i32.const 1)
     )
    )
   )
   (block $block10
    (block $block7
     (block $block8
      (block $block9
       (if
        (i32.eqz
         (i32.and
          (local.get $4)
          (i32.const 2)
         )
        )
        (then
         (if
          (i32.eq
           (i32.load
            (i32.const 1061256)
           )
           (local.get $5)
          )
          (then
           (i32.store
            (i32.const 1061256)
            (local.get $3)
           )
           (i32.store
            (i32.const 1061244)
            (local.tee $0
             (i32.add
              (i32.load
               (i32.const 1061244)
              )
              (local.get $0)
             )
            )
           )
           (i32.store offset=4
            (local.get $3)
            (i32.or
             (local.get $0)
             (i32.const 1)
            )
           )
           (br_if $block
            (i32.ne
             (local.get $3)
             (i32.load
              (i32.const 1061252)
             )
            )
           )
           (i32.store
            (i32.const 1061240)
            (i32.const 0)
           )
           (i32.store
            (i32.const 1061252)
            (i32.const 0)
           )
           (return)
          )
         )
         (if
          (i32.eq
           (local.tee $7
            (i32.load
             (i32.const 1061252)
            )
           )
           (local.get $5)
          )
          (then
           (i32.store
            (i32.const 1061252)
            (local.get $3)
           )
           (i32.store
            (i32.const 1061240)
            (local.tee $0
             (i32.add
              (i32.load
               (i32.const 1061240)
              )
              (local.get $0)
             )
            )
           )
           (i32.store offset=4
            (local.get $3)
            (i32.or
             (local.get $0)
             (i32.const 1)
            )
           )
           (i32.store
            (i32.add
             (local.get $0)
             (local.get $3)
            )
            (local.get $0)
           )
           (return)
          )
         )
         (local.set $0
          (i32.add
           (i32.and
            (local.get $4)
            (i32.const -8)
           )
           (local.get $0)
          )
         )
         (local.set $1
          (i32.load offset=12
           (local.get $5)
          )
         )
         (if
          (i32.le_u
           (local.get $4)
           (i32.const 255)
          )
          (then
           (if
            (i32.eq
             (local.tee $2
              (i32.load offset=8
               (local.get $5)
              )
             )
             (local.get $1)
            )
            (then
             (i32.store
              (i32.const 1061232)
              (i32.and
               (i32.load
                (i32.const 1061232)
               )
               (i32.rotl
                (i32.const -2)
                (i32.shr_u
                 (local.get $4)
                 (i32.const 3)
                )
               )
              )
             )
             (br $block7)
            )
           )
           (i32.store offset=8
            (local.get $1)
            (local.get $2)
           )
           (i32.store offset=12
            (local.get $2)
            (local.get $1)
           )
           (br $block7)
          )
         )
         (local.set $8
          (i32.load offset=24
           (local.get $5)
          )
         )
         (if
          (i32.ne
           (local.get $1)
           (local.get $5)
          )
          (then
           (i32.store offset=12
            (local.tee $2
             (i32.load offset=8
              (local.get $5)
             )
            )
            (local.get $1)
           )
           (i32.store offset=8
            (local.get $1)
            (local.get $2)
           )
           (br $block8)
          )
         )
         (local.set $4
          (if (result i32)
           (local.tee $2
            (i32.load offset=20
             (local.get $5)
            )
           )
           (then
            (i32.add
             (local.get $5)
             (i32.const 20)
            )
           )
           (else
            (br_if $block9
             (i32.eqz
              (local.tee $2
               (i32.load offset=16
                (local.get $5)
               )
              )
             )
            )
            (i32.add
             (local.get $5)
             (i32.const 16)
            )
           )
          )
         )
         (loop $label1
          (local.set $6
           (local.get $4)
          )
          (local.set $4
           (i32.add
            (local.tee $1
             (local.get $2)
            )
            (i32.const 20)
           )
          )
          (br_if $label1
           (local.tee $2
            (i32.load offset=20
             (local.get $1)
            )
           )
          )
          (local.set $4
           (i32.add
            (local.get $1)
            (i32.const 16)
           )
          )
          (br_if $label1
           (local.tee $2
            (i32.load offset=16
             (local.get $1)
            )
           )
          )
         )
         (i32.store
          (local.get $6)
          (i32.const 0)
         )
         (br $block8)
        )
       )
       (i32.store offset=4
        (local.get $5)
        (i32.and
         (local.get $4)
         (i32.const -2)
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (local.get $3)
        )
        (local.get $0)
       )
       (i32.store offset=4
        (local.get $3)
        (i32.or
         (local.get $0)
         (i32.const 1)
        )
       )
       (br $block10)
      )
      (local.set $1
       (i32.const 0)
      )
     )
     (br_if $block7
      (i32.eqz
       (local.get $8)
      )
     )
     (block $block11
      (if
       (i32.eq
        (i32.load offset=1061536
         (local.tee $2
          (i32.shl
           (local.tee $4
            (i32.load offset=28
             (local.get $5)
            )
           )
           (i32.const 2)
          )
         )
        )
        (local.get $5)
       )
       (then
        (i32.store
         (i32.add
          (local.get $2)
          (i32.const 1061536)
         )
         (local.get $1)
        )
        (br_if $block11
         (local.get $1)
        )
        (i32.store
         (i32.const 1061236)
         (i32.and
          (i32.load
           (i32.const 1061236)
          )
          (i32.rotl
           (i32.const -2)
           (local.get $4)
          )
         )
        )
        (br $block7)
       )
      )
      (block $block12
       (if
        (i32.eq
         (local.get $5)
         (i32.load offset=16
          (local.get $8)
         )
        )
        (then
         (i32.store offset=16
          (local.get $8)
          (local.get $1)
         )
         (br $block12)
        )
       )
       (i32.store offset=20
        (local.get $8)
        (local.get $1)
       )
      )
      (br_if $block7
       (i32.eqz
        (local.get $1)
       )
      )
     )
     (i32.store offset=24
      (local.get $1)
      (local.get $8)
     )
     (if
      (local.tee $2
       (i32.load offset=16
        (local.get $5)
       )
      )
      (then
       (i32.store offset=16
        (local.get $1)
        (local.get $2)
       )
       (i32.store offset=24
        (local.get $2)
        (local.get $1)
       )
      )
     )
     (br_if $block7
      (i32.eqz
       (local.tee $2
        (i32.load offset=20
         (local.get $5)
        )
       )
      )
     )
     (i32.store offset=20
      (local.get $1)
      (local.get $2)
     )
     (i32.store offset=24
      (local.get $2)
      (local.get $1)
     )
    )
    (i32.store
     (i32.add
      (local.get $0)
      (local.get $3)
     )
     (local.get $0)
    )
    (i32.store offset=4
     (local.get $3)
     (i32.or
      (local.get $0)
      (i32.const 1)
     )
    )
    (br_if $block10
     (i32.ne
      (local.get $3)
      (local.get $7)
     )
    )
    (i32.store
     (i32.const 1061240)
     (local.get $0)
    )
    (return)
   )
   (if
    (i32.le_u
     (local.get $0)
     (i32.const 255)
    )
    (then
     (local.set $2
      (i32.add
       (i32.and
        (local.get $0)
        (i32.const -8)
       )
       (i32.const 1061272)
      )
     )
     (i32.store offset=12
      (local.tee $0
       (block $block13 (result i32)
        (if
         (i32.eqz
          (i32.and
           (local.tee $4
            (i32.load
             (i32.const 1061232)
            )
           )
           (local.tee $0
            (i32.shl
             (i32.const 1)
             (i32.shr_u
              (local.get $0)
              (i32.const 3)
             )
            )
           )
          )
         )
         (then
          (i32.store
           (i32.const 1061232)
           (i32.or
            (local.get $0)
            (local.get $4)
           )
          )
          (br $block13
           (local.get $2)
          )
         )
        )
        (i32.load offset=8
         (local.get $2)
        )
       )
      )
      (local.get $3)
     )
     (i32.store offset=8
      (local.get $2)
      (local.get $3)
     )
     (i32.store offset=12
      (local.get $3)
      (local.get $2)
     )
     (i32.store offset=8
      (local.get $3)
      (local.get $0)
     )
     (return)
    )
   )
   (local.set $1
    (i32.const 31)
   )
   (if
    (i32.le_u
     (local.get $0)
     (i32.const 16777215)
    )
    (then
     (local.set $1
      (i32.add
       (i32.sub
        (i32.and
         (i32.shr_u
          (local.get $0)
          (i32.sub
           (i32.const 38)
           (local.tee $2
            (i32.clz
             (i32.shr_u
              (local.get $0)
              (i32.const 8)
             )
            )
           )
          )
         )
         (i32.const 1)
        )
        (i32.shl
         (local.get $2)
         (i32.const 1)
        )
       )
       (i32.const 62)
      )
     )
    )
   )
   (i32.store offset=28
    (local.get $3)
    (local.get $1)
   )
   (i64.store offset=16 align=4
    (local.get $3)
    (i64.const 0)
   )
   (local.set $4
    (i32.add
     (i32.shl
      (local.get $1)
      (i32.const 2)
     )
     (i32.const 1061536)
    )
   )
   (local.set $6
    (block $block16 (result i32)
     (block $block15
      (local.set $0
       (block $block14 (result i32)
        (if
         (i32.eqz
          (i32.and
           (local.tee $6
            (i32.load
             (i32.const 1061236)
            )
           )
           (local.tee $2
            (i32.shl
             (i32.const 1)
             (local.get $1)
            )
           )
          )
         )
         (then
          (i32.store
           (local.get $4)
           (local.get $3)
          )
          (i32.store
           (i32.const 1061236)
           (i32.or
            (local.get $2)
            (local.get $6)
           )
          )
          (local.set $1
           (i32.const 24)
          )
          (br $block14
           (i32.const 8)
          )
         )
        )
        (local.set $1
         (i32.shl
          (local.get $0)
          (select
           (i32.sub
            (i32.const 25)
            (i32.shr_u
             (local.get $1)
             (i32.const 1)
            )
           )
           (i32.const 0)
           (i32.ne
            (local.get $1)
            (i32.const 31)
           )
          )
         )
        )
        (local.set $4
         (i32.load
          (local.get $4)
         )
        )
        (loop $label2
         (br_if $block15
          (i32.eq
           (i32.and
            (i32.load offset=4
             (local.tee $2
              (local.get $4)
             )
            )
            (i32.const -8)
           )
           (local.get $0)
          )
         )
         (local.set $4
          (i32.shr_u
           (local.get $1)
           (i32.const 29)
          )
         )
         (local.set $1
          (i32.shl
           (local.get $1)
           (i32.const 1)
          )
         )
         (br_if $label2
          (local.tee $4
           (i32.load offset=16
            (local.tee $6
             (i32.add
              (local.get $2)
              (i32.and
               (local.get $4)
               (i32.const 4)
              )
             )
            )
           )
          )
         )
        )
        (i32.store
         (i32.add
          (local.get $6)
          (i32.const 16)
         )
         (local.get $3)
        )
        (local.set $1
         (i32.const 24)
        )
        (local.set $4
         (local.get $2)
        )
        (i32.const 8)
       )
      )
      (br $block16
       (local.tee $2
        (local.get $3)
       )
      )
     )
     (i32.store offset=12
      (local.tee $4
       (i32.load offset=8
        (local.get $2)
       )
      )
      (local.get $3)
     )
     (i32.store offset=8
      (local.get $2)
      (local.get $3)
     )
     (local.set $0
      (i32.const 24)
     )
     (local.set $1
      (i32.const 8)
     )
     (i32.const 0)
    )
   )
   (i32.store
    (i32.add
     (local.get $1)
     (local.get $3)
    )
    (local.get $4)
   )
   (i32.store offset=12
    (local.get $3)
    (local.get $2)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (local.get $3)
    )
    (local.get $6)
   )
   (i32.store
    (i32.const 1061264)
    (select
     (local.tee $0
      (i32.sub
       (i32.load
        (i32.const 1061264)
       )
       (i32.const 1)
      )
     )
     (i32.const -1)
     (local.get $0)
    )
   )
  )
 )
 (func $calloc (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i64)
  (block $block1
   (br_if $block1
    (i32.eqz
     (local.tee $0
      (call $dlmalloc
       (local.tee $2
        (block $block (result i32)
         (drop
          (br_if $block
           (i32.const 0)
           (i32.eqz
            (local.get $0)
           )
          )
         )
         (drop
          (br_if $block
           (local.tee $2
            (i32.wrap_i64
             (local.tee $3
              (i64.mul
               (i64.extend_i32_u
                (local.get $0)
               )
               (i64.extend_i32_u
                (local.get $1)
               )
              )
             )
            )
           )
           (i32.lt_u
            (i32.or
             (local.get $0)
             (local.get $1)
            )
            (i32.const 65536)
           )
          )
         )
         (select
          (i32.const -1)
          (local.get $2)
          (i32.wrap_i64
           (i64.shr_u
            (local.get $3)
            (i64.const 32)
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (br_if $block1
    (i32.eqz
     (i32.and
      (i32.load8_u
       (i32.sub
        (local.get $0)
        (i32.const 4)
       )
      )
      (i32.const 3)
     )
    )
   )
   (br_if $block1
    (i32.eqz
     (local.get $2)
    )
   )
   (memory.fill
    (local.get $0)
    (i32.const 0)
    (local.get $2)
   )
  )
  (local.get $0)
 )
 (func $realloc (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (return
     (call $dlmalloc
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.ge_u
    (local.get $1)
    (i32.const -64)
   )
   (then
    (i32.store
     (i32.const 1061060)
     (i32.const 48)
    )
    (return
     (i32.const 0)
    )
   )
  )
  (local.set $3
   (select
    (i32.const 16)
    (i32.and
     (i32.add
      (local.get $1)
      (i32.const 19)
     )
     (i32.const -16)
    )
    (i32.lt_u
     (local.get $1)
     (i32.const 11)
    )
   )
  )
  (local.set $2
   (i32.and
    (local.tee $8
     (i32.load
      (local.tee $7
       (i32.sub
        (local.get $0)
        (i32.const 4)
       )
      )
     )
    )
    (i32.const -8)
   )
  )
  (block $block1
   (block $block
    (if
     (i32.eqz
      (i32.and
       (local.get $8)
       (i32.const 3)
      )
     )
     (then
      (br_if $block
       (i32.lt_u
        (local.get $3)
        (i32.const 256)
       )
      )
      (br_if $block
       (i32.le_u
        (local.get $2)
        (local.get $3)
       )
      )
      (br_if $block1
       (i32.le_u
        (i32.sub
         (local.get $2)
         (local.get $3)
        )
        (i32.shl
         (i32.load
          (i32.const 1061712)
         )
         (i32.const 1)
        )
       )
      )
      (br $block)
     )
    )
    (local.set $4
     (i32.add
      (local.tee $6
       (i32.sub
        (local.get $0)
        (i32.const 8)
       )
      )
      (local.get $2)
     )
    )
    (if
     (i32.ge_u
      (local.get $2)
      (local.get $3)
     )
     (then
      (br_if $block1
       (i32.lt_u
        (local.tee $1
         (i32.sub
          (local.get $2)
          (local.get $3)
         )
        )
        (i32.const 16)
       )
      )
      (i32.store
       (local.get $7)
       (i32.or
        (i32.or
         (local.get $3)
         (i32.and
          (local.get $8)
          (i32.const 1)
         )
        )
        (i32.const 2)
       )
      )
      (i32.store offset=4
       (local.tee $2
        (i32.add
         (local.get $3)
         (local.get $6)
        )
       )
       (i32.or
        (local.get $1)
        (i32.const 3)
       )
      )
      (i32.store offset=4
       (local.get $4)
       (i32.or
        (i32.load offset=4
         (local.get $4)
        )
        (i32.const 1)
       )
      )
      (call $dispose_chunk
       (local.get $2)
       (local.get $1)
      )
      (return
       (local.get $0)
      )
     )
    )
    (if
     (i32.eq
      (i32.load
       (i32.const 1061256)
      )
      (local.get $4)
     )
     (then
      (br_if $block
       (i32.le_u
        (local.tee $2
         (i32.add
          (i32.load
           (i32.const 1061244)
          )
          (local.get $2)
         )
        )
        (local.get $3)
       )
      )
      (i32.store
       (local.get $7)
       (i32.or
        (i32.or
         (local.get $3)
         (i32.and
          (local.get $8)
          (i32.const 1)
         )
        )
        (i32.const 2)
       )
      )
      (i32.store
       (i32.const 1061256)
       (local.tee $1
        (i32.add
         (local.get $3)
         (local.get $6)
        )
       )
      )
      (i32.store
       (i32.const 1061244)
       (local.tee $2
        (i32.sub
         (local.get $2)
         (local.get $3)
        )
       )
      )
      (i32.store offset=4
       (local.get $1)
       (i32.or
        (local.get $2)
        (i32.const 1)
       )
      )
      (return
       (local.get $0)
      )
     )
    )
    (if
     (i32.eq
      (i32.load
       (i32.const 1061252)
      )
      (local.get $4)
     )
     (then
      (br_if $block
       (i32.lt_u
        (local.tee $2
         (i32.add
          (i32.load
           (i32.const 1061240)
          )
          (local.get $2)
         )
        )
        (local.get $3)
       )
      )
      (block $block2
       (if
        (i32.ge_u
         (local.tee $1
          (i32.sub
           (local.get $2)
           (local.get $3)
          )
         )
         (i32.const 16)
        )
        (then
         (i32.store
          (local.get $7)
          (i32.or
           (i32.or
            (local.get $3)
            (i32.and
             (local.get $8)
             (i32.const 1)
            )
           )
           (i32.const 2)
          )
         )
         (i32.store offset=4
          (local.tee $5
           (i32.add
            (local.get $3)
            (local.get $6)
           )
          )
          (i32.or
           (local.get $1)
           (i32.const 1)
          )
         )
         (i32.store
          (local.tee $2
           (i32.add
            (local.get $2)
            (local.get $6)
           )
          )
          (local.get $1)
         )
         (i32.store offset=4
          (local.get $2)
          (i32.and
           (i32.load offset=4
            (local.get $2)
           )
           (i32.const -2)
          )
         )
         (br $block2)
        )
       )
       (i32.store
        (local.get $7)
        (i32.or
         (i32.or
          (i32.and
           (local.get $8)
           (i32.const 1)
          )
          (local.get $2)
         )
         (i32.const 2)
        )
       )
       (i32.store offset=4
        (local.tee $1
         (i32.add
          (local.get $2)
          (local.get $6)
         )
        )
        (i32.or
         (i32.load offset=4
          (local.get $1)
         )
         (i32.const 1)
        )
       )
       (local.set $1
        (i32.const 0)
       )
      )
      (i32.store
       (i32.const 1061252)
       (local.get $5)
      )
      (i32.store
       (i32.const 1061240)
       (local.get $1)
      )
      (return
       (local.get $0)
      )
     )
    )
    (br_if $block
     (i32.and
      (local.tee $5
       (i32.load offset=4
        (local.get $4)
       )
      )
      (i32.const 2)
     )
    )
    (br_if $block
     (i32.lt_u
      (local.tee $10
       (i32.add
        (i32.and
         (local.get $5)
         (i32.const -8)
        )
        (local.get $2)
       )
      )
      (local.get $3)
     )
    )
    (local.set $11
     (i32.sub
      (local.get $10)
      (local.get $3)
     )
    )
    (local.set $1
     (i32.load offset=12
      (local.get $4)
     )
    )
    (block $block3
     (if
      (i32.le_u
       (local.get $5)
       (i32.const 255)
      )
      (then
       (if
        (i32.eq
         (local.tee $2
          (i32.load offset=8
           (local.get $4)
          )
         )
         (local.get $1)
        )
        (then
         (i32.store
          (i32.const 1061232)
          (i32.and
           (i32.load
            (i32.const 1061232)
           )
           (i32.rotl
            (i32.const -2)
            (i32.shr_u
             (local.get $5)
             (i32.const 3)
            )
           )
          )
         )
         (br $block3)
        )
       )
       (i32.store offset=8
        (local.get $1)
        (local.get $2)
       )
       (i32.store offset=12
        (local.get $2)
        (local.get $1)
       )
       (br $block3)
      )
     )
     (local.set $9
      (i32.load offset=24
       (local.get $4)
      )
     )
     (block $block4
      (if
       (i32.ne
        (local.get $1)
        (local.get $4)
       )
       (then
        (i32.store offset=12
         (local.tee $2
          (i32.load offset=8
           (local.get $4)
          )
         )
         (local.get $1)
        )
        (i32.store offset=8
         (local.get $1)
         (local.get $2)
        )
        (br $block4)
       )
      )
      (block $block5
       (local.set $5
        (if (result i32)
         (local.tee $2
          (i32.load offset=20
           (local.get $4)
          )
         )
         (then
          (i32.add
           (local.get $4)
           (i32.const 20)
          )
         )
         (else
          (br_if $block5
           (i32.eqz
            (local.tee $2
             (i32.load offset=16
              (local.get $4)
             )
            )
           )
          )
          (i32.add
           (local.get $4)
           (i32.const 16)
          )
         )
        )
       )
       (loop $label
        (local.set $12
         (local.get $5)
        )
        (local.set $5
         (i32.add
          (local.tee $1
           (local.get $2)
          )
          (i32.const 20)
         )
        )
        (br_if $label
         (local.tee $2
          (i32.load offset=20
           (local.get $1)
          )
         )
        )
        (local.set $5
         (i32.add
          (local.get $1)
          (i32.const 16)
         )
        )
        (br_if $label
         (local.tee $2
          (i32.load offset=16
           (local.get $1)
          )
         )
        )
       )
       (i32.store
        (local.get $12)
        (i32.const 0)
       )
       (br $block4)
      )
      (local.set $1
       (i32.const 0)
      )
     )
     (br_if $block3
      (i32.eqz
       (local.get $9)
      )
     )
     (block $block6
      (if
       (i32.eq
        (i32.load offset=1061536
         (local.tee $5
          (i32.shl
           (local.tee $2
            (i32.load offset=28
             (local.get $4)
            )
           )
           (i32.const 2)
          )
         )
        )
        (local.get $4)
       )
       (then
        (i32.store
         (i32.add
          (local.get $5)
          (i32.const 1061536)
         )
         (local.get $1)
        )
        (br_if $block6
         (local.get $1)
        )
        (i32.store
         (i32.const 1061236)
         (i32.and
          (i32.load
           (i32.const 1061236)
          )
          (i32.rotl
           (i32.const -2)
           (local.get $2)
          )
         )
        )
        (br $block3)
       )
      )
      (block $block7
       (if
        (i32.eq
         (local.get $4)
         (i32.load offset=16
          (local.get $9)
         )
        )
        (then
         (i32.store offset=16
          (local.get $9)
          (local.get $1)
         )
         (br $block7)
        )
       )
       (i32.store offset=20
        (local.get $9)
        (local.get $1)
       )
      )
      (br_if $block3
       (i32.eqz
        (local.get $1)
       )
      )
     )
     (i32.store offset=24
      (local.get $1)
      (local.get $9)
     )
     (if
      (local.tee $2
       (i32.load offset=16
        (local.get $4)
       )
      )
      (then
       (i32.store offset=16
        (local.get $1)
        (local.get $2)
       )
       (i32.store offset=24
        (local.get $2)
        (local.get $1)
       )
      )
     )
     (br_if $block3
      (i32.eqz
       (local.tee $2
        (i32.load offset=20
         (local.get $4)
        )
       )
      )
     )
     (i32.store offset=20
      (local.get $1)
      (local.get $2)
     )
     (i32.store offset=24
      (local.get $2)
      (local.get $1)
     )
    )
    (if
     (i32.le_u
      (local.get $11)
      (i32.const 15)
     )
     (then
      (i32.store
       (local.get $7)
       (i32.or
        (i32.or
         (i32.and
          (local.get $8)
          (i32.const 1)
         )
         (local.get $10)
        )
        (i32.const 2)
       )
      )
      (i32.store offset=4
       (local.tee $1
        (i32.add
         (local.get $6)
         (local.get $10)
        )
       )
       (i32.or
        (i32.load offset=4
         (local.get $1)
        )
        (i32.const 1)
       )
      )
      (return
       (local.get $0)
      )
     )
    )
    (i32.store
     (local.get $7)
     (i32.or
      (i32.or
       (local.get $3)
       (i32.and
        (local.get $8)
        (i32.const 1)
       )
      )
      (i32.const 2)
     )
    )
    (i32.store offset=4
     (local.tee $1
      (i32.add
       (local.get $3)
       (local.get $6)
      )
     )
     (i32.or
      (local.get $11)
      (i32.const 3)
     )
    )
    (i32.store offset=4
     (local.tee $2
      (i32.add
       (local.get $6)
       (local.get $10)
      )
     )
     (i32.or
      (i32.load offset=4
       (local.get $2)
      )
      (i32.const 1)
     )
    )
    (call $dispose_chunk
     (local.get $1)
     (local.get $11)
    )
    (return
     (local.get $0)
    )
   )
   (if
    (i32.eqz
     (local.tee $2
      (call $dlmalloc
       (local.get $1)
      )
     )
    )
    (then
     (return
      (i32.const 0)
     )
    )
   )
   (if
    (local.tee $1
     (select
      (local.tee $5
       (i32.add
        (select
         (i32.const -4)
         (i32.const -8)
         (i32.and
          (local.tee $5
           (i32.load
            (local.get $7)
           )
          )
          (i32.const 3)
         )
        )
        (i32.and
         (local.get $5)
         (i32.const -8)
        )
       )
      )
      (local.get $1)
      (i32.gt_u
       (local.get $1)
       (local.get $5)
      )
     )
    )
    (then
     (memory.copy
      (local.get $2)
      (local.get $0)
      (local.get $1)
     )
    )
   )
   (call $dlfree
    (local.get $0)
   )
   (local.set $0
    (local.get $2)
   )
  )
  (local.get $0)
 )
 (func $dispose_chunk (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local.set $5
   (i32.add
    (local.get $0)
    (local.get $1)
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (i32.and
      (local.tee $2
       (i32.load offset=4
        (local.get $0)
       )
      )
      (i32.const 1)
     )
    )
    (br_if $block1
     (i32.eqz
      (i32.and
       (local.get $2)
       (i32.const 2)
      )
     )
    )
    (local.set $1
     (i32.add
      (local.tee $2
       (i32.load
        (local.get $0)
       )
      )
      (local.get $1)
     )
    )
    (block $block3
     (block $block4
      (block $block2
       (if
        (i32.ne
         (local.tee $0
          (i32.sub
           (local.get $0)
           (local.get $2)
          )
         )
         (i32.load
          (i32.const 1061252)
         )
        )
        (then
         (local.set $3
          (i32.load offset=12
           (local.get $0)
          )
         )
         (if
          (i32.le_u
           (local.get $2)
           (i32.const 255)
          )
          (then
           (br_if $block2
            (i32.ne
             (local.get $3)
             (local.tee $4
              (i32.load offset=8
               (local.get $0)
              )
             )
            )
           )
           (i32.store
            (i32.const 1061232)
            (i32.and
             (i32.load
              (i32.const 1061232)
             )
             (i32.rotl
              (i32.const -2)
              (i32.shr_u
               (local.get $2)
               (i32.const 3)
              )
             )
            )
           )
           (br $block)
          )
         )
         (local.set $6
          (i32.load offset=24
           (local.get $0)
          )
         )
         (if
          (i32.ne
           (local.get $0)
           (local.get $3)
          )
          (then
           (i32.store offset=12
            (local.tee $2
             (i32.load offset=8
              (local.get $0)
             )
            )
            (local.get $3)
           )
           (i32.store offset=8
            (local.get $3)
            (local.get $2)
           )
           (br $block3)
          )
         )
         (local.set $2
          (if (result i32)
           (local.tee $4
            (i32.load offset=20
             (local.get $0)
            )
           )
           (then
            (i32.add
             (local.get $0)
             (i32.const 20)
            )
           )
           (else
            (br_if $block4
             (i32.eqz
              (local.tee $4
               (i32.load offset=16
                (local.get $0)
               )
              )
             )
            )
            (i32.add
             (local.get $0)
             (i32.const 16)
            )
           )
          )
         )
         (loop $label
          (local.set $7
           (local.get $2)
          )
          (local.set $2
           (i32.add
            (local.tee $3
             (local.get $4)
            )
            (i32.const 20)
           )
          )
          (br_if $label
           (local.tee $4
            (i32.load offset=20
             (local.get $3)
            )
           )
          )
          (local.set $2
           (i32.add
            (local.get $3)
            (i32.const 16)
           )
          )
          (br_if $label
           (local.tee $4
            (i32.load offset=16
             (local.get $3)
            )
           )
          )
         )
         (i32.store
          (local.get $7)
          (i32.const 0)
         )
         (br $block3)
        )
       )
       (br_if $block
        (i32.ne
         (i32.and
          (local.tee $2
           (i32.load offset=4
            (local.get $5)
           )
          )
          (i32.const 3)
         )
         (i32.const 3)
        )
       )
       (i32.store offset=4
        (local.get $5)
        (i32.and
         (local.get $2)
         (i32.const -2)
        )
       )
       (i32.store
        (i32.const 1061240)
        (local.get $1)
       )
       (i32.store
        (local.get $5)
        (local.get $1)
       )
       (i32.store offset=4
        (local.get $0)
        (i32.or
         (local.get $1)
         (i32.const 1)
        )
       )
       (return)
      )
      (i32.store offset=8
       (local.get $3)
       (local.get $4)
      )
      (i32.store offset=12
       (local.get $4)
       (local.get $3)
      )
      (br $block)
     )
     (local.set $3
      (i32.const 0)
     )
    )
    (br_if $block
     (i32.eqz
      (local.get $6)
     )
    )
    (block $block5
     (if
      (i32.eq
       (i32.load offset=1061536
        (local.tee $4
         (i32.shl
          (local.tee $2
           (i32.load offset=28
            (local.get $0)
           )
          )
          (i32.const 2)
         )
        )
       )
       (local.get $0)
      )
      (then
       (i32.store
        (i32.add
         (local.get $4)
         (i32.const 1061536)
        )
        (local.get $3)
       )
       (br_if $block5
        (local.get $3)
       )
       (i32.store
        (i32.const 1061236)
        (i32.and
         (i32.load
          (i32.const 1061236)
         )
         (i32.rotl
          (i32.const -2)
          (local.get $2)
         )
        )
       )
       (br $block)
      )
     )
     (block $block6
      (if
       (i32.eq
        (local.get $0)
        (i32.load offset=16
         (local.get $6)
        )
       )
       (then
        (i32.store offset=16
         (local.get $6)
         (local.get $3)
        )
        (br $block6)
       )
      )
      (i32.store offset=20
       (local.get $6)
       (local.get $3)
      )
     )
     (br_if $block
      (i32.eqz
       (local.get $3)
      )
     )
    )
    (i32.store offset=24
     (local.get $3)
     (local.get $6)
    )
    (if
     (local.tee $2
      (i32.load offset=16
       (local.get $0)
      )
     )
     (then
      (i32.store offset=16
       (local.get $3)
       (local.get $2)
      )
      (i32.store offset=24
       (local.get $2)
       (local.get $3)
      )
     )
    )
    (br_if $block
     (i32.eqz
      (local.tee $2
       (i32.load offset=20
        (local.get $0)
       )
      )
     )
    )
    (i32.store offset=20
     (local.get $3)
     (local.get $2)
    )
    (i32.store offset=24
     (local.get $2)
     (local.get $3)
    )
   )
   (block $block10
    (block $block7
     (block $block8
      (block $block9
       (if
        (i32.eqz
         (i32.and
          (local.tee $2
           (i32.load offset=4
            (local.get $5)
           )
          )
          (i32.const 2)
         )
        )
        (then
         (if
          (i32.eq
           (i32.load
            (i32.const 1061256)
           )
           (local.get $5)
          )
          (then
           (i32.store
            (i32.const 1061256)
            (local.get $0)
           )
           (i32.store
            (i32.const 1061244)
            (local.tee $1
             (i32.add
              (i32.load
               (i32.const 1061244)
              )
              (local.get $1)
             )
            )
           )
           (i32.store offset=4
            (local.get $0)
            (i32.or
             (local.get $1)
             (i32.const 1)
            )
           )
           (br_if $block1
            (i32.ne
             (local.get $0)
             (i32.load
              (i32.const 1061252)
             )
            )
           )
           (i32.store
            (i32.const 1061240)
            (i32.const 0)
           )
           (i32.store
            (i32.const 1061252)
            (i32.const 0)
           )
           (return)
          )
         )
         (if
          (i32.eq
           (local.tee $8
            (i32.load
             (i32.const 1061252)
            )
           )
           (local.get $5)
          )
          (then
           (i32.store
            (i32.const 1061252)
            (local.get $0)
           )
           (i32.store
            (i32.const 1061240)
            (local.tee $1
             (i32.add
              (i32.load
               (i32.const 1061240)
              )
              (local.get $1)
             )
            )
           )
           (i32.store offset=4
            (local.get $0)
            (i32.or
             (local.get $1)
             (i32.const 1)
            )
           )
           (i32.store
            (i32.add
             (local.get $0)
             (local.get $1)
            )
            (local.get $1)
           )
           (return)
          )
         )
         (local.set $1
          (i32.add
           (i32.and
            (local.get $2)
            (i32.const -8)
           )
           (local.get $1)
          )
         )
         (local.set $3
          (i32.load offset=12
           (local.get $5)
          )
         )
         (if
          (i32.le_u
           (local.get $2)
           (i32.const 255)
          )
          (then
           (if
            (i32.eq
             (local.tee $4
              (i32.load offset=8
               (local.get $5)
              )
             )
             (local.get $3)
            )
            (then
             (i32.store
              (i32.const 1061232)
              (i32.and
               (i32.load
                (i32.const 1061232)
               )
               (i32.rotl
                (i32.const -2)
                (i32.shr_u
                 (local.get $2)
                 (i32.const 3)
                )
               )
              )
             )
             (br $block7)
            )
           )
           (i32.store offset=8
            (local.get $3)
            (local.get $4)
           )
           (i32.store offset=12
            (local.get $4)
            (local.get $3)
           )
           (br $block7)
          )
         )
         (local.set $6
          (i32.load offset=24
           (local.get $5)
          )
         )
         (if
          (i32.ne
           (local.get $3)
           (local.get $5)
          )
          (then
           (i32.store offset=12
            (local.tee $2
             (i32.load offset=8
              (local.get $5)
             )
            )
            (local.get $3)
           )
           (i32.store offset=8
            (local.get $3)
            (local.get $2)
           )
           (br $block8)
          )
         )
         (local.set $2
          (if (result i32)
           (local.tee $4
            (i32.load offset=20
             (local.get $5)
            )
           )
           (then
            (i32.add
             (local.get $5)
             (i32.const 20)
            )
           )
           (else
            (br_if $block9
             (i32.eqz
              (local.tee $4
               (i32.load offset=16
                (local.get $5)
               )
              )
             )
            )
            (i32.add
             (local.get $5)
             (i32.const 16)
            )
           )
          )
         )
         (loop $label1
          (local.set $7
           (local.get $2)
          )
          (local.set $2
           (i32.add
            (local.tee $3
             (local.get $4)
            )
            (i32.const 20)
           )
          )
          (br_if $label1
           (local.tee $4
            (i32.load offset=20
             (local.get $3)
            )
           )
          )
          (local.set $2
           (i32.add
            (local.get $3)
            (i32.const 16)
           )
          )
          (br_if $label1
           (local.tee $4
            (i32.load offset=16
             (local.get $3)
            )
           )
          )
         )
         (i32.store
          (local.get $7)
          (i32.const 0)
         )
         (br $block8)
        )
       )
       (i32.store offset=4
        (local.get $5)
        (i32.and
         (local.get $2)
         (i32.const -2)
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (local.get $1)
        )
        (local.get $1)
       )
       (i32.store offset=4
        (local.get $0)
        (i32.or
         (local.get $1)
         (i32.const 1)
        )
       )
       (br $block10)
      )
      (local.set $3
       (i32.const 0)
      )
     )
     (br_if $block7
      (i32.eqz
       (local.get $6)
      )
     )
     (block $block11
      (if
       (i32.eq
        (i32.load offset=1061536
         (local.tee $4
          (i32.shl
           (local.tee $2
            (i32.load offset=28
             (local.get $5)
            )
           )
           (i32.const 2)
          )
         )
        )
        (local.get $5)
       )
       (then
        (i32.store
         (i32.add
          (local.get $4)
          (i32.const 1061536)
         )
         (local.get $3)
        )
        (br_if $block11
         (local.get $3)
        )
        (i32.store
         (i32.const 1061236)
         (i32.and
          (i32.load
           (i32.const 1061236)
          )
          (i32.rotl
           (i32.const -2)
           (local.get $2)
          )
         )
        )
        (br $block7)
       )
      )
      (block $block12
       (if
        (i32.eq
         (local.get $5)
         (i32.load offset=16
          (local.get $6)
         )
        )
        (then
         (i32.store offset=16
          (local.get $6)
          (local.get $3)
         )
         (br $block12)
        )
       )
       (i32.store offset=20
        (local.get $6)
        (local.get $3)
       )
      )
      (br_if $block7
       (i32.eqz
        (local.get $3)
       )
      )
     )
     (i32.store offset=24
      (local.get $3)
      (local.get $6)
     )
     (if
      (local.tee $2
       (i32.load offset=16
        (local.get $5)
       )
      )
      (then
       (i32.store offset=16
        (local.get $3)
        (local.get $2)
       )
       (i32.store offset=24
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (br_if $block7
      (i32.eqz
       (local.tee $2
        (i32.load offset=20
         (local.get $5)
        )
       )
      )
     )
     (i32.store offset=20
      (local.get $3)
      (local.get $2)
     )
     (i32.store offset=24
      (local.get $2)
      (local.get $3)
     )
    )
    (i32.store
     (i32.add
      (local.get $0)
      (local.get $1)
     )
     (local.get $1)
    )
    (i32.store offset=4
     (local.get $0)
     (i32.or
      (local.get $1)
      (i32.const 1)
     )
    )
    (br_if $block10
     (i32.ne
      (local.get $0)
      (local.get $8)
     )
    )
    (i32.store
     (i32.const 1061240)
     (local.get $1)
    )
    (return)
   )
   (if
    (i32.le_u
     (local.get $1)
     (i32.const 255)
    )
    (then
     (local.set $2
      (i32.add
       (i32.and
        (local.get $1)
        (i32.const -8)
       )
       (i32.const 1061272)
      )
     )
     (i32.store offset=12
      (local.tee $1
       (block $block13 (result i32)
        (if
         (i32.eqz
          (i32.and
           (local.tee $3
            (i32.load
             (i32.const 1061232)
            )
           )
           (local.tee $1
            (i32.shl
             (i32.const 1)
             (i32.shr_u
              (local.get $1)
              (i32.const 3)
             )
            )
           )
          )
         )
         (then
          (i32.store
           (i32.const 1061232)
           (i32.or
            (local.get $1)
            (local.get $3)
           )
          )
          (br $block13
           (local.get $2)
          )
         )
        )
        (i32.load offset=8
         (local.get $2)
        )
       )
      )
      (local.get $0)
     )
     (i32.store offset=8
      (local.get $2)
      (local.get $0)
     )
     (i32.store offset=12
      (local.get $0)
      (local.get $2)
     )
     (i32.store offset=8
      (local.get $0)
      (local.get $1)
     )
     (return)
    )
   )
   (local.set $3
    (i32.const 31)
   )
   (if
    (i32.le_u
     (local.get $1)
     (i32.const 16777215)
    )
    (then
     (local.set $3
      (i32.add
       (i32.sub
        (i32.and
         (i32.shr_u
          (local.get $1)
          (i32.sub
           (i32.const 38)
           (local.tee $2
            (i32.clz
             (i32.shr_u
              (local.get $1)
              (i32.const 8)
             )
            )
           )
          )
         )
         (i32.const 1)
        )
        (i32.shl
         (local.get $2)
         (i32.const 1)
        )
       )
       (i32.const 62)
      )
     )
    )
   )
   (i32.store offset=28
    (local.get $0)
    (local.get $3)
   )
   (i64.store offset=16 align=4
    (local.get $0)
    (i64.const 0)
   )
   (local.set $2
    (i32.add
     (i32.shl
      (local.get $3)
      (i32.const 2)
     )
     (i32.const 1061536)
    )
   )
   (if
    (i32.eqz
     (i32.and
      (local.tee $4
       (i32.load
        (i32.const 1061236)
       )
      )
      (local.tee $7
       (i32.shl
        (i32.const 1)
        (local.get $3)
       )
      )
     )
    )
    (then
     (i32.store
      (local.get $2)
      (local.get $0)
     )
     (i32.store
      (i32.const 1061236)
      (i32.or
       (local.get $4)
       (local.get $7)
      )
     )
     (i32.store offset=24
      (local.get $0)
      (local.get $2)
     )
     (i32.store offset=8
      (local.get $0)
      (local.get $0)
     )
     (i32.store offset=12
      (local.get $0)
      (local.get $0)
     )
     (return)
    )
   )
   (local.set $3
    (i32.shl
     (local.get $1)
     (select
      (i32.sub
       (i32.const 25)
       (i32.shr_u
        (local.get $3)
        (i32.const 1)
       )
      )
      (i32.const 0)
      (i32.ne
       (local.get $3)
       (i32.const 31)
      )
     )
    )
   )
   (local.set $2
    (i32.load
     (local.get $2)
    )
   )
   (block $block14
    (loop $label2
     (br_if $block14
      (i32.eq
       (i32.and
        (i32.load offset=4
         (local.tee $4
          (local.get $2)
         )
        )
        (i32.const -8)
       )
       (local.get $1)
      )
     )
     (local.set $2
      (i32.shr_u
       (local.get $3)
       (i32.const 29)
      )
     )
     (local.set $3
      (i32.shl
       (local.get $3)
       (i32.const 1)
      )
     )
     (br_if $label2
      (local.tee $2
       (i32.load offset=16
        (local.tee $7
         (i32.add
          (local.get $4)
          (i32.and
           (local.get $2)
           (i32.const 4)
          )
         )
        )
       )
      )
     )
    )
    (i32.store
     (i32.add
      (local.get $7)
      (i32.const 16)
     )
     (local.get $0)
    )
    (i32.store offset=24
     (local.get $0)
     (local.get $4)
    )
    (i32.store offset=12
     (local.get $0)
     (local.get $0)
    )
    (i32.store offset=8
     (local.get $0)
     (local.get $0)
    )
    (return)
   )
   (i32.store offset=12
    (local.tee $1
     (i32.load offset=8
      (local.get $4)
     )
    )
    (local.get $0)
   )
   (i32.store offset=8
    (local.get $4)
    (local.get $0)
   )
   (i32.store offset=24
    (local.get $0)
    (i32.const 0)
   )
   (i32.store offset=12
    (local.get $0)
    (local.get $4)
   )
   (i32.store offset=8
    (local.get $0)
    (local.get $1)
   )
  )
 )
 (func $posix_memalign (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (if
   (i32.gt_u
    (local.get $1)
    (i32.const -68)
   )
   (then
    (return
     (i32.const 48)
    )
   )
  )
  (if
   (i32.eqz
    (local.tee $1
     (block $block (result i32)
      (if
       (i32.ge_u
        (local.get $1)
        (i32.const -80)
       )
       (then
        (i32.store
         (i32.const 1061060)
         (i32.const 48)
        )
        (br $block
         (i32.const 0)
        )
       )
      )
      (drop
       (br_if $block
        (i32.const 0)
        (i32.eqz
         (local.tee $1
          (call $dlmalloc
           (i32.add
            (local.tee $5
             (select
              (i32.const 16)
              (i32.and
               (i32.add
                (local.get $1)
                (i32.const 19)
               )
               (i32.const -16)
              )
              (i32.lt_u
               (local.get $1)
               (i32.const 11)
              )
             )
            )
            (i32.const 28)
           )
          )
         )
        )
       )
      )
      (local.set $2
       (i32.sub
        (local.get $1)
        (i32.const 8)
       )
      )
      (block $block1
       (if
        (i32.eqz
         (i32.and
          (local.get $1)
          (i32.const 15)
         )
        )
        (then
         (local.set $1
          (local.get $2)
         )
         (br $block1)
        )
       )
       (local.set $4
        (i32.sub
         (i32.and
          (local.tee $7
           (i32.load
            (local.tee $6
             (i32.sub
              (local.get $1)
              (i32.const 4)
             )
            )
           )
          )
          (i32.const -8)
         )
         (local.tee $3
          (i32.sub
           (local.tee $1
            (i32.add
             (local.tee $1
              (i32.sub
               (i32.and
                (i32.add
                 (local.get $1)
                 (i32.const 15)
                )
                (i32.const -16)
               )
               (i32.const 8)
              )
             )
             (select
              (i32.const 16)
              (i32.const 0)
              (i32.le_u
               (i32.sub
                (local.get $1)
                (local.get $2)
               )
               (i32.const 15)
              )
             )
            )
           )
           (local.get $2)
          )
         )
        )
       )
       (if
        (i32.eqz
         (i32.and
          (local.get $7)
          (i32.const 3)
         )
        )
        (then
         (i32.store offset=4
          (local.get $1)
          (local.get $4)
         )
         (i32.store
          (local.get $1)
          (i32.add
           (i32.load
            (local.get $2)
           )
           (local.get $3)
          )
         )
         (br $block1)
        )
       )
       (i32.store offset=4
        (local.get $1)
        (i32.or
         (i32.or
          (local.get $4)
          (i32.and
           (i32.load offset=4
            (local.get $1)
           )
           (i32.const 1)
          )
         )
         (i32.const 2)
        )
       )
       (i32.store offset=4
        (local.tee $4
         (i32.add
          (local.get $1)
          (local.get $4)
         )
        )
        (i32.or
         (i32.load offset=4
          (local.get $4)
         )
         (i32.const 1)
        )
       )
       (i32.store
        (local.get $6)
        (i32.or
         (i32.or
          (local.get $3)
          (i32.and
           (i32.load
            (local.get $6)
           )
           (i32.const 1)
          )
         )
         (i32.const 2)
        )
       )
       (i32.store offset=4
        (local.tee $4
         (i32.add
          (local.get $2)
          (local.get $3)
         )
        )
        (i32.or
         (i32.load offset=4
          (local.get $4)
         )
         (i32.const 1)
        )
       )
       (call $dispose_chunk
        (local.get $2)
        (local.get $3)
       )
      )
      (block $block2
       (br_if $block2
        (i32.eqz
         (i32.and
          (local.tee $2
           (i32.load offset=4
            (local.get $1)
           )
          )
          (i32.const 3)
         )
        )
       )
       (br_if $block2
        (i32.le_u
         (local.tee $3
          (i32.and
           (local.get $2)
           (i32.const -8)
          )
         )
         (i32.add
          (local.get $5)
          (i32.const 16)
         )
        )
       )
       (i32.store offset=4
        (local.get $1)
        (i32.or
         (i32.or
          (local.get $5)
          (i32.and
           (local.get $2)
           (i32.const 1)
          )
         )
         (i32.const 2)
        )
       )
       (i32.store offset=4
        (local.tee $2
         (i32.add
          (local.get $1)
          (local.get $5)
         )
        )
        (i32.or
         (local.tee $5
          (i32.sub
           (local.get $3)
           (local.get $5)
          )
         )
         (i32.const 3)
        )
       )
       (i32.store offset=4
        (local.tee $3
         (i32.add
          (local.get $1)
          (local.get $3)
         )
        )
        (i32.or
         (i32.load offset=4
          (local.get $3)
         )
         (i32.const 1)
        )
       )
       (call $dispose_chunk
        (local.get $2)
        (local.get $5)
       )
      )
      (i32.add
       (local.get $1)
       (i32.const 8)
      )
     )
    )
   )
   (then
    (return
     (i32.const 48)
    )
   )
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
  (i32.const 0)
 )
 ;; custom section "producers", size 174
 ;; features section: mutable-globals, nontrapping-float-to-int, bulk-memory, sign-ext, reference-types, multivalue, extended-const, bulk-memory-opt, call-indirect-overlong
)

