(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-bv2string-20261014/build/bv2string-attempt4/bv2string/program.scm" "/tmp/snail-strict-bv2string-20261014/build/bv2string-attempt4/bv2string/program.so"))
