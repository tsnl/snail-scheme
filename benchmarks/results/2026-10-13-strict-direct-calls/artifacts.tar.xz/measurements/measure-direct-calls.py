"""Measure a frozen old/new strict module and original/adapted Chez controls."""

from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import math
import os
import statistics
import subprocess
import sys
import time


# ---- Frozen inputs and independently validated executables ----

benchmark = sys.argv[1]
frozen, candidate, output = map(Path, sys.argv[2:])
node = Path('/nix/store/lfaydgacdyngci7p60s8wwvgdm74fjkx-nodejs-24.19.0/bin/node')
chez = Path('/nix/store/bzqpmy5kmvf0xn4xh5ixzkw00w9srh07-chez-scheme-10.4.1/bin/scheme')
taskset = Path('/run/current-system/sw/bin/taskset')
host = frozen / 'host.mjs'
spec = frozen / benchmark / 'spec.json'
input_file = frozen / benchmark / 'input.txt'
variants = {
    'old-strict': frozen / benchmark / 'strict.wasm',
    'direct-strict': candidate,
    'original-chez': frozen / benchmark / 'program.so',
    'adapted-chez': frozen / benchmark / 'same-source-chez/program.so',
}
env = os.environ.copy()
env.pop('NODE_OPTIONS', None)
module_spec = importlib.util.spec_from_file_location('frozen_r7rs', frozen / 'r7rs.py')
runner = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(runner)


def identities():
    paths = dict(variants, node=node, chez=chez, taskset=taskset, host=host, spec=spec,
                 input=input_file, runner=frozen / 'r7rs.py', driver=Path(__file__))
    return {key: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            for key, path in paths.items()}


def observe(name):
    arguments = ([str(node), str(host), str(variants[name]), str(spec)] if name.endswith('strict')
                 else [str(chez), '--program', str(variants[name])])
    command = [str(taskset), '-c', '5', *arguments]
    data = None if name.endswith('strict') else input_file.read_text()
    started = time.monotonic()
    process = subprocess.run(command, env=env, input=data, capture_output=True, text=True, timeout=90)
    return {'variant': name, 'command': command, 'stdin': data, 'returncode': process.returncode,
            'stdout': process.stdout, 'stderr': process.stderr, 'process_seconds': time.monotonic() - started}


def checked_seconds(observation):
    assert observation['returncode'] == 0 and not observation['stderr'], observation
    if observation['variant'].endswith('strict'):
        result = json.loads(observation['stdout'])
        assert result['result'] == str(config['expected'])
        assert result['barriers'] is None and result['setup_barriers'] is None
    else:
        result = runner.parse_result(observation['stdout'], 'chez', benchmark)
        assert result['status'] == 'ok', result
    assert math.isfinite(result['seconds']) and result['seconds'] > 0
    return result['seconds']


# ---- One discarded round and four balanced retained rounds ----

initial = identities()
config = json.loads(spec.read_text())
canonical = {'quicksort': (2500, [10000, 1000000]), 'graphs': (3, [7]), 'mperm': (20, [10, 2, 1])}
assert (config['count'], config['inputs']) == canonical[benchmark]
record = {
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'benchmark': benchmark,
    'scope': 'Uninstrumented original workload; initialization excluded, V8 default tiering included.',
    'compiler_before': 'a4030ce190058db3e9d64f6942401b5fa38dbd58',
    'compiler_after': '35d5baa52c2a0e25d0c86c02adefd661a6457a3b',
    'cpu': 5, 'node_options': None, 'identities_before': initial, 'observations': [], 'complete': False,
}
names = list(variants)
for round_index in range(-1, 4):
    offset = max(round_index, 0) % len(names)
    for name in names[offset:] + names[:offset]:
        result = dict(observe(name), round=round_index, retained=round_index >= 0)
        record['observations'].append(result)
        output.write_text(json.dumps(record, indent=2) + '\n')
        result['workload_seconds'] = checked_seconds(result)
        output.write_text(json.dumps(record, indent=2) + '\n')
        print(round_index, name, result['workload_seconds'], flush=True)

record['identities_after'] = identities()
assert record['identities_after'] == initial
record['summary'] = {}
for name in names:
    samples = [r['workload_seconds'] for r in record['observations'] if r['variant'] == name and r['retained']]
    record['summary'][name] = {'samples': samples, 'median': statistics.median(samples),
                               'min': min(samples), 'max': max(samples)}
median = {name: value['median'] for name, value in record['summary'].items()}
record['ratios'] = {name: median['direct-strict'] / median[name] for name in names if name != 'direct-strict'}
record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['complete'] = True
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'summary': record['summary'], 'ratios': record['ratios']}, indent=2))
