"""Compare exact canonical Wasm shapes; this is not dynamic allocation evidence."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
FROZEN = Path('/tmp/snail-strict-enumeration-preparation-20261013')
BASELINE = json.loads((FROZEN / 'retention-audit.json').read_text())
OPERATIONS = re.compile(r'\((array\.[\w_]+|struct\.[\w_]+|call|call_ref|return_call|return_call_ref|ref\.is_null|i64\.div_s)\b')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def form(source, prefix):
    assert source.count(prefix) == 1, prefix
    start, depth = source.index(prefix), 0
    for token in re.finditer(r'"(?:[^"\\]|\\.)*"|;[^\n]*|[()]', source[start:]):
        depth += (token.group() == '(') - (token.group() == ')')
        if depth == 0:
            return source[start:start + token.end()]
    raise AssertionError('unclosed form')


def describe(source, prefix):
    body = form(source, prefix)
    return dict(start_line=source.count('\n', 0, source.index(prefix)) + 1,
                static_instruction_sites=dict(sorted(Counter(OPERATIONS.findall(body)).items())),
                direct_call_targets=re.findall(r'\((?:call|return_call) (\$[\w]+)', body),
                referenced_functions=re.findall(r'\(ref\.func (\$[\w]+)', body))


def summary(directory):
    result = dict(hashes={name: digest(directory / name) for name in
                         ['strict.wasm.raw.wasm', 'strict.wasm', 'strict.optimized.wat']},
                  optimized_bytes=(directory / 'strict.wasm').stat().st_size)
    for mode, name in [('raw', 'strict.wasm.wat'), ('optimized', 'strict.optimized.wat')]:
        source = (directory / name).read_text()
        result[mode] = dict(static_instruction_sites=dict(sorted(Counter(OPERATIONS.findall(source)).items())),
                           exports=re.findall(r'\(export "([^"]+)"', source))
    return result


def locations(source, needles):
    return {needle: [source.count('\n', 0, m.start()) + 1
                     for m in re.finditer(re.escape(needle), source)] for needle in needles}


def compare_case(name):
    old, new = FROZEN / name, ROOT / name
    source = (new / 'strict.optimized.wat').read_text()
    result = dict(before=summary(old), after=summary(new), source=str(old / 'strict.scm'),
                  source_sha256=digest(old / 'strict.scm'), functions=[])
    assert result['source_sha256'] == BASELINE['cases'][name]['hashes']['strict.scm']
    assert result['after']['optimized']['exports'] == ['bench', 'main']
    for previous in BASELINE['cases'][name]['functions']:
        name = previous['function']
        match = re.search(r'\(func ' + re.escape(name) + r'\s', source)
        current = describe(source, match.group()) if match else dict(status='inlined in optimized module')
        result['functions'].append(dict(function=name, role=previous['role'],
                                       source_origin=previous['source_origin'], after=current,
                                       before_static_instruction_sites=previous['static_instruction_sites']))
    return result


graphs = compare_case('graphs')
graph = (ROOT / 'graphs/strict.optimized.wat').read_text()
graph_layouts = ['$type13', '$type14', '$type16', '$type17', '$type18', '$type24', '$type48']
for label in graph_layouts:
    before = form((FROZEN / 'graphs/strict.optimized.wat').read_text(), '(type ' + label + ' ')
    assert form(graph, '(type ' + label + ' ') == before
for function in graphs['functions']:
    assert function['after']['static_instruction_sites'] == function['before_static_instruction_sites'], function
for mode in ['raw', 'optimized']:
    assert graphs['before'][mode]['static_instruction_sites'] == graphs['after'][mode]['static_instruction_sites']
accepted = form(graph, '(func $function74 ')
assert accepted.index('(array.set $type14') < accepted.index('(call $function30') < accepted.index('(struct.new $type24')
assert re.search(r'\(drop\s+\(call \$function30', accepted)
assert form(graph, '(type $type24 ') == '(type $type24 (struct (field (ref null $type24))))'
assert '(array.new $type14' in form(graph, '(func $function30 ')
assert '(array.set $type14' in form(graph, '(func $function36 ')
assert '(call $function87' in form(graph, '(func $function84 ')
assert '(return_call $function84' in form(graph, '(func $function84 ')
assert '(return_call $function87' in form(graph, '(func $function87 ')
graphs.update(
    conclusion='No retained-work shape change: every audited function has identical array/struct/call instruction counts and all seven audited data layouts are byte-identical. Environment field order changes with deterministic capture ordering.',
    retained=BASELINE['cases']['graphs']['retained'],
    eliminated=BASELINE['cases']['graphs']['eliminated'],
    accepted_result_order=['store root row', 'construct and discard fresh result vector', 'allocate cdr-only result-list node'],
    evidence=locations(graph, ['(func $function30 ', '(func $function36 ', '(func $function74 ',
                              '(call $function30', '(struct.new $type24', '(func $function84 ', '(func $function87 ']),
    allocation_claim=BASELINE['cases']['graphs']['allocation_claim'])

mperm = compare_case('mperm')
perm = (ROOT / 'mperm/strict.optimized.wat').read_text()
layouts = {
    '$type12': '(struct (field i64) (field (ref null $type12)))',
    '$type16': '(struct (field (ref null $type12)) (field (ref null $type16)))',
    '$type20': '(array (mut (ref null $type16)))',
    '$type22': '(struct (field (ref $type19)) (field (ref $type21)))',
    '$type19': '(struct (field (ref $environment45)))',
    '$environment45': '(struct (field i64) (field i64) (field i64) (field (ref $type33)) (field (ref $type34)) (field (ref $type34)))',
    '$type33': '(struct (field i32) (field (ref $type20)))',
    '$type40': '(struct (field (mut (ref null $type12))))',
    '$type42': '(struct (field (mut (ref $type16))))',
}
for label, shape in layouts.items():
    assert form(perm, '(type ' + label + ' ') == '(type ' + label + ' ' + shape + ')', label
fill, work, flush, generator, tail, reverse, predicate, bench, repeat = [
    form(perm, '(func $function' + str(n) + ' ') for n in [33, 45, 32, 41, 43, 44, 46, 53, 54]]
main = form(perm, re.search(r'\(func \$main\s', perm).group())
assert fill.count('(array.set $type20') == 1
assert fill.index('(call_ref $call35') < fill.index('(array.set $type20') < fill.index('(return_call $function33')
assert work.index('(call $function33') < work.index('(ref.func $function32') < work.index('(call_ref $call35')
assert '(array.get $type20' in flush and '(array.set $type20' in flush and '(ref.null none)' in flush
assert '(call $function43' in generator and '(call $function44' in generator and '(struct.new $type16' in generator
assert '(struct.get $type12 1' in tail and '(struct.new $type12' not in tail
assert '(struct.new $type12' in reverse and '(return_call $function44' in reverse
assert '(struct.new $type40' in fill and '(struct.new $type42' in fill
assert '(struct.set $type40 0' in generator and '(struct.set $type42 0' in generator
assert '(call $function50' in predicate and '(call $function26' in predicate
assert bench.count('(call $function46') == 1
assert '(call $function45' in repeat and '(return_call $function54' in repeat
plan_store = form(main, '(global.set $global145')
assert plan_store.index('(call $function33') < plan_store.index('(struct.new $type22')
assert '(array.new_default $type20' in plan_store
raw = (ROOT / 'mperm/strict.wasm.wat').read_text()
assert '(func $function40 ' in raw and '(func $function42 ' in raw
mperm.update(
    conclusion='Direct local procedures reduce closure/environment/binding scaffolding and expose P/F for optimization into the surviving generator loop. Inner/outer list payloads, explicit Ref objects, shared-tail traversal, queue reachability, and source operation order remain.',
    retained=BASELINE['cases']['mperm']['retained'],
    canonical_root_path=['$global145 -> $type22 plan work field 0', '$type19 work closure field 0 -> $environment45',
                         '$environment45 field 3 -> $type33 queue binding', '$type33 field 1 -> $type20 mutable queue array',
                         '$type20 slots -> $type16 outer nodes -> $type12 inner nodes and cdr tails'],
    changed_layouts={'work_environment_queue_field': '4 -> 3; direct fill/flush closure payloads replaced with captures/readiness',
                     'explicit_ref_current_permutation': '$type42 -> $type40; same mutable nullable inner-list payload',
                     'explicit_ref_accumulated_permutations': '$type44 -> $type42; same mutable nonnull outer-list payload'},
    optimized_layouts={key: form(perm, '(type ' + key + ' ') for key in layouts},
    order_and_overlap=BASELINE['cases']['mperm']['order_and_overlap'],
    source_schedule=BASELINE['cases']['mperm']['source_schedule'],
    source_pair_counts=BASELINE['cases']['mperm']['source_pair_counts'],
    rooting_limits=BASELINE['cases']['mperm']['rooting_limits'],
    evidence=locations(perm, ['(func $function32 ', '(func $function33 ', '(func $function41 ', '(func $function43 ',
                             '(func $function44 ', '(func $function45 ', '(func $function46 ', '(func $function53 ',
                             '(func $function54 ', '(array.set $type20', '(call $function33',
                             '(array.new_default $type20', '(struct.new $type22', '(global.set $global145']))

result = dict(compiler_commit='35d5baa52c2a0e25d0c86c02adefd661a6457a3b',
              baseline_retention_audit=str(FROZEN / 'retention-audit.json'),
              baseline_retention_audit_sha256=digest(FROZEN / 'retention-audit.json'),
              evidence_kind=__doc__, performance_samples=0,
              probe_isolation='Canonical modules export only bench/main. Complete encoders and the unchanged handwritten identity observer remain in separate modules.',
              source_map_identity='All function/global locations match the baseline after normalizing only the archived compiler path.',
              cases=dict(graphs=graphs, mperm=mperm))
(ROOT / 'retention-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print('Canonical retention assertions passed; saved retention-comparison.json.')
