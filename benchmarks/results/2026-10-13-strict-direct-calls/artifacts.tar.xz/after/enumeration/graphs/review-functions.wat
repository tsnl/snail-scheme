;; optimized source line 293
(func $function30 (type $96) (param $0 i64) (param $1 (ref $type33)) (result (ref $type14))
  (local $2 (ref $type58))
  (local $3 (ref $type55))
  (local $4 (ref $type28))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global72)
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready78)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global78)
     )
    )
    (if
     (i32.eqz
      (global.get $ready80)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global80)
     )
    )
    (array.new_fixed $type14 0)
   )
   (else
    (struct.set $type58 1
     (local.tee $2
      (struct.new_default $type58)
     )
     (struct.new $type28
      (ref.func $function36)
      (struct.new $environment36
       (local.get $0)
       (local.get $1)
       (local.tee $3
        (struct.new $type55
         (array.new $type14
          (call_ref $call33
           (struct.get $type33 1
            (local.get $1)
           )
           (i64.const 0)
           (struct.get $type33 0
            (local.get $1)
           )
          )
          (block (result i32)
           (if
            (i64.gt_u
             (local.get $0)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $0)
           )
          )
         )
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type58 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type58 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1)
      (struct.get $type28 0
       (local.get $4)
      )
     )
    )
    (struct.get $type55 0
     (local.get $3)
    )
   )
  )
 )

;; optimized source line 2956
(func $function54 (type $47) (param $0 i64) (param $1 (ref $type35)) (result (ref $type18))
  (local $2 (ref $type58))
  (local $3 (ref $type74))
  (local $4 (ref $type28))
  (if
   (i32.eqz
    (global.get $ready72)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global72)
   )
  )
  (if (result (ref $type18))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready162)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (if
     (i32.eqz
      (global.get $ready164)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global164)
     )
    )
    (array.new_fixed $type18 0)
   )
   (else
    (struct.set $type58 1
     (local.tee $2
      (struct.new_default $type58)
     )
     (struct.new $type28
      (ref.func $function60)
      (struct.new $environment60
       (local.get $0)
       (local.get $1)
       (local.tee $3
        (struct.new $type74
         (array.new $type18
          (call_ref $call35
           (struct.get $type35 1
            (local.get $1)
           )
           (i64.const 0)
           (struct.get $type35 0
            (local.get $1)
           )
          )
          (block (result i32)
           (if
            (i64.gt_u
             (local.get $0)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $0)
           )
          )
         )
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type58 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type58 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call28
      (struct.get $type28 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type58 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1)
      (struct.get $type28 0
       (local.get $4)
      )
     )
    )
    (struct.get $type74 0
     (local.get $3)
    )
   )
  )
 )

;; optimized source line 4043
(func $function74 (type $call87) (param $0 (ref $environment74)) (param $1 i64) (param $2 i64) (param $3 (ref null $type13)) (param $4 (ref null $type16)) (param $5 (ref null $type24)) (result (ref null $type24))
  (local $6 (ref $type80))
  (local $7 (ref $environment71))
  (local $8 (ref $type25))
  (local $9 (ref $type16))
  (local $10 i32)
  (if (result (ref null $type24))
   (if (result i32)
    (local.tee $10
     (i64.eq
      (struct.get $type69 1
       (struct.get $environment74 1
        (local.get $0)
       )
      )
      (local.get $1)
     )
    )
    (then
     (local.get $10)
    )
    (else
     (i64.eq
      (local.get $2)
      (i64.const 2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready235)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global235)
     )
    )
    (struct.set $type80 1
     (local.tee $6
      (struct.new_default $type80)
     )
     (struct.new $type25
      (ref.func $function80)
      (struct.new $environment80
       (struct.get $type69 1
        (struct.get $environment74 1
         (local.get $0)
        )
       )
       (struct.new $type25
        (ref.func $function75)
        (struct.new $environment75
         (local.get $4)
        )
       )
       (local.get $6)
      )
     )
    )
    (struct.set $type80 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type80 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref null $type24))
     (if (result i32)
      (call_ref $call25
       (struct.get $type25 1
        (local.tee $8
         (ref.as_non_null
          (struct.get $type80 1
           (local.get $6)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type25 0
        (local.get $8)
       )
      )
      (then
       (local.set $7
        (struct.get $type8 0
         (struct.get $type82 0
          (struct.get $environment74 3
           (local.get $0)
          )
         )
        )
       )
       (call $function37
        (struct.get $type46 0
         (struct.get $type79 0
          (struct.get $environment71 2
           (local.get $7)
          )
         )
        )
        (struct.get $type69 1
         (struct.get $environment71 0
          (local.get $7)
         )
        )
        (struct.get $type74 0
         (struct.get $environment71 1
          (local.get $7)
         )
        )
        (struct.get $type81 0
         (struct.get $environment71 3
          (local.get $7)
         )
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.tee $1
         (struct.get $type69 1
          (struct.get $environment74 1
           (local.get $0)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (struct.get $type55 0
        (struct.get $environment74 2
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $3)
      )
      (if
       (i32.eqz
        (global.get $ready75)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global75)
       )
      )
      (drop
       (call $function30
        (struct.get $environment74 0
         (local.get $0)
        )
        (struct.new $type33
         (ref.func $function81)
         (struct.new $environment81
          (struct.get $environment74 2
           (local.get $0)
          )
         )
        )
       )
      )
      (struct.new $type24
       (local.get $5)
      )
     )
     (else
      (local.get $5)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type63 0
       (struct.get $environment74 5
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $type63 1
      (struct.get $environment74 5
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (struct.new $type16
      (array.get $type18
       (struct.get $type74 0
        (struct.get $environment74 4
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (struct.get $type88 0
       (struct.get $environment74 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call $function74
      (struct.get $type87 0
       (struct.get $type88 1
        (struct.get $environment74 6
         (local.get $0)
        )
       )
      )
      (i64.add
       (local.get $1)
       (i64.const 1)
      )
      (i64.add
       (local.get $2)
       (i64.const 1)
      )
      (struct.new $type13
       (local.get $1)
       (local.get $3)
      )
      (local.get $9)
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (struct.get $type63 0
       (struct.get $environment74 5
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $type63 1
      (struct.get $environment74 5
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type88 0
       (struct.get $environment74 6
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function74
     (struct.get $type87 0
      (struct.get $type88 1
       (struct.get $environment74 6
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )

;; optimized source line 6423
(func $function84 (type $call29) (param $0 (ref null $environment84)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref null $type24))
  (local $4 (ref $environment87))
  (local $5 (ref $type74))
  (local $6 (ref $type84))
  (local $7 (ref $type93))
  (local $8 (ref $type69))
  (local $9 (ref $type33))
  (local $10 (ref $type55))
  (local $11 (ref $type79))
  (local $12 i32)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment84 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready255)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready261)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type29 1
      (global.get $global261)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global255)
     )
    )
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global188)
     )
    )
    (if
     (i32.eqz
      (global.get $ready190)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (if
     (i32.eqz
      (global.get $ready159)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global159)
     )
    )
    (local.set $5
     (struct.new $type74
      (call $function54
       (local.get $2)
       (struct.new $type35
        (ref.func $function68)
        (struct.new $environment68
         (local.get $2)
        )
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready64)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global64)
     )
    )
    (struct.set $type84 1
     (local.tee $6
      (struct.new_default $type84)
     )
     (struct.new $type83
      (struct.new $environment73
       (local.get $2)
       (local.tee $8
        (struct.new $type69
         (i32.const 1)
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
       )
       (local.get $5)
       (struct.new $type55
        (array.new_default $type14
         (local.tee $12
          (i32.wrap_i64
           (local.get $2)
          )
         )
        )
       )
       (struct.new $type56
        (array.new_default $type48
         (local.get $12)
        )
       )
       (block (result (ref (exact $type80)))
        (if
         (i32.eqz
          (global.get $ready67)
         )
         (then
          (unreachable)
         )
        )
        (local.set $9
         (ref.as_non_null
          (global.get $global67)
         )
        )
        (if
         (i32.eqz
          (global.get $ready75)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global75)
         )
        )
        (local.set $10
         (struct.new $type55
          (call $function30
           (i64.add
            (local.tee $2
             (struct.get $type69 1
              (local.get $8)
             )
            )
            (i64.const 1)
           )
           (local.get $9)
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $2)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type80
         (i32.const 1)
         (struct.new $type25
          (ref.func $function69)
          (struct.new $environment69
           (local.get $5)
           (local.tee $11
            (struct.new $type79
             (struct.new $type46
              (struct.new $environment37
               (local.get $10)
               (struct.new $type56
                (array.new_default $type48
                 (i32.wrap_i64
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
           )
           (struct.new $type81
            (struct.new $type47
             (ref.func $function70)
             (ref.null none)
            )
           )
          )
         )
        )
       )
       (struct.new $type82
        (struct.new $type8
         (struct.new $environment71
          (local.get $8)
          (local.get $5)
          (local.get $11)
          (struct.new $type81
           (struct.new $type47
            (ref.func $function72)
            (struct.new $environment72
             (local.get $8)
             (local.get $5)
            )
           )
          )
         )
        )
       )
       (local.get $6)
      )
     )
    )
    (struct.set $type84 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type84 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call $function73
      (struct.get $type83 0
       (struct.get $type84 1
        (local.get $6)
       )
      )
      (i64.const 0)
      (ref.null none)
     )
    )
    (if
     (i32.eqz
      (global.get $ready264)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global264)
     )
    )
    (struct.set $type93 1
     (local.tee $7
      (struct.new_default $type93)
     )
     (struct.new $type92
      (struct.new $environment87
       (local.get $7)
      )
     )
    )
    (struct.set $type93 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type93 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type92 0
      (struct.get $type93 1
       (local.get $7)
      )
     )
    )
    (local.set $2
     (if (result i64)
      (ref.is_null
       (local.get $3)
      )
      (then
       (i64.const 0)
      )
      (else
       (local.set $3
        (struct.get $type24 0
         (local.get $3)
        )
       )
       (if
        (i32.eqz
         (struct.get $type93 0
          (struct.get $environment87 0
           (local.get $4)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type92 0
         (struct.get $type93 1
          (struct.get $environment87 0
           (local.get $4)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $3)
        )
        (then
         (i64.const 1)
        )
        (else
         (local.set $3
          (struct.get $type24 0
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type93 0
            (struct.get $environment87 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type92 0
           (struct.get $type93 1
            (struct.get $environment87 0
             (local.get $4)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (i64.const 2)
          )
          (else
           (local.set $3
            (struct.get $type24 0
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (struct.get $type93 0
              (struct.get $environment87 0
               (local.get $4)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $4
            (struct.get $type92 0
             (struct.get $type93 1
              (struct.get $environment87 0
               (local.get $4)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $3)
            )
            (then
             (i64.const 3)
            )
            (else
             (local.set $3
              (struct.get $type24 0
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (struct.get $type93 0
                (struct.get $environment87 0
                 (local.get $4)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $4
              (struct.get $type92 0
               (struct.get $type93 1
                (struct.get $environment87 0
                 (local.get $4)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $3)
              )
              (then
               (i64.const 4)
              )
              (else
               (local.set $3
                (struct.get $type24 0
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type93 0
                  (struct.get $environment87 0
                   (local.get $4)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $4
                (struct.get $type92 0
                 (struct.get $type93 1
                  (struct.get $environment87 0
                   (local.get $4)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (i64.const 5)
                )
                (else
                 (local.set $3
                  (struct.get $type24 0
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type93 0
                    (struct.get $environment87 0
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $4
                  (struct.get $type92 0
                   (struct.get $type93 1
                    (struct.get $environment87 0
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (local.set $3
                    (struct.get $type24 0
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type93 0
                      (struct.get $environment87 0
                       (local.get $4)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $4
                    (struct.get $type92 0
                     (struct.get $type93 1
                      (struct.get $environment87 0
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (local.set $3
                      (struct.get $type24 0
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type93 0
                        (struct.get $environment87 0
                         (local.get $4)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $4
                      (struct.get $type92 0
                       (struct.get $type93 1
                        (struct.get $environment87 0
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (local.set $3
                        (struct.get $type24 0
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type93 0
                          (struct.get $environment87 0
                           (local.get $4)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $4
                        (struct.get $type92 0
                         (struct.get $type93 1
                          (struct.get $environment87 0
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (local.set $3
                          (struct.get $type24 0
                           (local.get $3)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type93 0
                            (struct.get $environment87 0
                             (local.get $4)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $4
                          (struct.get $type92 0
                           (struct.get $type93 1
                            (struct.get $environment87 0
                             (local.get $4)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (local.set $3
                            (struct.get $type24 0
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type93 0
                              (struct.get $environment87 0
                               (local.get $4)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $4
                            (struct.get $type92 0
                             (struct.get $type93 1
                              (struct.get $environment87 0
                               (local.get $4)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (local.set $3
                              (struct.get $type24 0
                               (local.get $3)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type93 0
                                (struct.get $environment87 0
                                 (local.get $4)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $4
                              (struct.get $type92 0
                               (struct.get $type93 1
                                (struct.get $environment87 0
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (local.set $3
                                (struct.get $type24 0
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type93 0
                                  (struct.get $environment87 0
                                   (local.get $4)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $4
                                (struct.get $type92 0
                                 (struct.get $type93 1
                                  (struct.get $environment87 0
                                   (local.get $4)
                                  )
                                 )
                                )
                               )
                               (if (result i64)
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (i64.const 13)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type24 0
                                   (local.get $3)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type93 0
                                    (struct.get $environment87 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function87
                                  (struct.get $type92 0
                                   (struct.get $type93 1
                                    (struct.get $environment87 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (local.get $3)
                                  (i64.const 14)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type91 0
       (struct.get $environment84 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (struct.get $type29 1
      (struct.get $type91 1
       (struct.get $environment84 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )

;; optimized source line 7301
(func $function87 (type $call92) (param $0 (ref $environment87)) (param $1 (ref null $type24)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type24 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type93 0
       (struct.get $environment87 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (struct.get $type92 0
      (struct.get $type93 1
       (struct.get $environment87 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
