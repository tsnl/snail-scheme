(module
 (rec
  (type $type25 (struct (field (ref $environment45))))
  (type $type30 (struct (field (mut (ref $type12)))))
  (type $type24 (struct (field (ref $type12)) (field (ref $type25))))
  (type $call31 (func (param i64) (result i64)))
  (type $environment45 (struct (field i64) (field i64) (field i64) (field (ref $type36)) (field (ref $type37)) (field (ref $type37))))
  (type $call25 (func (param (ref $environment45)) (result (ref $type12))))
  (type $6 (func (param (ref $type37) (ref null $type14) i64 (ref $type14)) (result (ref null $type14))))
  (type $7 (func (param (ref $type37) (ref null $type14) i64) (result (ref null $type14))))
  (type $call34 (func (param (ref $environment39) (ref null $type14) i64) (result i64)))
  (type $environment41 (struct (field (ref $type42)) (field (ref $type44)) (field (ref $type37)) (field i64) (field (ref $type39)) (field (ref $type37)) (field (ref $type37)) (field (ref $type37))))
  (type $type29 (struct (field (mut (ref null $type13)))))
  (type $type34 (struct (field (ref $environment39))))
  (type $type43 (struct (field (mut (ref null $type14)))))
  (type $type37 (struct (field i32)))
  (type $type42 (struct (field i32) (field (ref $type43))))
  (type $type44 (struct (field i32) (field (ref $type29))))
  (type $type35 (struct (field (mut i32)) (field (mut (ref null $type34)))))
  (type $environment39 (struct (field (ref $type35))))
  (type $call20 (func (param (ref null $type14)) (result (ref null $type13))))
  (type $call40 (func (param (ref $environment35) i64 (ref $type14)) (result (ref null $type14))))
  (type $type40 (struct (field (ref $environment35))))
  (type $type41 (struct (field (mut i32)) (field (mut (ref null $type40)))))
  (type $type14 (struct (field i64) (field (ref null $type14))))
  (type $environment35 (struct (field (ref $type41))))
  (type $24 (func (param i64 (ref $type36) (ref $type37) i64 i64) (result i32)))
  (type $type38 (struct (field (ref $call38)) (field (ref struct))))
  (type $type39 (struct (field (mut i32)) (field (mut (ref null $type38)))))
  (type $type36 (struct (field i32) (field (ref $type12))))
  (type $type13 (struct (field (ref null $type14)) (field (ref null $type13))))
  (type $type12 (array (mut (ref null $type13))))
  (type $environment32 (struct (field i64) (field i64) (field (ref $type36)) (field (ref $type39))))
  (type $call38 (func (param (ref struct) i64) (result i32)))
  (type $type31 (struct))
  (type $type28 (struct (field (ref $type29)) (field (ref $type29)) (field (ref $type30)) (field (ref $type30))))
  (type $type27 (struct))
  (type $type22 (struct))
  (type $type20 (struct))
  (type $type16 (struct))
  (type $type15 (struct))
  (type $type11 (struct))
 )
 (type $40 (func (param i64) (result i64)))
 (type $41 (func))
 (type $42 (func (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type11)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type15)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global92 (mut (ref null $type16)) (ref.null none))
 (global $ready92 (mut i32) (i32.const 0))
 (global $global77 (mut (ref null $type16)) (ref.null none))
 (global $ready77 (mut i32) (i32.const 0))
 (global $global94 (mut (ref null $type20)) (ref.null none))
 (global $ready94 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type22)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global72 (mut (ref null $type27)) (ref.null none))
 (global $ready72 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type28)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global131 (mut (ref null $type31)) (ref.null none))
 (global $ready131 (mut i32) (i32.const 0))
 (export "sharing-prepare" (func $export0))
 (export "main" (func $main))
 (export "sharing-check" (func $diagnostic-sharing))
 (func $function32 (type $call38) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment32))
  (local $3 (ref null $type13))
  (local $4 i64)
  (local.set $2
   (ref.cast (ref $environment32)
    (local.get $0)
   )
  )
  (if (result i32)
   (i64.lt_s
    (local.get $1)
    (i64.const 4)
   )
   (then
    (local.set $3
     (if (result (ref null $type13))
      (i64.lt_s
       (local.tee $4
        (i64.add
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 4)
      )
      (then
       (if
        (i64.gt_u
         (local.get $4)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type12
        (struct.get $type36 1
         (struct.get $environment32 2
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (else
       (ref.null none)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type36 1
      (struct.get $environment32 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment32 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function32
     (struct.get $type38 1
      (struct.get $type39 1
       (struct.get $environment32 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function33 (type $24) (param $0 i64) (param $1 (ref $type36)) (param $2 (ref $type37)) (param $3 i64) (param $4 i64) (result i32)
  (local $5 (ref $environment35))
  (local $6 (ref $type14))
  (local $7 (ref $type41))
  (local $8 (ref null $type14))
  (local $9 (ref null $type13))
  (local $10 i64)
  (local $11 i64)
  (local $scratch (ref null $type14))
  (if (result i32)
   (i64.lt_s
    (local.get $3)
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global87)
     )
    )
    (struct.set $type41 1
     (local.tee $7
      (struct.new_default $type41)
     )
     (struct.new $type40
      (struct.new $environment35
       (local.get $7)
      )
     )
    )
    (struct.set $type41 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type40 0
      (struct.get $type41 1
       (local.get $7)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (local.set $9
     (call $function37
      (block (result (ref null $type14))
       (local.set $scratch
        (if (result (ref null $type14))
         (i64.eqz
          (local.get $0)
         )
         (then
          (ref.null none)
         )
         (else
          (if
           (i32.eqz
            (struct.get $type41 0
             (struct.get $environment35 0
              (local.get $5)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $5
           (struct.get $type40 0
            (struct.get $type41 1
             (struct.get $environment35 0
              (local.get $5)
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready92)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global92)
           )
          )
          (local.set $6
           (struct.new $type14
            (local.get $0)
            (ref.null none)
           )
          )
          (if (result (ref null $type14))
           (i64.eqz
            (local.tee $10
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $6)
           )
           (else
            (if
             (i32.eqz
              (struct.get $type41 0
               (struct.get $environment35 0
                (local.get $5)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $5
             (struct.get $type40 0
              (struct.get $type41 1
               (struct.get $environment35 0
                (local.get $5)
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready92)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global92)
             )
            )
            (local.set $6
             (struct.new $type14
              (local.get $10)
              (local.get $6)
             )
            )
            (if (result (ref null $type14))
             (i64.eqz
              (local.tee $10
               (i64.sub
                (local.get $10)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $6)
             )
             (else
              (if
               (i32.eqz
                (struct.get $type41 0
                 (struct.get $environment35 0
                  (local.get $5)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $5
               (struct.get $type40 0
                (struct.get $type41 1
                 (struct.get $environment35 0
                  (local.get $5)
                 )
                )
               )
              )
              (if
               (i32.eqz
                (global.get $ready92)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global92)
               )
              )
              (local.set $6
               (struct.new $type14
                (local.get $10)
                (local.get $6)
               )
              )
              (if (result (ref null $type14))
               (i64.eqz
                (local.tee $10
                 (i64.sub
                  (local.get $10)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $6)
               )
               (else
                (if
                 (i32.eqz
                  (struct.get $type41 0
                   (struct.get $environment35 0
                    (local.get $5)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $5
                 (struct.get $type40 0
                  (struct.get $type41 1
                   (struct.get $environment35 0
                    (local.get $5)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready92)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global92)
                 )
                )
                (local.set $6
                 (struct.new $type14
                  (local.get $10)
                  (local.get $6)
                 )
                )
                (if (result (ref null $type14))
                 (i64.eqz
                  (local.tee $10
                   (i64.sub
                    (local.get $10)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $6)
                 )
                 (else
                  (if
                   (i32.eqz
                    (struct.get $type41 0
                     (struct.get $environment35 0
                      (local.get $5)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $5
                   (struct.get $type40 0
                    (struct.get $type41 1
                     (struct.get $environment35 0
                      (local.get $5)
                     )
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready92)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global92)
                   )
                  )
                  (local.set $6
                   (struct.new $type14
                    (local.get $10)
                    (local.get $6)
                   )
                  )
                  (if (result (ref null $type14))
                   (i64.eqz
                    (local.tee $10
                     (i64.sub
                      (local.get $10)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $6)
                   )
                   (else
                    (if
                     (i32.eqz
                      (struct.get $type41 0
                       (struct.get $environment35 0
                        (local.get $5)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $5
                     (struct.get $type40 0
                      (struct.get $type41 1
                       (struct.get $environment35 0
                        (local.get $5)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready92)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global92)
                     )
                    )
                    (local.set $6
                     (struct.new $type14
                      (local.get $10)
                      (local.get $6)
                     )
                    )
                    (if (result (ref null $type14))
                     (i64.eqz
                      (local.tee $10
                       (i64.sub
                        (local.get $10)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $6)
                     )
                     (else
                      (if
                       (i32.eqz
                        (struct.get $type41 0
                         (struct.get $environment35 0
                          (local.get $5)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $5
                       (struct.get $type40 0
                        (struct.get $type41 1
                         (struct.get $environment35 0
                          (local.get $5)
                         )
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready92)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global92)
                       )
                      )
                      (local.set $6
                       (struct.new $type14
                        (local.get $10)
                        (local.get $6)
                       )
                      )
                      (if (result (ref null $type14))
                       (i64.eqz
                        (local.tee $11
                         (i64.sub
                          (local.get $10)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (local.get $6)
                       )
                       (else
                        (if
                         (i32.eqz
                          (struct.get $type41 0
                           (struct.get $environment35 0
                            (local.get $5)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $5
                         (struct.get $type40 0
                          (struct.get $type41 1
                           (struct.get $environment35 0
                            (local.get $5)
                           )
                          )
                         )
                        )
                        (local.set $10
                         (i64.sub
                          (local.get $11)
                          (i64.const 1)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready92)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global92)
                         )
                        )
                        (local.set $6
                         (struct.new $type14
                          (local.get $11)
                          (local.get $6)
                         )
                        )
                        (if (result (ref null $type14))
                         (i64.eqz
                          (local.get $10)
                         )
                         (then
                          (local.get $6)
                         )
                         (else
                          (if
                           (i32.eqz
                            (struct.get $type41 0
                             (struct.get $environment35 0
                              (local.get $5)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $function35
                           (struct.get $type40 0
                            (struct.get $type41 1
                             (struct.get $environment35 0
                              (local.get $5)
                             )
                            )
                           )
                           (i64.sub
                            (local.get $10)
                            (i64.const 1)
                           )
                           (struct.new $type14
                            (local.get $10)
                            (local.get $6)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready94)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global94)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type36 1
      (local.get $1)
     )
     (i32.wrap_i64
      (local.get $3)
     )
     (local.get $9)
    )
    (return_call $function33
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function35 (type $call40) (param $0 (ref $environment35)) (param $1 i64) (param $2 (ref $type14)) (result (ref null $type14))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type41 0
       (struct.get $environment35 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function35
     (struct.get $type40 0
      (struct.get $type41 1
       (struct.get $environment35 0
        (local.get $0)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type14
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function37 (type $call20) (param $0 (ref null $type14)) (result (ref null $type13))
  (local $1 (ref $environment39))
  (local $2 (ref $type35))
  (local $3 (ref $type39))
  (local $4 (ref null $type14))
  (local $5 (ref $type44))
  (local $6 (ref $type42))
  (local $7 (ref $type37))
  (local $8 (ref $type37))
  (local $9 (ref $type37))
  (local $10 (ref $type38))
  (local $11 i64)
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type43 0
    (struct.get $type42 1
     (local.tee $6
      (struct.new $type42
       (i32.const 1)
       (struct.new $type43
        (local.get $0)
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (struct.set $type35 1
   (local.tee $2
    (struct.new_default $type35)
   )
   (struct.new $type34
    (struct.new $environment39
     (local.get $2)
    )
   )
  )
  (struct.set $type35 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type34 0
    (struct.get $type35 1
     (local.get $2)
    )
   )
  )
  (local.set $7
   (struct.new $type37
    (i32.const 1)
   )
  )
  (local.set $5
   (struct.new $type44
    (i32.const 1)
    (struct.new $type29
     (struct.new $type13
      (local.get $0)
      (ref.null none)
     )
    )
   )
  )
  (local.set $8
   (struct.new $type37
    (i32.const 1)
   )
  )
  (local.set $9
   (struct.new $type37
    (i32.const 1)
   )
  )
  (drop
   (if (result i32)
    (i64.gt_s
     (local.tee $11
      (if (result i64)
       (ref.is_null
        (local.get $4)
       )
       (then
        (i64.const 0)
       )
       (else
        (local.set $0
         (struct.get $type14 1
          (local.get $4)
         )
        )
        (if
         (i32.eqz
          (struct.get $type35 0
           (struct.get $environment39 0
            (local.get $1)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type34 0
          (struct.get $type35 1
           (struct.get $environment39 0
            (local.get $1)
           )
          )
         )
        )
        (if (result i64)
         (ref.is_null
          (local.get $0)
         )
         (then
          (i64.const 1)
         )
         (else
          (local.set $0
           (struct.get $type14 1
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (struct.get $type35 0
             (struct.get $environment39 0
              (local.get $1)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (struct.get $type34 0
            (struct.get $type35 1
             (struct.get $environment39 0
              (local.get $1)
             )
            )
           )
          )
          (if (result i64)
           (ref.is_null
            (local.get $0)
           )
           (then
            (i64.const 2)
           )
           (else
            (local.set $0
             (struct.get $type14 1
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (struct.get $type35 0
               (struct.get $environment39 0
                (local.get $1)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $1
             (struct.get $type34 0
              (struct.get $type35 1
               (struct.get $environment39 0
                (local.get $1)
               )
              )
             )
            )
            (if (result i64)
             (ref.is_null
              (local.get $0)
             )
             (then
              (i64.const 3)
             )
             (else
              (local.set $0
               (struct.get $type14 1
                (local.get $0)
               )
              )
              (if
               (i32.eqz
                (struct.get $type35 0
                 (struct.get $environment39 0
                  (local.get $1)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $1
               (struct.get $type34 0
                (struct.get $type35 1
                 (struct.get $environment39 0
                  (local.get $1)
                 )
                )
               )
              )
              (if (result i64)
               (ref.is_null
                (local.get $0)
               )
               (then
                (i64.const 4)
               )
               (else
                (local.set $0
                 (struct.get $type14 1
                  (local.get $0)
                 )
                )
                (if
                 (i32.eqz
                  (struct.get $type35 0
                   (struct.get $environment39 0
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $1
                 (struct.get $type34 0
                  (struct.get $type35 1
                   (struct.get $environment39 0
                    (local.get $1)
                   )
                  )
                 )
                )
                (if (result i64)
                 (ref.is_null
                  (local.get $0)
                 )
                 (then
                  (i64.const 5)
                 )
                 (else
                  (local.set $0
                   (struct.get $type14 1
                    (local.get $0)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type35 0
                     (struct.get $environment39 0
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $1
                   (struct.get $type34 0
                    (struct.get $type35 1
                     (struct.get $environment39 0
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if (result i64)
                   (ref.is_null
                    (local.get $0)
                   )
                   (then
                    (i64.const 6)
                   )
                   (else
                    (local.set $0
                     (struct.get $type14 1
                      (local.get $0)
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type35 0
                       (struct.get $environment39 0
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $1
                     (struct.get $type34 0
                      (struct.get $type35 1
                       (struct.get $environment39 0
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (if (result i64)
                     (ref.is_null
                      (local.get $0)
                     )
                     (then
                      (i64.const 7)
                     )
                     (else
                      (local.set $0
                       (struct.get $type14 1
                        (local.get $0)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type35 0
                         (struct.get $environment39 0
                          (local.get $1)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $1
                       (struct.get $type34 0
                        (struct.get $type35 1
                         (struct.get $environment39 0
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (if (result i64)
                       (ref.is_null
                        (local.get $0)
                       )
                       (then
                        (i64.const 8)
                       )
                       (else
                        (local.set $0
                         (struct.get $type14 1
                          (local.get $0)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type35 0
                           (struct.get $environment39 0
                            (local.get $1)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $function39
                         (struct.get $type34 0
                          (struct.get $type35 1
                           (struct.get $environment39 0
                            (local.get $1)
                           )
                          )
                         )
                         (local.get $0)
                         (i64.const 9)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (i64.const 1)
    )
    (then
     (struct.set $type39 1
      (local.tee $3
       (struct.new_default $type39)
      )
      (struct.new $type38
       (ref.func $function41)
       (struct.new $environment41
        (local.get $6)
        (local.get $5)
        (local.get $7)
        (local.get $11)
        (local.get $3)
        (local.get $8)
        (struct.new $type37
         (i32.const 1)
        )
        (local.get $9)
       )
      )
     )
     (struct.set $type39 0
      (local.get $3)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type39 0
        (local.get $3)
       )
      )
      (then
       (unreachable)
      )
     )
     (call_ref $call38
      (struct.get $type38 1
       (local.tee $10
        (ref.as_non_null
         (struct.get $type39 1
          (local.get $3)
         )
        )
       )
      )
      (i64.sub
       (local.get $11)
       (i64.const 1)
      )
      (struct.get $type38 0
       (local.get $10)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (struct.get $type29 0
   (struct.get $type44 1
    (local.get $5)
   )
  )
 )
 (func $function39 (type $call34) (param $0 (ref $environment39)) (param $1 (ref null $type14)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type14 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment39 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function39
     (struct.get $type34 0
      (struct.get $type35 1
       (struct.get $environment39 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function41 (type $call38) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref null $type14))
  (local $3 (ref null $type14))
  (local $4 (ref null $type14))
  (local $5 (ref $type14))
  (local $6 (ref $environment41))
  (local $7 (ref $type39))
  (local $8 (ref $type37))
  (local $9 (ref $type38))
  (local $10 (ref $type42))
  (local $11 (ref $type44))
  (local $12 (ref $type29))
  (local $13 i64)
  (local $14 i64)
  (local $scratch (ref $type44))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $1)
   )
   (then
    (if (result i32)
     (i64.gt_s
      (local.tee $1
       (i64.sub
        (struct.get $environment41 3
         (local.tee $6
          (ref.cast (ref $environment41)
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 1)
     )
     (then
      (struct.set $type39 1
       (local.tee $7
        (struct.new_default $type39)
       )
       (struct.new $type38
        (ref.func $function41)
        (struct.new $environment41
         (struct.get $environment41 0
          (local.get $6)
         )
         (struct.get $environment41 1
          (local.get $6)
         )
         (struct.get $environment41 2
          (local.get $6)
         )
         (local.get $1)
         (local.get $7)
         (struct.get $environment41 5
          (local.get $6)
         )
         (struct.get $environment41 6
          (local.get $6)
         )
         (struct.get $environment41 7
          (local.get $6)
         )
        )
       )
      )
      (struct.set $type39 0
       (local.get $7)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type39 0
         (local.get $7)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call38
       (struct.get $type38 1
        (local.tee $9
         (ref.as_non_null
          (struct.get $type39 1
           (local.get $7)
          )
         )
        )
       )
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
       (struct.get $type38 0
        (local.get $9)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (drop
     (if (result i32)
      (i64.gt_s
       (local.tee $13
        (i64.sub
         (struct.get $environment41 3
          (local.tee $6
           (ref.cast (ref $environment41)
            (local.get $0)
           )
          )
         )
         (block (result i64)
          (local.set $8
           (struct.get $environment41 5
            (local.get $6)
           )
          )
          (i64.const 1)
         )
        )
       )
       (i64.const 1)
      )
      (then
       (struct.set $type39 1
        (local.tee $7
         (struct.new_default $type39)
        )
        (struct.new $type38
         (ref.func $function41)
         (struct.new $environment41
          (struct.get $environment41 0
           (local.get $6)
          )
          (struct.get $environment41 1
           (local.get $6)
          )
          (struct.get $environment41 2
           (local.get $6)
          )
          (local.get $13)
          (local.get $7)
          (local.get $8)
          (struct.get $environment41 6
           (local.get $6)
          )
          (struct.get $environment41 7
           (local.get $6)
          )
         )
        )
       )
       (struct.set $type39 0
        (local.get $7)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type39 0
          (local.get $7)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call38
        (struct.get $type38 1
         (local.tee $9
          (ref.as_non_null
           (struct.get $type39 1
            (local.get $7)
           )
          )
         )
        )
        (i64.sub
         (local.get $13)
         (i64.const 1)
        )
        (struct.get $type38 0
         (local.get $9)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.set $2
     (struct.get $type43 0
      (struct.get $type42 1
       (local.tee $10
        (struct.get $environment41 0
         (local.get $6)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type43 0
      (struct.get $type42 1
       (local.get $10)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (if
     (i64.ne
      (local.tee $13
       (struct.get $environment41 3
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (local.set $2
       (struct.get $type14 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready92)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (struct.get $environment41 6
        (local.get $6)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global92)
       )
      )
      (local.set $2
       (if (result (ref null $type14))
        (i64.eqz
         (local.tee $14
          (i64.sub
           (local.get $13)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $2)
        )
        (else
         (local.set $2
          (struct.get $type14 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready92)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global92)
          )
         )
         (if (result (ref null $type14))
          (i64.eqz
           (local.tee $14
            (i64.sub
             (local.get $14)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $2
            (struct.get $type14 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (if (result (ref null $type14))
            (i64.eqz
             (local.tee $14
              (i64.sub
               (local.get $14)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $2)
            )
            (else
             (local.set $2
              (struct.get $type14 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (if (result (ref null $type14))
              (i64.eqz
               (local.tee $14
                (i64.sub
                 (local.get $14)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $2)
              )
              (else
               (local.set $2
                (struct.get $type14 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (if (result (ref null $type14))
                (i64.eqz
                 (local.tee $14
                  (i64.sub
                   (local.get $14)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $2)
                )
                (else
                 (local.set $2
                  (struct.get $type14 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (if (result (ref null $type14))
                  (i64.eqz
                   (local.tee $14
                    (i64.sub
                     (local.get $14)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (local.set $2
                    (struct.get $type14 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (if (result (ref null $type14))
                    (i64.eqz
                     (local.tee $14
                      (i64.sub
                       (local.get $14)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (local.set $2
                      (struct.get $type14 1
                       (local.get $2)
                      )
                     )
                     (local.set $14
                      (i64.sub
                       (local.get $14)
                       (i64.const 1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (if (result (ref null $type14))
                      (i64.eqz
                       (local.get $14)
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (call $function43
                        (local.get $8)
                        (struct.get $type14 1
                         (local.get $2)
                        )
                        (i64.sub
                         (local.get $14)
                         (i64.const 1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $environment41 7
      (local.get $6)
     )
    )
    (struct.set $type29 0
     (local.tee $12
      (struct.get $type44 1
       (block (result (ref $type44))
        (local.set $scratch
         (struct.get $environment41 1
          (local.get $6)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global92)
         )
        )
        (struct.set $type43 0
         (struct.get $type42 1
          (local.get $10)
         )
         (if (result (ref null $type14))
          (i64.eqz
           (local.get $13)
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $4
            (struct.get $type14 1
             (local.get $3)
            )
           )
           (local.set $5
            (struct.new $type14
             (struct.get $type14 0
              (local.get $3)
             )
             (block (result (ref null $type14))
              (if
               (i32.eqz
                (global.get $ready92)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global92)
               )
              )
              (local.get $2)
             )
            )
           )
           (if (result (ref null $type14))
            (i64.eqz
             (local.tee $13
              (i64.sub
               (local.get $13)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $2
              (struct.get $type14 1
               (local.get $4)
              )
             )
             (local.set $5
              (struct.new $type14
               (struct.get $type14 0
                (local.get $4)
               )
               (block (result (ref $type14))
                (if
                 (i32.eqz
                  (global.get $ready92)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global92)
                 )
                )
                (local.get $5)
               )
              )
             )
             (if (result (ref null $type14))
              (i64.eqz
               (local.tee $13
                (i64.sub
                 (local.get $13)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $3
                (struct.get $type14 1
                 (local.get $2)
                )
               )
               (local.set $5
                (struct.new $type14
                 (struct.get $type14 0
                  (local.get $2)
                 )
                 (block (result (ref $type14))
                  (if
                   (i32.eqz
                    (global.get $ready92)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global92)
                   )
                  )
                  (local.get $5)
                 )
                )
               )
               (if (result (ref null $type14))
                (i64.eqz
                 (local.tee $13
                  (i64.sub
                   (local.get $13)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $2
                  (struct.get $type14 1
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (local.set $5
                  (struct.new $type14
                   (struct.get $type14 0
                    (local.get $3)
                   )
                   (local.get $5)
                  )
                 )
                 (if (result (ref null $type14))
                  (i64.eqz
                   (local.tee $13
                    (i64.sub
                     (local.get $13)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type14 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (local.set $5
                    (struct.new $type14
                     (struct.get $type14 0
                      (local.get $2)
                     )
                     (local.get $5)
                    )
                   )
                   (if (result (ref null $type14))
                    (i64.eqz
                     (local.tee $13
                      (i64.sub
                       (local.get $13)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $2
                      (struct.get $type14 1
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (local.set $5
                      (struct.new $type14
                       (struct.get $type14 0
                        (local.get $3)
                       )
                       (local.get $5)
                      )
                     )
                     (if (result (ref null $type14))
                      (i64.eqz
                       (local.tee $13
                        (i64.sub
                         (local.get $13)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type14 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready92)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global92)
                        )
                       )
                       (local.set $5
                        (struct.new $type14
                         (struct.get $type14 0
                          (local.get $2)
                         )
                         (local.get $5)
                        )
                       )
                       (if (result (ref null $type14))
                        (i64.eqz
                         (local.tee $13
                          (i64.sub
                           (local.get $13)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $2
                          (struct.get $type14 1
                           (local.get $3)
                          )
                         )
                         (local.set $13
                          (i64.sub
                           (local.get $13)
                           (i64.const 1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready92)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global92)
                          )
                         )
                         (local.set $5
                          (struct.new $type14
                           (struct.get $type14 0
                            (local.get $3)
                           )
                           (local.get $5)
                          )
                         )
                         (if (result (ref null $type14))
                          (i64.eqz
                           (local.get $13)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (call $function44
                            (local.get $8)
                            (struct.get $type14 1
                             (local.get $2)
                            )
                            (i64.sub
                             (local.get $13)
                             (i64.const 1)
                            )
                            (struct.new $type14
                             (struct.get $type14 0
                              (local.get $2)
                             )
                             (local.get $5)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (local.get $scratch)
       )
      )
     )
     (struct.new $type13
      (struct.get $type43 0
       (struct.get $type42 1
        (local.get $10)
       )
      )
      (struct.get $type29 0
       (local.get $12)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment41 4
        (local.get $6)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function41
     (struct.get $type38 1
      (struct.get $type39 1
       (struct.get $environment41 4
        (local.get $6)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function43 (type $7) (param $0 (ref $type37)) (param $1 (ref null $type14)) (param $2 i64) (result (ref null $type14))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref null $type14))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function43
     (local.get $0)
     (struct.get $type14 1
      (local.get $1)
     )
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function44 (type $6) (param $0 (ref $type37)) (param $1 (ref null $type14)) (param $2 i64) (param $3 (ref $type14)) (result (ref null $type14))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (return_call $function44
     (local.get $0)
     (struct.get $type14 1
      (local.get $1)
     )
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
     (struct.new $type14
      (struct.get $type14 0
       (local.get $1)
      )
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function51 (type $call31) (param $0 i64) (result i64)
  (local $1 (ref $environment35))
  (local $2 (ref $type14))
  (local $3 (ref $type41))
  (local $4 (ref $type12))
  (local $5 (ref $type12))
  (local $6 (ref $type39))
  (local $7 (ref $type29))
  (local $8 (ref null $type14))
  (local $9 (ref $environment45))
  (local $10 (ref $type36))
  (local $11 (ref $type36))
  (local $12 (ref $type37))
  (local $13 (ref $type24))
  (local $14 (ref $type30))
  (local $15 (ref $type38))
  (local $16 i64)
  (local $17 i64)
  (local $scratch (ref null $type14))
  (local $scratch_19 (ref null $type14))
  (if (result i64)
   (i64.eq
    (local.get $0)
    (i64.const 3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type29 0
     (struct.get $type28 0
      (global.get $global130)
     )
     (block (result (ref null $type13))
      (if
       (i32.eqz
        (global.get $ready87)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global87)
       )
      )
      (struct.set $type41 1
       (local.tee $3
        (struct.new_default $type41)
       )
       (struct.new $type40
        (struct.new $environment35
         (local.get $3)
        )
       )
      )
      (struct.set $type41 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type41 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type40 0
        (struct.get $type41 1
         (local.get $3)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready92)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global92)
       )
      )
      (call $function37
       (block (result (ref null $type14))
        (local.set $scratch
         (if (result (ref null $type14))
          (i64.eqz
           (local.get $0)
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i32.eqz
             (struct.get $type41 0
              (struct.get $environment35 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type40 0
             (struct.get $type41 1
              (struct.get $environment35 0
               (local.get $1)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (local.set $2
            (struct.new $type14
             (local.get $0)
             (ref.null none)
            )
           )
           (if (result (ref null $type14))
            (i64.eqz
             (local.tee $16
              (i64.sub
               (local.get $0)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $2)
            )
            (else
             (if
              (i32.eqz
               (struct.get $type41 0
                (struct.get $environment35 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type40 0
               (struct.get $type41 1
                (struct.get $environment35 0
                 (local.get $1)
                )
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (local.set $2
              (struct.new $type14
               (local.get $16)
               (local.get $2)
              )
             )
             (if (result (ref null $type14))
              (i64.eqz
               (local.tee $16
                (i64.sub
                 (local.get $16)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $2)
              )
              (else
               (if
                (i32.eqz
                 (struct.get $type41 0
                  (struct.get $environment35 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type40 0
                 (struct.get $type41 1
                  (struct.get $environment35 0
                   (local.get $1)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (local.set $2
                (struct.new $type14
                 (local.get $16)
                 (local.get $2)
                )
               )
               (if (result (ref null $type14))
                (i64.eqz
                 (local.tee $16
                  (i64.sub
                   (local.get $16)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $2)
                )
                (else
                 (if
                  (i32.eqz
                   (struct.get $type41 0
                    (struct.get $environment35 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type40 0
                   (struct.get $type41 1
                    (struct.get $environment35 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (local.set $2
                  (struct.new $type14
                   (local.get $16)
                   (local.get $2)
                  )
                 )
                 (if (result (ref null $type14))
                  (i64.eqz
                   (local.tee $16
                    (i64.sub
                     (local.get $16)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (if
                    (i32.eqz
                     (struct.get $type41 0
                      (struct.get $environment35 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type40 0
                     (struct.get $type41 1
                      (struct.get $environment35 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (local.set $2
                    (struct.new $type14
                     (local.get $16)
                     (local.get $2)
                    )
                   )
                   (if (result (ref null $type14))
                    (i64.eqz
                     (local.tee $16
                      (i64.sub
                       (local.get $16)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (if
                      (i32.eqz
                       (struct.get $type41 0
                        (struct.get $environment35 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (struct.get $type40 0
                       (struct.get $type41 1
                        (struct.get $environment35 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (local.set $2
                      (struct.new $type14
                       (local.get $16)
                       (local.get $2)
                      )
                     )
                     (if (result (ref null $type14))
                      (i64.eqz
                       (local.tee $16
                        (i64.sub
                         (local.get $16)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (if
                        (i32.eqz
                         (struct.get $type41 0
                          (struct.get $environment35 0
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $1
                        (struct.get $type40 0
                         (struct.get $type41 1
                          (struct.get $environment35 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready92)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global92)
                        )
                       )
                       (local.set $2
                        (struct.new $type14
                         (local.get $16)
                         (local.get $2)
                        )
                       )
                       (if (result (ref null $type14))
                        (i64.eqz
                         (local.tee $17
                          (i64.sub
                           (local.get $16)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (local.get $2)
                        )
                        (else
                         (if
                          (i32.eqz
                           (struct.get $type41 0
                            (struct.get $environment35 0
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $1
                          (struct.get $type40 0
                           (struct.get $type41 1
                            (struct.get $environment35 0
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (local.set $16
                          (i64.sub
                           (local.get $17)
                           (i64.const 1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready92)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global92)
                          )
                         )
                         (local.set $2
                          (struct.new $type14
                           (local.get $17)
                           (local.get $2)
                          )
                         )
                         (if (result (ref null $type14))
                          (i64.eqz
                           (local.get $16)
                          )
                          (then
                           (local.get $2)
                          )
                          (else
                           (if
                            (i32.eqz
                             (struct.get $type41 0
                              (struct.get $environment35 0
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (call $function35
                            (struct.get $type40 0
                             (struct.get $type41 1
                              (struct.get $environment35 0
                               (local.get $1)
                              )
                             )
                            )
                            (i64.sub
                             (local.get $16)
                             (i64.const 1)
                            )
                            (struct.new $type14
                             (local.get $16)
                             (local.get $2)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready94)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global94)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type29 0
     (struct.get $type28 1
      (global.get $global130)
     )
     (block (result (ref null $type13))
      (if
       (i32.eqz
        (global.get $ready87)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global87)
       )
      )
      (struct.set $type41 1
       (local.tee $3
        (struct.new_default $type41)
       )
       (struct.new $type40
        (struct.new $environment35
         (local.get $3)
        )
       )
      )
      (struct.set $type41 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type41 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type40 0
        (struct.get $type41 1
         (local.get $3)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready92)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global92)
       )
      )
      (call $function37
       (block (result (ref null $type14))
        (local.set $scratch_19
         (if (result (ref null $type14))
          (i64.eqz
           (local.get $0)
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i32.eqz
             (struct.get $type41 0
              (struct.get $environment35 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type40 0
             (struct.get $type41 1
              (struct.get $environment35 0
               (local.get $1)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (local.set $2
            (struct.new $type14
             (local.get $0)
             (ref.null none)
            )
           )
           (if (result (ref null $type14))
            (i64.eqz
             (local.tee $16
              (i64.sub
               (local.get $0)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $2)
            )
            (else
             (if
              (i32.eqz
               (struct.get $type41 0
                (struct.get $environment35 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type40 0
               (struct.get $type41 1
                (struct.get $environment35 0
                 (local.get $1)
                )
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (local.set $2
              (struct.new $type14
               (local.get $16)
               (local.get $2)
              )
             )
             (if (result (ref null $type14))
              (i64.eqz
               (local.tee $16
                (i64.sub
                 (local.get $16)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $2)
              )
              (else
               (if
                (i32.eqz
                 (struct.get $type41 0
                  (struct.get $environment35 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type40 0
                 (struct.get $type41 1
                  (struct.get $environment35 0
                   (local.get $1)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (local.set $2
                (struct.new $type14
                 (local.get $16)
                 (local.get $2)
                )
               )
               (if (result (ref null $type14))
                (i64.eqz
                 (local.tee $16
                  (i64.sub
                   (local.get $16)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $2)
                )
                (else
                 (if
                  (i32.eqz
                   (struct.get $type41 0
                    (struct.get $environment35 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type40 0
                   (struct.get $type41 1
                    (struct.get $environment35 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (local.set $2
                  (struct.new $type14
                   (local.get $16)
                   (local.get $2)
                  )
                 )
                 (if (result (ref null $type14))
                  (i64.eqz
                   (local.tee $16
                    (i64.sub
                     (local.get $16)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (if
                    (i32.eqz
                     (struct.get $type41 0
                      (struct.get $environment35 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type40 0
                     (struct.get $type41 1
                      (struct.get $environment35 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (local.set $2
                    (struct.new $type14
                     (local.get $16)
                     (local.get $2)
                    )
                   )
                   (if (result (ref null $type14))
                    (i64.eqz
                     (local.tee $16
                      (i64.sub
                       (local.get $16)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (if
                      (i32.eqz
                       (struct.get $type41 0
                        (struct.get $environment35 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (struct.get $type40 0
                       (struct.get $type41 1
                        (struct.get $environment35 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (local.set $2
                      (struct.new $type14
                       (local.get $16)
                       (local.get $2)
                      )
                     )
                     (if (result (ref null $type14))
                      (i64.eqz
                       (local.tee $16
                        (i64.sub
                         (local.get $16)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (if
                        (i32.eqz
                         (struct.get $type41 0
                          (struct.get $environment35 0
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $1
                        (struct.get $type40 0
                         (struct.get $type41 1
                          (struct.get $environment35 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready92)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global92)
                        )
                       )
                       (local.set $2
                        (struct.new $type14
                         (local.get $16)
                         (local.get $2)
                        )
                       )
                       (if (result (ref null $type14))
                        (i64.eqz
                         (local.tee $17
                          (i64.sub
                           (local.get $16)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (local.get $2)
                        )
                        (else
                         (if
                          (i32.eqz
                           (struct.get $type41 0
                            (struct.get $environment35 0
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $1
                          (struct.get $type40 0
                           (struct.get $type41 1
                            (struct.get $environment35 0
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (local.set $16
                          (i64.sub
                           (local.get $17)
                           (i64.const 1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready92)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global92)
                          )
                         )
                         (local.set $2
                          (struct.new $type14
                           (local.get $17)
                           (local.get $2)
                          )
                         )
                         (if (result (ref null $type14))
                          (i64.eqz
                           (local.get $16)
                          )
                          (then
                           (local.get $2)
                          )
                          (else
                           (if
                            (i32.eqz
                             (struct.get $type41 0
                              (struct.get $environment35 0
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (call $function35
                            (struct.get $type40 0
                             (struct.get $type41 1
                              (struct.get $environment35 0
                               (local.get $1)
                              )
                             )
                            )
                            (i64.sub
                             (local.get $16)
                             (i64.const 1)
                            )
                            (struct.new $type14
                             (local.get $16)
                             (local.get $2)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready94)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global94)
         )
        )
        (local.get $scratch_19)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready72)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global72)
     )
    )
    (if
     (i32.eqz
      (global.get $ready77)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global77)
     )
    )
    (local.set $4
     (struct.get $type24 0
      (local.tee $13
       (if (result (ref $type24))
        (if (result i32)
         (i64.gt_s
          (local.get $0)
          (i64.const 0)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready77)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global77)
           )
          )
          (i32.const 1)
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (drop
          (call $function33
           (local.get $0)
           (local.tee $10
            (struct.new $type36
             (i32.const 1)
             (array.new_default $type12
              (i32.const 4)
             )
            )
           )
           (local.tee $12
            (struct.new $type37
             (i32.const 1)
            )
           )
           (i64.const 0)
           (i64.const 3)
          )
         )
         (struct.new $type24
          (struct.get $type36 1
           (local.get $10)
          )
          (struct.new $type25
           (struct.new $environment45
            (local.get $0)
            (i64.const 4)
            (i64.const 1)
            (local.get $10)
            (struct.new $type37
             (i32.const 1)
            )
            (local.get $12)
           )
          )
         )
        )
        (else
         (unreachable)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type30 0
     (struct.get $type28 2
      (global.get $global130)
     )
     (block (result (ref $type12))
      (if
       (i32.eqz
        (global.get $ready135)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global135)
       )
      )
      (if (result (ref $type12))
       (i64.eqz
        (local.tee $0
         (i64.extend_i32_u
          (array.len
           (local.get $4)
          )
         )
        )
       )
       (then
        (array.new_fixed $type12 0)
       )
       (else
        (if
         (i64.gt_u
          (local.get $0)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $5
         (array.new $type12
          (array.get $type12
           (local.get $4)
           (i32.const 0)
          )
          (i32.wrap_i64
           (local.get $0)
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $0)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.copy $type12 $type12
         (local.get $5)
         (i32.const 0)
         (local.get $4)
         (i32.const 0)
         (i32.wrap_i64
          (local.get $0)
         )
        )
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type30 0
     (struct.get $type28 3
      (global.get $global130)
     )
     (block (result (ref $type12))
      (drop
       (call $function33
        (struct.get $environment45 0
         (local.tee $9
          (struct.get $type25 0
           (struct.get $type24 1
            (local.get $13)
           )
          )
         )
        )
        (local.tee $11
         (struct.get $environment45 3
          (local.get $9)
         )
        )
        (struct.get $environment45 5
         (local.get $9)
        )
        (i64.const 3)
        (i64.const 4)
       )
      )
      (struct.set $type39 1
       (local.tee $6
        (struct.new_default $type39)
       )
       (struct.new $type38
        (ref.func $function32)
        (struct.new $environment32
         (i64.const 4)
         (i64.const 1)
         (local.get $11)
         (local.get $6)
        )
       )
      )
      (struct.set $type39 0
       (local.get $6)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type39 0
         (local.get $6)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call38
        (struct.get $type38 1
         (local.tee $15
          (ref.as_non_null
           (struct.get $type39 1
            (local.get $6)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type38 0
         (local.get $15)
        )
       )
      )
      (struct.get $type36 1
       (struct.get $environment45 3
        (local.get $9)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (ref.eq
        (local.get $4)
        (struct.get $type30 0
         (struct.get $type28 3
          (global.get $global130)
         )
        )
       )
       (then
        (if
         (i32.eqz
          (global.get $ready130)
         )
         (then
          (unreachable)
         )
        )
        (i32.eqz
         (ref.eq
          (local.get $4)
          (struct.get $type30 0
           (struct.get $type28 2
            (global.get $global130)
           )
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
      (i32.const 0)
     )
    )
   )
   (else
    (unreachable)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready131)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global131)
   )
  )
  (return_call $function51
   (local.get $0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type11)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type15)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global92
   (struct.new_default $type16)
  )
  (global.set $ready92
   (i32.const 1)
  )
  (global.set $global77
   (struct.new_default $type16)
  )
  (global.set $ready77
   (i32.const 1)
  )
  (global.set $global94
   (struct.new_default $type20)
  )
  (global.set $ready94
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type22)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global72
   (struct.new_default $type27)
  )
  (global.set $ready72
   (i32.const 1)
  )
  (global.set $global130
   (struct.new $type28
    (struct.new_default $type29)
    (struct.new_default $type29)
    (struct.new $type30
     (array.new_fixed $type12 0)
    )
    (struct.new $type30
     (array.new_fixed $type12 0)
    )
   )
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global131
   (struct.new_default $type31)
  )
  (global.set $ready131
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
 (func $diagnostic-sharing (result i32)
  (local $0 (ref null $type13))
  (local $1 (ref null $type13))
  (local $2 (ref null $type13))
  (local $3 (ref null $type13))
  (local $4 (ref $type12))
  (local $5 (ref $type12))
  (local $6 (ref null $type14))
  (local $7 i32)
  (local.set $7
   (i32.or
    (i32.shl
     (i32.eqz
      (ref.eq
       (local.tee $0
        (struct.get $type29 0
         (struct.get $type28 0
          (global.get $global130)
         )
        )
       )
       (local.tee $1
        (struct.get $type29 0
         (struct.get $type28 1
          (global.get $global130)
         )
        )
       )
      )
     )
     (i32.const 1)
    )
    (ref.eq
     (struct.get $type14 1
      (struct.get $type14 1
       (local.tee $6
        (struct.get $type13 0
         (local.get $0)
        )
       )
      )
     )
     (struct.get $type14 1
      (struct.get $type14 1
       (struct.get $type13 0
        (struct.get $type13 1
         (local.get $0)
        )
       )
      )
     )
    )
   )
  )
  (i32.or
   (i32.or
    (i32.or
     (i32.shl
      (i32.eqz
       (ref.eq
        (local.tee $2
         (array.get $type12
          (local.tee $4
           (struct.get $type30 0
            (struct.get $type28 2
             (global.get $global130)
            )
           )
          )
          (i32.const 2)
         )
        )
        (local.tee $0
         (array.get $type12
          (local.tee $5
           (struct.get $type30 0
            (struct.get $type28 3
             (global.get $global130)
            )
           )
          )
          (i32.const 2)
         )
        )
       )
      )
      (i32.const 7)
     )
     (i32.or
      (i32.shl
       (i32.eqz
        (ref.eq
         (local.tee $3
          (array.get $type12
           (local.get $4)
           (i32.const 1)
          )
         )
         (local.get $0)
        )
       )
       (i32.const 6)
      )
      (i32.or
       (i32.or
        (i32.or
         (i32.or
          (local.get $7)
          (i32.shl
           (i32.eqz
            (ref.eq
             (struct.get $type14 1
              (struct.get $type14 1
               (local.get $6)
              )
             )
             (struct.get $type14 1
              (struct.get $type14 1
               (struct.get $type13 0
                (local.get $1)
               )
              )
             )
            )
           )
           (i32.const 2)
          )
         )
         (i32.shl
          (ref.eq
           (local.get $3)
           (array.get $type12
            (local.get $5)
            (i32.const 0)
           )
          )
          (i32.const 3)
         )
        )
        (i32.shl
         (ref.eq
          (local.get $2)
          (array.get $type12
           (local.get $5)
           (i32.const 1)
          )
         )
         (i32.const 4)
        )
       )
       (i32.shl
        (i32.eqz
         (ref.eq
          (array.get $type12
           (local.get $4)
           (i32.const 0)
          )
          (local.get $0)
         )
        )
        (i32.const 5)
       )
      )
     )
    )
    (i32.shl
     (ref.is_null
      (array.get $type12
       (local.get $5)
       (i32.const 3)
      )
     )
     (i32.const 8)
    )
   )
   (i32.shl
    (ref.is_null
     (array.get $type12
      (local.get $4)
      (i32.const 3)
     )
    )
    (i32.const 9)
   )
  )
 )
)

