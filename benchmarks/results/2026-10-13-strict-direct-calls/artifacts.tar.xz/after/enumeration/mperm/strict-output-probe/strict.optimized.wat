(module
 (rec
  (type $environment65 (struct (field (ref $type49)) (field (ref $type41)) (field (ref $type50)) (field (ref $type36))))
  (type $type50 (struct (field i32) (field (ref $type25))))
  (type $type49 (struct (field i32) (field (ref $type23))))
  (type $call34 (func (param i64) (result i64)))
  (type $environment61 (struct (field (ref $type24)) (field (ref $type36))))
  (type $5 (func (param (ref null $type12) i32 i32 (ref null $type14)) (result (ref null $type12))))
  (type $environment59 (struct (field (ref $type38))))
  (type $call29 (func (param (ref null $type14) (ref null $type12)) (result (ref $type12))))
  (type $call28 (func (param (ref null $type12) (ref null $type12)) (result (ref null $type12))))
  (type $9 (func (param (ref null $type12) (ref null $type12)) (result (ref $type12))))
  (type $10 (func (param i32 i32 i64) (result i64)))
  (type $call26 (func (param (ref $environment49) (ref $type24)) (result i32)))
  (type $call25 (func (param (ref $environment48)) (result (ref $type24))))
  (type $13 (func (param (ref $type42) (ref null $type12) i64 (ref $type12)) (result (ref null $type12))))
  (type $14 (func (param (ref $type42) (ref null $type12) i64) (result (ref null $type12))))
  (type $environment44 (struct (field (ref $type45)) (field (ref $type47)) (field (ref $type42)) (field i64) (field (ref $type44)) (field (ref $type42)) (field (ref $type42)) (field (ref $type42))))
  (type $type48 (struct (field (mut (ref $type14)))))
  (type $environment42 (struct (field (ref $type40))))
  (type $type46 (struct (field (mut (ref null $type12)))))
  (type $type45 (struct (field i32) (field (ref $type46))))
  (type $type47 (struct (field i32) (field (ref $type48))))
  (type $call20 (func (param (ref null $type12)) (result (ref $type14))))
  (type $environment38 (struct (field (ref $type36))))
  (type $23 (func (param i64 (ref $type41) (ref $type42) i64 i64) (result i32)))
  (type $type43 (struct (field (ref $call43)) (field (ref struct))))
  (type $type44 (struct (field (mut i32)) (field (mut (ref null $type43)))))
  (type $environment35 (struct (field i64) (field i64) (field (ref $type41)) (field (ref $type44))))
  (type $call43 (func (param (ref struct) i64) (result i32)))
  (type $type23 (struct (field (ref $type24)) (field (ref $type25)) (field (ref $type26))))
  (type $type26 (struct (field (ref $environment49))))
  (type $environment49 (struct (field i64) (field i64) (field i64)))
  (type $type25 (struct (field (ref $environment48))))
  (type $environment48 (struct (field i64) (field i64) (field i64) (field (ref $type41)) (field (ref $type42)) (field (ref $type42))))
  (type $type24 (array (mut (ref null $type14))))
  (type $type42 (struct (field i32)))
  (type $type41 (struct (field i32) (field (ref $type24))))
  (type $call27 (func (param i64 i64 i64 i64) (result (ref $type23))))
  (type $type37 (struct (field (ref $call37)) (field (ref struct))))
  (type $type38 (struct (field (mut i32)) (field (mut (ref null $type37)))))
  (type $environment29 (struct (field (ref $type38))))
  (type $call39 (func (param (ref struct) (ref null $type12) i64) (result i64)))
  (type $environment30 (struct (field (ref $type40))))
  (type $type39 (struct (field (ref $call39)) (field (ref struct))))
  (type $type14 (struct (field (ref null $type12)) (field (ref null $type14))))
  (type $type40 (struct (field (mut i32)) (field (mut (ref null $type39)))))
  (type $call37 (func (param (ref struct) (ref null $type14) i64) (result i64)))
  (type $call16 (func (param (ref null $type12) (ref null $type12)) (result i32)))
  (type $type12 (struct (field i64) (field (ref null $type12))))
  (type $type35 (struct (field (ref $call35)) (field (ref struct))))
  (type $type36 (struct (field (mut i32)) (field (mut (ref null $type35)))))
  (type $environment26 (struct (field (ref $type36))))
  (type $call35 (func (param (ref struct) i64 (ref null $type12)) (result (ref null $type12))))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type21 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type18 (struct))
  (type $type17 (struct))
  (type $type16 (struct))
  (type $type15 (struct))
  (type $type13 (struct))
  (type $type11 (struct))
 )
 (type $69 (func (param i64) (result i64)))
 (type $70 (func (result i64)))
 (type $71 (func (param i32) (result i64)))
 (type $72 (func))
 (import "benchmark" "expected_length" (func $foreign0 (result i64)))
 (import "benchmark" "expected_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global105 (mut (ref null $type11)) (ref.null none))
 (global $ready105 (mut i32) (i32.const 0))
 (global $global148 (mut (ref null $type13)) (ref.null none))
 (global $ready148 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type15)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type16)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global99 (mut (ref null $type17)) (ref.null none))
 (global $ready99 (mut i32) (i32.const 0))
 (global $global84 (mut (ref null $type17)) (ref.null none))
 (global $ready84 (mut i32) (i32.const 0))
 (global $global128 (mut (ref null $type18)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type19)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type16)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global101 (mut (ref null $type20)) (ref.null none))
 (global $ready101 (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type13)) (ref.null none))
 (global $ready68 (mut i32) (i32.const 0))
 (global $global94 (mut (ref null $type21)) (ref.null none))
 (global $ready94 (mut i32) (i32.const 0))
 (global $global79 (mut (ref null $type27)) (ref.null none))
 (global $ready79 (mut i32) (i32.const 0))
 (global $global140 (mut (ref null $type28)) (ref.null none))
 (global $ready140 (mut i32) (i32.const 0))
 (global $global137 (mut (ref null $type28)) (ref.null none))
 (global $ready137 (mut i32) (i32.const 0))
 (global $global143 (mut (ref null $type29)) (ref.null none))
 (global $ready143 (mut i32) (i32.const 0))
 (global $global153 (mut (ref null $type30)) (ref.null none))
 (global $ready153 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type31)) (ref.null none))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global177 (mut (ref null $type28)) (ref.null none))
 (global $ready177 (mut i32) (i32.const 0))
 (global $global192 (mut (ref null $type32)) (ref.null none))
 (global $ready192 (mut i32) (i32.const 0))
 (global $global194 (mut (ref null $type32)) (ref.null none))
 (global $ready194 (mut i32) (i32.const 0))
 (global $global183 (mut (ref null $type33)) (ref.null none))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global159 (mut i64) (i64.const 0))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global160 (mut i64) (i64.const 0))
 (global $ready160 (mut i32) (i32.const 0))
 (global $global161 (mut i64) (i64.const 0))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global162 (mut (ref null $type34)) (ref.null none))
 (global $ready162 (mut i32) (i32.const 0))
 (global $global164 (mut (ref null $type34)) (ref.null none))
 (global $ready164 (mut i32) (i32.const 0))
 (global $global181 (mut (ref null $type34)) (ref.null none))
 (global $ready181 (mut i32) (i32.const 0))
 (export "enumeration-probe" (func $export0))
 (export "queue-probe" (func $export1))
 (export "predicate-probe" (func $export2))
 (export "main" (func $main))
 (func $function26 (type $call35) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type12)) (result (ref null $type12))
  (local $3 i64)
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (call $foreign1
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment26 0
        (ref.cast (ref $environment26)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function26
     (struct.get $type35 1
      (struct.get $type36 1
       (struct.get $environment26 0
        (ref.cast (ref $environment26)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type12
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function27 (type $call16) (param $0 (ref null $type12)) (param $1 (ref null $type12)) (result i32)
  (local $scratch (ref null $type12))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type12 0
         (local.get $0)
        )
        (struct.get $type12 0
         (local.get $1)
        )
       )
       (then
        (return_call $function27
         (struct.get $type12 1
          (local.get $0)
         )
         (block (result (ref null $type12))
          (local.set $scratch
           (struct.get $type12 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready65)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global65)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function29 (type $call37) (param $0 (ref struct)) (param $1 (ref null $type14)) (param $2 i64) (result i64)
  (local $3 (ref $type40))
  (local $4 (ref null $type14))
  (local $5 (ref null $type12))
  (local $6 (ref $type39))
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $4
     (struct.get $type14 1
      (local.get $1)
     )
    )
    (local.set $5
     (struct.get $type14 0
      (local.get $1)
     )
    )
    (struct.set $type40 1
     (local.tee $3
      (struct.new_default $type40)
     )
     (struct.new $type39
      (ref.func $function30)
      (struct.new $environment30
       (local.get $3)
      )
     )
    )
    (struct.set $type40 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type40 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call_ref $call39
      (struct.get $type39 1
       (local.tee $6
        (ref.as_non_null
         (struct.get $type40 1
          (local.get $3)
         )
        )
       )
      )
      (local.get $5)
      (local.get $2)
      (struct.get $type39 0
       (local.get $6)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type38 0
       (struct.get $environment29 0
        (ref.cast (ref $environment29)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function29
     (struct.get $type37 1
      (struct.get $type38 1
       (struct.get $environment29 0
        (ref.cast (ref $environment29)
         (local.get $0)
        )
       )
      )
     )
     (local.get $4)
     (local.get $2)
    )
   )
  )
 )
 (func $function30 (type $call39) (param $0 (ref struct)) (param $1 (ref null $type12)) (param $2 i64) (result i64)
  (local $3 (ref null $type12))
  (local $4 i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (local.set $4
     (struct.get $type12 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type40 0
       (struct.get $environment30 0
        (ref.cast (ref $environment30)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function30
     (struct.get $type39 1
      (struct.get $type40 1
       (struct.get $environment30 0
        (ref.cast (ref $environment30)
         (local.get $0)
        )
       )
      )
     )
     (local.get $3)
     (i64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function32 (type $call27) (param $0 i64) (param $1 i64) (param $2 i64) (param $3 i64) (result (ref $type23))
  (local $4 (ref $type42))
  (local $5 (ref $type41))
  (if (result (ref $type23))
   (if (result i32)
    (i64.ge_s
     (local.get $0)
     (i64.const 0)
    )
    (then
     (if
      (i32.eqz
       (global.get $ready84)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global84)
      )
     )
     (if (result i32)
      (i64.gt_s
       (local.get $1)
       (i64.const 0)
      )
      (then
       (if
        (i32.eqz
         (global.get $ready84)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global84)
        )
       )
       (i32.and
        (i32.and
         (i64.ge_s
          (local.get $2)
          (local.get $3)
         )
         (i64.ge_s
          (local.get $3)
          (i64.const 0)
         )
        )
        (i64.gt_s
         (local.get $2)
         (i64.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.new $type42
      (i32.const 1)
     )
    )
    (drop
     (call $function36
      (local.get $1)
      (local.tee $5
       (struct.new $type41
        (i32.const 1)
        (array.new_default $type24
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
      )
      (local.get $4)
      (i64.const 0)
      (i64.sub
       (local.get $2)
       (local.get $3)
      )
     )
    )
    (struct.new $type23
     (struct.get $type41 1
      (local.get $5)
     )
     (struct.new $type25
      (struct.new $environment48
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $5)
       (struct.new $type42
        (i32.const 1)
       )
       (local.get $4)
      )
     )
     (struct.new $type26
      (struct.new $environment49
       (local.get $1)
       (local.get $2)
       (local.get $3)
      )
     )
    )
   )
   (else
    (unreachable)
   )
  )
 )
 (func $function35 (type $call43) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment35))
  (local $3 (ref null $type14))
  (local $4 i64)
  (if (result i32)
   (i64.gt_s
    (struct.get $environment35 0
     (local.tee $2
      (ref.cast (ref $environment35)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $3
     (if (result (ref null $type14))
      (i64.lt_s
       (local.tee $4
        (i64.add
         (struct.get $environment35 1
          (local.get $2)
         )
         (local.get $1)
        )
       )
       (struct.get $environment35 0
        (local.get $2)
       )
      )
      (then
       (if
        (i64.gt_u
         (local.get $4)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type24
        (struct.get $type41 1
         (struct.get $environment35 2
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (else
       (ref.null none)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type24
     (struct.get $type41 1
      (struct.get $environment35 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type44 0
       (struct.get $environment35 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function35
     (struct.get $type43 1
      (struct.get $type44 1
       (struct.get $environment35 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function36 (type $23) (param $0 i64) (param $1 (ref $type41)) (param $2 (ref $type42)) (param $3 i64) (param $4 i64) (result i32)
  (local $5 (ref $type36))
  (local $6 (ref $type35))
  (local $7 (ref null $type12))
  (local $8 (ref $type14))
  (local $scratch (ref null $type12))
  (if (result i32)
   (i64.lt_s
    (local.get $3)
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready94)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global94)
     )
    )
    (struct.set $type36 1
     (local.tee $5
      (struct.new_default $type36)
     )
     (struct.new $type35
      (ref.func $function38)
      (struct.new $environment38
       (local.get $5)
      )
     )
    )
    (struct.set $type36 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (call $function40
      (block (result (ref null $type12))
       (local.set $scratch
        (call_ref $call35
         (struct.get $type35 1
          (local.tee $6
           (ref.as_non_null
            (struct.get $type36 1
             (local.get $5)
            )
           )
          )
         )
         (local.get $0)
         (ref.null none)
         (struct.get $type35 0
          (local.get $6)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready101)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global101)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type24
     (struct.get $type41 1
      (local.get $1)
     )
     (i32.wrap_i64
      (local.get $3)
     )
     (local.get $8)
    )
    (return_call $function36
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function38 (type $call35) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type12)) (result (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready99)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global99)
   )
  )
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment38 0
        (ref.cast (ref $environment38)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function38
     (struct.get $type35 1
      (struct.get $type36 1
       (struct.get $environment38 0
        (ref.cast (ref $environment38)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type12
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function40 (type $call20) (param $0 (ref null $type12)) (result (ref $type14))
  (local $1 (ref $type40))
  (local $2 (ref $type44))
  (local $3 (ref $type45))
  (local $4 (ref $type47))
  (local $5 (ref null $type12))
  (local $6 (ref $type42))
  (local $7 (ref $type42))
  (local $8 (ref $type42))
  (local $9 (ref $type39))
  (local $10 (ref $type43))
  (local $11 i64)
  (if
   (i32.eqz
    (global.get $ready105)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.new $type45
    (i32.const 1)
    (struct.new $type46
     (local.get $0)
    )
   )
  )
  (local.set $5
   (struct.get $type46 0
    (struct.get $type45 1
     (local.get $3)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global105)
   )
  )
  (struct.set $type40 1
   (local.tee $1
    (struct.new_default $type40)
   )
   (struct.new $type39
    (ref.func $function42)
    (struct.new $environment42
     (local.get $1)
    )
   )
  )
  (struct.set $type40 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type40 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.new $type42
    (i32.const 1)
   )
  )
  (local.set $4
   (struct.new $type47
    (i32.const 1)
    (struct.new $type48
     (struct.new $type14
      (local.get $0)
      (ref.null none)
     )
    )
   )
  )
  (local.set $7
   (struct.new $type42
    (i32.const 1)
   )
  )
  (local.set $8
   (struct.new $type42
    (i32.const 1)
   )
  )
  (drop
   (if (result i32)
    (i64.gt_s
     (local.tee $11
      (call_ref $call39
       (struct.get $type39 1
        (local.tee $9
         (ref.as_non_null
          (struct.get $type40 1
           (local.get $1)
          )
         )
        )
       )
       (local.get $5)
       (i64.const 0)
       (struct.get $type39 0
        (local.get $9)
       )
      )
     )
     (i64.const 1)
    )
    (then
     (struct.set $type44 1
      (local.tee $2
       (struct.new_default $type44)
      )
      (struct.new $type43
       (ref.func $function44)
       (struct.new $environment44
        (local.get $3)
        (local.get $4)
        (local.get $6)
        (local.get $11)
        (local.get $2)
        (local.get $7)
        (struct.new $type42
         (i32.const 1)
        )
        (local.get $8)
       )
      )
     )
     (struct.set $type44 0
      (local.get $2)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type44 0
        (local.get $2)
       )
      )
      (then
       (unreachable)
      )
     )
     (call_ref $call43
      (struct.get $type43 1
       (local.tee $10
        (ref.as_non_null
         (struct.get $type44 1
          (local.get $2)
         )
        )
       )
      )
      (i64.sub
       (local.get $11)
       (i64.const 1)
      )
      (struct.get $type43 0
       (local.get $10)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (struct.get $type48 0
   (struct.get $type47 1
    (local.get $4)
   )
  )
 )
 (func $function42 (type $call39) (param $0 (ref struct)) (param $1 (ref null $type12)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type12 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type40 0
       (struct.get $environment42 0
        (ref.cast (ref $environment42)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (struct.get $type39 1
      (struct.get $type40 1
       (struct.get $environment42 0
        (ref.cast (ref $environment42)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function44 (type $call43) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref null $type12))
  (local $3 (ref null $type12))
  (local $4 (ref null $type12))
  (local $5 (ref $type12))
  (local $6 (ref $environment44))
  (local $7 (ref $type44))
  (local $8 (ref $type42))
  (local $9 (ref $type43))
  (local $10 (ref $type45))
  (local $11 (ref $type47))
  (local $12 (ref $type48))
  (local $13 i64)
  (local $14 i64)
  (local $scratch (ref $type47))
  (if
   (i32.eqz
    (global.get $ready99)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global99)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $1)
   )
   (then
    (if (result i32)
     (i64.gt_s
      (local.tee $1
       (i64.sub
        (struct.get $environment44 3
         (local.tee $6
          (ref.cast (ref $environment44)
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 1)
     )
     (then
      (struct.set $type44 1
       (local.tee $7
        (struct.new_default $type44)
       )
       (struct.new $type43
        (ref.func $function44)
        (struct.new $environment44
         (struct.get $environment44 0
          (local.get $6)
         )
         (struct.get $environment44 1
          (local.get $6)
         )
         (struct.get $environment44 2
          (local.get $6)
         )
         (local.get $1)
         (local.get $7)
         (struct.get $environment44 5
          (local.get $6)
         )
         (struct.get $environment44 6
          (local.get $6)
         )
         (struct.get $environment44 7
          (local.get $6)
         )
        )
       )
      )
      (struct.set $type44 0
       (local.get $7)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type44 0
         (local.get $7)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call43
       (struct.get $type43 1
        (local.tee $9
         (ref.as_non_null
          (struct.get $type44 1
           (local.get $7)
          )
         )
        )
       )
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
       (struct.get $type43 0
        (local.get $9)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (drop
     (if (result i32)
      (i64.gt_s
       (local.tee $13
        (i64.sub
         (struct.get $environment44 3
          (local.tee $6
           (ref.cast (ref $environment44)
            (local.get $0)
           )
          )
         )
         (block (result i64)
          (local.set $8
           (struct.get $environment44 5
            (local.get $6)
           )
          )
          (i64.const 1)
         )
        )
       )
       (i64.const 1)
      )
      (then
       (struct.set $type44 1
        (local.tee $7
         (struct.new_default $type44)
        )
        (struct.new $type43
         (ref.func $function44)
         (struct.new $environment44
          (struct.get $environment44 0
           (local.get $6)
          )
          (struct.get $environment44 1
           (local.get $6)
          )
          (struct.get $environment44 2
           (local.get $6)
          )
          (local.get $13)
          (local.get $7)
          (local.get $8)
          (struct.get $environment44 6
           (local.get $6)
          )
          (struct.get $environment44 7
           (local.get $6)
          )
         )
        )
       )
       (struct.set $type44 0
        (local.get $7)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type44 0
          (local.get $7)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call43
        (struct.get $type43 1
         (local.tee $9
          (ref.as_non_null
           (struct.get $type44 1
            (local.get $7)
           )
          )
         )
        )
        (i64.sub
         (local.get $13)
         (i64.const 1)
        )
        (struct.get $type43 0
         (local.get $9)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.set $2
     (struct.get $type46 0
      (struct.get $type45 1
       (local.tee $10
        (struct.get $environment44 0
         (local.get $6)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready99)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type46 0
      (struct.get $type45 1
       (local.get $10)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global99)
     )
    )
    (if
     (i64.ne
      (local.tee $13
       (struct.get $environment44 3
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready99)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (struct.get $environment44 6
        (local.get $6)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global99)
       )
      )
      (local.set $2
       (if (result (ref null $type12))
        (i64.eqz
         (local.tee $14
          (i64.sub
           (local.get $13)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $2)
        )
        (else
         (local.set $2
          (struct.get $type12 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready99)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global99)
          )
         )
         (if (result (ref null $type12))
          (i64.eqz
           (local.tee $14
            (i64.sub
             (local.get $14)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $2
            (struct.get $type12 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready99)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global99)
            )
           )
           (if (result (ref null $type12))
            (i64.eqz
             (local.tee $14
              (i64.sub
               (local.get $14)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $2)
            )
            (else
             (local.set $2
              (struct.get $type12 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready99)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global99)
              )
             )
             (if (result (ref null $type12))
              (i64.eqz
               (local.tee $14
                (i64.sub
                 (local.get $14)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $2)
              )
              (else
               (local.set $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready99)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global99)
                )
               )
               (if (result (ref null $type12))
                (i64.eqz
                 (local.tee $14
                  (i64.sub
                   (local.get $14)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $2)
                )
                (else
                 (local.set $2
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready99)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global99)
                  )
                 )
                 (if (result (ref null $type12))
                  (i64.eqz
                   (local.tee $14
                    (i64.sub
                     (local.get $14)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (local.set $2
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready99)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global99)
                    )
                   )
                   (if (result (ref null $type12))
                    (i64.eqz
                     (local.tee $14
                      (i64.sub
                       (local.get $14)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (local.set $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                     (local.set $14
                      (i64.sub
                       (local.get $14)
                       (i64.const 1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready99)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global99)
                      )
                     )
                     (if (result (ref null $type12))
                      (i64.eqz
                       (local.get $14)
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (call $function46
                        (local.get $8)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.sub
                         (local.get $14)
                         (i64.const 1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready99)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $environment44 7
      (local.get $6)
     )
    )
    (struct.set $type48 0
     (local.tee $12
      (struct.get $type47 1
       (block (result (ref $type47))
        (local.set $scratch
         (struct.get $environment44 1
          (local.get $6)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global99)
         )
        )
        (struct.set $type46 0
         (struct.get $type45 1
          (local.get $10)
         )
         (if (result (ref null $type12))
          (i64.eqz
           (local.get $13)
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $4
            (struct.get $type12 1
             (local.get $3)
            )
           )
           (local.set $5
            (struct.new $type12
             (struct.get $type12 0
              (local.get $3)
             )
             (block (result (ref null $type12))
              (if
               (i32.eqz
                (global.get $ready99)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global99)
               )
              )
              (local.get $2)
             )
            )
           )
           (if (result (ref null $type12))
            (i64.eqz
             (local.tee $13
              (i64.sub
               (local.get $13)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $2
              (struct.get $type12 1
               (local.get $4)
              )
             )
             (local.set $5
              (struct.new $type12
               (struct.get $type12 0
                (local.get $4)
               )
               (block (result (ref $type12))
                (if
                 (i32.eqz
                  (global.get $ready99)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global99)
                 )
                )
                (local.get $5)
               )
              )
             )
             (if (result (ref null $type12))
              (i64.eqz
               (local.tee $13
                (i64.sub
                 (local.get $13)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $3
                (struct.get $type12 1
                 (local.get $2)
                )
               )
               (local.set $5
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $2)
                 )
                 (block (result (ref $type12))
                  (if
                   (i32.eqz
                    (global.get $ready99)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global99)
                   )
                  )
                  (local.get $5)
                 )
                )
               )
               (if (result (ref null $type12))
                (i64.eqz
                 (local.tee $13
                  (i64.sub
                   (local.get $13)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $2
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready99)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global99)
                  )
                 )
                 (local.set $5
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $3)
                   )
                   (local.get $5)
                  )
                 )
                 (if (result (ref null $type12))
                  (i64.eqz
                   (local.tee $13
                    (i64.sub
                     (local.get $13)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready99)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global99)
                    )
                   )
                   (local.set $5
                    (struct.new $type12
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (local.get $5)
                    )
                   )
                   (if (result (ref null $type12))
                    (i64.eqz
                     (local.tee $13
                      (i64.sub
                       (local.get $13)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $2
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready99)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global99)
                      )
                     )
                     (local.set $5
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $3)
                       )
                       (local.get $5)
                      )
                     )
                     (if (result (ref null $type12))
                      (i64.eqz
                       (local.tee $13
                        (i64.sub
                         (local.get $13)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready99)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global99)
                        )
                       )
                       (local.set $5
                        (struct.new $type12
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $5)
                        )
                       )
                       (if (result (ref null $type12))
                        (i64.eqz
                         (local.tee $13
                          (i64.sub
                           (local.get $13)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $2
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                         (local.set $13
                          (i64.sub
                           (local.get $13)
                           (i64.const 1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready99)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global99)
                          )
                         )
                         (local.set $5
                          (struct.new $type12
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (local.get $5)
                          )
                         )
                         (if (result (ref null $type12))
                          (i64.eqz
                           (local.get $13)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (call $function47
                            (local.get $8)
                            (struct.get $type12 1
                             (local.get $2)
                            )
                            (i64.sub
                             (local.get $13)
                             (i64.const 1)
                            )
                            (struct.new $type12
                             (struct.get $type12 0
                              (local.get $2)
                             )
                             (local.get $5)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (local.get $scratch)
       )
      )
     )
     (struct.new $type14
      (struct.get $type46 0
       (struct.get $type45 1
        (local.get $10)
       )
      )
      (struct.get $type48 0
       (local.get $12)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type44 0
       (struct.get $environment44 4
        (local.get $6)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (struct.get $type43 1
      (struct.get $type44 1
       (struct.get $environment44 4
        (local.get $6)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function46 (type $14) (param $0 (ref $type42)) (param $1 (ref null $type12)) (param $2 i64) (result (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready99)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global99)
   )
  )
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function46
     (local.get $0)
     (struct.get $type12 1
      (local.get $1)
     )
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function47 (type $13) (param $0 (ref $type42)) (param $1 (ref null $type12)) (param $2 i64) (param $3 (ref $type12)) (result (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready99)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global99)
   )
  )
  (if (result (ref $type12))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (return_call $function47
     (local.get $0)
     (struct.get $type12 1
      (local.get $1)
     )
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
     (struct.new $type12
      (struct.get $type12 0
       (local.get $1)
      )
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function48 (type $call25) (param $0 (ref $environment48)) (result (ref $type24))
  (local $1 (ref $type44))
  (local $2 (ref $type41))
  (local $3 (ref $type43))
  (local $4 i64)
  (local $5 i64)
  (drop
   (call $function36
    (struct.get $environment48 0
     (local.get $0)
    )
    (local.tee $2
     (struct.get $environment48 3
      (local.get $0)
     )
    )
    (struct.get $environment48 5
     (local.get $0)
    )
    (i64.sub
     (local.tee $4
      (struct.get $environment48 1
       (local.get $0)
      )
     )
     (local.tee $5
      (struct.get $environment48 2
       (local.get $0)
      )
     )
    )
    (local.get $4)
   )
  )
  (struct.set $type44 1
   (local.tee $1
    (struct.new_default $type44)
   )
   (struct.new $type43
    (ref.func $function35)
    (struct.new $environment35
     (local.get $4)
     (local.get $5)
     (local.get $2)
     (local.get $1)
    )
   )
  )
  (struct.set $type44 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type44 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call43
    (struct.get $type43 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type44 1
        (local.get $1)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type43 0
     (local.get $3)
    )
   )
  )
  (struct.get $type41 1
   (struct.get $environment48 3
    (local.get $0)
   )
  )
 )
 (func $function49 (type $call26) (param $0 (ref $environment49)) (param $1 (ref $type24)) (result i32)
  (local $2 (ref null $type12))
  (local $3 (ref null $type12))
  (local $4 (ref null $type14))
  (local $5 (ref null $type14))
  (local $6 (ref $type38))
  (local $7 (ref $type37))
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (local $15 i64)
  (local $16 i64)
  (local $17 i64)
  (local $18 i32)
  (local $scratch (ref null $type12))
  (local.set $4
   (array.get $type24
    (local.get $1)
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready128)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global128)
   )
  )
  (if
   (i64.gt_u
    (local.tee $8
     (select
      (local.tee $8
       (i64.sub
        (i64.sub
         (struct.get $environment49 1
          (local.get $0)
         )
         (struct.get $environment49 2
          (local.get $0)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 0)
      (i64.ge_s
       (local.get $8)
       (i64.const 0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $18
     (i32.and
      (ref.is_null
       (local.tee $5
        (array.get $type24
         (local.get $1)
         (i32.wrap_i64
          (local.get $8)
         )
        )
       )
      )
      (ref.is_null
       (local.get $4)
      )
     )
    )
    (then
     (local.get $18)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready132)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global132)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $4)
      )
      (then
       (i32.const 0)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready132)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global132)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $5)
        )
        (then
         (i32.const 0)
        )
        (else
         (local.set $3
          (struct.get $type14 0
           (local.get $4)
          )
         )
         (local.set $2
          (struct.get $type14 0
           (local.get $5)
          )
         )
         (if
          (i32.eqz
           (global.get $ready134)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global134)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $3)
          )
          (then
           (ref.is_null
            (local.get $2)
           )
          )
          (else
           (if (result i32)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i64.eq
               (struct.get $type12 0
                (local.get $3)
               )
               (struct.get $type12 0
                (local.get $2)
               )
              )
              (then
               (local.set $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
               (local.set $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready134)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global134)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (ref.is_null
                  (local.get $2)
                 )
                )
                (else
                 (if (result i32)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i64.eq
                     (struct.get $type12 0
                      (local.get $3)
                     )
                     (struct.get $type12 0
                      (local.get $2)
                     )
                    )
                    (then
                     (local.set $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (local.set $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready134)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global134)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (ref.is_null
                        (local.get $2)
                       )
                      )
                      (else
                       (if (result i32)
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (i64.eq
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (struct.get $type12 0
                            (local.get $2)
                           )
                          )
                          (then
                           (local.set $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                           (local.set $2
                            (struct.get $type12 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready134)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global134)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (ref.is_null
                              (local.get $2)
                             )
                            )
                            (else
                             (if (result i32)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (if (result i32)
                                (i64.eq
                                 (struct.get $type12 0
                                  (local.get $3)
                                 )
                                 (struct.get $type12 0
                                  (local.get $2)
                                 )
                                )
                                (then
                                 (local.set $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                 (local.set $2
                                  (struct.get $type12 1
                                   (local.get $2)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready134)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global134)
                                  )
                                 )
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                  )
                                  (else
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $2)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (if (result i32)
                                      (i64.eq
                                       (struct.get $type12 0
                                        (local.get $3)
                                       )
                                       (struct.get $type12 0
                                        (local.get $2)
                                       )
                                      )
                                      (then
                                       (local.set $3
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                       (local.set $2
                                        (struct.get $type12 1
                                         (local.get $2)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready134)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global134)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $3)
                                        )
                                        (then
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                        )
                                        (else
                                         (if (result i32)
                                          (ref.is_null
                                           (local.get $2)
                                          )
                                          (then
                                           (i32.const 0)
                                          )
                                          (else
                                           (if (result i32)
                                            (i64.eq
                                             (struct.get $type12 0
                                              (local.get $3)
                                             )
                                             (struct.get $type12 0
                                              (local.get $2)
                                             )
                                            )
                                            (then
                                             (local.set $3
                                              (struct.get $type12 1
                                               (local.get $3)
                                              )
                                             )
                                             (local.set $2
                                              (struct.get $type12 1
                                               (local.get $2)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready134)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global134)
                                              )
                                             )
                                             (if (result i32)
                                              (ref.is_null
                                               (local.get $3)
                                              )
                                              (then
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                              )
                                              (else
                                               (if (result i32)
                                                (ref.is_null
                                                 (local.get $2)
                                                )
                                                (then
                                                 (i32.const 0)
                                                )
                                                (else
                                                 (if (result i32)
                                                  (i64.eq
                                                   (struct.get $type12 0
                                                    (local.get $3)
                                                   )
                                                   (struct.get $type12 0
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (then
                                                   (local.set $3
                                                    (struct.get $type12 1
                                                     (local.get $3)
                                                    )
                                                   )
                                                   (local.set $2
                                                    (struct.get $type12 1
                                                     (local.get $2)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready134)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global134)
                                                    )
                                                   )
                                                   (if (result i32)
                                                    (ref.is_null
                                                     (local.get $3)
                                                    )
                                                    (then
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (else
                                                     (if (result i32)
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                      (then
                                                       (i32.const 0)
                                                      )
                                                      (else
                                                       (if (result i32)
                                                        (i64.eq
                                                         (struct.get $type12 0
                                                          (local.get $3)
                                                         )
                                                         (struct.get $type12 0
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (then
                                                         (local.set $3
                                                          (struct.get $type12 1
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (local.set $2
                                                          (struct.get $type12 1
                                                           (local.get $2)
                                                          )
                                                         )
                                                         (if
                                                          (i32.eqz
                                                           (global.get $ready134)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global134)
                                                          )
                                                         )
                                                         (if (result i32)
                                                          (ref.is_null
                                                           (local.get $3)
                                                          )
                                                          (then
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (else
                                                           (if (result i32)
                                                            (ref.is_null
                                                             (local.get $2)
                                                            )
                                                            (then
                                                             (i32.const 0)
                                                            )
                                                            (else
                                                             (if (result i32)
                                                              (i64.eq
                                                               (struct.get $type12 0
                                                                (local.get $3)
                                                               )
                                                               (struct.get $type12 0
                                                                (local.get $2)
                                                               )
                                                              )
                                                              (then
                                                               (local.set $3
                                                                (struct.get $type12 1
                                                                 (local.get $3)
                                                                )
                                                               )
                                                               (local.set $2
                                                                (struct.get $type12 1
                                                                 (local.get $2)
                                                                )
                                                               )
                                                               (if
                                                                (i32.eqz
                                                                 (global.get $ready134)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                               )
                                                               (drop
                                                                (ref.as_non_null
                                                                 (global.get $global134)
                                                                )
                                                               )
                                                               (if (result i32)
                                                                (ref.is_null
                                                                 (local.get $3)
                                                                )
                                                                (then
                                                                 (ref.is_null
                                                                  (local.get $2)
                                                                 )
                                                                )
                                                                (else
                                                                 (if (result i32)
                                                                  (ref.is_null
                                                                   (local.get $2)
                                                                  )
                                                                  (then
                                                                   (i32.const 0)
                                                                  )
                                                                  (else
                                                                   (if (result i32)
                                                                    (i64.eq
                                                                     (struct.get $type12 0
                                                                      (local.get $3)
                                                                     )
                                                                     (struct.get $type12 0
                                                                      (local.get $2)
                                                                     )
                                                                    )
                                                                    (then
                                                                     (call $function53
                                                                      (struct.get $type12 1
                                                                       (local.get $3)
                                                                      )
                                                                      (block (result (ref null $type12))
                                                                       (local.set $scratch
                                                                        (struct.get $type12 1
                                                                         (local.get $2)
                                                                        )
                                                                       )
                                                                       (if
                                                                        (i32.eqz
                                                                         (global.get $ready134)
                                                                        )
                                                                        (then
                                                                         (unreachable)
                                                                        )
                                                                       )
                                                                       (drop
                                                                        (ref.as_non_null
                                                                         (global.get $global134)
                                                                        )
                                                                       )
                                                                       (local.get $scratch)
                                                                      )
                                                                     )
                                                                    )
                                                                    (else
                                                                     (i32.const 0)
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (else
                                             (i32.const 0)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                      (else
                                       (i32.const 0)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (else
                                 (i32.const 0)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (else
                           (i32.const 0)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                 )
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready68)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global68)
     )
    )
    (struct.set $type38 1
     (local.tee $6
      (struct.new_default $type38)
     )
     (struct.new $type37
      (ref.func $function29)
      (struct.new $environment29
       (local.get $6)
      )
     )
    )
    (struct.set $type38 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type38 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (i64.eq
     (call_ref $call37
      (struct.get $type37 1
       (local.tee $7
        (ref.as_non_null
         (struct.get $type38 1
          (local.get $6)
         )
        )
       )
      )
      (local.get $4)
      (i64.const 0)
      (struct.get $type37 0
       (local.get $7)
      )
     )
     (i64.div_s
      (i64.mul
       (i64.mul
        (local.tee $8
         (struct.get $environment49 0
          (local.get $0)
         )
        )
        (i64.add
         (local.get $8)
         (i64.const 1)
        )
       )
       (if (result i64)
        (i64.eqz
         (local.get $8)
        )
        (then
         (i64.const 1)
        )
        (else
         (i64.mul
          (if (result i64)
           (i64.eqz
            (local.tee $9
             (i64.sub
              (local.get $8)
              (i64.const 1)
             )
            )
           )
           (then
            (i64.const 1)
           )
           (else
            (i64.mul
             (if (result i64)
              (i64.eqz
               (local.tee $10
                (i64.sub
                 (local.get $9)
                 (i64.const 1)
                )
               )
              )
              (then
               (i64.const 1)
              )
              (else
               (i64.mul
                (if (result i64)
                 (i64.eqz
                  (local.tee $11
                   (i64.sub
                    (local.get $10)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (i64.const 1)
                 )
                 (else
                  (i64.mul
                   (if (result i64)
                    (i64.eqz
                     (local.tee $12
                      (i64.sub
                       (local.get $11)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (i64.const 1)
                    )
                    (else
                     (i64.mul
                      (if (result i64)
                       (i64.eqz
                        (local.tee $13
                         (i64.sub
                          (local.get $12)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (i64.const 1)
                       )
                       (else
                        (i64.mul
                         (if (result i64)
                          (i64.eqz
                           (local.tee $14
                            (i64.sub
                             (local.get $13)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (i64.const 1)
                          )
                          (else
                           (i64.mul
                            (if (result i64)
                             (i64.eqz
                              (local.tee $15
                               (i64.sub
                                (local.get $14)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (i64.const 1)
                             )
                             (else
                              (i64.mul
                               (if (result i64)
                                (i64.eqz
                                 (local.tee $16
                                  (i64.sub
                                   (local.get $15)
                                   (i64.const 1)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 1)
                                )
                                (else
                                 (i64.mul
                                  (if (result i64)
                                   (i64.eqz
                                    (local.tee $17
                                     (i64.sub
                                      (local.get $16)
                                      (i64.const 1)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 1)
                                   )
                                   (else
                                    (i64.mul
                                     (call $function50
                                      (i32.const 0)
                                      (i32.const 1)
                                      (i64.sub
                                       (local.get $17)
                                       (i64.const 1)
                                      )
                                     )
                                     (local.get $17)
                                    )
                                   )
                                  )
                                  (local.get $16)
                                 )
                                )
                               )
                               (local.get $15)
                              )
                             )
                            )
                            (local.get $14)
                           )
                          )
                         )
                         (local.get $13)
                        )
                       )
                      )
                      (local.get $12)
                     )
                    )
                   )
                   (local.get $11)
                  )
                 )
                )
                (local.get $10)
               )
              )
             )
             (local.get $9)
            )
           )
          )
          (local.get $8)
         )
        )
       )
      )
      (i64.const 2)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function50 (type $10) (param $0 i32) (param $1 i32) (param $2 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $2)
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (i64.mul
     (call $function50
      (local.get $0)
      (local.get $1)
      (i64.sub
       (local.get $2)
       (i64.const 1)
      )
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function53 (type $call16) (param $0 (ref null $type12)) (param $1 (ref null $type12)) (result i32)
  (local $scratch (ref null $type12))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type12 0
         (local.get $0)
        )
        (struct.get $type12 0
         (local.get $1)
        )
       )
       (then
        (return_call $function53
         (struct.get $type12 1
          (local.get $0)
         )
         (block (result (ref null $type12))
          (local.set $scratch
           (struct.get $type12 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready134)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global134)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function54 (type $9) (param $0 (ref null $type12)) (param $1 (ref null $type12)) (result (ref $type12))
  (local $2 i64)
  (local $3 (ref $type40))
  (local $4 (ref $type39))
  (if
   (i32.eqz
    (global.get $ready105)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global105)
   )
  )
  (struct.set $type40 1
   (local.tee $3
    (struct.new_default $type40)
   )
   (struct.new $type39
    (ref.func $function42)
    (struct.new $environment42
     (local.get $3)
    )
   )
  )
  (struct.set $type40 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type40 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.new $type12
   (call_ref $call39
    (struct.get $type39 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type40 1
        (local.get $3)
       )
      )
     )
    )
    (local.get $0)
    (i64.const 0)
    (struct.get $type39 0
     (local.get $4)
    )
   )
   (block (result (ref null $type12))
    (if
     (i32.eqz
      (global.get $ready140)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global140)
     )
    )
    (if (result (ref null $type12))
     (ref.is_null
      (local.get $0)
     )
     (then
      (local.get $1)
     )
     (else
      (struct.new $type12
       (struct.get $type12 0
        (local.get $0)
       )
       (block (result (ref null $type12))
        (local.set $0
         (struct.get $type12 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready140)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global140)
         )
        )
        (if (result (ref null $type12))
         (ref.is_null
          (local.get $0)
         )
         (then
          (local.get $1)
         )
         (else
          (struct.new $type12
           (struct.get $type12 0
            (local.get $0)
           )
           (block (result (ref null $type12))
            (local.set $0
             (struct.get $type12 1
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready140)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global140)
             )
            )
            (if (result (ref null $type12))
             (ref.is_null
              (local.get $0)
             )
             (then
              (local.get $1)
             )
             (else
              (struct.new $type12
               (struct.get $type12 0
                (local.get $0)
               )
               (block (result (ref null $type12))
                (local.set $0
                 (struct.get $type12 1
                  (local.get $0)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready140)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global140)
                 )
                )
                (if (result (ref null $type12))
                 (ref.is_null
                  (local.get $0)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $0)
                   )
                   (block (result (ref null $type12))
                    (local.set $0
                     (struct.get $type12 1
                      (local.get $0)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready140)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global140)
                     )
                    )
                    (if (result (ref null $type12))
                     (ref.is_null
                      (local.get $0)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $0)
                       )
                       (block (result (ref null $type12))
                        (local.set $0
                         (struct.get $type12 1
                          (local.get $0)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready140)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global140)
                         )
                        )
                        (if (result (ref null $type12))
                         (ref.is_null
                          (local.get $0)
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (struct.new $type12
                           (struct.get $type12 0
                            (local.get $0)
                           )
                           (block (result (ref null $type12))
                            (local.set $0
                             (struct.get $type12 1
                              (local.get $0)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready140)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global140)
                             )
                            )
                            (if (result (ref null $type12))
                             (ref.is_null
                              (local.get $0)
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (struct.new $type12
                               (struct.get $type12 0
                                (local.get $0)
                               )
                               (block (result (ref null $type12))
                                (local.set $0
                                 (struct.get $type12 1
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready140)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global140)
                                 )
                                )
                                (if (result (ref null $type12))
                                 (ref.is_null
                                  (local.get $0)
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (struct.new $type12
                                   (struct.get $type12 0
                                    (local.get $0)
                                   )
                                   (block (result (ref null $type12))
                                    (local.set $0
                                     (struct.get $type12 1
                                      (local.get $0)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready140)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global140)
                                     )
                                    )
                                    (if (result (ref null $type12))
                                     (ref.is_null
                                      (local.get $0)
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (struct.new $type12
                                       (struct.get $type12 0
                                        (local.get $0)
                                       )
                                       (block (result (ref null $type12))
                                        (local.set $0
                                         (struct.get $type12 1
                                          (local.get $0)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready140)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global140)
                                         )
                                        )
                                        (if (result (ref null $type12))
                                         (ref.is_null
                                          (local.get $0)
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (struct.new $type12
                                           (struct.get $type12 0
                                            (local.get $0)
                                           )
                                           (call $function55
                                            (struct.get $type12 1
                                             (local.get $0)
                                            )
                                            (block (result (ref null $type12))
                                             (if
                                              (i32.eqz
                                               (global.get $ready140)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global140)
                                              )
                                             )
                                             (local.get $1)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function55 (type $call28) (param $0 (ref null $type12)) (param $1 (ref null $type12)) (result (ref null $type12))
  (local $2 i64)
  (if (result (ref null $type12))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (struct.new $type12
     (struct.get $type12 0
      (local.get $0)
     )
     (call $function55
      (struct.get $type12 1
       (local.get $0)
      )
      (block (result (ref null $type12))
       (if
        (i32.eqz
         (global.get $ready140)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global140)
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function56 (type $call29) (param $0 (ref null $type14)) (param $1 (ref null $type12)) (result (ref $type12))
  (local $2 (ref $type38))
  (local $3 (ref $type37))
  (local $4 (ref null $type12))
  (local $5 (ref null $type12))
  (local $6 (ref null $type12))
  (local $7 (ref null $type12))
  (local $8 (ref null $type12))
  (local $9 (ref null $type12))
  (local $10 (ref null $type12))
  (local $11 (ref null $type12))
  (local $12 (ref null $type12))
  (local $13 (ref null $type12))
  (local $scratch (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready148)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global148)
   )
  )
  (struct.set $type38 1
   (local.tee $2
    (struct.new_default $type38)
   )
   (struct.new $type37
    (ref.func $function59)
    (struct.new $environment59
     (local.get $2)
    )
   )
  )
  (struct.set $type38 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type38 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.new $type12
   (call_ref $call37
    (struct.get $type37 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type38 1
        (local.get $2)
       )
      )
     )
    )
    (local.get $0)
    (i64.const 0)
    (struct.get $type37 0
     (local.get $3)
    )
   )
   (if (result (ref null $type12))
    (ref.is_null
     (local.get $0)
    )
    (then
     (local.get $1)
    )
    (else
     (call $function54
      (struct.get $type14 0
       (local.get $0)
      )
      (block (result (ref null $type12))
       (if
        (i32.eqz
         (ref.is_null
          (local.tee $0
           (struct.get $type14 1
            (local.get $0)
           )
          )
         )
        )
        (then
         (local.set $1
          (call $function54
           (struct.get $type14 0
            (local.get $0)
           )
           (block (result (ref null $type12))
            (if
             (i32.eqz
              (ref.is_null
               (local.tee $0
                (struct.get $type14 1
                 (local.get $0)
                )
               )
              )
             )
             (then
              (local.set $1
               (call $function54
                (struct.get $type14 0
                 (local.get $0)
                )
                (block (result (ref null $type12))
                 (if
                  (i32.eqz
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type14 1
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (then
                   (local.set $1
                    (call $function54
                     (struct.get $type14 0
                      (local.get $0)
                     )
                     (block (result (ref null $type12))
                      (if
                       (i32.eqz
                        (ref.is_null
                         (local.tee $0
                          (struct.get $type14 1
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (then
                        (local.set $1
                         (call $function54
                          (struct.get $type14 0
                           (local.get $0)
                          )
                          (block (result (ref null $type12))
                           (if
                            (i32.eqz
                             (ref.is_null
                              (local.tee $0
                               (struct.get $type14 1
                                (local.get $0)
                               )
                              )
                             )
                            )
                            (then
                             (local.set $1
                              (call $function54
                               (struct.get $type14 0
                                (local.get $0)
                               )
                               (block (result (ref null $type12))
                                (if
                                 (i32.eqz
                                  (ref.is_null
                                   (local.tee $0
                                    (struct.get $type14 1
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.set $1
                                   (call $function54
                                    (struct.get $type14 0
                                     (local.get $0)
                                    )
                                    (block (result (ref null $type12))
                                     (if
                                      (i32.eqz
                                       (ref.is_null
                                        (local.tee $0
                                         (struct.get $type14 1
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                      (then
                                       (local.set $1
                                        (call $function54
                                         (struct.get $type14 0
                                          (local.get $0)
                                         )
                                         (block (result (ref null $type12))
                                          (if
                                           (i32.eqz
                                            (ref.is_null
                                             (local.tee $0
                                              (struct.get $type14 1
                                               (local.get $0)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (local.set $1
                                             (call $function54
                                              (struct.get $type14 0
                                               (local.get $0)
                                              )
                                              (block (result (ref null $type12))
                                               (if
                                                (i32.eqz
                                                 (ref.is_null
                                                  (local.tee $0
                                                   (struct.get $type14 1
                                                    (local.get $0)
                                                   )
                                                  )
                                                 )
                                                )
                                                (then
                                                 (local.set $1
                                                  (call $function54
                                                   (struct.get $type14 0
                                                    (local.get $0)
                                                   )
                                                   (block (result (ref null $type12))
                                                    (local.set $scratch
                                                     (call $function57
                                                      (local.get $1)
                                                      (i32.const 0)
                                                      (i32.const 1)
                                                      (struct.get $type14 1
                                                       (local.get $0)
                                                      )
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (global.get $ready137)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global137)
                                                     )
                                                    )
                                                    (local.get $scratch)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready137)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global137)
                                                )
                                               )
                                               (local.get $1)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready137)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global137)
                                           )
                                          )
                                          (local.get $1)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready137)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global137)
                                      )
                                     )
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready137)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global137)
                                 )
                                )
                                (local.get $1)
                               )
                              )
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready137)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global137)
                            )
                           )
                           (local.get $1)
                          )
                         )
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready137)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global137)
                       )
                      )
                      (local.get $1)
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready137)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global137)
                  )
                 )
                 (local.get $1)
                )
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready137)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global137)
             )
            )
            (local.get $1)
           )
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready137)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global137)
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function57 (type $5) (param $0 (ref null $type12)) (param $1 i32) (param $2 i32) (param $3 (ref null $type14)) (result (ref null $type12))
  (local $4 (ref null $type12))
  (local $scratch (ref null $type12))
  (if (result (ref null $type12))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (return_call $function54
     (struct.get $type14 0
      (local.get $3)
     )
     (block (result (ref null $type12))
      (local.set $3
       (struct.get $type14 1
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $scratch
       (call $function57
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (global.get $ready137)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global137)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function59 (type $call37) (param $0 (ref struct)) (param $1 (ref null $type14)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type14 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type38 0
       (struct.get $environment59 0
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function59
     (struct.get $type37 1
      (struct.get $type38 1
       (struct.get $environment59 0
        (ref.cast (ref $environment59)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function61 (type $call35) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type12)) (result (ref null $type12))
  (local $3 (ref null $type14))
  (local $4 (ref $type12))
  (if (result (ref $type12))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.new $type12
     (i64.extend_i32_u
      (array.len
       (struct.get $environment61 0
        (ref.cast (ref $environment61)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (call $function56
      (array.get $type24
       (struct.get $environment61 0
        (ref.cast (ref $environment61)
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (block (result (ref null $type12))
       (if
        (i32.eqz
         (global.get $ready143)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global143)
        )
       )
       (local.get $2)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment61 1
        (ref.cast (ref $environment61)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function61
     (struct.get $type35 1
      (struct.get $type36 1
       (struct.get $environment61 1
        (ref.cast (ref $environment61)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
  )
 )
 (func $function62 (result i64)
  (local $0 (ref null $type12))
  (local $1 (ref null $type12))
  (local $2 (ref $type36))
  (local $3 (ref $type35))
  (local $4 (ref $type12))
  (local $5 (ref $type14))
  (local $6 i64)
  (local $scratch (ref null $type12))
  (local $scratch_8 (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready159)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready94)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global94)
   )
  )
  (struct.set $type36 1
   (local.tee $2
    (struct.new_default $type36)
   )
   (struct.new $type35
    (ref.func $function38)
    (struct.new $environment38
     (local.get $2)
    )
   )
  )
  (struct.set $type36 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type36 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (call $function56
    (call $function40
     (block (result (ref null $type12))
      (local.set $scratch
       (call_ref $call35
        (struct.get $type35 1
         (local.tee $3
          (ref.as_non_null
           (struct.get $type36 1
            (local.get $2)
           )
          )
         )
        )
        (global.get $global159)
        (ref.null none)
        (struct.get $type35 0
         (local.get $3)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready101)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global101)
       )
      )
      (local.get $scratch)
     )
    )
    (block (result nullref)
     (if
      (i32.eqz
       (global.get $ready143)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global143)
      )
     )
     (ref.null none)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $6
   (call $foreign0)
  )
  (struct.set $type36 1
   (local.tee $2
    (struct.new_default $type36)
   )
   (struct.new $type35
    (ref.func $function26)
    (struct.new $environment26
     (local.get $2)
    )
   )
  )
  (struct.set $type36 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type36 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (call_ref $call35
    (struct.get $type35 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type36 1
        (local.get $2)
       )
      )
     )
    )
    (local.get $6)
    (ref.null none)
    (struct.get $type35 0
     (local.get $3)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $0)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type12 0
         (local.get $4)
        )
        (struct.get $type12 0
         (local.get $0)
        )
       )
       (then
        (local.set $0
         (struct.get $type12 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready65)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global65)
         )
        )
        (if (result i32)
         (ref.is_null
          (local.tee $1
           (struct.get $type12 1
            (local.get $4)
           )
          )
         )
         (then
          (ref.is_null
           (local.get $0)
          )
         )
         (else
          (if (result i32)
           (ref.is_null
            (local.get $0)
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (i64.eq
              (struct.get $type12 0
               (local.get $1)
              )
              (struct.get $type12 0
               (local.get $0)
              )
             )
             (then
              (local.set $1
               (struct.get $type12 1
                (local.get $1)
               )
              )
              (local.set $0
               (struct.get $type12 1
                (local.get $0)
               )
              )
              (if
               (i32.eqz
                (global.get $ready65)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global65)
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $1)
               )
               (then
                (ref.is_null
                 (local.get $0)
                )
               )
               (else
                (if (result i32)
                 (ref.is_null
                  (local.get $0)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if (result i32)
                   (i64.eq
                    (struct.get $type12 0
                     (local.get $1)
                    )
                    (struct.get $type12 0
                     (local.get $0)
                    )
                   )
                   (then
                    (local.set $1
                     (struct.get $type12 1
                      (local.get $1)
                     )
                    )
                    (local.set $0
                     (struct.get $type12 1
                      (local.get $0)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready65)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global65)
                     )
                    )
                    (if (result i32)
                     (ref.is_null
                      (local.get $1)
                     )
                     (then
                      (ref.is_null
                       (local.get $0)
                      )
                     )
                     (else
                      (if (result i32)
                       (ref.is_null
                        (local.get $0)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (i64.eq
                          (struct.get $type12 0
                           (local.get $1)
                          )
                          (struct.get $type12 0
                           (local.get $0)
                          )
                         )
                         (then
                          (local.set $1
                           (struct.get $type12 1
                            (local.get $1)
                           )
                          )
                          (local.set $0
                           (struct.get $type12 1
                            (local.get $0)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready65)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global65)
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $1)
                           )
                           (then
                            (ref.is_null
                             (local.get $0)
                            )
                           )
                           (else
                            (if (result i32)
                             (ref.is_null
                              (local.get $0)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if (result i32)
                               (i64.eq
                                (struct.get $type12 0
                                 (local.get $1)
                                )
                                (struct.get $type12 0
                                 (local.get $0)
                                )
                               )
                               (then
                                (local.set $1
                                 (struct.get $type12 1
                                  (local.get $1)
                                 )
                                )
                                (local.set $0
                                 (struct.get $type12 1
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready65)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global65)
                                 )
                                )
                                (if (result i32)
                                 (ref.is_null
                                  (local.get $1)
                                 )
                                 (then
                                  (ref.is_null
                                   (local.get $0)
                                  )
                                 )
                                 (else
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $0)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (i64.eq
                                      (struct.get $type12 0
                                       (local.get $1)
                                      )
                                      (struct.get $type12 0
                                       (local.get $0)
                                      )
                                     )
                                     (then
                                      (local.set $1
                                       (struct.get $type12 1
                                        (local.get $1)
                                       )
                                      )
                                      (local.set $0
                                       (struct.get $type12 1
                                        (local.get $0)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready65)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global65)
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $1)
                                       )
                                       (then
                                        (ref.is_null
                                         (local.get $0)
                                        )
                                       )
                                       (else
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $0)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (if (result i32)
                                           (i64.eq
                                            (struct.get $type12 0
                                             (local.get $1)
                                            )
                                            (struct.get $type12 0
                                             (local.get $0)
                                            )
                                           )
                                           (then
                                            (local.set $1
                                             (struct.get $type12 1
                                              (local.get $1)
                                             )
                                            )
                                            (local.set $0
                                             (struct.get $type12 1
                                              (local.get $0)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready65)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global65)
                                             )
                                            )
                                            (if (result i32)
                                             (ref.is_null
                                              (local.get $1)
                                             )
                                             (then
                                              (ref.is_null
                                               (local.get $0)
                                              )
                                             )
                                             (else
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $0)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (if (result i32)
                                                 (i64.eq
                                                  (struct.get $type12 0
                                                   (local.get $1)
                                                  )
                                                  (struct.get $type12 0
                                                   (local.get $0)
                                                  )
                                                 )
                                                 (then
                                                  (local.set $1
                                                   (struct.get $type12 1
                                                    (local.get $1)
                                                   )
                                                  )
                                                  (local.set $0
                                                   (struct.get $type12 1
                                                    (local.get $0)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready65)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global65)
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $1)
                                                   )
                                                   (then
                                                    (ref.is_null
                                                     (local.get $0)
                                                    )
                                                   )
                                                   (else
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $0)
                                                     )
                                                     (then
                                                      (i32.const 0)
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (i64.eq
                                                        (struct.get $type12 0
                                                         (local.get $1)
                                                        )
                                                        (struct.get $type12 0
                                                         (local.get $0)
                                                        )
                                                       )
                                                       (then
                                                        (local.set $1
                                                         (struct.get $type12 1
                                                          (local.get $1)
                                                         )
                                                        )
                                                        (local.set $0
                                                         (struct.get $type12 1
                                                          (local.get $0)
                                                         )
                                                        )
                                                        (if
                                                         (i32.eqz
                                                          (global.get $ready65)
                                                         )
                                                         (then
                                                          (unreachable)
                                                         )
                                                        )
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global65)
                                                         )
                                                        )
                                                        (if (result i32)
                                                         (ref.is_null
                                                          (local.get $1)
                                                         )
                                                         (then
                                                          (ref.is_null
                                                           (local.get $0)
                                                          )
                                                         )
                                                         (else
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $0)
                                                           )
                                                           (then
                                                            (i32.const 0)
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (i64.eq
                                                              (struct.get $type12 0
                                                               (local.get $1)
                                                              )
                                                              (struct.get $type12 0
                                                               (local.get $0)
                                                              )
                                                             )
                                                             (then
                                                              (call $function27
                                                               (struct.get $type12 1
                                                                (local.get $1)
                                                               )
                                                               (block (result (ref null $type12))
                                                                (local.set $scratch_8
                                                                 (struct.get $type12 1
                                                                  (local.get $0)
                                                                 )
                                                                )
                                                                (if
                                                                 (i32.eqz
                                                                  (global.get $ready65)
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global65)
                                                                 )
                                                                )
                                                                (local.get $scratch_8)
                                                               )
                                                              )
                                                             )
                                                             (else
                                                              (i32.const 0)
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                       (else
                                                        (i32.const 0)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (i32.const 0)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (else
                                            (i32.const 0)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (i32.const 0)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (i32.const 0)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function63 (type $call34) (param $0 i64) (result i64)
  (local $1 (ref null $type12))
  (local $2 (ref null $type12))
  (local $3 (ref $type36))
  (local $4 (ref $type35))
  (local $5 (ref $type49))
  (local $6 (ref $type41))
  (local $7 (ref $type24))
  (local $scratch (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready159)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready160)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global166)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (local.set $5
   (struct.new $type49
    (i32.const 1)
    (call $function32
     (local.get $0)
     (global.get $global159)
     (global.get $global160)
     (global.get $global161)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready153)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global153)
   )
  )
  (struct.set $type36 1
   (local.tee $3
    (struct.new_default $type36)
   )
   (struct.new $type35
    (ref.func $function61)
    (struct.new $environment61
     (local.tee $7
      (struct.get $type41 1
       (local.tee $6
        (struct.new $type41
         (i32.const 1)
         (struct.get $type23 0
          (struct.get $type49 1
           (local.get $5)
          )
         )
        )
       )
      )
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type36 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type36 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call_ref $call35
    (struct.get $type35 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type36 1
        (local.get $3)
       )
      )
     )
    )
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $7)
      )
     )
     (i64.const 1)
    )
    (ref.null none)
    (struct.get $type35 0
     (local.get $4)
    )
   )
  )
  (struct.set $type36 1
   (local.tee $3
    (struct.new_default $type36)
   )
   (struct.new $type35
    (ref.func $function65)
    (struct.new $environment65
     (local.get $5)
     (local.get $6)
     (struct.new $type50
      (i32.const 1)
      (struct.get $type23 1
       (struct.get $type49 1
        (local.get $5)
       )
      )
     )
     (local.get $3)
    )
   )
  )
  (struct.set $type36 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type36 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call_ref $call35
    (struct.get $type35 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type36 1
        (local.get $3)
       )
      )
     )
    )
    (local.get $0)
    (local.get $1)
    (struct.get $type35 0
     (local.get $4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $0
   (call $foreign0)
  )
  (struct.set $type36 1
   (local.tee $3
    (struct.new_default $type36)
   )
   (struct.new $type35
    (ref.func $function26)
    (struct.new $environment26
     (local.get $3)
    )
   )
  )
  (struct.set $type36 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type36 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call_ref $call35
    (struct.get $type35 1
     (local.tee $4
      (ref.as_non_null
       (struct.get $type36 1
        (local.get $3)
       )
      )
     )
    )
    (local.get $0)
    (ref.null none)
    (struct.get $type35 0
     (local.get $4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (ref.is_null
       (local.get $1)
      )
     )
     (else
      (if (result i32)
       (ref.is_null
        (local.get $1)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i64.eq
          (struct.get $type12 0
           (local.get $2)
          )
          (struct.get $type12 0
           (local.get $1)
          )
         )
         (then
          (local.set $2
           (struct.get $type12 1
            (local.get $2)
           )
          )
          (local.set $1
           (struct.get $type12 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready65)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global65)
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (ref.is_null
             (local.get $1)
            )
           )
           (else
            (if (result i32)
             (ref.is_null
              (local.get $1)
             )
             (then
              (i32.const 0)
             )
             (else
              (if (result i32)
               (i64.eq
                (struct.get $type12 0
                 (local.get $2)
                )
                (struct.get $type12 0
                 (local.get $1)
                )
               )
               (then
                (local.set $2
                 (struct.get $type12 1
                  (local.get $2)
                 )
                )
                (local.set $1
                 (struct.get $type12 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready65)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global65)
                 )
                )
                (if (result i32)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (ref.is_null
                   (local.get $1)
                  )
                 )
                 (else
                  (if (result i32)
                   (ref.is_null
                    (local.get $1)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (i64.eq
                      (struct.get $type12 0
                       (local.get $2)
                      )
                      (struct.get $type12 0
                       (local.get $1)
                      )
                     )
                     (then
                      (local.set $2
                       (struct.get $type12 1
                        (local.get $2)
                       )
                      )
                      (local.set $1
                       (struct.get $type12 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready65)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global65)
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (ref.is_null
                         (local.get $1)
                        )
                       )
                       (else
                        (if (result i32)
                         (ref.is_null
                          (local.get $1)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if (result i32)
                           (i64.eq
                            (struct.get $type12 0
                             (local.get $2)
                            )
                            (struct.get $type12 0
                             (local.get $1)
                            )
                           )
                           (then
                            (local.set $2
                             (struct.get $type12 1
                              (local.get $2)
                             )
                            )
                            (local.set $1
                             (struct.get $type12 1
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready65)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global65)
                             )
                            )
                            (if (result i32)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (ref.is_null
                               (local.get $1)
                              )
                             )
                             (else
                              (if (result i32)
                               (ref.is_null
                                (local.get $1)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (i64.eq
                                  (struct.get $type12 0
                                   (local.get $2)
                                  )
                                  (struct.get $type12 0
                                   (local.get $1)
                                  )
                                 )
                                 (then
                                  (local.set $2
                                   (struct.get $type12 1
                                    (local.get $2)
                                   )
                                  )
                                  (local.set $1
                                   (struct.get $type12 1
                                    (local.get $1)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready65)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global65)
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                   )
                                   (else
                                    (if (result i32)
                                     (ref.is_null
                                      (local.get $1)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if (result i32)
                                       (i64.eq
                                        (struct.get $type12 0
                                         (local.get $2)
                                        )
                                        (struct.get $type12 0
                                         (local.get $1)
                                        )
                                       )
                                       (then
                                        (local.set $2
                                         (struct.get $type12 1
                                          (local.get $2)
                                         )
                                        )
                                        (local.set $1
                                         (struct.get $type12 1
                                          (local.get $1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready65)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global65)
                                         )
                                        )
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                         (then
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                         )
                                         (else
                                          (if (result i32)
                                           (ref.is_null
                                            (local.get $1)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (if (result i32)
                                             (i64.eq
                                              (struct.get $type12 0
                                               (local.get $2)
                                              )
                                              (struct.get $type12 0
                                               (local.get $1)
                                              )
                                             )
                                             (then
                                              (local.set $2
                                               (struct.get $type12 1
                                                (local.get $2)
                                               )
                                              )
                                              (local.set $1
                                               (struct.get $type12 1
                                                (local.get $1)
                                               )
                                              )
                                              (if
                                               (i32.eqz
                                                (global.get $ready65)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global65)
                                               )
                                              )
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (ref.is_null
                                                 (local.get $1)
                                                )
                                               )
                                               (else
                                                (if (result i32)
                                                 (ref.is_null
                                                  (local.get $1)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (if (result i32)
                                                   (i64.eq
                                                    (struct.get $type12 0
                                                     (local.get $2)
                                                    )
                                                    (struct.get $type12 0
                                                     (local.get $1)
                                                    )
                                                   )
                                                   (then
                                                    (local.set $2
                                                     (struct.get $type12 1
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (local.set $1
                                                     (struct.get $type12 1
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (if
                                                     (i32.eqz
                                                      (global.get $ready65)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global65)
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                     (then
                                                      (ref.is_null
                                                       (local.get $1)
                                                      )
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (ref.is_null
                                                        (local.get $1)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (if (result i32)
                                                         (i64.eq
                                                          (struct.get $type12 0
                                                           (local.get $2)
                                                          )
                                                          (struct.get $type12 0
                                                           (local.get $1)
                                                          )
                                                         )
                                                         (then
                                                          (local.set $2
                                                           (struct.get $type12 1
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (local.set $1
                                                           (struct.get $type12 1
                                                            (local.get $1)
                                                           )
                                                          )
                                                          (if
                                                           (i32.eqz
                                                            (global.get $ready65)
                                                           )
                                                           (then
                                                            (unreachable)
                                                           )
                                                          )
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global65)
                                                           )
                                                          )
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                           (then
                                                            (ref.is_null
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (ref.is_null
                                                              (local.get $1)
                                                             )
                                                             (then
                                                              (i32.const 0)
                                                             )
                                                             (else
                                                              (if (result i32)
                                                               (i64.eq
                                                                (struct.get $type12 0
                                                                 (local.get $2)
                                                                )
                                                                (struct.get $type12 0
                                                                 (local.get $1)
                                                                )
                                                               )
                                                               (then
                                                                (call $function27
                                                                 (struct.get $type12 1
                                                                  (local.get $2)
                                                                 )
                                                                 (block (result (ref null $type12))
                                                                  (local.set $scratch
                                                                   (struct.get $type12 1
                                                                    (local.get $1)
                                                                   )
                                                                  )
                                                                  (if
                                                                   (i32.eqz
                                                                    (global.get $ready65)
                                                                   )
                                                                   (then
                                                                    (unreachable)
                                                                   )
                                                                  )
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global65)
                                                                   )
                                                                  )
                                                                  (local.get $scratch)
                                                                 )
                                                                )
                                                               )
                                                               (else
                                                                (i32.const 0)
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                         (else
                                                          (i32.const 0)
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (else
                                                    (i32.const 0)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (else
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (i32.const 0)
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (i32.const 0)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function65 (type $call35) (param $0 (ref struct)) (param $1 i64) (param $2 (ref null $type12)) (result (ref null $type12))
  (local $3 (ref null $type12))
  (local $4 (ref $type12))
  (local $5 (ref $environment65))
  (local $6 (ref $type24))
  (local $7 (ref $type36))
  (local $8 (ref $type35))
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.set $6
     (struct.get $type41 1
      (struct.get $environment65 1
       (local.tee $5
        (ref.cast (ref $environment65)
         (local.get $0)
        )
       )
      )
     )
    )
    (local.set $4
     (struct.new $type12
      (i64.extend_i32_u
       (i32.ne
        (call $function49
         (struct.get $type26 0
          (struct.get $type23 2
           (struct.get $type49 1
            (struct.get $environment65 0
             (local.get $5)
            )
           )
          )
         )
         (local.get $6)
        )
        (i32.const 0)
       )
      )
      (block (result nullref)
       (if
        (i32.eqz
         (global.get $ready177)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global177)
        )
       )
       (ref.null none)
      )
     )
    )
    (if (result (ref $type12))
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $4)
     )
     (else
      (struct.new $type12
       (struct.get $type12 0
        (local.get $2)
       )
       (block (result (ref $type12))
        (local.set $2
         (struct.get $type12 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (global.get $ready177)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global177)
         )
        )
        (if (result (ref $type12))
         (ref.is_null
          (local.get $2)
         )
         (then
          (local.get $4)
         )
         (else
          (struct.new $type12
           (struct.get $type12 0
            (local.get $2)
           )
           (block (result (ref $type12))
            (local.set $2
             (struct.get $type12 1
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready177)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global177)
             )
            )
            (if (result (ref $type12))
             (ref.is_null
              (local.get $2)
             )
             (then
              (local.get $4)
             )
             (else
              (struct.new $type12
               (struct.get $type12 0
                (local.get $2)
               )
               (block (result (ref $type12))
                (local.set $2
                 (struct.get $type12 1
                  (local.get $2)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready177)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global177)
                 )
                )
                (if (result (ref $type12))
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (local.get $4)
                 )
                 (else
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $2)
                   )
                   (block (result (ref $type12))
                    (local.set $2
                     (struct.get $type12 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready177)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global177)
                     )
                    )
                    (if (result (ref $type12))
                     (ref.is_null
                      (local.get $2)
                     )
                     (then
                      (local.get $4)
                     )
                     (else
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $2)
                       )
                       (block (result (ref $type12))
                        (local.set $2
                         (struct.get $type12 1
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready177)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global177)
                         )
                        )
                        (if (result (ref $type12))
                         (ref.is_null
                          (local.get $2)
                         )
                         (then
                          (local.get $4)
                         )
                         (else
                          (struct.new $type12
                           (struct.get $type12 0
                            (local.get $2)
                           )
                           (block (result (ref $type12))
                            (local.set $2
                             (struct.get $type12 1
                              (local.get $2)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready177)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global177)
                             )
                            )
                            (if (result (ref $type12))
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (local.get $4)
                             )
                             (else
                              (struct.new $type12
                               (struct.get $type12 0
                                (local.get $2)
                               )
                               (block (result (ref $type12))
                                (local.set $2
                                 (struct.get $type12 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready177)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global177)
                                 )
                                )
                                (if (result (ref $type12))
                                 (ref.is_null
                                  (local.get $2)
                                 )
                                 (then
                                  (local.get $4)
                                 )
                                 (else
                                  (struct.new $type12
                                   (struct.get $type12 0
                                    (local.get $2)
                                   )
                                   (block (result (ref $type12))
                                    (local.set $2
                                     (struct.get $type12 1
                                      (local.get $2)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready177)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global177)
                                     )
                                    )
                                    (if (result (ref $type12))
                                     (ref.is_null
                                      (local.get $2)
                                     )
                                     (then
                                      (local.get $4)
                                     )
                                     (else
                                      (struct.new $type12
                                       (struct.get $type12 0
                                        (local.get $2)
                                       )
                                       (block (result (ref $type12))
                                        (local.set $2
                                         (struct.get $type12 1
                                          (local.get $2)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready177)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global177)
                                         )
                                        )
                                        (if (result (ref $type12))
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                         (then
                                          (local.get $4)
                                         )
                                         (else
                                          (struct.new $type12
                                           (struct.get $type12 0
                                            (local.get $2)
                                           )
                                           (call $function66
                                            (struct.get $type12 1
                                             (local.get $2)
                                            )
                                            (block (result (ref $type12))
                                             (if
                                              (i32.eqz
                                               (global.get $ready177)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global177)
                                              )
                                             )
                                             (local.get $4)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (if (result (ref null $type12))
     (ref.eq
      (local.tee $6
       (call $function48
        (struct.get $type25 0
         (struct.get $type50 1
          (struct.get $environment65 2
           (local.tee $5
            (ref.cast (ref $environment65)
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (struct.get $type41 1
       (struct.get $environment65 1
        (local.get $5)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready153)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global153)
       )
      )
      (struct.set $type36 1
       (local.tee $7
        (struct.new_default $type36)
       )
       (struct.new $type35
        (ref.func $function61)
        (struct.new $environment61
         (local.get $6)
         (local.get $7)
        )
       )
      )
      (struct.set $type36 0
       (local.get $7)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type36 0
         (local.get $7)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call_ref $call35
        (struct.get $type35 1
         (local.tee $8
          (ref.as_non_null
           (struct.get $type36 1
            (local.get $7)
           )
          )
         )
        )
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $6)
          )
         )
         (i64.const 1)
        )
        (ref.null none)
        (struct.get $type35 0
         (local.get $8)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type36 0
         (struct.get $environment65 3
          (local.get $5)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $function65
        (struct.get $type35 1
         (struct.get $type36 1
          (struct.get $environment65 3
           (local.get $5)
          )
         )
        )
        (i64.sub
         (local.get $1)
         (i64.const 1)
        )
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (global.get $ready177)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global177)
       )
      )
      (if (result (ref null $type12))
       (ref.is_null
        (local.get $2)
       )
       (then
        (local.get $3)
       )
       (else
        (struct.new $type12
         (struct.get $type12 0
          (local.get $2)
         )
         (block (result (ref null $type12))
          (local.set $2
           (struct.get $type12 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (global.get $ready177)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global177)
           )
          )
          (if (result (ref null $type12))
           (ref.is_null
            (local.get $2)
           )
           (then
            (local.get $3)
           )
           (else
            (struct.new $type12
             (struct.get $type12 0
              (local.get $2)
             )
             (block (result (ref null $type12))
              (local.set $2
               (struct.get $type12 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (global.get $ready177)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global177)
               )
              )
              (if (result (ref null $type12))
               (ref.is_null
                (local.get $2)
               )
               (then
                (local.get $3)
               )
               (else
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $2)
                 )
                 (block (result (ref null $type12))
                  (local.set $2
                   (struct.get $type12 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready177)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global177)
                   )
                  )
                  (if (result (ref null $type12))
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (local.get $3)
                   )
                   (else
                    (struct.new $type12
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (block (result (ref null $type12))
                      (local.set $2
                       (struct.get $type12 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready177)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global177)
                       )
                      )
                      (if (result (ref null $type12))
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (local.get $3)
                       )
                       (else
                        (struct.new $type12
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (block (result (ref null $type12))
                          (local.set $2
                           (struct.get $type12 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready177)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global177)
                           )
                          )
                          (if (result (ref null $type12))
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (local.get $3)
                           )
                           (else
                            (struct.new $type12
                             (struct.get $type12 0
                              (local.get $2)
                             )
                             (block (result (ref null $type12))
                              (local.set $2
                               (struct.get $type12 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready177)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global177)
                               )
                              )
                              (if (result (ref null $type12))
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (local.get $3)
                               )
                               (else
                                (struct.new $type12
                                 (struct.get $type12 0
                                  (local.get $2)
                                 )
                                 (block (result (ref null $type12))
                                  (local.set $2
                                   (struct.get $type12 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (global.get $ready177)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global177)
                                   )
                                  )
                                  (if (result (ref null $type12))
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (local.get $3)
                                   )
                                   (else
                                    (struct.new $type12
                                     (struct.get $type12 0
                                      (local.get $2)
                                     )
                                     (block (result (ref null $type12))
                                      (local.set $2
                                       (struct.get $type12 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready177)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global177)
                                       )
                                      )
                                      (if (result (ref null $type12))
                                       (ref.is_null
                                        (local.get $2)
                                       )
                                       (then
                                        (local.get $3)
                                       )
                                       (else
                                        (struct.new $type12
                                         (struct.get $type12 0
                                          (local.get $2)
                                         )
                                         (block (result (ref null $type12))
                                          (local.set $2
                                           (struct.get $type12 1
                                            (local.get $2)
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready177)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global177)
                                           )
                                          )
                                          (if (result (ref null $type12))
                                           (ref.is_null
                                            (local.get $2)
                                           )
                                           (then
                                            (local.get $3)
                                           )
                                           (else
                                            (struct.new $type12
                                             (struct.get $type12 0
                                              (local.get $2)
                                             )
                                             (call $function66
                                              (struct.get $type12 1
                                               (local.get $2)
                                              )
                                              (block (result (ref null $type12))
                                               (if
                                                (i32.eqz
                                                 (global.get $ready177)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global177)
                                                )
                                               )
                                               (local.get $3)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (unreachable)
     )
    )
   )
  )
 )
 (func $function66 (type $call28) (param $0 (ref null $type12)) (param $1 (ref null $type12)) (result (ref null $type12))
  (local $2 i64)
  (if (result (ref null $type12))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (struct.new $type12
     (struct.get $type12 0
      (local.get $0)
     )
     (call $function66
      (struct.get $type12 1
       (local.get $0)
      )
      (block (result (ref null $type12))
       (if
        (i32.eqz
         (global.get $ready177)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global177)
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready162)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global162)
   )
  )
  (return_call $function62)
 )
 (func $export1 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready164)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global164)
   )
  )
  (return_call $function63
   (local.get $0)
  )
 )
 (func $export2 (param $0 i64) (result i64)
  (local $1 i64)
  (local $2 i64)
  (local $3 (ref null $type12))
  (local $4 (ref $type24))
  (local $5 (ref null $type14))
  (local $6 (ref $type36))
  (local $7 (ref $type23))
  (local $8 (ref $type35))
  (local $scratch (ref null $type12))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready181)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global181)
   )
  )
  (if
   (i32.eqz
    (global.get $ready159)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready160)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global79)
   )
  )
  (local.set $5
   (array.get $type24
    (local.tee $4
     (call $function48
      (struct.get $type25 0
       (struct.get $type23 1
        (local.tee $7
         (call $function32
          (i64.const 1)
          (global.get $global159)
          (local.tee $1
           (global.get $global160)
          )
          (local.tee $2
           (global.get $global161)
          )
         )
        )
       )
      )
     )
    )
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready128)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global128)
   )
  )
  (local.set $1
   (select
    (local.tee $1
     (i64.sub
      (i64.sub
       (local.get $1)
       (local.get $2)
      )
      (i64.const 1)
     )
    )
    (i64.const 0)
    (i64.ge_s
     (local.get $1)
     (i64.const 0)
    )
   )
  )
  (if
   (i64.eq
    (local.get $0)
    (i64.const 1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready192)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global192)
     )
    )
    (array.set $type24
     (local.get $4)
     (i32.const 0)
     (struct.new $type14
      (struct.get $type14 0
       (local.get $5)
      )
      (struct.new $type14
       (struct.new $type12
        (i64.add
         (struct.get $type12 0
          (local.tee $3
           (struct.get $type14 0
            (local.tee $5
             (struct.get $type14 1
              (local.get $5)
             )
            )
           )
          )
         )
         (i64.const 1)
        )
        (struct.get $type12 1
         (local.get $3)
        )
       )
       (struct.get $type14 1
        (local.get $5)
       )
      )
     )
    )
   )
   (else
    (if
     (i64.eq
      (local.get $0)
      (i64.const 2)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready194)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global194)
       )
      )
      (array.set $type24
       (local.get $4)
       (i32.const 0)
       (struct.new $type14
        (struct.new $type12
         (struct.get $type12 0
          (struct.get $type12 1
           (local.tee $3
            (struct.get $type14 0
             (local.get $5)
            )
           )
          )
         )
         (struct.new $type12
          (struct.get $type12 0
           (local.get $3)
          )
          (struct.get $type12 1
           (struct.get $type12 1
            (local.get $3)
           )
          )
         )
        )
        (struct.get $type14 1
         (local.get $5)
        )
       )
      )
     )
     (else
      (if
       (i64.eq
        (local.get $0)
        (i64.const 3)
       )
       (then
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type24
         (local.get $4)
         (i32.wrap_i64
          (local.get $1)
         )
         (ref.null none)
        )
       )
       (else
        (if
         (i64.eq
          (local.get $0)
          (i64.const 4)
         )
         (then
          (array.set $type24
           (local.get $4)
           (i32.const 0)
           (ref.null none)
          )
         )
         (else
          (if
           (i64.eq
            (local.get $0)
            (i64.const 5)
           )
           (then
            (array.set $type24
             (local.get $4)
             (i32.const 0)
             (ref.null none)
            )
            (if
             (i64.gt_u
              (local.get $1)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (array.set $type24
             (local.get $4)
             (i32.wrap_i64
              (local.get $1)
             )
             (ref.null none)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.set $0
   (i64.extend_i32_u
    (i32.ne
     (call $function49
      (struct.get $type26 0
       (struct.get $type23 2
        (local.get $7)
       )
      )
      (local.get $4)
     )
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $1
   (call $foreign0)
  )
  (struct.set $type36 1
   (local.tee $6
    (struct.new_default $type36)
   )
   (struct.new $type35
    (ref.func $function26)
    (struct.new $environment26
     (local.get $6)
    )
   )
  )
  (struct.set $type36 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type36 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (call_ref $call35
    (struct.get $type35 1
     (local.tee $8
      (ref.as_non_null
       (struct.get $type36 1
        (local.get $6)
       )
      )
     )
    )
    (local.get $1)
    (ref.null none)
    (struct.get $type35 0
     (local.get $8)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $3)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type12 0
         (local.get $3)
        )
        (local.get $0)
       )
       (then
        (ref.is_null
         (block (result (ref null $type12))
          (local.set $scratch
           (struct.get $type12 1
            (local.get $3)
           )
          )
          (if
           (i32.eqz
            (global.get $ready65)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global65)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global105
   (struct.new_default $type11)
  )
  (global.set $ready105
   (i32.const 1)
  )
  (global.set $global148
   (struct.new_default $type13)
  )
  (global.set $ready148
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type15)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global65
   (struct.new_default $type16)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global99
   (struct.new_default $type17)
  )
  (global.set $ready99
   (i32.const 1)
  )
  (global.set $global84
   (struct.new_default $type17)
  )
  (global.set $ready84
   (i32.const 1)
  )
  (global.set $global128
   (struct.new_default $type18)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global132
   (struct.new_default $type19)
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global134
   (struct.new_default $type16)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $global101
   (struct.new_default $type20)
  )
  (global.set $ready101
   (i32.const 1)
  )
  (global.set $global68
   (struct.new_default $type13)
  )
  (global.set $ready68
   (i32.const 1)
  )
  (global.set $global94
   (struct.new_default $type21)
  )
  (global.set $ready94
   (i32.const 1)
  )
  (global.set $global79
   (struct.new_default $type27)
  )
  (global.set $ready79
   (i32.const 1)
  )
  (global.set $global140
   (struct.new_default $type28)
  )
  (global.set $ready140
   (i32.const 1)
  )
  (global.set $global137
   (struct.new_default $type28)
  )
  (global.set $ready137
   (i32.const 1)
  )
  (global.set $global143
   (struct.new_default $type29)
  )
  (global.set $ready143
   (i32.const 1)
  )
  (global.set $global153
   (struct.new_default $type30)
  )
  (global.set $ready153
   (i32.const 1)
  )
  (global.set $global166
   (struct.new_default $type31)
  )
  (global.set $ready166
   (i32.const 1)
  )
  (global.set $global177
   (struct.new_default $type28)
  )
  (global.set $ready177
   (i32.const 1)
  )
  (global.set $global192
   (struct.new_default $type32)
  )
  (global.set $ready192
   (i32.const 1)
  )
  (global.set $global194
   (struct.new_default $type32)
  )
  (global.set $ready194
   (i32.const 1)
  )
  (global.set $global183
   (struct.new_default $type33)
  )
  (global.set $ready183
   (i32.const 1)
  )
  (global.set $global159
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global160
   (call $foreign2
    (i32.const 1)
   )
  )
  (global.set $ready160
   (i32.const 1)
  )
  (global.set $global161
   (call $foreign2
    (i32.const 2)
   )
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global162
   (struct.new_default $type34)
  )
  (global.set $ready162
   (i32.const 1)
  )
  (global.set $global164
   (struct.new_default $type34)
  )
  (global.set $ready164
   (i32.const 1)
  )
  (global.set $global181
   (struct.new_default $type34)
  )
  (global.set $ready181
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

