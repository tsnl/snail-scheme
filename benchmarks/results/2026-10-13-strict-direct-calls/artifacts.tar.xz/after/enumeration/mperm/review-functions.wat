;; optimized source line 362
(func $function33 (type $27) (param $0 i64) (param $1 (ref $type33)) (param $2 (ref $type34)) (param $3 i64) (param $4 i64) (result i32)
  (local $5 (ref $environment35))
  (local $6 (ref $type12))
  (local $7 (ref $type38))
  (local $8 (ref $type32))
  (local $9 (ref $type36))
  (local $10 (ref null $type12))
  (local $11 (ref null $type12))
  (local $12 (ref $type41))
  (local $13 (ref $type39))
  (local $14 (ref $type34))
  (local $15 (ref $type31))
  (local $16 (ref $type35))
  (local $17 i64)
  (local $18 i64)
  (if (result i32)
   (i64.lt_s
    (local.get $3)
    (local.get $4)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global87)
     )
    )
    (struct.set $type38 1
     (local.tee $7
      (struct.new_default $type38)
     )
     (struct.new $type37
      (struct.new $environment35
       (local.get $7)
      )
     )
    )
    (struct.set $type38 0
     (local.get $7)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type38 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type37 0
      (struct.get $type38 1
       (local.get $7)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (local.set $10
     (if (result (ref null $type12))
      (i64.eqz
       (local.get $0)
      )
      (then
       (ref.null none)
      )
      (else
       (if
        (i32.eqz
         (struct.get $type38 0
          (struct.get $environment35 0
           (local.get $5)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $5
        (struct.get $type37 0
         (struct.get $type38 1
          (struct.get $environment35 0
           (local.get $5)
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready92)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global92)
        )
       )
       (local.set $6
        (struct.new $type12
         (local.get $0)
         (ref.null none)
        )
       )
       (if (result (ref null $type12))
        (i64.eqz
         (local.tee $17
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $6)
        )
        (else
         (if
          (i32.eqz
           (struct.get $type38 0
            (struct.get $environment35 0
             (local.get $5)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $5
          (struct.get $type37 0
           (struct.get $type38 1
            (struct.get $environment35 0
             (local.get $5)
            )
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready92)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global92)
          )
         )
         (local.set $6
          (struct.new $type12
           (local.get $17)
           (local.get $6)
          )
         )
         (if (result (ref null $type12))
          (i64.eqz
           (local.tee $17
            (i64.sub
             (local.get $17)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $6)
          )
          (else
           (if
            (i32.eqz
             (struct.get $type38 0
              (struct.get $environment35 0
               (local.get $5)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (struct.get $type37 0
             (struct.get $type38 1
              (struct.get $environment35 0
               (local.get $5)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (local.set $6
            (struct.new $type12
             (local.get $17)
             (local.get $6)
            )
           )
           (if (result (ref null $type12))
            (i64.eqz
             (local.tee $17
              (i64.sub
               (local.get $17)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $6)
            )
            (else
             (if
              (i32.eqz
               (struct.get $type38 0
                (struct.get $environment35 0
                 (local.get $5)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $5
              (struct.get $type37 0
               (struct.get $type38 1
                (struct.get $environment35 0
                 (local.get $5)
                )
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (local.set $6
              (struct.new $type12
               (local.get $17)
               (local.get $6)
              )
             )
             (if (result (ref null $type12))
              (i64.eqz
               (local.tee $17
                (i64.sub
                 (local.get $17)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $6)
              )
              (else
               (if
                (i32.eqz
                 (struct.get $type38 0
                  (struct.get $environment35 0
                   (local.get $5)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $5
                (struct.get $type37 0
                 (struct.get $type38 1
                  (struct.get $environment35 0
                   (local.get $5)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (local.set $6
                (struct.new $type12
                 (local.get $17)
                 (local.get $6)
                )
               )
               (if (result (ref null $type12))
                (i64.eqz
                 (local.tee $17
                  (i64.sub
                   (local.get $17)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $6)
                )
                (else
                 (if
                  (i32.eqz
                   (struct.get $type38 0
                    (struct.get $environment35 0
                     (local.get $5)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $5
                  (struct.get $type37 0
                   (struct.get $type38 1
                    (struct.get $environment35 0
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (local.set $6
                  (struct.new $type12
                   (local.get $17)
                   (local.get $6)
                  )
                 )
                 (if (result (ref null $type12))
                  (i64.eqz
                   (local.tee $17
                    (i64.sub
                     (local.get $17)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (if
                    (i32.eqz
                     (struct.get $type38 0
                      (struct.get $environment35 0
                       (local.get $5)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $5
                    (struct.get $type37 0
                     (struct.get $type38 1
                      (struct.get $environment35 0
                       (local.get $5)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (local.set $6
                    (struct.new $type12
                     (local.get $17)
                     (local.get $6)
                    )
                   )
                   (if (result (ref null $type12))
                    (i64.eqz
                     (local.tee $18
                      (i64.sub
                       (local.get $17)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $6)
                    )
                    (else
                     (if
                      (i32.eqz
                       (struct.get $type38 0
                        (struct.get $environment35 0
                         (local.get $5)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $5
                      (struct.get $type37 0
                       (struct.get $type38 1
                        (struct.get $environment35 0
                         (local.get $5)
                        )
                       )
                      )
                     )
                     (local.set $17
                      (i64.sub
                       (local.get $18)
                       (i64.const 1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (local.set $6
                      (struct.new $type12
                       (local.get $18)
                       (local.get $6)
                      )
                     )
                     (if (result (ref null $type12))
                      (i64.eqz
                       (local.get $17)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (if
                        (i32.eqz
                         (struct.get $type38 0
                          (struct.get $environment35 0
                           (local.get $5)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (call $function35
                        (struct.get $type37 0
                         (struct.get $type38 1
                          (struct.get $environment35 0
                           (local.get $5)
                          )
                         )
                        )
                        (i64.sub
                         (local.get $17)
                         (i64.const 1)
                        )
                        (struct.new $type12
                         (local.get $17)
                         (local.get $6)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready94)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global94)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (local.set $11
     (struct.get $type40 0
      (struct.get $type39 1
       (local.tee $13
        (struct.new $type39
         (i32.const 1)
         (struct.new $type40
          (local.get $10)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (struct.set $type32 1
     (local.tee $8
      (struct.new_default $type32)
     )
     (struct.new $type31
      (ref.func $function39)
      (struct.new $environment39
       (local.get $8)
      )
     )
    )
    (struct.set $type32 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type32 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $14
     (struct.new $type34
      (i32.const 1)
     )
    )
    (local.set $12
     (struct.new $type41
      (i32.const 1)
      (struct.new $type42
       (struct.new $type16
        (local.get $10)
        (ref.null none)
       )
      )
     )
    )
    (drop
     (if (result i32)
      (i64.gt_s
       (local.tee $17
        (call_ref $call31
         (struct.get $type31 1
          (local.tee $15
           (ref.as_non_null
            (struct.get $type32 1
             (local.get $8)
            )
           )
          )
         )
         (local.get $11)
         (i64.const 0)
         (struct.get $type31 0
          (local.get $15)
         )
        )
       )
       (i64.const 1)
      )
      (then
       (struct.set $type36 1
        (local.tee $9
         (struct.new_default $type36)
        )
        (struct.new $type35
         (ref.func $function41)
         (struct.new $environment41
          (local.get $13)
          (local.get $12)
          (local.get $14)
          (local.get $17)
          (local.get $9)
          (struct.new $type34
           (i32.const 1)
          )
          (struct.new $type34
           (i32.const 1)
          )
          (struct.new $type34
           (i32.const 1)
          )
         )
        )
       )
       (struct.set $type36 0
        (local.get $9)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type36 0
          (local.get $9)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call35
        (struct.get $type35 1
         (local.tee $16
          (ref.as_non_null
           (struct.get $type36 1
            (local.get $9)
           )
          )
         )
        )
        (i64.sub
         (local.get $17)
         (i64.const 1)
        )
        (struct.get $type35 0
         (local.get $16)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type20
     (struct.get $type33 1
      (local.get $1)
     )
     (i32.wrap_i64
      (local.get $3)
     )
     (struct.get $type42 0
      (struct.get $type41 1
       (local.get $12)
      )
     )
    )
    (return_call $function33
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )

;; optimized source line 1228
(func $function41 (type $call35) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref null $type12))
  (local $3 (ref null $type12))
  (local $4 (ref null $type12))
  (local $5 (ref $type12))
  (local $6 (ref $environment41))
  (local $7 (ref $type36))
  (local $8 (ref $type34))
  (local $9 (ref $type35))
  (local $10 (ref $type39))
  (local $11 (ref $type41))
  (local $12 (ref $type42))
  (local $13 i64)
  (local $14 i64)
  (local $scratch (ref $type41))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $1)
   )
   (then
    (if (result i32)
     (i64.gt_s
      (local.tee $1
       (i64.sub
        (struct.get $environment41 3
         (local.tee $6
          (ref.cast (ref $environment41)
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 1)
     )
     (then
      (struct.set $type36 1
       (local.tee $7
        (struct.new_default $type36)
       )
       (struct.new $type35
        (ref.func $function41)
        (struct.new $environment41
         (struct.get $environment41 0
          (local.get $6)
         )
         (struct.get $environment41 1
          (local.get $6)
         )
         (struct.get $environment41 2
          (local.get $6)
         )
         (local.get $1)
         (local.get $7)
         (struct.get $environment41 5
          (local.get $6)
         )
         (struct.get $environment41 6
          (local.get $6)
         )
         (struct.get $environment41 7
          (local.get $6)
         )
        )
       )
      )
      (struct.set $type36 0
       (local.get $7)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type36 0
         (local.get $7)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call35
       (struct.get $type35 1
        (local.tee $9
         (ref.as_non_null
          (struct.get $type36 1
           (local.get $7)
          )
         )
        )
       )
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
       (struct.get $type35 0
        (local.get $9)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (drop
     (if (result i32)
      (i64.gt_s
       (local.tee $13
        (i64.sub
         (struct.get $environment41 3
          (local.tee $6
           (ref.cast (ref $environment41)
            (local.get $0)
           )
          )
         )
         (block (result i64)
          (local.set $8
           (struct.get $environment41 5
            (local.get $6)
           )
          )
          (i64.const 1)
         )
        )
       )
       (i64.const 1)
      )
      (then
       (struct.set $type36 1
        (local.tee $7
         (struct.new_default $type36)
        )
        (struct.new $type35
         (ref.func $function41)
         (struct.new $environment41
          (struct.get $environment41 0
           (local.get $6)
          )
          (struct.get $environment41 1
           (local.get $6)
          )
          (struct.get $environment41 2
           (local.get $6)
          )
          (local.get $13)
          (local.get $7)
          (local.get $8)
          (struct.get $environment41 6
           (local.get $6)
          )
          (struct.get $environment41 7
           (local.get $6)
          )
         )
        )
       )
       (struct.set $type36 0
        (local.get $7)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type36 0
          (local.get $7)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call35
        (struct.get $type35 1
         (local.tee $9
          (ref.as_non_null
           (struct.get $type36 1
            (local.get $7)
           )
          )
         )
        )
        (i64.sub
         (local.get $13)
         (i64.const 1)
        )
        (struct.get $type35 0
         (local.get $9)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (local.set $2
     (struct.get $type40 0
      (struct.get $type39 1
       (local.tee $10
        (struct.get $environment41 0
         (local.get $6)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type40 0
      (struct.get $type39 1
       (local.get $10)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (if
     (i64.ne
      (local.tee $13
       (struct.get $environment41 3
        (local.get $6)
       )
      )
      (i64.const 0)
     )
     (then
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready92)
       )
       (then
        (unreachable)
       )
      )
      (local.set $8
       (struct.get $environment41 6
        (local.get $6)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global92)
       )
      )
      (local.set $2
       (if (result (ref null $type12))
        (i64.eqz
         (local.tee $14
          (i64.sub
           (local.get $13)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $2)
        )
        (else
         (local.set $2
          (struct.get $type12 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready92)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global92)
          )
         )
         (if (result (ref null $type12))
          (i64.eqz
           (local.tee $14
            (i64.sub
             (local.get $14)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $2
            (struct.get $type12 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (if (result (ref null $type12))
            (i64.eqz
             (local.tee $14
              (i64.sub
               (local.get $14)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $2)
            )
            (else
             (local.set $2
              (struct.get $type12 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (if (result (ref null $type12))
              (i64.eqz
               (local.tee $14
                (i64.sub
                 (local.get $14)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $2)
              )
              (else
               (local.set $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (if (result (ref null $type12))
                (i64.eqz
                 (local.tee $14
                  (i64.sub
                   (local.get $14)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $2)
                )
                (else
                 (local.set $2
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (if (result (ref null $type12))
                  (i64.eqz
                   (local.tee $14
                    (i64.sub
                     (local.get $14)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (local.set $2
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (if (result (ref null $type12))
                    (i64.eqz
                     (local.tee $14
                      (i64.sub
                       (local.get $14)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (local.set $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                     (local.set $14
                      (i64.sub
                       (local.get $14)
                       (i64.const 1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (if (result (ref null $type12))
                      (i64.eqz
                       (local.get $14)
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (call $function43
                        (local.get $8)
                        (struct.get $type12 1
                         (local.get $2)
                        )
                        (i64.sub
                         (local.get $14)
                         (i64.const 1)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.get $environment41 7
      (local.get $6)
     )
    )
    (struct.set $type42 0
     (local.tee $12
      (struct.get $type41 1
       (block (result (ref $type41))
        (local.set $scratch
         (struct.get $environment41 1
          (local.get $6)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global92)
         )
        )
        (struct.set $type40 0
         (struct.get $type39 1
          (local.get $10)
         )
         (if (result (ref null $type12))
          (i64.eqz
           (local.get $13)
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $4
            (struct.get $type12 1
             (local.get $3)
            )
           )
           (local.set $5
            (struct.new $type12
             (struct.get $type12 0
              (local.get $3)
             )
             (block (result (ref null $type12))
              (if
               (i32.eqz
                (global.get $ready92)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global92)
               )
              )
              (local.get $2)
             )
            )
           )
           (if (result (ref null $type12))
            (i64.eqz
             (local.tee $13
              (i64.sub
               (local.get $13)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $2
              (struct.get $type12 1
               (local.get $4)
              )
             )
             (local.set $5
              (struct.new $type12
               (struct.get $type12 0
                (local.get $4)
               )
               (block (result (ref $type12))
                (if
                 (i32.eqz
                  (global.get $ready92)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global92)
                 )
                )
                (local.get $5)
               )
              )
             )
             (if (result (ref null $type12))
              (i64.eqz
               (local.tee $13
                (i64.sub
                 (local.get $13)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $3
                (struct.get $type12 1
                 (local.get $2)
                )
               )
               (local.set $5
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $2)
                 )
                 (block (result (ref $type12))
                  (if
                   (i32.eqz
                    (global.get $ready92)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global92)
                   )
                  )
                  (local.get $5)
                 )
                )
               )
               (if (result (ref null $type12))
                (i64.eqz
                 (local.tee $13
                  (i64.sub
                   (local.get $13)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $2
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (local.set $5
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $3)
                   )
                   (local.get $5)
                  )
                 )
                 (if (result (ref null $type12))
                  (i64.eqz
                   (local.tee $13
                    (i64.sub
                     (local.get $13)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (local.set $5
                    (struct.new $type12
                     (struct.get $type12 0
                      (local.get $2)
                     )
                     (local.get $5)
                    )
                   )
                   (if (result (ref null $type12))
                    (i64.eqz
                     (local.tee $13
                      (i64.sub
                       (local.get $13)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $2
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (local.set $5
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $3)
                       )
                       (local.get $5)
                      )
                     )
                     (if (result (ref null $type12))
                      (i64.eqz
                       (local.tee $13
                        (i64.sub
                         (local.get $13)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready92)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global92)
                        )
                       )
                       (local.set $5
                        (struct.new $type12
                         (struct.get $type12 0
                          (local.get $2)
                         )
                         (local.get $5)
                        )
                       )
                       (if (result (ref null $type12))
                        (i64.eqz
                         (local.tee $13
                          (i64.sub
                           (local.get $13)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $2
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                         (local.set $13
                          (i64.sub
                           (local.get $13)
                           (i64.const 1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready92)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global92)
                          )
                         )
                         (local.set $5
                          (struct.new $type12
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (local.get $5)
                          )
                         )
                         (if (result (ref null $type12))
                          (i64.eqz
                           (local.get $13)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (call $function44
                            (local.get $8)
                            (struct.get $type12 1
                             (local.get $2)
                            )
                            (i64.sub
                             (local.get $13)
                             (i64.const 1)
                            )
                            (struct.new $type12
                             (struct.get $type12 0
                              (local.get $2)
                             )
                             (local.get $5)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (local.get $scratch)
       )
      )
     )
     (struct.new $type16
      (struct.get $type40 0
       (struct.get $type39 1
        (local.get $10)
       )
      )
      (struct.get $type42 0
       (local.get $12)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type36 0
       (struct.get $environment41 4
        (local.get $6)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function41
     (struct.get $type35 1
      (struct.get $type36 1
       (struct.get $environment41 4
        (local.get $6)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )

;; optimized source line 2199
(func $function43 (type $15) (param $0 (ref $type34)) (param $1 (ref null $type12)) (param $2 i64) (result (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref null $type12))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function43
     (local.get $0)
     (struct.get $type12 1
      (local.get $1)
     )
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )

;; optimized source line 2234
(func $function44 (type $14) (param $0 (ref $type34)) (param $1 (ref null $type12)) (param $2 i64) (param $3 (ref $type12)) (result (ref null $type12))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref $type12))
   (i64.eqz
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (return_call $function44
     (local.get $0)
     (struct.get $type12 1
      (local.get $1)
     )
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
     (struct.new $type12
      (struct.get $type12 0
       (local.get $1)
      )
      (local.get $3)
     )
    )
   )
  )
 )

;; optimized source line 2275
(func $function45 (type $call19) (param $0 (ref $environment45)) (result (ref $type20))
  (local $1 (ref $type36))
  (local $2 (ref $type33))
  (local $3 (ref $type35))
  (local $4 i64)
  (local $5 i64)
  (drop
   (call $function33
    (struct.get $environment45 0
     (local.get $0)
    )
    (local.tee $2
     (struct.get $environment45 3
      (local.get $0)
     )
    )
    (struct.get $environment45 5
     (local.get $0)
    )
    (i64.sub
     (local.tee $4
      (struct.get $environment45 1
       (local.get $0)
      )
     )
     (local.tee $5
      (struct.get $environment45 2
       (local.get $0)
      )
     )
    )
    (local.get $4)
   )
  )
  (struct.set $type36 1
   (local.tee $1
    (struct.new_default $type36)
   )
   (struct.new $type35
    (ref.func $function32)
    (struct.new $environment32
     (local.get $4)
     (local.get $5)
     (local.get $2)
     (local.get $1)
    )
   )
  )
  (struct.set $type36 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type36 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call35
    (struct.get $type35 1
     (local.tee $3
      (ref.as_non_null
       (struct.get $type36 1
        (local.get $1)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type35 0
     (local.get $3)
    )
   )
  )
  (struct.get $type33 1
   (struct.get $environment45 3
    (local.get $0)
   )
  )
 )

;; optimized source line 2360
(func $function46 (type $call21) (param $0 (ref $environment46)) (param $1 (ref $type20)) (result i32)
  (local $2 (ref null $type12))
  (local $3 (ref null $type12))
  (local $4 (ref null $type16))
  (local $5 (ref null $type16))
  (local $6 (ref $type30))
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (local $15 i64)
  (local $16 i64)
  (local $17 i32)
  (local $scratch (ref null $type12))
  (local.set $4
   (array.get $type20
    (local.get $1)
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (if
   (i64.gt_u
    (local.tee $7
     (select
      (local.tee $7
       (i64.sub
        (i64.sub
         (struct.get $environment46 1
          (local.get $0)
         )
         (struct.get $environment46 2
          (local.get $0)
         )
        )
        (i64.const 1)
       )
      )
      (i64.const 0)
      (i64.ge_s
       (local.get $7)
       (i64.const 0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $17
     (i32.and
      (ref.is_null
       (local.tee $5
        (array.get $type20
         (local.get $1)
         (i32.wrap_i64
          (local.get $7)
         )
        )
       )
      )
      (ref.is_null
       (local.get $4)
      )
     )
    )
    (then
     (local.get $17)
    )
    (else
     (if
      (i32.eqz
       (global.get $ready125)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global125)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $4)
      )
      (then
       (i32.const 0)
      )
      (else
       (if
        (i32.eqz
         (global.get $ready125)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global125)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $5)
        )
        (then
         (i32.const 0)
        )
        (else
         (local.set $3
          (struct.get $type16 0
           (local.get $4)
          )
         )
         (local.set $2
          (struct.get $type16 0
           (local.get $5)
          )
         )
         (if
          (i32.eqz
           (global.get $ready127)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global127)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $3)
          )
          (then
           (ref.is_null
            (local.get $2)
           )
          )
          (else
           (if (result i32)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i32.const 0)
            )
            (else
             (if (result i32)
              (i64.eq
               (struct.get $type12 0
                (local.get $3)
               )
               (struct.get $type12 0
                (local.get $2)
               )
              )
              (then
               (local.set $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
               (local.set $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready127)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global127)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (ref.is_null
                  (local.get $2)
                 )
                )
                (else
                 (if (result i32)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (if (result i32)
                    (i64.eq
                     (struct.get $type12 0
                      (local.get $3)
                     )
                     (struct.get $type12 0
                      (local.get $2)
                     )
                    )
                    (then
                     (local.set $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (local.set $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready127)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global127)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (ref.is_null
                        (local.get $2)
                       )
                      )
                      (else
                       (if (result i32)
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (if (result i32)
                          (i64.eq
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (struct.get $type12 0
                            (local.get $2)
                           )
                          )
                          (then
                           (local.set $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                           (local.set $2
                            (struct.get $type12 1
                             (local.get $2)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready127)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global127)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (ref.is_null
                              (local.get $2)
                             )
                            )
                            (else
                             (if (result i32)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (if (result i32)
                                (i64.eq
                                 (struct.get $type12 0
                                  (local.get $3)
                                 )
                                 (struct.get $type12 0
                                  (local.get $2)
                                 )
                                )
                                (then
                                 (local.set $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                 (local.set $2
                                  (struct.get $type12 1
                                   (local.get $2)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready127)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global127)
                                  )
                                 )
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $3)
                                  )
                                  (then
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                  )
                                  (else
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $2)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (if (result i32)
                                      (i64.eq
                                       (struct.get $type12 0
                                        (local.get $3)
                                       )
                                       (struct.get $type12 0
                                        (local.get $2)
                                       )
                                      )
                                      (then
                                       (local.set $3
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                       (local.set $2
                                        (struct.get $type12 1
                                         (local.get $2)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready127)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global127)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $3)
                                        )
                                        (then
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                        )
                                        (else
                                         (if (result i32)
                                          (ref.is_null
                                           (local.get $2)
                                          )
                                          (then
                                           (i32.const 0)
                                          )
                                          (else
                                           (if (result i32)
                                            (i64.eq
                                             (struct.get $type12 0
                                              (local.get $3)
                                             )
                                             (struct.get $type12 0
                                              (local.get $2)
                                             )
                                            )
                                            (then
                                             (local.set $3
                                              (struct.get $type12 1
                                               (local.get $3)
                                              )
                                             )
                                             (local.set $2
                                              (struct.get $type12 1
                                               (local.get $2)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready127)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global127)
                                              )
                                             )
                                             (if (result i32)
                                              (ref.is_null
                                               (local.get $3)
                                              )
                                              (then
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                              )
                                              (else
                                               (if (result i32)
                                                (ref.is_null
                                                 (local.get $2)
                                                )
                                                (then
                                                 (i32.const 0)
                                                )
                                                (else
                                                 (if (result i32)
                                                  (i64.eq
                                                   (struct.get $type12 0
                                                    (local.get $3)
                                                   )
                                                   (struct.get $type12 0
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (then
                                                   (local.set $3
                                                    (struct.get $type12 1
                                                     (local.get $3)
                                                    )
                                                   )
                                                   (local.set $2
                                                    (struct.get $type12 1
                                                     (local.get $2)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready127)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global127)
                                                    )
                                                   )
                                                   (if (result i32)
                                                    (ref.is_null
                                                     (local.get $3)
                                                    )
                                                    (then
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (else
                                                     (if (result i32)
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                      (then
                                                       (i32.const 0)
                                                      )
                                                      (else
                                                       (if (result i32)
                                                        (i64.eq
                                                         (struct.get $type12 0
                                                          (local.get $3)
                                                         )
                                                         (struct.get $type12 0
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (then
                                                         (local.set $3
                                                          (struct.get $type12 1
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (local.set $2
                                                          (struct.get $type12 1
                                                           (local.get $2)
                                                          )
                                                         )
                                                         (if
                                                          (i32.eqz
                                                           (global.get $ready127)
                                                          )
                                                          (then
                                                           (unreachable)
                                                          )
                                                         )
                                                         (drop
                                                          (ref.as_non_null
                                                           (global.get $global127)
                                                          )
                                                         )
                                                         (if (result i32)
                                                          (ref.is_null
                                                           (local.get $3)
                                                          )
                                                          (then
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                          )
                                                          (else
                                                           (if (result i32)
                                                            (ref.is_null
                                                             (local.get $2)
                                                            )
                                                            (then
                                                             (i32.const 0)
                                                            )
                                                            (else
                                                             (if (result i32)
                                                              (i64.eq
                                                               (struct.get $type12 0
                                                                (local.get $3)
                                                               )
                                                               (struct.get $type12 0
                                                                (local.get $2)
                                                               )
                                                              )
                                                              (then
                                                               (local.set $3
                                                                (struct.get $type12 1
                                                                 (local.get $3)
                                                                )
                                                               )
                                                               (local.set $2
                                                                (struct.get $type12 1
                                                                 (local.get $2)
                                                                )
                                                               )
                                                               (if
                                                                (i32.eqz
                                                                 (global.get $ready127)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                               )
                                                               (drop
                                                                (ref.as_non_null
                                                                 (global.get $global127)
                                                                )
                                                               )
                                                               (if (result i32)
                                                                (ref.is_null
                                                                 (local.get $3)
                                                                )
                                                                (then
                                                                 (ref.is_null
                                                                  (local.get $2)
                                                                 )
                                                                )
                                                                (else
                                                                 (if (result i32)
                                                                  (ref.is_null
                                                                   (local.get $2)
                                                                  )
                                                                  (then
                                                                   (i32.const 0)
                                                                  )
                                                                  (else
                                                                   (if (result i32)
                                                                    (i64.eq
                                                                     (struct.get $type12 0
                                                                      (local.get $3)
                                                                     )
                                                                     (struct.get $type12 0
                                                                      (local.get $2)
                                                                     )
                                                                    )
                                                                    (then
                                                                     (call $function50
                                                                      (struct.get $type12 1
                                                                       (local.get $3)
                                                                      )
                                                                      (block (result (ref null $type12))
                                                                       (local.set $scratch
                                                                        (struct.get $type12 1
                                                                         (local.get $2)
                                                                        )
                                                                       )
                                                                       (if
                                                                        (i32.eqz
                                                                         (global.get $ready127)
                                                                        )
                                                                        (then
                                                                         (unreachable)
                                                                        )
                                                                       )
                                                                       (drop
                                                                        (ref.as_non_null
                                                                         (global.get $global127)
                                                                        )
                                                                       )
                                                                       (local.get $scratch)
                                                                      )
                                                                     )
                                                                    )
                                                                    (else
                                                                     (i32.const 0)
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (else
                                             (i32.const 0)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                      (else
                                       (i32.const 0)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (else
                                 (i32.const 0)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (else
                           (i32.const 0)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                 )
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (struct.set $type30 1
     (local.tee $6
      (struct.new_default $type30)
     )
     (struct.new $type29
      (struct.new $environment26
       (local.get $6)
      )
     )
    )
    (struct.set $type30 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type30 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (i64.eq
     (call $function26
      (struct.get $type29 0
       (struct.get $type30 1
        (local.get $6)
       )
      )
      (local.get $4)
      (i64.const 0)
     )
     (i64.div_s
      (i64.mul
       (i64.mul
        (local.tee $7
         (struct.get $environment46 0
          (local.get $0)
         )
        )
        (i64.add
         (local.get $7)
         (i64.const 1)
        )
       )
       (if (result i64)
        (i64.eqz
         (local.get $7)
        )
        (then
         (i64.const 1)
        )
        (else
         (i64.mul
          (if (result i64)
           (i64.eqz
            (local.tee $8
             (i64.sub
              (local.get $7)
              (i64.const 1)
             )
            )
           )
           (then
            (i64.const 1)
           )
           (else
            (i64.mul
             (if (result i64)
              (i64.eqz
               (local.tee $9
                (i64.sub
                 (local.get $8)
                 (i64.const 1)
                )
               )
              )
              (then
               (i64.const 1)
              )
              (else
               (i64.mul
                (if (result i64)
                 (i64.eqz
                  (local.tee $10
                   (i64.sub
                    (local.get $9)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (i64.const 1)
                 )
                 (else
                  (i64.mul
                   (if (result i64)
                    (i64.eqz
                     (local.tee $11
                      (i64.sub
                       (local.get $10)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (i64.const 1)
                    )
                    (else
                     (i64.mul
                      (if (result i64)
                       (i64.eqz
                        (local.tee $12
                         (i64.sub
                          (local.get $11)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (i64.const 1)
                       )
                       (else
                        (i64.mul
                         (if (result i64)
                          (i64.eqz
                           (local.tee $13
                            (i64.sub
                             (local.get $12)
                             (i64.const 1)
                            )
                           )
                          )
                          (then
                           (i64.const 1)
                          )
                          (else
                           (i64.mul
                            (if (result i64)
                             (i64.eqz
                              (local.tee $14
                               (i64.sub
                                (local.get $13)
                                (i64.const 1)
                               )
                              )
                             )
                             (then
                              (i64.const 1)
                             )
                             (else
                              (i64.mul
                               (if (result i64)
                                (i64.eqz
                                 (local.tee $15
                                  (i64.sub
                                   (local.get $14)
                                   (i64.const 1)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 1)
                                )
                                (else
                                 (i64.mul
                                  (if (result i64)
                                   (i64.eqz
                                    (local.tee $16
                                     (i64.sub
                                      (local.get $15)
                                      (i64.const 1)
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 1)
                                   )
                                   (else
                                    (i64.mul
                                     (call $function47
                                      (i32.const 0)
                                      (i32.const 1)
                                      (i64.sub
                                       (local.get $16)
                                       (i64.const 1)
                                      )
                                     )
                                     (local.get $16)
                                    )
                                   )
                                  )
                                  (local.get $15)
                                 )
                                )
                               )
                               (local.get $14)
                              )
                             )
                            )
                            (local.get $13)
                           )
                          )
                         )
                         (local.get $12)
                        )
                       )
                      )
                      (local.get $11)
                     )
                    )
                   )
                   (local.get $10)
                  )
                 )
                )
                (local.get $9)
               )
              )
             )
             (local.get $8)
            )
           )
          )
          (local.get $7)
         )
        )
       )
      )
      (i64.const 2)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )

;; optimized source line 3475
(func $function53 (type $call28) (param $0 i64) (result i64)
  (local $1 (ref $environment54))
  (local $2 (ref $type20))
  (local $3 (ref $type45))
  (local $4 (ref $type21))
  (local $scratch (ref $type21))
  (if
   (i32.eqz
    (global.get $ready145)
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call $function46
     (struct.get $type21 0
      (block (result (ref $type21))
       (local.set $scratch
        (struct.get $type22 1
         (global.get $global145)
        )
       )
       (if
        (i32.eqz
         (global.get $ready145)
        )
        (then
         (unreachable)
        )
       )
       (struct.set $type45 1
        (local.tee $3
         (struct.new_default $type45)
        )
        (struct.new $type44
         (struct.new $environment54
          (local.get $0)
          (struct.new $type43
           (i32.const 1)
           (struct.get $type22 0
            (global.get $global145)
           )
          )
          (local.get $3)
         )
        )
       )
       (struct.set $type45 0
        (local.get $3)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type45 0
          (local.get $3)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.get $scratch)
      )
     )
     (if (result (ref $type20))
      (i64.gt_s
       (struct.get $environment54 0
        (local.tee $1
         (struct.get $type44 0
          (struct.get $type45 1
           (local.get $3)
          )
         )
        )
       )
       (i64.const 0)
      )
      (then
       (local.set $2
        (call $function45
         (struct.get $type19 0
          (struct.get $type43 1
           (struct.get $environment54 1
            (local.get $1)
           )
          )
         )
        )
       )
       (if
        (i32.eqz
         (struct.get $type45 0
          (struct.get $environment54 2
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (if (result (ref $type20))
        (i64.gt_s
         (struct.get $environment54 0
          (local.tee $1
           (struct.get $type44 0
            (struct.get $type45 1
             (struct.get $environment54 2
              (local.get $1)
             )
            )
           )
          )
         )
         (i64.const 1)
        )
        (then
         (local.set $2
          (call $function45
           (struct.get $type19 0
            (struct.get $type43 1
             (struct.get $environment54 1
              (local.get $1)
             )
            )
           )
          )
         )
         (if
          (i32.eqz
           (struct.get $type45 0
            (struct.get $environment54 2
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (if (result (ref $type20))
          (i64.gt_s
           (struct.get $environment54 0
            (local.tee $1
             (struct.get $type44 0
              (struct.get $type45 1
               (struct.get $environment54 2
                (local.get $1)
               )
              )
             )
            )
           )
           (i64.const 2)
          )
          (then
           (local.set $2
            (call $function45
             (struct.get $type19 0
              (struct.get $type43 1
               (struct.get $environment54 1
                (local.get $1)
               )
              )
             )
            )
           )
           (if
            (i32.eqz
             (struct.get $type45 0
              (struct.get $environment54 2
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (if (result (ref $type20))
            (i64.gt_s
             (struct.get $environment54 0
              (local.tee $1
               (struct.get $type44 0
                (struct.get $type45 1
                 (struct.get $environment54 2
                  (local.get $1)
                 )
                )
               )
              )
             )
             (i64.const 3)
            )
            (then
             (local.set $2
              (call $function45
               (struct.get $type19 0
                (struct.get $type43 1
                 (struct.get $environment54 1
                  (local.get $1)
                 )
                )
               )
              )
             )
             (if
              (i32.eqz
               (struct.get $type45 0
                (struct.get $environment54 2
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (if (result (ref $type20))
              (i64.gt_s
               (struct.get $environment54 0
                (local.tee $1
                 (struct.get $type44 0
                  (struct.get $type45 1
                   (struct.get $environment54 2
                    (local.get $1)
                   )
                  )
                 )
                )
               )
               (i64.const 4)
              )
              (then
               (local.set $2
                (call $function45
                 (struct.get $type19 0
                  (struct.get $type43 1
                   (struct.get $environment54 1
                    (local.get $1)
                   )
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (struct.get $type45 0
                  (struct.get $environment54 2
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (if (result (ref $type20))
                (i64.gt_s
                 (struct.get $environment54 0
                  (local.tee $1
                   (struct.get $type44 0
                    (struct.get $type45 1
                     (struct.get $environment54 2
                      (local.get $1)
                     )
                    )
                   )
                  )
                 )
                 (i64.const 5)
                )
                (then
                 (local.set $2
                  (call $function45
                   (struct.get $type19 0
                    (struct.get $type43 1
                     (struct.get $environment54 1
                      (local.get $1)
                     )
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type45 0
                    (struct.get $environment54 2
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if (result (ref $type20))
                  (i64.gt_s
                   (struct.get $environment54 0
                    (local.tee $1
                     (struct.get $type44 0
                      (struct.get $type45 1
                       (struct.get $environment54 2
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                   (i64.const 6)
                  )
                  (then
                   (local.set $2
                    (call $function45
                     (struct.get $type19 0
                      (struct.get $type43 1
                       (struct.get $environment54 1
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type45 0
                      (struct.get $environment54 2
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if (result (ref $type20))
                    (i64.gt_s
                     (struct.get $environment54 0
                      (local.tee $1
                       (struct.get $type44 0
                        (struct.get $type45 1
                         (struct.get $environment54 2
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                     (i64.const 7)
                    )
                    (then
                     (local.set $2
                      (call $function45
                       (struct.get $type19 0
                        (struct.get $type43 1
                         (struct.get $environment54 1
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type45 0
                        (struct.get $environment54 2
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (if (result (ref $type20))
                      (i64.gt_s
                       (struct.get $environment54 0
                        (local.tee $1
                         (struct.get $type44 0
                          (struct.get $type45 1
                           (struct.get $environment54 2
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (i64.const 8)
                      )
                      (then
                       (local.set $2
                        (call $function45
                         (struct.get $type19 0
                          (struct.get $type43 1
                           (struct.get $environment54 1
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type45 0
                          (struct.get $environment54 2
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if (result (ref $type20))
                        (i64.gt_s
                         (struct.get $environment54 0
                          (local.tee $1
                           (struct.get $type44 0
                            (struct.get $type45 1
                             (struct.get $environment54 2
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                         (i64.const 9)
                        )
                        (then
                         (local.set $2
                          (call $function45
                           (struct.get $type19 0
                            (struct.get $type43 1
                             (struct.get $environment54 1
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type45 0
                            (struct.get $environment54 2
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (call $function54
                          (struct.get $type44 0
                           (struct.get $type45 1
                            (struct.get $environment54 2
                             (local.get $1)
                            )
                           )
                          )
                          (i64.const 10)
                          (local.get $2)
                         )
                        )
                        (else
                         (local.get $2)
                        )
                       )
                      )
                      (else
                       (local.get $2)
                      )
                     )
                    )
                    (else
                     (local.get $2)
                    )
                   )
                  )
                  (else
                   (local.get $2)
                  )
                 )
                )
                (else
                 (local.get $2)
                )
               )
              )
              (else
               (local.get $2)
              )
             )
            )
            (else
             (local.get $2)
            )
           )
          )
          (else
           (local.get $2)
          )
         )
        )
        (else
         (local.get $2)
        )
       )
      )
      (else
       (array.new_fixed $type20 0)
      )
     )
    )
    (i32.const 0)
   )
  )
 )

;; optimized source line 3995
(func $function54 (type $call44) (param $0 (ref $environment54)) (param $1 i64) (param $2 (ref $type20)) (result (ref $type20))
  (if (result (ref $type20))
   (i64.gt_s
    (struct.get $environment54 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (local.set $2
     (call $function45
      (struct.get $type19 0
       (struct.get $type43 1
        (struct.get $environment54 1
         (local.get $0)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type45 0
       (struct.get $environment54 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function54
     (struct.get $type44 0
      (struct.get $type45 1
       (struct.get $environment54 2
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
