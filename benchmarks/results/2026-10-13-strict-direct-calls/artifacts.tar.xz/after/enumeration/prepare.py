"""Rebuild frozen graphs/mperm inputs and replay correctness checks, not timings."""

import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
FROZEN = Path('/tmp/snail-strict-enumeration-preparation-20261013')
COMMIT = '35d5baa52c2a0e25d0c86c02adefd661a6457a3b'
BUILDS = ['graphs', 'mperm', 'graphs/strict-output-probe',
          'mperm/strict-output-probe', 'supplementary/mperm-sharing']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def run(command, **options):
    result = subprocess.run(command, capture_output=True, text=True, **options)
    return dict(command=command, returncode=result.returncode,
                stdout=result.stdout, stderr=result.stderr)


def compiler_snapshot():
    archive = subprocess.check_output(['git', 'archive', COMMIT, 'src',
                                      'scripts/build-strict', 'tests/build-strict-program.scm'], cwd=REPO)
    destination = ROOT / 'compiler-source'
    destination.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(archive)) as source:
        source.extractall(destination, filter='data')
    files = {str(p.relative_to(destination)): digest(p)
             for p in sorted(destination.rglob('*')) if p.is_file()}
    save(ROOT / 'compiler-identity.json', dict(compiler_commit=COMMIT,
         compiler_files=files, frozen_input_directory=str(FROZEN),
         performance_samples=0))


def build(relative):
    old = FROZEN / relative
    new = ROOT / relative
    new.mkdir(parents=True, exist_ok=True)
    record = json.loads((old / 'strict-build.json').read_text())
    command = record['command']
    command[0] = str(ROOT / 'compiler-source/scripts/build-strict')
    assert Path(command[-2]) == old / 'strict.scm'
    command[-1] = str(new / 'strict.wasm')
    result = run(command, cwd=REPO)
    save(new / 'strict-build.json', result)
    assert result['returncode'] == 0 and not result['stderr'], result
    subprocess.run(['wasm-dis', str(new / 'strict.wasm'), '-o',
                    str(new / 'strict.optimized.wat')], check=True)
    save(new / 'artifact-identity.json', dict(source=str(old / 'strict.scm'),
         source_sha256=digest(old / 'strict.scm'),
         artifacts={p.name: digest(p) for p in sorted(new.glob('strict.*'))
                    if p.suffix in ['.wasm', '.wat']}))
    print('Built', relative, flush=True)


def compare_output(old, result):
    assert result['returncode'] == old['returncode'], result
    if old['returncode']:
        assert 'AssertionError [ERR_ASSERTION]' in result['stderr'], result
        assert "'0' !== '1'" in result['stderr'], result
        return
    assert not result['stderr'], result
    previous, current = [json.loads(item['stdout']) for item in (old, result)]
    previous.pop('seconds', None)
    current.pop('seconds', None)
    assert previous == current, (previous, current)


def replay(relative, filename):
    old_directory, new_directory = FROZEN / relative, ROOT / relative
    records = json.loads((old_directory / filename).read_text())
    results = []
    for old in records:
        command = old['command'].copy()
        assert Path(command[2]).parent == old_directory
        command[2] = str(new_directory / Path(command[2]).name)
        result = run(command)
        compare_output(old, result)
        result.update(expected_returncode=old['returncode'], passed=True,
                      reference_record=str(old_directory / filename))
        results.append(result)
        save(new_directory / filename, results)
    print('Checked', relative, filename, flush=True)
    return results


def sharing_witness():
    relative = Path('supplementary/mperm-sharing')
    old, new = FROZEN / relative, ROOT / relative
    for filename in ['build-witness.py', 'identity-getters.wat', 'check.mjs']:
        shutil.copyfile(old / filename, new / filename)
    env = os.environ.copy()
    for key, executable in [('WASM_AS', 'wasm-as'), ('WASM_OPT', 'wasm-opt'),
                            ('WASM_DIS', 'wasm-dis'), ('NODE', 'node')]:
        env[key] = shutil.which(executable)
    result = run(['python3', str(new / 'build-witness.py')], env=env)
    save(new / 'witness-rebuild.json', result)
    assert result['returncode'] == 0, result
    print(result['stdout'].strip(), flush=True)


compiler_snapshot()
for relative in BUILDS:
    build(relative)
outcomes = {}
for name in ['graphs', 'mperm']:
    canonical = replay(name, 'validation.json')
    probe = name + '/strict-output-probe'
    supplemental = []
    for path in sorted((FROZEN / probe).glob('validation-*.json')):
        if not path.name.startswith('validation-spec-'):
            supplemental.extend(replay(probe, path.name))
    outcomes[name] = dict(canonical=len(canonical), supplemental=len(supplemental),
                         expected_rejections=sum(bool(r['returncode']) for r in supplemental),
                         passed=len(canonical) + len(supplemental))
sharing_witness()
outcomes['mperm_sharing'] = dict(raw=True, optimized=True, identity_flags=1023,
                               reference_checks=10, vector_identity_checks=2)
save(ROOT / 'correctness-summary.json', dict(performance_samples=0, outcomes=outcomes))
print(json.dumps(outcomes), flush=True)
