(module
 (rec
  (type $call52 (func (param (ref $environment70) i64 (ref $type12)) (result (ref $type12))))
  (type $type52 (struct (field (ref $environment70))))
  (type $environment70 (struct (field i64) (field (ref $type53))))
  (type $type53 (struct (field (mut i32)) (field (mut (ref null $type52)))))
  (type $call25 (func (param (ref null $type14) (ref null $type14)) (result i32)))
  (type $5 (func (param (ref $type12) i64 i64 (ref $type31) i64 i32 i32 i32 i32 i32 i32 i32 i64 i64) (result i64)))
  (type $6 (func (param (ref $type12) i64 (ref $type31) i64 i32 i32 i32 i64) (result i64)))
  (type $7 (func (param (ref $type12) (ref $type31) i32 i32 i64 i64) (result (ref $type12))))
  (type $environment52 (struct (field (ref $type21)) (field (ref $type12)) (field (ref $type37)) (field (ref $type38)) (field (ref $type39))))
  (type $9 (func (param (ref $type21) (ref $type12)) (result (ref $type12))))
  (type $environment64 (struct (field (ref $type12)) (field i32) (field (ref $type51))))
  (type $environment62 (struct (field (ref $type12)) (field (ref $type51))))
  (type $call50 (func (param (ref struct) i64) (result i32)))
  (type $environment60 (struct (field (ref $type12)) (field (ref $type51))))
  (type $type50 (struct (field (ref $call50)) (field (ref struct))))
  (type $type51 (struct (field (mut i32)) (field (mut (ref null $type50)))))
  (type $environment48 (struct (field (ref $type38)) (field (ref $type39))))
  (type $environment47 (struct (field i64) (field (ref $type38)) (field (ref $type39))))
  (type $call21 (func (param i64) (result i64)))
  (type $environment41 (struct (field (ref $type46))))
  (type $call48 (func (param (ref $environment40) i64 (ref $type14)) (result (ref null $type14))))
  (type $type48 (struct (field (ref $environment40))))
  (type $environment38 (struct (field (ref $type46))))
  (type $type49 (struct (field (mut i32)) (field (mut (ref null $type48)))))
  (type $environment40 (struct (field (ref $type15)) (field (ref $type49))))
  (type $type47 (struct (field i32) (field f64)))
  (type $type45 (struct (field (mut (ref $type15)))))
  (type $type46 (struct (field i32) (field (ref $type45))))
  (type $environment37 (struct (field (ref $type47)) (field (ref $type47)) (field (ref $type47)) (field (ref $type47)) (field (ref $type47)) (field (ref $type47)) (field (ref $type47)) (field (ref $type46))))
  (type $call41 (func (param (ref $environment36) (ref null $type14) i64) (result (ref $type15))))
  (type $call43 (func (param (ref $environment35) (ref null $type14) i64) (result i64)))
  (type $type41 (struct (field (ref $environment36))))
  (type $environment36 (struct (field (ref $type40)) (field (ref $type42))))
  (type $type40 (struct (field i32) (field (ref $type15))))
  (type $type15 (array (mut f64)))
  (type $type43 (struct (field (ref $environment35))))
  (type $type42 (struct (field (mut i32)) (field (mut (ref null $type41)))))
  (type $type44 (struct (field (mut i32)) (field (mut (ref null $type43)))))
  (type $type14 (struct (field f64) (field (ref null $type14))))
  (type $environment35 (struct (field (ref $type44))))
  (type $40 (func (param (ref $type14)) (result (ref $type15))))
  (type $call7 (func (param (ref null $environment37)) (result f64)))
  (type $call27 (func (param (ref null $environment38)) (result (ref null $type14))))
  (type $call26 (func (param (ref null $environment41) (ref $type14)) (result i32)))
  (type $call11 (func (param structref i64) (result (ref $type12))))
  (type $environment28 (struct (field i32) (field (ref $type37)) (field (ref $type38)) (field (ref $type39))))
  (type $type38 (struct (field i32) (field (ref $type12))))
  (type $type39 (struct (field (mut i32)) (field (mut (ref null $type11)))))
  (type $type37 (struct (field (mut i32)) (field i64)))
  (type $49 (func (result (ref $type12))))
  (type $type12 (array (mut i64)))
  (type $type31 (struct))
  (type $type36 (struct (field (mut (ref $type7)))))
  (type $type35 (struct (field (mut (ref $type27)))))
  (type $type34 (struct (field (mut (ref $type26)))))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type7 (struct (field (ref $call7)) (field (ref null $environment37))))
  (type $type27 (struct (field (ref $call27)) (field (ref null $environment38))))
  (type $type26 (struct (field (ref $call26)) (field (ref null $environment41))))
  (type $type25 (struct))
  (type $type24 (struct))
  (type $type23 (struct))
  (type $type22 (struct))
  (type $type21 (struct (field (ref $call21))))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type18 (struct))
  (type $type17 (struct))
  (type $type16 (struct))
  (type $type13 (struct))
  (type $type11 (struct (field (ref $call11)) (field structref)))
  (type $type5 (struct))
 )
 (type $76 (func (param i64) (result i64)))
 (type $77 (func (param i32) (result i64)))
 (type $78 (func (result i64)))
 (type $79 (func (param i32 i64) (result i64)))
 (type $80 (func (result i32)))
 (type $81 (func))
 (import "benchmark" "vector_length" (func $foreign0 (param i32) (result i64)))
 (import "benchmark" "vector_i64" (func $foreign1 (param i32 i64) (result i64)))
 (import "benchmark" "barrier" (func $foreign2 (result i32)))
 (import "benchmark" "expected_length" (func $foreign3 (result i64)))
 (import "benchmark" "expected_i64" (func $foreign4 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign5 (param i32) (result i64)))
 (import "benchmark" "count" (func $foreign6 (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $ready55 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type11)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (global $global86 (mut (ref null $type13)) (ref.null none))
 (global $ready86 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type16)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global91 (mut (ref null $type17)) (ref.null none))
 (global $ready91 (mut i32) (i32.const 0))
 (global $global112 (mut (ref null $type18)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type19)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type20)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global146 (mut (ref null $type21)) (ref.null none))
 (global $ready146 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type22)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global180 (mut (ref null $type23)) (ref.null none))
 (global $ready180 (mut i32) (i32.const 0))
 (global $global190 (mut (ref null $type24)) (ref.null none))
 (global $ready190 (mut i32) (i32.const 0))
 (global $global201 (mut (ref null $type25)) (ref.null none))
 (global $ready201 (mut i32) (i32.const 0))
 (global $global71 (mut (ref null $type26)) (ref.null none))
 (global $global73 (mut (ref null $type27)) (ref.null none))
 (global $global74 (mut (ref null $type7)) (ref.null none))
 (global $global148 (mut (ref null $type28)) (ref.null none))
 (global $ready148 (mut i32) (i32.const 0))
 (global $global185 (mut (ref null $type23)) (ref.null none))
 (global $ready185 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type29)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type30)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type32)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global162 (mut (ref null $type33)) (ref.null none))
 (global $ready162 (mut i32) (i32.const 0))
 (global $global75 (mut (ref null $type34)) (ref.null none))
 (global $ready75 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type35)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global77 (mut (ref null $type36)) (ref.null none))
 (global $ready77 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type21)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global121 (mut i64) (i64.const 0))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global125 (mut i64) (i64.const 0))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type31)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type12)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type21)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global197 (mut (ref null $type21)) (ref.null none))
 (global $ready197 (mut i32) (i32.const 0))
 (global $global199 (mut (ref null $type21)) (ref.null none))
 (global $ready199 (mut i32) (i32.const 0))
 (global $global204 (mut (ref null $type21)) (ref.null none))
 (global $ready204 (mut i32) (i32.const 0))
 (global $global206 (mut (ref null $type21)) (ref.null none))
 (global $ready206 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "quicksort-probe" (func $export1))
 (export "quicksort-rng-probe" (func $export2))
 (export "quicksort-seed-probe" (func $export3))
 (export "quicksort-sorted-probe" (func $export4))
 (export "main" (func $main))
 (func $function27 (type $49) (result (ref $type12))
  (local $0 (ref $type39))
  (local $1 (ref $type37))
  (local $2 (ref $type11))
  (local $3 i64)
  (local.set $1
   (struct.new $type37
    (i32.const 1)
    (call $foreign0
     (i32.const 2)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type37 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $3
     (struct.get $type37 1
      (local.get $1)
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type39 1
   (local.tee $0
    (struct.new_default $type39)
   )
   (struct.new $type11
    (ref.func $function28)
    (struct.new $environment28
     (i32.const 2)
     (local.get $1)
     (struct.new $type38
      (i32.const 1)
      (array.new_default $type12
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type39 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type39 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call11
   (struct.get $type11 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type39 1
       (local.get $0)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type11 0
    (local.get $2)
   )
  )
 )
 (func $function28 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 (ref $environment28))
  (local $3 i64)
  (if
   (i32.eqz
    (struct.get $type37 0
     (struct.get $environment28 1
      (ref.cast (ref $environment28)
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type12))
   (i64.eq
    (struct.get $type37 1
     (struct.get $environment28 1
      (local.tee $2
       (ref.cast (ref $environment28)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $type38 1
     (struct.get $environment28 2
      (local.get $2)
     )
    )
   )
   (else
    (local.set $3
     (call $foreign1
      (i32.const 2)
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type38 1
      (struct.get $environment28 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment28 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function28
     (struct.get $type11 1
      (struct.get $type39 1
       (struct.get $environment28 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function29 (type $call26) (param $0 (ref null $environment41)) (param $1 (ref $type14)) (result i32)
  (unreachable)
 )
 (func $function30 (type $call27) (param $0 (ref null $environment38)) (result (ref null $type14))
  (unreachable)
 )
 (func $function31 (type $call7) (param $0 (ref null $environment37)) (result f64)
  (unreachable)
 )
 (func $function33 (type $40) (param $0 (ref $type14)) (result (ref $type15))
  (local $1 (ref null $type14))
  (local $2 (ref $environment35))
  (local $3 (ref $environment36))
  (local $4 (ref $type44))
  (local $5 (ref $type42))
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready91)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global91)
   )
  )
  (struct.set $type44 1
   (local.tee $4
    (struct.new_default $type44)
   )
   (struct.new $type43
    (struct.new $environment35
     (local.get $4)
    )
   )
  )
  (struct.set $type44 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type44 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type44 0
     (struct.get $environment35 0
      (local.tee $2
       (struct.get $type43 0
        (struct.get $type44 1
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type43 0
    (struct.get $type44 1
     (struct.get $environment35 0
      (local.get $2)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $6
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type14 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $1
        (struct.get $type14 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (struct.get $type44 0
          (struct.get $environment35 0
           (local.get $2)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (struct.get $type43 0
         (struct.get $type44 1
          (struct.get $environment35 0
           (local.get $2)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $1
          (struct.get $type14 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (struct.get $type44 0
            (struct.get $environment35 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type43 0
           (struct.get $type44 1
            (struct.get $environment35 0
             (local.get $2)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $1
            (struct.get $type14 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (struct.get $type44 0
              (struct.get $environment35 0
               (local.get $2)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $2
            (struct.get $type43 0
             (struct.get $type44 1
              (struct.get $environment35 0
               (local.get $2)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $1
              (struct.get $type14 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (struct.get $type44 0
                (struct.get $environment35 0
                 (local.get $2)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $2
              (struct.get $type43 0
               (struct.get $type44 1
                (struct.get $environment35 0
                 (local.get $2)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $1
                (struct.get $type14 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type44 0
                  (struct.get $environment35 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type43 0
                 (struct.get $type44 1
                  (struct.get $environment35 0
                   (local.get $2)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $1
                  (struct.get $type14 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type44 0
                    (struct.get $environment35 0
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $2
                  (struct.get $type43 0
                   (struct.get $type44 1
                    (struct.get $environment35 0
                     (local.get $2)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $1
                    (struct.get $type14 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type44 0
                      (struct.get $environment35 0
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $2
                    (struct.get $type43 0
                     (struct.get $type44 1
                      (struct.get $environment35 0
                       (local.get $2)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $1
                      (struct.get $type14 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type44 0
                        (struct.get $environment35 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function35
                      (struct.get $type43 0
                       (struct.get $type44 1
                        (struct.get $environment35 0
                         (local.get $2)
                        )
                       )
                      )
                      (local.get $1)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type42 1
   (local.tee $5
    (struct.new_default $type42)
   )
   (struct.new $type41
    (struct.new $environment36
     (struct.new $type40
      (i32.const 1)
      (array.new $type15
       (struct.get $type14 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $6)
       )
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type42 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type42 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type15
   (struct.get $type40 1
    (struct.get $environment36 0
     (local.tee $3
      (struct.get $type41 0
       (struct.get $type42 1
        (local.get $5)
       )
      )
     )
    )
   )
   (i32.const 0)
   (struct.get $type14 0
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type42 0
     (struct.get $environment36 1
      (local.get $3)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type41 0
    (struct.get $type42 1
     (struct.get $environment36 1
      (local.get $3)
     )
    )
   )
  )
  (if (result (ref $type15))
   (ref.is_null
    (local.tee $1
     (struct.get $type14 1
      (local.get $0)
     )
    )
   )
   (then
    (struct.get $type40 1
     (struct.get $environment36 0
      (local.get $3)
     )
    )
   )
   (else
    (array.set $type15
     (struct.get $type40 1
      (struct.get $environment36 0
       (local.get $3)
      )
     )
     (i32.const 1)
     (struct.get $type14 0
      (local.get $1)
     )
    )
    (local.set $1
     (struct.get $type14 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type42 0
       (struct.get $environment36 1
        (local.get $3)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type41 0
      (struct.get $type42 1
       (struct.get $environment36 1
        (local.get $3)
       )
      )
     )
    )
    (if (result (ref $type15))
     (ref.is_null
      (local.get $1)
     )
     (then
      (struct.get $type40 1
       (struct.get $environment36 0
        (local.get $3)
       )
      )
     )
     (else
      (array.set $type15
       (struct.get $type40 1
        (struct.get $environment36 0
         (local.get $3)
        )
       )
       (i32.const 2)
       (struct.get $type14 0
        (local.get $1)
       )
      )
      (local.set $1
       (struct.get $type14 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type42 0
         (struct.get $environment36 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type41 0
        (struct.get $type42 1
         (struct.get $environment36 1
          (local.get $3)
         )
        )
       )
      )
      (if (result (ref $type15))
       (ref.is_null
        (local.get $1)
       )
       (then
        (struct.get $type40 1
         (struct.get $environment36 0
          (local.get $3)
         )
        )
       )
       (else
        (array.set $type15
         (struct.get $type40 1
          (struct.get $environment36 0
           (local.get $3)
          )
         )
         (i32.const 3)
         (struct.get $type14 0
          (local.get $1)
         )
        )
        (local.set $1
         (struct.get $type14 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (struct.get $type42 0
           (struct.get $environment36 1
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type41 0
          (struct.get $type42 1
           (struct.get $environment36 1
            (local.get $3)
           )
          )
         )
        )
        (if (result (ref $type15))
         (ref.is_null
          (local.get $1)
         )
         (then
          (struct.get $type40 1
           (struct.get $environment36 0
            (local.get $3)
           )
          )
         )
         (else
          (array.set $type15
           (struct.get $type40 1
            (struct.get $environment36 0
             (local.get $3)
            )
           )
           (i32.const 4)
           (struct.get $type14 0
            (local.get $1)
           )
          )
          (local.set $1
           (struct.get $type14 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (struct.get $type42 0
             (struct.get $environment36 1
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (return_call $function36
           (struct.get $type41 0
            (struct.get $type42 1
             (struct.get $environment36 1
              (local.get $3)
             )
            )
           )
           (local.get $1)
           (i64.const 5)
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function35 (type $call43) (param $0 (ref $environment35)) (param $1 (ref null $type14)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.eq
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $1
       (struct.get $type14 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type44 0
         (struct.get $environment35 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function35
       (struct.get $type43 0
        (struct.get $type44 1
         (struct.get $environment35 0
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function36 (type $call41) (param $0 (ref $environment36)) (param $1 (ref null $type14)) (param $2 i64) (result (ref $type15))
  (local $3 f64)
  (if (result (ref $type15))
   (ref.is_null
    (local.get $1)
   )
   (then
    (struct.get $type40 1
     (struct.get $environment36 0
      (local.get $0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type14 0
      (local.get $1)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (struct.get $type40 1
      (struct.get $environment36 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $3)
    )
    (local.set $1
     (struct.get $type14 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type42 0
       (struct.get $environment36 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function36
     (struct.get $type41 0
      (struct.get $type42 1
       (struct.get $environment36 1
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function37 (type $call7) (param $0 (ref null $environment37)) (result f64)
  (local $1 (ref $type15))
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (local $10 f64)
  (local $11 f64)
  (local $12 f64)
  (local $scratch f64)
  (local $scratch_14 f64)
  (drop
   (struct.get $environment37 7
    (local.get $0)
   )
  )
  (local.set $1
   (struct.get $type45 0
    (struct.get $type46 1
     (struct.get $environment37 7
      (local.get $0)
     )
    )
   )
  )
  (drop
   (struct.get $environment37 3
    (local.get $0)
   )
  )
  (if
   (f64.lt
    (local.tee $3
     (f64.sub
      (local.tee $3
       (f64.sub
        (f64.mul
         (struct.get $type47 1
          (struct.get $environment37 3
           (local.get $0)
          )
         )
         (block (result f64)
          (local.set $scratch_14
           (array.get $type15
            (local.get $1)
            (i32.const 1)
           )
          )
          (drop
           (struct.get $environment37 4
            (local.get $0)
           )
          )
          (local.set $5
           (struct.get $type47 1
            (struct.get $environment37 4
             (local.get $0)
            )
           )
          )
          (local.set $6
           (array.get $type15
            (local.get $1)
            (i32.const 0)
           )
          )
          (drop
           (struct.get $environment37 5
            (local.get $0)
           )
          )
          (local.set $2
           (f64.sub
            (local.tee $2
             (f64.sub
              (f64.mul
               (struct.get $type47 1
                (struct.get $environment37 5
                 (local.get $0)
                )
               )
               (block (result f64)
                (local.set $scratch
                 (array.get $type15
                  (local.get $1)
                  (i32.const 5)
                 )
                )
                (drop
                 (struct.get $environment37 6
                  (local.get $0)
                 )
                )
                (local.set $8
                 (struct.get $type47 1
                  (struct.get $environment37 6
                   (local.get $0)
                  )
                 )
                )
                (local.set $9
                 (array.get $type15
                  (local.get $1)
                  (i32.const 3)
                 )
                )
                (drop
                 (struct.get $environment37 1
                  (local.get $0)
                 )
                )
                (local.set $10
                 (struct.get $type47 1
                  (struct.get $environment37 1
                   (local.get $0)
                  )
                 )
                )
                (drop
                 (struct.get $environment37 2
                  (local.get $0)
                 )
                )
                (local.set $11
                 (struct.get $type47 1
                  (struct.get $environment37 2
                   (local.get $0)
                  )
                 )
                )
                (array.set $type15
                 (local.get $1)
                 (i32.const 0)
                 (array.get $type15
                  (local.get $1)
                  (i32.const 1)
                 )
                )
                (array.set $type15
                 (local.get $1)
                 (i32.const 3)
                 (array.get $type15
                  (local.get $1)
                  (i32.const 4)
                 )
                )
                (drop
                 (struct.get $environment37 1
                  (local.get $0)
                 )
                )
                (local.set $12
                 (struct.get $type47 1
                  (struct.get $environment37 1
                   (local.get $0)
                  )
                 )
                )
                (drop
                 (struct.get $environment37 2
                  (local.get $0)
                 )
                )
                (local.get $scratch)
               )
              )
              (f64.mul
               (local.get $8)
               (local.get $9)
              )
             )
            )
            (f64.mul
             (f64.trunc
              (f64.div
               (local.get $2)
               (local.get $11)
              )
             )
             (struct.get $type47 1
              (struct.get $environment37 2
               (local.get $0)
              )
             )
            )
           )
          )
          (array.set $type15
           (local.get $1)
           (i32.const 1)
           (array.get $type15
            (local.get $1)
            (i32.const 2)
           )
          )
          (array.set $type15
           (local.get $1)
           (i32.const 4)
           (array.get $type15
            (local.get $1)
            (i32.const 5)
           )
          )
          (local.get $scratch_14)
         )
        )
        (f64.mul
         (local.get $5)
         (local.get $6)
        )
       )
      )
      (f64.mul
       (f64.trunc
        (f64.div
         (local.get $3)
         (local.get $10)
        )
       )
       (local.get $12)
      )
     )
    )
    (f64.const 0)
   )
   (then
    (drop
     (struct.get $environment37 1
      (local.get $0)
     )
    )
    (local.set $3
     (f64.add
      (local.get $3)
      (struct.get $type47 1
       (struct.get $environment37 1
        (local.get $0)
       )
      )
     )
    )
   )
  )
  (if
   (f64.lt
    (local.get $2)
    (f64.const 0)
   )
   (then
    (drop
     (struct.get $environment37 2
      (local.get $0)
     )
    )
    (local.set $2
     (f64.add
      (local.get $2)
      (struct.get $type47 1
       (struct.get $environment37 2
        (local.get $0)
       )
      )
     )
    )
   )
  )
  (array.set $type15
   (local.get $1)
   (i32.const 2)
   (local.get $3)
  )
  (array.set $type15
   (local.get $1)
   (i32.const 5)
   (local.get $2)
  )
  (if (result f64)
   (f64.ge
    (local.get $2)
    (local.get $3)
   )
   (then
    (drop
     (struct.get $environment37 0
      (local.get $0)
     )
    )
    (f64.mul
     (struct.get $type47 1
      (struct.get $environment37 0
       (local.get $0)
      )
     )
     (block (result f64)
      (drop
       (struct.get $environment37 1
        (local.get $0)
       )
      )
      (f64.add
       (f64.sub
        (local.get $3)
        (local.get $2)
       )
       (struct.get $type47 1
        (struct.get $environment37 1
         (local.get $0)
        )
       )
      )
     )
    )
   )
   (else
    (drop
     (struct.get $environment37 0
      (local.get $0)
     )
    )
    (f64.mul
     (struct.get $type47 1
      (struct.get $environment37 0
       (local.get $0)
      )
     )
     (f64.sub
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function38 (type $call27) (param $0 (ref null $environment38)) (result (ref null $type14))
  (local $1 (ref $environment40))
  (local $2 (ref $type14))
  (local $3 (ref $type49))
  (local $4 (ref $type15))
  (local $5 i64)
  (local $6 i64)
  (local $7 f64)
  (local.set $4
   (struct.get $type45 0
    (struct.get $type46 1
     (struct.get $environment38 0
      (local.get $0)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (struct.set $type49 1
   (local.tee $3
    (struct.new_default $type49)
   )
   (struct.new $type48
    (struct.new $environment40
     (local.get $4)
     (local.get $3)
    )
   )
  )
  (struct.set $type49 0
   (local.get $3)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type49 0
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type48 0
    (struct.get $type49 1
     (local.get $3)
    )
   )
  )
  (if (result (ref null $type14))
   (i64.eqz
    (local.tee $5
     (i64.extend_i32_u
      (array.len
       (local.get $4)
      )
     )
    )
   )
   (then
    (ref.null none)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $6
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.new $type14
      (array.get $type15
       (struct.get $environment40 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $6)
       )
      )
      (block (result nullref)
       (if
        (i32.eqz
         (struct.get $type49 0
          (struct.get $environment40 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (struct.get $type48 0
         (struct.get $type49 1
          (struct.get $environment40 1
           (local.get $1)
          )
         )
        )
       )
       (ref.null none)
      )
     )
    )
    (if (result (ref $type14))
     (i64.eqz
      (local.tee $5
       (i64.sub
        (local.get $5)
        (i64.const 1)
       )
      )
     )
     (then
      (local.get $2)
     )
     (else
      (if
       (i64.gt_u
        (local.tee $6
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.new $type14
        (array.get $type15
         (struct.get $environment40 0
          (local.get $1)
         )
         (i32.wrap_i64
          (local.get $6)
         )
        )
        (block (result (ref $type14))
         (if
          (i32.eqz
           (struct.get $type49 0
            (struct.get $environment40 1
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (struct.get $type48 0
           (struct.get $type49 1
            (struct.get $environment40 1
             (local.get $1)
            )
           )
          )
         )
         (local.get $2)
        )
       )
      )
      (if (result (ref $type14))
       (i64.eqz
        (local.tee $5
         (i64.sub
          (local.get $5)
          (i64.const 1)
         )
        )
       )
       (then
        (local.get $2)
       )
       (else
        (if
         (i64.gt_u
          (local.tee $6
           (i64.sub
            (local.get $5)
            (i64.const 1)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.new $type14
          (array.get $type15
           (struct.get $environment40 0
            (local.get $1)
           )
           (i32.wrap_i64
            (local.get $6)
           )
          )
          (block (result (ref $type14))
           (if
            (i32.eqz
             (struct.get $type49 0
              (struct.get $environment40 1
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type48 0
             (struct.get $type49 1
              (struct.get $environment40 1
               (local.get $1)
              )
             )
            )
           )
           (local.get $2)
          )
         )
        )
        (if (result (ref $type14))
         (i64.eqz
          (local.tee $5
           (i64.sub
            (local.get $5)
            (i64.const 1)
           )
          )
         )
         (then
          (local.get $2)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $6
             (i64.sub
              (local.get $5)
              (i64.const 1)
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.set $2
           (struct.new $type14
            (array.get $type15
             (struct.get $environment40 0
              (local.get $1)
             )
             (i32.wrap_i64
              (local.get $6)
             )
            )
            (block (result (ref $type14))
             (if
              (i32.eqz
               (struct.get $type49 0
                (struct.get $environment40 1
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type48 0
               (struct.get $type49 1
                (struct.get $environment40 1
                 (local.get $1)
                )
               )
              )
             )
             (local.get $2)
            )
           )
          )
          (if (result (ref $type14))
           (i64.eqz
            (local.tee $5
             (i64.sub
              (local.get $5)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $2)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $6
               (i64.sub
                (local.get $5)
                (i64.const 1)
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.new $type14
              (array.get $type15
               (struct.get $environment40 0
                (local.get $1)
               )
               (i32.wrap_i64
                (local.get $6)
               )
              )
              (block (result (ref $type14))
               (if
                (i32.eqz
                 (struct.get $type49 0
                  (struct.get $environment40 1
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type48 0
                 (struct.get $type49 1
                  (struct.get $environment40 1
                   (local.get $1)
                  )
                 )
                )
               )
               (local.get $2)
              )
             )
            )
            (if (result (ref $type14))
             (i64.eqz
              (local.tee $5
               (i64.sub
                (local.get $5)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $2)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $6
                 (i64.sub
                  (local.get $5)
                  (i64.const 1)
                 )
                )
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (local.set $2
               (struct.new $type14
                (array.get $type15
                 (struct.get $environment40 0
                  (local.get $1)
                 )
                 (i32.wrap_i64
                  (local.get $6)
                 )
                )
                (block (result (ref $type14))
                 (if
                  (i32.eqz
                   (struct.get $type49 0
                    (struct.get $environment40 1
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type48 0
                   (struct.get $type49 1
                    (struct.get $environment40 1
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (local.get $2)
                )
               )
              )
              (if (result (ref $type14))
               (i64.eqz
                (local.tee $5
                 (i64.sub
                  (local.get $5)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $2)
               )
               (else
                (if
                 (i64.gt_u
                  (local.tee $6
                   (i64.sub
                    (local.get $5)
                    (i64.const 1)
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $2
                 (struct.new $type14
                  (array.get $type15
                   (struct.get $environment40 0
                    (local.get $1)
                   )
                   (i32.wrap_i64
                    (local.get $6)
                   )
                  )
                  (block (result (ref $type14))
                   (if
                    (i32.eqz
                     (struct.get $type49 0
                      (struct.get $environment40 1
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type48 0
                     (struct.get $type49 1
                      (struct.get $environment40 1
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (local.get $2)
                  )
                 )
                )
                (if (result (ref $type14))
                 (i64.eqz
                  (local.tee $5
                   (i64.sub
                    (local.get $5)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $6
                     (i64.sub
                      (local.get $5)
                      (i64.const 1)
                     )
                    )
                    (i64.const 4294967295)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.new $type14
                    (array.get $type15
                     (struct.get $environment40 0
                      (local.get $1)
                     )
                     (i32.wrap_i64
                      (local.get $6)
                     )
                    )
                    (block (result (ref $type14))
                     (if
                      (i32.eqz
                       (struct.get $type49 0
                        (struct.get $environment40 1
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (struct.get $type48 0
                       (struct.get $type49 1
                        (struct.get $environment40 1
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (local.get $2)
                    )
                   )
                  )
                  (if (result (ref $type14))
                   (i64.eqz
                    (local.tee $5
                     (i64.sub
                      (local.get $5)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $6
                       (i64.sub
                        (local.get $5)
                        (i64.const 1)
                       )
                      )
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $7
                     (array.get $type15
                      (struct.get $environment40 0
                       (local.get $1)
                      )
                      (i32.wrap_i64
                       (local.get $6)
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (struct.get $type49 0
                       (struct.get $environment40 1
                        (local.get $1)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (return_call $function40
                     (struct.get $type48 0
                      (struct.get $type49 1
                       (struct.get $environment40 1
                        (local.get $1)
                       )
                      )
                     )
                     (i64.sub
                      (local.get $5)
                      (i64.const 1)
                     )
                     (struct.new $type14
                      (local.get $7)
                      (local.get $2)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function40 (type $call48) (param $0 (ref $environment40)) (param $1 i64) (param $2 (ref $type14)) (result (ref null $type14))
  (local $3 i64)
  (local $4 f64)
  (if (result (ref $type14))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $3
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type15
      (struct.get $environment40 0
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (struct.get $environment40 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function40
     (struct.get $type48 0
      (struct.get $type49 1
       (struct.get $environment40 1
        (local.get $0)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type14
      (local.get $4)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function41 (type $call26) (param $0 (ref null $environment41)) (param $1 (ref $type14)) (result i32)
  (local $2 (ref $type45))
  (drop
   (struct.get $environment41 0
    (local.get $0)
   )
  )
  (struct.set $type45 0
   (struct.get $type46 1
    (struct.get $environment41 0
     (local.get $0)
    )
   )
   (block (result (ref $type15))
    (if
     (i32.eqz
      (global.get $ready88)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global88)
     )
    )
    (call $function33
     (local.get $1)
    )
   )
  )
  (i32.const 0)
 )
 (func $function42 (type $call21) (param $0 i64) (result i64)
  (local $1 (ref $type7))
  (local $2 f64)
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i32.eqz
    (global.get $ready77)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call_ref $call7
    (struct.get $type7 1
     (local.tee $1
      (struct.get $type36 0
       (global.get $global77)
      )
     )
    )
    (struct.get $type7 0
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready63)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global63)
   )
  )
  (i64.trunc_f64_s
   (f64.trunc
    (f64.mul
     (f64.convert_i64_s
      (local.get $0)
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function46 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 (ref $type39))
  (local $3 (ref $type11))
  (local $4 i32)
  (if (result (ref $type12))
   (if (result i32)
    (local.tee $4
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $4)
    )
    (else
     (i64.gt_s
      (local.get $1)
      (i64.const 4294967295)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if (result (ref $type12))
     (i64.eqz
      (local.get $1)
     )
     (then
      (array.new_fixed $type12 0)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready55)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global55)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type39 1
       (local.tee $2
        (struct.new_default $type39)
       )
       (struct.new $type11
        (ref.func $function47)
        (struct.new $environment47
         (local.get $1)
         (struct.new $type38
          (i32.const 1)
          (array.new_default $type12
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $2)
        )
       )
      )
      (struct.set $type39 0
       (local.get $2)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type39 0
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call11
       (struct.get $type11 1
        (local.tee $3
         (ref.as_non_null
          (struct.get $type39 1
           (local.get $2)
          )
         )
        )
       )
       (i64.const 1)
       (struct.get $type11 0
        (local.get $3)
       )
      )
     )
    )
   )
  )
 )
 (func $function47 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 (ref $environment47))
  (if (result (ref $type12))
   (i64.eq
    (struct.get $environment47 0
     (local.tee $2
      (ref.cast (ref $environment47)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $type38 1
     (struct.get $environment47 1
      (local.get $2)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready55)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global55)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type38 1
      (struct.get $environment47 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i64.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment47 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function47
     (struct.get $type11 1
      (struct.get $type39 1
       (struct.get $environment47 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function48 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 i64)
  (local $3 f64)
  (local $4 (ref $type12))
  (local $5 (ref $type7))
  (local $scratch i64)
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type12))
   (i64.eq
    (global.get $global121)
    (local.get $1)
   )
   (then
    (drop
     (ref.cast (ref $environment48)
      (local.get $0)
     )
    )
    (struct.get $type38 1
     (struct.get $environment48 0
      (ref.cast (ref $environment48)
       (local.get $0)
      )
     )
    )
   )
   (else
    (drop
     (ref.cast (ref $environment48)
      (local.get $0)
     )
    )
    (array.set $type12
     (struct.get $type38 1
      (struct.get $environment48 0
       (ref.cast (ref $environment48)
        (local.get $0)
       )
      )
     )
     (block (result i32)
      (if
       (i32.eqz
        (global.get $ready125)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i32.eqz
        (global.get $ready77)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (i64.trunc_f64_s
        (f64.trunc
         (f64.mul
          (f64.convert_i64_s
           (block (result i64)
            (local.set $scratch
             (global.get $global125)
            )
            (local.set $3
             (call_ref $call7
              (struct.get $type7 1
               (local.tee $5
                (struct.get $type36 0
                 (global.get $global77)
                )
               )
              )
              (struct.get $type7 0
               (local.get $5)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready63)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global63)
             )
            )
            (local.get $scratch)
           )
          )
          (local.get $3)
         )
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
     (local.get $2)
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment48 1
        (ref.cast (ref $environment48)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (struct.get $type11 1
      (struct.get $type39 1
       (struct.get $environment48 1
        (ref.cast (ref $environment48)
         (local.get $0)
        )
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function49 (type $call21) (param $0 i64) (result i64)
  (local $1 (ref $type51))
  (local $2 (ref $type12))
  (local $3 (ref $type12))
  (local $4 (ref $type50))
  (local $5 (ref $type21))
  (local $6 (ref $type31))
  (local $7 i32)
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (local.set $3
   (call $function27)
  )
  (if
   (i32.eqz
    (global.get $ready146)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call $function51
    (ref.as_non_null
     (global.get $global146)
    )
    (block (result (ref $type12))
     (if
      (i32.eqz
       (global.get $ready148)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global148)
      )
     )
     (local.get $3)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (local.set $2
   (call $function54
    (local.get $2)
    (local.get $6)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $2)
      )
     )
     (i64.const 1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready180)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global180)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (if (result i32)
      (i64.eq
       (call $foreign3)
       (i64.extend_i32_u
        (array.len
         (local.get $2)
        )
       )
      )
      (then
       (struct.set $type51 1
        (local.tee $1
         (struct.new_default $type51)
        )
        (struct.new $type50
         (ref.func $function60)
         (struct.new $environment60
          (local.get $2)
          (local.get $1)
         )
        )
       )
       (struct.set $type51 0
        (local.get $1)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type51 0
          (local.get $1)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call50
        (struct.get $type50 1
         (local.tee $4
          (ref.as_non_null
           (struct.get $type51 1
            (local.get $1)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type50 0
         (local.get $4)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready185)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global185)
       )
      )
      (struct.set $type51 1
       (local.tee $1
        (struct.new_default $type51)
       )
       (struct.new $type50
        (ref.func $function62)
        (struct.new $environment62
         (local.get $2)
         (local.get $1)
        )
       )
      )
      (struct.set $type51 0
       (local.get $1)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type51 0
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (if (result i32)
       (call_ref $call50
        (struct.get $type50 1
         (local.tee $4
          (ref.as_non_null
           (struct.get $type51 1
            (local.get $1)
           )
          )
         )
        )
        (i64.const 1)
        (struct.get $type50 0
         (local.get $4)
        )
       )
       (then
        (if
         (i32.eqz
          (global.get $ready190)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global190)
         )
        )
        (if (result i32)
         (if (result i32)
          (i64.eq
           (call $foreign0
            (i32.const 2)
           )
           (i64.extend_i32_u
            (array.len
             (local.get $3)
            )
           )
          )
          (then
           (struct.set $type51 1
            (local.tee $1
             (struct.new_default $type51)
            )
            (struct.new $type50
             (ref.func $function64)
             (struct.new $environment64
              (local.get $3)
              (i32.const 2)
              (local.get $1)
             )
            )
           )
           (struct.set $type51 0
            (local.get $1)
            (i32.const 1)
           )
           (if
            (i32.eqz
             (struct.get $type51 0
              (local.get $1)
             )
            )
            (then
             (unreachable)
            )
           )
           (call_ref $call50
            (struct.get $type50 1
             (local.tee $4
              (ref.as_non_null
               (struct.get $type51 1
                (local.get $1)
               )
              )
             )
            )
            (i64.const 0)
            (struct.get $type50 0
             (local.get $4)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
         (then
          (if (result i32)
           (local.tee $7
            (i64.eqz
             (i64.extend_i32_u
              (array.len
               (local.get $3)
              )
             )
            )
           )
           (then
            (local.get $7)
           )
           (else
            (i32.eqz
             (ref.eq
              (local.get $2)
              (local.get $3)
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function50 (type $call21) (param $0 i64) (result i64)
  (local.get $0)
 )
 (func $function51 (type $9) (param $0 (ref $type21)) (param $1 (ref $type12)) (result (ref $type12))
  (local $2 (ref $type37))
  (local $3 (ref $type39))
  (local $4 (ref $type11))
  (local $5 i64)
  (if
   (i32.eqz
    (struct.get $type37 0
     (local.tee $2
      (struct.new $type37
       (i32.const 1)
       (i64.extend_i32_u
        (array.len
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type12))
   (i64.eqz
    (struct.get $type37 1
     (local.get $2)
    )
   )
   (then
    (array.new_fixed $type12 0)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type37 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type39 1
     (local.tee $3
      (struct.new_default $type39)
     )
     (struct.new $type11
      (ref.func $function52)
      (struct.new $environment52
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (struct.new $type38
        (i32.const 1)
        (array.new $type12
         (call_ref $call21
          (array.get $type12
           (local.get $1)
           (i32.const 0)
          )
          (struct.get $type21 0
           (local.get $0)
          )
         )
         (block (result i32)
          (if
           (i64.gt_u
            (local.tee $5
             (struct.get $type37 1
              (local.get $2)
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (i32.wrap_i64
           (local.get $5)
          )
         )
        )
       )
       (local.get $3)
      )
     )
    )
    (struct.set $type39 0
     (local.get $3)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call11
     (struct.get $type11 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type39 1
         (local.get $3)
        )
       )
      )
     )
     (i64.const 1)
     (struct.get $type11 0
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function52 (type $call11) (param $0 structref) (param $1 i64) (result (ref $type12))
  (local $2 (ref $environment52))
  (local $3 i64)
  (if
   (i32.eqz
    (struct.get $type37 0
     (struct.get $environment52 2
      (ref.cast (ref $environment52)
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type12))
   (i64.eq
    (struct.get $type37 1
     (struct.get $environment52 2
      (local.tee $2
       (ref.cast (ref $environment52)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $type38 1
     (struct.get $environment52 3
      (local.get $2)
     )
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call_ref $call21
      (array.get $type12
       (struct.get $environment52 1
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (struct.get $type21 0
       (struct.get $environment52 0
        (local.get $2)
       )
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type38 1
      (struct.get $environment52 3
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type39 0
       (struct.get $environment52 4
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (struct.get $type11 1
      (struct.get $type39 1
       (struct.get $environment52 4
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function54 (type $7) (param $0 (ref $type12)) (param $1 (ref $type31)) (param $2 i32) (param $3 i32) (param $4 i64) (param $5 i64) (result (ref $type12))
  (local $6 i64)
  (if (result (ref $type12))
   (i64.lt_s
    (local.get $4)
    (local.get $5)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready162)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global162)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (i64.sub
       (local.tee $6
        (call $function58
         (local.get $0)
         (local.get $4)
         (local.get $5)
         (local.get $1)
         (array.get $type12
          (local.get $0)
          (i32.wrap_i64
           (local.get $5)
          )
         )
         (i32.const 1)
         (i32.const 0)
         (i32.const 1)
         (i32.const 0)
         (i32.const 1)
         (i32.const 0)
         (i32.const 1)
         (i64.sub
          (local.get $4)
          (i64.const 1)
         )
         (local.get $5)
        )
       )
       (local.get $4)
      )
      (i64.sub
       (local.get $5)
       (local.get $6)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call $function54
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (local.get $4)
        (i64.sub
         (local.get $6)
         (i64.const 1)
        )
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function54
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $6)
        (i64.const 1)
       )
       (local.get $5)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call $function54
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $3)
        (i64.add
         (local.get $6)
         (i64.const 1)
        )
        (local.get $5)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function54
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i64.sub
        (local.get $6)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
   (else
    (local.get $0)
   )
  )
 )
 (func $function56 (type $6) (param $0 (ref $type12)) (param $1 i64) (param $2 (ref $type31)) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (result i64)
  (local $8 i64)
  (if (result i64)
   (if (result i32)
    (i64.gt_s
     (local.get $1)
     (local.tee $7
      (i64.add
       (local.get $7)
       (i64.const 1)
      )
     )
    )
    (then
     (if
      (i64.gt_u
       (local.get $7)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (local.set $8
      (array.get $type12
       (local.get $0)
       (i32.wrap_i64
        (local.get $7)
       )
      )
     )
     (if
      (i32.eqz
       (local.get $4)
      )
      (then
       (unreachable)
      )
     )
     (i64.gt_s
      (local.get $3)
      (local.get $8)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function56
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
    )
   )
   (else
    (local.get $7)
   )
  )
 )
 (func $function57 (type $6) (param $0 (ref $type12)) (param $1 i64) (param $2 (ref $type31)) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i32) (param $7 i64) (result i64)
  (if (result i64)
   (if (result i32)
    (i64.lt_s
     (local.get $1)
     (local.tee $7
      (i64.sub
       (local.get $7)
       (i64.const 1)
      )
     )
    )
    (then
     (if
      (i32.eqz
       (local.get $4)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.gt_u
       (local.get $7)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.gt_s
      (array.get $type12
       (local.get $0)
       (i32.wrap_i64
        (local.get $7)
       )
      )
      (local.get $3)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $6)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function57
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
    )
   )
   (else
    (local.get $7)
   )
  )
 )
 (func $function58 (type $5) (param $0 (ref $type12)) (param $1 i64) (param $2 i64) (param $3 (ref $type31)) (param $4 i64) (param $5 i32) (param $6 i32) (param $7 i32) (param $8 i32) (param $9 i32) (param $10 i32) (param $11 i32) (param $12 i64) (param $13 i64) (result i64)
  (local $14 i64)
  (local $15 i64)
  (if
   (i32.eqz
    (local.get $7)
   )
   (then
    (unreachable)
   )
  )
  (local.set $12
   (call $function56
    (local.get $0)
    (local.get $2)
    (local.get $3)
    (local.get $4)
    (local.get $5)
    (local.get $6)
    (local.get $7)
    (local.get $12)
   )
  )
  (if
   (i32.eqz
    (local.get $9)
   )
   (then
    (unreachable)
   )
  )
  (if
   (if (result i32)
    (i64.lt_s
     (local.get $1)
     (local.tee $13
      (i64.sub
       (local.get $13)
       (i64.const 1)
      )
     )
    )
    (then
     (if
      (i32.eqz
       (local.get $5)
      )
      (then
       (unreachable)
      )
     )
     (if
      (i64.gt_u
       (local.get $13)
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (i64.gt_s
      (array.get $type12
       (local.get $0)
       (i32.wrap_i64
        (local.get $13)
       )
      )
      (local.get $4)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $9)
     )
     (then
      (unreachable)
     )
    )
    (local.set $13
     (if (result i64)
      (if (result i32)
       (i64.lt_s
        (local.get $1)
        (local.tee $13
         (i64.sub
          (local.get $13)
          (i64.const 1)
         )
        )
       )
       (then
        (if
         (i32.eqz
          (local.get $5)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $13)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i64.gt_s
         (array.get $type12
          (local.get $0)
          (i32.wrap_i64
           (local.get $13)
          )
         )
         (local.get $4)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (if
        (i32.eqz
         (local.get $9)
        )
        (then
         (unreachable)
        )
       )
       (if (result i64)
        (if (result i32)
         (i64.lt_s
          (local.get $1)
          (local.tee $13
           (i64.sub
            (local.get $13)
            (i64.const 1)
           )
          )
         )
         (then
          (if
           (i32.eqz
            (local.get $5)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.get $13)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (i64.gt_s
           (array.get $type12
            (local.get $0)
            (i32.wrap_i64
             (local.get $13)
            )
           )
           (local.get $4)
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (if
          (i32.eqz
           (local.get $9)
          )
          (then
           (unreachable)
          )
         )
         (if (result i64)
          (if (result i32)
           (i64.lt_s
            (local.get $1)
            (local.tee $13
             (i64.sub
              (local.get $13)
              (i64.const 1)
             )
            )
           )
           (then
            (if
             (i32.eqz
              (local.get $5)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i64.gt_u
              (local.get $13)
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (i64.gt_s
             (array.get $type12
              (local.get $0)
              (i32.wrap_i64
               (local.get $13)
              )
             )
             (local.get $4)
            )
           )
           (else
            (i32.const 0)
           )
          )
          (then
           (if
            (i32.eqz
             (local.get $9)
            )
            (then
             (unreachable)
            )
           )
           (if (result i64)
            (if (result i32)
             (i64.lt_s
              (local.get $1)
              (local.tee $13
               (i64.sub
                (local.get $13)
                (i64.const 1)
               )
              )
             )
             (then
              (if
               (i32.eqz
                (local.get $5)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i64.gt_u
                (local.get $13)
                (i64.const 4294967295)
               )
               (then
                (unreachable)
               )
              )
              (i64.gt_s
               (array.get $type12
                (local.get $0)
                (i32.wrap_i64
                 (local.get $13)
                )
               )
               (local.get $4)
              )
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (if
              (i32.eqz
               (local.get $9)
              )
              (then
               (unreachable)
              )
             )
             (if (result i64)
              (if (result i32)
               (i64.lt_s
                (local.get $1)
                (local.tee $13
                 (i64.sub
                  (local.get $13)
                  (i64.const 1)
                 )
                )
               )
               (then
                (if
                 (i32.eqz
                  (local.get $5)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i64.gt_u
                  (local.get $13)
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (i64.gt_s
                 (array.get $type12
                  (local.get $0)
                  (i32.wrap_i64
                   (local.get $13)
                  )
                 )
                 (local.get $4)
                )
               )
               (else
                (i32.const 0)
               )
              )
              (then
               (if
                (i32.eqz
                 (local.get $9)
                )
                (then
                 (unreachable)
                )
               )
               (if (result i64)
                (if (result i32)
                 (i64.lt_s
                  (local.get $1)
                  (local.tee $13
                   (i64.sub
                    (local.get $13)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (if
                   (i32.eqz
                    (local.get $5)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i64.gt_u
                    (local.get $13)
                    (i64.const 4294967295)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (i64.gt_s
                   (array.get $type12
                    (local.get $0)
                    (i32.wrap_i64
                     (local.get $13)
                    )
                   )
                   (local.get $4)
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
                (then
                 (if
                  (i32.eqz
                   (local.get $9)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if (result i64)
                  (if (result i32)
                   (i64.lt_s
                    (local.get $1)
                    (local.tee $13
                     (i64.sub
                      (local.get $13)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (if
                     (i32.eqz
                      (local.get $5)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i64.gt_u
                      (local.get $13)
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (i64.gt_s
                     (array.get $type12
                      (local.get $0)
                      (i32.wrap_i64
                       (local.get $13)
                      )
                     )
                     (local.get $4)
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                  (then
                   (if
                    (i32.eqz
                     (local.get $9)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (if (result i64)
                    (if (result i32)
                     (i64.lt_s
                      (local.get $1)
                      (local.tee $13
                       (i64.sub
                        (local.get $13)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (if
                       (i32.eqz
                        (local.get $5)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (if
                       (i64.gt_u
                        (local.get $13)
                        (i64.const 4294967295)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (i64.gt_s
                       (array.get $type12
                        (local.get $0)
                        (i32.wrap_i64
                         (local.get $13)
                        )
                       )
                       (local.get $4)
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                    (then
                     (if
                      (i32.eqz
                       (local.get $9)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function57
                      (local.get $0)
                      (local.get $1)
                      (local.get $3)
                      (local.get $4)
                      (local.get $5)
                      (local.get $8)
                      (local.get $9)
                      (local.get $13)
                     )
                    )
                    (else
                     (local.get $13)
                    )
                   )
                  )
                  (else
                   (local.get $13)
                  )
                 )
                )
                (else
                 (local.get $13)
                )
               )
              )
              (else
               (local.get $13)
              )
             )
            )
            (else
             (local.get $13)
            )
           )
          )
          (else
           (local.get $13)
          )
         )
        )
        (else
         (local.get $13)
        )
       )
      )
      (else
       (local.get $13)
      )
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $12)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $14
   (array.get $type12
    (local.get $0)
    (i32.wrap_i64
     (local.get $12)
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $13)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $15
   (array.get $type12
    (local.get $0)
    (i32.wrap_i64
     (local.get $13)
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $12)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type12
   (local.get $0)
   (i32.wrap_i64
    (local.get $12)
   )
   (local.get $15)
  )
  (if
   (i64.gt_u
    (local.get $13)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type12
   (local.get $0)
   (i32.wrap_i64
    (local.get $13)
   )
   (local.get $14)
  )
  (if (result i64)
   (i64.lt_s
    (local.get $12)
    (local.get $13)
   )
   (then
    (if
     (i32.eqz
      (local.get $11)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function58
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
     (local.get $7)
     (local.get $8)
     (local.get $9)
     (local.get $10)
     (local.get $11)
     (local.get $12)
     (local.get $13)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (array.get $type12
      (local.get $0)
      (i32.wrap_i64
       (local.get $12)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $13)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $0)
     (i32.wrap_i64
      (local.get $13)
     )
     (local.get $1)
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (array.get $type12
      (local.get $0)
      (i32.wrap_i64
       (local.get $2)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $12)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $0)
     (i32.wrap_i64
      (local.get $12)
     )
     (local.get $1)
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (local.get $0)
     (i32.wrap_i64
      (local.get $2)
     )
     (local.get $14)
    )
    (local.get $12)
   )
  )
 )
 (func $function60 (type $call50) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i32)
  (local $3 (ref $environment60))
  (if (result i32)
   (local.tee $2
    (i64.eq
     (i64.extend_i32_u
      (array.len
       (struct.get $environment60 0
        (ref.cast (ref $environment60)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (array.get $type12
       (struct.get $environment60 0
        (local.tee $3
         (ref.cast (ref $environment60)
          (local.get $0)
         )
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (call $foreign4
       (local.get $1)
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type51 0
         (struct.get $environment60 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function60
       (struct.get $type50 1
        (struct.get $type51 1
         (struct.get $environment60 1
          (ref.cast (ref $environment60)
           (local.get $3)
          )
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function62 (type $call50) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment62))
  (local $3 i32)
  (local $4 i64)
  (if (result i32)
   (local.tee $3
    (i64.le_s
     (i64.extend_i32_u
      (array.len
       (struct.get $environment62 0
        (ref.cast (ref $environment62)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $4
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.le_s
      (array.get $type12
       (struct.get $environment62 0
        (local.tee $2
         (ref.cast (ref $environment62)
          (local.get $0)
         )
        )
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
      (array.get $type12
       (struct.get $environment62 0
        (local.get $2)
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type51 0
         (struct.get $environment62 1
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function62
       (struct.get $type50 1
        (struct.get $type51 1
         (struct.get $environment62 1
          (ref.cast (ref $environment62)
           (local.get $2)
          )
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function64 (type $call50) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment64))
  (local $3 i32)
  (if (result i32)
   (local.tee $3
    (i64.eq
     (i64.extend_i32_u
      (array.len
       (struct.get $environment64 0
        (ref.cast (ref $environment64)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (array.get $type12
       (struct.get $environment64 0
        (local.tee $2
         (ref.cast (ref $environment64)
          (local.get $0)
         )
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (call $foreign1
       (i32.const 2)
       (local.get $1)
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type51 0
         (struct.get $environment64 2
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function64
       (struct.get $type50 1
        (struct.get $type51 1
         (struct.get $environment64 2
          (local.get $2)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function65 (type $call21) (param $0 i64) (result i64)
  (local $1 (ref $type51))
  (local $2 (ref $type12))
  (local $3 (ref $type50))
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (i32.eqz
    (global.get $ready180)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global180)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (i64.eq
      (call $foreign3)
      (i64.extend_i32_u
       (array.len
        (local.get $2)
       )
      )
     )
     (then
      (struct.set $type51 1
       (local.tee $1
        (struct.new_default $type51)
       )
       (struct.new $type50
        (ref.func $function60)
        (struct.new $environment60
         (local.get $2)
         (local.get $1)
        )
       )
      )
      (struct.set $type51 0
       (local.get $1)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type51 0
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (call_ref $call50
       (struct.get $type50 1
        (local.tee $3
         (ref.as_non_null
          (struct.get $type51 1
           (local.get $1)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type50 0
        (local.get $3)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function66 (type $call21) (param $0 i64) (result i64)
  (local $1 (ref null $type14))
  (local $2 (ref null $type14))
  (local $3 (ref $environment40))
  (local $4 (ref $type14))
  (local $5 (ref $type49))
  (local $6 (ref $type15))
  (local $7 (ref $type26))
  (local $8 (ref $type27))
  (local $9 (ref $type7))
  (local $10 f64)
  (local $11 i64)
  (local $scratch (ref null $type14))
  (local $scratch_13 i64)
  (if
   (i32.eqz
    (global.get $ready75)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (call_ref $call26
    (struct.get $type26 1
     (local.tee $7
      (struct.get $type34 0
       (global.get $global75)
      )
     )
    )
    (struct.new $type14
     (f64.const 1)
     (struct.new $type14
      (f64.const 0)
      (struct.new $type14
       (f64.const 0)
       (struct.new $type14
        (f64.const 1)
        (struct.new $type14
         (f64.const 0)
         (struct.new_default $type14)
        )
       )
      )
     )
    )
    (struct.get $type26 0
     (local.get $7)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready76)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call_ref $call27
    (struct.get $type27 1
     (local.tee $8
      (struct.get $type35 0
       (global.get $global76)
      )
     )
    )
    (struct.get $type27 0
     (local.get $8)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready86)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global86)
   )
  )
  (if
   (i32.eqz
    (global.get $ready88)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global88)
   )
  )
  (local.set $6
   (call $function33
    (struct.new $type14
     (f64.const 1)
     (struct.new $type14
      (f64.const 0)
      (struct.new $type14
       (f64.const 0)
       (struct.new $type14
        (f64.const 1)
        (struct.new $type14
         (f64.const 0)
         (struct.new_default $type14)
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (struct.set $type49 1
   (local.tee $5
    (struct.new_default $type49)
   )
   (struct.new $type48
    (struct.new $environment40
     (local.get $6)
     (local.get $5)
    )
   )
  )
  (struct.set $type49 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type49 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type48 0
    (struct.get $type49 1
     (local.get $5)
    )
   )
  )
  (local.set $1
   (if (result (ref null $type14))
    (i64.eqz
     (local.tee $0
      (i64.extend_i32_u
       (array.len
        (local.get $6)
       )
      )
     )
    )
    (then
     (ref.null none)
    )
    (else
     (if
      (i64.gt_u
       (local.tee $11
        (i64.sub
         (local.get $0)
         (i64.const 1)
        )
       )
       (i64.const 4294967295)
      )
      (then
       (unreachable)
      )
     )
     (local.set $4
      (struct.new $type14
       (array.get $type15
        (struct.get $environment40 0
         (local.get $3)
        )
        (i32.wrap_i64
         (local.get $11)
        )
       )
       (block (result nullref)
        (if
         (i32.eqz
          (struct.get $type49 0
           (struct.get $environment40 1
            (local.get $3)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (struct.get $type48 0
          (struct.get $type49 1
           (struct.get $environment40 1
            (local.get $3)
           )
          )
         )
        )
        (ref.null none)
       )
      )
     )
     (if (result (ref null $type14))
      (i64.eqz
       (local.tee $0
        (i64.sub
         (local.get $0)
         (i64.const 1)
        )
       )
      )
      (then
       (local.get $4)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $11
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
         )
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.new $type14
         (array.get $type15
          (struct.get $environment40 0
           (local.get $3)
          )
          (i32.wrap_i64
           (local.get $11)
          )
         )
         (block (result (ref $type14))
          (if
           (i32.eqz
            (struct.get $type49 0
             (struct.get $environment40 1
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type48 0
            (struct.get $type49 1
             (struct.get $environment40 1
              (local.get $3)
             )
            )
           )
          )
          (local.get $4)
         )
        )
       )
       (if (result (ref null $type14))
        (i64.eqz
         (local.tee $0
          (i64.sub
           (local.get $0)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $4)
        )
        (else
         (if
          (i64.gt_u
           (local.tee $11
            (i64.sub
             (local.get $0)
             (i64.const 1)
            )
           )
           (i64.const 4294967295)
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.new $type14
           (array.get $type15
            (struct.get $environment40 0
             (local.get $3)
            )
            (i32.wrap_i64
             (local.get $11)
            )
           )
           (block (result (ref $type14))
            (if
             (i32.eqz
              (struct.get $type49 0
               (struct.get $environment40 1
                (local.get $3)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (struct.get $type48 0
              (struct.get $type49 1
               (struct.get $environment40 1
                (local.get $3)
               )
              )
             )
            )
            (local.get $4)
           )
          )
         )
         (if (result (ref null $type14))
          (i64.eqz
           (local.tee $0
            (i64.sub
             (local.get $0)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $4)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $11
              (i64.sub
               (local.get $0)
               (i64.const 1)
              )
             )
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (local.set $4
            (struct.new $type14
             (array.get $type15
              (struct.get $environment40 0
               (local.get $3)
              )
              (i32.wrap_i64
               (local.get $11)
              )
             )
             (block (result (ref $type14))
              (if
               (i32.eqz
                (struct.get $type49 0
                 (struct.get $environment40 1
                  (local.get $3)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type48 0
                (struct.get $type49 1
                 (struct.get $environment40 1
                  (local.get $3)
                 )
                )
               )
              )
              (local.get $4)
             )
            )
           )
           (if (result (ref null $type14))
            (i64.eqz
             (local.tee $0
              (i64.sub
               (local.get $0)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $4)
            )
            (else
             (if
              (i64.gt_u
               (local.tee $11
                (i64.sub
                 (local.get $0)
                 (i64.const 1)
                )
               )
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (local.set $4
              (struct.new $type14
               (array.get $type15
                (struct.get $environment40 0
                 (local.get $3)
                )
                (i32.wrap_i64
                 (local.get $11)
                )
               )
               (block (result (ref $type14))
                (if
                 (i32.eqz
                  (struct.get $type49 0
                   (struct.get $environment40 1
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $3
                 (struct.get $type48 0
                  (struct.get $type49 1
                   (struct.get $environment40 1
                    (local.get $3)
                   )
                  )
                 )
                )
                (local.get $4)
               )
              )
             )
             (if (result (ref null $type14))
              (i64.eqz
               (local.tee $0
                (i64.sub
                 (local.get $0)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $4)
              )
              (else
               (if
                (i64.gt_u
                 (local.tee $11
                  (i64.sub
                   (local.get $0)
                   (i64.const 1)
                  )
                 )
                 (i64.const 4294967295)
                )
                (then
                 (unreachable)
                )
               )
               (local.set $4
                (struct.new $type14
                 (array.get $type15
                  (struct.get $environment40 0
                   (local.get $3)
                  )
                  (i32.wrap_i64
                   (local.get $11)
                  )
                 )
                 (block (result (ref $type14))
                  (if
                   (i32.eqz
                    (struct.get $type49 0
                     (struct.get $environment40 1
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type48 0
                    (struct.get $type49 1
                     (struct.get $environment40 1
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (local.get $4)
                 )
                )
               )
               (if (result (ref null $type14))
                (i64.eqz
                 (local.tee $0
                  (i64.sub
                   (local.get $0)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $4)
                )
                (else
                 (if
                  (i64.gt_u
                   (local.tee $11
                    (i64.sub
                     (local.get $0)
                     (i64.const 1)
                    )
                   )
                   (i64.const 4294967295)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $4
                  (struct.new $type14
                   (array.get $type15
                    (struct.get $environment40 0
                     (local.get $3)
                    )
                    (i32.wrap_i64
                     (local.get $11)
                    )
                   )
                   (block (result (ref $type14))
                    (if
                     (i32.eqz
                      (struct.get $type49 0
                       (struct.get $environment40 1
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $3
                     (struct.get $type48 0
                      (struct.get $type49 1
                       (struct.get $environment40 1
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (local.get $4)
                   )
                  )
                 )
                 (if (result (ref null $type14))
                  (i64.eqz
                   (local.tee $0
                    (i64.sub
                     (local.get $0)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $4)
                  )
                  (else
                   (if
                    (i64.gt_u
                     (local.tee $11
                      (i64.sub
                       (local.get $0)
                       (i64.const 1)
                      )
                     )
                     (i64.const 4294967295)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $4
                    (struct.new $type14
                     (array.get $type15
                      (struct.get $environment40 0
                       (local.get $3)
                      )
                      (i32.wrap_i64
                       (local.get $11)
                      )
                     )
                     (block (result (ref $type14))
                      (if
                       (i32.eqz
                        (struct.get $type49 0
                         (struct.get $environment40 1
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $3
                       (struct.get $type48 0
                        (struct.get $type49 1
                         (struct.get $environment40 1
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (local.get $4)
                     )
                    )
                   )
                   (if (result (ref null $type14))
                    (i64.eqz
                     (local.tee $0
                      (i64.sub
                       (local.get $0)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $4)
                    )
                    (else
                     (if
                      (i64.gt_u
                       (local.tee $11
                        (i64.sub
                         (local.get $0)
                         (i64.const 1)
                        )
                       )
                       (i64.const 4294967295)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $10
                      (array.get $type15
                       (struct.get $environment40 0
                        (local.get $3)
                       )
                       (i32.wrap_i64
                        (local.get $11)
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type49 0
                        (struct.get $environment40 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function40
                      (struct.get $type48 0
                       (struct.get $type49 1
                        (struct.get $environment40 1
                         (local.get $3)
                        )
                       )
                      )
                      (i64.sub
                       (local.get $0)
                       (i64.const 1)
                      )
                      (struct.new $type14
                       (local.get $10)
                       (local.get $4)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready201)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global201)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (if (result i32)
      (ref.is_null
       (local.get $2)
      )
      (then
       (ref.is_null
        (local.get $1)
       )
      )
      (else
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (if (result i32)
          (f64.eq
           (struct.get $type14 0
            (local.get $2)
           )
           (struct.get $type14 0
            (local.get $1)
           )
          )
          (then
           (local.set $2
            (struct.get $type14 1
             (local.get $2)
            )
           )
           (local.set $1
            (struct.get $type14 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready201)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global201)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $2)
            )
            (then
             (ref.is_null
              (local.get $1)
             )
            )
            (else
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (if (result i32)
                (f64.eq
                 (struct.get $type14 0
                  (local.get $2)
                 )
                 (struct.get $type14 0
                  (local.get $1)
                 )
                )
                (then
                 (local.set $2
                  (struct.get $type14 1
                   (local.get $2)
                  )
                 )
                 (local.set $1
                  (struct.get $type14 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready201)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global201)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (ref.is_null
                    (local.get $1)
                   )
                  )
                  (else
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (if (result i32)
                      (f64.eq
                       (struct.get $type14 0
                        (local.get $2)
                       )
                       (struct.get $type14 0
                        (local.get $1)
                       )
                      )
                      (then
                       (local.set $2
                        (struct.get $type14 1
                         (local.get $2)
                        )
                       )
                       (local.set $1
                        (struct.get $type14 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready201)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global201)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $2)
                        )
                        (then
                         (ref.is_null
                          (local.get $1)
                         )
                        )
                        (else
                         (if (result i32)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (if (result i32)
                            (f64.eq
                             (struct.get $type14 0
                              (local.get $2)
                             )
                             (struct.get $type14 0
                              (local.get $1)
                             )
                            )
                            (then
                             (local.set $2
                              (struct.get $type14 1
                               (local.get $2)
                              )
                             )
                             (local.set $1
                              (struct.get $type14 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready201)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global201)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (ref.is_null
                                (local.get $1)
                               )
                              )
                              (else
                               (if (result i32)
                                (ref.is_null
                                 (local.get $1)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (if (result i32)
                                  (f64.eq
                                   (struct.get $type14 0
                                    (local.get $2)
                                   )
                                   (struct.get $type14 0
                                    (local.get $1)
                                   )
                                  )
                                  (then
                                   (local.set $2
                                    (struct.get $type14 1
                                     (local.get $2)
                                    )
                                   )
                                   (local.set $1
                                    (struct.get $type14 1
                                     (local.get $1)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready201)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global201)
                                    )
                                   )
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $2)
                                    )
                                    (then
                                     (ref.is_null
                                      (local.get $1)
                                     )
                                    )
                                    (else
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $1)
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (if (result i32)
                                        (f64.eq
                                         (struct.get $type14 0
                                          (local.get $2)
                                         )
                                         (struct.get $type14 0
                                          (local.get $1)
                                         )
                                        )
                                        (then
                                         (local.set $2
                                          (struct.get $type14 1
                                           (local.get $2)
                                          )
                                         )
                                         (local.set $1
                                          (struct.get $type14 1
                                           (local.get $1)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready201)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global201)
                                          )
                                         )
                                         (if (result i32)
                                          (ref.is_null
                                           (local.get $2)
                                          )
                                          (then
                                           (ref.is_null
                                            (local.get $1)
                                           )
                                          )
                                          (else
                                           (if (result i32)
                                            (ref.is_null
                                             (local.get $1)
                                            )
                                            (then
                                             (i32.const 0)
                                            )
                                            (else
                                             (if (result i32)
                                              (f64.eq
                                               (struct.get $type14 0
                                                (local.get $2)
                                               )
                                               (struct.get $type14 0
                                                (local.get $1)
                                               )
                                              )
                                              (then
                                               (local.set $2
                                                (struct.get $type14 1
                                                 (local.get $2)
                                                )
                                               )
                                               (local.set $1
                                                (struct.get $type14 1
                                                 (local.get $1)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready201)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global201)
                                                )
                                               )
                                               (if (result i32)
                                                (ref.is_null
                                                 (local.get $2)
                                                )
                                                (then
                                                 (ref.is_null
                                                  (local.get $1)
                                                 )
                                                )
                                                (else
                                                 (if (result i32)
                                                  (ref.is_null
                                                   (local.get $1)
                                                  )
                                                  (then
                                                   (i32.const 0)
                                                  )
                                                  (else
                                                   (if (result i32)
                                                    (f64.eq
                                                     (struct.get $type14 0
                                                      (local.get $2)
                                                     )
                                                     (struct.get $type14 0
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (then
                                                     (local.set $2
                                                      (struct.get $type14 1
                                                       (local.get $2)
                                                      )
                                                     )
                                                     (local.set $1
                                                      (struct.get $type14 1
                                                       (local.get $1)
                                                      )
                                                     )
                                                     (if
                                                      (i32.eqz
                                                       (global.get $ready201)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global201)
                                                      )
                                                     )
                                                     (if (result i32)
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                      (then
                                                       (ref.is_null
                                                        (local.get $1)
                                                       )
                                                      )
                                                      (else
                                                       (if (result i32)
                                                        (ref.is_null
                                                         (local.get $1)
                                                        )
                                                        (then
                                                         (i32.const 0)
                                                        )
                                                        (else
                                                         (if (result i32)
                                                          (f64.eq
                                                           (struct.get $type14 0
                                                            (local.get $2)
                                                           )
                                                           (struct.get $type14 0
                                                            (local.get $1)
                                                           )
                                                          )
                                                          (then
                                                           (local.set $2
                                                            (struct.get $type14 1
                                                             (local.get $2)
                                                            )
                                                           )
                                                           (local.set $1
                                                            (struct.get $type14 1
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (if
                                                            (i32.eqz
                                                             (global.get $ready201)
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                           )
                                                           (drop
                                                            (ref.as_non_null
                                                             (global.get $global201)
                                                            )
                                                           )
                                                           (if (result i32)
                                                            (ref.is_null
                                                             (local.get $2)
                                                            )
                                                            (then
                                                             (ref.is_null
                                                              (local.get $1)
                                                             )
                                                            )
                                                            (else
                                                             (if (result i32)
                                                              (ref.is_null
                                                               (local.get $1)
                                                              )
                                                              (then
                                                               (i32.const 0)
                                                              )
                                                              (else
                                                               (if (result i32)
                                                                (f64.eq
                                                                 (struct.get $type14 0
                                                                  (local.get $2)
                                                                 )
                                                                 (struct.get $type14 0
                                                                  (local.get $1)
                                                                 )
                                                                )
                                                                (then
                                                                 (call $function67
                                                                  (struct.get $type14 1
                                                                   (local.get $2)
                                                                  )
                                                                  (block (result (ref null $type14))
                                                                   (local.set $scratch
                                                                    (struct.get $type14 1
                                                                     (local.get $1)
                                                                    )
                                                                   )
                                                                   (if
                                                                    (i32.eqz
                                                                     (global.get $ready201)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                   )
                                                                   (drop
                                                                    (ref.as_non_null
                                                                     (global.get $global201)
                                                                    )
                                                                   )
                                                                   (local.get $scratch)
                                                                  )
                                                                 )
                                                                )
                                                                (else
                                                                 (i32.const 0)
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                          (else
                                                           (i32.const 0)
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                    (else
                                                     (i32.const 0)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                        (else
                                         (i32.const 0)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                  (else
                                   (i32.const 0)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                            (else
                             (i32.const 0)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready125)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (global.get $ready61)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i32.eqz
        (global.get $ready77)
       )
       (then
        (unreachable)
       )
      )
      (i64.eq
       (i64.trunc_f64_s
        (f64.trunc
         (f64.mul
          (f64.convert_i64_s
           (block (result i64)
            (local.set $scratch_13
             (global.get $global125)
            )
            (local.set $10
             (call_ref $call7
              (struct.get $type7 1
               (local.tee $9
                (struct.get $type36 0
                 (global.get $global77)
                )
               )
              )
              (struct.get $type7 0
               (local.get $9)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready63)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global63)
             )
            )
            (local.get $scratch_13)
           )
          )
          (local.get $10)
         )
        )
       )
       (call $foreign4
        (i64.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function67 (type $call25) (param $0 (ref null $type14)) (param $1 (ref null $type14)) (result i32)
  (local $scratch (ref null $type14))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (f64.eq
        (struct.get $type14 0
         (local.get $0)
        )
        (struct.get $type14 0
         (local.get $1)
        )
       )
       (then
        (return_call $function67
         (struct.get $type14 1
          (local.get $0)
         )
         (block (result (ref null $type14))
          (local.set $scratch
           (struct.get $type14 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready201)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global201)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function68 (type $call21) (param $0 i64) (result i64)
  (local $1 (ref $type51))
  (local $2 (ref $type12))
  (local $3 (ref $type50))
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (local.set $2
   (call $function27)
  )
  (if
   (i32.eqz
    (global.get $ready185)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global185)
   )
  )
  (struct.set $type51 1
   (local.tee $1
    (struct.new_default $type51)
   )
   (struct.new $type50
    (ref.func $function62)
    (struct.new $environment62
     (local.get $2)
     (local.get $1)
    )
   )
  )
  (struct.set $type51 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call_ref $call50
     (struct.get $type50 1
      (local.tee $3
       (ref.as_non_null
        (struct.get $type51 1
         (local.get $1)
        )
       )
      )
     )
     (i64.const 1)
     (struct.get $type50 0
      (local.get $3)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function69 (type $call21) (param $0 i64) (result i64)
  (local $1 (ref $type53))
  (local $2 (ref $type51))
  (local $3 (ref $type12))
  (local $4 (ref $type50))
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (struct.set $type53 1
   (local.tee $1
    (struct.new_default $type53)
   )
   (struct.new $type52
    (struct.new $environment70
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type53 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type53 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (call $function70
    (struct.get $type52 0
     (struct.get $type53 1
      (local.get $1)
     )
    )
    (i64.const 0)
    (local.get $3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready185)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global185)
   )
  )
  (struct.set $type51 1
   (local.tee $2
    (struct.new_default $type51)
   )
   (struct.new $type50
    (ref.func $function62)
    (struct.new $environment62
     (local.get $3)
     (local.get $2)
    )
   )
  )
  (struct.set $type51 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (call_ref $call50
     (struct.get $type50 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type51 1
         (local.get $2)
        )
       )
      )
     )
     (i64.const 1)
     (struct.get $type50 0
      (local.get $4)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function70 (type $call52) (param $0 (ref $environment70)) (param $1 i64) (param $2 (ref $type12)) (result (ref $type12))
  (local $3 (ref $type21))
  (local $4 (ref $type31))
  (local $scratch (ref $type12))
  (if (result (ref $type12))
   (i64.gt_s
    (struct.get $environment70 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready146)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function51
      (ref.as_non_null
       (global.get $global146)
      )
      (block (result (ref $type12))
       (if
        (i32.eqz
         (global.get $ready132)
        )
        (then
         (unreachable)
        )
       )
       (local.set $scratch
        (ref.as_non_null
         (global.get $global132)
        )
       )
       (if
        (i32.eqz
         (global.get $ready148)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global148)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready126)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (if
     (i32.eqz
      (global.get $ready155)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global155)
     )
    )
    (local.set $2
     (call $function54
      (local.get $2)
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $2)
        )
       )
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type53 0
       (struct.get $environment70 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function70
     (struct.get $type52 0
      (struct.get $type53 1
       (struct.get $environment70 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready206)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global206)
   )
  )
  (return_call $function69
   (local.get $0)
  )
 )
 (func $export1 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready142)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global142)
   )
  )
  (return_call $function49
   (local.get $0)
  )
 )
 (func $export2 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready197)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global197)
   )
  )
  (return_call $function65
   (local.get $0)
  )
 )
 (func $export3 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready199)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global199)
   )
  )
  (return_call $function66
   (local.get $0)
  )
 )
 (func $export4 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready204)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global204)
   )
  )
  (return_call $function68
   (local.get $0)
  )
 )
 (func $main
  (local $0 (ref $type39))
  (local $1 (ref $type46))
  (local $2 (ref $type11))
  (local $3 i64)
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global55
   (struct.new_default $type5)
  )
  (global.set $ready55
   (i32.const 1)
  )
  (global.set $global134
   (struct.new $type11
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $global86
   (struct.new_default $type13)
  )
  (global.set $ready86
   (i32.const 1)
  )
  (global.set $global88
   (struct.new_default $type16)
  )
  (global.set $ready88
   (i32.const 1)
  )
  (global.set $global91
   (struct.new_default $type17)
  )
  (global.set $ready91
   (i32.const 1)
  )
  (global.set $global112
   (struct.new_default $type18)
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type19)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global63
   (struct.new_default $type20)
  )
  (global.set $ready63
   (i32.const 1)
  )
  (global.set $global146
   (struct.new $type21
    (ref.func $function50)
   )
  )
  (global.set $ready146
   (i32.const 1)
  )
  (global.set $global65
   (struct.new_default $type22)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global180
   (struct.new_default $type23)
  )
  (global.set $ready180
   (i32.const 1)
  )
  (global.set $global190
   (struct.new_default $type24)
  )
  (global.set $ready190
   (i32.const 1)
  )
  (global.set $global201
   (struct.new_default $type25)
  )
  (global.set $ready201
   (i32.const 1)
  )
  (global.set $global71
   (struct.new $type26
    (ref.func $function29)
    (ref.null none)
   )
  )
  (global.set $global73
   (struct.new $type27
    (ref.func $function30)
    (ref.null none)
   )
  )
  (global.set $global74
   (struct.new $type7
    (ref.func $function31)
    (ref.null none)
   )
  )
  (global.set $global148
   (struct.new_default $type28)
  )
  (global.set $ready148
   (i32.const 1)
  )
  (global.set $global185
   (struct.new_default $type23)
  )
  (global.set $ready185
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type29)
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type30)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global155
   (struct.new_default $type32)
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global162
   (struct.new_default $type33)
  )
  (global.set $ready162
   (i32.const 1)
  )
  (global.set $global75
   (struct.new $type34
    (ref.as_non_null
     (global.get $global71)
    )
   )
  )
  (global.set $ready75
   (i32.const 1)
  )
  (global.set $global76
   (struct.new $type35
    (ref.as_non_null
     (global.get $global73)
    )
   )
  )
  (global.set $ready76
   (i32.const 1)
  )
  (global.set $global77
   (struct.new $type36
    (ref.as_non_null
     (global.get $global74)
    )
   )
  )
  (global.set $ready77
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global86)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global88)
   )
  )
  (local.set $1
   (struct.new $type46
    (i32.const 1)
    (struct.new $type45
     (call $function33
      (struct.new $type14
       (f64.const 1)
       (struct.new $type14
        (f64.const 0)
        (struct.new $type14
         (f64.const 0)
         (struct.new $type14
          (f64.const 1)
          (struct.new $type14
           (f64.const 0)
           (struct.new_default $type14)
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready77)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type36 0
   (global.get $global77)
   (struct.new $type7
    (ref.func $function37)
    (struct.new $environment37
     (struct.new $type47
      (i32.const 1)
      (f64.const 2.328306549295728e-10)
     )
     (struct.new $type47
      (i32.const 1)
      (f64.const 4294967087)
     )
     (struct.new $type47
      (i32.const 1)
      (f64.const 4294944443)
     )
     (struct.new $type47
      (i32.const 1)
      (f64.const 1403580)
     )
     (struct.new $type47
      (i32.const 1)
      (f64.const 810728)
     )
     (struct.new $type47
      (i32.const 1)
      (f64.const 527612)
     )
     (struct.new $type47
      (i32.const 1)
      (f64.const 1370589)
     )
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready76)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type35 0
   (global.get $global76)
   (struct.new $type27
    (ref.func $function38)
    (struct.new $environment38
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready75)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type34 0
   (global.get $global75)
   (struct.new $type26
    (ref.func $function41)
    (struct.new $environment41
     (local.get $1)
    )
   )
  )
  (global.set $global118
   (struct.new $type21
    (ref.func $function42)
   )
  )
  (global.set $ready118
   (i32.const 1)
  )
  (drop
   (call $foreign6)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (local.set $3
   (call $foreign5
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready122)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (global.set $global121
   (if (result i64)
    (call $foreign2)
    (then
     (local.get $3)
    )
    (else
     (unreachable)
    )
   )
  )
  (global.set $ready121
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (call $foreign5
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready122)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global122)
   )
  )
  (global.set $global125
   (if (result i64)
    (call $foreign2)
    (then
     (local.get $3)
    )
    (else
     (unreachable)
    )
   )
  )
  (global.set $ready125
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (global.set $global126
   (if (result (ref $type31))
    (call $foreign2)
    (then
     (struct.new_default $type31)
    )
    (else
     (unreachable)
    )
   )
  )
  (global.set $ready126
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type39 1
   (local.tee $0
    (struct.new_default $type39)
   )
   (struct.new $type11
    (ref.func $function48)
    (struct.new $environment48
     (struct.new $type38
      (i32.const 1)
      (call $function46
       (struct.get $type11 1
        (global.get $global134)
       )
       (global.get $global121)
      )
     )
     (local.get $0)
    )
   )
  )
  (struct.set $type39 0
   (local.get $0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type39 0
     (local.get $0)
    )
   )
   (then
    (unreachable)
   )
  )
  (global.set $global132
   (call_ref $call11
    (struct.get $type11 1
     (local.tee $2
      (ref.as_non_null
       (struct.get $type39 1
        (local.get $0)
       )
      )
     )
    )
    (i64.const 0)
    (struct.get $type11 0
     (local.get $2)
    )
   )
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global142
   (struct.new $type21
    (ref.func $function49)
   )
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global197
   (struct.new $type21
    (ref.func $function65)
   )
  )
  (global.set $ready197
   (i32.const 1)
  )
  (global.set $global199
   (struct.new $type21
    (ref.func $function66)
   )
  )
  (global.set $ready199
   (i32.const 1)
  )
  (global.set $global204
   (struct.new $type21
    (ref.func $function68)
   )
  )
  (global.set $ready204
   (i32.const 1)
  )
  (global.set $global206
   (struct.new $type21
    (ref.func $function69)
   )
  )
  (global.set $ready206
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

