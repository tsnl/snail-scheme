"""Count generated Wasm instructions; these are not physical allocation counts."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = Path(__file__).resolve().parent
CONSTRUCTIONS = {'struct.new', 'struct.new_default', 'array.new',
                 'array.new_default', 'array.new_fixed'}


def parse(source):
    stack = [[]]
    for token in re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+', source):
        if token == '(':
            stack.append([])
        elif token == ')':
            form = stack.pop()
            stack[-1].append(form)
        else:
            stack[-1].append(token)
    assert len(stack) == 1 and len(stack[0]) == 1
    return stack[0][0]


def operations(node):
    if not isinstance(node, list):
        return Counter()
    counts = Counter([node[0]]) if node and isinstance(node[0], str) else Counter()
    for child in node:
        counts.update(operations(child))
    return counts


def stats(path):
    module = parse(path.read_text())
    funcs = [child for child in module if isinstance(child, list) and child[0] == 'func']
    result = {}
    for function in funcs:
        counts = operations(function)
        result[function[1]] = dict(
            constructions={key: counts[key] for key in sorted(CONSTRUCTIONS) if counts[key]},
            direct_calls=counts['call'] + counts['return_call'],
            indirect_calls=counts['call_ref'] + counts['return_call_ref'],
            tail_calls=counts['return_call'] + counts['return_call_ref'],
            signature=[child for child in function[2:] if isinstance(child, list)
                       and child[0] in ('type', 'param', 'result')])
    counts = operations(module)
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                constructions={key: counts[key] for key in sorted(CONSTRUCTIONS) if counts[key]},
                functions=result)


def disassemble(artifact):
    wat = Path(str(artifact) + '.optimized.wat')
    subprocess.run(['wasm-dis', str(artifact), '-o', str(wat)], check=True)
    return wat


summary = dict(scope=__doc__, quicksort={}, fixtures={})
for label, name in [('before', 'base.wasm'), ('after', 'strict.wasm')]:
    artifact = OUTPUT / name
    summary['quicksort'][label] = dict(raw=stats(Path(str(artifact) + '.wat')),
                                      optimized=stats(disassemble(artifact)))
for fixture in ['recursive-capture', 'mutual-recursive-capture', 'direct-deferred-captures',
                'direct-escaping-alias', 'direct-activation-cells']:
    pair = {}
    for label, directory in [('before', 'direct-baseline'), ('after', 'strict-contracts')]:
        artifact = ROOT / 'build' / directory / (fixture + '.wasm')
        pair[label] = dict(raw=stats(Path(str(artifact) + '.wat')),
                           optimized=stats(disassemble(artifact)))
    summary['fixtures'][fixture] = pair
(OUTPUT / 'construction-comparison.json').write_text(json.dumps(summary, indent=2) + '\n')
for name, pair in [('quicksort', summary['quicksort']), *summary['fixtures'].items()]:
    print(name, {label: pair[label]['raw']['constructions'] for label in ('before', 'after')})
