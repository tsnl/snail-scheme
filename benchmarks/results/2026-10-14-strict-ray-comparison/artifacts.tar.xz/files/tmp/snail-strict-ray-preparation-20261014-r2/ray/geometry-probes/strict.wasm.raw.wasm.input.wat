(module
 (rec
  (type $top-scalar (struct (field i32) (field i64)))
  (type $top-reference (struct (field i32) (field eqref)))
  (type $call0 (func (param eqref i64 f64) (result f64)))
  (type $type0 (struct (field (ref $call0)) (field eqref)))
  (type $call1 (func (param eqref f64 i64) (result f64)))
  (type $type1 (struct (field (ref $call1)) (field eqref)))
  (type $call2 (func (param eqref i64 f64) (result i32)))
  (type $type2 (struct (field (ref $call2)) (field eqref)))
  (type $call3 (func (param eqref f64 i64) (result i32)))
  (type $type3 (struct (field (ref $call3)) (field eqref)))
  (type $call4 (func (param eqref) (result i32)))
  (type $type4 (struct (field (ref $call4)) (field eqref)))
  (type $call5 (func (param eqref) (result i64)))
  (type $type5 (struct (field (ref $call5)) (field eqref)))
  (type $call6 (func (param eqref) (result f32)))
  (type $type6 (struct (field (ref $call6)) (field eqref)))
  (type $call7 (func (param eqref) (result f64)))
  (type $type7 (struct (field (ref $call7)) (field eqref)))
  (type $call8 (func (param eqref) (result i32)))
  (type $type8 (struct (field (ref $call8)) (field eqref)))
  (type $call9 (func (param eqref) (result i32)))
  (type $type9 (struct (field (ref $call9)) (field eqref)))
  (type $call10 (func (param eqref) (result i32)))
  (type $type10 (struct (field (ref $call10)) (field eqref)))
  (type $call11 (func (param eqref (ref null $type12)) (result i64)))
  (type $type11 (struct (field (ref $call11)) (field eqref)))
  (type $type12 (struct (field i32) (field (ref null $type12))))
  (type $call13 (func (param eqref i64) (result (ref $type14))))
  (type $type13 (struct (field (ref $call13)) (field eqref)))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $call17 (func (param eqref (ref null $type12)) (result (ref $type14))))
  (type $type17 (struct (field (ref $call17)) (field eqref)))
  (type $call18 (func (param eqref (ref null $type12)) (result (ref $type14))))
  (type $type18 (struct (field (ref $call18)) (field eqref)))
  (type $call19 (func (param eqref (ref $type14)) (result (ref null $type12))))
  (type $type19 (struct (field (ref $call19)) (field eqref)))
  (type $call20 (func (param eqref (ref $type14) i64 i64) (result (ref $type14))))
  (type $type20 (struct (field (ref $call20)) (field eqref)))
  (type $call21 (func (param eqref (ref $type14)) (result (ref $type14))))
  (type $type21 (struct (field (ref $call21)) (field eqref)))
  (type $call22 (func (param eqref (ref null $type23)) (result (ref $type14))))
  (type $type22 (struct (field (ref $call22)) (field eqref)))
  (type $type23 (struct (field (ref $type14)) (field (ref null $type23))))
  (type $call24 (func (param eqref (ref null $type23)) (result i64)))
  (type $type24 (struct (field (ref $call24)) (field eqref)))
  (type $call25 (func (param eqref (ref $type14) (ref null $type23) i64) (result i32)))
  (type $type25 (struct (field (ref $call25)) (field eqref)))
  (type $call26 (func (param eqref (ref $type14) (ref $type14)) (result i32)))
  (type $type26 (struct (field (ref $call26)) (field eqref)))
  (type $call27 (func (param eqref (ref $type14)) (result i32)))
  (type $type27 (struct (field (ref $call27)) (field eqref)))
  (type $call28 (func (param eqref (ref $type14)) (result i32)))
  (type $type28 (struct (field (ref $call28)) (field eqref)))
  (type $call29 (func (param eqref (ref $type14)) (result (ref $type30))))
  (type $type29 (struct (field (ref $call29)) (field eqref)))
  (type $type30 (struct (field (ref $type31))))
  (type $type31 (struct (field (mut i32))))
  (type $call32 (func (param eqref (ref $type30)) (result i32)))
  (type $type32 (struct (field (ref $call32)) (field eqref)))
  (type $call33 (func (param eqref (ref $type14) (ref $type32)) (result i32)))
  (type $type33 (struct (field (ref $call33)) (field eqref)))
  (type $call34 (func (param eqref i32 (ref $type30)) (result i32)))
  (type $type34 (struct (field (ref $call34)) (field eqref)))
  (type $call35 (func (param eqref (ref $type14) (ref $type30)) (result i32)))
  (type $type35 (struct (field (ref $call35)) (field eqref)))
  (type $call36 (func (param eqref i64 (ref $type30)) (result i32)))
  (type $type36 (struct (field (ref $call36)) (field eqref)))
  (type $call37 (func (param eqref (ref null $type38)) (result i64)))
  (type $type37 (struct (field (ref $call37)) (field eqref)))
  (type $type38 (struct (field (ref $type39)) (field (ref null $type38))))
  (type $type39 (struct (field f64) (field f64) (field (ref $type40))))
  (type $type40 (struct (field f64) (field f64) (field f64)))
  (type $call41 (func (param eqref (ref $type42)) (result i32)))
  (type $type41 (struct (field (ref $call41)) (field eqref)))
  (type $type42 (sub (struct (field i32))))
  (type $type43 (sub $type42 (struct (field i32))))
  (type $type44 (sub $type42 (struct (field i32) (field f64))))
  (type $call45 (func (param eqref (ref $type46)) (result i32)))
  (type $type45 (struct (field (ref $call45)) (field eqref)))
  (type $type46 (sub (struct (field i32))))
  (type $type47 (sub $type46 (struct (field i32))))
  (type $type48 (sub $type46 (struct (field i32) (field (ref $type40)))))
  (type $call49 (func (param eqref (ref $type50)) (result i32)))
  (type $type49 (struct (field (ref $call49)) (field eqref)))
  (type $type50 (sub (struct (field i32))))
  (type $type51 (sub $type50 (struct (field i32))))
  (type $type52 (sub $type50 (struct (field i32) (field (ref $type39)) (field (ref $type40)))))
  (type $call53 (func (param eqref f64 f64) (result f64)))
  (type $type53 (struct (field (ref $call53)) (field eqref)))
  (type $call54 (func (param eqref i64 i64) (result i64)))
  (type $type54 (struct (field (ref $call54)) (field eqref)))
  (type $call55 (func (param eqref f64) (result f64)))
  (type $type55 (struct (field (ref $call55)) (field eqref)))
  (type $call56 (func (param eqref f64 f64 f64) (result f64)))
  (type $type56 (struct (field (ref $call56)) (field eqref)))
  (type $call57 (func (param eqref f64 f64 f64) (result (ref $type40))))
  (type $type57 (struct (field (ref $call57)) (field eqref)))
  (type $call58 (func (param eqref (ref $type40) (ref $type40)) (result f64)))
  (type $type58 (struct (field (ref $call58)) (field eqref)))
  (type $call59 (func (param eqref f64 f64 f64) (result (ref $type42))))
  (type $type59 (struct (field (ref $call59)) (field eqref)))
  (type $type60 (struct (field (mut (ref null $type38)))))
  (type $call61 (func (param eqref (ref $type14) i64) (result i32)))
  (type $type61 (struct (field (ref $call61)) (field eqref)))
  (type $call62 (func (param eqref f64 f64) (result i64)))
  (type $type62 (struct (field (ref $call62)) (field eqref)))
  (type $call63 (func (param eqref (ref $type40) (ref $type40)) (result (ref $type50))))
  (type $type63 (struct (field (ref $call63)) (field eqref)))
  (type $call64 (func (param eqref (ref $type39) (ref $type40) (ref $type40)) (result f64)))
  (type $type64 (struct (field (ref $call64)) (field eqref)))
  (type $call65 (func (param eqref f64 f64 f64 f64 f64) (result (ref $type39))))
  (type $type65 (struct (field (ref $call65)) (field eqref)))
  (type $call66 (func (param eqref (ref $type39)) (result f64)))
  (type $type66 (struct (field (ref $call66)) (field eqref)))
  (type $call67 (func (param eqref (ref $type39) (ref $type40) (ref $type40)) (result (ref $type46))))
  (type $type67 (struct (field (ref $call67)) (field eqref)))
  (type $call68 (func (param eqref (ref $type39) (ref $type40)) (result (ref $type40))))
  (type $type68 (struct (field (ref $call68)) (field eqref)))
  (type $call69 (func (param eqref i64 (ref $type14)) (result i32)))
  (type $type69 (struct (field (ref $call69)) (field eqref)))
  (type $call70 (func (param eqref i64 (ref $type14)) (result i64)))
  (type $type70 (struct (field (ref $call70)) (field eqref)))
  (type $call71 (func (param eqref) (result (ref $type14))))
  (type $type71 (struct (field (ref $call71)) (field eqref)))
  (type $call72 (func (param eqref i64 (ref $type14)) (result (ref $type14))))
  (type $type72 (struct (field (ref $call72)) (field eqref)))
  (type $call73 (func (param eqref i64) (result i64)))
  (type $type73 (struct (field (ref $call73)) (field eqref)))
  (type $call74 (func (param eqref (ref $type42)) (result f64)))
  (type $type74 (struct (field (ref $call74)) (field eqref)))
  (type $call75 (func (param eqref (ref $type46)) (result (ref $type40))))
  (type $type75 (struct (field (ref $call75)) (field eqref)))
  (type $call76 (func (param eqref (ref $type50)) (result (ref $type39))))
  (type $type76 (struct (field (ref $call76)) (field eqref)))
  (type $call77 (func (param eqref (ref $type50)) (result (ref $type40))))
  (type $type77 (struct (field (ref $call77)) (field eqref)))
  (type $call78 (func (param eqref (ref null $type38)) (result i32)))
  (type $type78 (struct (field (ref $call78)) (field eqref)))
  (type $call79 (func (param eqref) (result (ref null $type38))))
  (type $type79 (struct (field (ref $call79)) (field eqref)))
  (type $call80 (func (param eqref (ref $type40)) (result i32)))
  (type $type80 (struct (field (ref $call80)) (field eqref)))
  (type $call81 (func (param eqref f64 f64 f64) (result i32)))
  (type $type81 (struct (field (ref $call81)) (field eqref)))
  (type $call82 (func (param eqref (ref $type39) (ref $type40) (ref $type40)) (result i32)))
  (type $type82 (struct (field (ref $call82)) (field eqref)))
  (type $call83 (func (param eqref (ref $type40) (ref $type40)) (result i32)))
  (type $type83 (struct (field (ref $call83)) (field eqref)))
  (type $call84 (func (param eqref f64 f64) (result i32)))
  (type $type84 (struct (field (ref $call84)) (field eqref)))
  (type $environment0 (struct))
  (type $environment1 (struct))
  (type $environment2 (struct))
  (type $environment3 (struct))
  (type $environment4 (struct))
  (type $environment5 (struct))
  (type $environment6 (struct))
  (type $environment7 (struct))
  (type $environment8 (struct))
  (type $environment9 (struct))
  (type $environment10 (struct))
  (type $environment11 (struct))
  (type $environment12 (struct))
  (type $environment13 (struct))
  (type $environment14 (struct))
  (type $environment15 (struct))
  (type $environment16 (struct))
  (type $environment17 (struct))
  (type $environment18 (struct))
  (type $environment19 (struct))
  (type $environment20 (struct))
  (type $environment21 (struct))
  (type $environment22 (struct))
  (type $environment23 (struct))
  (type $environment24 (struct))
  (type $environment25 (struct))
  (type $environment26 (struct))
  (type $environment27 (struct))
  (type $environment28 (struct))
  (type $environment31 (struct))
  (type $environment33 (struct))
  (type $environment34 (struct))
  (type $environment35 (struct))
  (type $environment36 (struct))
  (type $environment38 (struct))
  (type $environment39 (struct))
  (type $environment41 (struct))
  (type $environment43 (struct))
  (type $environment44 (struct))
  (type $environment45 (struct))
  (type $environment46 (struct))
  (type $environment47 (struct))
  (type $environment48 (struct))
  (type $environment50 (struct))
  (type $environment51 (struct))
  (type $environment52 (struct))
  (type $environment53 (struct))
  (type $environment54 (struct))
  (type $environment55 (struct))
  (type $environment56 (struct))
  (type $environment57 (struct))
  (type $environment58 (struct))
  (type $environment59 (struct))
  (type $environment60 (struct))
  (type $environment61 (struct))
  (type $environment62 (struct))
  (type $environment63 (struct))
  (type $environment64 (struct (field i64)))
  (type $environment67 (struct))
  (type $environment68 (struct))
  (type $environment69 (struct))
  (type $environment71 (struct))
  (type $environment72 (struct))
  (type $environment73 (struct))
  (type $environment74 (struct))
  (type $environment75 (struct))
  (type $environment76 (struct))
  (type $environment77 (struct))
  (type $environment78 (struct))
  (type $environment79 (struct))
  (type $environment82 (struct))
  (type $environment83 (struct))
  (type $environment85 (struct))
  (type $environment86 (struct))
  (type $environment88 (struct))
  (type $environment89 (struct))
  (type $environment90 (struct))
  (type $environment91 (struct))
  (type $environment92 (struct))
  (type $environment93 (struct))
  (type $environment94 (struct))
  (type $environment95 (struct))
  (type $environment96 (struct))
  (type $environment97 (struct))
 )
 (type $236 (func))
 (type $237 (func (result i32)))
 (type $238 (func (param i32)))
 (type $239 (func (param i64) (result i64)))
 (type $240 (func (param (ref $type14) i32 (ref $type14) i32 i32)))
 (type $241 (func (param i32 i32)))
 (type $242 (func (result i64)))
 (type $243 (func (param i64) (result i32)))
 (type $244 (func (param f64)))
 (type $245 (func (param i64)))
 (type $246 (func (param i64) (result f64)))
 (type $247 (func (param i32) (result i64)))
 (type $248 (func (param i32 i32) (result i32)))
 (type $249 (func (param i32 i32) (result (ref $type14))))
 (type $250 (func (param (ref $type14) i32) (result (ref $type15))))
 (type $251 (func (param (ref $type14) i64 (ref $type14) i64 i64) (result i32)))
 (type $252 (func (param i32 i32 (ref null $type12) i64) (result i64)))
 (type $253 (func (param (ref $type14) i32 i32 (ref null $type12) i64) (result (ref $type14))))
 (type $254 (func (param (ref $type14) i32 i32 i64 (ref null $type12)) (result (ref null $type12))))
 (type $255 (func (param i32 i32 (ref null $type23) i64) (result i64)))
 (type $256 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
 (type $257 (func (param (ref $type14) i64 i32 i32 i64) (result i32)))
 (type $258 (func (param (ref $type14) (ref $type30) i64 i32 i32 i64) (result i32)))
 (type $259 (func (param i64 (ref $type30) i64 i32 i32 i64) (result i32)))
 (type $260 (func (param i64 (ref $type30) i64 i64 i32 i32 i64) (result i32)))
 (type $261 (func (param (ref $type40) (ref $type40) i32 i32 (ref null $type38) (ref $type50) f64) (result (ref $type50))))
 (type $262 (func (param i32 i32 i64) (result i32)))
 (type $263 (func (param i64 i32 i32 i64) (result i32)))
 (type $264 (func (param i64 (ref $type14) i32 i32 i64) (result (ref $type14))))
 (type $265 (func (param i64 i32 i32 i64 i64) (result i64)))
 (type $266 (func (param i32 i32 (ref null $type38) i64) (result i64)))
 (type $267 (func (param i32 i32 (ref null $type38)) (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign3))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign5 (param i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign6 (param i32 i32)))
 (import "benchmark" "path_length" (func $foreign7 (result i64)))
 (import "benchmark" "path_character" (func $foreign8 (param i64) (result i32)))
 (import "benchmark" "barrier" (func $foreign9 (result i32)))
 (import "benchmark" "hide_i64" (func $foreign10 (param i64) (result i64)))
 (import "probe" "f64" (func $foreign11 (param f64)))
 (import "probe" "i64" (func $foreign12 (param i64)))
 (import "probe" "float" (func $foreign13 (param i64) (result f64)))
 (import "benchmark" "input_i64" (func $foreign14 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type15 4
   (i32.const 32)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type15 1
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 80)
   (i32.const 50)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 18)
  (array.new_fixed $type15 18
   (i32.const 103)
   (i32.const 101)
   (i32.const 111)
   (i32.const 109)
   (i32.const 101)
   (i32.const 116)
   (i32.const 114)
   (i32.const 121)
   (i32.const 45)
   (i32.const 115)
   (i32.const 99)
   (i32.const 101)
   (i32.const 110)
   (i32.const 101)
   (i32.const 46)
   (i32.const 112)
   (i32.const 103)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $global0 (mut (ref null $type0)) (ref.null none))
 (global $ready0 (mut i32) (i32.const 0))
 (global $global3 (mut (ref null $type1)) (ref.null none))
 (global $ready3 (mut i32) (i32.const 0))
 (global $global6 (mut (ref null $type0)) (ref.null none))
 (global $ready6 (mut i32) (i32.const 0))
 (global $global9 (mut (ref null $type1)) (ref.null none))
 (global $ready9 (mut i32) (i32.const 0))
 (global $global12 (mut (ref null $type0)) (ref.null none))
 (global $ready12 (mut i32) (i32.const 0))
 (global $global15 (mut (ref null $type1)) (ref.null none))
 (global $ready15 (mut i32) (i32.const 0))
 (global $global18 (mut (ref null $type0)) (ref.null none))
 (global $ready18 (mut i32) (i32.const 0))
 (global $global21 (mut (ref null $type1)) (ref.null none))
 (global $ready21 (mut i32) (i32.const 0))
 (global $global24 (mut (ref null $type2)) (ref.null none))
 (global $ready24 (mut i32) (i32.const 0))
 (global $global27 (mut (ref null $type3)) (ref.null none))
 (global $ready27 (mut i32) (i32.const 0))
 (global $global30 (mut (ref null $type2)) (ref.null none))
 (global $ready30 (mut i32) (i32.const 0))
 (global $global33 (mut (ref null $type3)) (ref.null none))
 (global $ready33 (mut i32) (i32.const 0))
 (global $global36 (mut (ref null $type2)) (ref.null none))
 (global $ready36 (mut i32) (i32.const 0))
 (global $global39 (mut (ref null $type3)) (ref.null none))
 (global $ready39 (mut i32) (i32.const 0))
 (global $global42 (mut (ref null $type2)) (ref.null none))
 (global $ready42 (mut i32) (i32.const 0))
 (global $global45 (mut (ref null $type3)) (ref.null none))
 (global $ready45 (mut i32) (i32.const 0))
 (global $global48 (mut (ref null $type2)) (ref.null none))
 (global $ready48 (mut i32) (i32.const 0))
 (global $global51 (mut (ref null $type3)) (ref.null none))
 (global $ready51 (mut i32) (i32.const 0))
 (global $global54 (mut (ref null $type4)) (ref.null none))
 (global $ready54 (mut i32) (i32.const 0))
 (global $global55 (mut (ref null $type5)) (ref.null none))
 (global $ready55 (mut i32) (i32.const 0))
 (global $global56 (mut (ref null $type6)) (ref.null none))
 (global $ready56 (mut i32) (i32.const 0))
 (global $global57 (mut (ref null $type7)) (ref.null none))
 (global $ready57 (mut i32) (i32.const 0))
 (global $global58 (mut (ref null $type8)) (ref.null none))
 (global $ready58 (mut i32) (i32.const 0))
 (global $global59 (mut (ref null $type9)) (ref.null none))
 (global $ready59 (mut i32) (i32.const 0))
 (global $global60 (mut (ref null $type10)) (ref.null none))
 (global $ready60 (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type11)) (ref.null none))
 (global $ready68 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global63 (mut (ref null $type17)) (ref.null none))
 (global $ready63 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type18)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global76 (mut (ref null $type19)) (ref.null none))
 (global $ready76 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type20)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type21)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type22)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type24)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type25)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type26)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type28)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type29)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type32)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global241 (mut (ref null $type33)) (ref.null none))
 (global $ready241 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type34)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type35)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type32)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type36)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type36)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global321 (mut (ref null $type37)) (ref.null none))
 (global $ready321 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type41)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global146 (mut (ref null $type45)) (ref.null none))
 (global $ready146 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type49)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type53)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global158 (mut (ref null $type53)) (ref.null none))
 (global $ready158 (mut i32) (i32.const 0))
 (global $global279 (mut (ref null $type54)) (ref.null none))
 (global $ready279 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type55)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global163 (mut (ref null $type56)) (ref.null none))
 (global $ready163 (mut i32) (i32.const 0))
 (global $global167 (mut (ref null $type57)) (ref.null none))
 (global $ready167 (mut i32) (i32.const 0))
 (global $global172 (mut (ref null $type58)) (ref.null none))
 (global $ready172 (mut i32) (i32.const 0))
 (global $global175 (mut (ref null $type59)) (ref.null none))
 (global $ready175 (mut i32) (i32.const 0))
 (global $global183 (mut (ref null $type60)) (ref.null none))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global184 (mut (ref null $type40)) (ref.null none))
 (global $ready184 (mut i32) (i32.const 0))
 (global $global185 (mut (ref null $type61)) (ref.null none))
 (global $ready185 (mut i32) (i32.const 0))
 (global $global194 (mut (ref null $type62)) (ref.null none))
 (global $ready194 (mut i32) (i32.const 0))
 (global $global198 (mut (ref null $type58)) (ref.null none))
 (global $ready198 (mut i32) (i32.const 0))
 (global $global202 (mut (ref null $type63)) (ref.null none))
 (global $ready202 (mut i32) (i32.const 0))
 (global $global227 (mut (ref null $type64)) (ref.null none))
 (global $ready227 (mut i32) (i32.const 0))
 (global $global246 (mut (ref null $type65)) (ref.null none))
 (global $ready246 (mut i32) (i32.const 0))
 (global $global239 (mut (ref null $type66)) (ref.null none))
 (global $ready239 (mut i32) (i32.const 0))
 (global $global211 (mut (ref null $type67)) (ref.null none))
 (global $ready211 (mut i32) (i32.const 0))
 (global $global215 (mut (ref null $type67)) (ref.null none))
 (global $ready215 (mut i32) (i32.const 0))
 (global $global232 (mut (ref null $type68)) (ref.null none))
 (global $ready232 (mut i32) (i32.const 0))
 (global $global235 (mut (ref null $type68)) (ref.null none))
 (global $ready235 (mut i32) (i32.const 0))
 (global $global253 (mut (ref null $type69)) (ref.null none))
 (global $ready253 (mut i32) (i32.const 0))
 (global $global260 (mut (ref null $type70)) (ref.null none))
 (global $ready260 (mut i32) (i32.const 0))
 (global $global263 (mut (ref null $type71)) (ref.null none))
 (global $ready263 (mut i32) (i32.const 0))
 (global $global268 (mut i64) (i64.const 0))
 (global $ready268 (mut i32) (i32.const 0))
 (global $global269 (mut (ref null $type14)) (ref.null none))
 (global $ready269 (mut i32) (i32.const 0))
 (global $global270 (mut i64) (i64.const 0))
 (global $ready270 (mut i32) (i32.const 0))
 (global $global271 (mut (ref null $type72)) (ref.null none))
 (global $ready271 (mut i32) (i32.const 0))
 (global $global274 (mut (ref null $type73)) (ref.null none))
 (global $ready274 (mut i32) (i32.const 0))
 (global $global282 (mut (ref null $type41)) (ref.null none))
 (global $ready282 (mut i32) (i32.const 0))
 (global $global283 (mut (ref null $type74)) (ref.null none))
 (global $ready283 (mut i32) (i32.const 0))
 (global $global284 (mut (ref null $type45)) (ref.null none))
 (global $ready284 (mut i32) (i32.const 0))
 (global $global285 (mut (ref null $type75)) (ref.null none))
 (global $ready285 (mut i32) (i32.const 0))
 (global $global286 (mut (ref null $type49)) (ref.null none))
 (global $ready286 (mut i32) (i32.const 0))
 (global $global287 (mut (ref null $type76)) (ref.null none))
 (global $ready287 (mut i32) (i32.const 0))
 (global $global288 (mut (ref null $type77)) (ref.null none))
 (global $ready288 (mut i32) (i32.const 0))
 (global $global289 (mut (ref null $type53)) (ref.null none))
 (global $ready289 (mut i32) (i32.const 0))
 (global $global290 (mut (ref null $type53)) (ref.null none))
 (global $ready290 (mut i32) (i32.const 0))
 (global $global291 (mut (ref null $type78)) (ref.null none))
 (global $ready291 (mut i32) (i32.const 0))
 (global $global293 (mut (ref null $type79)) (ref.null none))
 (global $ready293 (mut i32) (i32.const 0))
 (global $global294 (mut (ref null $type80)) (ref.null none))
 (global $ready294 (mut i32) (i32.const 0))
 (global $global296 (mut (ref null $type81)) (ref.null none))
 (global $ready296 (mut i32) (i32.const 0))
 (global $global301 (mut (ref null $type82)) (ref.null none))
 (global $ready301 (mut i32) (i32.const 0))
 (global $global306 (mut (ref null $type83)) (ref.null none))
 (global $ready306 (mut i32) (i32.const 0))
 (global $global310 (mut (ref null $type84)) (ref.null none))
 (global $ready310 (mut i32) (i32.const 0))
 (global $global313 (mut (ref null $type73)) (ref.null none))
 (global $ready313 (mut i32) (i32.const 0))
 (export "geometry-probe" (func $export0))
 (export "main" (func $main))
 (func $string-min (param $a i32) (param $b i32) (result i32)
  (if (result i32)
   (i32.lt_u
    (local.get $a)
    (local.get $b)
   )
   (then
    (local.get $a)
   )
   (else
    (local.get $b)
   )
  )
 )
 (func $string-new (param $length i32) (param $fill i32) (result (ref $type14))
  (local $first (ref null $type15))
  (local $directory (ref null $type16))
  (local $remaining i32)
  (local $index i32)
  (local $size i32)
  (local.set $size
   (call $string-min
    (local.get $length)
    (i32.const 8192)
   )
  )
  (local.set $first
   (array.new $type15
    (local.get $fill)
    (local.get $size)
   )
  )
  (local.set $remaining
   (i32.sub
    (local.get $length)
    (local.get $size)
   )
  )
  (if
   (local.get $remaining)
   (then
    (local.set $directory
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $length)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (local.set $size
      (call $string-min
       (local.get $remaining)
       (i32.const 8192)
      )
     )
     (array.set $type16
      (local.get $directory)
      (local.get $index)
      (array.new $type15
       (local.get $fill)
       (local.get $size)
      )
     )
     (local.set $index
      (i32.add
       (local.get $index)
       (i32.const 1)
      )
     )
     (local.set $remaining
      (i32.sub
       (local.get $remaining)
       (local.get $size)
      )
     )
     (br_if $label
      (local.get $remaining)
     )
    )
   )
  )
  (struct.new $type14
   (i32.const 1)
   (local.get $length)
   (ref.as_non_null
    (local.get $first)
   )
   (local.get $directory)
  )
 )
 (func $string-block (param $string (ref $type14)) (param $index i32) (result (ref $type15))
  (if (result (ref $type15))
   (i32.lt_u
    (local.get $index)
    (i32.const 8192)
   )
   (then
    (struct.get $type14 2
     (local.get $string)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type16
      (struct.get $type14 3
       (local.get $string)
      )
      (i32.sub
       (i32.shr_u
        (local.get $index)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy-forward (param $target (ref $type14)) (param $at i32) (param $source (ref $type14)) (param $start i32) (param $remaining i32)
  (local $step i32)
  (block $block
   (loop $label
    (br_if $block
     (i32.eqz
      (local.get $remaining)
     )
    )
    (local.set $step
     (call $string-min
      (local.get $remaining)
      (call $string-min
       (i32.sub
        (i32.const 8192)
        (i32.and
         (local.get $at)
         (i32.const 8191)
        )
       )
       (i32.sub
        (i32.const 8192)
        (i32.and
         (local.get $start)
         (i32.const 8191)
        )
       )
      )
     )
    )
    (array.copy $type15 $type15
     (call $string-block
      (local.get $target)
      (local.get $at)
     )
     (i32.and
      (local.get $at)
      (i32.const 8191)
     )
     (call $string-block
      (local.get $source)
      (local.get $start)
     )
     (i32.and
      (local.get $start)
      (i32.const 8191)
     )
     (local.get $step)
    )
    (local.set $at
     (i32.add
      (local.get $at)
      (local.get $step)
     )
    )
    (local.set $start
     (i32.add
      (local.get $start)
      (local.get $step)
     )
    )
    (local.set $remaining
     (i32.sub
      (local.get $remaining)
      (local.get $step)
     )
    )
    (br $label)
   )
   (unreachable)
  )
 )
 (func $string-copy-backward (param $target (ref $type14)) (param $at i32) (param $source (ref $type14)) (param $start i32) (param $remaining i32)
  (local $step i32)
  (local.set $at
   (i32.add
    (local.get $at)
    (local.get $remaining)
   )
  )
  (local.set $start
   (i32.add
    (local.get $start)
    (local.get $remaining)
   )
  )
  (block $block
   (loop $label
    (br_if $block
     (i32.eqz
      (local.get $remaining)
     )
    )
    (local.set $step
     (call $string-min
      (local.get $remaining)
      (call $string-min
       (i32.add
        (i32.and
         (i32.sub
          (local.get $at)
          (i32.const 1)
         )
         (i32.const 8191)
        )
        (i32.const 1)
       )
       (i32.add
        (i32.and
         (i32.sub
          (local.get $start)
          (i32.const 1)
         )
         (i32.const 8191)
        )
        (i32.const 1)
       )
      )
     )
    )
    (local.set $at
     (i32.sub
      (local.get $at)
      (local.get $step)
     )
    )
    (local.set $start
     (i32.sub
      (local.get $start)
      (local.get $step)
     )
    )
    (array.copy $type15 $type15
     (call $string-block
      (local.get $target)
      (local.get $at)
     )
     (i32.and
      (local.get $at)
      (i32.const 8191)
     )
     (call $string-block
      (local.get $source)
      (local.get $start)
     )
     (i32.and
      (local.get $start)
      (i32.const 8191)
     )
     (local.get $step)
    )
    (local.set $remaining
     (i32.sub
      (local.get $remaining)
      (local.get $step)
     )
    )
    (br $label)
   )
   (unreachable)
  )
 )
 (func $string-copy (param $target (ref $type14)) (param $at i64) (param $source (ref $type14)) (param $start i64) (param $end i64) (result i32)
  (if
   (i32.ne
    (struct.get $type14 0
     (local.get $target)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $at)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $target)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $end)
    (i64.extend_i32_u
     (struct.get $type14 1
      (local.get $source)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $start)
    (local.get $end)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (i64.sub
     (local.get $end)
     (local.get $start)
    )
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $target)
      )
     )
     (local.get $at)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (ref.eq
     (local.get $target)
     (local.get $source)
    )
    (i64.gt_u
     (local.get $at)
     (local.get $start)
    )
   )
   (then
    (call $string-copy-backward
     (local.get $target)
     (i32.wrap_i64
      (local.get $at)
     )
     (local.get $source)
     (i32.wrap_i64
      (local.get $start)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $end)
       (local.get $start)
      )
     )
    )
   )
   (else
    (call $string-copy-forward
     (local.get $target)
     (i32.wrap_i64
      (local.get $at)
     )
     (local.get $source)
     (i32.wrap_i64
      (local.get $start)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $end)
       (local.get $start)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $function0 (type $call0) (param $environment eqref) (param $argument1 i64) (param $argument2 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument1)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument2)
  )
  (f64.add
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function1 (type $call1) (param $environment eqref) (param $argument4 f64) (param $argument5 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument4)
  )
  (local.set $local2
   (local.get $argument5)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.add
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function2 (type $call0) (param $environment eqref) (param $argument7 i64) (param $argument8 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument7)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument8)
  )
  (f64.sub
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function3 (type $call1) (param $environment eqref) (param $argument10 f64) (param $argument11 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument10)
  )
  (local.set $local2
   (local.get $argument11)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.sub
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function4 (type $call0) (param $environment eqref) (param $argument13 i64) (param $argument14 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument13)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument14)
  )
  (f64.mul
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function5 (type $call1) (param $environment eqref) (param $argument16 f64) (param $argument17 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument16)
  )
  (local.set $local2
   (local.get $argument17)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.mul
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function6 (type $call0) (param $environment eqref) (param $argument19 i64) (param $argument20 f64) (result f64)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument19)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument20)
  )
  (f64.div
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function7 (type $call1) (param $environment eqref) (param $argument22 f64) (param $argument23 i64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument22)
  )
  (local.set $local2
   (local.get $argument23)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.div
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function8 (type $call2) (param $environment eqref) (param $argument25 i64) (param $argument26 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument25)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument26)
  )
  (f64.eq
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function9 (type $call3) (param $environment eqref) (param $argument28 f64) (param $argument29 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument28)
  )
  (local.set $local2
   (local.get $argument29)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.eq
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function10 (type $call2) (param $environment eqref) (param $argument31 i64) (param $argument32 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument31)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument32)
  )
  (f64.lt
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function11 (type $call3) (param $environment eqref) (param $argument34 f64) (param $argument35 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument34)
  )
  (local.set $local2
   (local.get $argument35)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.lt
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function12 (type $call2) (param $environment eqref) (param $argument37 i64) (param $argument38 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument37)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument38)
  )
  (f64.le
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function13 (type $call3) (param $environment eqref) (param $argument40 f64) (param $argument41 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument40)
  )
  (local.set $local2
   (local.get $argument41)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.le
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function14 (type $call2) (param $environment eqref) (param $argument43 i64) (param $argument44 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument43)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument44)
  )
  (f64.gt
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function15 (type $call3) (param $environment eqref) (param $argument46 f64) (param $argument47 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument46)
  )
  (local.set $local2
   (local.get $argument47)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.gt
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function16 (type $call2) (param $environment eqref) (param $argument49 i64) (param $argument50 f64) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local1 i64)
  (local.set $local1
   (local.get $argument49)
  )
  (local.set $local0
   (f64.convert_i64_s
    (local.get $local1)
   )
  )
  (local.set $local2
   (local.get $argument50)
  )
  (f64.ge
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function17 (type $call3) (param $environment eqref) (param $argument52 f64) (param $argument53 i64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument52)
  )
  (local.set $local2
   (local.get $argument53)
  )
  (local.set $local1
   (f64.convert_i64_s
    (local.get $local2)
   )
  )
  (f64.ge
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function18 (type $call4) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function19 (type $call5) (param $environment eqref) (result i64)
  (i64.const 0)
 )
 (func $function20 (type $call6) (param $environment eqref) (result f32)
  (f32.const 0)
 )
 (func $function21 (type $call7) (param $environment eqref) (result f64)
  (f64.const 0)
 )
 (func $function22 (type $call8) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function23 (type $call9) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function24 (type $call10) (param $environment eqref) (result i32)
  (i32.const 0)
 )
 (func $function25 (type $call13) (param $environment eqref) (param $argument62 i64) (result (ref $type14))
  (local $local0 i64)
  (local $local1 i32)
  (local.set $local0
   (local.get $argument62)
  )
  (local.set $local1
   (i32.const 0)
  )
  (if
   (i64.gt_u
    (local.get $local0)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (call $string-new
   (i32.wrap_i64
    (local.get $local0)
   )
   (local.get $local1)
  )
 )
 (func $function26 (type $call17) (param $environment eqref) (param $argument64 (ref null $type12)) (result (ref $type14))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type18))
  (local.set $local0
   (local.get $argument64)
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (return_call $function27
   (struct.get $type18 1
    (ref.as_non_null
     (local.get $local1)
    )
   )
   (local.get $local0)
  )
 )
 (func $function27 (type $call18) (param $environment eqref) (param $argument66 (ref null $type12)) (result (ref $type14))
  (local $local0 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local2 i64)
  (local $local7 i64)
  (local $local1 (ref null $type14))
  (local $local3 (ref null $type12))
  (local $local6 (ref null $type12))
  (local $local4 (ref null $type11))
  (local $local5 (ref null $type13))
  (local.set $local3
   (local.get $argument66)
  )
  (if
   (i32.eqz
    (global.get $ready68)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global68)
   )
  )
  (local.set $local2
   (call $function28
    (struct.get $type11 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type13 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local6
   (local.get $argument66)
  )
  (local.set $local7
   (i64.const 0)
  )
  (local.set $local9
   (i32.const 0)
  )
  (local.set $local8
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local8)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local9)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function30
   (ref.as_non_null
    (local.get $local1)
   )
   (local.get $local9)
   (local.get $local8)
   (local.get $local6)
   (local.get $local7)
  )
 )
 (func $function28 (type $call11) (param $environment eqref) (param $argument69 (ref null $type12)) (result i64)
  (local $local0 (ref null $type12))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument69)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function29
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function29 (param $capture70 i32) (param $initialized70 i32) (param $argument71 (ref null $type12)) (param $argument72 i64) (result i64)
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local7 (ref null $type12))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local.set $local7
   (local.get $argument71)
  )
  (if (result i64)
   (ref.is_null
    (local.get $local7)
   )
   (then
    (local.get $argument72)
   )
   (else
    (local.set $local5
     (local.get $argument72)
    )
    (local.set $local6
     (i64.const 4294967295)
    )
    (if (result i64)
     (i64.eq
      (local.get $local5)
      (local.get $local6)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $local1
       (local.get $argument71)
      )
      (local.set $local0
       (struct.get $type12 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument72)
      )
      (local.set $local4
       (i64.const 1)
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized70)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture70)
      )
      (return_call $function29
       (local.get $capture70)
       (local.get $initialized70)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function30 (param $capture67 (ref $type14)) (param $capture73 i32) (param $initialized73 i32) (param $argument74 (ref null $type12)) (param $argument75 i64) (result (ref $type14))
  (local $local0 (ref null $type12))
  (local $local1 (ref null $type12))
  (local $local8 (ref null $type12))
  (local $local10 (ref null $type12))
  (local $local5 (ref null $type14))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local7 i32)
  (local $local9 i32)
  (local.set $local10
   (local.get $argument74)
  )
  (if (result (ref $type14))
   (ref.is_null
    (local.get $local10)
   )
   (then
    (local.get $capture67)
   )
   (else
    (local.set $local5
     (local.get $capture67)
    )
    (local.set $local6
     (local.get $argument75)
    )
    (local.set $local8
     (local.get $argument74)
    )
    (local.set $local7
     (struct.get $type12 0
      (local.get $local8)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local6)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local6)
     )
    )
    (array.set $type15
     (call $string-block
      (ref.as_non_null
       (local.get $local5)
      )
      (local.get $local9)
     )
     (i32.and
      (local.get $local9)
      (i32.const 8191)
     )
     (local.get $local7)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument74)
    )
    (local.set $local0
     (struct.get $type12 1
      (local.get $local1)
     )
    )
    (local.set $local3
     (local.get $argument75)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized73)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture73)
    )
    (return_call $function30
     (local.get $capture67)
     (local.get $capture73)
     (local.get $initialized73)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function31 (type $call19) (param $environment eqref) (param $argument77 (ref $type14)) (result (ref null $type12))
  (local $local0 i64)
  (local $local3 i32)
  (local $local4 i32)
  (local $local1 (ref null $type14))
  (local $local2 (ref null $type12))
  (local.set $local1
   (local.get $argument77)
  )
  (local.set $local0
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local2
   (ref.null none)
  )
  (local.set $local4
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local4)
  )
  (return_call $function32
   (local.get $argument77)
   (local.get $local4)
   (local.get $local3)
   (local.get $local0)
   (local.get $local2)
  )
 )
 (func $function32 (param $capture77 (ref $type14)) (param $capture78 i32) (param $initialized78 i32) (param $argument79 i64) (param $argument80 (ref null $type12)) (result (ref null $type12))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local11 i64)
  (local $local12 i64)
  (local $local4 i32)
  (local $local9 i32)
  (local $local3 (ref null $type12))
  (local $local10 (ref null $type12))
  (local $local5 (ref null $type14))
  (local.set $local11
   (local.get $argument79)
  )
  (local.set $local12
   (i64.const 0)
  )
  (if (result (ref null $type12))
   (i64.eq
    (local.get $local11)
    (local.get $local12)
   )
   (then
    (local.get $argument80)
   )
   (else
    (local.set $local1
     (local.get $argument79)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (local.set $local5
     (local.get $capture77)
    )
    (local.set $local7
     (local.get $argument79)
    )
    (local.set $local8
     (i64.const 1)
    )
    (local.set $local6
     (i64.sub
      (local.get $local7)
      (local.get $local8)
     )
    )
    (if
     (i64.ge_u
      (local.get $local6)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local5)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (i32.wrap_i64
      (local.get $local6)
     )
    )
    (local.set $local4
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local5)
       )
       (local.get $local9)
      )
      (i32.and
       (local.get $local9)
       (i32.const 8191)
      )
     )
    )
    (local.set $local10
     (local.get $argument80)
    )
    (local.set $local3
     (struct.new $type12
      (local.get $local4)
      (local.get $local10)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized78)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture78)
    )
    (return_call $function32
     (local.get $capture77)
     (local.get $capture78)
     (local.get $initialized78)
     (local.get $local0)
     (local.get $local3)
    )
   )
  )
 )
 (func $function33 (type $call20) (param $environment eqref) (param $argument82 (ref $type14)) (param $argument83 i64) (param $argument84 i64) (result (ref $type14))
  (local $local0 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local15 i32)
  (local $local16 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local7 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local13 i64)
  (local $local14 i64)
  (local $local17 i64)
  (local $local18 i64)
  (local $local19 i64)
  (local $local20 i64)
  (local $local1 (ref null $type14))
  (local $local6 (ref null $type14))
  (local $local8 (ref null $type14))
  (local $local21 (ref null $type14))
  (local $local5 (ref null $type13))
  (local.set $local13
   (local.get $argument83)
  )
  (local.set $local14
   (i64.const 0)
  )
  (local.set $local12
   (i64.lt_s
    (local.get $local13)
    (local.get $local14)
   )
  )
  (local.set $local11
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref $type14))
   (if (result i32)
    (local.get $local12)
    (then
     (if
      (i32.eqz
       (local.get $local11)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local12)
    )
    (else
     (local.set $local17
      (local.get $argument84)
     )
     (local.set $local18
      (local.get $argument83)
     )
     (local.set $local16
      (i64.lt_s
       (local.get $local17)
       (local.get $local18)
      )
     )
     (local.set $local15
      (i32.const 1)
     )
     (if
      (i32.eqz
       (local.get $local15)
      )
      (then
       (unreachable)
      )
     )
     (if (result i32)
      (local.get $local16)
      (then
       (if
        (i32.eqz
         (local.get $local15)
        )
        (then
         (unreachable)
        )
       )
       (local.get $local16)
      )
      (else
       (local.set $local19
        (local.get $argument84)
       )
       (local.set $local21
        (local.get $argument82)
       )
       (local.set $local20
        (i64.extend_i32_u
         (struct.get $type14 1
          (ref.as_non_null
           (local.get $local21)
          )
         )
        )
       )
       (i64.gt_s
        (local.get $local19)
        (local.get $local20)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local3
     (local.get $argument84)
    )
    (local.set $local4
     (local.get $argument83)
    )
    (local.set $local2
     (i64.sub
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (local.set $local1
     (call $function25
      (struct.get $type13 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (local.get $local2)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local7
     (i64.const 0)
    )
    (local.set $local8
     (local.get $argument82)
    )
    (local.set $local9
     (local.get $argument83)
    )
    (local.set $local10
     (local.get $argument84)
    )
    (drop
     (call $string-copy
      (ref.as_non_null
       (local.get $local6)
      )
      (local.get $local7)
      (ref.as_non_null
       (local.get $local8)
      )
      (local.get $local9)
      (local.get $local10)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
 )
 (func $function34 (type $call21) (param $environment eqref) (param $argument89 (ref $type14)) (result (ref $type14))
  (local $local0 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local4 (ref null $type20))
  (local $local1 i64)
  (local $local2 i64)
  (local.set $local0
   (local.get $argument89)
  )
  (local.set $local1
   (i64.const 0)
  )
  (local.set $local3
   (local.get $argument89)
  )
  (local.set $local2
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (return_call $function33
   (struct.get $type20 1
    (ref.as_non_null
     (local.get $local4)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
   (local.get $local2)
  )
 )
 (func $function35 (type $call22) (param $environment eqref) (param $argument91 (ref null $type23)) (result (ref $type14))
  (local $local0 i32)
  (local $local2 i64)
  (local $local8 i64)
  (local $local1 (ref null $type14))
  (local $local6 (ref null $type14))
  (local $local3 (ref null $type23))
  (local $local7 (ref null $type23))
  (local $local4 (ref null $type24))
  (local $local5 (ref null $type13))
  (local $local9 (ref null $type25))
  (local.set $local3
   (local.get $argument91)
  )
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $local2
   (call $function36
    (struct.get $type24 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $local1
   (call $function25
    (struct.get $type13 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local7
   (local.get $argument91)
  )
  (local.set $local8
   (i64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (call $function38
    (struct.get $type25 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
    (local.get $local7)
    (local.get $local8)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (local.get $local1)
  )
 )
 (func $function36 (type $call24) (param $environment eqref) (param $argument94 (ref null $type23)) (result i64)
  (local $local0 (ref null $type23))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument94)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function37
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function37 (param $capture95 i32) (param $initialized95 i32) (param $argument96 (ref null $type23)) (param $argument97 i64) (result i64)
  (local $local0 (ref null $type23))
  (local $local1 (ref null $type23))
  (local $local6 (ref null $type23))
  (local $local7 (ref null $type23))
  (local $local5 (ref null $type14))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local.set $local8
   (local.get $argument97)
  )
  (local.set $local9
   (i64.const 4294967294)
  )
  (if (result i64)
   (i64.gt_s
    (local.get $local8)
    (local.get $local9)
   )
   (then
    (unreachable)
   )
   (else
    (local.set $local7
     (local.get $argument96)
    )
    (if (result i64)
     (ref.is_null
      (local.get $local7)
     )
     (then
      (local.get $argument97)
     )
     (else
      (local.set $local1
       (local.get $argument96)
      )
      (local.set $local0
       (struct.get $type23 1
        (local.get $local1)
       )
      )
      (local.set $local3
       (local.get $argument97)
      )
      (local.set $local6
       (local.get $argument96)
      )
      (local.set $local5
       (struct.get $type23 0
        (local.get $local6)
       )
      )
      (local.set $local4
       (i64.extend_i32_u
        (struct.get $type14 1
         (ref.as_non_null
          (local.get $local5)
         )
        )
       )
      )
      (local.set $local2
       (i64.add
        (local.get $local3)
        (local.get $local4)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized95)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture95)
      )
      (return_call $function37
       (local.get $capture95)
       (local.get $initialized95)
       (local.get $local0)
       (local.get $local2)
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call25) (param $environment eqref) (param $argument99 (ref $type14)) (param $argument100 (ref null $type23)) (param $argument101 i64) (result i32)
  (local $local0 i32)
  (local $local1 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local2 (ref null $type14))
  (local $local4 (ref null $type14))
  (local $local11 (ref null $type14))
  (local $local13 (ref null $type14))
  (local $local3 (ref null $type23))
  (local $local5 (ref null $type23))
  (local $local6 (ref null $type23))
  (local $local14 (ref null $type23))
  (local $local17 (ref null $type23))
  (local $local10 (ref null $type25))
  (local.set $local17
   (local.get $argument100)
  )
  (if (result i32)
   (ref.is_null
    (local.get $local17)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local3
     (local.get $argument100)
    )
    (local.set $local2
     (struct.get $type23 0
      (local.get $local3)
     )
    )
    (local.set $local1
     (i64.extend_i32_u
      (struct.get $type14 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local11
     (local.get $argument99)
    )
    (local.set $local12
     (local.get $argument101)
    )
    (local.set $local14
     (local.get $argument100)
    )
    (local.set $local13
     (struct.get $type23 0
      (local.get $local14)
     )
    )
    (local.set $local15
     (i64.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local16
     (local.get $local1)
    )
    (drop
     (call $string-copy
      (ref.as_non_null
       (local.get $local11)
      )
      (local.get $local12)
      (ref.as_non_null
       (local.get $local13)
      )
      (local.get $local15)
      (local.get $local16)
     )
    )
    (local.set $local4
     (local.get $argument99)
    )
    (local.set $local6
     (local.get $argument100)
    )
    (local.set $local5
     (struct.get $type23 1
      (local.get $local6)
     )
    )
    (local.set $local8
     (local.get $argument101)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (local.get $local1)
    )
    (local.set $local7
     (i64.add
      (local.get $local8)
      (local.get $local9)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (struct.get $type25 1
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (ref.as_non_null
      (local.get $local4)
     )
     (local.get $local5)
     (local.get $local7)
    )
   )
  )
 )
 (func $function39 (type $call26) (param $environment eqref) (param $argument104 (ref $type14)) (param $argument105 (ref $type14)) (result i32)
  (local $local0 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local1 i32)
  (local $local2 i32)
  (local $local4 (ref null $type14))
  (local $local6 (ref null $type14))
  (local.set $local4
   (local.get $argument104)
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local6
   (local.get $argument105)
  )
  (local.set $local5
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
  )
  (if (result i32)
   (i64.eq
    (local.get $local3)
    (local.get $local5)
   )
   (then
    (local.set $local0
     (i64.const 0)
    )
    (local.set $local2
     (i32.const 0)
    )
    (local.set $local1
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local1)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local2)
    )
    (return_call $function40
     (local.get $argument104)
     (local.get $argument105)
     (local.get $local2)
     (local.get $local1)
     (local.get $local0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function40 (param $capture104 (ref $type14)) (param $capture105 (ref $type14)) (param $capture106 i32) (param $initialized106 i32) (param $argument107 i64) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local8 i32)
  (local $local11 i32)
  (local $local12 i32)
  (local $local15 i32)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local10 i64)
  (local $local14 i64)
  (local $local4 (ref null $type14))
  (local $local9 (ref null $type14))
  (local $local13 (ref null $type14))
  (local.set $local2
   (local.get $argument107)
  )
  (local.set $local4
   (local.get $capture104)
  )
  (local.set $local3
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
   )
  )
  (local.set $local1
   (i64.eq
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (local.get $local1)
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (else
    (local.set $local9
     (local.get $capture104)
    )
    (local.set $local10
     (local.get $argument107)
    )
    (if
     (i64.ge_u
      (local.get $local10)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local9)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (i32.wrap_i64
      (local.get $local10)
     )
    )
    (local.set $local8
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local9)
       )
       (local.get $local11)
      )
      (i32.and
       (local.get $local11)
       (i32.const 8191)
      )
     )
    )
    (local.set $local13
     (local.get $capture105)
    )
    (local.set $local14
     (local.get $argument107)
    )
    (if
     (i64.ge_u
      (local.get $local14)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local13)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (i32.wrap_i64
      (local.get $local14)
     )
    )
    (local.set $local12
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local13)
       )
       (local.get $local15)
      )
      (i32.and
       (local.get $local15)
       (i32.const 8191)
      )
     )
    )
    (if (result i32)
     (i32.eq
      (local.get $local8)
      (local.get $local12)
     )
     (then
      (local.set $local6
       (local.get $argument107)
      )
      (local.set $local7
       (i64.const 1)
      )
      (local.set $local5
       (i64.add
        (local.get $local6)
        (local.get $local7)
       )
      )
      (if
       (i32.eqz
        (local.get $initialized106)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture106)
      )
      (return_call $function40
       (local.get $capture104)
       (local.get $capture105)
       (local.get $capture106)
       (local.get $initialized106)
       (local.get $local5)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call27) (param $environment eqref) (param $argument110 (ref $type14)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local2 (ref null $type14))
  (call $foreign0)
  (drop
   (i32.const 0)
  )
  (local.set $local2
   (local.get $argument110)
  )
  (local.set $local1
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (return_call $function42
   (local.get $argument110)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local5)
   (local.get $local4)
   (local.get $local3)
  )
 )
 (func $function42 (param $capture110 (ref $type14)) (param $capture111 i64) (param $capture112 i32) (param $initialized112 i32) (param $argument113 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local3 i32)
  (local $local6 i32)
  (local $local4 (ref null $type14))
  (local.set $local7
   (local.get $argument113)
  )
  (local.set $local8
   (local.get $capture111)
  )
  (if (result i32)
   (i64.eq
    (local.get $local7)
    (local.get $local8)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (local.get $capture110)
    )
    (local.set $local5
     (local.get $argument113)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (call $foreign1
     (local.get $local3)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument113)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized112)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture112)
    )
    (return_call $function42
     (local.get $capture110)
     (local.get $capture111)
     (local.get $capture112)
     (local.get $initialized112)
     (local.get $local0)
    )
   )
  )
 )
 (func $function43 (type $call28) (param $environment eqref) (param $argument115 (ref $type14)) (result i32)
  (local $local0 i32)
  (local $local1 i32)
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type27))
  (local.set $local2
   (local.get $argument115)
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (struct.get $type27 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (call $foreign2)
  )
  (local.set $local1
   (i32.const 1)
  )
  (i32.eq
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function44 (type $call27) (param $environment eqref) (param $argument117 (ref $type14)) (result i32)
  (local $local0 (ref null $type14))
  (local $local1 (ref null $type27))
  (local.set $local0
   (local.get $argument117)
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (struct.get $type27 1
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (ref.as_non_null
     (local.get $local0)
    )
   )
  )
  (call $foreign3)
  (i32.const 0)
 )
 (func $function45 (type $call29) (param $environment eqref) (param $argument119 (ref $type14)) (result (ref $type30))
  (local $local0 (ref null $type31))
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type27))
  (local $local1 i32)
  (local.set $local2
   (local.get $argument119)
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (struct.get $type27 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local1
   (call $foreign4)
  )
  (local.set $local0
   (struct.new $type31
    (local.get $local1)
   )
  )
  (struct.new $type30
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function46 (type $call32) (param $environment eqref) (param $argument121 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local3 i32)
  (local $local4 i32)
  (local $local6 i32)
  (local $local8 i32)
  (local $local9 i32)
  (local $local10 i32)
  (local $local1 (ref null $type31))
  (local $local5 (ref null $type31))
  (local $local7 (ref null $type31))
  (local $local2 (ref null $type30))
  (local.set $local2
   (local.get $argument121)
  )
  (local.set $local1
   (struct.get $type30 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local4
   (struct.get $type31 0
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (local.get $local4)
  )
  (local.set $local10
   (i32.const -1)
  )
  (if (result i32)
   (i32.eq
    (local.get $local9)
    (local.get $local10)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local8
     (i32.const -1)
    )
    (struct.set $type31 0
     (ref.as_non_null
      (local.get $local7)
     )
     (local.get $local8)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (local.get $local4)
    )
    (call $foreign5
     (local.get $local6)
    )
    (i32.const 0)
   )
  )
 )
 (func $function47 (type $call34) (param $environment eqref) (param $argument125 i32) (param $argument126 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local3 i32)
  (local $local1 (ref null $type31))
  (local $local2 (ref null $type30))
  (local.set $local2
   (local.get $argument126)
  )
  (local.set $local1
   (struct.get $type30 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (struct.get $type31 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local3
   (local.get $argument125)
  )
  (call $foreign6
   (local.get $local0)
   (local.get $local3)
  )
  (i32.const 0)
 )
 (func $function48 (type $call35) (param $environment eqref) (param $argument128 (ref $type14)) (param $argument129 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 i64)
  (local $local3 i64)
  (local $local2 (ref null $type14))
  (local.set $local2
   (local.get $argument128)
  )
  (local.set $local1
   (i64.extend_i32_u
    (struct.get $type14 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local3
   (i64.const 0)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (return_call $function49
   (local.get $argument128)
   (local.get $argument129)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local5)
   (local.get $local4)
   (local.get $local3)
  )
 )
 (func $function49 (param $capture128 (ref $type14)) (param $capture129 (ref $type30)) (param $capture130 i64) (param $capture131 i32) (param $initialized131 i32) (param $argument132 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local9 i64)
  (local $local10 i64)
  (local $local3 i32)
  (local $local6 i32)
  (local $local4 (ref null $type14))
  (local $local7 (ref null $type30))
  (local $local8 (ref null $type34))
  (local.set $local9
   (local.get $argument132)
  )
  (local.set $local10
   (local.get $capture130)
  )
  (if (result i32)
   (i64.eq
    (local.get $local9)
    (local.get $local10)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (local.get $capture128)
    )
    (local.set $local5
     (local.get $argument132)
    )
    (if
     (i64.ge_u
      (local.get $local5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (i32.wrap_i64
      (local.get $local5)
     )
    )
    (local.set $local3
     (array.get $type15
      (call $string-block
       (ref.as_non_null
        (local.get $local4)
       )
       (local.get $local6)
      )
      (i32.and
       (local.get $local6)
       (i32.const 8191)
      )
     )
    )
    (local.set $local7
     (local.get $capture129)
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (drop
     (call $function47
      (struct.get $type34 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (local.get $local3)
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local1
     (local.get $argument132)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized131)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture131)
    )
    (return_call $function49
     (local.get $capture128)
     (local.get $capture129)
     (local.get $capture130)
     (local.get $capture131)
     (local.get $initialized131)
     (local.get $local0)
    )
   )
  )
 )
 (func $function50 (type $call32) (param $environment eqref) (param $argument134 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local1 (ref null $type30))
  (local $local2 (ref null $type34))
  (local.set $local0
   (i32.const 10)
  )
  (local.set $local1
   (local.get $argument134)
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (return_call $function47
   (struct.get $type34 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (local.get $local0)
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function51 (type $call36) (param $environment eqref) (param $argument136 i64) (param $argument137 (ref $type30)) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local10 i64)
  (local $local11 i64)
  (local $local7 i32)
  (local $local5 (ref null $type30))
  (local $local8 (ref null $type30))
  (local $local6 (ref null $type36))
  (local $local9 (ref null $type34))
  (local.set $local10
   (local.get $argument136)
  )
  (local.set $local11
   (i64.const 0)
  )
  (drop
   (if (result i32)
    (i64.lt_s
     (local.get $local10)
     (local.get $local11)
    )
    (then
     (local.set $local7
      (i32.const 45)
     )
     (local.set $local8
      (local.get $argument137)
     )
     (if
      (i32.eqz
       (global.get $ready124)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local9
      (ref.as_non_null
       (global.get $global124)
      )
     )
     (drop
      (call $function47
       (struct.get $type34 1
        (ref.as_non_null
         (local.get $local9)
        )
       )
       (local.get $local7)
       (ref.as_non_null
        (local.get $local8)
       )
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 0)
    )
   )
  )
  (local.set $local3
   (local.get $argument136)
  )
  (local.set $local4
   (i64.const 0)
  )
  (local.set $local0
   (if (result i64)
    (i64.gt_s
     (local.get $local3)
     (local.get $local4)
    )
    (then
     (local.set $local1
      (i64.const 0)
     )
     (local.set $local2
      (local.get $argument136)
     )
     (i64.sub
      (local.get $local1)
      (local.get $local2)
     )
    )
    (else
     (local.get $argument136)
    )
   )
  )
  (local.set $local5
   (local.get $argument137)
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (return_call $function52
   (struct.get $type36 1
    (ref.as_non_null
     (local.get $local6)
    )
   )
   (local.get $local0)
   (ref.as_non_null
    (local.get $local5)
   )
  )
 )
 (func $function52 (type $call36) (param $environment eqref) (param $argument139 i64) (param $argument140 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local12 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local10 (ref null $type30))
  (local $local13 (ref null $type30))
  (local $local11 (ref null $type34))
  (local $local14 (ref null $type36))
  (local.set $local2
   (local.get $argument139)
  )
  (local.set $local3
   (i64.const 10)
  )
  (local.set $local1
   (i64.div_s
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (local.get $local1)
  )
  (local.set $local16
   (i64.const 0)
  )
  (drop
   (if (result i32)
    (i64.eq
     (local.get $local15)
     (local.get $local16)
    )
    (then
     (i32.const 0)
    )
    (else
     (if
      (i32.eqz
       (local.get $local0)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local12
      (local.get $local1)
     )
     (local.set $local13
      (local.get $argument140)
     )
     (if
      (i32.eqz
       (global.get $ready138)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local14
      (ref.as_non_null
       (global.get $global138)
      )
     )
     (drop
      (call $function52
       (struct.get $type36 1
        (ref.as_non_null
         (local.get $local14)
        )
       )
       (local.get $local12)
       (ref.as_non_null
        (local.get $local13)
       )
      )
     )
     (i32.const 0)
    )
   )
  )
  (local.set $local6
   (i64.const 48)
  )
  (local.set $local8
   (local.get $argument139)
  )
  (local.set $local9
   (i64.const 10)
  )
  (local.set $local7
   (i64.rem_s
    (local.get $local8)
    (local.get $local9)
   )
  )
  (local.set $local5
   (i64.sub
    (local.get $local6)
    (local.get $local7)
   )
  )
  (if
   (i64.gt_u
    (local.get $local5)
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ge_u
     (local.get $local5)
     (i64.const 55296)
    )
    (i64.le_u
     (local.get $local5)
     (i64.const 57343)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (i32.wrap_i64
    (local.get $local5)
   )
  )
  (local.set $local10
   (local.get $argument140)
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (return_call $function47
   (struct.get $type34 1
    (ref.as_non_null
     (local.get $local11)
    )
   )
   (local.get $local4)
   (ref.as_non_null
    (local.get $local10)
   )
  )
 )
 (func $function53 (type $call41) (param $environment eqref) (param $argument143 (ref $type42)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local3 f64)
  (local $local1 (ref null $type42))
  (local.set $local1
   (local.get $argument143)
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type42 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type44 1
      (ref.cast (ref $type44)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (i32.const 1)
   )
  )
 )
 (func $function54 (type $call45) (param $environment eqref) (param $argument147 (ref $type46)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local1 (ref null $type46))
  (local $local3 (ref null $type40))
  (local.set $local1
   (local.get $argument147)
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type46 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type48 1
      (ref.cast (ref $type48)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (i32.const 1)
   )
  )
 )
 (func $function55 (type $call49) (param $environment eqref) (param $argument151 (ref $type50)) (result i32)
  (local $local0 i32)
  (local $local2 i32)
  (local $local4 i32)
  (local $local1 (ref null $type50))
  (local $local3 (ref null $type39))
  (local $local5 (ref null $type40))
  (local.set $local1
   (local.get $argument151)
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i32.eq
    (struct.get $type50 0
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (i32.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local3
     (struct.get $type52 1
      (ref.cast (ref $type52)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local2
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (struct.get $type52 2
      (ref.cast (ref $type52)
       (ref.as_non_null
        (local.get $local1)
       )
      )
     )
    )
    (local.set $local4
     (i32.const 1)
    )
    (i32.const 1)
   )
  )
 )
 (func $function56 (type $call53) (param $environment eqref) (param $argument156 f64) (param $argument157 f64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local3 f64)
  (local $local4 f64)
  (local $local2 i32)
  (local.set $local3
   (local.get $argument156)
  )
  (local.set $local4
   (local.get $argument156)
  )
  (local.set $local2
   (f64.eq
    (local.get $local3)
    (local.get $local4)
   )
  )
  (if (result f64)
   (i32.eqz
    (local.get $local2)
   )
   (then
    (local.get $argument156)
   )
   (else
    (local.set $local0
     (local.get $argument156)
    )
    (local.set $local1
     (local.get $argument157)
    )
    (if (result f64)
     (f64.lt
      (local.get $local0)
      (local.get $local1)
     )
     (then
      (local.get $argument156)
     )
     (else
      (local.get $argument157)
     )
    )
   )
  )
 )
 (func $function57 (type $call53) (param $environment eqref) (param $argument159 f64) (param $argument160 f64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local3 f64)
  (local $local4 f64)
  (local $local2 i32)
  (local.set $local3
   (local.get $argument159)
  )
  (local.set $local4
   (local.get $argument159)
  )
  (local.set $local2
   (f64.eq
    (local.get $local3)
    (local.get $local4)
   )
  )
  (if (result f64)
   (i32.eqz
    (local.get $local2)
   )
   (then
    (local.get $argument159)
   )
   (else
    (local.set $local0
     (local.get $argument159)
    )
    (local.set $local1
     (local.get $argument160)
    )
    (if (result f64)
     (f64.gt
      (local.get $local0)
      (local.get $local1)
     )
     (then
      (local.get $argument159)
     )
     (else
      (local.get $argument160)
     )
    )
   )
  )
 )
 (func $function58 (type $call55) (param $environment eqref) (param $argument162 f64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local.set $local0
   (local.get $argument162)
  )
  (local.set $local1
   (local.get $argument162)
  )
  (f64.mul
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function59 (type $call56) (param $environment eqref) (param $argument164 f64) (param $argument165 f64) (param $argument166 f64) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 f64)
  (local $local3 f64)
  (local $local5 f64)
  (local $local6 f64)
  (local $local8 f64)
  (local $local9 f64)
  (local $local4 (ref null $type55))
  (local $local7 (ref null $type55))
  (local $local10 (ref null $type55))
  (local.set $local3
   (local.get $argument164)
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local2
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (local.get $local3)
   )
  )
  (local.set $local6
   (local.get $argument165)
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local5
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.get $local6)
   )
  )
  (local.set $local1
   (f64.add
    (local.get $local2)
    (local.get $local5)
   )
  )
  (local.set $local9
   (local.get $argument166)
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local8
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local10)
     )
    )
    (local.get $local9)
   )
  )
  (local.set $local0
   (f64.add
    (local.get $local1)
    (local.get $local8)
   )
  )
  (f64.sqrt
   (local.get $local0)
  )
 )
 (func $function60 (type $call57) (param $environment eqref) (param $argument168 f64) (param $argument169 f64) (param $argument170 f64) (result (ref $type40))
  (local $local0 i32)
  (local $local1 f64)
  (local $local2 f64)
  (local $local3 f64)
  (local $local4 f64)
  (local $local6 f64)
  (local $local7 f64)
  (local $local8 f64)
  (local $local9 f64)
  (local $local10 f64)
  (local $local11 f64)
  (local $local12 f64)
  (local $local13 f64)
  (local $local14 f64)
  (local $local5 (ref null $type56))
  (local.set $local2
   (local.get $argument168)
  )
  (local.set $local3
   (local.get $argument169)
  )
  (local.set $local4
   (local.get $argument170)
  )
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (local.set $local1
   (call $function59
    (struct.get $type56 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
    (local.get $local3)
    (local.get $local4)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local7
   (local.get $argument168)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (local.get $local1)
  )
  (local.set $local6
   (f64.div
    (local.get $local7)
    (local.get $local8)
   )
  )
  (local.set $local10
   (local.get $argument169)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (local.get $local1)
  )
  (local.set $local9
   (f64.div
    (local.get $local10)
    (local.get $local11)
   )
  )
  (local.set $local13
   (local.get $argument170)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (local.get $local1)
  )
  (local.set $local12
   (f64.div
    (local.get $local13)
    (local.get $local14)
   )
  )
  (struct.new $type40
   (local.get $local6)
   (local.get $local9)
   (local.get $local12)
  )
 )
 (func $function61 (type $call58) (param $environment eqref) (param $argument173 (ref $type40)) (param $argument174 (ref $type40)) (result f64)
  (local $local0 f64)
  (local $local1 f64)
  (local $local3 f64)
  (local $local5 f64)
  (local $local6 f64)
  (local $local8 f64)
  (local $local10 f64)
  (local $local11 f64)
  (local $local13 f64)
  (local $local2 (ref null $type40))
  (local $local4 (ref null $type40))
  (local $local7 (ref null $type40))
  (local $local9 (ref null $type40))
  (local $local12 (ref null $type40))
  (local $local14 (ref null $type40))
  (local $local15 (ref null $type56))
  (local.set $local2
   (local.get $argument173)
  )
  (local.set $local1
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local4
   (local.get $argument174)
  )
  (local.set $local3
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local4)
    )
   )
  )
  (local.set $local0
   (f64.sub
    (local.get $local1)
    (local.get $local3)
   )
  )
  (local.set $local7
   (local.get $argument173)
  )
  (local.set $local6
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local7)
    )
   )
  )
  (local.set $local9
   (local.get $argument174)
  )
  (local.set $local8
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local9)
    )
   )
  )
  (local.set $local5
   (f64.sub
    (local.get $local6)
    (local.get $local8)
   )
  )
  (local.set $local12
   (local.get $argument173)
  )
  (local.set $local11
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local12)
    )
   )
  )
  (local.set $local14
   (local.get $argument174)
  )
  (local.set $local13
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local14)
    )
   )
  )
  (local.set $local10
   (f64.sub
    (local.get $local11)
    (local.get $local13)
   )
  )
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (return_call $function59
   (struct.get $type56 1
    (ref.as_non_null
     (local.get $local15)
    )
   )
   (local.get $local0)
   (local.get $local5)
   (local.get $local10)
  )
 )
 (func $function62 (type $call59) (param $environment eqref) (param $argument176 f64) (param $argument177 f64) (param $argument178 f64) (result (ref $type42))
  (local $local0 i32)
  (local $local10 i32)
  (local $local12 i32)
  (local $local14 i32)
  (local $local1 f64)
  (local $local2 f64)
  (local $local3 f64)
  (local $local5 f64)
  (local $local6 f64)
  (local $local7 f64)
  (local $local8 f64)
  (local $local9 f64)
  (local $local11 f64)
  (local $local13 f64)
  (local $local15 f64)
  (local $local16 f64)
  (local $local17 f64)
  (local $local18 f64)
  (local $local19 f64)
  (local $local20 f64)
  (local $local21 f64)
  (local $local22 f64)
  (local $local23 f64)
  (local $local24 f64)
  (local $local25 f64)
  (local $local26 f64)
  (local $local27 f64)
  (local $local28 f64)
  (local $local29 f64)
  (local $local30 f64)
  (local $local31 f64)
  (local $local33 f64)
  (local $local34 f64)
  (local $local35 f64)
  (local $local36 f64)
  (local $local37 f64)
  (local $local38 f64)
  (local $local39 f64)
  (local $local40 f64)
  (local $local41 f64)
  (local $local4 (ref null $type55))
  (local $local32 (ref null $type53))
  (local.set $local40
   (local.get $argument176)
  )
  (local.set $local41
   (f64.const 0)
  )
  (if (result (ref $type42))
   (f64.eq
    (local.get $local40)
    (local.get $local41)
   )
   (then
    (local.set $local37
     (f64.const -1)
    )
    (local.set $local38
     (local.get $argument178)
    )
    (local.set $local36
     (f64.mul
      (local.get $local37)
      (local.get $local38)
     )
    )
    (local.set $local39
     (local.get $argument177)
    )
    (local.set $local35
     (f64.div
      (local.get $local36)
      (local.get $local39)
     )
    )
    (struct.new $type44
     (i32.const 1)
     (local.get $local35)
    )
   )
   (else
    (local.set $local3
     (local.get $argument177)
    )
    (if
     (i32.eqz
      (global.get $ready161)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global161)
     )
    )
    (local.set $local2
     (call $function58
      (struct.get $type55 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (local.get $local3)
     )
    )
    (local.set $local7
     (f64.const 4)
    )
    (local.set $local8
     (local.get $argument176)
    )
    (local.set $local6
     (f64.mul
      (local.get $local7)
      (local.get $local8)
     )
    )
    (local.set $local9
     (local.get $argument178)
    )
    (local.set $local5
     (f64.mul
      (local.get $local6)
      (local.get $local9)
     )
    )
    (local.set $local1
     (f64.sub
      (local.get $local2)
      (local.get $local5)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local33
     (local.get $local1)
    )
    (local.set $local34
     (f64.const 0)
    )
    (if (result (ref $type42))
     (f64.lt
      (local.get $local33)
      (local.get $local34)
     )
     (then
      (struct.new $type43
       (i32.const 0)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local16
       (local.get $local1)
      )
      (local.set $local11
       (f64.sqrt
        (local.get $local16)
       )
      )
      (local.set $local10
       (i32.const 1)
      )
      (local.set $local17
       (f64.const -1)
      )
      (local.set $local18
       (local.get $argument177)
      )
      (local.set $local13
       (f64.mul
        (local.get $local17)
        (local.get $local18)
       )
      )
      (local.set $local12
       (i32.const 1)
      )
      (local.set $local19
       (f64.const 2)
      )
      (local.set $local20
       (local.get $argument176)
      )
      (local.set $local15
       (f64.mul
        (local.get $local19)
        (local.get $local20)
       )
      )
      (local.set $local14
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local12)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local24
       (local.get $local13)
      )
      (if
       (i32.eqz
        (local.get $local10)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local25
       (local.get $local11)
      )
      (local.set $local23
       (f64.add
        (local.get $local24)
        (local.get $local25)
       )
      )
      (if
       (i32.eqz
        (local.get $local14)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local26
       (local.get $local15)
      )
      (local.set $local22
       (f64.div
        (local.get $local23)
        (local.get $local26)
       )
      )
      (if
       (i32.eqz
        (local.get $local12)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local29
       (local.get $local13)
      )
      (if
       (i32.eqz
        (local.get $local10)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local30
       (local.get $local11)
      )
      (local.set $local28
       (f64.sub
        (local.get $local29)
        (local.get $local30)
       )
      )
      (if
       (i32.eqz
        (local.get $local14)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local31
       (local.get $local15)
      )
      (local.set $local27
       (f64.div
        (local.get $local28)
        (local.get $local31)
       )
      )
      (if
       (i32.eqz
        (global.get $ready155)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local32
       (ref.as_non_null
        (global.get $global155)
       )
      )
      (local.set $local21
       (call $function56
        (struct.get $type53 1
         (ref.as_non_null
          (local.get $local32)
         )
        )
        (local.get $local22)
        (local.get $local27)
       )
      )
      (struct.new $type44
       (i32.const 1)
       (local.get $local21)
      )
     )
    )
   )
  )
 )
 (func $function63 (type $call61) (param $environment eqref) (param $argument186 (ref $type14)) (param $argument187 i64) (result i32)
  (local $local0 (ref null $type14))
  (local $local3 (ref null $type14))
  (local $local5 (ref null $type14))
  (local $local1 (ref null $type32))
  (local $local2 (ref null $type33))
  (local $local4 (ref null $type27))
  (local $local6 (ref null $type28))
  (local.set $local5
   (local.get $argument186)
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (drop
   (if (result i32)
    (call $function43
     (struct.get $type28 1
      (ref.as_non_null
       (local.get $local6)
      )
     )
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (then
     (local.set $local3
      (local.get $argument186)
     )
     (if
      (i32.eqz
       (global.get $ready116)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local4
      (ref.as_non_null
       (global.get $global116)
      )
     )
     (drop
      (call $function44
       (struct.get $type27 1
        (ref.as_non_null
         (local.get $local4)
        )
       )
       (ref.as_non_null
        (local.get $local3)
       )
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 0)
    )
   )
  )
  (local.set $local0
   (local.get $argument186)
  )
  (local.set $local1
   (struct.new $type32
    (ref.func $function64)
    (struct.new $environment64
     (local.get $argument187)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready241)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global241)
   )
  )
  (return_call $function77
   (struct.get $type33 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function64 (type $call32) (param $environment eqref) (param $argument188 (ref $type30)) (result i32)
  (local $local0 i32)
  (local $local5 i32)
  (local $local6 i32)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local12 i64)
  (local $local18 i64)
  (local $local7 (ref null $type30))
  (local $local10 (ref null $type30))
  (local $local13 (ref null $type30))
  (local $local16 (ref null $type30))
  (local $local19 (ref null $type30))
  (local $local22 (ref null $type30))
  (local $local8 (ref null $type32))
  (local $local9 (ref null $type14))
  (local $local15 (ref null $type14))
  (local $local21 (ref null $type14))
  (local $local11 (ref null $type35))
  (local $local17 (ref null $type35))
  (local $local23 (ref null $type35))
  (local $local14 (ref null $type36))
  (local $local20 (ref null $type36))
  (local.set $local2
   (struct.get $environment64 0
    (ref.cast (ref $environment64)
     (local.get $environment)
    )
   )
  )
  (local.set $local3
   (i64.const 100)
  )
  (local.set $local1
   (i64.mul
    (local.get $local2)
    (local.get $local3)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local21
   (global.get $string2)
  )
  (local.set $local22
   (local.get $argument188)
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local23
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function48
    (struct.get $type35 1
     (ref.as_non_null
      (local.get $local23)
     )
    )
    (ref.as_non_null
     (local.get $local21)
    )
    (ref.as_non_null
     (local.get $local22)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local18
   (local.get $local1)
  )
  (local.set $local19
   (local.get $argument188)
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local20
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (drop
   (call $function51
    (struct.get $type36 1
     (ref.as_non_null
      (local.get $local20)
     )
    )
    (local.get $local18)
    (ref.as_non_null
     (local.get $local19)
    )
   )
  )
  (local.set $local15
   (global.get $string1)
  )
  (local.set $local16
   (local.get $argument188)
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function48
    (struct.get $type35 1
     (ref.as_non_null
      (local.get $local17)
     )
    )
    (ref.as_non_null
     (local.get $local15)
    )
    (ref.as_non_null
     (local.get $local16)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local12
   (local.get $local1)
  )
  (local.set $local13
   (local.get $argument188)
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (drop
   (call $function51
    (struct.get $type36 1
     (ref.as_non_null
      (local.get $local14)
     )
    )
    (local.get $local12)
    (ref.as_non_null
     (local.get $local13)
    )
   )
  )
  (local.set $local9
   (global.get $string0)
  )
  (local.set $local10
   (local.get $argument188)
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function48
    (struct.get $type35 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (ref.as_non_null
     (local.get $local9)
    )
    (ref.as_non_null
     (local.get $local10)
    )
   )
  )
  (local.set $local7
   (local.get $argument188)
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (call $function50
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local8)
     )
    )
    (ref.as_non_null
     (local.get $local7)
    )
   )
  )
  (local.set $local4
   (i64.const 0)
  )
  (local.set $local6
   (i32.const 0)
  )
  (local.set $local5
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local5)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local6)
  )
  (return_call $function65
   (struct.get $environment64 0
    (ref.cast (ref $environment64)
     (local.get $environment)
    )
   )
   (local.get $argument188)
   (block (result i64)
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.get $local1)
   )
   (local.get $local6)
   (local.get $local5)
   (local.get $local4)
  )
 )
 (func $function65 (param $capture187 i64) (param $capture188 (ref $type30)) (param $capture189 i64) (param $capture190 i32) (param $initialized190 i32) (param $argument191 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local4 i32)
  (local $local5 i32)
  (local.set $local6
   (local.get $argument191)
  )
  (local.set $local7
   (local.get $capture189)
  )
  (if (result i32)
   (i64.eq
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local3
     (i64.const 0)
    )
    (local.set $local5
     (i32.const 0)
    )
    (local.set $local4
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local5)
    )
    (drop
     (call $function66
      (local.get $capture187)
      (local.get $capture188)
      (local.get $capture189)
      (local.get $argument191)
      (local.get $local5)
      (local.get $local4)
      (local.get $local3)
     )
    )
    (local.set $local1
     (local.get $argument191)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized190)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture190)
    )
    (return_call $function65
     (local.get $capture187)
     (local.get $capture188)
     (local.get $capture189)
     (local.get $capture190)
     (local.get $initialized190)
     (local.get $local0)
    )
   )
  )
 )
 (func $function66 (param $capture187 i64) (param $capture188 (ref $type30)) (param $capture189 i64) (param $capture191 i64) (param $capture192 i32) (param $initialized192 i32) (param $argument193 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local10 i64)
  (local $local12 i64)
  (local $local17 i64)
  (local $local19 i64)
  (local $local23 i64)
  (local $local24 i64)
  (local $local6 f64)
  (local $local7 f64)
  (local $local8 f64)
  (local $local9 f64)
  (local $local11 f64)
  (local $local13 f64)
  (local $local14 f64)
  (local $local15 f64)
  (local $local16 f64)
  (local $local18 f64)
  (local $local3 (ref null $type30))
  (local $local21 (ref null $type30))
  (local $local4 (ref null $type32))
  (local $local20 (ref null $type62))
  (local $local22 (ref null $type36))
  (local.set $local23
   (local.get $argument193)
  )
  (local.set $local24
   (local.get $capture189)
  )
  (if (result i32)
   (i64.eq
    (local.get $local23)
    (local.get $local24)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local7
     (f64.const -50)
    )
    (local.set $local10
     (local.get $argument193)
    )
    (local.set $local9
     (f64.convert_i64_s
      (local.get $local10)
     )
    )
    (local.set $local12
     (local.get $capture187)
    )
    (local.set $local11
     (f64.convert_i64_s
      (local.get $local12)
     )
    )
    (local.set $local8
     (f64.div
      (local.get $local9)
      (local.get $local11)
     )
    )
    (local.set $local6
     (f64.add
      (local.get $local7)
      (local.get $local8)
     )
    )
    (local.set $local14
     (f64.const -50)
    )
    (local.set $local17
     (local.get $capture191)
    )
    (local.set $local16
     (f64.convert_i64_s
      (local.get $local17)
     )
    )
    (local.set $local19
     (local.get $capture187)
    )
    (local.set $local18
     (f64.convert_i64_s
      (local.get $local19)
     )
    )
    (local.set $local15
     (f64.div
      (local.get $local16)
      (local.get $local18)
     )
    )
    (local.set $local13
     (f64.add
      (local.get $local14)
      (local.get $local15)
     )
    )
    (if
     (i32.eqz
      (global.get $ready194)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local20
     (ref.as_non_null
      (global.get $global194)
     )
    )
    (local.set $local5
     (call $function67
      (struct.get $type62 1
       (ref.as_non_null
        (local.get $local20)
       )
      )
      (local.get $local6)
      (local.get $local13)
     )
    )
    (local.set $local21
     (local.get $capture188)
    )
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local22
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (drop
     (call $function51
      (struct.get $type36 1
       (ref.as_non_null
        (local.get $local22)
       )
      )
      (local.get $local5)
      (ref.as_non_null
       (local.get $local21)
      )
     )
    )
    (local.set $local3
     (local.get $capture188)
    )
    (if
     (i32.eqz
      (global.get $ready133)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local4
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (drop
     (call $function50
      (struct.get $type32 1
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (local.set $local1
     (local.get $argument193)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized192)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture192)
    )
    (return_call $function66
     (local.get $capture187)
     (local.get $capture188)
     (local.get $capture189)
     (local.get $capture191)
     (local.get $capture192)
     (local.get $initialized192)
     (local.get $local0)
    )
   )
  )
 )
 (func $function67 (type $call62) (param $environment eqref) (param $argument195 f64) (param $argument196 f64) (result i64)
  (local $local0 i32)
  (local $local2 f64)
  (local $local3 f64)
  (local $local4 f64)
  (local $local6 f64)
  (local $local7 f64)
  (local $local8 f64)
  (local $local10 f64)
  (local $local11 f64)
  (local $local12 f64)
  (local $local15 f64)
  (local $local16 f64)
  (local $local17 f64)
  (local $local21 f64)
  (local $local1 (ref null $type40))
  (local $local5 (ref null $type40))
  (local $local9 (ref null $type40))
  (local $local13 (ref null $type40))
  (local $local18 (ref null $type40))
  (local $local19 (ref null $type40))
  (local $local14 (ref null $type57))
  (local $local20 (ref null $type58))
  (local.set $local3
   (local.get $argument195)
  )
  (if
   (i32.eqz
    (global.get $ready184)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global184)
   )
  )
  (local.set $local4
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (local.set $local2
   (f64.sub
    (local.get $local3)
    (local.get $local4)
   )
  )
  (local.set $local7
   (local.get $argument196)
  )
  (if
   (i32.eqz
    (global.get $ready184)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global184)
   )
  )
  (local.set $local8
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local9)
    )
   )
  )
  (local.set $local6
   (f64.sub
    (local.get $local7)
    (local.get $local8)
   )
  )
  (local.set $local11
   (f64.const -1)
  )
  (if
   (i32.eqz
    (global.get $ready184)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local13
   (ref.as_non_null
    (global.get $global184)
   )
  )
  (local.set $local12
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local13)
    )
   )
  )
  (local.set $local10
   (f64.mul
    (local.get $local11)
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (global.get $ready167)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (local.set $local1
   (call $function60
    (struct.get $type57 1
     (ref.as_non_null
      (local.get $local14)
     )
    )
    (local.get $local2)
    (local.get $local6)
    (local.get $local10)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready184)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local18
   (ref.as_non_null
    (global.get $global184)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local19
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready198)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local20
   (ref.as_non_null
    (global.get $global198)
   )
  )
  (local.set $local17
   (call $function68
    (struct.get $type58 1
     (ref.as_non_null
      (local.get $local20)
     )
    )
    (ref.as_non_null
     (local.get $local18)
    )
    (ref.as_non_null
     (local.get $local19)
    )
   )
  )
  (local.set $local21
   (f64.const 255)
  )
  (local.set $local16
   (f64.mul
    (local.get $local17)
    (local.get $local21)
   )
  )
  (local.set $local15
   (f64.nearest
    (local.get $local16)
   )
  )
  (i64.trunc_f64_s
   (local.get $local15)
  )
 )
 (func $function68 (type $call58) (param $environment eqref) (param $argument199 (ref $type40)) (param $argument200 (ref $type40)) (result f64)
  (local $local0 i32)
  (local $local5 f64)
  (local $local12 f64)
  (local $local1 (ref null $type50))
  (local $local7 (ref null $type50))
  (local $local9 (ref null $type50))
  (local $local14 (ref null $type50))
  (local $local16 (ref null $type50))
  (local $local2 (ref null $type40))
  (local $local3 (ref null $type40))
  (local $local8 (ref null $type40))
  (local $local10 (ref null $type40))
  (local $local4 (ref null $type63))
  (local $local6 (ref null $type39))
  (local $local13 (ref null $type39))
  (local $local11 (ref null $type64))
  (local $local15 (ref null $type66))
  (local $local17 (ref null $type49))
  (local.set $local2
   (local.get $argument199)
  )
  (local.set $local3
   (local.get $argument200)
  )
  (if
   (i32.eqz
    (global.get $ready202)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global202)
   )
  )
  (local.set $local1
   (call $function69
    (struct.get $type63 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local16
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (if (result f64)
   (call $function55
    (struct.get $type49 1
     (ref.as_non_null
      (local.get $local17)
     )
    )
    (ref.as_non_null
     (local.get $local16)
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.ne
      (struct.get $type50 0
       (ref.as_non_null
        (local.get $local7)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (struct.get $type52 1
      (ref.cast (ref $type52)
       (ref.as_non_null
        (local.get $local7)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.ne
      (struct.get $type50 0
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (struct.get $type52 2
      (ref.cast (ref $type52)
       (ref.as_non_null
        (local.get $local9)
       )
      )
     )
    )
    (local.set $local10
     (local.get $argument200)
    )
    (if
     (i32.eqz
      (global.get $ready227)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (ref.as_non_null
      (global.get $global227)
     )
    )
    (local.set $local5
     (call $function73
      (struct.get $type64 1
       (ref.as_non_null
        (local.get $local11)
       )
      )
      (ref.as_non_null
       (local.get $local6)
      )
      (ref.as_non_null
       (local.get $local8)
      )
      (ref.as_non_null
       (local.get $local10)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.ne
      (struct.get $type50 0
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (struct.get $type52 1
      (ref.cast (ref $type52)
       (ref.as_non_null
        (local.get $local14)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready239)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local15
     (ref.as_non_null
      (global.get $global239)
     )
    )
    (local.set $local12
     (call $function76
      (struct.get $type66 1
       (ref.as_non_null
        (local.get $local15)
       )
      )
      (ref.as_non_null
       (local.get $local13)
      )
     )
    )
    (f64.mul
     (local.get $local5)
     (local.get $local12)
    )
   )
   (else
    (f64.const 0)
   )
  )
 )
 (func $function69 (type $call63) (param $environment eqref) (param $argument203 (ref $type40)) (param $argument204 (ref $type40)) (result (ref $type50))
  (local $local0 (ref null $type38))
  (local $local1 (ref null $type60))
  (local $local2 (ref null $type50))
  (local $local3 f64)
  (local $local4 i32)
  (local $local5 i32)
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (local.set $local0
   (struct.get $type60 0
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (local.set $local2
   (struct.new $type51
    (i32.const 0)
   )
  )
  (local.set $local3
   (f64.const 1.e+308)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (return_call $function70
   (local.get $argument203)
   (local.get $argument204)
   (local.get $local5)
   (local.get $local4)
   (local.get $local0)
   (ref.as_non_null
    (local.get $local2)
   )
   (local.get $local3)
  )
 )
 (func $function70 (param $capture203 (ref $type40)) (param $capture204 (ref $type40)) (param $capture205 i32) (param $initialized205 i32) (param $argument206 (ref null $type38)) (param $argument207 (ref $type50)) (param $argument208 f64) (result (ref $type50))
  (local $local0 i32)
  (local $local3 i32)
  (local $local13 i32)
  (local $local16 i32)
  (local $local12 f64)
  (local $local17 f64)
  (local $local24 f64)
  (local $local30 f64)
  (local $local31 f64)
  (local $local32 f64)
  (local $local1 (ref null $type39))
  (local $local5 (ref null $type39))
  (local $local28 (ref null $type39))
  (local $local2 (ref null $type38))
  (local $local9 (ref null $type38))
  (local $local10 (ref null $type38))
  (local $local21 (ref null $type38))
  (local $local22 (ref null $type38))
  (local $local25 (ref null $type38))
  (local $local26 (ref null $type38))
  (local $local35 (ref null $type38))
  (local $local4 (ref null $type46))
  (local $local15 (ref null $type46))
  (local $local33 (ref null $type46))
  (local $local6 (ref null $type40))
  (local $local7 (ref null $type40))
  (local $local14 (ref null $type40))
  (local $local18 (ref null $type40))
  (local $local19 (ref null $type40))
  (local $local29 (ref null $type40))
  (local $local8 (ref null $type67))
  (local $local11 (ref null $type50))
  (local $local23 (ref null $type50))
  (local $local27 (ref null $type50))
  (local $local20 (ref null $type58))
  (local $local34 (ref null $type45))
  (local.set $local35
   (local.get $argument206)
  )
  (if (result (ref $type50))
   (ref.is_null
    (local.get $local35)
   )
   (then
    (local.get $argument207)
   )
   (else
    (local.set $local2
     (local.get $argument206)
    )
    (local.set $local1
     (struct.get $type38 0
      (local.get $local2)
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local6
     (local.get $capture203)
    )
    (local.set $local7
     (local.get $capture204)
    )
    (if
     (i32.eqz
      (global.get $ready211)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global211)
     )
    )
    (local.set $local4
     (call $function71
      (struct.get $type67 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local5)
      )
      (ref.as_non_null
       (local.get $local6)
      )
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local3
     (i32.const 1)
    )
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local33
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (global.get $ready146)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local34
     (ref.as_non_null
      (global.get $global146)
     )
    )
    (if (result (ref $type50))
     (call $function54
      (struct.get $type45 1
       (ref.as_non_null
        (local.get $local34)
       )
      )
      (ref.as_non_null
       (local.get $local33)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $local3)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local15
       (ref.as_non_null
        (local.get $local4)
       )
      )
      (if
       (i32.ne
        (struct.get $type46 0
         (ref.as_non_null
          (local.get $local15)
         )
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local14
       (struct.get $type48 1
        (ref.cast (ref $type48)
         (ref.as_non_null
          (local.get $local15)
         )
        )
       )
      )
      (local.set $local13
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local13)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local18
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (local.set $local19
       (local.get $capture203)
      )
      (if
       (i32.eqz
        (global.get $ready172)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local20
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (local.set $local17
       (call $function61
        (struct.get $type58 1
         (ref.as_non_null
          (local.get $local20)
         )
        )
        (ref.as_non_null
         (local.get $local18)
        )
        (ref.as_non_null
         (local.get $local19)
        )
       )
      )
      (local.set $local16
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local16)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local31
       (local.get $local17)
      )
      (local.set $local32
       (local.get $argument208)
      )
      (if (result (ref $type50))
       (f64.lt
        (local.get $local31)
        (local.get $local32)
       )
       (then
        (local.set $local26
         (local.get $argument206)
        )
        (local.set $local25
         (struct.get $type38 1
          (local.get $local26)
         )
        )
        (if
         (i32.eqz
          (local.get $local0)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local28
         (ref.as_non_null
          (local.get $local1)
         )
        )
        (if
         (i32.eqz
          (local.get $local13)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local29
         (ref.as_non_null
          (local.get $local14)
         )
        )
        (local.set $local27
         (struct.new $type52
          (i32.const 1)
          (ref.as_non_null
           (local.get $local28)
          )
          (ref.as_non_null
           (local.get $local29)
          )
         )
        )
        (if
         (i32.eqz
          (local.get $local16)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local30
         (local.get $local17)
        )
        (if
         (i32.eqz
          (local.get $initialized205)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (local.get $capture205)
        )
        (return_call $function70
         (local.get $capture203)
         (local.get $capture204)
         (local.get $capture205)
         (local.get $initialized205)
         (local.get $local25)
         (ref.as_non_null
          (local.get $local27)
         )
         (local.get $local30)
        )
       )
       (else
        (local.set $local22
         (local.get $argument206)
        )
        (local.set $local21
         (struct.get $type38 1
          (local.get $local22)
         )
        )
        (local.set $local23
         (local.get $argument207)
        )
        (local.set $local24
         (local.get $argument208)
        )
        (if
         (i32.eqz
          (local.get $initialized205)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (local.get $capture205)
        )
        (return_call $function70
         (local.get $capture203)
         (local.get $capture204)
         (local.get $capture205)
         (local.get $initialized205)
         (local.get $local21)
         (ref.as_non_null
          (local.get $local23)
         )
         (local.get $local24)
        )
       )
      )
     )
     (else
      (local.set $local10
       (local.get $argument206)
      )
      (local.set $local9
       (struct.get $type38 1
        (local.get $local10)
       )
      )
      (local.set $local11
       (local.get $argument207)
      )
      (local.set $local12
       (local.get $argument208)
      )
      (if
       (i32.eqz
        (local.get $initialized205)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (local.get $capture205)
      )
      (return_call $function70
       (local.get $capture203)
       (local.get $capture204)
       (local.get $capture205)
       (local.get $initialized205)
       (local.get $local9)
       (ref.as_non_null
        (local.get $local11)
       )
       (local.get $local12)
      )
     )
    )
   )
  )
 )
 (func $function71 (type $call67) (param $environment eqref) (param $argument212 (ref $type39)) (param $argument213 (ref $type40)) (param $argument214 (ref $type40)) (result (ref $type46))
  (local $local0 (ref null $type39))
  (local $local1 (ref null $type40))
  (local $local2 (ref null $type40))
  (local $local3 (ref null $type67))
  (local.set $local0
   (local.get $argument212)
  )
  (local.set $local1
   (local.get $argument213)
  )
  (local.set $local2
   (local.get $argument214)
  )
  (if
   (i32.eqz
    (global.get $ready215)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (return_call $function72
   (struct.get $type67 1
    (ref.as_non_null
     (local.get $local3)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local1)
   )
   (ref.as_non_null
    (local.get $local2)
   )
  )
 )
 (func $function72 (type $call67) (param $environment eqref) (param $argument216 (ref $type39)) (param $argument217 (ref $type40)) (param $argument218 (ref $type40)) (result (ref $type46))
  (local $local0 i32)
  (local $local3 i32)
  (local $local6 i32)
  (local $local9 i32)
  (local $local12 i32)
  (local $local81 i32)
  (local $local1 f64)
  (local $local4 f64)
  (local $local7 f64)
  (local $local14 f64)
  (local $local15 f64)
  (local $local16 f64)
  (local $local17 f64)
  (local $local19 f64)
  (local $local20 f64)
  (local $local22 f64)
  (local $local23 f64)
  (local $local25 f64)
  (local $local26 f64)
  (local $local27 f64)
  (local $local28 f64)
  (local $local29 f64)
  (local $local30 f64)
  (local $local31 f64)
  (local $local33 f64)
  (local $local35 f64)
  (local $local36 f64)
  (local $local37 f64)
  (local $local38 f64)
  (local $local40 f64)
  (local $local42 f64)
  (local $local43 f64)
  (local $local44 f64)
  (local $local45 f64)
  (local $local47 f64)
  (local $local49 f64)
  (local $local50 f64)
  (local $local51 f64)
  (local $local52 f64)
  (local $local53 f64)
  (local $local54 f64)
  (local $local55 f64)
  (local $local57 f64)
  (local $local60 f64)
  (local $local61 f64)
  (local $local62 f64)
  (local $local64 f64)
  (local $local67 f64)
  (local $local68 f64)
  (local $local69 f64)
  (local $local71 f64)
  (local $local74 f64)
  (local $local75 f64)
  (local $local76 f64)
  (local $local77 f64)
  (local $local82 f64)
  (local $local85 f64)
  (local $local86 f64)
  (local $local88 f64)
  (local $local89 f64)
  (local $local90 f64)
  (local $local91 f64)
  (local $local92 f64)
  (local $local94 f64)
  (local $local95 f64)
  (local $local96 f64)
  (local $local97 f64)
  (local $local98 f64)
  (local $local100 f64)
  (local $local101 f64)
  (local $local102 f64)
  (local $local2 (ref null $type40))
  (local $local5 (ref null $type40))
  (local $local8 (ref null $type40))
  (local $local10 (ref null $type40))
  (local $local32 (ref null $type40))
  (local $local34 (ref null $type40))
  (local $local39 (ref null $type40))
  (local $local41 (ref null $type40))
  (local $local46 (ref null $type40))
  (local $local48 (ref null $type40))
  (local $local56 (ref null $type40))
  (local $local58 (ref null $type40))
  (local $local63 (ref null $type40))
  (local $local65 (ref null $type40))
  (local $local70 (ref null $type40))
  (local $local72 (ref null $type40))
  (local $local84 (ref null $type40))
  (local $local87 (ref null $type40))
  (local $local93 (ref null $type40))
  (local $local99 (ref null $type40))
  (local $local11 (ref null $type39))
  (local $local78 (ref null $type39))
  (local $local13 (ref null $type42))
  (local $local83 (ref null $type42))
  (local $local103 (ref null $type42))
  (local $local18 (ref null $type55))
  (local $local21 (ref null $type55))
  (local $local24 (ref null $type55))
  (local $local59 (ref null $type55))
  (local $local66 (ref null $type55))
  (local $local73 (ref null $type55))
  (local $local79 (ref null $type55))
  (local $local80 (ref null $type59))
  (local $local104 (ref null $type41))
  (local.set $local2
   (local.get $argument218)
  )
  (local.set $local1
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local5
   (local.get $argument218)
  )
  (local.set $local4
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (local.set $local3
   (i32.const 1)
  )
  (local.set $local8
   (local.get $argument218)
  )
  (local.set $local7
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local8)
    )
   )
  )
  (local.set $local6
   (i32.const 1)
  )
  (local.set $local11
   (local.get $argument216)
  )
  (local.set $local10
   (struct.get $type39 2
    (ref.as_non_null
     (local.get $local11)
    )
   )
  )
  (local.set $local9
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (local.get $local1)
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local18
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local16
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local18)
     )
    )
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local20
   (local.get $local4)
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local21
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local19
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local21)
     )
    )
    (local.get $local20)
   )
  )
  (local.set $local15
   (f64.add
    (local.get $local16)
    (local.get $local19)
   )
  )
  (if
   (i32.eqz
    (local.get $local6)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local23
   (local.get $local7)
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local24
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local22
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local24)
     )
    )
    (local.get $local23)
   )
  )
  (local.set $local14
   (f64.add
    (local.get $local15)
    (local.get $local22)
   )
  )
  (local.set $local26
   (f64.const 2)
  )
  (local.set $local32
   (local.get $argument217)
  )
  (local.set $local31
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local32)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local34
   (ref.as_non_null
    (local.get $local10)
   )
  )
  (local.set $local33
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local34)
    )
   )
  )
  (local.set $local30
   (f64.sub
    (local.get $local31)
    (local.get $local33)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local35
   (local.get $local1)
  )
  (local.set $local29
   (f64.mul
    (local.get $local30)
    (local.get $local35)
   )
  )
  (local.set $local39
   (local.get $argument217)
  )
  (local.set $local38
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local39)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local41
   (ref.as_non_null
    (local.get $local10)
   )
  )
  (local.set $local40
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local41)
    )
   )
  )
  (local.set $local37
   (f64.sub
    (local.get $local38)
    (local.get $local40)
   )
  )
  (if
   (i32.eqz
    (local.get $local3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local42
   (local.get $local4)
  )
  (local.set $local36
   (f64.mul
    (local.get $local37)
    (local.get $local42)
   )
  )
  (local.set $local28
   (f64.add
    (local.get $local29)
    (local.get $local36)
   )
  )
  (local.set $local46
   (local.get $argument217)
  )
  (local.set $local45
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local46)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local48
   (ref.as_non_null
    (local.get $local10)
   )
  )
  (local.set $local47
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local48)
    )
   )
  )
  (local.set $local44
   (f64.sub
    (local.get $local45)
    (local.get $local47)
   )
  )
  (if
   (i32.eqz
    (local.get $local6)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local49
   (local.get $local7)
  )
  (local.set $local43
   (f64.mul
    (local.get $local44)
    (local.get $local49)
   )
  )
  (local.set $local27
   (f64.add
    (local.get $local28)
    (local.get $local43)
   )
  )
  (local.set $local25
   (f64.mul
    (local.get $local26)
    (local.get $local27)
   )
  )
  (local.set $local56
   (local.get $argument217)
  )
  (local.set $local55
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local56)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local58
   (ref.as_non_null
    (local.get $local10)
   )
  )
  (local.set $local57
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local58)
    )
   )
  )
  (local.set $local54
   (f64.sub
    (local.get $local55)
    (local.get $local57)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local59
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local53
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local59)
     )
    )
    (local.get $local54)
   )
  )
  (local.set $local63
   (local.get $argument217)
  )
  (local.set $local62
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local63)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local65
   (ref.as_non_null
    (local.get $local10)
   )
  )
  (local.set $local64
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local65)
    )
   )
  )
  (local.set $local61
   (f64.sub
    (local.get $local62)
    (local.get $local64)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local66
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local60
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local66)
     )
    )
    (local.get $local61)
   )
  )
  (local.set $local52
   (f64.add
    (local.get $local53)
    (local.get $local60)
   )
  )
  (local.set $local70
   (local.get $argument217)
  )
  (local.set $local69
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local70)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local9)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local72
   (ref.as_non_null
    (local.get $local10)
   )
  )
  (local.set $local71
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local72)
    )
   )
  )
  (local.set $local68
   (f64.sub
    (local.get $local69)
    (local.get $local71)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local73
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local67
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local73)
     )
    )
    (local.get $local68)
   )
  )
  (local.set $local51
   (f64.add
    (local.get $local52)
    (local.get $local67)
   )
  )
  (local.set $local75
   (f64.const -1)
  )
  (local.set $local78
   (local.get $argument216)
  )
  (local.set $local77
   (struct.get $type39 1
    (ref.as_non_null
     (local.get $local78)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local79
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $local76
   (call $function58
    (struct.get $type55 1
     (ref.as_non_null
      (local.get $local79)
     )
    )
    (local.get $local77)
   )
  )
  (local.set $local74
   (f64.mul
    (local.get $local75)
    (local.get $local76)
   )
  )
  (local.set $local50
   (f64.add
    (local.get $local51)
    (local.get $local74)
   )
  )
  (if
   (i32.eqz
    (global.get $ready175)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local80
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (local.set $local13
   (call $function62
    (struct.get $type59 1
     (ref.as_non_null
      (local.get $local80)
     )
    )
    (local.get $local14)
    (local.get $local25)
    (local.get $local50)
   )
  )
  (local.set $local12
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local12)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local103
   (ref.as_non_null
    (local.get $local13)
   )
  )
  (if
   (i32.eqz
    (global.get $ready142)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local104
   (ref.as_non_null
    (global.get $global142)
   )
  )
  (if (result (ref $type46))
   (call $function53
    (struct.get $type41 1
     (ref.as_non_null
      (local.get $local104)
     )
    )
    (ref.as_non_null
     (local.get $local103)
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $local12)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local83
     (ref.as_non_null
      (local.get $local13)
     )
    )
    (if
     (i32.ne
      (struct.get $type42 0
       (ref.as_non_null
        (local.get $local83)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local82
     (struct.get $type44 1
      (ref.cast (ref $type44)
       (ref.as_non_null
        (local.get $local83)
       )
      )
     )
    )
    (local.set $local81
     (i32.const 1)
    )
    (local.set $local87
     (local.get $argument217)
    )
    (local.set $local86
     (struct.get $type40 0
      (ref.as_non_null
       (local.get $local87)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local81)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local89
     (local.get $local82)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local90
     (local.get $local1)
    )
    (local.set $local88
     (f64.mul
      (local.get $local89)
      (local.get $local90)
     )
    )
    (local.set $local85
     (f64.add
      (local.get $local86)
      (local.get $local88)
     )
    )
    (local.set $local93
     (local.get $argument217)
    )
    (local.set $local92
     (struct.get $type40 1
      (ref.as_non_null
       (local.get $local93)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local81)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local95
     (local.get $local82)
    )
    (if
     (i32.eqz
      (local.get $local3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local96
     (local.get $local4)
    )
    (local.set $local94
     (f64.mul
      (local.get $local95)
      (local.get $local96)
     )
    )
    (local.set $local91
     (f64.add
      (local.get $local92)
      (local.get $local94)
     )
    )
    (local.set $local99
     (local.get $argument217)
    )
    (local.set $local98
     (struct.get $type40 2
      (ref.as_non_null
       (local.get $local99)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $local81)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local101
     (local.get $local82)
    )
    (if
     (i32.eqz
      (local.get $local6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local102
     (local.get $local7)
    )
    (local.set $local100
     (f64.mul
      (local.get $local101)
      (local.get $local102)
     )
    )
    (local.set $local97
     (f64.add
      (local.get $local98)
      (local.get $local100)
     )
    )
    (local.set $local84
     (struct.new $type40
      (local.get $local85)
      (local.get $local91)
      (local.get $local97)
     )
    )
    (struct.new $type48
     (i32.const 1)
     (ref.as_non_null
      (local.get $local84)
     )
    )
   )
   (else
    (struct.new $type47
     (i32.const 0)
    )
   )
  )
 )
 (func $function73 (type $call64) (param $environment eqref) (param $argument228 (ref $type39)) (param $argument229 (ref $type40)) (param $argument230 (ref $type40)) (result f64)
  (local $local0 i32)
  (local $local5 f64)
  (local $local6 f64)
  (local $local7 f64)
  (local $local8 f64)
  (local $local9 f64)
  (local $local11 f64)
  (local $local13 f64)
  (local $local14 f64)
  (local $local16 f64)
  (local $local18 f64)
  (local $local19 f64)
  (local $local21 f64)
  (local $local1 (ref null $type40))
  (local $local3 (ref null $type40))
  (local $local10 (ref null $type40))
  (local $local12 (ref null $type40))
  (local $local15 (ref null $type40))
  (local $local17 (ref null $type40))
  (local $local20 (ref null $type40))
  (local $local22 (ref null $type40))
  (local $local2 (ref null $type39))
  (local $local4 (ref null $type68))
  (local $local23 (ref null $type53))
  (local.set $local2
   (local.get $argument228)
  )
  (local.set $local3
   (local.get $argument229)
  )
  (if
   (i32.eqz
    (global.get $ready232)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global232)
   )
  )
  (local.set $local1
   (call $function74
    (struct.get $type68 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (local.set $local5
   (f64.const 0)
  )
  (local.set $local10
   (local.get $argument230)
  )
  (local.set $local9
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local10)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local11
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local12)
    )
   )
  )
  (local.set $local8
   (f64.mul
    (local.get $local9)
    (local.get $local11)
   )
  )
  (local.set $local15
   (local.get $argument230)
  )
  (local.set $local14
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local15)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local16
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local17)
    )
   )
  )
  (local.set $local13
   (f64.mul
    (local.get $local14)
    (local.get $local16)
   )
  )
  (local.set $local7
   (f64.add
    (local.get $local8)
    (local.get $local13)
   )
  )
  (local.set $local20
   (local.get $argument230)
  )
  (local.set $local19
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local20)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local22
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local21
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local22)
    )
   )
  )
  (local.set $local18
   (f64.mul
    (local.get $local19)
    (local.get $local21)
   )
  )
  (local.set $local6
   (f64.add
    (local.get $local7)
    (local.get $local18)
   )
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local23
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (return_call $function57
   (struct.get $type53 1
    (ref.as_non_null
     (local.get $local23)
    )
   )
   (local.get $local5)
   (local.get $local6)
  )
 )
 (func $function74 (type $call68) (param $environment eqref) (param $argument233 (ref $type39)) (param $argument234 (ref $type40)) (result (ref $type40))
  (local $local0 (ref null $type39))
  (local $local1 (ref null $type40))
  (local $local2 (ref null $type68))
  (local.set $local0
   (local.get $argument233)
  )
  (local.set $local1
   (local.get $argument234)
  )
  (if
   (i32.eqz
    (global.get $ready235)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global235)
   )
  )
  (return_call $function75
   (struct.get $type68 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (ref.as_non_null
    (local.get $local1)
   )
  )
 )
 (func $function75 (type $call68) (param $environment eqref) (param $argument236 (ref $type39)) (param $argument237 (ref $type40)) (result (ref $type40))
  (local $local0 i32)
  (local $local3 f64)
  (local $local4 f64)
  (local $local6 f64)
  (local $local8 f64)
  (local $local9 f64)
  (local $local11 f64)
  (local $local13 f64)
  (local $local14 f64)
  (local $local16 f64)
  (local $local1 (ref null $type40))
  (local $local5 (ref null $type40))
  (local $local7 (ref null $type40))
  (local $local10 (ref null $type40))
  (local $local12 (ref null $type40))
  (local $local15 (ref null $type40))
  (local $local17 (ref null $type40))
  (local $local2 (ref null $type39))
  (local $local18 (ref null $type57))
  (local.set $local2
   (local.get $argument236)
  )
  (local.set $local1
   (struct.get $type39 2
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local4
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (local.set $local7
   (local.get $argument237)
  )
  (local.set $local6
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local7)
    )
   )
  )
  (local.set $local3
   (f64.sub
    (local.get $local4)
    (local.get $local6)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local9
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local10)
    )
   )
  )
  (local.set $local12
   (local.get $argument237)
  )
  (local.set $local11
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local12)
    )
   )
  )
  (local.set $local8
   (f64.sub
    (local.get $local9)
    (local.get $local11)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local15
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local14
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local15)
    )
   )
  )
  (local.set $local17
   (local.get $argument237)
  )
  (local.set $local16
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local17)
    )
   )
  )
  (local.set $local13
   (f64.sub
    (local.get $local14)
    (local.get $local16)
   )
  )
  (if
   (i32.eqz
    (global.get $ready167)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local18
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (return_call $function60
   (struct.get $type57 1
    (ref.as_non_null
     (local.get $local18)
    )
   )
   (local.get $local3)
   (local.get $local8)
   (local.get $local13)
  )
 )
 (func $function76 (type $call66) (param $environment eqref) (param $argument240 (ref $type39)) (result f64)
  (local $local0 (ref null $type39))
  (local.set $local0
   (local.get $argument240)
  )
  (struct.get $type39 0
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function77 (type $call33) (param $environment eqref) (param $argument242 (ref $type14)) (param $argument243 (ref $type32)) (result i32)
  (local $local0 i32)
  (local $local4 i32)
  (local $local5 i32)
  (local $local1 (ref null $type30))
  (local $local6 (ref null $type30))
  (local $local8 (ref null $type30))
  (local $local2 (ref null $type14))
  (local $local3 (ref null $type29))
  (local $local7 (ref null $type32))
  (local $local9 (ref null $type32))
  (local.set $local2
   (local.get $argument242)
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (local.set $local1
   (call $function45
    (struct.get $type29 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (local.set $local7
   (local.get $argument243)
  )
  (local.set $local5
   (call_ref $call32
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
    (struct.get $type32 0
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
  (local.set $local4
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (drop
   (call $function46
    (struct.get $type32 1
     (ref.as_non_null
      (local.get $local9)
     )
    )
    (ref.as_non_null
     (local.get $local8)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (local.get $local5)
 )
 (func $function78 (type $call65) (param $environment eqref) (param $argument247 f64) (param $argument248 f64) (param $argument249 f64) (param $argument250 f64) (param $argument251 f64) (result (ref $type39))
  (local $local0 i32)
  (local $local2 f64)
  (local $local3 f64)
  (local $local5 f64)
  (local $local6 f64)
  (local $local7 f64)
  (local $local1 (ref null $type39))
  (local $local10 (ref null $type39))
  (local $local4 (ref null $type40))
  (local $local8 (ref null $type60))
  (local $local12 (ref null $type60))
  (local $local9 (ref null $type38))
  (local $local11 (ref null $type38))
  (local.set $local2
   (local.get $argument251)
  )
  (local.set $local3
   (local.get $argument250)
  )
  (local.set $local5
   (local.get $argument247)
  )
  (local.set $local6
   (local.get $argument248)
  )
  (local.set $local7
   (local.get $argument249)
  )
  (local.set $local4
   (struct.new $type40
    (local.get $local5)
    (local.get $local6)
    (local.get $local7)
   )
  )
  (local.set $local1
   (struct.new $type39
    (local.get $local2)
    (local.get $local3)
    (ref.as_non_null
     (local.get $local4)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local8
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (local.set $local11
   (struct.get $type60 0
    (ref.as_non_null
     (local.get $local12)
    )
   )
  )
  (local.set $local9
   (struct.new $type38
    (ref.as_non_null
     (local.get $local10)
    )
    (local.get $local11)
   )
  )
  (struct.set $type60 0
   (ref.as_non_null
    (local.get $local8)
   )
   (local.get $local9)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (local.get $local1)
  )
 )
 (func $function79 (type $call69) (param $environment eqref) (param $argument254 i64) (param $argument255 (ref $type14)) (result i32)
  (local $local0 (ref null $type14))
  (local $local2 (ref null $type61))
  (local $local11 (ref null $type65))
  (local $local17 (ref null $type65))
  (local $local23 (ref null $type65))
  (local $local24 (ref null $type60))
  (local $local25 (ref null $type38))
  (local $local1 i64)
  (local $local3 i64)
  (local $local4 i32)
  (local $local5 i32)
  (local $local6 f64)
  (local $local7 f64)
  (local $local8 f64)
  (local $local9 f64)
  (local $local10 f64)
  (local $local12 f64)
  (local $local13 f64)
  (local $local14 f64)
  (local $local15 f64)
  (local $local16 f64)
  (local $local18 f64)
  (local $local19 f64)
  (local $local20 f64)
  (local $local21 f64)
  (local $local22 f64)
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local24
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (local.set $local25
   (ref.null none)
  )
  (struct.set $type60 0
   (ref.as_non_null
    (local.get $local24)
   )
   (local.get $local25)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local18
   (f64.const 0)
  )
  (local.set $local19
   (f64.const -300)
  )
  (local.set $local20
   (f64.const -1200)
  )
  (local.set $local21
   (f64.const 200)
  )
  (local.set $local22
   (f64.const 0.8)
  )
  (if
   (i32.eqz
    (global.get $ready246)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local23
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (drop
   (call $function78
    (struct.get $type65 1
     (ref.as_non_null
      (local.get $local23)
     )
    )
    (local.get $local18)
    (local.get $local19)
    (local.get $local20)
    (local.get $local21)
    (local.get $local22)
   )
  )
  (local.set $local12
   (f64.const -80)
  )
  (local.set $local13
   (f64.const -150)
  )
  (local.set $local14
   (f64.const -1200)
  )
  (local.set $local15
   (f64.const 200)
  )
  (local.set $local16
   (f64.const 0.7)
  )
  (if
   (i32.eqz
    (global.get $ready246)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (drop
   (call $function78
    (struct.get $type65 1
     (ref.as_non_null
      (local.get $local17)
     )
    )
    (local.get $local12)
    (local.get $local13)
    (local.get $local14)
    (local.get $local15)
    (local.get $local16)
   )
  )
  (local.set $local6
   (f64.const 70)
  )
  (local.set $local7
   (f64.const -100)
  )
  (local.set $local8
   (f64.const -1200)
  )
  (local.set $local9
   (f64.const 200)
  )
  (local.set $local10
   (f64.const 0.9)
  )
  (if
   (i32.eqz
    (global.get $ready246)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (drop
   (call $function78
    (struct.get $type65 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (local.get $local6)
    (local.get $local7)
    (local.get $local8)
    (local.get $local9)
    (local.get $local10)
   )
  )
  (local.set $local3
   (i64.const -2)
  )
  (local.set $local5
   (i32.const 0)
  )
  (local.set $local4
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local4)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local5)
  )
  (drop
   (call $function80
    (local.get $local5)
    (local.get $local4)
    (local.get $local3)
   )
  )
  (local.set $local0
   (local.get $argument255)
  )
  (local.set $local1
   (local.get $argument254)
  )
  (if
   (i32.eqz
    (global.get $ready185)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global185)
   )
  )
  (return_call $function63
   (struct.get $type61 1
    (ref.as_non_null
     (local.get $local2)
    )
   )
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
  )
 )
 (func $function80 (param $capture256 i32) (param $initialized256 i32) (param $argument257 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local4 i32)
  (local $local5 i32)
  (local.set $local6
   (local.get $argument257)
  )
  (local.set $local7
   (i64.const 2)
  )
  (if (result i32)
   (i64.gt_s
    (local.get $local6)
    (local.get $local7)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local3
     (i64.const 2)
    )
    (local.set $local5
     (i32.const 0)
    )
    (local.set $local4
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local5)
    )
    (drop
     (call $function81
      (local.get $argument257)
      (local.get $local5)
      (local.get $local4)
      (local.get $local3)
     )
    )
    (local.set $local1
     (local.get $argument257)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized256)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture256)
    )
    (return_call $function80
     (local.get $capture256)
     (local.get $initialized256)
     (local.get $local0)
    )
   )
  )
 )
 (func $function81 (param $capture257 i64) (param $capture258 i32) (param $initialized258 i32) (param $argument259 i64) (result i32)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local5 i64)
  (local $local10 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local3 f64)
  (local $local4 f64)
  (local $local6 f64)
  (local $local7 f64)
  (local $local8 f64)
  (local $local9 f64)
  (local $local11 f64)
  (local $local12 f64)
  (local $local13 f64)
  (local $local14 (ref null $type65))
  (local.set $local15
   (local.get $argument259)
  )
  (local.set $local16
   (i64.const 7)
  )
  (if (result i32)
   (i64.gt_s
    (local.get $local15)
    (local.get $local16)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local5
     (local.get $capture257)
    )
    (local.set $local4
     (f64.convert_i64_s
      (local.get $local5)
     )
    )
    (local.set $local6
     (f64.const 200)
    )
    (local.set $local3
     (f64.mul
      (local.get $local4)
      (local.get $local6)
     )
    )
    (local.set $local7
     (f64.const 300)
    )
    (local.set $local10
     (local.get $argument259)
    )
    (local.set $local9
     (f64.convert_i64_s
      (local.get $local10)
     )
    )
    (local.set $local11
     (f64.const -400)
    )
    (local.set $local8
     (f64.mul
      (local.get $local9)
      (local.get $local11)
     )
    )
    (local.set $local12
     (f64.const 40)
    )
    (local.set $local13
     (f64.const 0.75)
    )
    (if
     (i32.eqz
      (global.get $ready246)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (global.get $global246)
     )
    )
    (drop
     (call $function78
      (struct.get $type65 1
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (local.get $local3)
      (local.get $local7)
      (local.get $local8)
      (local.get $local12)
      (local.get $local13)
     )
    )
    (local.set $local1
     (local.get $argument259)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized258)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture258)
    )
    (return_call $function81
     (local.get $capture257)
     (local.get $capture258)
     (local.get $initialized258)
     (local.get $local0)
    )
   )
  )
 )
 (func $function82 (type $call70) (param $environment eqref) (param $argument261 i64) (param $argument262 (ref $type14)) (result i64)
  (local $local0 i64)
  (local $local1 (ref null $type14))
  (local $local2 (ref null $type69))
  (local.set $local0
   (local.get $argument261)
  )
  (local.set $local1
   (local.get $argument262)
  )
  (if
   (i32.eqz
    (global.get $ready253)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local2
   (ref.as_non_null
    (global.get $global253)
   )
  )
  (drop
   (call $function79
    (struct.get $type69 1
     (ref.as_non_null
      (local.get $local2)
     )
    )
    (local.get $local0)
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (i64.const 1)
 )
 (func $function83 (type $call71) (param $environment eqref) (result (ref $type14))
  (local $local0 i32)
  (local $local2 i32)
  (local $local5 i32)
  (local $local7 i32)
  (local $local8 i32)
  (local $local1 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local3 (ref null $type14))
  (local.set $local1
   (call $foreign7)
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (local.get $local1)
  )
  (local.set $local5
   (i32.const 32)
  )
  (if
   (i64.gt_u
    (local.get $local4)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (call $string-new
    (i32.wrap_i64
     (local.get $local4)
    )
    (local.get $local5)
   )
  )
  (local.set $local2
   (i32.const 1)
  )
  (local.set $local6
   (i64.const 0)
  )
  (local.set $local8
   (i32.const 0)
  )
  (local.set $local7
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local7)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local8)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function84
   (local.get $local1)
   (block (result (ref $type14))
    (if
     (i32.eqz
      (local.get $local2)
     )
     (then
      (unreachable)
     )
    )
    (ref.as_non_null
     (local.get $local3)
    )
   )
   (local.get $local8)
   (local.get $local7)
   (local.get $local6)
  )
 )
 (func $function84 (param $capture264 i64) (param $capture265 (ref $type14)) (param $capture266 i32) (param $initialized266 i32) (param $argument267 i64) (result (ref $type14))
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local4 i64)
  (local $local6 i64)
  (local $local8 i64)
  (local $local9 i64)
  (local $local5 i32)
  (local $local7 i32)
  (local $local3 (ref null $type14))
  (local.set $local8
   (local.get $argument267)
  )
  (local.set $local9
   (local.get $capture264)
  )
  (if (result (ref $type14))
   (i64.eq
    (local.get $local8)
    (local.get $local9)
   )
   (then
    (local.get $capture265)
   )
   (else
    (local.set $local3
     (local.get $capture265)
    )
    (local.set $local4
     (local.get $argument267)
    )
    (local.set $local6
     (local.get $argument267)
    )
    (local.set $local5
     (call $foreign8
      (local.get $local6)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $local4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (ref.as_non_null
         (local.get $local3)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (i32.wrap_i64
      (local.get $local4)
     )
    )
    (array.set $type15
     (call $string-block
      (ref.as_non_null
       (local.get $local3)
      )
      (local.get $local7)
     )
     (i32.and
      (local.get $local7)
      (i32.const 8191)
     )
     (local.get $local5)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local1
     (local.get $argument267)
    )
    (local.set $local2
     (i64.const 1)
    )
    (local.set $local0
     (i64.add
      (local.get $local1)
      (local.get $local2)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized266)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture266)
    )
    (return_call $function84
     (local.get $capture264)
     (local.get $capture265)
     (local.get $capture266)
     (local.get $initialized266)
     (local.get $local0)
    )
   )
  )
 )
 (func $function85 (type $call72) (param $environment eqref) (param $argument272 i64) (param $argument273 (ref $type14)) (result (ref $type14))
  (if (result (ref $type14))
   (call $foreign9)
   (then
    (local.get $argument273)
   )
   (else
    (unreachable)
   )
  )
 )
 (func $function86 (type $call73) (param $environment eqref) (param $argument275 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (i64.const 0)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function87
   (local.get $argument275)
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function87 (param $capture275 i64) (param $capture276 i32) (param $initialized276 i32) (param $argument277 i64) (param $argument278 i64) (result i64)
  (local $local0 i64)
  (local $local1 i64)
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local6 i64)
  (local $local7 i64)
  (local $local8 i64)
  (local $local11 i64)
  (local $local15 i64)
  (local $local16 i64)
  (local $local9 (ref null $type54))
  (local $local10 (ref null $type14))
  (local $local12 (ref null $type14))
  (local $local13 (ref null $type72))
  (local $local14 (ref null $type70))
  (local.set $local15
   (local.get $argument277)
  )
  (local.set $local16
   (local.get $capture275)
  )
  (if (result i64)
   (i64.lt_s
    (local.get $local15)
    (local.get $local16)
   )
   (then
    (local.set $local3
     (local.get $argument277)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (local.set $local7
     (local.get $capture275)
    )
    (if
     (i32.eqz
      (global.get $ready268)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (global.get $global268)
    )
    (if
     (i32.eqz
      (global.get $ready279)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global279)
     )
    )
    (local.set $local6
     (call $function88
      (struct.get $type54 1
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (local.get $local7)
      (local.get $local8)
     )
    )
    (local.set $local11
     (local.get $capture275)
    )
    (if
     (i32.eqz
      (global.get $ready269)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global269)
     )
    )
    (if
     (i32.eqz
      (global.get $ready271)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global271)
     )
    )
    (local.set $local10
     (call $function85
      (struct.get $type72 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (local.get $local11)
      (ref.as_non_null
       (local.get $local12)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready260)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local14
     (ref.as_non_null
      (global.get $global260)
     )
    )
    (local.set $local5
     (call $function82
      (struct.get $type70 1
       (ref.as_non_null
        (local.get $local14)
       )
      )
      (local.get $local6)
      (ref.as_non_null
       (local.get $local10)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $initialized276)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture276)
    )
    (return_call $function87
     (local.get $capture275)
     (local.get $capture276)
     (local.get $initialized276)
     (local.get $local2)
     (local.get $local5)
    )
   )
   (else
    (local.set $local0
     (local.get $argument278)
    )
    (if
     (i32.eqz
      (global.get $ready270)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local1
     (global.get $global270)
    )
    (if (result i64)
     (i64.eq
      (local.get $local0)
      (local.get $local1)
     )
     (then
      (i64.const 1)
     )
     (else
      (i64.const 0)
     )
    )
   )
  )
 )
 (func $function88 (type $call54) (param $environment eqref) (param $argument280 i64) (param $argument281 i64) (result i64)
  (local $local0 i64)
  (local.set $local0
   (local.get $argument281)
  )
  (call $foreign10
   (local.get $local0)
  )
 )
 (func $function89 (type $call78) (param $environment eqref) (param $argument292 (ref null $type38)) (result i32)
  (local $local0 (ref null $type60))
  (local $local1 (ref null $type38))
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (local.set $local1
   (local.get $argument292)
  )
  (struct.set $type60 0
   (ref.as_non_null
    (local.get $local0)
   )
   (local.get $local1)
  )
  (i32.const 0)
 )
 (func $function90 (type $call79) (param $environment eqref) (result (ref null $type38))
  (local $local0 (ref null $type60))
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (ref.as_non_null
    (global.get $global183)
   )
  )
  (struct.get $type60 0
   (ref.as_non_null
    (local.get $local0)
   )
  )
 )
 (func $function91 (type $call80) (param $environment eqref) (param $argument295 (ref $type40)) (result i32)
  (local $local0 f64)
  (local $local2 f64)
  (local $local4 f64)
  (local $local1 (ref null $type40))
  (local $local3 (ref null $type40))
  (local $local5 (ref null $type40))
  (local.set $local5
   (local.get $argument295)
  )
  (local.set $local4
   (struct.get $type40 0
    (ref.as_non_null
     (local.get $local5)
    )
   )
  )
  (call $foreign11
   (local.get $local4)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (local.get $argument295)
  )
  (local.set $local2
   (struct.get $type40 1
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (call $foreign11
   (local.get $local2)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local1
   (local.get $argument295)
  )
  (local.set $local0
   (struct.get $type40 2
    (ref.as_non_null
     (local.get $local1)
    )
   )
  )
  (call $foreign11
   (local.get $local0)
  )
  (i32.const 0)
 )
 (func $function92 (type $call81) (param $environment eqref) (param $argument297 f64) (param $argument298 f64) (param $argument299 f64) (result i32)
  (local $local0 i32)
  (local $local2 f64)
  (local $local3 f64)
  (local $local4 f64)
  (local $local6 f64)
  (local $local11 i64)
  (local $local1 (ref null $type42))
  (local $local7 (ref null $type42))
  (local $local9 (ref null $type42))
  (local $local12 (ref null $type42))
  (local $local5 (ref null $type59))
  (local $local8 (ref null $type74))
  (local $local10 (ref null $type41))
  (local $local13 (ref null $type41))
  (local.set $local2
   (local.get $argument297)
  )
  (local.set $local3
   (local.get $argument298)
  )
  (local.set $local4
   (local.get $argument299)
  )
  (if
   (i32.eqz
    (global.get $ready175)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (local.set $local1
   (call $function62
    (struct.get $type59 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (local.get $local2)
    (local.get $local3)
    (local.get $local4)
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready282)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local13
   (ref.as_non_null
    (global.get $global282)
   )
  )
  (local.set $local11
   (if (result i64)
    (call_ref $call41
     (struct.get $type41 1
      (ref.as_non_null
       (local.get $local13)
      )
     )
     (ref.as_non_null
      (local.get $local12)
     )
     (struct.get $type41 0
      (ref.as_non_null
       (local.get $local13)
      )
     )
    )
    (then
     (i64.const 1)
    )
    (else
     (i64.const 0)
    )
   )
  )
  (call $foreign12
   (local.get $local11)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local9
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready282)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (global.get $global282)
   )
  )
  (if (result i32)
   (call_ref $call41
    (struct.get $type41 1
     (ref.as_non_null
      (local.get $local10)
     )
    )
    (ref.as_non_null
     (local.get $local9)
    )
    (struct.get $type41 0
     (ref.as_non_null
      (local.get $local10)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready283)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global283)
     )
    )
    (local.set $local6
     (call_ref $call74
      (struct.get $type74 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local7)
      )
      (struct.get $type74 0
       (ref.as_non_null
        (local.get $local8)
       )
      )
     )
    )
    (call $foreign11
     (local.get $local6)
    )
    (i32.const 0)
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function93 (type $call82) (param $environment eqref) (param $argument302 (ref $type39)) (param $argument303 (ref $type40)) (param $argument304 (ref $type40)) (result i32)
  (local $local0 i32)
  (local $local12 i64)
  (local $local1 (ref null $type46))
  (local $local7 (ref null $type46))
  (local $local10 (ref null $type46))
  (local $local13 (ref null $type46))
  (local $local2 (ref null $type39))
  (local $local3 (ref null $type40))
  (local $local4 (ref null $type40))
  (local $local6 (ref null $type40))
  (local $local5 (ref null $type67))
  (local $local8 (ref null $type75))
  (local $local9 (ref null $type80))
  (local $local11 (ref null $type45))
  (local $local14 (ref null $type45))
  (local.set $local2
   (local.get $argument302)
  )
  (local.set $local3
   (local.get $argument303)
  )
  (local.set $local4
   (local.get $argument304)
  )
  (if
   (i32.eqz
    (global.get $ready211)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local5
   (ref.as_non_null
    (global.get $global211)
   )
  )
  (local.set $local1
   (call $function71
    (struct.get $type67 1
     (ref.as_non_null
      (local.get $local5)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
    (ref.as_non_null
     (local.get $local3)
    )
    (ref.as_non_null
     (local.get $local4)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local13
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready284)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (ref.as_non_null
    (global.get $global284)
   )
  )
  (local.set $local12
   (if (result i64)
    (call_ref $call45
     (struct.get $type45 1
      (ref.as_non_null
       (local.get $local14)
      )
     )
     (ref.as_non_null
      (local.get $local13)
     )
     (struct.get $type45 0
      (ref.as_non_null
       (local.get $local14)
      )
     )
    )
    (then
     (i64.const 1)
    )
    (else
     (i64.const 0)
    )
   )
  )
  (call $foreign12
   (local.get $local12)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready284)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global284)
   )
  )
  (if (result i32)
   (call_ref $call45
    (struct.get $type45 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (ref.as_non_null
     (local.get $local10)
    )
    (struct.get $type45 0
     (ref.as_non_null
      (local.get $local11)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready285)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global285)
     )
    )
    (local.set $local6
     (call_ref $call75
      (struct.get $type75 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local7)
      )
      (struct.get $type75 0
       (ref.as_non_null
        (local.get $local8)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready294)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global294)
     )
    )
    (return_call $function91
     (struct.get $type80 1
      (ref.as_non_null
       (local.get $local9)
      )
     )
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function94 (type $call83) (param $environment eqref) (param $argument307 (ref $type40)) (param $argument308 (ref $type40)) (result i32)
  (local $local0 i32)
  (local $local9 f64)
  (local $local15 i64)
  (local $local1 (ref null $type50))
  (local $local6 (ref null $type50))
  (local $local11 (ref null $type50))
  (local $local13 (ref null $type50))
  (local $local16 (ref null $type50))
  (local $local2 (ref null $type40))
  (local $local3 (ref null $type40))
  (local $local5 (ref null $type40))
  (local $local4 (ref null $type63))
  (local $local7 (ref null $type77))
  (local $local8 (ref null $type80))
  (local $local10 (ref null $type39))
  (local $local12 (ref null $type76))
  (local $local14 (ref null $type49))
  (local $local17 (ref null $type49))
  (local.set $local2
   (local.get $argument307)
  )
  (local.set $local3
   (local.get $argument308)
  )
  (if
   (i32.eqz
    (global.get $ready202)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local4
   (ref.as_non_null
    (global.get $global202)
   )
  )
  (local.set $local1
   (call $function69
    (struct.get $type63 1
     (ref.as_non_null
      (local.get $local4)
     )
    )
    (ref.as_non_null
     (local.get $local2)
    )
    (ref.as_non_null
     (local.get $local3)
    )
   )
  )
  (local.set $local0
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local16
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready286)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local17
   (ref.as_non_null
    (global.get $global286)
   )
  )
  (local.set $local15
   (if (result i64)
    (call_ref $call49
     (struct.get $type49 1
      (ref.as_non_null
       (local.get $local17)
      )
     )
     (ref.as_non_null
      (local.get $local16)
     )
     (struct.get $type49 0
      (ref.as_non_null
       (local.get $local17)
      )
     )
    )
    (then
     (i64.const 1)
    )
    (else
     (i64.const 0)
    )
   )
  )
  (call $foreign12
   (local.get $local15)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local0)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local13
   (ref.as_non_null
    (local.get $local1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready286)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local14
   (ref.as_non_null
    (global.get $global286)
   )
  )
  (if (result i32)
   (call_ref $call49
    (struct.get $type49 1
     (ref.as_non_null
      (local.get $local14)
     )
    )
    (ref.as_non_null
     (local.get $local13)
    )
    (struct.get $type49 0
     (ref.as_non_null
      (local.get $local14)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready287)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global287)
     )
    )
    (local.set $local10
     (call_ref $call76
      (struct.get $type76 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (ref.as_non_null
       (local.get $local11)
      )
      (struct.get $type76 0
       (ref.as_non_null
        (local.get $local12)
       )
      )
     )
    )
    (local.set $local9
     (struct.get $type39 0
      (ref.as_non_null
       (local.get $local10)
      )
     )
    )
    (call $foreign11
     (local.get $local9)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready288)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global288)
     )
    )
    (local.set $local5
     (call_ref $call77
      (struct.get $type77 1
       (ref.as_non_null
        (local.get $local7)
       )
      )
      (ref.as_non_null
       (local.get $local6)
      )
      (struct.get $type77 0
       (ref.as_non_null
        (local.get $local7)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready294)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global294)
     )
    )
    (return_call $function91
     (struct.get $type80 1
      (ref.as_non_null
       (local.get $local8)
      )
     )
     (ref.as_non_null
      (local.get $local5)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function95 (type $call84) (param $environment eqref) (param $argument311 f64) (param $argument312 f64) (result i32)
  (local $local0 f64)
  (local $local1 f64)
  (local $local2 f64)
  (local $local4 f64)
  (local $local5 f64)
  (local $local6 f64)
  (local $local3 (ref null $type53))
  (local $local7 (ref null $type53))
  (local.set $local5
   (local.get $argument311)
  )
  (local.set $local6
   (local.get $argument312)
  )
  (if
   (i32.eqz
    (global.get $ready289)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global289)
   )
  )
  (local.set $local4
   (call_ref $call53
    (struct.get $type53 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.get $local5)
    (local.get $local6)
    (struct.get $type53 0
     (ref.as_non_null
      (local.get $local7)
     )
    )
   )
  )
  (call $foreign11
   (local.get $local4)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local1
   (local.get $argument311)
  )
  (local.set $local2
   (local.get $argument312)
  )
  (if
   (i32.eqz
    (global.get $ready290)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local3
   (ref.as_non_null
    (global.get $global290)
   )
  )
  (local.set $local0
   (call_ref $call53
    (struct.get $type53 1
     (ref.as_non_null
      (local.get $local3)
     )
    )
    (local.get $local1)
    (local.get $local2)
    (struct.get $type53 0
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
  (call $foreign11
   (local.get $local0)
  )
  (i32.const 0)
 )
 (func $function96 (type $call73) (param $environment eqref) (param $argument314 i64) (result i64)
  (local $local0 (ref null $type38))
  (local $local5 (ref null $type38))
  (local $local72 (ref null $type38))
  (local $local80 (ref null $type38))
  (local $local85 (ref null $type38))
  (local $local94 (ref null $type38))
  (local $local99 (ref null $type38))
  (local $local101 (ref null $type38))
  (local $local103 (ref null $type38))
  (local $local108 (ref null $type38))
  (local $local110 (ref null $type38))
  (local $local112 (ref null $type38))
  (local $local117 (ref null $type38))
  (local $local119 (ref null $type38))
  (local $local124 (ref null $type38))
  (local $local1 (ref null $type79))
  (local $local6 (ref null $type79))
  (local $local7 (ref null $type37))
  (local $local9 (ref null $type14))
  (local $local10 (ref null $type69))
  (local $local12 (ref null $type40))
  (local $local17 (ref null $type40))
  (local $local25 (ref null $type40))
  (local $local33 (ref null $type40))
  (local $local41 (ref null $type40))
  (local $local49 (ref null $type40))
  (local $local55 (ref null $type40))
  (local $local59 (ref null $type40))
  (local $local61 (ref null $type40))
  (local $local63 (ref null $type40))
  (local $local69 (ref null $type40))
  (local $local70 (ref null $type40))
  (local $local76 (ref null $type40))
  (local $local82 (ref null $type40))
  (local $local83 (ref null $type40))
  (local $local89 (ref null $type40))
  (local $local96 (ref null $type40))
  (local $local97 (ref null $type40))
  (local $local105 (ref null $type40))
  (local $local106 (ref null $type40))
  (local $local114 (ref null $type40))
  (local $local115 (ref null $type40))
  (local $local121 (ref null $type40))
  (local $local122 (ref null $type40))
  (local $local127 (ref null $type40))
  (local $local128 (ref null $type40))
  (local $local134 (ref null $type40))
  (local $local135 (ref null $type40))
  (local $local138 (ref null $type40))
  (local $local139 (ref null $type40))
  (local $local22 (ref null $type39))
  (local $local30 (ref null $type39))
  (local $local38 (ref null $type39))
  (local $local46 (ref null $type39))
  (local $local54 (ref null $type39))
  (local $local62 (ref null $type39))
  (local $local73 (ref null $type39))
  (local $local86 (ref null $type39))
  (local $local100 (ref null $type39))
  (local $local102 (ref null $type39))
  (local $local109 (ref null $type39))
  (local $local111 (ref null $type39))
  (local $local118 (ref null $type39))
  (local $local126 (ref null $type39))
  (local $local133 (ref null $type39))
  (local $local137 (ref null $type39))
  (local $local60 (ref null $type64))
  (local $local67 (ref null $type68))
  (local $local68 (ref null $type80))
  (local $local71 (ref null $type83))
  (local $local84 (ref null $type83))
  (local $local98 (ref null $type83))
  (local $local107 (ref null $type83))
  (local $local116 (ref null $type83))
  (local $local123 (ref null $type83))
  (local $local81 (ref null $type78))
  (local $local95 (ref null $type78))
  (local $local104 (ref null $type78))
  (local $local113 (ref null $type78))
  (local $local120 (ref null $type78))
  (local $local125 (ref null $type78))
  (local $local132 (ref null $type82))
  (local $local136 (ref null $type82))
  (local $local140 (ref null $type82))
  (local $local145 (ref null $type84))
  (local $local149 (ref null $type84))
  (local $local153 (ref null $type84))
  (local $local157 (ref null $type84))
  (local $local161 (ref null $type84))
  (local $local166 (ref null $type81))
  (local $local170 (ref null $type81))
  (local $local174 (ref null $type81))
  (local $local178 (ref null $type81))
  (local $local182 (ref null $type81))
  (local $local186 (ref null $type81))
  (local $local190 (ref null $type81))
  (local $local194 (ref null $type81))
  (local $local2 i32)
  (local $local3 i32)
  (local $local11 i32)
  (local $local16 i32)
  (local $local21 i32)
  (local $local29 i32)
  (local $local37 i32)
  (local $local45 i32)
  (local $local4 i64)
  (local $local8 i64)
  (local $local93 i64)
  (local $local142 i64)
  (local $local144 i64)
  (local $local148 i64)
  (local $local151 i64)
  (local $local155 i64)
  (local $local160 i64)
  (local $local164 i64)
  (local $local13 f64)
  (local $local14 f64)
  (local $local15 f64)
  (local $local18 f64)
  (local $local19 f64)
  (local $local20 f64)
  (local $local23 f64)
  (local $local24 f64)
  (local $local26 f64)
  (local $local27 f64)
  (local $local28 f64)
  (local $local31 f64)
  (local $local32 f64)
  (local $local34 f64)
  (local $local35 f64)
  (local $local36 f64)
  (local $local39 f64)
  (local $local40 f64)
  (local $local42 f64)
  (local $local43 f64)
  (local $local44 f64)
  (local $local47 f64)
  (local $local48 f64)
  (local $local50 f64)
  (local $local51 f64)
  (local $local52 f64)
  (local $local53 f64)
  (local $local56 f64)
  (local $local57 f64)
  (local $local58 f64)
  (local $local64 f64)
  (local $local65 f64)
  (local $local66 f64)
  (local $local74 f64)
  (local $local75 f64)
  (local $local77 f64)
  (local $local78 f64)
  (local $local79 f64)
  (local $local87 f64)
  (local $local88 f64)
  (local $local90 f64)
  (local $local91 f64)
  (local $local92 f64)
  (local $local129 f64)
  (local $local130 f64)
  (local $local131 f64)
  (local $local141 f64)
  (local $local143 f64)
  (local $local146 f64)
  (local $local147 f64)
  (local $local150 f64)
  (local $local152 f64)
  (local $local154 f64)
  (local $local156 f64)
  (local $local158 f64)
  (local $local159 f64)
  (local $local162 f64)
  (local $local163 f64)
  (local $local165 f64)
  (local $local167 f64)
  (local $local168 f64)
  (local $local169 f64)
  (local $local171 f64)
  (local $local172 f64)
  (local $local173 f64)
  (local $local175 f64)
  (local $local176 f64)
  (local $local177 f64)
  (local $local179 f64)
  (local $local180 f64)
  (local $local181 f64)
  (local $local183 f64)
  (local $local184 f64)
  (local $local185 f64)
  (local $local187 f64)
  (local $local188 f64)
  (local $local189 f64)
  (local $local191 f64)
  (local $local192 f64)
  (local $local193 f64)
  (local.set $local191
   (f64.const 1)
  )
  (local.set $local192
   (f64.const 0)
  )
  (local.set $local193
   (f64.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local194
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (drop
   (call $function92
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local194)
     )
    )
    (local.get $local191)
    (local.get $local192)
    (local.get $local193)
   )
  )
  (local.set $local187
   (f64.const 1)
  )
  (local.set $local188
   (f64.const -2)
  )
  (local.set $local189
   (f64.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local190
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (drop
   (call $function92
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local190)
     )
    )
    (local.get $local187)
    (local.get $local188)
    (local.get $local189)
   )
  )
  (local.set $local183
   (f64.const 1)
  )
  (local.set $local184
   (f64.const 3)
  )
  (local.set $local185
   (f64.const 2)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local186
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (drop
   (call $function92
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local186)
     )
    )
    (local.get $local183)
    (local.get $local184)
    (local.get $local185)
   )
  )
  (local.set $local179
   (f64.const 1)
  )
  (local.set $local180
   (f64.const -3)
  )
  (local.set $local181
   (f64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local182
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (drop
   (call $function92
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local182)
     )
    )
    (local.get $local179)
    (local.get $local180)
    (local.get $local181)
   )
  )
  (local.set $local175
   (f64.const 0)
  )
  (local.set $local176
   (f64.const 2)
  )
  (local.set $local177
   (f64.const -4)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local178
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (drop
   (call $function92
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local178)
     )
    )
    (local.get $local175)
    (local.get $local176)
    (local.get $local177)
   )
  )
  (local.set $local171
   (f64.const 0)
  )
  (local.set $local172
   (f64.const 0)
  )
  (local.set $local173
   (f64.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local174
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (drop
   (call $function92
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local174)
     )
    )
    (local.get $local171)
    (local.get $local172)
    (local.get $local173)
   )
  )
  (local.set $local167
   (f64.const 0)
  )
  (local.set $local168
   (f64.const 0)
  )
  (local.set $local169
   (f64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local170
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (drop
   (call $function92
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local170)
     )
    )
    (local.get $local167)
    (local.get $local168)
    (local.get $local169)
   )
  )
  (local.set $local162
   (f64.const 1)
  )
  (local.set $local164
   (i64.const 1)
  )
  (local.set $local163
   (call $foreign13
    (local.get $local164)
   )
  )
  (local.set $local165
   (f64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local166
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (drop
   (call $function92
    (struct.get $type81 1
     (ref.as_non_null
      (local.get $local166)
     )
    )
    (local.get $local162)
    (local.get $local163)
    (local.get $local165)
   )
  )
  (local.set $local158
   (f64.const 0)
  )
  (local.set $local160
   (i64.const 0)
  )
  (local.set $local159
   (call $foreign13
    (local.get $local160)
   )
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local161
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (drop
   (call $function95
    (struct.get $type84 1
     (ref.as_non_null
      (local.get $local161)
     )
    )
    (local.get $local158)
    (local.get $local159)
   )
  )
  (local.set $local155
   (i64.const 0)
  )
  (local.set $local154
   (call $foreign13
    (local.get $local155)
   )
  )
  (local.set $local156
   (f64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local157
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (drop
   (call $function95
    (struct.get $type84 1
     (ref.as_non_null
      (local.get $local157)
     )
    )
    (local.get $local154)
    (local.get $local156)
   )
  )
  (local.set $local151
   (i64.const 1)
  )
  (local.set $local150
   (call $foreign13
    (local.get $local151)
   )
  )
  (local.set $local152
   (f64.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local153
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (drop
   (call $function95
    (struct.get $type84 1
     (ref.as_non_null
      (local.get $local153)
     )
    )
    (local.get $local150)
    (local.get $local152)
   )
  )
  (local.set $local146
   (f64.const 1)
  )
  (local.set $local148
   (i64.const 1)
  )
  (local.set $local147
   (call $foreign13
    (local.get $local148)
   )
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local149
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (drop
   (call $function95
    (struct.get $type84 1
     (ref.as_non_null
      (local.get $local149)
     )
    )
    (local.get $local146)
    (local.get $local147)
   )
  )
  (local.set $local142
   (i64.const 2)
  )
  (local.set $local141
   (call $foreign13
    (local.get $local142)
   )
  )
  (local.set $local144
   (i64.const 3)
  )
  (local.set $local143
   (call $foreign13
    (local.get $local144)
   )
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local145
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (drop
   (call $function95
    (struct.get $type84 1
     (ref.as_non_null
      (local.get $local145)
     )
    )
    (local.get $local141)
    (local.get $local143)
   )
  )
  (local.set $local13
   (f64.const 0)
  )
  (local.set $local14
   (f64.const 0)
  )
  (local.set $local15
   (f64.const 0)
  )
  (local.set $local12
   (struct.new $type40
    (local.get $local13)
    (local.get $local14)
    (local.get $local15)
   )
  )
  (local.set $local11
   (i32.const 1)
  )
  (local.set $local18
   (f64.const 0)
  )
  (local.set $local19
   (f64.const 0)
  )
  (local.set $local20
   (f64.const -1)
  )
  (local.set $local17
   (struct.new $type40
    (local.get $local18)
    (local.get $local19)
    (local.get $local20)
   )
  )
  (local.set $local16
   (i32.const 1)
  )
  (local.set $local23
   (f64.const 0.25)
  )
  (local.set $local24
   (f64.const 1)
  )
  (local.set $local26
   (f64.const 0)
  )
  (local.set $local27
   (f64.const 0)
  )
  (local.set $local28
   (f64.const 10)
  )
  (local.set $local25
   (struct.new $type40
    (local.get $local26)
    (local.get $local27)
    (local.get $local28)
   )
  )
  (local.set $local22
   (struct.new $type39
    (local.get $local23)
    (local.get $local24)
    (ref.as_non_null
     (local.get $local25)
    )
   )
  )
  (local.set $local21
   (i32.const 1)
  )
  (local.set $local31
   (f64.const 0.5)
  )
  (local.set $local32
   (f64.const 1)
  )
  (local.set $local34
   (f64.const 1)
  )
  (local.set $local35
   (f64.const 0)
  )
  (local.set $local36
   (f64.const -10)
  )
  (local.set $local33
   (struct.new $type40
    (local.get $local34)
    (local.get $local35)
    (local.get $local36)
   )
  )
  (local.set $local30
   (struct.new $type39
    (local.get $local31)
    (local.get $local32)
    (ref.as_non_null
     (local.get $local33)
    )
   )
  )
  (local.set $local29
   (i32.const 1)
  )
  (local.set $local39
   (f64.const 0.5)
  )
  (local.set $local40
   (f64.const 1)
  )
  (local.set $local42
   (f64.const 0)
  )
  (local.set $local43
   (f64.const 0)
  )
  (local.set $local44
   (f64.const -10)
  )
  (local.set $local41
   (struct.new $type40
    (local.get $local42)
    (local.get $local43)
    (local.get $local44)
   )
  )
  (local.set $local38
   (struct.new $type39
    (local.get $local39)
    (local.get $local40)
    (ref.as_non_null
     (local.get $local41)
    )
   )
  )
  (local.set $local37
   (i32.const 1)
  )
  (local.set $local47
   (f64.const 0.75)
  )
  (local.set $local48
   (f64.const 1)
  )
  (local.set $local50
   (f64.const 0)
  )
  (local.set $local51
   (f64.const 0)
  )
  (local.set $local52
   (f64.const -10)
  )
  (local.set $local49
   (struct.new $type40
    (local.get $local50)
    (local.get $local51)
    (local.get $local52)
   )
  )
  (local.set $local46
   (struct.new $type39
    (local.get $local47)
    (local.get $local48)
    (ref.as_non_null
     (local.get $local49)
    )
   )
  )
  (local.set $local45
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local21)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local137
   (ref.as_non_null
    (local.get $local22)
   )
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local138
   (ref.as_non_null
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local139
   (ref.as_non_null
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (global.get $ready301)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local140
   (ref.as_non_null
    (global.get $global301)
   )
  )
  (drop
   (call $function93
    (struct.get $type82 1
     (ref.as_non_null
      (local.get $local140)
     )
    )
    (ref.as_non_null
     (local.get $local137)
    )
    (ref.as_non_null
     (local.get $local138)
    )
    (ref.as_non_null
     (local.get $local139)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local29)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local133
   (ref.as_non_null
    (local.get $local30)
   )
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local134
   (ref.as_non_null
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local135
   (ref.as_non_null
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (global.get $ready301)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local136
   (ref.as_non_null
    (global.get $global301)
   )
  )
  (drop
   (call $function93
    (struct.get $type82 1
     (ref.as_non_null
      (local.get $local136)
     )
    )
    (ref.as_non_null
     (local.get $local133)
    )
    (ref.as_non_null
     (local.get $local134)
    )
    (ref.as_non_null
     (local.get $local135)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local37)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local126
   (ref.as_non_null
    (local.get $local38)
   )
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local127
   (ref.as_non_null
    (local.get $local12)
   )
  )
  (local.set $local129
   (f64.const 1)
  )
  (local.set $local130
   (f64.const 0)
  )
  (local.set $local131
   (f64.const 0)
  )
  (local.set $local128
   (struct.new $type40
    (local.get $local129)
    (local.get $local130)
    (local.get $local131)
   )
  )
  (if
   (i32.eqz
    (global.get $ready301)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local132
   (ref.as_non_null
    (global.get $global301)
   )
  )
  (drop
   (call $function93
    (struct.get $type82 1
     (ref.as_non_null
      (local.get $local132)
     )
    )
    (ref.as_non_null
     (local.get $local126)
    )
    (ref.as_non_null
     (local.get $local127)
    )
    (ref.as_non_null
     (local.get $local128)
    )
   )
  )
  (local.set $local124
   (ref.null none)
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local125
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (drop
   (call $function89
    (struct.get $type78 1
     (ref.as_non_null
      (local.get $local125)
     )
    )
    (local.get $local124)
   )
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local121
   (ref.as_non_null
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local122
   (ref.as_non_null
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local123
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (drop
   (call $function94
    (struct.get $type83 1
     (ref.as_non_null
      (local.get $local123)
     )
    )
    (ref.as_non_null
     (local.get $local121)
    )
    (ref.as_non_null
     (local.get $local122)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local21)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local118
   (ref.as_non_null
    (local.get $local22)
   )
  )
  (local.set $local119
   (ref.null none)
  )
  (local.set $local117
   (struct.new $type38
    (ref.as_non_null
     (local.get $local118)
    )
    (local.get $local119)
   )
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local120
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (drop
   (call $function89
    (struct.get $type78 1
     (ref.as_non_null
      (local.get $local120)
     )
    )
    (local.get $local117)
   )
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local114
   (ref.as_non_null
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local115
   (ref.as_non_null
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local116
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (drop
   (call $function94
    (struct.get $type83 1
     (ref.as_non_null
      (local.get $local116)
     )
    )
    (ref.as_non_null
     (local.get $local114)
    )
    (ref.as_non_null
     (local.get $local115)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local37)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local109
   (ref.as_non_null
    (local.get $local38)
   )
  )
  (if
   (i32.eqz
    (local.get $local45)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local111
   (ref.as_non_null
    (local.get $local46)
   )
  )
  (local.set $local112
   (ref.null none)
  )
  (local.set $local110
   (struct.new $type38
    (ref.as_non_null
     (local.get $local111)
    )
    (local.get $local112)
   )
  )
  (local.set $local108
   (struct.new $type38
    (ref.as_non_null
     (local.get $local109)
    )
    (local.get $local110)
   )
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local113
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (drop
   (call $function89
    (struct.get $type78 1
     (ref.as_non_null
      (local.get $local113)
     )
    )
    (local.get $local108)
   )
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local105
   (ref.as_non_null
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local106
   (ref.as_non_null
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local107
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (drop
   (call $function94
    (struct.get $type83 1
     (ref.as_non_null
      (local.get $local107)
     )
    )
    (ref.as_non_null
     (local.get $local105)
    )
    (ref.as_non_null
     (local.get $local106)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local45)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local100
   (ref.as_non_null
    (local.get $local46)
   )
  )
  (if
   (i32.eqz
    (local.get $local37)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local102
   (ref.as_non_null
    (local.get $local38)
   )
  )
  (local.set $local103
   (ref.null none)
  )
  (local.set $local101
   (struct.new $type38
    (ref.as_non_null
     (local.get $local102)
    )
    (local.get $local103)
   )
  )
  (local.set $local99
   (struct.new $type38
    (ref.as_non_null
     (local.get $local100)
    )
    (local.get $local101)
   )
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local104
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (drop
   (call $function89
    (struct.get $type78 1
     (ref.as_non_null
      (local.get $local104)
     )
    )
    (local.get $local99)
   )
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local96
   (ref.as_non_null
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local97
   (ref.as_non_null
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local98
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (drop
   (call $function94
    (struct.get $type83 1
     (ref.as_non_null
      (local.get $local98)
     )
    )
    (ref.as_non_null
     (local.get $local96)
    )
    (ref.as_non_null
     (local.get $local97)
    )
   )
  )
  (local.set $local87
   (f64.const 0.5)
  )
  (local.set $local88
   (f64.const 1)
  )
  (local.set $local90
   (f64.const 0)
  )
  (local.set $local91
   (f64.const 0)
  )
  (local.set $local93
   (i64.const 1)
  )
  (local.set $local92
   (call $foreign13
    (local.get $local93)
   )
  )
  (local.set $local89
   (struct.new $type40
    (local.get $local90)
    (local.get $local91)
    (local.get $local92)
   )
  )
  (local.set $local86
   (struct.new $type39
    (local.get $local87)
    (local.get $local88)
    (ref.as_non_null
     (local.get $local89)
    )
   )
  )
  (local.set $local94
   (ref.null none)
  )
  (local.set $local85
   (struct.new $type38
    (ref.as_non_null
     (local.get $local86)
    )
    (local.get $local94)
   )
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local95
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (drop
   (call $function89
    (struct.get $type78 1
     (ref.as_non_null
      (local.get $local95)
     )
    )
    (local.get $local85)
   )
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local82
   (ref.as_non_null
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local83
   (ref.as_non_null
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local84
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (drop
   (call $function94
    (struct.get $type83 1
     (ref.as_non_null
      (local.get $local84)
     )
    )
    (ref.as_non_null
     (local.get $local82)
    )
    (ref.as_non_null
     (local.get $local83)
    )
   )
  )
  (local.set $local74
   (f64.const 0.5)
  )
  (local.set $local75
   (f64.const 0)
  )
  (local.set $local77
   (f64.const 0)
  )
  (local.set $local78
   (f64.const 0)
  )
  (local.set $local79
   (f64.const 1.e+308)
  )
  (local.set $local76
   (struct.new $type40
    (local.get $local77)
    (local.get $local78)
    (local.get $local79)
   )
  )
  (local.set $local73
   (struct.new $type39
    (local.get $local74)
    (local.get $local75)
    (ref.as_non_null
     (local.get $local76)
    )
   )
  )
  (local.set $local80
   (ref.null none)
  )
  (local.set $local72
   (struct.new $type38
    (ref.as_non_null
     (local.get $local73)
    )
    (local.get $local80)
   )
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local81
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (drop
   (call $function89
    (struct.get $type78 1
     (ref.as_non_null
      (local.get $local81)
     )
    )
    (local.get $local72)
   )
  )
  (if
   (i32.eqz
    (local.get $local11)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local69
   (ref.as_non_null
    (local.get $local12)
   )
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local70
   (ref.as_non_null
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local71
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (drop
   (call $function94
    (struct.get $type83 1
     (ref.as_non_null
      (local.get $local71)
     )
    )
    (ref.as_non_null
     (local.get $local69)
    )
    (ref.as_non_null
     (local.get $local70)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local37)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local62
   (ref.as_non_null
    (local.get $local38)
   )
  )
  (local.set $local64
   (f64.const 0)
  )
  (local.set $local65
   (f64.const 0)
  )
  (local.set $local66
   (f64.const -9)
  )
  (local.set $local63
   (struct.new $type40
    (local.get $local64)
    (local.get $local65)
    (local.get $local66)
   )
  )
  (if
   (i32.eqz
    (global.get $ready232)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local67
   (ref.as_non_null
    (global.get $global232)
   )
  )
  (local.set $local61
   (call $function74
    (struct.get $type68 1
     (ref.as_non_null
      (local.get $local67)
     )
    )
    (ref.as_non_null
     (local.get $local62)
    )
    (ref.as_non_null
     (local.get $local63)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local68
   (ref.as_non_null
    (global.get $global294)
   )
  )
  (drop
   (call $function91
    (struct.get $type80 1
     (ref.as_non_null
      (local.get $local68)
     )
    )
    (ref.as_non_null
     (local.get $local61)
    )
   )
  )
  (if
   (i32.eqz
    (local.get $local37)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local54
   (ref.as_non_null
    (local.get $local38)
   )
  )
  (local.set $local56
   (f64.const 0)
  )
  (local.set $local57
   (f64.const 0)
  )
  (local.set $local58
   (f64.const -9)
  )
  (local.set $local55
   (struct.new $type40
    (local.get $local56)
    (local.get $local57)
    (local.get $local58)
   )
  )
  (if
   (i32.eqz
    (local.get $local16)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local59
   (ref.as_non_null
    (local.get $local17)
   )
  )
  (if
   (i32.eqz
    (global.get $ready227)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local60
   (ref.as_non_null
    (global.get $global227)
   )
  )
  (local.set $local53
   (call $function73
    (struct.get $type64 1
     (ref.as_non_null
      (local.get $local60)
     )
    )
    (ref.as_non_null
     (local.get $local54)
    )
    (ref.as_non_null
     (local.get $local55)
    )
    (ref.as_non_null
     (local.get $local59)
    )
   )
  )
  (call $foreign11
   (local.get $local53)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local8
   (i64.const 0)
  )
  (local.set $local9
   (global.get $string3)
  )
  (if
   (i32.eqz
    (global.get $ready253)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local10
   (ref.as_non_null
    (global.get $global253)
   )
  )
  (drop
   (call $function79
    (struct.get $type69 1
     (ref.as_non_null
      (local.get $local10)
     )
    )
    (local.get $local8)
    (ref.as_non_null
     (local.get $local9)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready293)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local6
   (ref.as_non_null
    (global.get $global293)
   )
  )
  (local.set $local5
   (call $function90
    (struct.get $type79 1
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready321)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global321)
   )
  )
  (local.set $local4
   (call $function97
    (struct.get $type37 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (local.get $local5)
   )
  )
  (call $foreign12
   (local.get $local4)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready293)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global293)
   )
  )
  (local.set $local0
   (call $function90
    (struct.get $type79 1
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (drop
   (call $function99
    (local.get $local3)
    (local.get $local2)
    (local.get $local0)
   )
  )
  (i64.const 1)
 )
 (func $function97 (type $call37) (param $environment eqref) (param $argument322 (ref null $type38)) (result i64)
  (local $local0 (ref null $type38))
  (local $local1 i64)
  (local $local2 i32)
  (local $local3 i32)
  (local.set $local0
   (local.get $argument322)
  )
  (local.set $local1
   (i64.const 0)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (local.get $local2)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (local.get $local3)
  )
  (return_call $function98
   (local.get $local3)
   (local.get $local2)
   (local.get $local0)
   (local.get $local1)
  )
 )
 (func $function98 (param $capture323 i32) (param $initialized323 i32) (param $argument324 (ref null $type38)) (param $argument325 i64) (result i64)
  (local $local0 (ref null $type38))
  (local $local1 (ref null $type38))
  (local $local5 (ref null $type38))
  (local $local2 i64)
  (local $local3 i64)
  (local $local4 i64)
  (local.set $local5
   (local.get $argument324)
  )
  (if (result i64)
   (ref.is_null
    (local.get $local5)
   )
   (then
    (local.get $argument325)
   )
   (else
    (local.set $local1
     (local.get $argument324)
    )
    (local.set $local0
     (struct.get $type38 1
      (local.get $local1)
     )
    )
    (local.set $local3
     (local.get $argument325)
    )
    (local.set $local4
     (i64.const 1)
    )
    (local.set $local2
     (i64.add
      (local.get $local3)
      (local.get $local4)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized323)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture323)
    )
    (return_call $function98
     (local.get $capture323)
     (local.get $initialized323)
     (local.get $local0)
     (local.get $local2)
    )
   )
  )
 )
 (func $function99 (param $capture326 i32) (param $initialized326 i32) (param $argument327 (ref null $type38)) (result i32)
  (local $local0 (ref null $type38))
  (local $local1 (ref null $type38))
  (local $local4 (ref null $type38))
  (local $local8 (ref null $type38))
  (local $local11 (ref null $type38))
  (local $local12 (ref null $type38))
  (local $local2 (ref null $type40))
  (local $local3 (ref null $type39))
  (local $local7 (ref null $type39))
  (local $local10 (ref null $type39))
  (local $local5 (ref null $type80))
  (local $local6 f64)
  (local $local9 f64)
  (local.set $local12
   (local.get $argument327)
  )
  (if (result i32)
   (ref.is_null
    (local.get $local12)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local11
     (local.get $argument327)
    )
    (local.set $local10
     (struct.get $type38 0
      (local.get $local11)
     )
    )
    (local.set $local9
     (struct.get $type39 0
      (ref.as_non_null
       (local.get $local10)
      )
     )
    )
    (call $foreign11
     (local.get $local9)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local8
     (local.get $argument327)
    )
    (local.set $local7
     (struct.get $type38 0
      (local.get $local8)
     )
    )
    (local.set $local6
     (struct.get $type39 1
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (call $foreign11
     (local.get $local6)
    )
    (drop
     (i32.const 0)
    )
    (local.set $local4
     (local.get $argument327)
    )
    (local.set $local3
     (struct.get $type38 0
      (local.get $local4)
     )
    )
    (local.set $local2
     (struct.get $type39 2
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready294)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global294)
     )
    )
    (drop
     (call $function91
      (struct.get $type80 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local1
     (local.get $argument327)
    )
    (local.set $local0
     (struct.get $type38 1
      (local.get $local1)
     )
    )
    (if
     (i32.eqz
      (local.get $initialized326)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture326)
    )
    (return_call $function99
     (local.get $capture326)
     (local.get $initialized326)
     (local.get $local0)
    )
   )
  )
 )
 (func $primitive0 (type $call77) (param $environment eqref) (param $argument0 (ref $type50)) (result (ref $type40))
  (if
   (i32.ne
    (struct.get $type50 0
     (local.get $argument0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type52 2
   (ref.cast (ref $type52)
    (local.get $argument0)
   )
  )
 )
 (func $primitive1 (type $call76) (param $environment eqref) (param $argument0 (ref $type50)) (result (ref $type39))
  (if
   (i32.ne
    (struct.get $type50 0
     (local.get $argument0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type52 1
   (ref.cast (ref $type52)
    (local.get $argument0)
   )
  )
 )
 (func $primitive2 (type $call75) (param $environment eqref) (param $argument0 (ref $type46)) (result (ref $type40))
  (if
   (i32.ne
    (struct.get $type46 0
     (local.get $argument0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type48 1
   (ref.cast (ref $type48)
    (local.get $argument0)
   )
  )
 )
 (func $primitive3 (type $call74) (param $environment eqref) (param $argument0 (ref $type42)) (result f64)
  (if
   (i32.ne
    (struct.get $type42 0
     (local.get $argument0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type44 1
   (ref.cast (ref $type44)
    (local.get $argument0)
   )
  )
 )
 (func $export0 (param $argument0 i64) (result i64)
  (local $local0 (ref null $type73))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready313)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local0
   (ref.as_non_null
    (global.get $global313)
   )
  )
  (return_call $function96
   (struct.get $type73 1
    (ref.as_non_null
     (local.get $local0)
    )
   )
   (local.get $argument0)
  )
 )
 (func $main
  (local $local0 i32)
  (local $local2 i32)
  (local $local3 f64)
  (local $local4 f64)
  (local $local5 f64)
  (local $local1 (ref null $type71))
  (local $local6 (ref null $type38))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global0
   (struct.new $type0
    (ref.func $function0)
    (ref.null none)
   )
  )
  (global.set $ready0
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global3
   (struct.new $type1
    (ref.func $function1)
    (ref.null none)
   )
  )
  (global.set $ready3
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global6
   (struct.new $type0
    (ref.func $function2)
    (ref.null none)
   )
  )
  (global.set $ready6
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global9
   (struct.new $type1
    (ref.func $function3)
    (ref.null none)
   )
  )
  (global.set $ready9
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global12
   (struct.new $type0
    (ref.func $function4)
    (ref.null none)
   )
  )
  (global.set $ready12
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global15
   (struct.new $type1
    (ref.func $function5)
    (ref.null none)
   )
  )
  (global.set $ready15
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global18
   (struct.new $type0
    (ref.func $function6)
    (ref.null none)
   )
  )
  (global.set $ready18
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global21
   (struct.new $type1
    (ref.func $function7)
    (ref.null none)
   )
  )
  (global.set $ready21
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global24
   (struct.new $type2
    (ref.func $function8)
    (ref.null none)
   )
  )
  (global.set $ready24
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global27
   (struct.new $type3
    (ref.func $function9)
    (ref.null none)
   )
  )
  (global.set $ready27
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global30
   (struct.new $type2
    (ref.func $function10)
    (ref.null none)
   )
  )
  (global.set $ready30
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global33
   (struct.new $type3
    (ref.func $function11)
    (ref.null none)
   )
  )
  (global.set $ready33
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global36
   (struct.new $type2
    (ref.func $function12)
    (ref.null none)
   )
  )
  (global.set $ready36
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global39
   (struct.new $type3
    (ref.func $function13)
    (ref.null none)
   )
  )
  (global.set $ready39
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global42
   (struct.new $type2
    (ref.func $function14)
    (ref.null none)
   )
  )
  (global.set $ready42
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global45
   (struct.new $type3
    (ref.func $function15)
    (ref.null none)
   )
  )
  (global.set $ready45
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global48
   (struct.new $type2
    (ref.func $function16)
    (ref.null none)
   )
  )
  (global.set $ready48
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global51
   (struct.new $type3
    (ref.func $function17)
    (ref.null none)
   )
  )
  (global.set $ready51
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global54
   (struct.new $type4
    (ref.func $function18)
    (ref.null none)
   )
  )
  (global.set $ready54
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global55
   (struct.new $type5
    (ref.func $function19)
    (ref.null none)
   )
  )
  (global.set $ready55
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global56
   (struct.new $type6
    (ref.func $function20)
    (ref.null none)
   )
  )
  (global.set $ready56
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global57
   (struct.new $type7
    (ref.func $function21)
    (ref.null none)
   )
  )
  (global.set $ready57
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global58
   (struct.new $type8
    (ref.func $function22)
    (ref.null none)
   )
  )
  (global.set $ready58
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global59
   (struct.new $type9
    (ref.func $function23)
    (ref.null none)
   )
  )
  (global.set $ready59
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global60
   (struct.new $type10
    (ref.func $function24)
    (ref.null none)
   )
  )
  (global.set $ready60
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global68
   (struct.new $type11
    (ref.func $function28)
    (ref.null none)
   )
  )
  (global.set $ready68
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global61
   (struct.new $type13
    (ref.func $function25)
    (ref.null none)
   )
  )
  (global.set $ready61
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global63
   (struct.new $type17
    (ref.func $function26)
    (ref.null none)
   )
  )
  (global.set $ready63
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global65
   (struct.new $type18
    (ref.func $function27)
    (ref.null none)
   )
  )
  (global.set $ready65
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global76
   (struct.new $type19
    (ref.func $function31)
    (ref.null none)
   )
  )
  (global.set $ready76
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global81
   (struct.new $type20
    (ref.func $function33)
    (ref.null none)
   )
  )
  (global.set $ready81
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global88
   (struct.new $type21
    (ref.func $function34)
    (ref.null none)
   )
  )
  (global.set $ready88
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global90
   (struct.new $type22
    (ref.func $function35)
    (ref.null none)
   )
  )
  (global.set $ready90
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global93
   (struct.new $type24
    (ref.func $function36)
    (ref.null none)
   )
  )
  (global.set $ready93
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global98
   (struct.new $type25
    (ref.func $function38)
    (ref.null none)
   )
  )
  (global.set $ready98
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global103
   (struct.new $type26
    (ref.func $function39)
    (ref.null none)
   )
  )
  (global.set $ready103
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global109
   (struct.new $type27
    (ref.func $function41)
    (ref.null none)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global114
   (struct.new $type28
    (ref.func $function43)
    (ref.null none)
   )
  )
  (global.set $ready114
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global116
   (struct.new $type27
    (ref.func $function44)
    (ref.null none)
   )
  )
  (global.set $ready116
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global118
   (struct.new $type29
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $ready118
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global120
   (struct.new $type32
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $ready120
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global241
   (struct.new $type33
    (ref.func $function77)
    (ref.null none)
   )
  )
  (global.set $ready241
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global124
   (struct.new $type34
    (ref.func $function47)
    (ref.null none)
   )
  )
  (global.set $ready124
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global127
   (struct.new $type35
    (ref.func $function48)
    (ref.null none)
   )
  )
  (global.set $ready127
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global133
   (struct.new $type32
    (ref.func $function50)
    (ref.null none)
   )
  )
  (global.set $ready133
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global135
   (struct.new $type36
    (ref.func $function51)
    (ref.null none)
   )
  )
  (global.set $ready135
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global138
   (struct.new $type36
    (ref.func $function52)
    (ref.null none)
   )
  )
  (global.set $ready138
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global321
   (struct.new $type37
    (ref.func $function97)
    (ref.null none)
   )
  )
  (global.set $ready321
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global142
   (struct.new $type41
    (ref.func $function53)
    (ref.null none)
   )
  )
  (global.set $ready142
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global146
   (struct.new $type45
    (ref.func $function54)
    (ref.null none)
   )
  )
  (global.set $ready146
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global150
   (struct.new $type49
    (ref.func $function55)
    (ref.null none)
   )
  )
  (global.set $ready150
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global155
   (struct.new $type53
    (ref.func $function56)
    (ref.null none)
   )
  )
  (global.set $ready155
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global158
   (struct.new $type53
    (ref.func $function57)
    (ref.null none)
   )
  )
  (global.set $ready158
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global279
   (struct.new $type54
    (ref.func $function88)
    (ref.null none)
   )
  )
  (global.set $ready279
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global161
   (struct.new $type55
    (ref.func $function58)
    (ref.null none)
   )
  )
  (global.set $ready161
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global163
   (struct.new $type56
    (ref.func $function59)
    (ref.null none)
   )
  )
  (global.set $ready163
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global167
   (struct.new $type57
    (ref.func $function60)
    (ref.null none)
   )
  )
  (global.set $ready167
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global172
   (struct.new $type58
    (ref.func $function61)
    (ref.null none)
   )
  )
  (global.set $ready172
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global175
   (struct.new $type59
    (ref.func $function62)
    (ref.null none)
   )
  )
  (global.set $ready175
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local6
   (ref.null none)
  )
  (global.set $global183
   (struct.new $type60
    (local.get $local6)
   )
  )
  (global.set $ready183
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local3
   (f64.const 0)
  )
  (local.set $local4
   (f64.const 0)
  )
  (local.set $local5
   (f64.const 200)
  )
  (global.set $global184
   (struct.new $type40
    (local.get $local3)
    (local.get $local4)
    (local.get $local5)
   )
  )
  (global.set $ready184
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global185
   (struct.new $type61
    (ref.func $function63)
    (ref.null none)
   )
  )
  (global.set $ready185
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global194
   (struct.new $type62
    (ref.func $function67)
    (ref.null none)
   )
  )
  (global.set $ready194
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global198
   (struct.new $type58
    (ref.func $function68)
    (ref.null none)
   )
  )
  (global.set $ready198
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global202
   (struct.new $type63
    (ref.func $function69)
    (ref.null none)
   )
  )
  (global.set $ready202
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global227
   (struct.new $type64
    (ref.func $function73)
    (ref.null none)
   )
  )
  (global.set $ready227
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global246
   (struct.new $type65
    (ref.func $function78)
    (ref.null none)
   )
  )
  (global.set $ready246
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global239
   (struct.new $type66
    (ref.func $function76)
    (ref.null none)
   )
  )
  (global.set $ready239
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global211
   (struct.new $type67
    (ref.func $function71)
    (ref.null none)
   )
  )
  (global.set $ready211
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global215
   (struct.new $type67
    (ref.func $function72)
    (ref.null none)
   )
  )
  (global.set $ready215
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global232
   (struct.new $type68
    (ref.func $function74)
    (ref.null none)
   )
  )
  (global.set $ready232
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global235
   (struct.new $type68
    (ref.func $function75)
    (ref.null none)
   )
  )
  (global.set $ready235
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global253
   (struct.new $type69
    (ref.func $function79)
    (ref.null none)
   )
  )
  (global.set $ready253
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global260
   (struct.new $type70
    (ref.func $function82)
    (ref.null none)
   )
  )
  (global.set $ready260
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global263
   (struct.new $type71
    (ref.func $function83)
    (ref.null none)
   )
  )
  (global.set $ready263
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local2
   (i32.const 0)
  )
  (global.set $global268
   (call $foreign14
    (local.get $local2)
   )
  )
  (global.set $ready268
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready263)
   )
   (then
    (unreachable)
   )
  )
  (local.set $local1
   (ref.as_non_null
    (global.get $global263)
   )
  )
  (global.set $global269
   (call $function83
    (struct.get $type71 1
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
  (global.set $ready269
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (local.set $local0
   (i32.const 1)
  )
  (global.set $global270
   (call $foreign14
    (local.get $local0)
   )
  )
  (global.set $ready270
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global271
   (struct.new $type72
    (ref.func $function85)
    (ref.null none)
   )
  )
  (global.set $ready271
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global274
   (struct.new $type73
    (ref.func $function86)
    (ref.null none)
   )
  )
  (global.set $ready274
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready142)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global282
   (ref.as_non_null
    (global.get $global142)
   )
  )
  (global.set $ready282
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global283
   (struct.new $type74
    (ref.func $primitive3)
    (ref.null none)
   )
  )
  (global.set $ready283
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready146)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global284
   (ref.as_non_null
    (global.get $global146)
   )
  )
  (global.set $ready284
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global285
   (struct.new $type75
    (ref.func $primitive2)
    (ref.null none)
   )
  )
  (global.set $ready285
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global286
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (global.set $ready286
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global287
   (struct.new $type76
    (ref.func $primitive1)
    (ref.null none)
   )
  )
  (global.set $ready287
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global288
   (struct.new $type77
    (ref.func $primitive0)
    (ref.null none)
   )
  )
  (global.set $ready288
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global289
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (global.set $ready289
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global290
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (global.set $ready290
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global291
   (struct.new $type78
    (ref.func $function89)
    (ref.null none)
   )
  )
  (global.set $ready291
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global293
   (struct.new $type79
    (ref.func $function90)
    (ref.null none)
   )
  )
  (global.set $ready293
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global294
   (struct.new $type80
    (ref.func $function91)
    (ref.null none)
   )
  )
  (global.set $ready294
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global296
   (struct.new $type81
    (ref.func $function92)
    (ref.null none)
   )
  )
  (global.set $ready296
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global301
   (struct.new $type82
    (ref.func $function93)
    (ref.null none)
   )
  )
  (global.set $ready301
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global306
   (struct.new $type83
    (ref.func $function94)
    (ref.null none)
   )
  )
  (global.set $ready306
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global310
   (struct.new $type84
    (ref.func $function95)
    (ref.null none)
   )
  )
  (global.set $ready310
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $global313
   (struct.new $type73
    (ref.func $function96)
    (ref.null none)
   )
  )
  (global.set $ready313
   (i32.const 1)
  )
  (drop
   (i32.const 0)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

