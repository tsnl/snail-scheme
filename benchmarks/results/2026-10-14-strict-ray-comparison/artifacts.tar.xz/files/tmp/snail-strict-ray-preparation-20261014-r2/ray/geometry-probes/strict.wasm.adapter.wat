(module
  (import "snail.library" "snail:report-error" (func $report (param i32 i32)))
  (import "snail.library" "snail:io/close-all" (func $close (result i32)))
  (export "diagnostics/report-error" (func $report))
  (export "close-resources" (func $close)))
