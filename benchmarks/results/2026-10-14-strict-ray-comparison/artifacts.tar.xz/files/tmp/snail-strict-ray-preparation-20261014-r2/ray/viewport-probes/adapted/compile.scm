(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-ray-preparation-20261014-r2/ray/viewport-probes/adapted/program.scm" "/tmp/snail-strict-ray-preparation-20261014-r2/ray/viewport-probes/adapted/program.so"))
