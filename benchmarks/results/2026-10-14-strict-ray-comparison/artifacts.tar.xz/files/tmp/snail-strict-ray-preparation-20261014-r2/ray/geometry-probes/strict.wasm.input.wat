(module
 (rec
  (type $type50 (sub (struct)))
  (type $type46 (sub (struct)))
  (type $type42 (sub (struct)))
  (type $3 (func (param i32 i32 (ref null $type38)) (result i32)))
  (type $4 (func (param i32 i32 (ref null $type38) i64) (result i64)))
  (type $call73 (func (result i64)))
  (type $type51 (sub $type50 (struct)))
  (type $7 (func (param (ref $type40) (ref $type40))))
  (type $8 (func (param (ref $type39) (ref $type40) (ref $type40))))
  (type $9 (func (param f64 f64 f64)))
  (type $10 (func (param (ref $type40))))
  (type $11 (func (param i64 (ref $type14) i32 i32 i64) (result (ref $type14))))
  (type $12 (func (param i64 i32 i32 i64) (result i32)))
  (type $type47 (sub $type46 (struct)))
  (type $call67 (func (param (ref $type39) (ref $type40) (ref $type40)) (result (ref $type46))))
  (type $type52 (sub $type50 (struct (field (ref $type39)) (field (ref $type40)))))
  (type $type48 (sub $type46 (struct (field (ref $type40)))))
  (type $type38 (struct (field (ref $type39)) (field (ref null $type38))))
  (type $type40 (struct (field f64) (field f64) (field f64)))
  (type $type39 (struct (field f64) (field f64) (field (ref $type40))))
  (type $20 (func (param (ref $type40) (ref $type40) i32 i32 (ref null $type38) (ref $type50) f64) (result (ref $type50))))
  (type $type43 (sub $type42 (struct)))
  (type $type44 (sub $type42 (struct (field f64))))
  (type $call59 (func (param f64 f64 f64) (result (ref $type42))))
  (type $call53 (func (param f64 f64) (result f64)))
  (type $25 (func (param i64 (ref $type30))))
  (type $type31 (struct (field (mut i32))))
  (type $type30 (struct (field (ref $type31))))
  (type $28 (func (param (ref $type14) (ref $type30) i64 i32 i32 i64) (result i32)))
  (type $29 (func (param (ref $type14) i64 i32 i32 i64) (result i32)))
  (type $30 (func (param (ref $type14)) (result i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $32 (func (param (ref $type14) i32) (result (ref $type15))))
  (type $type73 (struct))
  (type $type84 (struct))
  (type $type83 (struct))
  (type $type82 (struct))
  (type $type81 (struct))
  (type $type80 (struct))
  (type $type79 (struct))
  (type $type78 (struct))
  (type $type77 (struct))
  (type $type76 (struct))
  (type $type75 (struct))
  (type $type74 (struct))
  (type $type71 (struct))
  (type $type69 (struct))
  (type $type68 (struct))
  (type $type67 (struct))
  (type $type65 (struct))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type61 (struct))
  (type $type60 (struct (field (mut (ref null $type38)))))
  (type $type59 (struct))
  (type $type58 (struct))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type53 (struct (field (ref $call53))))
  (type $type49 (struct))
  (type $type45 (struct))
  (type $type41 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $74 (func))
 (type $75 (func (param i32)))
 (type $76 (func (result i32)))
 (type $77 (func (param i32 i32)))
 (type $78 (func (result i64)))
 (type $79 (func (param i64) (result i32)))
 (type $80 (func (param f64)))
 (type $81 (func (param i64)))
 (type $82 (func (param i64) (result f64)))
 (type $83 (func (param i32) (result i64)))
 (type $84 (func (param i64) (result i64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign3))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign5 (param i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign6 (param i32 i32)))
 (import "benchmark" "path_length" (func $foreign7 (result i64)))
 (import "benchmark" "path_character" (func $foreign8 (param i64) (result i32)))
 (import "probe" "f64" (func $foreign11 (param f64)))
 (import "probe" "i64" (func $foreign12 (param i64)))
 (import "probe" "float" (func $foreign13 (param i64) (result f64)))
 (import "benchmark" "input_i64" (func $foreign14 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type15 4
   (i32.const 32)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type15 1
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 80)
   (i32.const 50)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 18)
  (array.new_fixed $type15 18
   (i32.const 103)
   (i32.const 101)
   (i32.const 111)
   (i32.const 109)
   (i32.const 101)
   (i32.const 116)
   (i32.const 114)
   (i32.const 121)
   (i32.const 45)
   (i32.const 115)
   (i32.const 99)
   (i32.const 101)
   (i32.const 110)
   (i32.const 101)
   (i32.const 46)
   (i32.const 112)
   (i32.const 103)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type28)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type29)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type32)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global241 (mut (ref null $type33)) (ref.null none))
 (global $ready241 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type34)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type35)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type32)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type36)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type36)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global321 (mut (ref null $type37)) (ref.null none))
 (global $ready321 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type41)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global146 (mut (ref null $type45)) (ref.null none))
 (global $ready146 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type49)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type53)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global158 (mut (ref null $type53)) (ref.null none))
 (global $ready158 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type55)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global163 (mut (ref null $type56)) (ref.null none))
 (global $ready163 (mut i32) (i32.const 0))
 (global $global167 (mut (ref null $type57)) (ref.null none))
 (global $ready167 (mut i32) (i32.const 0))
 (global $global172 (mut (ref null $type58)) (ref.null none))
 (global $ready172 (mut i32) (i32.const 0))
 (global $global175 (mut (ref null $type59)) (ref.null none))
 (global $ready175 (mut i32) (i32.const 0))
 (global $global183 (mut (ref null $type60)) (ref.null none))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global185 (mut (ref null $type61)) (ref.null none))
 (global $ready185 (mut i32) (i32.const 0))
 (global $global202 (mut (ref null $type63)) (ref.null none))
 (global $ready202 (mut i32) (i32.const 0))
 (global $global227 (mut (ref null $type64)) (ref.null none))
 (global $ready227 (mut i32) (i32.const 0))
 (global $global246 (mut (ref null $type65)) (ref.null none))
 (global $ready246 (mut i32) (i32.const 0))
 (global $global211 (mut (ref null $type67)) (ref.null none))
 (global $ready211 (mut i32) (i32.const 0))
 (global $global215 (mut (ref null $type67)) (ref.null none))
 (global $ready215 (mut i32) (i32.const 0))
 (global $global232 (mut (ref null $type68)) (ref.null none))
 (global $ready232 (mut i32) (i32.const 0))
 (global $global235 (mut (ref null $type68)) (ref.null none))
 (global $ready235 (mut i32) (i32.const 0))
 (global $global253 (mut (ref null $type69)) (ref.null none))
 (global $ready253 (mut i32) (i32.const 0))
 (global $global263 (mut (ref null $type71)) (ref.null none))
 (global $ready263 (mut i32) (i32.const 0))
 (global $global282 (mut (ref null $type41)) (ref.null none))
 (global $ready282 (mut i32) (i32.const 0))
 (global $global283 (mut (ref null $type74)) (ref.null none))
 (global $ready283 (mut i32) (i32.const 0))
 (global $global284 (mut (ref null $type45)) (ref.null none))
 (global $ready284 (mut i32) (i32.const 0))
 (global $global285 (mut (ref null $type75)) (ref.null none))
 (global $ready285 (mut i32) (i32.const 0))
 (global $global286 (mut (ref null $type49)) (ref.null none))
 (global $ready286 (mut i32) (i32.const 0))
 (global $global287 (mut (ref null $type76)) (ref.null none))
 (global $ready287 (mut i32) (i32.const 0))
 (global $global288 (mut (ref null $type77)) (ref.null none))
 (global $ready288 (mut i32) (i32.const 0))
 (global $global289 (mut (ref null $type53)) (ref.null none))
 (global $ready289 (mut i32) (i32.const 0))
 (global $global290 (mut (ref null $type53)) (ref.null none))
 (global $ready290 (mut i32) (i32.const 0))
 (global $global291 (mut (ref null $type78)) (ref.null none))
 (global $ready291 (mut i32) (i32.const 0))
 (global $global293 (mut (ref null $type79)) (ref.null none))
 (global $ready293 (mut i32) (i32.const 0))
 (global $global294 (mut (ref null $type80)) (ref.null none))
 (global $ready294 (mut i32) (i32.const 0))
 (global $global296 (mut (ref null $type81)) (ref.null none))
 (global $ready296 (mut i32) (i32.const 0))
 (global $global301 (mut (ref null $type82)) (ref.null none))
 (global $ready301 (mut i32) (i32.const 0))
 (global $global306 (mut (ref null $type83)) (ref.null none))
 (global $ready306 (mut i32) (i32.const 0))
 (global $global310 (mut (ref null $type84)) (ref.null none))
 (global $ready310 (mut i32) (i32.const 0))
 (global $global313 (mut (ref null $type73)) (ref.null none))
 (global $ready313 (mut i32) (i32.const 0))
 (export "geometry-probe" (func $export0))
 (export "main" (func $main))
 (func $string-block (type $32) (param $0 (ref $type14)) (param $1 i32) (result (ref $type15))
  (if (result (ref $type15))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type14 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type16
      (struct.get $type14 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function41 (type $30) (param $0 (ref $type14)) (result i32)
  (local $1 i64)
  (call $foreign0)
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (struct.get $type14 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (array.get $type15
        (struct.get $type14 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (array.get $type15
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (array.get $type15
            (struct.get $type14 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type14 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (array.get $type15
              (struct.get $type14 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type14 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (array.get $type15
                (struct.get $type14 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type14 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (array.get $type15
                  (struct.get $type14 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type14 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (array.get $type15
                    (struct.get $type14 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type14 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (array.get $type15
                      (struct.get $type14 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type14 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (array.get $type15
                        (struct.get $type14 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type14 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign1
                         (array.get $type15
                          (struct.get $type14 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type14 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign1
                           (array.get $type15
                            (struct.get $type14 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type14 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign1
                             (array.get $type15
                              (struct.get $type14 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type14 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign1
                               (array.get $type15
                                (struct.get $type14 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type14 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign1
                                 (array.get $type15
                                  (call $string-block
                                   (local.get $0)
                                   (i32.const 14)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (return_call $function42
                                 (local.get $0)
                                 (local.get $1)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $29) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (call $string-block
       (local.get $0)
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i32.and
       (local.get $5)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function49 (type $28) (param $0 (ref $type14)) (param $1 (ref $type30)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $6)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (call $foreign6
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function52 (type $25) (param $0 i64) (param $1 (ref $type30))
  (local $2 i64)
  (if
   (i64.ne
    (local.tee $2
     (i64.div_s
      (local.get $0)
      (i64.const 10)
     )
    )
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready138)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global138)
     )
    )
    (call $function52
     (local.get $2)
     (local.get $1)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (i64.sub
      (i64.const 48)
      (i64.rem_s
       (local.get $0)
       (i64.const 10)
      )
     )
    )
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $0)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $0)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (call $foreign6
   (struct.get $type31 0
    (struct.get $type30 0
     (local.get $1)
    )
   )
   (i32.wrap_i64
    (local.get $0)
   )
  )
 )
 (func $function56 (type $call53) (param $0 f64) (param $1 f64) (result f64)
  (select
   (select
    (local.get $0)
    (local.get $1)
    (f64.lt
     (local.get $0)
     (local.get $1)
    )
   )
   (local.get $0)
   (f64.eq
    (local.get $0)
    (local.get $0)
   )
  )
 )
 (func $function57 (type $call53) (param $0 f64) (param $1 f64) (result f64)
  (select
   (select
    (local.get $0)
    (local.get $1)
    (f64.gt
     (local.get $0)
     (local.get $1)
    )
   )
   (local.get $0)
   (f64.eq
    (local.get $0)
    (local.get $0)
   )
  )
 )
 (func $function62 (type $call59) (param $0 f64) (param $1 f64) (param $2 f64) (result (ref $type42))
  (local $3 f64)
  (if (result (ref $type42))
   (f64.eq
    (local.get $0)
    (f64.const 0)
   )
   (then
    (struct.new $type44
     (f64.div
      (f64.sub
       (f64.const -0)
       (local.get $2)
      )
      (local.get $1)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready161)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global161)
     )
    )
    (if (result (ref $type42))
     (f64.lt
      (local.tee $2
       (f64.sub
        (f64.mul
         (local.get $1)
         (local.get $1)
        )
        (f64.mul
         (f64.mul
          (local.get $0)
          (f64.const 4)
         )
         (local.get $2)
        )
       )
      )
      (f64.const 0)
     )
     (then
      (struct.new_default $type43)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready155)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global155)
       )
      )
      (struct.new $type44
       (select
        (select
         (local.tee $0
          (f64.div
           (f64.add
            (local.tee $1
             (f64.sub
              (f64.const -0)
              (local.get $1)
             )
            )
            (local.tee $2
             (f64.sqrt
              (local.get $2)
             )
            )
           )
           (local.tee $3
            (f64.add
             (local.get $0)
             (local.get $0)
            )
           )
          )
         )
         (local.tee $1
          (f64.div
           (f64.sub
            (local.get $1)
            (local.get $2)
           )
           (local.get $3)
          )
         )
         (f64.lt
          (local.get $0)
          (local.get $1)
         )
        )
        (local.get $0)
        (f64.eq
         (local.get $0)
         (local.get $0)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function70 (type $20) (param $0 (ref $type40)) (param $1 (ref $type40)) (param $2 i32) (param $3 i32) (param $4 (ref null $type38)) (param $5 (ref $type50)) (param $6 f64) (result (ref $type50))
  (local $7 f64)
  (local $8 (ref $type46))
  (local $9 (ref $type39))
  (local $10 (ref null $type40))
  (block $block
   (return
    (if (result (ref $type50))
     (ref.is_null
      (local.get $4)
     )
     (then
      (local.get $5)
     )
     (else
      (local.set $9
       (struct.get $type38 0
        (local.get $4)
       )
      )
      (if
       (i32.eqz
        (global.get $ready211)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global211)
       )
      )
      (local.set $10
       (local.get $1)
      )
      (if
       (i32.eqz
        (global.get $ready215)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global215)
       )
      )
      (local.set $8
       (call $function72
        (local.get $9)
        (local.get $0)
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready146)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global146)
       )
      )
      (br_if $block
       (i32.eqz
        (if (result i32)
         (ref.test (ref $type48)
          (local.get $8)
         )
         (then
          (drop
           (ref.cast (ref $type48)
            (local.get $8)
           )
          )
          (i32.const 1)
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type48)
         (local.get $8)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type48 0
        (ref.cast (ref $type48)
         (local.get $8)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready172)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (i32.eqz
        (global.get $ready163)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global163)
       )
      )
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (br_if $block
       (i32.eqz
        (f64.gt
         (local.get $6)
         (local.tee $7
          (f64.sqrt
           (f64.add
            (f64.add
             (f64.mul
              (local.tee $7
               (f64.sub
                (struct.get $type40 0
                 (local.get $1)
                )
                (struct.get $type40 0
                 (local.get $0)
                )
               )
              )
              (local.get $7)
             )
             (f64.mul
              (local.tee $7
               (f64.sub
                (struct.get $type40 1
                 (local.get $1)
                )
                (struct.get $type40 1
                 (local.get $0)
                )
               )
              )
              (local.get $7)
             )
            )
            (f64.mul
             (local.tee $7
              (f64.sub
               (struct.get $type40 2
                (local.get $1)
               )
               (struct.get $type40 2
                (local.get $0)
               )
              )
             )
             (local.get $7)
            )
           )
          )
         )
        )
       )
      )
      (local.set $4
       (struct.get $type38 1
        (local.get $4)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function70
       (local.get $0)
       (ref.as_non_null
        (local.get $10)
       )
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (struct.new $type52
        (local.get $9)
        (local.get $1)
       )
       (local.get $7)
      )
     )
    )
   )
  )
  (local.set $4
   (struct.get $type38 1
    (local.get $4)
   )
  )
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function70
   (local.get $0)
   (ref.as_non_null
    (local.get $10)
   )
   (local.get $2)
   (local.get $3)
   (local.get $4)
   (local.get $5)
   (local.get $6)
  )
 )
 (func $function72 (type $call67) (param $0 (ref $type39)) (param $1 (ref $type40)) (param $2 (ref $type40)) (result (ref $type46))
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (local $10 f64)
  (local $11 f64)
  (local $12 f64)
  (local $13 f64)
  (local $14 (ref $type42))
  (local $scratch f64)
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (local.set $14
   (call $function62
    (f64.add
     (f64.add
      (f64.mul
       (local.tee $4
        (struct.get $type40 0
         (local.get $2)
        )
       )
       (local.get $4)
      )
      (block (result f64)
       (if
        (i32.eqz
         (global.get $ready161)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global161)
        )
       )
       (local.set $scratch
        (f64.mul
         (local.tee $5
          (struct.get $type40 1
           (local.get $2)
          )
         )
         (local.get $5)
        )
       )
       (if
        (i32.eqz
         (global.get $ready161)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global161)
        )
       )
       (local.set $12
        (f64.mul
         (local.tee $6
          (struct.get $type40 2
           (local.get $2)
          )
         )
         (local.get $6)
        )
       )
       (if
        (i32.eqz
         (global.get $ready161)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global161)
        )
       )
       (local.set $7
        (f64.mul
         (local.tee $7
          (f64.sub
           (local.tee $13
            (struct.get $type40 0
             (local.get $1)
            )
           )
           (struct.get $type40 0
            (local.tee $2
             (struct.get $type39 2
              (local.get $0)
             )
            )
           )
          )
         )
         (local.get $7)
        )
       )
       (if
        (i32.eqz
         (global.get $ready161)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global161)
        )
       )
       (local.set $8
        (f64.mul
         (local.tee $8
          (f64.sub
           (struct.get $type40 1
            (local.get $1)
           )
           (struct.get $type40 1
            (local.get $2)
           )
          )
         )
         (local.get $8)
        )
       )
       (if
        (i32.eqz
         (global.get $ready161)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global161)
        )
       )
       (local.set $9
        (f64.mul
         (local.tee $9
          (f64.sub
           (struct.get $type40 2
            (local.get $1)
           )
           (struct.get $type40 2
            (local.get $2)
           )
          )
         )
         (local.get $9)
        )
       )
       (if
        (i32.eqz
         (global.get $ready161)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global161)
        )
       )
       (local.set $10
        (f64.mul
         (local.tee $10
          (struct.get $type39 1
           (local.get $0)
          )
         )
         (local.get $10)
        )
       )
       (if
        (i32.eqz
         (global.get $ready175)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global175)
        )
       )
       (local.get $scratch)
      )
     )
     (local.get $12)
    )
    (f64.mul
     (f64.add
      (f64.add
       (f64.mul
        (f64.sub
         (local.get $13)
         (struct.get $type40 0
          (local.get $2)
         )
        )
        (local.get $4)
       )
       (f64.mul
        (f64.sub
         (struct.get $type40 1
          (local.get $1)
         )
         (struct.get $type40 1
          (local.get $2)
         )
        )
        (local.get $5)
       )
      )
      (f64.mul
       (f64.sub
        (struct.get $type40 2
         (local.get $1)
        )
        (struct.get $type40 2
         (local.get $2)
        )
       )
       (local.get $6)
      )
     )
     (f64.const 2)
    )
    (f64.add
     (f64.add
      (f64.add
       (local.get $7)
       (local.get $8)
      )
      (local.get $9)
     )
     (f64.sub
      (f64.const -0)
      (local.get $10)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready142)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global142)
   )
  )
  (if (result (ref $type46))
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $14)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $14)
      )
     )
     (i32.const 1)
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $14)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type48
     (struct.new $type40
      (f64.add
       (struct.get $type40 0
        (local.get $1)
       )
       (f64.mul
        (local.tee $3
         (struct.get $type44 0
          (ref.cast (ref $type44)
           (local.get $14)
          )
         )
        )
        (local.get $4)
       )
      )
      (f64.add
       (struct.get $type40 1
        (local.get $1)
       )
       (f64.mul
        (local.get $3)
        (local.get $5)
       )
      )
      (f64.add
       (struct.get $type40 2
        (local.get $1)
       )
       (f64.mul
        (local.get $3)
        (local.get $6)
       )
      )
     )
    )
   )
   (else
    (struct.new_default $type47)
   )
  )
 )
 (func $function81 (type $12) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 (ref $type60))
  (if (result i32)
   (i64.gt_s
    (local.get $3)
    (i64.const 7)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready246)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global246)
     )
    )
    (if
     (i32.eqz
      (global.get $ready183)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type60 0
     (ref.as_non_null
      (global.get $global183)
     )
     (block (result (ref (exact $type38)))
      (if
       (i32.eqz
        (global.get $ready183)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type38
       (struct.new $type39
        (f64.const 0.75)
        (f64.const 40)
        (struct.new $type40
         (f64.mul
          (f64.convert_i64_s
           (local.get $0)
          )
          (f64.const 200)
         )
         (f64.const 300)
         (f64.mul
          (f64.convert_i64_s
           (local.get $3)
          )
          (f64.const -400)
         )
        )
       )
       (struct.get $type60 0
        (global.get $global183)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function84 (type $11) (param $0 i64) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref $type14))
  (local $5 i32)
  (local $6 i32)
  (if (result (ref $type14))
   (i64.eq
    (local.get $0)
    (local.get $4)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $6
     (call $foreign8
      (local.get $4)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.get $1)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 2
        (local.get $1)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 3
          (local.get $1)
         )
         (i32.sub
          (i32.shr_u
           (local.get $5)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $5)
      (i32.const 8191)
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function91 (type $10) (param $0 (ref $type40))
  (call $foreign11
   (struct.get $type40 0
    (local.get $0)
   )
  )
  (call $foreign11
   (struct.get $type40 1
    (local.get $0)
   )
  )
  (call $foreign11
   (struct.get $type40 2
    (local.get $0)
   )
  )
 )
 (func $function92 (type $9) (param $0 f64) (param $1 f64) (param $2 f64)
  (local $3 (ref $type42))
  (if
   (i32.eqz
    (global.get $ready175)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global175)
   )
  )
  (local.set $3
   (call $function62
    (local.get $0)
    (local.get $1)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready282)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global282)
   )
  )
  (call $foreign12
   (i64.extend_i32_u
    (i32.ne
     (if (result i32)
      (ref.test (ref $type44)
       (local.get $3)
      )
      (then
       (drop
        (ref.cast (ref $type44)
         (local.get $3)
        )
       )
       (i32.const 1)
      )
      (else
       (i32.const 0)
      )
     )
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready282)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global282)
   )
  )
  (if
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $3)
      )
     )
     (i32.const 1)
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready283)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global283)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign11
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function93 (type $8) (param $0 (ref $type39)) (param $1 (ref $type40)) (param $2 (ref $type40))
  (local $3 (ref $type46))
  (local $4 (ref $type40))
  (if
   (i32.eqz
    (global.get $ready211)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global211)
   )
  )
  (if
   (i32.eqz
    (global.get $ready215)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global215)
   )
  )
  (local.set $3
   (call $function72
    (local.get $0)
    (local.get $1)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready284)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global284)
   )
  )
  (call $foreign12
   (i64.extend_i32_u
    (i32.ne
     (if (result i32)
      (ref.test (ref $type48)
       (local.get $3)
      )
      (then
       (drop
        (ref.cast (ref $type48)
         (local.get $3)
        )
       )
       (i32.const 1)
      )
      (else
       (i32.const 0)
      )
     )
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready284)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global284)
   )
  )
  (if
   (if (result i32)
    (ref.test (ref $type48)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type48)
       (local.get $3)
      )
     )
     (i32.const 1)
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready285)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global285)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type48)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type48 0
      (ref.cast (ref $type48)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready294)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global294)
     )
    )
    (call $foreign11
     (struct.get $type40 0
      (local.get $4)
     )
    )
    (call $foreign11
     (struct.get $type40 1
      (local.get $4)
     )
    )
    (call $foreign11
     (struct.get $type40 2
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function94 (type $7) (param $0 (ref $type40)) (param $1 (ref $type40))
  (local $2 (ref $type50))
  (local $3 (ref $type40))
  (if
   (i32.eqz
    (global.get $ready202)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global202)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call $function70
    (local.get $0)
    (local.get $1)
    (i32.const 0)
    (i32.const 1)
    (struct.get $type60 0
     (global.get $global183)
    )
    (struct.new_default $type51)
    (f64.const 1.e+308)
   )
  )
  (if
   (i32.eqz
    (global.get $ready286)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global286)
   )
  )
  (call $foreign12
   (i64.extend_i32_u
    (i32.ne
     (if (result i32)
      (ref.test (ref $type52)
       (local.get $2)
      )
      (then
       (drop
        (ref.cast (ref $type52)
         (local.get $2)
        )
       )
       (i32.const 1)
      )
      (else
       (i32.const 0)
      )
     )
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready286)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global286)
   )
  )
  (if
   (if (result i32)
    (ref.test (ref $type52)
     (local.get $2)
    )
    (then
     (drop
      (ref.cast (ref $type52)
       (local.get $2)
      )
     )
     (i32.const 1)
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready287)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global287)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type52)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign11
     (struct.get $type39 0
      (struct.get $type52 0
       (ref.cast (ref $type52)
        (local.get $2)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready288)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global288)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type52)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type52 1
      (ref.cast (ref $type52)
       (local.get $2)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready294)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global294)
     )
    )
    (call $foreign11
     (struct.get $type40 0
      (local.get $3)
     )
    )
    (call $foreign11
     (struct.get $type40 1
      (local.get $3)
     )
    )
    (call $foreign11
     (struct.get $type40 2
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function96 (type $call73) (result i64)
  (local $0 (ref null $type38))
  (local $1 (ref $type39))
  (local $2 (ref $type39))
  (local $3 (ref $type39))
  (local $4 (ref $type40))
  (local $5 (ref $type40))
  (local $6 (ref $type40))
  (local $7 (ref $type30))
  (local $8 (ref $type60))
  (local $9 (ref $type14))
  (local $10 (ref $type31))
  (local $11 f64)
  (local $12 f64)
  (local $13 i32)
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (call $function92
   (f64.const 1)
   (f64.const 0)
   (f64.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (call $function92
   (f64.const 1)
   (f64.const -2)
   (f64.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (call $function92
   (f64.const 1)
   (f64.const 3)
   (f64.const 2)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (call $function92
   (f64.const 1)
   (f64.const -3)
   (f64.const 0)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (call $function92
   (f64.const 0)
   (f64.const 2)
   (f64.const -4)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (call $function92
   (f64.const 0)
   (f64.const 0)
   (f64.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (call $function92
   (f64.const 0)
   (f64.const 0)
   (f64.const 0)
  )
  (local.set $11
   (call $foreign13
    (i64.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready296)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global296)
   )
  )
  (call $function92
   (f64.const 1)
   (local.get $11)
   (f64.const 0)
  )
  (local.set $11
   (call $foreign13
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (if
   (i32.eqz
    (global.get $ready289)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (f64.const 0)
    (local.get $11)
    (struct.get $type53 0
     (global.get $global289)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready290)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (f64.const 0)
    (local.get $11)
    (struct.get $type53 0
     (global.get $global290)
    )
   )
  )
  (local.set $11
   (call $foreign13
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (if
   (i32.eqz
    (global.get $ready289)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (local.get $11)
    (f64.const 0)
    (struct.get $type53 0
     (global.get $global289)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready290)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (local.get $11)
    (f64.const 0)
    (struct.get $type53 0
     (global.get $global290)
    )
   )
  )
  (local.set $11
   (call $foreign13
    (i64.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (if
   (i32.eqz
    (global.get $ready289)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (local.get $11)
    (f64.const 1)
    (struct.get $type53 0
     (global.get $global289)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready290)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (local.get $11)
    (f64.const 1)
    (struct.get $type53 0
     (global.get $global290)
    )
   )
  )
  (local.set $11
   (call $foreign13
    (i64.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (if
   (i32.eqz
    (global.get $ready289)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (f64.const 1)
    (local.get $11)
    (struct.get $type53 0
     (global.get $global289)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready290)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (f64.const 1)
    (local.get $11)
    (struct.get $type53 0
     (global.get $global290)
    )
   )
  )
  (local.set $11
   (call $foreign13
    (i64.const 2)
   )
  )
  (local.set $12
   (call $foreign13
    (i64.const 3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready310)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global310)
   )
  )
  (if
   (i32.eqz
    (global.get $ready289)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (local.get $11)
    (local.get $12)
    (struct.get $type53 0
     (global.get $global289)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready290)
   )
   (then
    (unreachable)
   )
  )
  (call $foreign11
   (call_ref $call53
    (local.get $11)
    (local.get $12)
    (struct.get $type53 0
     (global.get $global290)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready301)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global301)
   )
  )
  (call $function93
   (local.tee $3
    (struct.new $type39
     (f64.const 0.25)
     (f64.const 1)
     (struct.new $type40
      (f64.const 0)
      (f64.const 0)
      (f64.const 10)
     )
    )
   )
   (local.tee $5
    (struct.new_default $type40)
   )
   (local.tee $6
    (struct.new $type40
     (f64.const 0)
     (f64.const 0)
     (f64.const -1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready301)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global301)
   )
  )
  (call $function93
   (struct.new $type39
    (f64.const 0.5)
    (f64.const 1)
    (struct.new $type40
     (f64.const 1)
     (f64.const 0)
     (f64.const -10)
    )
   )
   (local.get $5)
   (local.get $6)
  )
  (if
   (i32.eqz
    (global.get $ready301)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global301)
   )
  )
  (call $function93
   (local.tee $2
    (struct.new $type39
     (f64.const 0.5)
     (f64.const 1)
     (struct.new $type40
      (f64.const 0)
      (f64.const 0)
      (f64.const -10)
     )
    )
   )
   (local.get $5)
   (struct.new $type40
    (f64.const 1)
    (f64.const 0)
    (f64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (global.get $global183)
   (ref.null none)
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (call $function94
   (local.get $5)
   (local.get $6)
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (global.get $global183)
   (struct.new $type38
    (local.get $3)
    (ref.null none)
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (call $function94
   (local.get $5)
   (local.get $6)
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (global.get $global183)
   (struct.new $type38
    (local.get $2)
    (struct.new $type38
     (local.tee $3
      (struct.new $type39
       (f64.const 0.75)
       (f64.const 1)
       (struct.new $type40
        (f64.const 0)
        (f64.const 0)
        (f64.const -10)
       )
      )
     )
     (ref.null none)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (call $function94
   (local.get $5)
   (local.get $6)
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (global.get $global183)
   (struct.new $type38
    (local.get $3)
    (struct.new $type38
     (local.get $2)
     (ref.null none)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (call $function94
   (local.get $5)
   (local.get $6)
  )
  (local.set $2
   (struct.new $type39
    (f64.const 0.5)
    (f64.const 1)
    (struct.new $type40
     (f64.const 0)
     (f64.const 0)
     (call $foreign13
      (i64.const 1)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (global.get $global183)
   (struct.new $type38
    (local.get $2)
    (ref.null none)
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (call $function94
   (local.get $5)
   (local.get $6)
  )
  (if
   (i32.eqz
    (global.get $ready291)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global291)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (global.get $global183)
   (struct.new $type38
    (struct.new $type39
     (f64.const 0.5)
     (f64.const 0)
     (struct.new $type40
      (f64.const 0)
      (f64.const 0)
      (f64.const 1.e+308)
     )
    )
    (ref.null none)
   )
  )
  (if
   (i32.eqz
    (global.get $ready306)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global306)
   )
  )
  (call $function94
   (local.get $5)
   (local.get $6)
  )
  (if
   (i32.eqz
    (global.get $ready232)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global232)
   )
  )
  (if
   (i32.eqz
    (global.get $ready235)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global235)
   )
  )
  (if
   (i32.eqz
    (global.get $ready167)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready294)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global294)
   )
  )
  (call $foreign11
   (f64.const 0)
  )
  (call $foreign11
   (f64.const 0)
  )
  (call $foreign11
   (f64.const -1)
  )
  (if
   (i32.eqz
    (global.get $ready227)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global227)
   )
  )
  (if
   (i32.eqz
    (global.get $ready232)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global232)
   )
  )
  (if
   (i32.eqz
    (global.get $ready235)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global235)
   )
  )
  (if
   (i32.eqz
    (global.get $ready167)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global167)
   )
  )
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (call $foreign11
   (f64.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready253)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global253)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (global.get $global183)
   (ref.null none)
  )
  (if
   (i32.eqz
    (global.get $ready246)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (ref.as_non_null
    (global.get $global183)
   )
   (block (result (ref (exact $type38)))
    (if
     (i32.eqz
      (global.get $ready183)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type38
     (struct.new $type39
      (f64.const 0.8)
      (f64.const 200)
      (struct.new $type40
       (f64.const 0)
       (f64.const -300)
       (f64.const -1200)
      )
     )
     (struct.get $type60 0
      (global.get $global183)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready246)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (ref.as_non_null
    (global.get $global183)
   )
   (block (result (ref (exact $type38)))
    (if
     (i32.eqz
      (global.get $ready183)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type38
     (struct.new $type39
      (f64.const 0.7)
      (f64.const 200)
      (struct.new $type40
       (f64.const -80)
       (f64.const -150)
       (f64.const -1200)
      )
     )
     (struct.get $type60 0
      (global.get $global183)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready246)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type60 0
   (ref.as_non_null
    (global.get $global183)
   )
   (block (result (ref (exact $type38)))
    (if
     (i32.eqz
      (global.get $ready183)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type38
     (struct.new $type39
      (f64.const 0.9)
      (f64.const 200)
      (struct.new $type40
       (f64.const 70)
       (f64.const -100)
       (f64.const -1200)
      )
     )
     (struct.get $type60 0
      (global.get $global183)
     )
    )
   )
  )
  (drop
   (call $function81
    (i64.const -2)
    (i32.const 0)
    (i32.const 1)
    (i64.const 2)
   )
  )
  (drop
   (call $function81
    (i64.const -1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 2)
   )
  )
  (drop
   (call $function81
    (i64.const 0)
    (i32.const 0)
    (i32.const 1)
    (i64.const 2)
   )
  )
  (drop
   (call $function81
    (i64.const 1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 2)
   )
  )
  (drop
   (call $function81
    (i64.const 2)
    (i32.const 0)
    (i32.const 1)
    (i64.const 2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready185)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global185)
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (local.tee $9
     (global.get $string3)
    )
   )
  )
  (if
   (i32.eq
    (call $foreign2)
    (i32.const 1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready116)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (call $function41
      (local.get $9)
     )
    )
    (call $foreign3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready241)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global241)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (local.get $9)
   )
  )
  (local.set $7
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string2)
    (local.get $7)
    (i64.const 3)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (call $function52
   (i64.const 0)
   (local.get $7)
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string1)
    (local.get $7)
    (i64.const 1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (call $function52
   (i64.const 0)
   (local.get $7)
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string0)
    (local.get $7)
    (i64.const 4)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (call $foreign6
   (struct.get $type31 0
    (struct.get $type30 0
     (local.get $7)
    )
   )
   (i32.const 10)
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $13
     (struct.get $type31 0
      (local.tee $10
       (struct.get $type30 0
        (local.get $7)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $10)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $13)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready293)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global293)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (struct.get $type60 0
    (global.get $global183)
   )
  )
  (if
   (i32.eqz
    (global.get $ready321)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global321)
   )
  )
  (call $foreign12
   (if (result i64)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i64.const 0)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $0
        (struct.get $type38 1
         (local.get $0)
        )
       )
      )
      (then
       (i64.const 1)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $0
          (struct.get $type38 1
           (local.get $0)
          )
         )
        )
        (then
         (i64.const 2)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $0
            (struct.get $type38 1
             (local.get $0)
            )
           )
          )
          (then
           (i64.const 3)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $0
              (struct.get $type38 1
               (local.get $0)
              )
             )
            )
            (then
             (i64.const 4)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $0
                (struct.get $type38 1
                 (local.get $0)
                )
               )
              )
              (then
               (i64.const 5)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $0
                  (struct.get $type38 1
                   (local.get $0)
                  )
                 )
                )
                (then
                 (i64.const 6)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $0
                    (struct.get $type38 1
                     (local.get $0)
                    )
                   )
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $0
                      (struct.get $type38 1
                       (local.get $0)
                      )
                     )
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $0
                        (struct.get $type38 1
                         (local.get $0)
                        )
                       )
                      )
                      (then
                       (i64.const 9)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $0
                          (struct.get $type38 1
                           (local.get $0)
                          )
                         )
                        )
                        (then
                         (i64.const 10)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $0
                            (struct.get $type38 1
                             (local.get $0)
                            )
                           )
                          )
                          (then
                           (i64.const 11)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $0
                              (struct.get $type38 1
                               (local.get $0)
                              )
                             )
                            )
                            (then
                             (i64.const 12)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $0
                                (struct.get $type38 1
                                 (local.get $0)
                                )
                               )
                              )
                              (then
                               (i64.const 13)
                              )
                              (else
                               (call $function98
                                (i32.const 0)
                                (i32.const 1)
                                (struct.get $type38 1
                                 (local.get $0)
                                )
                                (i64.const 14)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready293)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global293)
   )
  )
  (if
   (i32.eqz
    (global.get $ready183)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.tee $0
      (struct.get $type60 0
       (global.get $global183)
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (call $foreign11
      (struct.get $type39 0
       (local.tee $1
        (struct.get $type38 0
         (local.get $0)
        )
       )
      )
     )
     (call $foreign11
      (struct.get $type39 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready294)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global294)
      )
     )
     (call $foreign11
      (struct.get $type40 0
       (local.tee $4
        (struct.get $type39 2
         (local.get $1)
        )
       )
      )
     )
     (call $foreign11
      (struct.get $type40 1
       (local.get $4)
      )
     )
     (call $foreign11
      (struct.get $type40 2
       (local.get $4)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.tee $0
        (struct.get $type38 1
         (local.get $0)
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (call $foreign11
        (struct.get $type39 0
         (local.tee $1
          (struct.get $type38 0
           (local.get $0)
          )
         )
        )
       )
       (call $foreign11
        (struct.get $type39 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready294)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global294)
        )
       )
       (call $foreign11
        (struct.get $type40 0
         (local.tee $4
          (struct.get $type39 2
           (local.get $1)
          )
         )
        )
       )
       (call $foreign11
        (struct.get $type40 1
         (local.get $4)
        )
       )
       (call $foreign11
        (struct.get $type40 2
         (local.get $4)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.tee $0
          (struct.get $type38 1
           (local.get $0)
          )
         )
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign11
          (struct.get $type39 0
           (local.tee $1
            (struct.get $type38 0
             (local.get $0)
            )
           )
          )
         )
         (call $foreign11
          (struct.get $type39 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready294)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global294)
          )
         )
         (call $foreign11
          (struct.get $type40 0
           (local.tee $4
            (struct.get $type39 2
             (local.get $1)
            )
           )
          )
         )
         (call $foreign11
          (struct.get $type40 1
           (local.get $4)
          )
         )
         (call $foreign11
          (struct.get $type40 2
           (local.get $4)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.tee $0
            (struct.get $type38 1
             (local.get $0)
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign11
            (struct.get $type39 0
             (local.tee $1
              (struct.get $type38 0
               (local.get $0)
              )
             )
            )
           )
           (call $foreign11
            (struct.get $type39 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready294)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global294)
            )
           )
           (call $foreign11
            (struct.get $type40 0
             (local.tee $4
              (struct.get $type39 2
               (local.get $1)
              )
             )
            )
           )
           (call $foreign11
            (struct.get $type40 1
             (local.get $4)
            )
           )
           (call $foreign11
            (struct.get $type40 2
             (local.get $4)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.tee $0
              (struct.get $type38 1
               (local.get $0)
              )
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign11
              (struct.get $type39 0
               (local.tee $1
                (struct.get $type38 0
                 (local.get $0)
                )
               )
              )
             )
             (call $foreign11
              (struct.get $type39 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready294)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global294)
              )
             )
             (call $foreign11
              (struct.get $type40 0
               (local.tee $4
                (struct.get $type39 2
                 (local.get $1)
                )
               )
              )
             )
             (call $foreign11
              (struct.get $type40 1
               (local.get $4)
              )
             )
             (call $foreign11
              (struct.get $type40 2
               (local.get $4)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.tee $0
                (struct.get $type38 1
                 (local.get $0)
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign11
                (struct.get $type39 0
                 (local.tee $1
                  (struct.get $type38 0
                   (local.get $0)
                  )
                 )
                )
               )
               (call $foreign11
                (struct.get $type39 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready294)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global294)
                )
               )
               (call $foreign11
                (struct.get $type40 0
                 (local.tee $4
                  (struct.get $type39 2
                   (local.get $1)
                  )
                 )
                )
               )
               (call $foreign11
                (struct.get $type40 1
                 (local.get $4)
                )
               )
               (call $foreign11
                (struct.get $type40 2
                 (local.get $4)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.tee $0
                  (struct.get $type38 1
                   (local.get $0)
                  )
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign11
                  (struct.get $type39 0
                   (local.tee $1
                    (struct.get $type38 0
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (call $foreign11
                  (struct.get $type39 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready294)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global294)
                  )
                 )
                 (call $foreign11
                  (struct.get $type40 0
                   (local.tee $4
                    (struct.get $type39 2
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (call $foreign11
                  (struct.get $type40 1
                   (local.get $4)
                  )
                 )
                 (call $foreign11
                  (struct.get $type40 2
                   (local.get $4)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.tee $0
                    (struct.get $type38 1
                     (local.get $0)
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign11
                    (struct.get $type39 0
                     (local.tee $1
                      (struct.get $type38 0
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (call $foreign11
                    (struct.get $type39 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready294)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global294)
                    )
                   )
                   (call $foreign11
                    (struct.get $type40 0
                     (local.tee $4
                      (struct.get $type39 2
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (call $foreign11
                    (struct.get $type40 1
                     (local.get $4)
                    )
                   )
                   (call $foreign11
                    (struct.get $type40 2
                     (local.get $4)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.tee $0
                      (struct.get $type38 1
                       (local.get $0)
                      )
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign11
                      (struct.get $type39 0
                       (local.tee $1
                        (struct.get $type38 0
                         (local.get $0)
                        )
                       )
                      )
                     )
                     (call $foreign11
                      (struct.get $type39 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready294)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global294)
                      )
                     )
                     (call $foreign11
                      (struct.get $type40 0
                       (local.tee $4
                        (struct.get $type39 2
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (call $foreign11
                      (struct.get $type40 1
                       (local.get $4)
                      )
                     )
                     (call $foreign11
                      (struct.get $type40 2
                       (local.get $4)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.tee $0
                        (struct.get $type38 1
                         (local.get $0)
                        )
                       )
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign11
                        (struct.get $type39 0
                         (local.tee $1
                          (struct.get $type38 0
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (call $foreign11
                        (struct.get $type39 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready294)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global294)
                        )
                       )
                       (call $foreign11
                        (struct.get $type40 0
                         (local.tee $4
                          (struct.get $type39 2
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (call $foreign11
                        (struct.get $type40 1
                         (local.get $4)
                        )
                       )
                       (call $foreign11
                        (struct.get $type40 2
                         (local.get $4)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.tee $0
                          (struct.get $type38 1
                           (local.get $0)
                          )
                         )
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (call $foreign11
                          (struct.get $type39 0
                           (local.tee $1
                            (struct.get $type38 0
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (call $foreign11
                          (struct.get $type39 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready294)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global294)
                          )
                         )
                         (call $foreign11
                          (struct.get $type40 0
                           (local.tee $4
                            (struct.get $type39 2
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (call $foreign11
                          (struct.get $type40 1
                           (local.get $4)
                          )
                         )
                         (call $foreign11
                          (struct.get $type40 2
                           (local.get $4)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.tee $0
                            (struct.get $type38 1
                             (local.get $0)
                            )
                           )
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (call $foreign11
                            (struct.get $type39 0
                             (local.tee $1
                              (struct.get $type38 0
                               (local.get $0)
                              )
                             )
                            )
                           )
                           (call $foreign11
                            (struct.get $type39 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready294)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global294)
                            )
                           )
                           (call $foreign11
                            (struct.get $type40 0
                             (local.tee $4
                              (struct.get $type39 2
                               (local.get $1)
                              )
                             )
                            )
                           )
                           (call $foreign11
                            (struct.get $type40 1
                             (local.get $4)
                            )
                           )
                           (call $foreign11
                            (struct.get $type40 2
                             (local.get $4)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.tee $0
                              (struct.get $type38 1
                               (local.get $0)
                              )
                             )
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (call $foreign11
                              (struct.get $type39 0
                               (local.tee $1
                                (struct.get $type38 0
                                 (local.get $0)
                                )
                               )
                              )
                             )
                             (call $foreign11
                              (struct.get $type39 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready294)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global294)
                              )
                             )
                             (call $foreign11
                              (struct.get $type40 0
                               (local.tee $4
                                (struct.get $type39 2
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (call $foreign11
                              (struct.get $type40 1
                               (local.get $4)
                              )
                             )
                             (call $foreign11
                              (struct.get $type40 2
                               (local.get $4)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.tee $0
                                (struct.get $type38 1
                                 (local.get $0)
                                )
                               )
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (call $foreign11
                                (struct.get $type39 0
                                 (local.tee $1
                                  (struct.get $type38 0
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                               (call $foreign11
                                (struct.get $type39 1
                                 (local.get $1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready294)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global294)
                                )
                               )
                               (call $foreign11
                                (struct.get $type40 0
                                 (local.tee $4
                                  (struct.get $type39 2
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (call $foreign11
                                (struct.get $type40 1
                                 (local.get $4)
                                )
                               )
                               (call $foreign11
                                (struct.get $type40 2
                                 (local.get $4)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.tee $0
                                  (struct.get $type38 1
                                   (local.get $0)
                                  )
                                 )
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (call $foreign11
                                  (struct.get $type39 0
                                   (local.tee $1
                                    (struct.get $type38 0
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                 (call $foreign11
                                  (struct.get $type39 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready294)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global294)
                                  )
                                 )
                                 (call $function91
                                  (struct.get $type39 2
                                   (local.get $1)
                                  )
                                 )
                                 (call $function99
                                  (i32.const 0)
                                  (i32.const 1)
                                  (struct.get $type38 1
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (i64.const 1)
 )
 (func $function98 (type $4) (param $0 i32) (param $1 i32) (param $2 (ref null $type38)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type38 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function98
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function99 (type $3) (param $0 i32) (param $1 i32) (param $2 (ref null $type38)) (result i32)
  (local $3 (ref $type39))
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $foreign11
     (struct.get $type39 0
      (local.tee $3
       (struct.get $type38 0
        (local.get $2)
       )
      )
     )
    )
    (call $foreign11
     (struct.get $type39 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (global.get $ready294)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global294)
     )
    )
    (call $function91
     (struct.get $type39 2
      (local.get $3)
     )
    )
    (local.set $2
     (struct.get $type38 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function99
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready313)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global313)
   )
  )
  (return_call $function96)
 )
 (func $main
  (local $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i64)
  (local $6 (ref null $type16))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type27)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global114
   (struct.new_default $type28)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type27)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type29)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type32)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global241
   (struct.new_default $type33)
  )
  (global.set $ready241
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type34)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type35)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type32)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type36)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global138
   (struct.new_default $type36)
  )
  (global.set $ready138
   (i32.const 1)
  )
  (global.set $global321
   (struct.new_default $type37)
  )
  (global.set $ready321
   (i32.const 1)
  )
  (global.set $global142
   (struct.new_default $type41)
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global146
   (struct.new_default $type45)
  )
  (global.set $ready146
   (i32.const 1)
  )
  (global.set $global150
   (struct.new_default $type49)
  )
  (global.set $ready150
   (i32.const 1)
  )
  (global.set $global155
   (struct.new $type53
    (ref.func $function56)
   )
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global158
   (struct.new $type53
    (ref.func $function57)
   )
  )
  (global.set $ready158
   (i32.const 1)
  )
  (global.set $global161
   (struct.new_default $type55)
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global163
   (struct.new_default $type56)
  )
  (global.set $ready163
   (i32.const 1)
  )
  (global.set $global167
   (struct.new_default $type57)
  )
  (global.set $ready167
   (i32.const 1)
  )
  (global.set $global172
   (struct.new_default $type58)
  )
  (global.set $ready172
   (i32.const 1)
  )
  (global.set $global175
   (struct.new_default $type59)
  )
  (global.set $ready175
   (i32.const 1)
  )
  (global.set $global183
   (struct.new_default $type60)
  )
  (global.set $ready183
   (i32.const 1)
  )
  (global.set $global185
   (struct.new_default $type61)
  )
  (global.set $ready185
   (i32.const 1)
  )
  (global.set $global202
   (struct.new_default $type63)
  )
  (global.set $ready202
   (i32.const 1)
  )
  (global.set $global227
   (struct.new_default $type64)
  )
  (global.set $ready227
   (i32.const 1)
  )
  (global.set $global246
   (struct.new_default $type65)
  )
  (global.set $ready246
   (i32.const 1)
  )
  (global.set $global211
   (struct.new_default $type67)
  )
  (global.set $ready211
   (i32.const 1)
  )
  (global.set $global215
   (struct.new_default $type67)
  )
  (global.set $ready215
   (i32.const 1)
  )
  (global.set $global232
   (struct.new_default $type68)
  )
  (global.set $ready232
   (i32.const 1)
  )
  (global.set $global235
   (struct.new_default $type68)
  )
  (global.set $ready235
   (i32.const 1)
  )
  (global.set $global253
   (struct.new_default $type69)
  )
  (global.set $ready253
   (i32.const 1)
  )
  (global.set $global263
   (struct.new_default $type71)
  )
  (global.set $ready263
   (i32.const 1)
  )
  (drop
   (call $foreign14
    (i32.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready263)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global263)
   )
  )
  (if
   (i64.gt_u
    (local.tee $5
     (call $foreign7)
    )
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (if
   (local.tee $1
    (i32.sub
     (local.tee $0
      (i32.wrap_i64
       (local.get $5)
      )
     )
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $6
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $6)
      (local.get $2)
      (array.new $type15
       (i32.const 32)
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (drop
   (call $function84
    (local.get $5)
    (struct.new $type14
     (i32.const 1)
     (local.get $0)
     (array.new $type15
      (i32.const 32)
      (local.get $3)
     )
     (local.get $6)
    )
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (drop
   (call $foreign14
    (i32.const 1)
   )
  )
  (if
   (i32.eqz
    (global.get $ready142)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global282
   (ref.as_non_null
    (global.get $global142)
   )
  )
  (global.set $ready282
   (i32.const 1)
  )
  (global.set $global283
   (struct.new_default $type74)
  )
  (global.set $ready283
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready146)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global284
   (ref.as_non_null
    (global.get $global146)
   )
  )
  (global.set $ready284
   (i32.const 1)
  )
  (global.set $global285
   (struct.new_default $type75)
  )
  (global.set $ready285
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready150)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global286
   (ref.as_non_null
    (global.get $global150)
   )
  )
  (global.set $ready286
   (i32.const 1)
  )
  (global.set $global287
   (struct.new_default $type76)
  )
  (global.set $ready287
   (i32.const 1)
  )
  (global.set $global288
   (struct.new_default $type77)
  )
  (global.set $ready288
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready155)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global289
   (ref.as_non_null
    (global.get $global155)
   )
  )
  (global.set $ready289
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready158)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global290
   (ref.as_non_null
    (global.get $global158)
   )
  )
  (global.set $ready290
   (i32.const 1)
  )
  (global.set $global291
   (struct.new_default $type78)
  )
  (global.set $ready291
   (i32.const 1)
  )
  (global.set $global293
   (struct.new_default $type79)
  )
  (global.set $ready293
   (i32.const 1)
  )
  (global.set $global294
   (struct.new_default $type80)
  )
  (global.set $ready294
   (i32.const 1)
  )
  (global.set $global296
   (struct.new_default $type81)
  )
  (global.set $ready296
   (i32.const 1)
  )
  (global.set $global301
   (struct.new_default $type82)
  )
  (global.set $ready301
   (i32.const 1)
  )
  (global.set $global306
   (struct.new_default $type83)
  )
  (global.set $ready306
   (i32.const 1)
  )
  (global.set $global310
   (struct.new_default $type84)
  )
  (global.set $ready310
   (i32.const 1)
  )
  (global.set $global313
   (struct.new_default $type73)
  )
  (global.set $ready313
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

