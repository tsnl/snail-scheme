import fs from 'node:fs';
import assert from 'node:assert/strict';
import {WASI} from 'node:wasi';
const module = new WebAssembly.Module(fs.readFileSync(process.argv[2]));
const wasi = new WASI({version:'preview1',args:[],env:{},preopens:{'.':process.cwd()},returnOnExit:true});
const values = [], bytes = new DataView(new ArrayBuffer(8));
const instance = new WebAssembly.Instance(module, {
  wasi_snapshot_preview1:wasi.wasiImport,
  benchmark:{input_i64:()=>1n,hide_i64:x=>x,barrier:()=>1,path_length:()=>0n,path_character:()=>32},
  probe:{i64:value=>values.push(value.toString()), float:index=>[-0,NaN,Infinity,-Infinity][Number(index)],
    f64:value=>{bytes.setFloat64(0,value,true);values.push(Number.isNaN(value)?'NaN':bytes.getBigUint64(0,true).toString());}}});
let failure;
try {wasi.initialize(instance);instance.exports.main();assert.equal(instance.exports['geometry-probe'](0n),1n);}
catch(error){failure=error;}
finally {try{assert.equal(instance.exports['close-resources'](),0);}catch(error){failure??=error;}}
if(failure)throw failure;
console.log(values.join('\n'));
