(module
 (rec
  (type $type42 (sub (struct)))
  (type $type38 (sub (struct)))
  (type $type47 (sub (struct)))
  (type $3 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $4 (func (param i64 (ref $type14) i32 i32 i64) (result (ref $type14))))
  (type $5 (func (param i64 i32 i32 i64) (result i32)))
  (type $type43 (sub $type42 (struct)))
  (type $type44 (sub $type42 (struct (field (ref $type45)))))
  (type $type39 (sub $type38 (struct)))
  (type $type40 (sub $type38 (struct (field f64))))
  (type $type59 (struct (field (ref $type50)) (field (ref null $type59))))
  (type $11 (func (param (ref $type45) (ref $type45) i32 i32 (ref null $type59) (ref $type47) f64) (result (ref $type47))))
  (type $type48 (sub $type47 (struct)))
  (type $type50 (struct (field f64) (field f64) (field (ref $type45))))
  (type $type49 (sub $type47 (struct (field (ref $type50)) (field (ref $type45)))))
  (type $15 (func (param i64 (ref $type30) i64 i64 i32 i32 i64) (result i32)))
  (type $16 (func (param i64 (ref $type30) i64 i32 i32 i64) (result i32)))
  (type $call60 (func (param (ref $type14) i64) (result i32)))
  (type $call55 (func (param f64 f64 f64) (result (ref $type45))))
  (type $19 (func (param i64 (ref $type30))))
  (type $type31 (struct (field (mut i32))))
  (type $type30 (struct (field (ref $type31))))
  (type $22 (func (param (ref $type14) (ref $type30) i64 i32 i32 i64) (result i32)))
  (type $23 (func (param (ref $type14) i64 i32 i32 i64) (result i32)))
  (type $call27 (func (param (ref $type14)) (result i32)))
  (type $type16 (array (mut (ref null $type15))))
  (type $26 (func (param (ref $type14) i32) (result (ref $type15))))
  (type $type72 (struct))
  (type $type71 (struct))
  (type $type70 (struct))
  (type $type69 (struct))
  (type $type68 (struct))
  (type $type67 (struct))
  (type $type66 (struct))
  (type $type65 (struct))
  (type $type64 (struct))
  (type $type63 (struct))
  (type $type62 (struct))
  (type $type61 (struct))
  (type $type60 (struct))
  (type $type45 (struct (field f64) (field f64) (field f64)))
  (type $type58 (struct (field (mut (ref null $type59)))))
  (type $type57 (struct))
  (type $type56 (struct))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type46 (struct))
  (type $type41 (struct))
  (type $type37 (struct))
  (type $type36 (struct))
  (type $type35 (struct))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type14 (struct (field i32) (field i32) (field (ref $type15)) (field (ref null $type16))))
  (type $type15 (array (mut i32)))
 )
 (type $62 (func))
 (type $63 (func (result i32)))
 (type $64 (func (param i32)))
 (type $65 (func (param i64) (result i64)))
 (type $66 (func (param i32 i32)))
 (type $67 (func (result i64)))
 (type $68 (func (param i64) (result i32)))
 (type $69 (func (param i32) (result i64)))
 (type $70 (func (param (ref $type14) i64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/file-exists" (func $foreign2 (result i32)))
 (import "snail.library" "snail:io/delete-file" (func $foreign3))
 (import "snail.library" "snail:io/open-output-file" (func $foreign4 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign5 (param i32)))
 (import "snail.library" "snail:io/write-character" (func $foreign6 (param i32 i32)))
 (import "benchmark" "path_length" (func $foreign7 (result i64)))
 (import "benchmark" "path_character" (func $foreign8 (param i64) (result i32)))
 (import "benchmark" "barrier" (func $foreign9 (result i32)))
 (import "benchmark" "hide_i64" (func $foreign10 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign11 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type15 4
   (i32.const 32)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type15 1
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type14) (struct.new $type14
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type15 3
   (i32.const 80)
   (i32.const 50)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $global109 (mut (ref null $type27)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type28)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type29)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type32)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global242 (mut (ref null $type33)) (ref.null none))
 (global $ready242 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type34)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type35)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global133 (mut (ref null $type32)) (ref.null none))
 (global $ready133 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type36)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global138 (mut (ref null $type36)) (ref.null none))
 (global $ready138 (mut i32) (i32.const 0))
 (global $global142 (mut (ref null $type37)) (ref.null none))
 (global $ready142 (mut i32) (i32.const 0))
 (global $global146 (mut (ref null $type41)) (ref.null none))
 (global $ready146 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type46)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type51)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global158 (mut (ref null $type51)) (ref.null none))
 (global $ready158 (mut i32) (i32.const 0))
 (global $global280 (mut (ref null $type52)) (ref.null none))
 (global $ready280 (mut i32) (i32.const 0))
 (global $global161 (mut (ref null $type53)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global163 (mut (ref null $type54)) (ref.null none))
 (global $ready163 (mut i32) (i32.const 0))
 (global $global167 (mut (ref null $type55)) (ref.null none))
 (global $ready167 (mut i32) (i32.const 0))
 (global $global172 (mut (ref null $type56)) (ref.null none))
 (global $ready172 (mut i32) (i32.const 0))
 (global $global175 (mut (ref null $type57)) (ref.null none))
 (global $ready175 (mut i32) (i32.const 0))
 (global $global183 (mut (ref null $type58)) (ref.null none))
 (global $ready183 (mut i32) (i32.const 0))
 (global $global184 (mut (ref null $type45)) (ref.null none))
 (global $ready184 (mut i32) (i32.const 0))
 (global $global185 (mut (ref null $type60)) (ref.null none))
 (global $ready185 (mut i32) (i32.const 0))
 (global $global195 (mut (ref null $type61)) (ref.null none))
 (global $ready195 (mut i32) (i32.const 0))
 (global $global199 (mut (ref null $type56)) (ref.null none))
 (global $ready199 (mut i32) (i32.const 0))
 (global $global203 (mut (ref null $type62)) (ref.null none))
 (global $ready203 (mut i32) (i32.const 0))
 (global $global228 (mut (ref null $type63)) (ref.null none))
 (global $ready228 (mut i32) (i32.const 0))
 (global $global247 (mut (ref null $type64)) (ref.null none))
 (global $ready247 (mut i32) (i32.const 0))
 (global $global240 (mut (ref null $type65)) (ref.null none))
 (global $ready240 (mut i32) (i32.const 0))
 (global $global212 (mut (ref null $type66)) (ref.null none))
 (global $ready212 (mut i32) (i32.const 0))
 (global $global216 (mut (ref null $type66)) (ref.null none))
 (global $ready216 (mut i32) (i32.const 0))
 (global $global233 (mut (ref null $type67)) (ref.null none))
 (global $ready233 (mut i32) (i32.const 0))
 (global $global236 (mut (ref null $type67)) (ref.null none))
 (global $ready236 (mut i32) (i32.const 0))
 (global $global254 (mut (ref null $type68)) (ref.null none))
 (global $ready254 (mut i32) (i32.const 0))
 (global $global261 (mut (ref null $type69)) (ref.null none))
 (global $ready261 (mut i32) (i32.const 0))
 (global $global264 (mut (ref null $type70)) (ref.null none))
 (global $ready264 (mut i32) (i32.const 0))
 (global $global190 (mut i64) (i64.const 0))
 (global $ready190 (mut i32) (i32.const 0))
 (global $global269 (mut i64) (i64.const 0))
 (global $ready269 (mut i32) (i32.const 0))
 (global $global270 (mut (ref null $type14)) (ref.null none))
 (global $ready270 (mut i32) (i32.const 0))
 (global $global271 (mut i64) (i64.const 0))
 (global $ready271 (mut i32) (i32.const 0))
 (global $global272 (mut (ref null $type71)) (ref.null none))
 (global $ready272 (mut i32) (i32.const 0))
 (global $global275 (mut (ref null $type72)) (ref.null none))
 (global $ready275 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $string-block (type $26) (param $0 (ref $type14)) (param $1 i32) (result (ref $type15))
  (if (result (ref $type15))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type14 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type16
      (struct.get $type14 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function41 (type $call27) (param $0 (ref $type14)) (result i32)
  (local $1 i64)
  (call $foreign0)
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_u
      (struct.get $type14 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (struct.get $type14 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type14 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (array.get $type15
        (struct.get $type14 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type14 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (array.get $type15
          (struct.get $type14 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type14 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (array.get $type15
            (struct.get $type14 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type14 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (array.get $type15
              (struct.get $type14 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type14 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (array.get $type15
                (struct.get $type14 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type14 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (array.get $type15
                  (struct.get $type14 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type14 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (array.get $type15
                    (struct.get $type14 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type14 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (array.get $type15
                      (struct.get $type14 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type14 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (array.get $type15
                        (struct.get $type14 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type14 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign1
                         (array.get $type15
                          (struct.get $type14 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type14 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign1
                           (array.get $type15
                            (struct.get $type14 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type14 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign1
                             (array.get $type15
                              (struct.get $type14 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type14 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign1
                               (array.get $type15
                                (struct.get $type14 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type14 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign1
                                 (array.get $type15
                                  (call $string-block
                                   (local.get $0)
                                   (i32.const 14)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (return_call $function42
                                 (local.get $0)
                                 (local.get $1)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 15)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $23) (param $0 (ref $type14)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type15
      (call $string-block
       (local.get $0)
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i32.and
       (local.get $5)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function49 (type $22) (param $0 (ref $type14)) (param $1 (ref $type30)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (array.get $type15
      (if (result (ref $type15))
       (i32.lt_u
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.const 8192)
       )
       (then
        (struct.get $type14 2
         (local.get $0)
        )
       )
       (else
        (ref.as_non_null
         (array.get $type16
          (struct.get $type14 3
           (local.get $0)
          )
          (i32.sub
           (i32.shr_u
            (local.get $6)
            (i32.const 13)
           )
           (i32.const 1)
          )
         )
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (call $foreign6
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function49
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function52 (type $19) (param $0 i64) (param $1 (ref $type30))
  (local $2 i64)
  (if
   (i64.ne
    (local.tee $2
     (i64.div_s
      (local.get $0)
      (i64.const 10)
     )
    )
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready138)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global138)
     )
    )
    (call $function52
     (local.get $2)
     (local.get $1)
    )
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (i64.sub
      (i64.const 48)
      (i64.rem_s
       (local.get $0)
       (i64.const 10)
      )
     )
    )
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $0)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $0)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (call $foreign6
   (struct.get $type31 0
    (struct.get $type30 0
     (local.get $1)
    )
   )
   (i32.wrap_i64
    (local.get $0)
   )
  )
 )
 (func $function60 (type $call55) (param $0 f64) (param $1 f64) (param $2 f64) (result (ref $type45))
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global161)
   )
  )
  (struct.new $type45
   (f64.div
    (local.get $0)
    (local.tee $0
     (f64.sqrt
      (f64.add
       (f64.add
        (f64.mul
         (local.get $0)
         (local.get $0)
        )
        (f64.mul
         (local.get $1)
         (local.get $1)
        )
       )
       (f64.mul
        (local.get $2)
        (local.get $2)
       )
      )
     )
    )
   )
   (f64.div
    (local.get $1)
    (local.get $0)
   )
   (f64.div
    (local.get $2)
    (local.get $0)
   )
  )
 )
 (func $function63 (param $0 (ref $type14)) (param $1 i64)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type30))
  (local $5 (ref $type31))
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (local.get $0)
   )
  )
  (if
   (i32.eq
    (call $foreign2)
    (i32.const 1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready116)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global116)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (drop
     (call $function41
      (local.get $0)
     )
    )
    (call $foreign3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready242)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global242)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (local.get $0)
   )
  )
  (local.set $4
   (struct.new $type30
    (struct.new $type31
     (call $foreign4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready190)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (global.get $global190)
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string2)
    (local.get $4)
    (i64.const 3)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (call $foreign6
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $4)
      )
     )
     (i32.const 45)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (call $function52
   (select
    (i64.sub
     (i64.const 0)
     (local.get $2)
    )
    (local.get $2)
    (i64.gt_s
     (local.get $2)
     (i64.const 0)
    )
   )
   (local.get $4)
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string1)
    (local.get $4)
    (i64.const 1)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready135)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (if
   (i64.lt_s
    (local.get $2)
    (i64.const 0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (call $foreign6
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $4)
      )
     )
     (i32.const 45)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready138)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global138)
   )
  )
  (call $function52
   (select
    (i64.sub
     (i64.const 0)
     (local.get $2)
    )
    (local.get $2)
    (i64.gt_s
     (local.get $2)
     (i64.const 0)
    )
   )
   (local.get $4)
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (drop
   (call $function49
    (global.get $string0)
    (local.get $4)
    (i64.const 4)
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready133)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (if
   (i32.eqz
    (global.get $ready124)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global124)
   )
  )
  (call $foreign6
   (struct.get $type31 0
    (struct.get $type30 0
     (local.get $4)
    )
   )
   (i32.const 10)
  )
  (drop
   (if (result i32)
    (i64.eqz
     (local.get $2)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call $function66
       (local.get $1)
       (local.get $4)
       (local.get $2)
       (i64.const 0)
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
      )
     )
     (if (result i32)
      (i64.eq
       (local.get $2)
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call $function66
         (local.get $1)
         (local.get $4)
         (local.get $2)
         (i64.const 1)
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (if (result i32)
        (i64.eq
         (local.get $2)
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call $function66
           (local.get $1)
           (local.get $4)
           (local.get $2)
           (i64.const 2)
           (i32.const 0)
           (i32.const 1)
           (i64.const 0)
          )
         )
         (if (result i32)
          (i64.eq
           (local.get $2)
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call $function66
             (local.get $1)
             (local.get $4)
             (local.get $2)
             (i64.const 3)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
            )
           )
           (if (result i32)
            (i64.eq
             (local.get $2)
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call $function66
               (local.get $1)
               (local.get $4)
               (local.get $2)
               (i64.const 4)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
              )
             )
             (if (result i32)
              (i64.eq
               (local.get $2)
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call $function66
                 (local.get $1)
                 (local.get $4)
                 (local.get $2)
                 (i64.const 5)
                 (i32.const 0)
                 (i32.const 1)
                 (i64.const 0)
                )
               )
               (if (result i32)
                (i64.eq
                 (local.get $2)
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call $function66
                   (local.get $1)
                   (local.get $4)
                   (local.get $2)
                   (i64.const 6)
                   (i32.const 0)
                   (i32.const 1)
                   (i64.const 0)
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (local.get $2)
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call $function66
                     (local.get $1)
                     (local.get $4)
                     (local.get $2)
                     (i64.const 7)
                     (i32.const 0)
                     (i32.const 1)
                     (i64.const 0)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (local.get $2)
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call $function66
                       (local.get $1)
                       (local.get $4)
                       (local.get $2)
                       (i64.const 8)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 0)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (local.get $2)
                       (i64.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (call $function66
                         (local.get $1)
                         (local.get $4)
                         (local.get $2)
                         (i64.const 9)
                         (i32.const 0)
                         (i32.const 1)
                         (i64.const 0)
                        )
                       )
                       (if (result i32)
                        (i64.eq
                         (local.get $2)
                         (i64.const 10)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (drop
                          (call $function66
                           (local.get $1)
                           (local.get $4)
                           (local.get $2)
                           (i64.const 10)
                           (i32.const 0)
                           (i32.const 1)
                           (i64.const 0)
                          )
                         )
                         (if (result i32)
                          (i64.eq
                           (local.get $2)
                           (i64.const 11)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (call $function66
                             (local.get $1)
                             (local.get $4)
                             (local.get $2)
                             (i64.const 11)
                             (i32.const 0)
                             (i32.const 1)
                             (i64.const 0)
                            )
                           )
                           (if (result i32)
                            (i64.eq
                             (local.get $2)
                             (i64.const 12)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (drop
                              (call $function66
                               (local.get $1)
                               (local.get $4)
                               (local.get $2)
                               (i64.const 12)
                               (i32.const 0)
                               (i32.const 1)
                               (i64.const 0)
                              )
                             )
                             (if (result i32)
                              (i64.eq
                               (local.get $2)
                               (i64.const 13)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (drop
                                (call $function66
                                 (local.get $1)
                                 (local.get $4)
                                 (local.get $2)
                                 (i64.const 13)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 0)
                                )
                               )
                               (call $function65
                                (local.get $1)
                                (local.get $4)
                                (local.get $2)
                                (i32.const 0)
                                (i32.const 1)
                                (i64.const 14)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (if
   (i32.ne
    (local.tee $3
     (struct.get $type31 0
      (local.tee $5
       (struct.get $type30 0
        (local.get $4)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type31 0
     (local.get $5)
     (i32.const -1)
    )
    (call $foreign5
     (local.get $3)
    )
   )
  )
 )
 (func $function65 (type $16) (param $0 i64) (param $1 (ref $type30)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call $function66
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $5)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function65
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function66 (type $15) (param $0 i64) (param $1 (ref $type30)) (param $2 i64) (param $3 i64) (param $4 i32) (param $5 i32) (param $6 i64) (result i32)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (local $10 f64)
  (local $11 f64)
  (local $12 i64)
  (local $13 (ref $type45))
  (local $14 (ref $type45))
  (local $15 (ref $type45))
  (local $16 (ref $type45))
  (local $17 (ref $type47))
  (local $18 (ref $type49))
  (local $19 (ref $type50))
  (local $scratch f64)
  (local $scratch_21 (ref $type50))
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $6)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready195)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global195)
     )
    )
    (local.set $13
     (call $function60
      (f64.sub
       (f64.add
        (f64.div
         (f64.convert_i64_s
          (local.get $6)
         )
         (local.tee $7
          (f64.convert_i64_s
           (local.get $0)
          )
         )
        )
        (f64.const -50)
       )
       (block (result f64)
        (if
         (i32.eqz
          (global.get $ready184)
         )
         (then
          (unreachable)
         )
        )
        (local.set $scratch
         (struct.get $type45 0
          (global.get $global184)
         )
        )
        (if
         (i32.eqz
          (global.get $ready184)
         )
         (then
          (unreachable)
         )
        )
        (local.set $10
         (struct.get $type45 1
          (global.get $global184)
         )
        )
        (if
         (i32.eqz
          (global.get $ready184)
         )
         (then
          (unreachable)
         )
        )
        (local.set $11
         (struct.get $type45 2
          (global.get $global184)
         )
        )
        (if
         (i32.eqz
          (global.get $ready167)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global167)
         )
        )
        (local.get $scratch)
       )
      )
      (f64.sub
       (f64.add
        (f64.div
         (f64.convert_i64_s
          (local.get $3)
         )
         (local.get $7)
        )
        (f64.const -50)
       )
       (local.get $10)
      )
      (f64.sub
       (f64.const -0)
       (local.get $11)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready184)
     )
     (then
      (unreachable)
     )
    )
    (local.set $17
     (call $function70
      (ref.as_non_null
       (global.get $global184)
      )
      (block (result (ref $type45))
       (if
        (i32.eqz
         (global.get $ready199)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global199)
        )
       )
       (if
        (i32.eqz
         (global.get $ready203)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global203)
        )
       )
       (if
        (i32.eqz
         (global.get $ready183)
        )
        (then
         (unreachable)
        )
       )
       (local.get $13)
      )
      (i32.const 0)
      (i32.const 1)
      (struct.get $type58 0
       (global.get $global183)
      )
      (struct.new_default $type48)
      (f64.const 1.e+308)
     )
    )
    (if
     (i32.eqz
      (global.get $ready150)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global150)
     )
    )
    (local.set $12
     (i64.trunc_f64_s
      (f64.nearest
       (f64.mul
        (if (result f64)
         (if (result i32)
          (ref.test (ref $type49)
           (local.get $17)
          )
          (then
           (drop
            (ref.cast (ref $type49)
             (local.get $17)
            )
           )
           (i32.const 1)
          )
          (else
           (i32.const 0)
          )
         )
         (then
          (if
           (i32.eqz
            (ref.test (ref $type49)
             (local.get $17)
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $7
           (struct.get $type45 0
            (local.tee $14
             (call $function60
              (f64.sub
               (struct.get $type45 0
                (local.tee $15
                 (struct.get $type50 2
                  (block (result (ref $type50))
                   (local.set $scratch_21
                    (struct.get $type49 0
                     (local.tee $18
                      (ref.cast (ref $type49)
                       (local.get $17)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready228)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global228)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready233)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global233)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready236)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global236)
                    )
                   )
                   (local.get $scratch_21)
                  )
                 )
                )
               )
               (block (result f64)
                (if
                 (i32.eqz
                  (global.get $ready167)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global167)
                 )
                )
                (struct.get $type45 0
                 (local.tee $16
                  (struct.get $type49 1
                   (local.get $18)
                  )
                 )
                )
               )
              )
              (f64.sub
               (struct.get $type45 1
                (local.get $15)
               )
               (struct.get $type45 1
                (local.get $16)
               )
              )
              (f64.sub
               (struct.get $type45 2
                (local.get $15)
               )
               (struct.get $type45 2
                (local.get $16)
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready158)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global158)
           )
          )
          (f64.mul
           (select
            (f64.const 0)
            (local.tee $7
             (f64.add
              (f64.add
               (f64.mul
                (struct.get $type45 0
                 (local.get $13)
                )
                (local.get $7)
               )
               (f64.mul
                (struct.get $type45 1
                 (local.get $13)
                )
                (struct.get $type45 1
                 (local.get $14)
                )
               )
              )
              (f64.mul
               (struct.get $type45 2
                (local.get $13)
               )
               (struct.get $type45 2
                (local.get $14)
               )
              )
             )
            )
            (f64.lt
             (local.get $7)
             (f64.const 0)
            )
           )
           (block (result f64)
            (if
             (i32.eqz
              (global.get $ready240)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global240)
             )
            )
            (struct.get $type50 0
             (struct.get $type49 0
              (local.get $18)
             )
            )
           )
          )
         )
         (else
          (f64.const 0)
         )
        )
        (f64.const 255)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready135)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (if
     (i64.lt_s
      (local.get $12)
      (i64.const 0)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready124)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global124)
       )
      )
      (call $foreign6
       (struct.get $type31 0
        (struct.get $type30 0
         (local.get $1)
        )
       )
       (i32.const 45)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready138)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global138)
     )
    )
    (call $function52
     (select
      (i64.sub
       (i64.const 0)
       (local.get $12)
      )
      (local.get $12)
      (i64.gt_s
       (local.get $12)
       (i64.const 0)
      )
     )
     (local.get $1)
    )
    (if
     (i32.eqz
      (global.get $ready133)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (call $foreign6
     (struct.get $type31 0
      (struct.get $type30 0
       (local.get $1)
      )
     )
     (i32.const 10)
    )
    (if
     (i32.eqz
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function66
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (i64.add
      (local.get $6)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function70 (type $11) (param $0 (ref $type45)) (param $1 (ref $type45)) (param $2 i32) (param $3 i32) (param $4 (ref null $type59)) (param $5 (ref $type47)) (param $6 f64) (result (ref $type47))
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (local $10 f64)
  (local $11 f64)
  (local $12 f64)
  (local $13 f64)
  (local $14 f64)
  (local $15 f64)
  (local $16 f64)
  (local $17 f64)
  (local $18 (ref null $type45))
  (local $19 (ref null $type45))
  (local $20 (ref $type38))
  (local $21 (ref $type42))
  (local $22 (ref $type50))
  (local $scratch f64)
  (local $scratch_24 f64)
  (block $block
   (return
    (if (result (ref $type47))
     (ref.is_null
      (local.get $4)
     )
     (then
      (local.get $5)
     )
     (else
      (local.set $22
       (struct.get $type59 0
        (local.get $4)
       )
      )
      (if
       (i32.eqz
        (global.get $ready212)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global212)
       )
      )
      (local.set $19
       (local.get $1)
      )
      (if
       (i32.eqz
        (global.get $ready216)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global216)
       )
      )
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (local.set $20
       (if (result (ref $type38))
        (f64.eq
         (local.tee $9
          (f64.add
           (f64.add
            (f64.mul
             (local.tee $10
              (struct.get $type45 0
               (local.get $1)
              )
             )
             (local.get $10)
            )
            (block (result f64)
             (if
              (i32.eqz
               (global.get $ready161)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global161)
              )
             )
             (local.set $scratch_24
              (f64.mul
               (local.tee $11
                (struct.get $type45 1
                 (local.get $1)
                )
               )
               (local.get $11)
              )
             )
             (if
              (i32.eqz
               (global.get $ready161)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global161)
              )
             )
             (local.set $17
              (f64.mul
               (local.tee $13
                (struct.get $type45 2
                 (local.get $1)
                )
               )
               (local.get $13)
              )
             )
             (if
              (i32.eqz
               (global.get $ready161)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global161)
              )
             )
             (local.set $8
              (f64.add
               (f64.add
                (f64.add
                 (f64.mul
                  (local.tee $8
                   (f64.sub
                    (local.tee $7
                     (struct.get $type45 0
                      (local.get $0)
                     )
                    )
                    (struct.get $type45 0
                     (local.tee $1
                      (struct.get $type50 2
                       (local.get $22)
                      )
                     )
                    )
                   )
                  )
                  (local.get $8)
                 )
                 (block (result f64)
                  (if
                   (i32.eqz
                    (global.get $ready161)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global161)
                   )
                  )
                  (local.set $scratch
                   (f64.mul
                    (local.tee $14
                     (f64.sub
                      (struct.get $type45 1
                       (local.get $0)
                      )
                      (struct.get $type45 1
                       (local.get $1)
                      )
                     )
                    )
                    (local.get $14)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready161)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global161)
                   )
                  )
                  (local.set $15
                   (f64.mul
                    (local.tee $15
                     (f64.sub
                      (struct.get $type45 2
                       (local.get $0)
                      )
                      (struct.get $type45 2
                       (local.get $1)
                      )
                     )
                    )
                    (local.get $15)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready161)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global161)
                   )
                  )
                  (local.set $16
                   (f64.mul
                    (local.tee $16
                     (struct.get $type50 1
                      (local.get $22)
                     )
                    )
                    (local.get $16)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready175)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global175)
                   )
                  )
                  (local.set $7
                   (f64.mul
                    (f64.add
                     (f64.add
                      (f64.mul
                       (f64.sub
                        (local.get $7)
                        (struct.get $type45 0
                         (local.get $1)
                        )
                       )
                       (local.get $10)
                      )
                      (f64.mul
                       (f64.sub
                        (struct.get $type45 1
                         (local.tee $18
                          (local.get $0)
                         )
                        )
                        (struct.get $type45 1
                         (local.get $1)
                        )
                       )
                       (local.get $11)
                      )
                     )
                     (f64.mul
                      (f64.sub
                       (struct.get $type45 2
                        (local.get $0)
                       )
                       (struct.get $type45 2
                        (local.get $1)
                       )
                      )
                      (local.get $13)
                     )
                    )
                    (f64.const 2)
                   )
                  )
                  (local.get $scratch)
                 )
                )
                (local.get $15)
               )
               (f64.sub
                (f64.const -0)
                (local.get $16)
               )
              )
             )
             (local.get $scratch_24)
            )
           )
           (local.get $17)
          )
         )
         (f64.const 0)
        )
        (then
         (struct.new $type40
          (f64.div
           (f64.sub
            (f64.const -0)
            (local.get $8)
           )
           (local.get $7)
          )
         )
        )
        (else
         (if
          (i32.eqz
           (global.get $ready161)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global161)
          )
         )
         (if (result (ref $type38))
          (f64.lt
           (local.tee $8
            (f64.sub
             (f64.mul
              (local.get $7)
              (local.get $7)
             )
             (f64.mul
              (f64.mul
               (local.get $9)
               (f64.const 4)
              )
              (local.get $8)
             )
            )
           )
           (f64.const 0)
          )
          (then
           (struct.new_default $type39)
          )
          (else
           (if
            (i32.eqz
             (global.get $ready155)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global155)
            )
           )
           (struct.new $type40
            (select
             (select
              (local.tee $7
               (f64.div
                (f64.add
                 (local.tee $12
                  (f64.sub
                   (f64.const -0)
                   (local.get $7)
                  )
                 )
                 (local.tee $8
                  (f64.sqrt
                   (local.get $8)
                  )
                 )
                )
                (local.tee $9
                 (f64.add
                  (local.get $9)
                  (local.get $9)
                 )
                )
               )
              )
              (local.tee $9
               (f64.div
                (f64.sub
                 (local.get $12)
                 (local.get $8)
                )
                (local.get $9)
               )
              )
              (f64.lt
               (local.get $7)
               (local.get $9)
              )
             )
             (local.get $7)
             (f64.eq
              (local.get $7)
              (local.get $7)
             )
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready142)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global142)
       )
      )
      (local.set $21
       (if (result (ref $type42))
        (if (result i32)
         (ref.test (ref $type40)
          (local.get $20)
         )
         (then
          (drop
           (ref.cast (ref $type40)
            (local.get $20)
           )
          )
          (i32.const 1)
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (if
          (i32.eqz
           (ref.test (ref $type40)
            (local.get $20)
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.new $type44
          (struct.new $type45
           (f64.add
            (struct.get $type45 0
             (local.get $0)
            )
            (f64.mul
             (local.tee $7
              (struct.get $type40 0
               (ref.cast (ref $type40)
                (local.get $20)
               )
              )
             )
             (local.get $10)
            )
           )
           (f64.add
            (struct.get $type45 1
             (local.get $0)
            )
            (f64.mul
             (local.get $7)
             (local.get $11)
            )
           )
           (f64.add
            (struct.get $type45 2
             (local.get $0)
            )
            (f64.mul
             (local.get $7)
             (local.get $13)
            )
           )
          )
         )
        )
        (else
         (struct.new_default $type43)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready146)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global146)
       )
      )
      (br_if $block
       (i32.eqz
        (if (result i32)
         (ref.test (ref $type44)
          (local.get $21)
         )
         (then
          (drop
           (ref.cast (ref $type44)
            (local.get $21)
           )
          )
          (i32.const 1)
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $21)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $0
       (struct.get $type44 0
        (ref.cast (ref $type44)
         (local.get $21)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready172)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global172)
       )
      )
      (if
       (i32.eqz
        (global.get $ready163)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global163)
       )
      )
      (local.set $7
       (f64.sub
        (struct.get $type45 0
         (local.get $0)
        )
        (struct.get $type45 0
         (local.get $18)
        )
       )
      )
      (local.set $10
       (f64.sub
        (struct.get $type45 1
         (local.get $0)
        )
        (struct.get $type45 1
         (local.get $18)
        )
       )
      )
      (local.set $11
       (f64.sub
        (struct.get $type45 2
         (local.get $0)
        )
        (struct.get $type45 2
         (local.get $18)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (if
       (i32.eqz
        (global.get $ready161)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global161)
       )
      )
      (br_if $block
       (i32.eqz
        (f64.gt
         (local.get $6)
         (local.tee $7
          (f64.sqrt
           (f64.add
            (f64.add
             (f64.mul
              (local.get $7)
              (local.get $7)
             )
             (f64.mul
              (local.get $10)
              (local.get $10)
             )
            )
            (f64.mul
             (local.get $11)
             (local.get $11)
            )
           )
          )
         )
        )
       )
      )
      (local.set $4
       (struct.get $type59 1
        (local.get $4)
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function70
       (ref.as_non_null
        (local.get $18)
       )
       (ref.as_non_null
        (local.get $19)
       )
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (struct.new $type49
        (local.get $22)
        (local.get $0)
       )
       (local.get $7)
      )
     )
    )
   )
  )
  (local.set $4
   (struct.get $type59 1
    (local.get $4)
   )
  )
  (if
   (i32.eqz
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function70
   (ref.as_non_null
    (local.get $18)
   )
   (ref.as_non_null
    (local.get $19)
   )
   (local.get $2)
   (local.get $3)
   (local.get $4)
   (local.get $5)
   (local.get $6)
  )
 )
 (func $function81 (type $5) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 (ref $type58))
  (if (result i32)
   (i64.gt_s
    (local.get $3)
    (i64.const 7)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready247)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global247)
     )
    )
    (if
     (i32.eqz
      (global.get $ready183)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type58 0
     (ref.as_non_null
      (global.get $global183)
     )
     (block (result (ref (exact $type59)))
      (if
       (i32.eqz
        (global.get $ready183)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type59
       (struct.new $type50
        (f64.const 0.75)
        (f64.const 40)
        (struct.new $type45
         (f64.mul
          (f64.convert_i64_s
           (local.get $0)
          )
          (f64.const 200)
         )
         (f64.const 300)
         (f64.mul
          (f64.convert_i64_s
           (local.get $3)
          )
          (f64.const -400)
         )
        )
       )
       (struct.get $type58 0
        (global.get $global183)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function84 (type $4) (param $0 i64) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result (ref $type14))
  (local $5 i32)
  (local $6 i32)
  (if (result (ref $type14))
   (i64.eq
    (local.get $0)
    (local.get $4)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $6
     (call $foreign8
      (local.get $4)
     )
    )
    (if
     (i32.ne
      (struct.get $type14 0
       (local.get $1)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type14 1
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type14 2
        (local.get $1)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type16
         (struct.get $type14 3
          (local.get $1)
         )
         (i32.sub
          (i32.shr_u
           (local.get $5)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $5)
      (i32.const 8191)
     )
     (local.get $6)
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function84
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function87 (type $3) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 (ref $type58))
  (local $6 (ref $type14))
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready269)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready280)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (local.set $4
     (call $foreign10
      (global.get $global269)
     )
    )
    (if
     (i32.eqz
      (global.get $ready270)
     )
     (then
      (unreachable)
     )
    )
    (call $function63
     (ref.as_non_null
      (global.get $global270)
     )
     (block (result i64)
      (if
       (i32.eqz
        (global.get $ready272)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global272)
       )
      )
      (if
       (i32.eqz
        (call $foreign9)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready261)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global261)
       )
      )
      (if
       (i32.eqz
        (global.get $ready254)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global254)
       )
      )
      (if
       (i32.eqz
        (global.get $ready183)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type58 0
       (global.get $global183)
       (ref.null none)
      )
      (if
       (i32.eqz
        (global.get $ready247)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global247)
       )
      )
      (if
       (i32.eqz
        (global.get $ready183)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type58 0
       (ref.as_non_null
        (global.get $global183)
       )
       (block (result (ref (exact $type59)))
        (if
         (i32.eqz
          (global.get $ready183)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type59
         (struct.new $type50
          (f64.const 0.8)
          (f64.const 200)
          (struct.new $type45
           (f64.const 0)
           (f64.const -300)
           (f64.const -1200)
          )
         )
         (struct.get $type58 0
          (global.get $global183)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready247)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global247)
       )
      )
      (if
       (i32.eqz
        (global.get $ready183)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type58 0
       (ref.as_non_null
        (global.get $global183)
       )
       (block (result (ref (exact $type59)))
        (if
         (i32.eqz
          (global.get $ready183)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type59
         (struct.new $type50
          (f64.const 0.7)
          (f64.const 200)
          (struct.new $type45
           (f64.const -80)
           (f64.const -150)
           (f64.const -1200)
          )
         )
         (struct.get $type58 0
          (global.get $global183)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready247)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global247)
       )
      )
      (if
       (i32.eqz
        (global.get $ready183)
       )
       (then
        (unreachable)
       )
      )
      (struct.set $type58 0
       (ref.as_non_null
        (global.get $global183)
       )
       (block (result (ref (exact $type59)))
        (if
         (i32.eqz
          (global.get $ready183)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type59
         (struct.new $type50
          (f64.const 0.9)
          (f64.const 200)
          (struct.new $type45
           (f64.const 70)
           (f64.const -100)
           (f64.const -1200)
          )
         )
         (struct.get $type58 0
          (global.get $global183)
         )
        )
       )
      )
      (drop
       (call $function81
        (i64.const -2)
        (i32.const 0)
        (i32.const 1)
        (i64.const 2)
       )
      )
      (drop
       (call $function81
        (i64.const -1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 2)
       )
      )
      (drop
       (call $function81
        (i64.const 0)
        (i32.const 0)
        (i32.const 1)
        (i64.const 2)
       )
      )
      (drop
       (call $function81
        (i64.const 1)
        (i32.const 0)
        (i32.const 1)
        (i64.const 2)
       )
      )
      (drop
       (call $function81
        (i64.const 2)
        (i32.const 0)
        (i32.const 1)
        (i64.const 2)
       )
      )
      (if
       (i32.eqz
        (global.get $ready185)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global185)
       )
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (i64.const 1)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready271)
     )
     (then
      (unreachable)
     )
    )
    (i64.extend_i32_u
     (i64.eq
      (global.get $global271)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready275)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global275)
   )
  )
  (return_call $function87
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $main
  (local $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i64)
  (local $6 (ref null $type16))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type27)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global114
   (struct.new_default $type28)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type27)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type29)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type32)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global242
   (struct.new_default $type33)
  )
  (global.set $ready242
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type34)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type35)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global133
   (struct.new_default $type32)
  )
  (global.set $ready133
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type36)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global138
   (struct.new_default $type36)
  )
  (global.set $ready138
   (i32.const 1)
  )
  (global.set $global142
   (struct.new_default $type37)
  )
  (global.set $ready142
   (i32.const 1)
  )
  (global.set $global146
   (struct.new_default $type41)
  )
  (global.set $ready146
   (i32.const 1)
  )
  (global.set $global150
   (struct.new_default $type46)
  )
  (global.set $ready150
   (i32.const 1)
  )
  (global.set $global155
   (struct.new_default $type51)
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global158
   (struct.new_default $type51)
  )
  (global.set $ready158
   (i32.const 1)
  )
  (global.set $global280
   (struct.new_default $type52)
  )
  (global.set $ready280
   (i32.const 1)
  )
  (global.set $global161
   (struct.new_default $type53)
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global163
   (struct.new_default $type54)
  )
  (global.set $ready163
   (i32.const 1)
  )
  (global.set $global167
   (struct.new_default $type55)
  )
  (global.set $ready167
   (i32.const 1)
  )
  (global.set $global172
   (struct.new_default $type56)
  )
  (global.set $ready172
   (i32.const 1)
  )
  (global.set $global175
   (struct.new_default $type57)
  )
  (global.set $ready175
   (i32.const 1)
  )
  (global.set $global183
   (struct.new_default $type58)
  )
  (global.set $ready183
   (i32.const 1)
  )
  (global.set $global184
   (struct.new $type45
    (f64.const 0)
    (f64.const 0)
    (f64.const 200)
   )
  )
  (global.set $ready184
   (i32.const 1)
  )
  (global.set $global185
   (struct.new_default $type60)
  )
  (global.set $ready185
   (i32.const 1)
  )
  (global.set $global195
   (struct.new_default $type61)
  )
  (global.set $ready195
   (i32.const 1)
  )
  (global.set $global199
   (struct.new_default $type56)
  )
  (global.set $ready199
   (i32.const 1)
  )
  (global.set $global203
   (struct.new_default $type62)
  )
  (global.set $ready203
   (i32.const 1)
  )
  (global.set $global228
   (struct.new_default $type63)
  )
  (global.set $ready228
   (i32.const 1)
  )
  (global.set $global247
   (struct.new_default $type64)
  )
  (global.set $ready247
   (i32.const 1)
  )
  (global.set $global240
   (struct.new_default $type65)
  )
  (global.set $ready240
   (i32.const 1)
  )
  (global.set $global212
   (struct.new_default $type66)
  )
  (global.set $ready212
   (i32.const 1)
  )
  (global.set $global216
   (struct.new_default $type66)
  )
  (global.set $ready216
   (i32.const 1)
  )
  (global.set $global233
   (struct.new_default $type67)
  )
  (global.set $ready233
   (i32.const 1)
  )
  (global.set $global236
   (struct.new_default $type67)
  )
  (global.set $ready236
   (i32.const 1)
  )
  (global.set $global254
   (struct.new_default $type68)
  )
  (global.set $ready254
   (i32.const 1)
  )
  (global.set $global261
   (struct.new_default $type69)
  )
  (global.set $ready261
   (i32.const 1)
  )
  (global.set $global264
   (struct.new_default $type70)
  )
  (global.set $ready264
   (i32.const 1)
  )
  (global.set $global190
   (call $foreign11
    (i32.const 2)
   )
  )
  (global.set $ready190
   (i32.const 1)
  )
  (global.set $global269
   (call $foreign11
    (i32.const 0)
   )
  )
  (global.set $ready269
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready264)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global264)
   )
  )
  (if
   (i64.gt_u
    (local.tee $5
     (call $foreign7)
    )
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (if
   (local.tee $1
    (i32.sub
     (local.tee $0
      (i32.wrap_i64
       (local.get $5)
      )
     )
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $6
     (array.new_default $type16
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type16
      (local.get $6)
      (local.get $2)
      (array.new $type15
       (i32.const 32)
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (global.set $global270
   (call $function84
    (local.get $5)
    (struct.new $type14
     (i32.const 1)
     (local.get $0)
     (array.new $type15
      (i32.const 32)
      (local.get $3)
     )
     (local.get $6)
    )
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (global.set $ready270
   (i32.const 1)
  )
  (global.set $global271
   (call $foreign11
    (i32.const 1)
   )
  )
  (global.set $ready271
   (i32.const 1)
  )
  (global.set $global272
   (struct.new_default $type71)
  )
  (global.set $ready272
   (i32.const 1)
  )
  (global.set $global275
   (struct.new_default $type72)
  )
  (global.set $ready275
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

