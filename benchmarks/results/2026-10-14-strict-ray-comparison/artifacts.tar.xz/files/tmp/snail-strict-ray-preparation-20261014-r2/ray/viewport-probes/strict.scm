(import (snail strict) (snail io))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test) body ...)
     (do ((var init step) ...) (test (unit)) body ...))
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define-data Point
  (make-point (x F64 point-x) (y F64 point-y) (z F64 point-z)))
(define-data Sphere
  (make-sphere (color F64 sphere-color) (radius F64 sphere-radius)
               (center Point sphere-center)))
(define-data Root (no-root) (some-root (value F64 root-value)))
(define-data Candidate (no-point) (some-point (value Point candidate-point)))
(define-data Hit (miss) (hit (sphere Sphere hit-sphere) (point Point hit-point)))
(: root? (-> Root Bool))
(define (root? value) (match value ((no-root) #f) ((some-root n) #t)))
(: candidate? (-> Candidate Bool))
(define (candidate? value) (match value ((no-point) #f) ((some-point p) #t)))
(: hit? (-> Hit Bool))
(define (hit? value) (match value ((miss) #f) ((hit s p) #t)))
;; Chez min/max propagate NaN and select the right equal operand,
;; including signed zero. The source uses these two-argument operations only.
(: ray-min (-> F64 F64 F64))
(define (ray-min left right)
  (if (not (= left left)) left (if (< left right) left right)))
(: ray-max (-> F64 F64 F64))
(define (ray-max left right)
  (if (not (= left left)) left (if (> left right) left right)))
(define (hide count x) (hide-i64 x))
(: sq (-> F64 F64))
(: mag (-> F64 F64 F64 F64))
(: unit-vector (-> F64 F64 F64 Point))
(: distance (-> Point Point F64))
(: minroot (-> F64 F64 F64 Root))
(: tracer (-> String I64 Unit))
(: color-at (-> F64 F64 I64))
(: sendray (-> Point Point F64))
(: first-hit (-> Point Point Hit))
(: lambert (-> Sphere Point Point F64))
(: defsphere (-> F64 F64 F64 F64 F64 Sphere))
(: surface-color (-> Sphere F64))
(: intersect (-> Sphere Point Point Candidate))
(: sphere-intersect (-> Sphere Point Point Candidate))
(: normal (-> Sphere Point Point))
(: sphere-normal (-> Sphere Point Point))
(: ray-test (-> I64 String Unit))
(: run (-> I64 String I64))
;;; RAY -- Ray-trace a simple scene with spheres, generating a ".pgm" file.
;;; Translated to Scheme from Paul Graham's book ANSI Common Lisp, Example 9.8


; make-point: concrete product operation.

; point-x: concrete product operation.
; point-y: concrete product operation.
; point-z: concrete product operation.

(define (sq x) (* x x))

(define (mag x y z)
  (sqrt (+ (+ (sq x) (sq y)) (sq z))))

(define (unit-vector x y z)
  (let ((d (mag x y z)))
    (make-point (/ x d) (/ y d) (/ z d))))

(define (distance p1 p2)
  (mag (- (point-x p1) (point-x p2))
       (- (point-y p1) (point-y p2))
       (- (point-z p1) (point-z p2))))

(define (minroot a b c)
  (if (= a 0.0)
      (some-root (/ (* -1.0 c) b))
      (let ((disc (- (sq b) (* (* 4.0 a) c))))
        (if (< disc 0.0)
            (no-root)
            (let ((discrt (sqrt disc))
                  (minus-b (* -1.0 b))
                  (two-a (* 2.0 a)))
              (some-root (ray-min (/ (+ minus-b discrt) two-a)
                              (/ (- minus-b discrt) two-a))))))))

(define *world* (ref (ann '() (List Sphere))))

(define eye (make-point 0.0 0.0 200.0))

(define (tracer pathname res)
  (when (file-exists? pathname)
    (delete-file pathname))
  (call-with-output-file
      pathname
    (lambda (p)
      (let ((extent probe-extent))
        (write-string "P2 " p)
        (write-i64 extent p)
        (write-string " " p)
        (write-i64 extent p)
        (write-string " 255" p)
        (newline p)
        (do ((y 0 (+ y 1)))
            ((= y extent))
          (do ((x 0 (+ x 1)))
              ((= x extent))
            (write-i64 (color-at
                    (+ -50.0
                       (/ (i64->f64 x) (i64->f64 res)))
                    (+ -50.0
                       (/ (i64->f64 y) (i64->f64 res))))
                   p)
            (newline p)))))))

(define (color-at x y)
  (let ((ray (unit-vector (- x (point-x eye))
                          (- y (point-y eye))
                          (* -1.0 (point-z eye)))))
    (f64->i64 (round (* (sendray eye ray) 255.0)))))



(define (sendray pt ray)
  (let ((selected (first-hit pt ray)))
    (if (hit? selected)
        (* (lambert (hit-sphere selected) (hit-point selected) ray)
           (surface-color (hit-sphere selected)))
        0.0)))

(define (first-hit pt ray)
  (let loop ((lst (ref-get *world*)) (selected (miss)) (dist 1e308))
    (if (null? lst)
        selected
        (let ((s (car lst)))
          (let ((candidate (intersect s pt ray)))
            (if (candidate? candidate)
                (let* ((h (candidate-point candidate)) (d (distance h pt)))
                  (if (< d dist)
                      (loop (cdr lst) (hit s h) d)
                      (loop (cdr lst) selected dist)))
                (loop (cdr lst) selected dist)))))))

(define (lambert s int ray)
  (let ((n (normal s int)))
    (ray-max 0.0
         (+ (+ (* (point-x ray) (point-x n))
               (* (point-y ray) (point-y n)))
            (* (point-z ray) (point-z n))))))

; make-sphere: concrete product operation.

; sphere-color: concrete product operation.
; sphere-radius: concrete product operation.
; sphere-center: concrete product operation.

(define (defsphere x y z r c)
  (let ((s (make-sphere c r (make-point x y z))))
    (ref-set! *world* (cons s (ref-get *world*)))
    s))

(define (surface-color s)
  (sphere-color s))

(define (intersect s pt ray)
  (sphere-intersect s pt ray))

(define (sphere-intersect s pt ray)
  (let* ((xr (point-x ray))
         (yr (point-y ray))
         (zr (point-z ray))
         (c (sphere-center s))
         (n (minroot
             (+ (+ (sq xr) (sq yr)) (sq zr))
             (* 2.0
                (+ (+ (* (- (point-x pt) (point-x c)) xr)
                      (* (- (point-y pt) (point-y c)) yr))
                   (* (- (point-z pt) (point-z c)) zr)))
             (+ (+ (+ (sq (- (point-x pt) (point-x c)))
                      (sq (- (point-y pt) (point-y c))))
                   (sq (- (point-z pt) (point-z c))))
                (* -1.0 (sq (sphere-radius s)))))))
    (if (root? n)
        (let ((root (root-value n)))
          (some-point (make-point (+ (point-x pt) (* root xr))
                                  (+ (point-y pt) (* root yr))
                                  (+ (point-z pt) (* root zr)))))
        (no-point))))

(define (normal s pt)
  (sphere-normal s pt))

(define (sphere-normal s pt)
  (let ((c (sphere-center s)))
    (unit-vector (- (point-x c) (point-x pt))
                 (- (point-y c) (point-y pt))
                 (- (point-z c) (point-z pt)))))

(define (ray-test res output-file)
  (ref-set! *world* '())
  (defsphere 0.0 -300.0 -1200.0 200.0 0.8)
  (defsphere -80.0 -150.0 -1200.0 200.0 0.7)
  (defsphere 70.0 -100.0 -1200.0 200.0 0.9)
  (do ((x -2 (+ x 1)))
      ((> x 2))
    (do ((z 2 (+ z 1)))
        ((> z 7))
      (defsphere
        (* (i64->f64 x) 200.0)
        300.0
        (* (i64->f64 z) -400.0)
        40.0
        0.75)))
  (tracer output-file res))

(define (run input output)
  (ray-test input output)
  1)

(define-extern path-length "benchmark" "path_length" (-> I64))
(define-extern path-character "benchmark" "path_character" (-> I64 Char))
(: input-path (-> String))
(define (input-path)
  (let* ((size (path-length)) (text (make-string size #\space)))
    (let loop ((index 0))
      (if (= index size) text
          (begin (string-set! text index (path-character index)) (loop (+ index 1)))))))
(define probe-extent (native-input-i64 (ann 2 I32)))
(define input0 (native-input-i64 (ann 0 I32)))
(define input1 (input-path))
(define expected-kind (native-input-i64 (ann 1 I32)))
(: hide-path (-> I64 String String))
(define (hide-path count value) (if (barrier) value (unreachable)))

(: bench (-> I64 I64))
(define (bench count) (let loop ((i 0) (result 0))
  (if (< i count)
      (loop (+ i 1) (run (hide count input0) (hide-path count input1)))
      (if (= result expected-kind) 1 0))))
(unit)
