(: lexico (All (T)
  (-> (-> T T I64) (-> (MutableList T) (MutableList T) I64))))
(: zulu-select (All (T)
  (-> (-> T Bool) (MutableList T) (MutableList T))))
(: xreverse! (All (T) (-> (MutableList T) (MutableList T))))
(: select-map (All (A B)
  (-> (-> A Bool) (-> A B) (MutableList A) (MutableList B))))
(: map-and (All (T) (-> (-> T Bool) (MutableList T) Bool)))
(: maps-1 (All (S T)
  (-> (Lattice S) (Lattice T) (MutableList (Binding S T)) S (MutableList T))))
(: maps-rest (All (S T R)
  (-> (Lattice S) (Lattice T) (MutableList (Binding S T)) (MutableList S)
      (-> (MutableList (Binding S T)) R) (-> (MutableList R) R) R)))
(: maps (All (S T) (-> (Lattice S) (Lattice T) (Lattice (MutableList T)))))
(: count-maps (All (S T) (-> (Lattice S) (Lattice T) I64)))
(: sum (-> (MutableList I64) I64))
(: run (-> I64 I64))
;;; LATTICE -- Obtained from Andrew Wright.


;; Given a comparison routine that returns one of
;;       less
;;       more
;;       equal
;;       uncomparable
;; return a new comparison routine that applies to sequences.
(define lexico
  (lambda (base)
    (define lex-fixed
      (lambda (fixed lhs rhs)
        (define check
          (lambda (lhs rhs)
            (if (ml-null? lhs)
                fixed
                (let ((probe
                       (base (ml-car lhs)
                             (ml-car rhs))))
                  (if (or (= probe 1)
                          (= probe fixed))
                      (check (ml-cdr lhs)
                             (ml-cdr rhs))
                      3)))))
        (check lhs rhs)))
    (define lex-first
      (lambda (lhs rhs)
        (if (ml-null? lhs)
            1
            (let ((probe
                   (base (ml-car lhs)
                         (ml-car rhs))))
              (case probe
                ((0 2)
                 (lex-fixed probe
                            (ml-cdr lhs)
                            (ml-cdr rhs)))
                ((1)
                 (lex-first (ml-cdr lhs)
                            (ml-cdr rhs)))
                ((3)
                 3))))))
    lex-first))







;; Select elements of a list which pass some test.
(define zulu-select
  (lambda (test lst)
    (define select-a
      (lambda (ac lst)
        (if (ml-null? lst)
            (xreverse! ac)
            (select-a
             (let ((head (ml-car lst)))
               (if (test head)
                   (ml-cons head ac)
                   ac))
             (ml-cdr lst)))))
    (select-a (ml-empty) lst)))

(define (xreverse! lst)
  (letrec ((rotate
            (lambda (fo fum)
              (let ((next (ml-cdr fo)))
                (ml-set-cdr! fo fum)
                (if (ml-null? next)
                    fo
                    (rotate next fo))))))
    (if (ml-null? lst)
          (ml-empty)
          (rotate lst (ml-empty)))))

;; Select elements of a list which pass some test and map a function
;; over the result.  Note, only efficiency prevents this from being the
;; composition of select and map.
(define select-map
  (lambda (test func lst)
    (define select-a
      (lambda (ac lst)
        (if (ml-null? lst)
            (xreverse! ac)
            (select-a
             (let ((head (ml-car lst)))
               (if (test head)
                   (ml-cons (func head)
                         ac)
                   ac))
             (ml-cdr lst)))))
    (select-a (ml-empty) lst)))



;; This version of map-and tail-recurses on the last test.
(define map-and
  (lambda (proc lst)
    (if (ml-null? lst)
        #t
        (letrec ((drudge
                  (lambda (lst)
                    (let ((rest (ml-cdr lst)))
                      (if (ml-null? rest)
                          (proc (ml-car lst))
                          (and (proc (ml-car lst))
                               (drudge rest)))))))
          (drudge lst)))))

(define (maps-1 source target pas new)
  (let ((scmp (lattice->cmp source))
        (tcmp (lattice->cmp target)))
    (let ((less
           (select-map
            (lambda (p)
              (= 0
                   (scmp (binding-source p) new)))
            binding-target
            pas))
          (more
           (select-map
            (lambda (p)
              (= 2
                   (scmp (binding-source p) new)))
            binding-target
            pas)))
      (zulu-select
       (lambda (t)
         (and
          (map-and
           (lambda (t2)
             (code-member? (tcmp t2 t) lattice-less-equal))
           less)
          (map-and
           (lambda (t2)
             (code-member? (tcmp t2 t) lattice-more-equal))
           more)))
       (lattice->elements target)))))

(define (maps-rest source target pas rest to-1 to-collect)
  (if (ml-null? rest)
      (to-1 pas)
      (let ((next (ml-car rest))
            (rest (ml-cdr rest)))
        (to-collect
         (ml-map
          (lambda (x)
            (maps-rest source target
                       (ml-cons
                        (make-binding next x)
                        pas)
                       rest
                       to-1
                       to-collect))
          (maps-1 source target pas next))))))

(define (maps source target)
  (make-lattice
   (maps-rest source
              target
              (ml-empty)
              (lattice->elements source)
              (lambda (x) (ml-cons (ml-map binding-target x) (ml-empty)))
              (lambda (x) (ml-concatenate x)))
   (lexico (lattice->cmp target))))

(define (count-maps source target)
  (maps-rest source
             target
             (ml-empty)
             (lattice->elements source)
             (lambda (x) 1)
             sum))

(define (sum lst)
  (if (ml-null? lst)
      0
      (+ (ml-car lst) (sum (ml-cdr lst)))))

(define (run k)
  (let* ((l2
          (make-lattice lattice-base-elements
                        (lambda (lhs rhs)
                          (case lhs
                            ((0)
                             (case rhs
                               ((0)
                                1)
                               ((1)
                                0)
                               (else
                                (unreachable))))
                            ((1)
                             (case rhs
                               ((0)
                                2)
                               ((1)
                                1)
                               (else
                                (unreachable))))
                            (else
                             (unreachable))))))
         (l3 (maps l2 l2))
         (l4 (maps l3 l3)))
    (count-maps l2 l2)
    (count-maps l3 l3)
    (count-maps l2 l3)
    (count-maps l3 l2)
    (case k
      ((33) (count-maps l3 l3))
      ((44) (count-maps l4 l4))
      ((45) (let ((l5 (maps l4 l4)))
              (count-maps l4 l5)))
      ((54) (let ((l5 (maps l4 l4)))
              (count-maps l5 l4)))
      ((55) (let ((l5 (maps l4 l4)))
              (count-maps l5 l5)))
      (else (unreachable)))))

