(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define-data (MutableList T)
  (ml-empty)
  (ml-node (head T ml-car) (tail (Ref (MutableList T)) ml-tail-cell)))
(define-data (Lattice T)
  (make-lattice (elements (MutableList T) lattice->elements)
                (compare (-> T T I64) lattice->cmp)))
(define-data (Binding S T)
  (make-binding (source S binding-source) (target T binding-target)))
(: ml-cons (All (T) (-> T (MutableList T) (MutableList T))))
(define (ml-cons head tail) (ml-node head (ref tail)))
(: ml-null? (All (T) (-> (MutableList T) Bool)))
(define (ml-null? values)
  (match values ((ml-empty) #t) ((ml-node head tail) #f)))
(: ml-cdr (All (T) (-> (MutableList T) (MutableList T))))
(define (ml-cdr values) (ref-get (ml-tail-cell values)))
(: ml-set-cdr! (All (T) (-> (MutableList T) (MutableList T) Unit)))
(define (ml-set-cdr! values tail) (ref-set! (ml-tail-cell values) tail))
(define-syntax case
  (syntax-rules (else)
    ((_ key) (unreachable))
    ((_ key (else body ...)) (begin body ...))
    ((_ key ((datum ...) body ...) rest ...)
     (let ((value key))
       (if (or (= value datum) ...) (begin body ...) (case value rest ...))))))
;; Each proper-list node has an explicit mutable tail. Selection
;; reverses only its fresh accumulator spine; element identities stay shared.
(: ml-map (All (A B) (-> (-> A B) (MutableList A) (MutableList B))))
(define (ml-map procedure values)
  (if (ml-null? values) (ml-empty)
      (let ((head (procedure (ml-car values))))
        (ml-cons head (ml-map procedure (ml-cdr values))))))
(: ml-append (All (T) (-> (MutableList T) (MutableList T) (MutableList T))))
(define (ml-append first last)
  (if (ml-null? first) last
      (ml-cons (ml-car first) (ml-append (ml-cdr first) last))))
(: ml-concatenate (All (T) (-> (MutableList (MutableList T)) (MutableList T))))
(define (ml-concatenate lists)
  (if (ml-null? lists) (ml-empty)
      (if (ml-null? (ml-cdr lists)) (ml-car lists)
          (ml-append (ml-car lists) (ml-concatenate (ml-cdr lists))))))
(: code-member? (-> I64 (MutableList I64) Bool))
(define (code-member? value codes)
  (and (not (ml-null? codes))
       (or (= value (ml-car codes)) (code-member? value (ml-cdr codes)))))
;; The original quoted lists have constant lifetime and precede timing.
;; Point codes: low=0, high=1. Order codes: less=0, equal=1, more=2, uncomparable=3.
(define lattice-base-elements (ml-cons 0 (ml-cons 1 (ml-empty))))
(define lattice-less-equal (ml-cons 0 (ml-cons 1 (ml-empty))))
(define lattice-more-equal (ml-cons 2 (ml-cons 1 (ml-empty))))
(define (hide count x) (hide-i64 x))
(: lexico (All (T)
  (-> (-> T T I64) (-> (MutableList T) (MutableList T) I64))))
(: zulu-select (All (T)
  (-> (-> T Bool) (MutableList T) (MutableList T))))
(: xreverse! (All (T) (-> (MutableList T) (MutableList T))))
(: select-map (All (A B)
  (-> (-> A Bool) (-> A B) (MutableList A) (MutableList B))))
(: map-and (All (T) (-> (-> T Bool) (MutableList T) Bool)))
(: maps-1 (All (S T)
  (-> (Lattice S) (Lattice T) (MutableList (Binding S T)) S (MutableList T))))
(: maps-rest (All (S T R)
  (-> (Lattice S) (Lattice T) (MutableList (Binding S T)) (MutableList S)
      (-> (MutableList (Binding S T)) R) (-> (MutableList R) R) R)))
(: maps (All (S T) (-> (Lattice S) (Lattice T) (Lattice (MutableList T)))))
(: count-maps (All (S T) (-> (Lattice S) (Lattice T) I64)))
(: sum (-> (MutableList I64) I64))
(: run (-> I64 I64))
;;; LATTICE -- Obtained from Andrew Wright.


;; Given a comparison routine that returns one of
;;       less
;;       more
;;       equal
;;       uncomparable
;; return a new comparison routine that applies to sequences.
(define lexico
  (lambda (base)
    (define lex-fixed
      (lambda (fixed lhs rhs)
        (define check
          (lambda (lhs rhs)
            (if (ml-null? lhs)
                fixed
                (let ((probe
                       (base (ml-car lhs)
                             (ml-car rhs))))
                  (if (or (= probe 1)
                          (= probe fixed))
                      (check (ml-cdr lhs)
                             (ml-cdr rhs))
                      3)))))
        (check lhs rhs)))
    (define lex-first
      (lambda (lhs rhs)
        (if (ml-null? lhs)
            1
            (let ((probe
                   (base (ml-car lhs)
                         (ml-car rhs))))
              (case probe
                ((0 2)
                 (lex-fixed probe
                            (ml-cdr lhs)
                            (ml-cdr rhs)))
                ((1)
                 (lex-first (ml-cdr lhs)
                            (ml-cdr rhs)))
                ((3)
                 3))))))
    lex-first))







;; Select elements of a list which pass some test.
(define zulu-select
  (lambda (test lst)
    (define select-a
      (lambda (ac lst)
        (if (ml-null? lst)
            (xreverse! ac)
            (select-a
             (let ((head (ml-car lst)))
               (if (test head)
                   (ml-cons head ac)
                   ac))
             (ml-cdr lst)))))
    (select-a (ml-empty) lst)))

(define (xreverse! lst)
  (letrec ((rotate
            (lambda (fo fum)
              (let ((next (ml-cdr fo)))
                (ml-set-cdr! fo fum)
                (if (ml-null? next)
                    fo
                    (rotate next fo))))))
    (if (ml-null? lst)
          (ml-empty)
          (rotate lst (ml-empty)))))

;; Select elements of a list which pass some test and map a function
;; over the result.  Note, only efficiency prevents this from being the
;; composition of select and map.
(define select-map
  (lambda (test func lst)
    (define select-a
      (lambda (ac lst)
        (if (ml-null? lst)
            (xreverse! ac)
            (select-a
             (let ((head (ml-car lst)))
               (if (test head)
                   (ml-cons (func head)
                         ac)
                   ac))
             (ml-cdr lst)))))
    (select-a (ml-empty) lst)))



;; This version of map-and tail-recurses on the last test.
(define map-and
  (lambda (proc lst)
    (if (ml-null? lst)
        #t
        (letrec ((drudge
                  (lambda (lst)
                    (let ((rest (ml-cdr lst)))
                      (if (ml-null? rest)
                          (proc (ml-car lst))
                          (and (proc (ml-car lst))
                               (drudge rest)))))))
          (drudge lst)))))

(define (maps-1 source target pas new)
  (let ((scmp (lattice->cmp source))
        (tcmp (lattice->cmp target)))
    (let ((less
           (select-map
            (lambda (p)
              (= 0
                   (scmp (binding-source p) new)))
            binding-target
            pas))
          (more
           (select-map
            (lambda (p)
              (= 2
                   (scmp (binding-source p) new)))
            binding-target
            pas)))
      (zulu-select
       (lambda (t)
         (and
          (map-and
           (lambda (t2)
             (code-member? (tcmp t2 t) lattice-less-equal))
           less)
          (map-and
           (lambda (t2)
             (code-member? (tcmp t2 t) lattice-more-equal))
           more)))
       (lattice->elements target)))))

(define (maps-rest source target pas rest to-1 to-collect)
  (if (ml-null? rest)
      (to-1 pas)
      (let ((next (ml-car rest))
            (rest (ml-cdr rest)))
        (to-collect
         (ml-map
          (lambda (x)
            (maps-rest source target
                       (ml-cons
                        (make-binding next x)
                        pas)
                       rest
                       to-1
                       to-collect))
          (maps-1 source target pas next))))))

(define (maps source target)
  (make-lattice
   (maps-rest source
              target
              (ml-empty)
              (lattice->elements source)
              (lambda (x) (ml-cons (ml-map binding-target x) (ml-empty)))
              (lambda (x) (ml-concatenate x)))
   (lexico (lattice->cmp target))))

(define (count-maps source target)
  (maps-rest source
             target
             (ml-empty)
             (lattice->elements source)
             (lambda (x) 1)
             sum))

(define (sum lst)
  (if (ml-null? lst)
      0
      (+ (ml-car lst) (sum (ml-cdr lst)))))

(define (run k)
  (let* ((l2
          (make-lattice lattice-base-elements
                        (lambda (lhs rhs)
                          (case lhs
                            ((0)
                             (case rhs
                               ((0)
                                1)
                               ((1)
                                0)
                               (else
                                (unreachable))))
                            ((1)
                             (case rhs
                               ((0)
                                2)
                               ((1)
                                1)
                               (else
                                (unreachable))))
                            (else
                             (unreachable))))))
         (l3 (maps l2 l2))
         (l4 (maps l3 l3)))
    (count-maps l2 l2)
    (count-maps l3 l3)
    (count-maps l2 l3)
    (count-maps l3 l2)
    (case k
      ((33) (count-maps l3 l3))
      ((44) (count-maps l4 l4))
      ((45) (let ((l5 (maps l4 l4)))
              (count-maps l4 l5)))
      ((54) (let ((l5 (maps l4 l4)))
              (count-maps l5 l4)))
      ((55) (let ((l5 (maps l4 l4)))
              (count-maps l5 l5)))
      (else (unreachable)))))

(define input0 (native-input-i64 (ann 0 I32)))
(: bench (-> I64 I64))
(define (bench count) (if (<= count 0) (unreachable)
  (let loop ((i 1) (result (run (hide count input0))))
    (if (< i count) (loop (+ i 1) (run (hide count input0))) result))))
(unit)
