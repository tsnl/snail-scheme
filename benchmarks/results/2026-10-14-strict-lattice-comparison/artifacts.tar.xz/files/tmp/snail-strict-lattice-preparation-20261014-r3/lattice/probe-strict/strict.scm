(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define-data (MutableList T)
  (ml-empty)
  (ml-node (head T ml-car) (tail (Ref (MutableList T)) ml-tail-cell)))
(define-data (Lattice T)
  (make-lattice (elements (MutableList T) lattice->elements)
                (compare (-> T T I64) lattice->cmp)))
(define-data (Binding S T)
  (make-binding (source S binding-source) (target T binding-target)))
(: ml-cons (All (T) (-> T (MutableList T) (MutableList T))))
(define (ml-cons head tail) (ml-node head (ref tail)))
(: ml-null? (All (T) (-> (MutableList T) Bool)))
(define (ml-null? values)
  (match values ((ml-empty) #t) ((ml-node head tail) #f)))
(: ml-cdr (All (T) (-> (MutableList T) (MutableList T))))
(define (ml-cdr values) (ref-get (ml-tail-cell values)))
(: ml-set-cdr! (All (T) (-> (MutableList T) (MutableList T) Unit)))
(define (ml-set-cdr! values tail) (ref-set! (ml-tail-cell values) tail))
(define-syntax case
  (syntax-rules (else)
    ((_ key) (unreachable))
    ((_ key (else body ...)) (begin body ...))
    ((_ key ((datum ...) body ...) rest ...)
     (let ((value key))
       (if (or (= value datum) ...) (begin body ...) (case value rest ...))))))
;; Each proper-list node has an explicit mutable tail. Selection
;; reverses only its fresh accumulator spine; element identities stay shared.
(: ml-map (All (A B) (-> (-> A B) (MutableList A) (MutableList B))))
(define (ml-map procedure values)
  (if (ml-null? values) (ml-empty)
      (let ((head (procedure (ml-car values))))
        (ml-cons head (ml-map procedure (ml-cdr values))))))
(: ml-append (All (T) (-> (MutableList T) (MutableList T) (MutableList T))))
(define (ml-append first last)
  (if (ml-null? first) last
      (ml-cons (ml-car first) (ml-append (ml-cdr first) last))))
(: ml-concatenate (All (T) (-> (MutableList (MutableList T)) (MutableList T))))
(define (ml-concatenate lists)
  (if (ml-null? lists) (ml-empty)
      (if (ml-null? (ml-cdr lists)) (ml-car lists)
          (ml-append (ml-car lists) (ml-concatenate (ml-cdr lists))))))
(: code-member? (-> I64 (MutableList I64) Bool))
(define (code-member? value codes)
  (and (not (ml-null? codes))
       (or (= value (ml-car codes)) (code-member? value (ml-cdr codes)))))
;; The original quoted lists have constant lifetime and precede timing.
;; Point codes: low=0, high=1. Order codes: less=0, equal=1, more=2, uncomparable=3.
(define lattice-base-elements (ml-cons 0 (ml-cons 1 (ml-empty))))
(define lattice-less-equal (ml-cons 0 (ml-cons 1 (ml-empty))))
(define lattice-more-equal (ml-cons 2 (ml-cons 1 (ml-empty))))
(: lexico (All (T)
  (-> (-> T T I64) (-> (MutableList T) (MutableList T) I64))))
(: zulu-select (All (T)
  (-> (-> T Bool) (MutableList T) (MutableList T))))
(: xreverse! (All (T) (-> (MutableList T) (MutableList T))))
(: select-map (All (A B)
  (-> (-> A Bool) (-> A B) (MutableList A) (MutableList B))))
(: map-and (All (T) (-> (-> T Bool) (MutableList T) Bool)))
(: maps-1 (All (S T)
  (-> (Lattice S) (Lattice T) (MutableList (Binding S T)) S (MutableList T))))
(: maps-rest (All (S T R)
  (-> (Lattice S) (Lattice T) (MutableList (Binding S T)) (MutableList S)
      (-> (MutableList (Binding S T)) R) (-> (MutableList R) R) R)))
(: maps (All (S T) (-> (Lattice S) (Lattice T) (Lattice (MutableList T)))))
(: count-maps (All (S T) (-> (Lattice S) (Lattice T) I64)))
(: sum (-> (MutableList I64) I64))
(: run (-> I64 I64))
;;; LATTICE -- Obtained from Andrew Wright.


;; Given a comparison routine that returns one of
;;       less
;;       more
;;       equal
;;       uncomparable
;; return a new comparison routine that applies to sequences.
(define lexico
  (lambda (base)
    (define lex-fixed
      (lambda (fixed lhs rhs)
        (define check
          (lambda (lhs rhs)
            (if (ml-null? lhs)
                fixed
                (let ((probe
                       (base (ml-car lhs)
                             (ml-car rhs))))
                  (if (or (= probe 1)
                          (= probe fixed))
                      (check (ml-cdr lhs)
                             (ml-cdr rhs))
                      3)))))
        (check lhs rhs)))
    (define lex-first
      (lambda (lhs rhs)
        (if (ml-null? lhs)
            1
            (let ((probe
                   (base (ml-car lhs)
                         (ml-car rhs))))
              (case probe
                ((0 2)
                 (lex-fixed probe
                            (ml-cdr lhs)
                            (ml-cdr rhs)))
                ((1)
                 (lex-first (ml-cdr lhs)
                            (ml-cdr rhs)))
                ((3)
                 3))))))
    lex-first))







;; Select elements of a list which pass some test.
(define zulu-select
  (lambda (test lst)
    (define select-a
      (lambda (ac lst)
        (if (ml-null? lst)
            (xreverse! ac)
            (select-a
             (let ((head (ml-car lst)))
               (if (test head)
                   (ml-cons head ac)
                   ac))
             (ml-cdr lst)))))
    (select-a (ml-empty) lst)))

(define (xreverse! lst)
  (letrec ((rotate
            (lambda (fo fum)
              (let ((next (ml-cdr fo)))
                (ml-set-cdr! fo fum)
                (if (ml-null? next)
                    fo
                    (rotate next fo))))))
    (if (ml-null? lst)
          (ml-empty)
          (rotate lst (ml-empty)))))

;; Select elements of a list which pass some test and map a function
;; over the result.  Note, only efficiency prevents this from being the
;; composition of select and map.
(define select-map
  (lambda (test func lst)
    (define select-a
      (lambda (ac lst)
        (if (ml-null? lst)
            (xreverse! ac)
            (select-a
             (let ((head (ml-car lst)))
               (if (test head)
                   (ml-cons (func head)
                         ac)
                   ac))
             (ml-cdr lst)))))
    (select-a (ml-empty) lst)))



;; This version of map-and tail-recurses on the last test.
(define map-and
  (lambda (proc lst)
    (if (ml-null? lst)
        #t
        (letrec ((drudge
                  (lambda (lst)
                    (let ((rest (ml-cdr lst)))
                      (if (ml-null? rest)
                          (proc (ml-car lst))
                          (and (proc (ml-car lst))
                               (drudge rest)))))))
          (drudge lst)))))

(define (maps-1 source target pas new)
  (let ((scmp (lattice->cmp source))
        (tcmp (lattice->cmp target)))
    (let ((less
           (select-map
            (lambda (p)
              (= 0
                   (scmp (binding-source p) new)))
            binding-target
            pas))
          (more
           (select-map
            (lambda (p)
              (= 2
                   (scmp (binding-source p) new)))
            binding-target
            pas)))
      (zulu-select
       (lambda (t)
         (and
          (map-and
           (lambda (t2)
             (code-member? (tcmp t2 t) lattice-less-equal))
           less)
          (map-and
           (lambda (t2)
             (code-member? (tcmp t2 t) lattice-more-equal))
           more)))
       (lattice->elements target)))))

(define (maps-rest source target pas rest to-1 to-collect)
  (if (ml-null? rest)
      (to-1 pas)
      (let ((next (ml-car rest))
            (rest (ml-cdr rest)))
        (to-collect
         (ml-map
          (lambda (x)
            (maps-rest source target
                       (ml-cons
                        (make-binding next x)
                        pas)
                       rest
                       to-1
                       to-collect))
          (maps-1 source target pas next))))))

(define (maps source target)
  (make-lattice
   (maps-rest source
              target
              (ml-empty)
              (lattice->elements source)
              (lambda (x) (ml-cons (ml-map binding-target x) (ml-empty)))
              (lambda (x) (ml-concatenate x)))
   (lexico (lattice->cmp target))))

(define (count-maps source target)
  (maps-rest source
             target
             (ml-empty)
             (lattice->elements source)
             (lambda (x) 1)
             sum))

(define (sum lst)
  (if (ml-null? lst)
      0
      (+ (ml-car lst) (sum (ml-cdr lst)))))

(define (run k)
  (let* ((l2
          (make-lattice lattice-base-elements
                        (lambda (lhs rhs)
                          (case lhs
                            ((0)
                             (case rhs
                               ((0)
                                1)
                               ((1)
                                0)
                               (else
                                (unreachable))))
                            ((1)
                             (case rhs
                               ((0)
                                2)
                               ((1)
                                1)
                               (else
                                (unreachable))))
                            (else
                             (unreachable))))))
         (l3 (maps l2 l2))
         (l4 (maps l3 l3)))
    (count-maps l2 l2)
    (count-maps l3 l3)
    (count-maps l2 l3)
    (count-maps l3 l2)
    (case k
      ((33) (count-maps l3 l3))
      ((44) (count-maps l4 l4))
      ((45) (let ((l5 (maps l4 l4)))
              (count-maps l4 l5)))
      ((54) (let ((l5 (maps l4 l4)))
              (count-maps l5 l4)))
      ((55) (let ((l5 (maps l4 l4)))
              (count-maps l5 l5)))
      (else (unreachable)))))

(define (probe-base) (make-lattice lattice-base-elements
                        (lambda (lhs rhs)
                          (case lhs
                            ((0)
                             (case rhs
                               ((0)
                                1)
                               ((1)
                                0)
                               (else
                                (unreachable))))
                            ((1)
                             (case rhs
                               ((0)
                                2)
                               ((1)
                                1)
                               (else
                                (unreachable))))
                            (else
                             (unreachable))))))
(define-extern emit-i64 "probe" "emit" (-> I64 Unit))
(define emit-point emit-i64)
(define emit-order emit-i64)
(define (probe-order value) value)
(define (ml-same? left right)
  (if (ml-null? left) (ml-null? right)
      (and (not (ml-null? right)) (ref-eq? (ml-tail-cell left) (ml-tail-cell right)))))
(: probe (-> I64 I64))
(define (emit-bool value) (emit-i64 (if value 1 0)))
(define (probe-list-length values)
  (if (ml-null? values) 0 (+ 1 (probe-list-length (ml-cdr values)))))
(define (emit-sequence emit-element values)
  (emit-i64 (probe-list-length values))
  (let loop ((values values))
    (unless (ml-null? values)
      (emit-element (ml-car values)) (loop (ml-cdr values)))))
(define (emit-points values) (emit-sequence emit-point values))
(define (emit-assignments values) (emit-sequence emit-points values))
(define (emit-i64s values) (emit-sequence emit-i64 values))
(define (emit-comparisons lattice)
  (let ((compare (lattice->cmp lattice)) (elements (lattice->elements lattice)))
    (let rows ((left elements))
      (unless (ml-null? left)
        (let columns ((right elements))
          (unless (ml-null? right)
            (emit-order (compare (ml-car left) (ml-car right)))
            (columns (ml-cdr right))))
        (rows (ml-cdr left))))))
(define (probe-number-compare left right)
  (if (< left right) (probe-order 0)
      (if (= left right) (probe-order 1) (probe-order 2))))
(define (probe-diamond-compare left right)
  (cond ((= left right) (probe-order 1))
        ((or (= left 0) (= right 3)) (probe-order 0))
        ((or (= left 3) (= right 0)) (probe-order 2))
        (else (probe-order 3))))
(define (probe-complete-values)
  (let* ((l2 (probe-base)) (l3 (maps l2 l2)) (l4 (maps l3 l3)))
    (emit-points (lattice->elements l2))
    (emit-assignments (lattice->elements l3))
    (emit-sequence emit-assignments (lattice->elements l4))
    (emit-comparisons l3) (emit-comparisons l4)
    (emit-i64 (count-maps l2 l2)) (emit-i64 (count-maps l3 l3))
    (emit-i64 (count-maps l2 l3)) (emit-i64 (count-maps l3 l2))))
(define (probe-number-maps source target)
  (emit-sequence emit-i64s (lattice->elements (maps source target)))
  (emit-i64 (count-maps source target)))
(define (probe-boundaries)
  (let* ((none (make-lattice (ml-empty) probe-number-compare))
         (two (make-lattice (ml-cons 0 (ml-cons 1 (ml-empty))) probe-number-compare))
         (reverse (make-lattice (ml-cons 1 (ml-cons 0 (ml-empty))) probe-number-compare))
         (diamond (make-lattice (ml-cons 3 (ml-cons 2 (ml-cons 0 (ml-cons 1 (ml-empty)))))
                                probe-diamond-compare)))
    (probe-number-maps none none) (probe-number-maps none two)
    (probe-number-maps two none) (probe-number-maps reverse two)
    (probe-number-maps diamond two)))
(define (probe-source-compare left right)
  (emit-i64 20) (emit-i64 left) (emit-i64 right)
  (probe-number-compare left right))
(define (probe-target-compare left right)
  (emit-i64 21) (emit-i64 left) (emit-i64 right)
  (probe-number-compare left right))
(define (probe-enumeration-order)
  (let ((source (make-lattice (ml-cons 1 (ml-cons 0 (ml-empty))) probe-source-compare))
        (target (make-lattice (ml-cons 0 (ml-cons 1 (ml-empty))) probe-target-compare)))
    (probe-number-maps source target)))
(define (probe-select-order)
  (let* ((a (ml-cons 1 (ml-empty))) (b (ml-cons 2 (ml-empty))) (c (ml-cons 3 (ml-empty)))
         (source (ml-cons a (ml-cons b (ml-cons c (ml-empty)))))
         (selected (zulu-select
           (lambda (value) (emit-i64 10) (emit-i64 (ml-car value))
             (= (remainder (ml-car value) 2) 1)) source)))
    (emit-sequence emit-i64s selected) (emit-sequence emit-i64s source)
    (emit-bool (ml-same? (ml-car selected) a))
    (emit-bool (ml-same? (ml-car (ml-cdr selected)) c))
    (emit-bool (not (ml-same? selected source)))
    (emit-bool (not (ml-same? (ml-cdr selected) (ml-cdr (ml-cdr source)))))))
(define (probe-map-order)
  (let ((source (ml-cons 1 (ml-cons 2 (ml-cons 3 (ml-empty))))))
    (emit-i64s (select-map
      (lambda (value) (emit-i64 11) (emit-i64 value) (not (= value 2)))
      (lambda (value) (emit-i64 12) (emit-i64 value) (+ value 10)) source))
    (emit-bool (map-and
      (lambda (value) (emit-i64 13) (emit-i64 value) (< value 2)) source))
    (emit-bool (map-and (lambda (value) (unreachable)) (ann (ml-empty) (MutableList I64))))
    (emit-bool (map-and
      (lambda (value) (emit-i64 14) (emit-i64 value) #t) (ml-cons 3 (ml-empty))))))
(define (probe-reverse-identity)
  (let* ((first (ml-cons 1 (ml-cons 2 (ml-cons 3 (ml-empty)))))
         (second (ml-cdr first)) (third (ml-cdr second)) (result (xreverse! first)))
    (emit-i64s result)
    (emit-bool (ml-same? result third)) (emit-bool (ml-same? (ml-cdr third) second))
    (emit-bool (ml-same? (ml-cdr second) first)) (emit-bool (ml-null? (ml-cdr first))))
  (let ((single (ml-cons 4 (ml-empty)))) (emit-bool (ml-same? single (xreverse! single))))
  (emit-bool (ml-null? (xreverse! (ann (ml-empty) (MutableList I64))))))
(define (probe-append-identity)
  (let* ((prefix (ml-cons 1 (ml-empty))) (tail (ml-cons 2 (ml-empty)))
         (joined (ml-concatenate (ml-cons prefix (ml-cons tail (ml-empty)))))
         (copied (ml-concatenate (ml-cons prefix (ml-cons (ml-empty) (ml-empty))))))
    (emit-i64s joined) (emit-bool (ml-same? (ml-cdr joined) tail))
    (emit-bool (not (ml-same? joined prefix)))
    (emit-bool (not (ml-same? copied prefix)))
    (emit-bool (ml-same? tail (ml-concatenate (ml-cons tail (ml-empty)))))
    (emit-bool (ml-same? tail (ml-concatenate (ml-cons (ml-empty) (ml-cons tail (ml-empty))))))
    (emit-bool (ml-null? (ml-concatenate (ann (ml-empty) (MutableList (MutableList I64))))))))
(define (probe command)
  (cond ((= command 0) (probe-complete-values))
        ((= command 1) (probe-boundaries))
        ((= command 2) (probe-enumeration-order))
        (else (probe-select-order) (probe-map-order)
              (probe-reverse-identity) (probe-append-identity)))
  1)
