(import (chezscheme))
;;; LATTICE -- Obtained from Andrew Wright.


;; Given a comparison routine that returns one of
;;       less
;;       more
;;       equal
;;       uncomparable
;; return a new comparison routine that applies to sequences.
(define lexico
  (lambda (base)
    (define lex-fixed
      (lambda (fixed lhs rhs)
        (define check
          (lambda (lhs rhs)
            (if (null? lhs)
                fixed
                (let ((probe
                       (base (car lhs)
                             (car rhs))))
                  (if (or (eq? probe 'equal)
                          (eq? probe fixed))
                      (check (cdr lhs)
                             (cdr rhs))
                      'uncomparable)))))
        (check lhs rhs)))
    (define lex-first
      (lambda (lhs rhs)
        (if (null? lhs)
            'equal
            (let ((probe
                   (base (car lhs)
                         (car rhs))))
              (case probe
                ((less more)
                 (lex-fixed probe
                            (cdr lhs)
                            (cdr rhs)))
                ((equal)
                 (lex-first (cdr lhs)
                            (cdr rhs)))
                ((uncomparable)
                 'uncomparable))))))
    lex-first))

(define (make-lattice elem-list cmp-func)
  (cons elem-list cmp-func))

(define lattice->elements car)

(define lattice->cmp cdr)

;; Select elements of a list which pass some test.
(define zulu-select
  (lambda (test lst)
    (define select-a
      (lambda (ac lst)
        (if (null? lst)
            (xreverse! ac)
            (select-a
             (let ((head (car lst)))
               (if (test head)
                   (cons head ac)
                   ac))
             (cdr lst)))))
    (select-a '() lst)))

(define xreverse!
  (letrec ((rotate
            (lambda (fo fum)
              (let ((next (cdr fo)))
                (set-cdr! fo fum)
                (if (null? next)
                    fo
                    (rotate next fo))))))
    (lambda (lst)
      (if (null? lst)
          '()
          (rotate lst '())))))

;; Select elements of a list which pass some test and map a function
;; over the result.  Note, only efficiency prevents this from being the
;; composition of select and map.
(define select-map
  (lambda (test func lst)
    (define select-a
      (lambda (ac lst)
        (if (null? lst)
            (xreverse! ac)
            (select-a
             (let ((head (car lst)))
               (if (test head)
                   (cons (func head)
                         ac)
                   ac))
             (cdr lst)))))
    (select-a '() lst)))



;; This version of map-and tail-recurses on the last test.
(define map-and
  (lambda (proc lst)
    (if (null? lst)
        #t
        (letrec ((drudge
                  (lambda (lst)
                    (let ((rest (cdr lst)))
                      (if (null? rest)
                          (proc (car lst))
                          (and (proc (car lst))
                               (drudge rest)))))))
          (drudge lst)))))

(define (maps-1 source target pas new)
  (let ((scmp (lattice->cmp source))
        (tcmp (lattice->cmp target)))
    (let ((less
           (select-map
            (lambda (p)
              (eq? 'less
                   (scmp (car p) new)))
            cdr
            pas))
          (more
           (select-map
            (lambda (p)
              (eq? 'more
                   (scmp (car p) new)))
            cdr
            pas)))
      (zulu-select
       (lambda (t)
         (and
          (map-and
           (lambda (t2)
             (memq (tcmp t2 t) '(less equal)))
           less)
          (map-and
           (lambda (t2)
             (memq (tcmp t2 t) '(more equal)))
           more)))
       (lattice->elements target)))))

(define (maps-rest source target pas rest to-1 to-collect)
  (if (null? rest)
      (to-1 pas)
      (let ((next (car rest))
            (rest (cdr rest)))
        (to-collect
         (map
          (lambda (x)
            (maps-rest source target
                       (cons
                        (cons next x)
                        pas)
                       rest
                       to-1
                       to-collect))
          (maps-1 source target pas next))))))

(define (maps source target)
  (make-lattice
   (maps-rest source
              target
              '()
              (lattice->elements source)
              (lambda (x) (list (map cdr x)))
              (lambda (x) (apply append x)))
   (lexico (lattice->cmp target))))

(define (count-maps source target)
  (maps-rest source
             target
             '()
             (lattice->elements source)
             (lambda (x) 1)
             sum))

(define (sum lst)
  (if (null? lst)
      0
      (+ (car lst) (sum (cdr lst)))))

(define (run k)
  (let* ((l2
          (make-lattice '(low high)
                        (lambda (lhs rhs)
                          (case lhs
                            ((low)
                             (case rhs
                               ((low)
                                'equal)
                               ((high)
                                'less)
                               (else
                                (error 'make-lattice "base" rhs))))
                            ((high)
                             (case rhs
                               ((low)
                                'more)
                               ((high)
                                'equal)
                               (else
                                (error 'make-lattice "base" rhs))))
                            (else
                             (error 'make-lattice "base" lhs))))))
         (l3 (maps l2 l2))
         (l4 (maps l3 l3)))
    (count-maps l2 l2)
    (count-maps l3 l3)
    (count-maps l2 l3)
    (count-maps l3 l2)
    (case k
      ((33) (count-maps l3 l3))
      ((44) (count-maps l4 l4))
      ((45) (let ((l5 (maps l4 l4)))
              (count-maps l4 l5)))
      ((54) (let ((l5 (maps l4 l4)))
              (count-maps l5 l4)))
      ((55) (let ((l5 (maps l4 l4)))
              (count-maps l5 l5)))
      (else (error "run: unanticipated problem size" k)))))

(define (probe-base) (make-lattice '(low high)
                        (lambda (lhs rhs)
                          (case lhs
                            ((low)
                             (case rhs
                               ((low)
                                'equal)
                               ((high)
                                'less)
                               (else
                                (error 'make-lattice "base" rhs))))
                            ((high)
                             (case rhs
                               ((low)
                                'more)
                               ((high)
                                'equal)
                               (else
                                (error 'make-lattice "base" rhs))))
                            (else
                             (error 'make-lattice "base" lhs))))))
(define (emit-i64 value) (write value) (newline))
(define-syntax ann (syntax-rules () ((_ value type) value)))
(define ml-cons cons)
(define (ml-empty) '())
(define ml-null? null?)
(define ml-car car)
(define ml-cdr cdr)
(define ml-same? eq?)
(define (ml-concatenate values) (apply append values))
(define (emit-point value) (emit-i64 (case value ((low) 0) ((high) 1))))
(define (emit-order value)
  (emit-i64 (case value ((less) 0) ((equal) 1) ((more) 2) ((uncomparable) 3))))
(define (probe-order value) (list-ref '(less equal more uncomparable) value))
(define (unreachable) (error 'probe "unexpected evaluation"))
(define (emit-bool value) (emit-i64 (if value 1 0)))
(define (probe-list-length values)
  (if (ml-null? values) 0 (+ 1 (probe-list-length (ml-cdr values)))))
(define (emit-sequence emit-element values)
  (emit-i64 (probe-list-length values))
  (let loop ((values values))
    (unless (ml-null? values)
      (emit-element (ml-car values)) (loop (ml-cdr values)))))
(define (emit-points values) (emit-sequence emit-point values))
(define (emit-assignments values) (emit-sequence emit-points values))
(define (emit-i64s values) (emit-sequence emit-i64 values))
(define (emit-comparisons lattice)
  (let ((compare (lattice->cmp lattice)) (elements (lattice->elements lattice)))
    (let rows ((left elements))
      (unless (ml-null? left)
        (let columns ((right elements))
          (unless (ml-null? right)
            (emit-order (compare (ml-car left) (ml-car right)))
            (columns (ml-cdr right))))
        (rows (ml-cdr left))))))
(define (probe-number-compare left right)
  (if (< left right) (probe-order 0)
      (if (= left right) (probe-order 1) (probe-order 2))))
(define (probe-diamond-compare left right)
  (cond ((= left right) (probe-order 1))
        ((or (= left 0) (= right 3)) (probe-order 0))
        ((or (= left 3) (= right 0)) (probe-order 2))
        (else (probe-order 3))))
(define (probe-complete-values)
  (let* ((l2 (probe-base)) (l3 (maps l2 l2)) (l4 (maps l3 l3)))
    (emit-points (lattice->elements l2))
    (emit-assignments (lattice->elements l3))
    (emit-sequence emit-assignments (lattice->elements l4))
    (emit-comparisons l3) (emit-comparisons l4)
    (emit-i64 (count-maps l2 l2)) (emit-i64 (count-maps l3 l3))
    (emit-i64 (count-maps l2 l3)) (emit-i64 (count-maps l3 l2))))
(define (probe-number-maps source target)
  (emit-sequence emit-i64s (lattice->elements (maps source target)))
  (emit-i64 (count-maps source target)))
(define (probe-boundaries)
  (let* ((none (make-lattice (ml-empty) probe-number-compare))
         (two (make-lattice (ml-cons 0 (ml-cons 1 (ml-empty))) probe-number-compare))
         (reverse (make-lattice (ml-cons 1 (ml-cons 0 (ml-empty))) probe-number-compare))
         (diamond (make-lattice (ml-cons 3 (ml-cons 2 (ml-cons 0 (ml-cons 1 (ml-empty)))))
                                probe-diamond-compare)))
    (probe-number-maps none none) (probe-number-maps none two)
    (probe-number-maps two none) (probe-number-maps reverse two)
    (probe-number-maps diamond two)))
(define (probe-source-compare left right)
  (emit-i64 20) (emit-i64 left) (emit-i64 right)
  (probe-number-compare left right))
(define (probe-target-compare left right)
  (emit-i64 21) (emit-i64 left) (emit-i64 right)
  (probe-number-compare left right))
(define (probe-enumeration-order)
  (let ((source (make-lattice (ml-cons 1 (ml-cons 0 (ml-empty))) probe-source-compare))
        (target (make-lattice (ml-cons 0 (ml-cons 1 (ml-empty))) probe-target-compare)))
    (probe-number-maps source target)))
(define (probe-select-order)
  (let* ((a (ml-cons 1 (ml-empty))) (b (ml-cons 2 (ml-empty))) (c (ml-cons 3 (ml-empty)))
         (source (ml-cons a (ml-cons b (ml-cons c (ml-empty)))))
         (selected (zulu-select
           (lambda (value) (emit-i64 10) (emit-i64 (ml-car value))
             (= (remainder (ml-car value) 2) 1)) source)))
    (emit-sequence emit-i64s selected) (emit-sequence emit-i64s source)
    (emit-bool (ml-same? (ml-car selected) a))
    (emit-bool (ml-same? (ml-car (ml-cdr selected)) c))
    (emit-bool (not (ml-same? selected source)))
    (emit-bool (not (ml-same? (ml-cdr selected) (ml-cdr (ml-cdr source)))))))
(define (probe-map-order)
  (let ((source (ml-cons 1 (ml-cons 2 (ml-cons 3 (ml-empty))))))
    (emit-i64s (select-map
      (lambda (value) (emit-i64 11) (emit-i64 value) (not (= value 2)))
      (lambda (value) (emit-i64 12) (emit-i64 value) (+ value 10)) source))
    (emit-bool (map-and
      (lambda (value) (emit-i64 13) (emit-i64 value) (< value 2)) source))
    (emit-bool (map-and (lambda (value) (unreachable)) (ann (ml-empty) (MutableList I64))))
    (emit-bool (map-and
      (lambda (value) (emit-i64 14) (emit-i64 value) #t) (ml-cons 3 (ml-empty))))))
(define (probe-reverse-identity)
  (let* ((first (ml-cons 1 (ml-cons 2 (ml-cons 3 (ml-empty)))))
         (second (ml-cdr first)) (third (ml-cdr second)) (result (xreverse! first)))
    (emit-i64s result)
    (emit-bool (ml-same? result third)) (emit-bool (ml-same? (ml-cdr third) second))
    (emit-bool (ml-same? (ml-cdr second) first)) (emit-bool (ml-null? (ml-cdr first))))
  (let ((single (ml-cons 4 (ml-empty)))) (emit-bool (ml-same? single (xreverse! single))))
  (emit-bool (ml-null? (xreverse! (ann (ml-empty) (MutableList I64))))))
(define (probe-append-identity)
  (let* ((prefix (ml-cons 1 (ml-empty))) (tail (ml-cons 2 (ml-empty)))
         (joined (ml-concatenate (ml-cons prefix (ml-cons tail (ml-empty)))))
         (copied (ml-concatenate (ml-cons prefix (ml-cons (ml-empty) (ml-empty))))))
    (emit-i64s joined) (emit-bool (ml-same? (ml-cdr joined) tail))
    (emit-bool (not (ml-same? joined prefix)))
    (emit-bool (not (ml-same? copied prefix)))
    (emit-bool (ml-same? tail (ml-concatenate (ml-cons tail (ml-empty)))))
    (emit-bool (ml-same? tail (ml-concatenate (ml-cons (ml-empty) (ml-cons tail (ml-empty))))))
    (emit-bool (ml-null? (ml-concatenate (ann (ml-empty) (MutableList (MutableList I64))))))))
(define (probe command)
  (cond ((= command 0) (probe-complete-values))
        ((= command 1) (probe-boundaries))
        ((= command 2) (probe-enumeration-order))
        (else (probe-select-order) (probe-map-order)
              (probe-reverse-identity) (probe-append-identity)))
  1)
(probe (read))
