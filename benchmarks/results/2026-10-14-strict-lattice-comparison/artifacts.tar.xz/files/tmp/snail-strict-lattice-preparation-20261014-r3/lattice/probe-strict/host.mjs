import fs from 'node:fs';
import assert from 'node:assert/strict';
const [artifact, command] = process.argv.slice(2);
const values = [];
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact),
  {probe: {emit: value => values.push(Number(value))}});
instance.exports.main();
assert.equal(instance.exports.probe(BigInt(command)), 1n);
console.log(JSON.stringify(values));
