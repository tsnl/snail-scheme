(module
 (rec
  (type $type94 (sub (struct)))
  (type $type88 (sub (struct)))
  (type $type82 (sub (struct)))
  (type $type76 (sub (struct)))
  (type $type71 (sub (struct)))
  (type $type65 (sub (struct)))
  (type $type59 (sub (struct)))
  (type $type53 (sub (struct)))
  (type $type48 (sub (struct)))
  (type $type42 (sub (struct)))
  (type $type31 (sub (struct)))
  (type $type26 (sub (struct)))
  (type $type37 (sub (struct)))
  (type $13 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $environment250 (struct (field (ref $type161)) (field (ref $type42))))
  (type $environment249 (struct (field (ref $type161)) (field (ref $type42))))
  (type $16 (func (param (ref $type186) (ref $type187) i32 i32 (ref $type53) (ref $type94)) (result (ref $type53))))
  (type $call186 (func (param (ref struct) (ref $type93)) (result i32)))
  (type $type96 (sub $type94 (struct (field (ref $type93)) (field (ref $type97)))))
  (type $type97 (struct (field (ref $type94))))
  (type $type93 (struct (field (ref $type42)) (field (ref $type42))))
  (type $environment248 (struct (field (ref $type161)) (field (ref $type53)) (field (ref $type53))))
  (type $environment247 (struct (field (ref $type42)) (field (ref $type161))))
  (type $type187 (struct))
  (type $type186 (struct (field (ref $call186)) (field (ref struct))))
  (type $environment242 (struct (field (ref $type42)) (field (ref $type161))))
  (type $environment239 (struct (field (ref $type201)) (field (ref $type201)) (field (ref $type94)) (field (ref $type225)) (field (ref $type139)) (field (ref $type42)) (field (ref $type53))))
  (type $call224 (func (param (ref $type201) (ref $type201) (ref $type94) (ref $type53) (ref $type225) (ref $type139)) (result i64)))
  (type $environment235 (struct (field (ref $type159)) (field (ref $type31))))
  (type $environment234 (struct (field (ref $type159)) (field (ref $type31))))
  (type $30 (func (param (ref $type183) (ref $type184) i32 i32 (ref $type42) (ref $type88)) (result (ref $type42))))
  (type $call183 (func (param (ref struct) (ref $type87)) (result i32)))
  (type $type90 (sub $type88 (struct (field (ref $type87)) (field (ref $type91)))))
  (type $type91 (struct (field (ref $type88))))
  (type $type87 (struct (field (ref $type42)) (field (ref $type31))))
  (type $environment233 (struct (field (ref $type159)) (field (ref $type42)) (field (ref $type42))))
  (type $environment232 (struct (field (ref $type42)) (field (ref $type161))))
  (type $type184 (struct))
  (type $type183 (struct (field (ref $call183)) (field (ref struct))))
  (type $environment227 (struct (field (ref $type42)) (field (ref $type161))))
  (type $environment224 (struct (field (ref $type201)) (field (ref $type199)) (field (ref $type88)) (field (ref $type223)) (field (ref $type139)) (field (ref $type42)) (field (ref $type53))))
  (type $call222 (func (param (ref $type201) (ref $type199) (ref $type88) (ref $type53) (ref $type223) (ref $type139)) (result i64)))
  (type $call146 (func (param (ref $type147) (ref $type53)) (result (ref $type26))))
  (type $43 (func (param (ref $type100) i32 i32 (ref $type53) (ref $type53)) (result (ref $type53))))
  (type $44 (func (param (ref $type100) i32 i32 (ref $type53)) (result i32)))
  (type $environment217 (struct (field (ref $type161)) (field (ref $type42))))
  (type $environment214 (struct (field (ref $type161)) (field (ref $type42))))
  (type $47 (func (param i32 i32 (ref $type53) (ref $type53)) (result (ref $type53))))
  (type $48 (func (param (ref $type180) (ref $type181) i32 i32 (ref $type53) (ref $type82)) (result (ref $type53))))
  (type $call180 (func (param (ref struct) (ref $type81)) (result i32)))
  (type $type84 (sub $type82 (struct (field (ref $type81)) (field (ref $type85)))))
  (type $type85 (struct (field (ref $type82))))
  (type $type81 (struct (field (ref $type31)) (field (ref $type42))))
  (type $call147 (func (param (ref struct) (ref $type42)) (result i64)))
  (type $environment213 (struct (field (ref $type161)) (field (ref $type53)) (field (ref $type53))))
  (type $environment212 (struct (field (ref $type31)) (field (ref $type159))))
  (type $type181 (struct))
  (type $type180 (struct (field (ref $call180)) (field (ref struct))))
  (type $environment204 (struct (field (ref $type31)) (field (ref $type159))))
  (type $environment201 (struct (field (ref $type199)) (field (ref $type201)) (field (ref $type82)) (field (ref $type221)) (field (ref $type139)) (field (ref $type31)) (field (ref $type42))))
  (type $type147 (struct (field (ref $call147)) (field (ref struct))))
  (type $call220 (func (param (ref $type199) (ref $type201) (ref $type82) (ref $type42) (ref $type221) (ref $type139)) (result i64)))
  (type $call161 (func (param (ref $environment197) (ref $type42) (ref $type42)) (result i64)))
  (type $63 (func (param (ref $type159) i64 i32 i32 (ref $type42) (ref $type42)) (result i64)))
  (type $type77 (sub $type76 (struct)))
  (type $call144 (func (param (ref $type145) (ref $type42)) (result (ref $type76))))
  (type $environment191 (struct (field (ref $type199)) (field (ref $type199)) (field (ref $type71)) (field (ref $type219)) (field (ref $type153)) (field (ref $type31)) (field (ref $type42))))
  (type $type145 (struct (field (ref $environment191))))
  (type $call218 (func (param (ref $type199) (ref $type199) (ref $type71) (ref $type42) (ref $type219) (ref $type153)) (result (ref $type53))))
  (type $call150 (func (param (ref $type53) (ref $type53)) (result (ref $type53))))
  (type $type79 (struct (field (ref $type76))))
  (type $type78 (sub $type76 (struct (field (ref $type53)) (field (ref $type79)))))
  (type $call153 (func (param (ref $type76)) (result (ref $type53))))
  (type $call142 (func (param (ref $type143) (ref $type71)) (result (ref $type42))))
  (type $call140 (func (param (ref $type141) (ref $type42)) (result (ref $type26))))
  (type $75 (func (param (ref $type101) i32 i32 (ref $type42) (ref $type42)) (result (ref $type42))))
  (type $76 (func (param (ref $type101) i32 i32 (ref $type42)) (result i32)))
  (type $environment178 (struct (field (ref $type159)) (field (ref $type31))))
  (type $environment175 (struct (field (ref $type159)) (field (ref $type31))))
  (type $79 (func (param i32 i32 (ref $type42) (ref $type42)) (result (ref $type42))))
  (type $80 (func (param (ref $type178) (ref $type143) i32 i32 (ref $type42) (ref $type71)) (result (ref $type42))))
  (type $call178 (func (param (ref struct) (ref $type70)) (result i32)))
  (type $environment174 (struct (field (ref $type159)) (field (ref $type42)) (field (ref $type42))))
  (type $environment173 (struct (field (ref $type31)) (field (ref $type159))))
  (type $type143 (struct))
  (type $environment165 (struct (field (ref $type31)) (field (ref $type159))))
  (type $type178 (struct (field (ref $call178)) (field (ref struct))))
  (type $call198 (func (param (ref $type199) (ref $type199) (ref $type71) (ref $type31)) (result (ref $type42))))
  (type $type73 (sub $type71 (struct (field (ref $type70)) (field (ref $type74)))))
  (type $type74 (struct (field (ref $type71))))
  (type $type70 (struct (field (ref $type31)) (field (ref $type31))))
  (type $call141 (func (param (ref struct) (ref $type31)) (result i64)))
  (type $environment162 (struct (field (ref $type199)) (field (ref $type199)) (field (ref $type71)) (field (ref $type217)) (field (ref $type139)) (field (ref $type31)) (field (ref $type42))))
  (type $type141 (struct (field (ref $call141)) (field (ref struct))))
  (type $call216 (func (param (ref $type199) (ref $type199) (ref $type71) (ref $type42) (ref $type217) (ref $type139)) (result i64)))
  (type $environment158 (struct (field (ref $type155)) (field i64)))
  (type $environment157 (struct (field (ref $type155)) (field i64)))
  (type $97 (func (param (ref $type175) (ref $type176) i32 i32 (ref $type26) (ref $type65)) (result (ref $type26))))
  (type $call175 (func (param (ref struct) (ref $type64)) (result i32)))
  (type $type67 (sub $type65 (struct (field (ref $type64)) (field (ref $type68)))))
  (type $type68 (struct (field (ref $type65))))
  (type $type64 (struct (field (ref $type26)) (field i64)))
  (type $environment156 (struct (field (ref $type155)) (field (ref $type26)) (field (ref $type26))))
  (type $environment155 (struct (field (ref $type26)) (field (ref $type157))))
  (type $type176 (struct))
  (type $type175 (struct (field (ref $call175)) (field (ref struct))))
  (type $environment150 (struct (field (ref $type26)) (field (ref $type157))))
  (type $environment147 (struct (field (ref $type195)) (field (ref $type193)) (field (ref $type65)) (field (ref $type215)) (field (ref $type139)) (field (ref $type26)) (field (ref $type31))))
  (type $call214 (func (param (ref $type195) (ref $type193) (ref $type65) (ref $type31) (ref $type215) (ref $type139)) (result i64)))
  (type $environment143 (struct (field (ref $type157)) (field (ref $type26))))
  (type $environment142 (struct (field (ref $type157)) (field (ref $type26))))
  (type $111 (func (param (ref $type172) (ref $type173) i32 i32 (ref $type31) (ref $type59)) (result (ref $type31))))
  (type $call172 (func (param (ref struct) (ref $type58)) (result i32)))
  (type $type61 (sub $type59 (struct (field (ref $type58)) (field (ref $type62)))))
  (type $type62 (struct (field (ref $type59))))
  (type $type58 (struct (field i64) (field (ref $type26))))
  (type $environment141 (struct (field (ref $type157)) (field (ref $type31)) (field (ref $type31))))
  (type $environment140 (struct (field i64) (field (ref $type155))))
  (type $type173 (struct))
  (type $type172 (struct (field (ref $call172)) (field (ref struct))))
  (type $environment135 (struct (field i64) (field (ref $type155))))
  (type $environment132 (struct (field (ref $type193)) (field (ref $type195)) (field (ref $type59)) (field (ref $type213)) (field (ref $type139)) (field i64) (field (ref $type26))))
  (type $call212 (func (param (ref $type193) (ref $type195) (ref $type59) (ref $type26) (ref $type213) (ref $type139)) (result i64)))
  (type $call138 (func (param (ref $type139) (ref $type31)) (result (ref $type26))))
  (type $environment127 (struct (field (ref $type195)) (field (ref $type195)) (field (ref $type48)) (field (ref $type211)) (field (ref $type139)) (field (ref $type26)) (field (ref $type31))))
  (type $call210 (func (param (ref $type195) (ref $type195) (ref $type48) (ref $type31) (ref $type211) (ref $type139)) (result i64)))
  (type $call136 (func (param (ref $type137) (ref $type26)) (result (ref $type26))))
  (type $environment122 (struct (field (ref $type193)) (field (ref $type193)) (field (ref $type37)) (field (ref $type209)) (field (ref $type139)) (field i64) (field (ref $type26))))
  (type $call208 (func (param (ref $type193) (ref $type193) (ref $type37) (ref $type26) (ref $type209) (ref $type139)) (result i64)))
  (type $call159 (func (param (ref $environment118) (ref $type31) (ref $type31)) (result i64)))
  (type $130 (func (param (ref $type157) i64 i32 i32 (ref $type31) (ref $type31)) (result i64)))
  (type $type54 (sub $type53 (struct)))
  (type $call134 (func (param (ref $type135) (ref $type31)) (result (ref $type53))))
  (type $133 (func (param (ref $type98) i32 i32 (ref $type31) (ref $type31)) (result (ref $type31))))
  (type $134 (func (param (ref $type98) i32 i32 (ref $type31)) (result i32)))
  (type $environment110 (struct (field (ref $type157)) (field (ref $type26))))
  (type $environment107 (struct (field (ref $type157)) (field (ref $type26))))
  (type $137 (func (param i32 i32 (ref $type31) (ref $type31)) (result (ref $type31))))
  (type $138 (func (param (ref $type170) (ref $type133) i32 i32 (ref $type31) (ref $type48)) (result (ref $type31))))
  (type $call170 (func (param (ref struct) (ref $type47)) (result i32)))
  (type $environment106 (struct (field (ref $type157)) (field (ref $type31)) (field (ref $type31))))
  (type $environment105 (struct (field (ref $type26)) (field (ref $type157))))
  (type $environment99 (struct (field (ref $type26)) (field (ref $type157))))
  (type $type170 (struct (field (ref $call170)) (field (ref struct))))
  (type $call194 (func (param (ref $type195) (ref $type195) (ref $type48) (ref $type26)) (result (ref $type31))))
  (type $environment96 (struct (field (ref $type195)) (field (ref $type195)) (field (ref $type48)) (field (ref $type207)) (field (ref $type152)) (field (ref $type26)) (field (ref $type31))))
  (type $type133 (struct))
  (type $type135 (struct (field (ref $environment96))))
  (type $call206 (func (param (ref $type195) (ref $type195) (ref $type48) (ref $type31) (ref $type207) (ref $type152)) (result (ref $type42))))
  (type $call149 (func (param (ref $type42) (ref $type42)) (result (ref $type42))))
  (type $type56 (struct (field (mut (ref $type53)))))
  (type $type55 (sub $type53 (struct (field (ref $type42)) (field (ref $type56)))))
  (type $call152 (func (param (ref $type53)) (result (ref $type42))))
  (type $type51 (struct (field (ref $type48))))
  (type $type47 (struct (field (ref $type26)) (field (ref $type26))))
  (type $type50 (sub $type48 (struct (field (ref $type47)) (field (ref $type51)))))
  (type $call132 (func (param (ref $type133) (ref $type48)) (result (ref $type31))))
  (type $call157 (func (param (ref $environment84) (ref $type26) (ref $type26)) (result i64)))
  (type $158 (func (param (ref $type155) i64 i32 i32 (ref $type26) (ref $type26)) (result i64)))
  (type $type43 (sub $type42 (struct)))
  (type $call130 (func (param (ref $type131) (ref $type26)) (result (ref $type42))))
  (type $161 (func (param (ref $type163) i32 i32 (ref $type26) (ref $type26)) (result (ref $type26))))
  (type $162 (func (param (ref $type163) i32 i32 (ref $type26)) (result i32)))
  (type $environment76 (struct (field (ref $type155)) (field i64)))
  (type $environment73 (struct (field (ref $type155)) (field i64)))
  (type $call163 (func (param (ref struct) i64) (result i32)))
  (type $166 (func (param i32 i32 (ref $type26) (ref $type26)) (result (ref $type26))))
  (type $167 (func (param (ref $type168) (ref $type129) i32 i32 (ref $type26) (ref $type37)) (result (ref $type26))))
  (type $call168 (func (param (ref struct) (ref $type36)) (result i32)))
  (type $environment72 (struct (field (ref $type155)) (field (ref $type26)) (field (ref $type26))))
  (type $environment71 (struct (field i64) (field (ref $type155))))
  (type $environment65 (struct (field i64) (field (ref $type155))))
  (type $type163 (struct (field (ref $call163)) (field (ref struct))))
  (type $type168 (struct (field (ref $call168)) (field (ref struct))))
  (type $call192 (func (param (ref $type193) (ref $type193) (ref $type37) i64) (result (ref $type26))))
  (type $environment62 (struct (field (ref $type193)) (field (ref $type193)) (field (ref $type37)) (field (ref $type205)) (field (ref $type151)) (field i64) (field (ref $type26))))
  (type $type129 (struct))
  (type $type131 (struct (field (ref $environment62))))
  (type $call204 (func (param (ref $type193) (ref $type193) (ref $type37) (ref $type26) (ref $type205) (ref $type151)) (result (ref $type31))))
  (type $call101 (func (param structref (ref $type31)) (result i32)))
  (type $type34 (struct (field (mut (ref $type31)))))
  (type $type33 (sub $type31 (struct (field (ref $type26)) (field (ref $type34)))))
  (type $call148 (func (param (ref $type31) (ref $type31)) (result (ref $type31))))
  (type $call100 (func (param structref (ref $type42)) (result i32)))
  (type $type45 (struct (field (mut (ref $type42)))))
  (type $type32 (sub $type31 (struct)))
  (type $type44 (sub $type42 (struct (field (ref $type31)) (field (ref $type45)))))
  (type $call151 (func (param (ref $type42)) (result (ref $type31))))
  (type $type40 (struct (field (ref $type37))))
  (type $type36 (struct (field i64) (field i64)))
  (type $type27 (sub $type26 (struct)))
  (type $type39 (sub $type37 (struct (field (ref $type36)) (field (ref $type40)))))
  (type $call128 (func (param (ref $type129) (ref $type37)) (result (ref $type26))))
  (type $call155 (func (param i64 i64) (result i64)))
  (type $type225 (struct))
  (type $type95 (sub $type94 (struct)))
  (type $type223 (struct))
  (type $type89 (sub $type88 (struct)))
  (type $type221 (struct))
  (type $type83 (sub $type82 (struct)))
  (type $type161 (struct (field (ref $environment197))))
  (type $environment197 (struct (field (ref $type159)) (field (ref $type240))))
  (type $type219 (struct))
  (type $type217 (struct))
  (type $type72 (sub $type71 (struct)))
  (type $type215 (struct))
  (type $type66 (sub $type65 (struct)))
  (type $type213 (struct))
  (type $type60 (sub $type59 (struct)))
  (type $type211 (struct))
  (type $type209 (struct))
  (type $type159 (struct (field (ref $environment118))))
  (type $environment118 (struct (field (ref $type157)) (field (ref $type239))))
  (type $type207 (struct))
  (type $type49 (sub $type48 (struct)))
  (type $type157 (struct (field (ref $environment84))))
  (type $environment84 (struct (field (ref $type155)) (field (ref $type238))))
  (type $type205 (struct))
  (type $type38 (sub $type37 (struct)))
  (type $type239 (struct (field (mut i32)) (field (mut (ref null $type159)))))
  (type $type238 (struct (field (mut i32)) (field (mut (ref null $type157)))))
  (type $type201 (struct (field (ref $type53)) (field (ref $type161))))
  (type $type193 (struct (field (ref $type28)) (field (ref $type155))))
  (type $type195 (struct (field (ref $type31)) (field (ref $type157))))
  (type $type240 (struct (field (mut i32)) (field (mut (ref null $type161)))))
  (type $type199 (struct (field (ref $type42)) (field (ref $type159))))
  (type $call137 (func (param structref i64) (result i64)))
  (type $call139 (func (param structref (ref $type26)) (result i64)))
  (type $call98 (func (param structref (ref $type26)) (result i32)))
  (type $type29 (struct (field (mut (ref $type26)))))
  (type $call154 (func (param i64 (ref $type26)) (result i32)))
  (type $type236 (struct))
  (type $type235 (struct))
  (type $type234 (struct))
  (type $type233 (struct))
  (type $type232 (struct))
  (type $type231 (struct))
  (type $type229 (struct))
  (type $type227 (struct))
  (type $type226 (struct))
  (type $type203 (struct))
  (type $type202 (struct))
  (type $type200 (struct))
  (type $type197 (struct))
  (type $type196 (struct))
  (type $type158 (struct))
  (type $type156 (struct))
  (type $type127 (struct))
  (type $type126 (struct))
  (type $type125 (struct))
  (type $type124 (struct))
  (type $type123 (struct))
  (type $type122 (struct))
  (type $type121 (struct))
  (type $type118 (struct))
  (type $type117 (struct))
  (type $type110 (struct))
  (type $type109 (struct))
  (type $type108 (struct))
  (type $type105 (struct))
  (type $type104 (struct))
  (type $type92 (struct))
  (type $type86 (struct))
  (type $type80 (struct))
  (type $type75 (struct))
  (type $type63 (struct))
  (type $type57 (struct))
  (type $type230 (struct))
  (type $type224 (struct))
  (type $type222 (struct))
  (type $type220 (struct))
  (type $type216 (struct))
  (type $type214 (struct))
  (type $type212 (struct))
  (type $type208 (struct))
  (type $type206 (struct))
  (type $type204 (struct))
  (type $type198 (struct))
  (type $type194 (struct))
  (type $type192 (struct))
  (type $type185 (struct))
  (type $type182 (struct))
  (type $type179 (struct))
  (type $type177 (struct))
  (type $type174 (struct))
  (type $type171 (struct))
  (type $type169 (struct))
  (type $type167 (struct))
  (type $type166 (struct))
  (type $type165 (struct))
  (type $type164 (struct))
  (type $type162 (struct))
  (type $type153 (struct (field (ref $call153))))
  (type $type152 (struct (field (ref $call152))))
  (type $type151 (struct (field (ref $call151))))
  (type $type150 (struct))
  (type $type149 (struct))
  (type $type148 (struct))
  (type $type144 (struct))
  (type $type142 (struct))
  (type $type134 (struct))
  (type $type132 (struct))
  (type $type130 (struct))
  (type $type128 (struct))
  (type $type120 (struct))
  (type $type119 (struct))
  (type $type115 (struct))
  (type $type112 (struct))
  (type $type107 (struct))
  (type $type106 (struct))
  (type $type102 (struct))
  (type $type99 (struct))
  (type $type69 (struct))
  (type $type46 (struct))
  (type $type35 (struct))
  (type $type137 (struct (field (ref $call137)) (field structref)))
  (type $type228 (struct))
  (type $type210 (struct))
  (type $type160 (struct))
  (type $type155 (struct (field (ref $call155))))
  (type $type146 (struct))
  (type $type140 (struct))
  (type $type138 (struct))
  (type $type136 (struct))
  (type $type218 (struct))
  (type $type191 (struct))
  (type $type190 (struct))
  (type $type189 (struct))
  (type $type188 (struct))
  (type $type52 (struct))
  (type $type30 (struct))
  (type $type41 (struct))
  (type $type28 (sub $type26 (struct (field i64) (field (ref $type29)))))
  (type $type116 (struct))
  (type $type139 (struct (field (ref $call139)) (field structref)))
  (type $type25 (struct))
  (type $type114 (struct))
  (type $type111 (struct))
  (type $type103 (struct))
  (type $type154 (struct))
  (type $type113 (struct))
  (type $type101 (struct (field (ref $call101)) (field structref)))
  (type $type98 (struct (field (ref $call98)) (field structref)))
  (type $type100 (struct (field (ref $call100)) (field structref)))
 )
 (type $344 (func (param i64) (result i64)))
 (type $345 (func (param i32) (result i64)))
 (type $346 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $global161 (mut (ref null $type100)) (ref.null none))
 (global $ready161 (mut i32) (i32.const 0))
 (global $global112 (mut (ref null $type98)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (global $global171 (mut (ref null $type101)) (ref.null none))
 (global $ready171 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type113)) (ref.null none))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type154)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global280 (mut (ref null $type103)) (ref.null none))
 (global $ready280 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type111)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global176 (mut (ref null $type114)) (ref.null none))
 (global $ready176 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type25)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type139)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global285 (mut (ref null $type116)) (ref.null none))
 (global $ready285 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type28)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type28)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global239 (mut (ref null $type41)) (ref.null none))
 (global $ready239 (mut i32) (i32.const 0))
 (global $global155 (mut (ref null $type30)) (ref.null none))
 (global $ready155 (mut i32) (i32.const 0))
 (global $global351 (mut (ref null $type52)) (ref.null none))
 (global $ready351 (mut i32) (i32.const 0))
 (global $global221 (mut (ref null $type188)) (ref.null none))
 (global $ready221 (mut i32) (i32.const 0))
 (global $global333 (mut (ref null $type189)) (ref.null none))
 (global $ready333 (mut i32) (i32.const 0))
 (global $global557 (mut (ref null $type190)) (ref.null none))
 (global $ready557 (mut i32) (i32.const 0))
 (global $global688 (mut (ref null $type191)) (ref.null none))
 (global $ready688 (mut i32) (i32.const 0))
 (global $global598 (mut (ref null $type218)) (ref.null none))
 (global $ready598 (mut i32) (i32.const 0))
 (global $execution (mut i32) (i32.const 0))
 (global $global387 (mut (ref null $type136)) (ref.null none))
 (global $ready387 (mut i32) (i32.const 0))
 (global $global405 (mut (ref null $type138)) (ref.null none))
 (global $ready405 (mut i32) (i32.const 0))
 (global $global571 (mut (ref null $type140)) (ref.null none))
 (global $ready571 (mut i32) (i32.const 0))
 (global $global702 (mut (ref null $type146)) (ref.null none))
 (global $ready702 (mut i32) (i32.const 0))
 (global $global805 (mut (ref null $type155)) (ref.null none))
 (global $ready805 (mut i32) (i32.const 0))
 (global $global615 (mut (ref null $type160)) (ref.null none))
 (global $ready615 (mut i32) (i32.const 0))
 (global $global207 (mut (ref null $type111)) (ref.null none))
 (global $ready207 (mut i32) (i32.const 0))
 (global $global319 (mut (ref null $type114)) (ref.null none))
 (global $ready319 (mut i32) (i32.const 0))
 (global $global541 (mut (ref null $type113)) (ref.null none))
 (global $ready541 (mut i32) (i32.const 0))
 (global $global672 (mut (ref null $type116)) (ref.null none))
 (global $ready672 (mut i32) (i32.const 0))
 (global $global395 (mut (ref null $type210)) (ref.null none))
 (global $ready395 (mut i32) (i32.const 0))
 (global $global577 (mut (ref null $type228)) (ref.null none))
 (global $ready577 (mut i32) (i32.const 0))
 (global $global128 (mut (ref null $type137)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global802 (mut i64) (i64.const 0))
 (global $ready802 (mut i32) (i32.const 0))
 (global $global188 (mut (ref null $type35)) (ref.null none))
 (global $ready188 (mut i32) (i32.const 0))
 (global $global300 (mut (ref null $type46)) (ref.null none))
 (global $ready300 (mut i32) (i32.const 0))
 (global $global517 (mut (ref null $type69)) (ref.null none))
 (global $ready517 (mut i32) (i32.const 0))
 (global $global147 (mut (ref null $type99)) (ref.null none))
 (global $ready147 (mut i32) (i32.const 0))
 (global $global269 (mut (ref null $type102)) (ref.null none))
 (global $ready269 (mut i32) (i32.const 0))
 (global $global536 (mut (ref null $type106)) (ref.null none))
 (global $ready536 (mut i32) (i32.const 0))
 (global $global588 (mut (ref null $type107)) (ref.null none))
 (global $ready588 (mut i32) (i32.const 0))
 (global $global153 (mut (ref null $type112)) (ref.null none))
 (global $ready153 (mut i32) (i32.const 0))
 (global $global275 (mut (ref null $type115)) (ref.null none))
 (global $ready275 (mut i32) (i32.const 0))
 (global $global551 (mut (ref null $type119)) (ref.null none))
 (global $ready551 (mut i32) (i32.const 0))
 (global $global593 (mut (ref null $type120)) (ref.null none))
 (global $ready593 (mut i32) (i32.const 0))
 (global $global144 (mut (ref null $type128)) (ref.null none))
 (global $ready144 (mut i32) (i32.const 0))
 (global $global235 (mut (ref null $type130)) (ref.null none))
 (global $ready235 (mut i32) (i32.const 0))
 (global $global266 (mut (ref null $type132)) (ref.null none))
 (global $ready266 (mut i32) (i32.const 0))
 (global $global347 (mut (ref null $type134)) (ref.null none))
 (global $ready347 (mut i32) (i32.const 0))
 (global $global581 (mut (ref null $type142)) (ref.null none))
 (global $ready581 (mut i32) (i32.const 0))
 (global $global608 (mut (ref null $type144)) (ref.null none))
 (global $ready608 (mut i32) (i32.const 0))
 (global $global168 (mut (ref null $type148)) (ref.null none))
 (global $ready168 (mut i32) (i32.const 0))
 (global $global287 (mut (ref null $type149)) (ref.null none))
 (global $ready287 (mut i32) (i32.const 0))
 (global $global595 (mut (ref null $type150)) (ref.null none))
 (global $ready595 (mut i32) (i32.const 0))
 (global $global159 (mut (ref null $type151)) (ref.null none))
 (global $ready159 (mut i32) (i32.const 0))
 (global $global278 (mut (ref null $type152)) (ref.null none))
 (global $ready278 (mut i32) (i32.const 0))
 (global $global586 (mut (ref null $type153)) (ref.null none))
 (global $ready586 (mut i32) (i32.const 0))
 (global $global228 (mut (ref null $type162)) (ref.null none))
 (global $ready228 (mut i32) (i32.const 0))
 (global $global340 (mut (ref null $type164)) (ref.null none))
 (global $ready340 (mut i32) (i32.const 0))
 (global $global564 (mut (ref null $type165)) (ref.null none))
 (global $ready564 (mut i32) (i32.const 0))
 (global $global695 (mut (ref null $type166)) (ref.null none))
 (global $ready695 (mut i32) (i32.const 0))
 (global $global200 (mut (ref null $type167)) (ref.null none))
 (global $ready200 (mut i32) (i32.const 0))
 (global $global312 (mut (ref null $type169)) (ref.null none))
 (global $ready312 (mut i32) (i32.const 0))
 (global $global435 (mut (ref null $type171)) (ref.null none))
 (global $ready435 (mut i32) (i32.const 0))
 (global $global481 (mut (ref null $type174)) (ref.null none))
 (global $ready481 (mut i32) (i32.const 0))
 (global $global529 (mut (ref null $type177)) (ref.null none))
 (global $ready529 (mut i32) (i32.const 0))
 (global $global660 (mut (ref null $type179)) (ref.null none))
 (global $ready660 (mut i32) (i32.const 0))
 (global $global734 (mut (ref null $type182)) (ref.null none))
 (global $ready734 (mut i32) (i32.const 0))
 (global $global782 (mut (ref null $type185)) (ref.null none))
 (global $ready782 (mut i32) (i32.const 0))
 (global $global191 (mut (ref null $type192)) (ref.null none))
 (global $ready191 (mut i32) (i32.const 0))
 (global $global303 (mut (ref null $type194)) (ref.null none))
 (global $ready303 (mut i32) (i32.const 0))
 (global $global520 (mut (ref null $type198)) (ref.null none))
 (global $ready520 (mut i32) (i32.const 0))
 (global $global178 (mut (ref null $type204)) (ref.null none))
 (global $ready178 (mut i32) (i32.const 0))
 (global $global290 (mut (ref null $type206)) (ref.null none))
 (global $ready290 (mut i32) (i32.const 0))
 (global $global377 (mut (ref null $type208)) (ref.null none))
 (global $ready377 (mut i32) (i32.const 0))
 (global $global413 (mut (ref null $type212)) (ref.null none))
 (global $ready413 (mut i32) (i32.const 0))
 (global $global459 (mut (ref null $type214)) (ref.null none))
 (global $ready459 (mut i32) (i32.const 0))
 (global $global507 (mut (ref null $type216)) (ref.null none))
 (global $ready507 (mut i32) (i32.const 0))
 (global $global638 (mut (ref null $type220)) (ref.null none))
 (global $ready638 (mut i32) (i32.const 0))
 (global $global712 (mut (ref null $type222)) (ref.null none))
 (global $ready712 (mut i32) (i32.const 0))
 (global $global760 (mut (ref null $type224)) (ref.null none))
 (global $ready760 (mut i32) (i32.const 0))
 (global $global391 (mut (ref null $type230)) (ref.null none))
 (global $ready391 (mut i32) (i32.const 0))
 (global $global423 (mut (ref null $type57)) (ref.null none))
 (global $ready423 (mut i32) (i32.const 0))
 (global $global469 (mut (ref null $type63)) (ref.null none))
 (global $ready469 (mut i32) (i32.const 0))
 (global $global612 (mut (ref null $type75)) (ref.null none))
 (global $ready612 (mut i32) (i32.const 0))
 (global $global648 (mut (ref null $type80)) (ref.null none))
 (global $ready648 (mut i32) (i32.const 0))
 (global $global722 (mut (ref null $type86)) (ref.null none))
 (global $ready722 (mut i32) (i32.const 0))
 (global $global770 (mut (ref null $type92)) (ref.null none))
 (global $ready770 (mut i32) (i32.const 0))
 (global $global442 (mut (ref null $type104)) (ref.null none))
 (global $ready442 (mut i32) (i32.const 0))
 (global $global488 (mut (ref null $type105)) (ref.null none))
 (global $ready488 (mut i32) (i32.const 0))
 (global $global667 (mut (ref null $type108)) (ref.null none))
 (global $ready667 (mut i32) (i32.const 0))
 (global $global741 (mut (ref null $type109)) (ref.null none))
 (global $ready741 (mut i32) (i32.const 0))
 (global $global789 (mut (ref null $type110)) (ref.null none))
 (global $ready789 (mut i32) (i32.const 0))
 (global $global448 (mut (ref null $type117)) (ref.null none))
 (global $ready448 (mut i32) (i32.const 0))
 (global $global494 (mut (ref null $type118)) (ref.null none))
 (global $ready494 (mut i32) (i32.const 0))
 (global $global682 (mut (ref null $type121)) (ref.null none))
 (global $ready682 (mut i32) (i32.const 0))
 (global $global747 (mut (ref null $type122)) (ref.null none))
 (global $ready747 (mut i32) (i32.const 0))
 (global $global795 (mut (ref null $type123)) (ref.null none))
 (global $ready795 (mut i32) (i32.const 0))
 (global $global213 (mut (ref null $type124)) (ref.null none))
 (global $ready213 (mut i32) (i32.const 0))
 (global $global325 (mut (ref null $type125)) (ref.null none))
 (global $ready325 (mut i32) (i32.const 0))
 (global $global547 (mut (ref null $type126)) (ref.null none))
 (global $ready547 (mut i32) (i32.const 0))
 (global $global678 (mut (ref null $type127)) (ref.null none))
 (global $ready678 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type28)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global242 (mut (ref null $type156)) (ref.null none))
 (global $ready242 (mut i32) (i32.const 0))
 (global $global354 (mut (ref null $type158)) (ref.null none))
 (global $ready354 (mut i32) (i32.const 0))
 (global $global426 (mut (ref null $type196)) (ref.null none))
 (global $ready426 (mut i32) (i32.const 0))
 (global $global472 (mut (ref null $type197)) (ref.null none))
 (global $ready472 (mut i32) (i32.const 0))
 (global $global651 (mut (ref null $type200)) (ref.null none))
 (global $ready651 (mut i32) (i32.const 0))
 (global $global725 (mut (ref null $type202)) (ref.null none))
 (global $ready725 (mut i32) (i32.const 0))
 (global $global773 (mut (ref null $type203)) (ref.null none))
 (global $ready773 (mut i32) (i32.const 0))
 (global $global140 (mut (ref null $type226)) (ref.null none))
 (global $ready140 (mut i32) (i32.const 0))
 (global $global262 (mut (ref null $type227)) (ref.null none))
 (global $ready262 (mut i32) (i32.const 0))
 (global $global373 (mut (ref null $type229)) (ref.null none))
 (global $ready373 (mut i32) (i32.const 0))
 (global $global409 (mut (ref null $type231)) (ref.null none))
 (global $ready409 (mut i32) (i32.const 0))
 (global $global455 (mut (ref null $type232)) (ref.null none))
 (global $ready455 (mut i32) (i32.const 0))
 (global $global503 (mut (ref null $type233)) (ref.null none))
 (global $ready503 (mut i32) (i32.const 0))
 (global $global634 (mut (ref null $type234)) (ref.null none))
 (global $ready634 (mut i32) (i32.const 0))
 (global $global708 (mut (ref null $type235)) (ref.null none))
 (global $ready708 (mut i32) (i32.const 0))
 (global $global756 (mut (ref null $type236)) (ref.null none))
 (global $ready756 (mut i32) (i32.const 0))
 (global $global803 (mut (ref null $type137)) (ref.null none))
 (global $ready803 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $function41 (type $call154) (param $0 i64) (param $1 (ref $type26)) (result i32)
  (local $2 i32)
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $1)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (local.tee $2
      (i64.eq
       (struct.get $type28 0
        (ref.cast (ref $type28)
         (local.get $1)
        )
       )
       (local.get $0)
      )
     )
     (then
      (local.get $2)
     )
     (else
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type28)
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type29 0
        (struct.get $type28 1
         (ref.cast (ref $type28)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global109)
       )
      )
      (return_call $function41
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function42 (type $call98) (param $0 structref) (param $1 (ref $type26)) (result i32)
  (if (result i32)
   (ref.test (ref $type28)
    (local.get $1)
   )
   (then
    (drop
     (ref.cast (ref $type28)
      (local.get $1)
     )
    )
    (i32.const 0)
   )
   (else
    (i32.const 1)
   )
  )
 )
 (func $function45 (type $call139) (param $0 structref) (param $1 (ref $type26)) (result i64)
  (local $2 i64)
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $1)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 0)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type28 0
      (ref.cast (ref $type28)
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type29 0
      (struct.get $type28 1
       (ref.cast (ref $type28)
        (local.get $1)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready126)
     )
     (then
      (unreachable)
     )
    )
    (i64.add
     (call $function45
      (struct.get $type139 1
       (global.get $global126)
      )
      (local.get $1)
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function46 (type $call137) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type199))
  (local $3 (ref $type139))
  (local $4 (ref $type240))
  (local $5 (ref $type195))
  (local $6 (ref $type193))
  (local $7 (ref $type201))
  (local $8 (ref $type53))
  (local $9 (ref $type238))
  (local $10 (ref $type239))
  (local $11 (ref $type31))
  (local $12 (ref $type42))
  (if
   (i32.eqz
    (global.get $ready120)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready140)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global140)
   )
  )
  (if
   (i32.eqz
    (global.get $ready178)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global178)
   )
  )
  (local.set $2
   (struct.new $type199
    (call $function95
     (local.tee $5
      (struct.new $type195
       (call $function61
        (local.tee $6
         (struct.new $type193
          (ref.as_non_null
           (global.get $global120)
          )
          (struct.new $type155
           (ref.func $function47)
          )
         )
        )
        (local.get $6)
        (struct.new_default $type38)
        (struct.get $type193 0
         (local.get $6)
        )
        (struct.new_default $type205)
        (struct.new $type151
         (ref.func $function54)
        )
       )
       (block (result (ref $type157))
        (if
         (i32.eqz
          (global.get $ready242)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global242)
         )
        )
        (struct.set $type238 1
         (local.tee $9
          (struct.new_default $type238)
         )
         (struct.new $type157
          (struct.new $environment84
           (struct.get $type193 1
            (local.get $6)
           )
           (local.get $9)
          )
         )
        )
        (struct.set $type238 0
         (local.get $9)
         (i32.const 1)
        )
        (if
         (i32.eqz
          (struct.get $type238 0
           (local.get $9)
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready262)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global262)
         )
        )
        (if
         (i32.eqz
          (global.get $ready290)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global290)
         )
        )
        (ref.as_non_null
         (struct.get $type238 1
          (local.get $9)
         )
        )
       )
      )
     )
     (local.get $5)
     (struct.new_default $type49)
     (struct.get $type195 0
      (local.get $5)
     )
     (struct.new_default $type207)
     (struct.new $type152
      (ref.func $function90)
     )
    )
    (block (result (ref $type159))
     (if
      (i32.eqz
       (global.get $ready354)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global354)
      )
     )
     (struct.set $type239 1
      (local.tee $10
       (struct.new_default $type239)
      )
      (struct.new $type159
       (struct.new $environment118
        (struct.get $type195 1
         (local.get $5)
        )
        (local.get $10)
       )
      )
     )
     (struct.set $type239 0
      (local.get $10)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type239 0
        (local.get $10)
       )
      )
      (then
       (unreachable)
      )
     )
     (if
      (i32.eqz
       (global.get $ready373)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global373)
      )
     )
     (if
      (i32.eqz
       (global.get $ready126)
      )
      (then
       (unreachable)
      )
     )
     (local.set $3
      (ref.as_non_null
       (global.get $global126)
      )
     )
     (if
      (i32.eqz
       (global.get $ready377)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global377)
      )
     )
     (ref.as_non_null
      (struct.get $type239 1
       (local.get $10)
      )
     )
    )
   )
  )
  (drop
   (call $function121
    (local.get $6)
    (local.get $6)
    (struct.new_default $type38)
    (struct.get $type193 0
     (local.get $6)
    )
    (struct.new_default $type209)
    (local.get $3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready391)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global391)
   )
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (if
   (i32.eqz
    (global.get $ready395)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global395)
   )
  )
  (drop
   (call $function126
    (local.get $5)
    (local.get $5)
    (struct.new_default $type49)
    (struct.get $type195 0
     (local.get $5)
    )
    (struct.new_default $type211)
    (local.get $3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready409)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global409)
   )
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (if
   (i32.eqz
    (global.get $ready413)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global413)
   )
  )
  (drop
   (call $function131
    (local.get $6)
    (local.get $5)
    (struct.new_default $type60)
    (struct.get $type193 0
     (local.get $6)
    )
    (struct.new_default $type213)
    (local.get $3)
   )
  )
  (if
   (i32.eqz
    (global.get $ready455)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global455)
   )
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (if
   (i32.eqz
    (global.get $ready459)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global459)
   )
  )
  (drop
   (call $function146
    (local.get $5)
    (local.get $6)
    (struct.new_default $type66)
    (struct.get $type195 0
     (local.get $5)
    )
    (struct.new_default $type215)
    (local.get $3)
   )
  )
  (if
   (i64.eq
    (local.get $1)
    (i64.const 33)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready391)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global391)
     )
    )
    (if
     (i32.eqz
      (global.get $ready126)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (if
     (i32.eqz
      (global.get $ready395)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global395)
     )
    )
    (return_call $function126
     (local.get $5)
     (local.get $5)
     (struct.new_default $type49)
     (struct.get $type195 0
      (local.get $5)
     )
     (struct.new_default $type211)
     (local.get $3)
    )
   )
   (else
    (if
     (i64.eq
      (local.get $1)
      (i64.const 44)
     )
     (then
      (if
       (i32.eqz
        (global.get $ready503)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global503)
       )
      )
      (if
       (i32.eqz
        (global.get $ready126)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (ref.as_non_null
        (global.get $global126)
       )
      )
      (if
       (i32.eqz
        (global.get $ready507)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global507)
       )
      )
      (return_call $function161
       (local.get $2)
       (local.get $2)
       (struct.new_default $type72)
       (struct.get $type199 0
        (local.get $2)
       )
       (struct.new_default $type217)
       (local.get $3)
      )
     )
     (else
      (if
       (i64.eq
        (local.get $1)
        (i64.const 45)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready577)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global577)
         )
        )
        (if
         (i32.eqz
          (global.get $ready598)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global598)
         )
        )
        (local.set $7
         (struct.new $type201
          (call $function190
           (local.get $2)
           (local.get $2)
           (struct.new_default $type72)
           (struct.get $type199 0
            (local.get $2)
           )
           (struct.new_default $type219)
           (struct.new $type153
            (ref.func $function185)
           )
          )
          (block (result (ref $type161))
           (if
            (i32.eqz
             (global.get $ready615)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global615)
            )
           )
           (struct.set $type240 1
            (local.tee $4
             (struct.new_default $type240)
            )
            (struct.new $type161
             (struct.new $environment197
              (struct.get $type199 1
               (local.get $2)
              )
              (local.get $4)
             )
            )
           )
           (struct.set $type240 0
            (local.get $4)
            (i32.const 1)
           )
           (if
            (i32.eqz
             (struct.get $type240 0
              (local.get $4)
             )
            )
            (then
             (unreachable)
            )
           )
           (ref.as_non_null
            (struct.get $type240 1
             (local.get $4)
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready634)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global634)
         )
        )
        (if
         (i32.eqz
          (global.get $ready126)
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (ref.as_non_null
          (global.get $global126)
         )
        )
        (if
         (i32.eqz
          (global.get $ready638)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global638)
         )
        )
        (return_call $function200
         (local.get $2)
         (local.get $7)
         (struct.new_default $type83)
         (struct.get $type199 0
          (local.get $2)
         )
         (struct.new_default $type221)
         (local.get $3)
        )
       )
       (else
        (if
         (i64.eq
          (local.get $1)
          (i64.const 54)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready577)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global577)
           )
          )
          (if
           (i32.eqz
            (global.get $ready598)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global598)
           )
          )
          (local.set $7
           (struct.new $type201
            (call $function190
             (local.get $2)
             (local.get $2)
             (struct.new_default $type72)
             (struct.get $type199 0
              (local.get $2)
             )
             (struct.new_default $type219)
             (struct.new $type153
              (ref.func $function185)
             )
            )
            (block (result (ref $type161))
             (if
              (i32.eqz
               (global.get $ready615)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global615)
              )
             )
             (struct.set $type240 1
              (local.tee $4
               (struct.new_default $type240)
              )
              (struct.new $type161
               (struct.new $environment197
                (struct.get $type199 1
                 (local.get $2)
                )
                (local.get $4)
               )
              )
             )
             (struct.set $type240 0
              (local.get $4)
              (i32.const 1)
             )
             (if
              (i32.eqz
               (struct.get $type240 0
                (local.get $4)
               )
              )
              (then
               (unreachable)
              )
             )
             (ref.as_non_null
              (struct.get $type240 1
               (local.get $4)
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready708)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global708)
           )
          )
          (if
           (i32.eqz
            (global.get $ready126)
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (ref.as_non_null
            (global.get $global126)
           )
          )
          (if
           (i32.eqz
            (global.get $ready712)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global712)
           )
          )
          (return_call $function223
           (local.get $7)
           (local.get $2)
           (struct.new_default $type89)
           (struct.get $type201 0
            (local.get $7)
           )
           (struct.new_default $type223)
           (local.get $3)
          )
         )
         (else
          (if
           (i64.eq
            (local.get $1)
            (i64.const 55)
           )
           (then
            (if
             (i32.eqz
              (global.get $ready577)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global577)
             )
            )
            (if
             (i32.eqz
              (global.get $ready598)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global598)
             )
            )
            (local.set $7
             (struct.new $type201
              (call $function190
               (local.get $2)
               (local.get $2)
               (struct.new_default $type72)
               (struct.get $type199 0
                (local.get $2)
               )
               (struct.new_default $type219)
               (struct.new $type153
                (ref.func $function185)
               )
              )
              (block (result (ref $type161))
               (if
                (i32.eqz
                 (global.get $ready615)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global615)
                )
               )
               (struct.set $type240 1
                (local.tee $4
                 (struct.new_default $type240)
                )
                (struct.new $type161
                 (struct.new $environment197
                  (struct.get $type199 1
                   (local.get $2)
                  )
                  (local.get $4)
                 )
                )
               )
               (struct.set $type240 0
                (local.get $4)
                (i32.const 1)
               )
               (if
                (i32.eqz
                 (struct.get $type240 0
                  (local.get $4)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (ref.as_non_null
                (struct.get $type240 1
                 (local.get $4)
                )
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready756)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global756)
             )
            )
            (if
             (i32.eqz
              (global.get $ready126)
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (ref.as_non_null
              (global.get $global126)
             )
            )
            (if
             (i32.eqz
              (global.get $ready760)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global760)
             )
            )
            (return_call $function238
             (local.get $7)
             (local.get $7)
             (struct.new_default $type95)
             (struct.get $type201 0
              (local.get $7)
             )
             (struct.new_default $type225)
             (local.get $3)
            )
           )
           (else
            (unreachable)
           )
          )
          (unreachable)
         )
        )
        (unreachable)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
  (unreachable)
 )
 (func $function47 (type $call155) (param $0 i64) (param $1 i64) (result i64)
  (if (result i64)
   (i64.eqz
    (local.get $0)
   )
   (then
    (if (result i64)
     (i64.eqz
      (local.get $1)
     )
     (then
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $1)
        (i64.const 1)
       )
       (then
        (i64.const 0)
       )
       (else
        (unreachable)
       )
      )
     )
    )
   )
   (else
    (if (result i64)
     (i64.eq
      (local.get $0)
      (i64.const 1)
     )
     (then
      (if (result i64)
       (i64.eqz
        (local.get $1)
       )
       (then
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $1)
          (i64.const 1)
         )
         (then
          (i64.const 1)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
     (else
      (unreachable)
     )
    )
   )
  )
 )
 (func $function50 (type $call128) (param $0 (ref $type129)) (param $1 (ref $type37)) (result (ref $type26))
  (local $2 i64)
  (local $3 (ref $type26))
  (local $scratch (ref $type26))
  (if
   (i32.eqz
    (global.get $ready147)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (if (result (ref $type26))
   (if (result i32)
    (ref.test (ref $type38)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type39)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (struct.new_default $type27)
   )
   (else
    (if
     (ref.test (ref $type38)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type28
     (struct.get $type36 1
      (struct.get $type39 0
       (ref.cast (ref $type39)
        (local.get $1)
       )
      )
     )
     (block (result (ref (exact $type29)))
      (if
       (i32.eqz
        (global.get $ready153)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global153)
       )
      )
      (if
       (ref.test (ref $type38)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type40 0
        (struct.get $type39 1
         (ref.cast (ref $type39)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready144)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global144)
       )
      )
      (struct.new $type29
       (block (result (ref $type26))
        (local.set $scratch
         (call $function50
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready121)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global121)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function54 (type $call151) (param $0 (ref $type42)) (result (ref $type31))
  (if
   (i32.eqz
    (global.get $ready159)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global159)
   )
  )
  (return_call $function55
   (local.get $0)
  )
 )
 (func $function55 (type $call151) (param $0 (ref $type42)) (result (ref $type31))
  (local $1 (ref $type42))
  (local $2 (ref $type31))
  (local $3 (ref $type31))
  (local $scratch (ref $type42))
  (local $scratch_5 (ref $type31))
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result (ref $type31))
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (struct.new_default $type32)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready166)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global166)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $0)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type45 0
      (struct.get $type44 1
       (ref.cast (ref $type44)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready161)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global161)
     )
    )
    (if (result (ref $type31))
     (if (result i32)
      (ref.test (ref $type44)
       (local.get $1)
      )
      (then
       (drop
        (ref.cast (ref $type44)
         (local.get $1)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $0)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.get $type44 0
       (ref.cast (ref $type44)
        (local.get $0)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $0)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function58
       (struct.get $type44 0
        (ref.cast (ref $type44)
         (local.get $0)
        )
       )
       (block (result (ref $type31))
        (if
         (i32.eqz
          (global.get $ready166)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global166)
         )
        )
        (if
         (i32.eqz
          (ref.test (ref $type44)
           (local.get $0)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $scratch_5
         (call $function55
          (block (result (ref $type42))
           (local.set $scratch
            (struct.get $type45 0
             (struct.get $type44 1
              (ref.cast (ref $type44)
               (local.get $0)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready159)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global159)
            )
           )
           (local.get $scratch)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready168)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global168)
         )
        )
        (local.get $scratch_5)
       )
      )
     )
    )
   )
  )
 )
 (func $function56 (type $call100) (param $0 structref) (param $1 (ref $type42)) (result i32)
  (if (result i32)
   (ref.test (ref $type44)
    (local.get $1)
   )
   (then
    (drop
     (ref.cast (ref $type44)
      (local.get $1)
     )
    )
    (i32.const 0)
   )
   (else
    (i32.const 1)
   )
  )
 )
 (func $function58 (type $call148) (param $0 (ref $type31)) (param $1 (ref $type31)) (result (ref $type31))
  (local $2 (ref $type26))
  (local $scratch (ref $type31))
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result (ref $type31))
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $0)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $0)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type33
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $0)
      )
     )
     (block (result (ref (exact $type34)))
      (if
       (i32.eqz
        (global.get $ready176)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global176)
       )
      )
      (if
       (ref.test (ref $type32)
        (local.get $0)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type34
       (block (result (ref $type31))
        (local.set $scratch
         (call $function58
          (struct.get $type34 0
           (struct.get $type33 1
            (ref.cast (ref $type33)
             (local.get $0)
            )
           )
          )
          (block (result (ref $type31))
           (if
            (i32.eqz
             (global.get $ready168)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global168)
            )
           )
           (local.get $1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready155)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global155)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function59 (type $call101) (param $0 structref) (param $1 (ref $type31)) (result i32)
  (if (result i32)
   (ref.test (ref $type32)
    (local.get $1)
   )
   (then
    (i32.const 1)
   )
   (else
    (drop
     (ref.cast (ref $type33)
      (local.get $1)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function61 (type $call204) (param $0 (ref $type193)) (param $1 (ref $type193)) (param $2 (ref $type37)) (param $3 (ref $type26)) (param $4 (ref $type205)) (param $5 (ref $type151)) (result (ref $type31))
  (local $6 i64)
  (local $7 (ref $type131))
  (local $scratch (ref $type26))
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result (ref $type33))
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready144)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global144)
     )
    )
    (struct.new $type33
     (call $function50
      (struct.new_default $type129)
      (local.get $2)
     )
     (block (result (ref (exact $type34)))
      (if
       (i32.eqz
        (global.get $ready155)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global155)
       )
      )
      (struct.new $type34
       (struct.new_default $type32)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type28 0
      (ref.cast (ref $type28)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call151
     (call $function79
      (struct.new $type131
       (struct.new $environment62
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $4)
        (local.get $5)
        (local.get $6)
        (struct.get $type29 0
         (struct.get $type28 1
          (ref.cast (ref $type28)
           (local.get $3)
          )
         )
        )
       )
      )
      (block (result (ref $type26))
       (if
        (i32.eqz
         (global.get $ready191)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global191)
        )
       )
       (local.set $scratch
        (call $function64
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $6)
        )
       )
       (if
        (i32.eqz
         (global.get $ready235)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global235)
        )
       )
       (local.get $scratch)
      )
     )
     (struct.get $type151 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function64 (type $call192) (param $0 (ref $type193)) (param $1 (ref $type193)) (param $2 (ref $type37)) (param $3 i64) (result (ref $type26))
  (local $4 (ref $type155))
  (local $5 (ref $type168))
  (local $6 (ref $type26))
  (local $7 (ref $type163))
  (local.set $6
   (call $function67
    (struct.new $type168
     (ref.func $function65)
     (struct.new $environment65
      (local.get $3)
      (local.tee $4
       (struct.get $type193 1
        (local.get $0)
       )
      )
     )
    )
    (block (result (ref (exact $type129)))
     (if
      (i32.eqz
       (global.get $ready200)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global200)
      )
     )
     (struct.new_default $type129)
    )
    (i32.const 0)
    (i32.const 1)
    (struct.new_default $type27)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready200)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global200)
   )
  )
  (return_call $function78
   (struct.new $type163
    (ref.func $function72)
    (struct.new $environment72
     (struct.get $type193 1
      (local.get $1)
     )
     (local.get $6)
     (call $function67
      (struct.new $type168
       (ref.func $function71)
       (struct.new $environment71
        (local.get $3)
        (local.get $4)
       )
      )
      (struct.new_default $type129)
      (i32.const 0)
      (i32.const 1)
      (struct.new_default $type27)
      (local.get $2)
     )
    )
   )
   (block (result i32)
    (if
     (i32.eqz
      (global.get $ready228)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global228)
     )
    )
    (i32.const 0)
   )
   (i32.const 1)
   (struct.new_default $type27)
   (struct.get $type193 0
    (local.get $1)
   )
  )
 )
 (func $function65 (type $call168) (param $0 (ref struct)) (param $1 (ref $type36)) (result i32)
  (local $2 (ref $environment65))
  (local $3 (ref $type155))
  (local.set $3
   (struct.get $environment65 1
    (local.tee $2
     (ref.cast (ref $environment65)
      (local.get $0)
     )
    )
   )
  )
  (i64.eqz
   (call_ref $call155
    (struct.get $type36 0
     (local.get $1)
    )
    (struct.get $environment65 0
     (local.get $2)
    )
    (struct.get $type155 0
     (local.get $3)
    )
   )
  )
 )
 (func $function67 (type $167) (param $0 (ref $type168)) (param $1 (ref $type129)) (param $2 i32) (param $3 i32) (param $4 (ref $type26)) (param $5 (ref $type37)) (result (ref $type26))
  (local $6 (ref $type36))
  (if
   (i32.eqz
    (global.get $ready147)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global147)
   )
  )
  (if (result (ref $type27))
   (if (result i32)
    (ref.test (ref $type38)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type39)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready207)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (if
     (i32.eqz
      (global.get $ready112)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type98 1
      (global.get $global112)
     )
    )
    (if (result (ref $type27))
     (if (result i32)
      (ref.test (ref $type28)
       (local.get $4)
      )
      (then
       (drop
        (ref.cast (ref $type28)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (struct.new_default $type27)
     )
     (else
      (return_call $function69
       (i32.const 0)
       (i32.const 1)
       (local.get $4)
       (struct.new_default $type27)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type38)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call168
      (struct.get $type168 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type39 0
        (ref.cast (ref $type39)
         (local.get $5)
        )
       )
      )
      (struct.get $type168 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready121)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global121)
       )
      )
      (local.set $4
       (struct.new $type28
        (struct.get $type36 1
         (local.get $6)
        )
        (struct.new $type29
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready153)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global153)
     )
    )
    (if
     (ref.test (ref $type38)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type40 0
      (struct.get $type39 1
       (ref.cast (ref $type39)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function67
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function69 (type $166) (param $0 i32) (param $1 i32) (param $2 (ref $type26)) (param $3 (ref $type26)) (result (ref $type26))
  (local $4 (ref $type26))
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type28)
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type29 0
    (struct.get $type28 1
     (ref.cast (ref $type28)
      (local.get $2)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready213)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global213)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type28)
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type29 0
   (struct.get $type28 1
    (ref.cast (ref $type28)
     (local.get $2)
    )
   )
   (local.get $3)
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result (ref $type26))
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function69
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $2)
    )
   )
  )
 )
 (func $function71 (type $call168) (param $0 (ref struct)) (param $1 (ref $type36)) (result i32)
  (local $2 (ref $environment71))
  (local $3 (ref $type155))
  (local.set $3
   (struct.get $environment71 1
    (local.tee $2
     (ref.cast (ref $environment71)
      (local.get $0)
     )
    )
   )
  )
  (i64.eq
   (call_ref $call155
    (struct.get $type36 0
     (local.get $1)
    )
    (struct.get $environment71 0
     (local.get $2)
    )
    (struct.get $type155 0
     (local.get $3)
    )
   )
   (i64.const 2)
  )
 )
 (func $function72 (type $call163) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type26))
  (local $3 (ref $environment72))
  (local $4 (ref $type163))
  (local.set $2
   (struct.get $environment72 1
    (ref.cast (ref $environment72)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready221)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global221)
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (local.set $4
   (struct.new $type163
    (ref.func $function73)
    (struct.new $environment73
     (struct.get $environment72 0
      (local.tee $3
       (ref.cast (ref $environment72)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type28)
      (local.get $2)
     )
     (then
      (drop
       (ref.cast (ref $type28)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
     (else
      (i32.const 1)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (call $function75
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready221)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global221)
     )
    )
    (if
     (i32.eqz
      (global.get $ready112)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type98 1
      (global.get $global112)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type28)
       (local.tee $2
        (struct.get $environment72 2
         (local.get $3)
        )
       )
      )
      (then
       (drop
        (ref.cast (ref $type28)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function75
       (struct.new $type163
        (ref.func $function76)
        (struct.new $environment76
         (struct.get $environment72 0
          (local.get $3)
         )
         (local.get $1)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function73 (type $call163) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment73))
  (local $3 (ref $type155))
  (local $4 (ref $type28))
  (local $scratch (ref $type28))
  (local.set $3
   (struct.get $environment73 0
    (local.tee $2
     (ref.cast (ref $environment73)
      (local.get $0)
     )
    )
   )
  )
  (return_call $function41
   (call_ref $call155
    (local.get $1)
    (struct.get $environment73 1
     (local.get $2)
    )
    (struct.get $type155 0
     (local.get $3)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function75 (type $162) (param $0 (ref $type163)) (param $1 i32) (param $2 i32) (param $3 (ref $type26)) (result i32)
  (local $4 (ref $type26))
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type28)
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type29 0
    (struct.get $type28 1
     (ref.cast (ref $type28)
      (local.get $3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call163
     (struct.get $type163 1
      (local.get $0)
     )
     (struct.get $type28 0
      (ref.cast (ref $type28)
       (local.get $3)
      )
     )
     (struct.get $type163 0
      (local.get $0)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call_ref $call163
      (struct.get $type163 1
       (local.get $0)
      )
      (struct.get $type28 0
       (ref.cast (ref $type28)
        (local.get $3)
       )
      )
      (struct.get $type163 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function75
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function76 (type $call163) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment76))
  (local $3 (ref $type155))
  (local $4 (ref $type28))
  (local $scratch (ref $type28))
  (local.set $3
   (struct.get $environment76 0
    (local.tee $2
     (ref.cast (ref $environment76)
      (local.get $0)
     )
    )
   )
  )
  (return_call $function41
   (call_ref $call155
    (local.get $1)
    (struct.get $environment76 1
     (local.get $2)
    )
    (struct.get $type155 0
     (local.get $3)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function78 (type $161) (param $0 (ref $type163)) (param $1 i32) (param $2 i32) (param $3 (ref $type26)) (param $4 (ref $type26)) (result (ref $type26))
  (local $5 i64)
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result (ref $type27))
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready207)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (if
     (i32.eqz
      (global.get $ready112)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type98 1
      (global.get $global112)
     )
    )
    (if (result (ref $type27))
     (if (result i32)
      (ref.test (ref $type28)
       (local.get $3)
      )
      (then
       (drop
        (ref.cast (ref $type28)
         (local.get $3)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (struct.new_default $type27)
     )
     (else
      (return_call $function69
       (i32.const 0)
       (i32.const 1)
       (local.get $3)
       (struct.new_default $type27)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call163
      (struct.get $type163 1
       (local.get $0)
      )
      (local.tee $5
       (struct.get $type28 0
        (ref.cast (ref $type28)
         (local.get $4)
        )
       )
      )
      (struct.get $type163 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready121)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global121)
       )
      )
      (local.set $3
       (struct.new $type28
        (local.get $5)
        (struct.new $type29
         (local.get $3)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type29 0
      (struct.get $type28 1
       (ref.cast (ref $type28)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function78
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function79 (type $call130) (param $0 (ref $type131)) (param $1 (ref $type26)) (result (ref $type42))
  (local $2 (ref $environment62))
  (local $3 (ref $type31))
  (local $4 (ref $type42))
  (local $5 i64)
  (local $scratch (ref $type42))
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result (ref $type42))
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $1)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (struct.new_default $type43)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type28 0
      (ref.cast (ref $type28)
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global188)
     )
    )
    (if
     (i32.eqz
      (global.get $ready178)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global178)
     )
    )
    (struct.new $type44
     (call $function61
      (struct.get $environment62 0
       (local.tee $2
        (struct.get $type131 0
         (local.get $0)
        )
       )
      )
      (struct.get $environment62 1
       (local.get $2)
      )
      (struct.new $type39
       (struct.new $type36
        (struct.get $environment62 5
         (local.get $2)
        )
        (local.get $5)
       )
       (struct.new $type40
        (struct.get $environment62 2
         (local.get $2)
        )
       )
      )
      (struct.get $environment62 6
       (local.get $2)
      )
      (struct.get $environment62 3
       (local.get $2)
      )
      (struct.get $environment62 4
       (local.get $2)
      )
     )
     (block (result (ref (exact $type45)))
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type28)
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type29 0
        (struct.get $type28 1
         (ref.cast (ref $type28)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready235)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global235)
       )
      )
      (struct.new $type45
       (block (result (ref $type42))
        (local.set $scratch
         (call $function79
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready239)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global239)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function83 (type $158) (param $0 (ref $type155)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 (ref $type26)) (param $5 (ref $type26)) (result i64)
  (local $6 i64)
  (local $7 i32)
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (if (result i32)
      (local.tee $7
       (i64.eq
        (local.tee $6
         (call_ref $call155
          (struct.get $type28 0
           (ref.cast (ref $type28)
            (local.get $4)
           )
          )
          (block (result i64)
           (if
            (i32.eqz
             (ref.test (ref $type28)
              (local.get $5)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.get $type28 0
            (ref.cast (ref $type28)
             (local.get $5)
            )
           )
          )
          (struct.get $type155 0
           (local.get $0)
          )
         )
        )
        (i64.const 1)
       )
      )
      (then
       (local.get $7)
      )
      (else
       (i64.eq
        (local.get $1)
        (local.get $6)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type28)
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (struct.get $type29 0
        (struct.get $type28 1
         (ref.cast (ref $type28)
          (local.get $4)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type28)
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (struct.get $type29 0
        (struct.get $type28 1
         (ref.cast (ref $type28)
          (local.get $5)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function83
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
      )
     )
     (else
      (i64.const 3)
     )
    )
   )
  )
 )
 (func $function84 (type $call157) (param $0 (ref $environment84)) (param $1 (ref $type26)) (param $2 (ref $type26)) (result i64)
  (local $3 i64)
  (local $4 i32)
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $1)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (if (result i32)
      (local.tee $4
       (i64.eqz
        (local.tee $3
         (call_ref $call155
          (struct.get $type28 0
           (ref.cast (ref $type28)
            (local.get $1)
           )
          )
          (block (result i64)
           (if
            (i32.eqz
             (ref.test (ref $type28)
              (local.get $2)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.get $type28 0
            (ref.cast (ref $type28)
             (local.get $2)
            )
           )
          )
          (struct.get $type155 0
           (struct.get $environment84 0
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.eq
        (local.get $3)
        (i64.const 2)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type28)
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type29 0
        (struct.get $type28 1
         (ref.cast (ref $type28)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type28)
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function83
       (struct.get $environment84 0
        (local.get $0)
       )
       (local.get $3)
       (i32.const 0)
       (i32.const 1)
       (local.get $1)
       (struct.get $type29 0
        (struct.get $type28 1
         (ref.cast (ref $type28)
          (local.get $2)
         )
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready118)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global118)
         )
        )
        (if
         (i32.eqz
          (ref.test (ref $type28)
           (local.get $1)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type29 0
          (struct.get $type28 1
           (ref.cast (ref $type28)
            (local.get $1)
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready118)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global118)
         )
        )
        (if
         (i32.eqz
          (ref.test (ref $type28)
           (local.get $2)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type29 0
          (struct.get $type28 1
           (ref.cast (ref $type28)
            (local.get $2)
           )
          )
         )
        )
        (if
         (i32.eqz
          (struct.get $type238 0
           (struct.get $environment84 1
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function84
         (struct.get $type157 0
          (struct.get $type238 1
           (struct.get $environment84 1
            (local.get $0)
           )
          )
         )
         (local.get $1)
         (local.get $2)
        )
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $3)
          (i64.const 3)
         )
         (then
          (i64.const 3)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function87 (type $call132) (param $0 (ref $type133)) (param $1 (ref $type48)) (result (ref $type31))
  (local $2 (ref $type26))
  (local $3 (ref $type31))
  (local $scratch (ref $type31))
  (if
   (i32.eqz
    (global.get $ready269)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global269)
   )
  )
  (if (result (ref $type31))
   (if (result i32)
    (ref.test (ref $type49)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type50)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (struct.new_default $type32)
   )
   (else
    (if
     (ref.test (ref $type49)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type33
     (struct.get $type47 1
      (struct.get $type50 0
       (ref.cast (ref $type50)
        (local.get $1)
       )
      )
     )
     (block (result (ref (exact $type34)))
      (if
       (i32.eqz
        (global.get $ready275)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global275)
       )
      )
      (if
       (ref.test (ref $type49)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type51 0
        (struct.get $type50 1
         (ref.cast (ref $type50)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready266)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global266)
       )
      )
      (struct.new $type34
       (block (result (ref $type31))
        (local.set $scratch
         (call $function87
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready155)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global155)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function90 (type $call152) (param $0 (ref $type53)) (result (ref $type42))
  (if
   (i32.eqz
    (global.get $ready278)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global278)
   )
  )
  (return_call $function91
   (local.get $0)
  )
 )
 (func $function91 (type $call152) (param $0 (ref $type53)) (result (ref $type42))
  (local $1 (ref $type53))
  (local $2 (ref $type42))
  (local $3 (ref $type42))
  (local $scratch (ref $type53))
  (local $scratch_5 (ref $type42))
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (if (result (ref $type42))
   (if (result i32)
    (ref.test (ref $type55)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type55)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (struct.new_default $type43)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready285)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global285)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $0)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type56 0
      (struct.get $type55 1
       (ref.cast (ref $type55)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready280)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (if (result (ref $type42))
     (if (result i32)
      (ref.test (ref $type55)
       (local.get $1)
      )
      (then
       (drop
        (ref.cast (ref $type55)
         (local.get $1)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (if
       (i32.eqz
        (ref.test (ref $type55)
         (local.get $0)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.get $type55 0
       (ref.cast (ref $type55)
        (local.get $0)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (ref.test (ref $type55)
         (local.get $0)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function94
       (struct.get $type55 0
        (ref.cast (ref $type55)
         (local.get $0)
        )
       )
       (block (result (ref $type42))
        (if
         (i32.eqz
          (global.get $ready285)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global285)
         )
        )
        (if
         (i32.eqz
          (ref.test (ref $type55)
           (local.get $0)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $scratch_5
         (call $function91
          (block (result (ref $type53))
           (local.set $scratch
            (struct.get $type56 0
             (struct.get $type55 1
              (ref.cast (ref $type55)
               (local.get $0)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready278)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global278)
            )
           )
           (local.get $scratch)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready287)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global287)
         )
        )
        (local.get $scratch_5)
       )
      )
     )
    )
   )
  )
 )
 (func $function94 (type $call149) (param $0 (ref $type42)) (param $1 (ref $type42)) (result (ref $type42))
  (local $2 (ref $type31))
  (local $scratch (ref $type42))
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result (ref $type42))
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $0)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type44
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $0)
      )
     )
     (block (result (ref (exact $type45)))
      (if
       (i32.eqz
        (global.get $ready166)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global166)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $0)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type45
       (block (result (ref $type42))
        (local.set $scratch
         (call $function94
          (struct.get $type45 0
           (struct.get $type44 1
            (ref.cast (ref $type44)
             (local.get $0)
            )
           )
          )
          (block (result (ref $type42))
           (if
            (i32.eqz
             (global.get $ready287)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global287)
            )
           )
           (local.get $1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready239)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global239)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function95 (type $call206) (param $0 (ref $type195)) (param $1 (ref $type195)) (param $2 (ref $type48)) (param $3 (ref $type31)) (param $4 (ref $type207)) (param $5 (ref $type152)) (result (ref $type42))
  (local $6 (ref $type26))
  (local $7 (ref $type135))
  (local $scratch (ref $type31))
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result (ref $type44))
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready266)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global266)
     )
    )
    (struct.new $type44
     (call $function87
      (struct.new_default $type133)
      (local.get $2)
     )
     (block (result (ref (exact $type45)))
      (if
       (i32.eqz
        (global.get $ready239)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global239)
       )
      )
      (struct.new $type45
       (struct.new_default $type43)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready176)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global176)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call152
     (call $function113
      (struct.new $type135
       (struct.new $environment96
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $4)
        (local.get $5)
        (local.get $6)
        (struct.get $type34 0
         (struct.get $type33 1
          (ref.cast (ref $type33)
           (local.get $3)
          )
         )
        )
       )
      )
      (block (result (ref $type31))
       (if
        (i32.eqz
         (global.get $ready303)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global303)
        )
       )
       (local.set $scratch
        (call $function98
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $6)
        )
       )
       (if
        (i32.eqz
         (global.get $ready347)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global347)
        )
       )
       (local.get $scratch)
      )
     )
     (struct.get $type152 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function98 (type $call194) (param $0 (ref $type195)) (param $1 (ref $type195)) (param $2 (ref $type48)) (param $3 (ref $type26)) (result (ref $type31))
  (local $4 (ref $type157))
  (local $5 (ref $type170))
  (local $6 (ref $type31))
  (local $7 (ref $type98))
  (local.set $6
   (call $function101
    (struct.new $type170
     (ref.func $function99)
     (struct.new $environment99
      (local.get $3)
      (local.tee $4
       (struct.get $type195 1
        (local.get $0)
       )
      )
     )
    )
    (block (result (ref (exact $type133)))
     (if
      (i32.eqz
       (global.get $ready312)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global312)
      )
     )
     (struct.new_default $type133)
    )
    (i32.const 0)
    (i32.const 1)
    (struct.new_default $type32)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready312)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global312)
   )
  )
  (return_call $function112
   (struct.new $type98
    (ref.func $function106)
    (struct.new $environment106
     (struct.get $type195 1
      (local.get $1)
     )
     (local.get $6)
     (call $function101
      (struct.new $type170
       (ref.func $function105)
       (struct.new $environment105
        (local.get $3)
        (local.get $4)
       )
      )
      (struct.new_default $type133)
      (i32.const 0)
      (i32.const 1)
      (struct.new_default $type32)
      (local.get $2)
     )
    )
   )
   (block (result i32)
    (if
     (i32.eqz
      (global.get $ready340)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global340)
     )
    )
    (i32.const 0)
   )
   (i32.const 1)
   (struct.new_default $type32)
   (struct.get $type195 0
    (local.get $1)
   )
  )
 )
 (func $function99 (type $call170) (param $0 (ref struct)) (param $1 (ref $type47)) (result i32)
  (local $2 (ref $environment99))
  (i64.eqz
   (call $function84
    (struct.get $type157 0
     (struct.get $environment99 1
      (local.tee $2
       (ref.cast (ref $environment99)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type47 0
     (local.get $1)
    )
    (struct.get $environment99 0
     (local.get $2)
    )
   )
  )
 )
 (func $function101 (type $138) (param $0 (ref $type170)) (param $1 (ref $type133)) (param $2 i32) (param $3 i32) (param $4 (ref $type31)) (param $5 (ref $type48)) (result (ref $type31))
  (local $6 (ref $type47))
  (if
   (i32.eqz
    (global.get $ready269)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global269)
   )
  )
  (if (result (ref $type32))
   (if (result i32)
    (ref.test (ref $type49)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type50)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready319)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global319)
     )
    )
    (if
     (i32.eqz
      (global.get $ready171)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type101 1
      (global.get $global171)
     )
    )
    (if (result (ref $type32))
     (if (result i32)
      (ref.test (ref $type32)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (struct.new_default $type32)
     )
     (else
      (return_call $function103
       (i32.const 0)
       (i32.const 1)
       (local.get $4)
       (struct.new_default $type32)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type49)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call170
      (struct.get $type170 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type50 0
        (ref.cast (ref $type50)
         (local.get $5)
        )
       )
      )
      (struct.get $type170 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready155)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global155)
       )
      )
      (local.set $4
       (struct.new $type33
        (struct.get $type47 1
         (local.get $6)
        )
        (struct.new $type34
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready275)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global275)
     )
    )
    (if
     (ref.test (ref $type49)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type51 0
      (struct.get $type50 1
       (ref.cast (ref $type50)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function101
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function103 (type $137) (param $0 i32) (param $1 i32) (param $2 (ref $type31)) (param $3 (ref $type31)) (result (ref $type31))
  (local $4 (ref $type31))
  (if
   (i32.eqz
    (global.get $ready176)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global176)
   )
  )
  (if
   (ref.test (ref $type32)
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type34 0
    (struct.get $type33 1
     (ref.cast (ref $type33)
      (local.get $2)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready325)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if
   (ref.test (ref $type32)
    (local.get $2)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type34 0
   (struct.get $type33 1
    (ref.cast (ref $type33)
     (local.get $2)
    )
   )
   (local.get $3)
  )
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result (ref $type31))
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $4)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function103
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $2)
    )
   )
  )
 )
 (func $function105 (type $call170) (param $0 (ref struct)) (param $1 (ref $type47)) (result i32)
  (local $2 (ref $environment105))
  (i64.eq
   (call $function84
    (struct.get $type157 0
     (struct.get $environment105 1
      (local.tee $2
       (ref.cast (ref $environment105)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type47 0
     (local.get $1)
    )
    (struct.get $environment105 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function106 (type $call98) (param $0 structref) (param $1 (ref $type26)) (result i32)
  (local $2 (ref $type31))
  (local $3 (ref $environment106))
  (local $4 (ref $type98))
  (local.set $2
   (struct.get $environment106 1
    (ref.cast (ref $environment106)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready333)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global333)
   )
  )
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (local.set $4
   (struct.new $type98
    (ref.func $function107)
    (struct.new $environment107
     (struct.get $environment106 0
      (local.tee $3
       (ref.cast (ref $environment106)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type32)
      (local.get $2)
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (call $function109
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready333)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global333)
     )
    )
    (if
     (i32.eqz
      (global.get $ready171)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type101 1
      (global.get $global171)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type32)
       (local.tee $2
        (struct.get $environment106 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function109
       (struct.new $type98
        (ref.func $function110)
        (struct.new $environment110
         (struct.get $environment106 0
          (local.get $3)
         )
         (local.get $1)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function107 (type $call98) (param $0 structref) (param $1 (ref $type26)) (result i32)
  (local $2 (ref $environment107))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function84
    (struct.get $type157 0
     (struct.get $environment107 0
      (local.tee $2
       (ref.cast (ref $environment107)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment107 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function109 (type $134) (param $0 (ref $type98)) (param $1 i32) (param $2 i32) (param $3 (ref $type31)) (result i32)
  (local $4 (ref $type31))
  (if
   (i32.eqz
    (global.get $ready176)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global176)
   )
  )
  (if
   (ref.test (ref $type32)
    (local.get $3)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type34 0
    (struct.get $type33 1
     (ref.cast (ref $type33)
      (local.get $3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $4)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (ref.test (ref $type32)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call98
     (struct.get $type98 1
      (local.get $0)
     )
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $3)
      )
     )
     (struct.get $type98 0
      (local.get $0)
     )
    )
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call_ref $call98
      (struct.get $type98 1
       (local.get $0)
      )
      (struct.get $type33 0
       (ref.cast (ref $type33)
        (local.get $3)
       )
      )
      (struct.get $type98 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function109
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function110 (type $call98) (param $0 structref) (param $1 (ref $type26)) (result i32)
  (local $2 (ref $environment110))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function84
    (struct.get $type157 0
     (struct.get $environment110 0
      (local.tee $2
       (ref.cast (ref $environment110)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment110 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function112 (type $133) (param $0 (ref $type98)) (param $1 i32) (param $2 i32) (param $3 (ref $type31)) (param $4 (ref $type31)) (result (ref $type31))
  (local $5 (ref $type26))
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result (ref $type32))
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $4)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready319)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global319)
     )
    )
    (if
     (i32.eqz
      (global.get $ready171)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type101 1
      (global.get $global171)
     )
    )
    (if (result (ref $type32))
     (if (result i32)
      (ref.test (ref $type32)
       (local.get $3)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $3)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (struct.new_default $type32)
     )
     (else
      (return_call $function103
       (i32.const 0)
       (i32.const 1)
       (local.get $3)
       (struct.new_default $type32)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call98
      (struct.get $type98 1
       (local.get $0)
      )
      (local.tee $5
       (struct.get $type33 0
        (ref.cast (ref $type33)
         (local.get $4)
        )
       )
      )
      (struct.get $type98 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready155)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global155)
       )
      )
      (local.set $3
       (struct.new $type33
        (local.get $5)
        (struct.new $type34
         (local.get $3)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready176)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global176)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type34 0
      (struct.get $type33 1
       (ref.cast (ref $type33)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function112
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function113 (type $call134) (param $0 (ref $type135)) (param $1 (ref $type31)) (result (ref $type53))
  (local $2 (ref $environment96))
  (local $3 (ref $type26))
  (local $4 (ref $type42))
  (local $5 (ref $type53))
  (local $scratch (ref $type53))
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result (ref $type53))
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (struct.new_default $type54)
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready300)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global300)
     )
    )
    (if
     (i32.eqz
      (global.get $ready290)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global290)
     )
    )
    (struct.new $type55
     (call $function95
      (struct.get $environment96 0
       (local.tee $2
        (struct.get $type135 0
         (local.get $0)
        )
       )
      )
      (struct.get $environment96 1
       (local.get $2)
      )
      (struct.new $type50
       (struct.new $type47
        (struct.get $environment96 5
         (local.get $2)
        )
        (local.get $3)
       )
       (struct.new $type51
        (struct.get $environment96 2
         (local.get $2)
        )
       )
      )
      (struct.get $environment96 6
       (local.get $2)
      )
      (struct.get $environment96 3
       (local.get $2)
      )
      (struct.get $environment96 4
       (local.get $2)
      )
     )
     (block (result (ref (exact $type56)))
      (if
       (i32.eqz
        (global.get $ready176)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global176)
       )
      )
      (if
       (ref.test (ref $type32)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type34 0
        (struct.get $type33 1
         (ref.cast (ref $type33)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready347)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global347)
       )
      )
      (struct.new $type56
       (block (result (ref $type53))
        (local.set $scratch
         (call $function113
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready351)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global351)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function117 (type $130) (param $0 (ref $type157)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 (ref $type31)) (param $5 (ref $type31)) (result i64)
  (local $6 (ref $type26))
  (local $7 i64)
  (local $8 i32)
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $4)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $4)
      )
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (if (result i32)
      (local.tee $8
       (i64.eq
        (local.tee $7
         (call $function84
          (struct.get $type157 0
           (local.get $0)
          )
          (local.get $6)
          (struct.get $type33 0
           (ref.cast (ref $type33)
            (local.get $5)
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (then
       (local.get $8)
      )
      (else
       (i64.eq
        (local.get $1)
        (local.get $7)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready176)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global176)
       )
      )
      (if
       (ref.test (ref $type32)
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (struct.get $type34 0
        (struct.get $type33 1
         (ref.cast (ref $type33)
          (local.get $4)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready176)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global176)
       )
      )
      (if
       (ref.test (ref $type32)
        (local.get $5)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (struct.get $type34 0
        (struct.get $type33 1
         (ref.cast (ref $type33)
          (local.get $5)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function117
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
      )
     )
     (else
      (i64.const 3)
     )
    )
   )
  )
 )
 (func $function118 (type $call159) (param $0 (ref $environment118)) (param $1 (ref $type31)) (param $2 (ref $type31)) (result i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type26))
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (if (result i32)
      (local.tee $4
       (i64.eqz
        (local.tee $3
         (call $function84
          (struct.get $type157 0
           (struct.get $environment118 0
            (local.get $0)
           )
          )
          (local.get $5)
          (struct.get $type33 0
           (ref.cast (ref $type33)
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.eq
        (local.get $3)
        (i64.const 2)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready176)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global176)
       )
      )
      (if
       (ref.test (ref $type32)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type34 0
        (struct.get $type33 1
         (ref.cast (ref $type33)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready176)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global176)
       )
      )
      (if
       (ref.test (ref $type32)
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function117
       (struct.get $environment118 0
        (local.get $0)
       )
       (local.get $3)
       (i32.const 0)
       (i32.const 1)
       (local.get $1)
       (struct.get $type34 0
        (struct.get $type33 1
         (ref.cast (ref $type33)
          (local.get $2)
         )
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready176)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global176)
         )
        )
        (if
         (ref.test (ref $type32)
          (local.get $1)
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type34 0
          (struct.get $type33 1
           (ref.cast (ref $type33)
            (local.get $1)
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready176)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global176)
         )
        )
        (if
         (ref.test (ref $type32)
          (local.get $2)
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type34 0
          (struct.get $type33 1
           (ref.cast (ref $type33)
            (local.get $2)
           )
          )
         )
        )
        (if
         (i32.eqz
          (struct.get $type239 0
           (struct.get $environment118 1
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function118
         (struct.get $type159 0
          (struct.get $type239 1
           (struct.get $environment118 1
            (local.get $0)
           )
          )
         )
         (local.get $1)
         (local.get $2)
        )
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $3)
          (i64.const 3)
         )
         (then
          (i64.const 3)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function121 (type $call208) (param $0 (ref $type193)) (param $1 (ref $type193)) (param $2 (ref $type37)) (param $3 (ref $type26)) (param $4 (ref $type209)) (param $5 (ref $type139)) (result i64)
  (local $6 i64)
  (local $7 (ref $type137))
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type28 0
      (ref.cast (ref $type28)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.new $type137
      (ref.func $function122)
      (struct.new $environment122
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (struct.get $type29 0
        (struct.get $type28 1
         (ref.cast (ref $type28)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready191)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global191)
     )
    )
    (local.set $3
     (call $function64
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $6)
     )
    )
    (if
     (i32.eqz
      (global.get $ready387)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global387)
     )
    )
    (return_call_ref $call139
     (struct.get $type139 1
      (local.get $5)
     )
     (call $function123
      (local.get $7)
      (local.get $3)
     )
     (struct.get $type139 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function122 (type $call137) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment122))
  (local $3 (ref $type193))
  (return_call $function121
   (struct.get $environment122 0
    (local.tee $2
     (ref.cast (ref $environment122)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type193))
    (if
     (i32.eqz
      (global.get $ready188)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global188)
     )
    )
    (if
     (i32.eqz
      (global.get $ready377)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global377)
     )
    )
    (struct.get $environment122 1
     (local.get $2)
    )
   )
   (struct.new $type39
    (struct.new $type36
     (struct.get $environment122 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type40
     (struct.get $environment122 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment122 6
    (local.get $2)
   )
   (struct.get $environment122 3
    (local.get $2)
   )
   (struct.get $environment122 4
    (local.get $2)
   )
  )
 )
 (func $function123 (type $call136) (param $0 (ref $type137)) (param $1 (ref $type26)) (result (ref $type26))
  (local $2 i64)
  (local $scratch (ref $type26))
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result (ref $type26))
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $1)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (struct.new_default $type27)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type28
     (call_ref $call137
      (struct.get $type137 1
       (local.get $0)
      )
      (struct.get $type28 0
       (ref.cast (ref $type28)
        (local.get $1)
       )
      )
      (struct.get $type137 0
       (local.get $0)
      )
     )
     (block (result (ref (exact $type29)))
      (if
       (i32.eqz
        (global.get $ready118)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global118)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type28)
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type29 0
        (struct.get $type28 1
         (ref.cast (ref $type28)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready387)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global387)
       )
      )
      (struct.new $type29
       (block (result (ref $type26))
        (local.set $scratch
         (call $function123
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready121)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global121)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function126 (type $call210) (param $0 (ref $type195)) (param $1 (ref $type195)) (param $2 (ref $type48)) (param $3 (ref $type31)) (param $4 (ref $type211)) (param $5 (ref $type139)) (result i64)
  (local $6 (ref $type26))
  (local $7 (ref $type139))
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready176)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global176)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.new $type139
      (ref.func $function127)
      (struct.new $environment127
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (struct.get $type34 0
        (struct.get $type33 1
         (ref.cast (ref $type33)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready303)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global303)
     )
    )
    (local.set $3
     (call $function98
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $6)
     )
    )
    (if
     (i32.eqz
      (global.get $ready405)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global405)
     )
    )
    (return_call_ref $call139
     (struct.get $type139 1
      (local.get $5)
     )
     (call $function128
      (local.get $7)
      (local.get $3)
     )
     (struct.get $type139 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function127 (type $call139) (param $0 structref) (param $1 (ref $type26)) (result i64)
  (local $2 (ref $environment127))
  (local $3 (ref $type195))
  (return_call $function126
   (struct.get $environment127 0
    (local.tee $2
     (ref.cast (ref $environment127)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type195))
    (if
     (i32.eqz
      (global.get $ready300)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global300)
     )
    )
    (if
     (i32.eqz
      (global.get $ready395)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global395)
     )
    )
    (struct.get $environment127 1
     (local.get $2)
    )
   )
   (struct.new $type50
    (struct.new $type47
     (struct.get $environment127 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type51
     (struct.get $environment127 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment127 6
    (local.get $2)
   )
   (struct.get $environment127 3
    (local.get $2)
   )
   (struct.get $environment127 4
    (local.get $2)
   )
  )
 )
 (func $function128 (type $call138) (param $0 (ref $type139)) (param $1 (ref $type31)) (result (ref $type26))
  (local $2 i64)
  (local $3 (ref $type26))
  (local $scratch (ref $type26))
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result (ref $type26))
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (struct.new_default $type27)
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type28
     (call_ref $call139
      (struct.get $type139 1
       (local.get $0)
      )
      (struct.get $type33 0
       (ref.cast (ref $type33)
        (local.get $1)
       )
      )
      (struct.get $type139 0
       (local.get $0)
      )
     )
     (block (result (ref (exact $type29)))
      (if
       (i32.eqz
        (global.get $ready176)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global176)
       )
      )
      (if
       (ref.test (ref $type32)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type34 0
        (struct.get $type33 1
         (ref.cast (ref $type33)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready405)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global405)
       )
      )
      (struct.new $type29
       (block (result (ref $type26))
        (local.set $scratch
         (call $function128
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready121)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global121)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function131 (type $call212) (param $0 (ref $type193)) (param $1 (ref $type195)) (param $2 (ref $type59)) (param $3 (ref $type26)) (param $4 (ref $type213)) (param $5 (ref $type139)) (result i64)
  (local $6 i64)
  (local $7 (ref $type31))
  (local $8 (ref $type139))
  (local $9 (ref $type155))
  (local $10 (ref $type98))
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type28)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type28)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type28 0
      (ref.cast (ref $type28)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type28)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.new $type139
      (ref.func $function132)
      (struct.new $environment132
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (struct.get $type29 0
        (struct.get $type28 1
         (ref.cast (ref $type28)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready426)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global426)
     )
    )
    (if
     (i32.eqz
      (global.get $ready435)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global435)
     )
    )
    (local.set $7
     (call $function137
      (struct.new $type172
       (ref.func $function135)
       (struct.new $environment135
        (local.get $6)
        (local.tee $9
         (struct.get $type193 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type173)
      (i32.const 0)
      (i32.const 1)
      (struct.new_default $type32)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready435)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global435)
     )
    )
    (local.set $7
     (call $function112
      (struct.new $type98
       (ref.func $function141)
       (struct.new $environment141
        (struct.get $type195 1
         (local.get $1)
        )
        (local.get $7)
        (call $function137
         (struct.new $type172
          (ref.func $function140)
          (struct.new $environment140
           (local.get $6)
           (local.get $9)
          )
         )
         (struct.new_default $type173)
         (i32.const 0)
         (i32.const 1)
         (struct.new_default $type32)
         (local.get $2)
        )
       )
      )
      (block (result i32)
       (if
        (i32.eqz
         (global.get $ready340)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global340)
        )
       )
       (i32.const 0)
      )
      (i32.const 1)
      (struct.new_default $type32)
      (struct.get $type195 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready405)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global405)
     )
    )
    (return_call_ref $call139
     (struct.get $type139 1
      (local.get $5)
     )
     (call $function128
      (local.get $8)
      (local.get $7)
     )
     (struct.get $type139 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function132 (type $call139) (param $0 structref) (param $1 (ref $type26)) (result i64)
  (local $2 (ref $environment132))
  (local $3 (ref $type193))
  (return_call $function131
   (struct.get $environment132 0
    (local.tee $2
     (ref.cast (ref $environment132)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type195))
    (if
     (i32.eqz
      (global.get $ready423)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global423)
     )
    )
    (if
     (i32.eqz
      (global.get $ready413)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global413)
     )
    )
    (struct.get $environment132 1
     (local.get $2)
    )
   )
   (struct.new $type61
    (struct.new $type58
     (struct.get $environment132 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type62
     (struct.get $environment132 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment132 6
    (local.get $2)
   )
   (struct.get $environment132 3
    (local.get $2)
   )
   (struct.get $environment132 4
    (local.get $2)
   )
  )
 )
 (func $function135 (type $call172) (param $0 (ref struct)) (param $1 (ref $type58)) (result i32)
  (local $2 (ref $environment135))
  (local $3 (ref $type155))
  (local.set $3
   (struct.get $environment135 1
    (local.tee $2
     (ref.cast (ref $environment135)
      (local.get $0)
     )
    )
   )
  )
  (i64.eqz
   (call_ref $call155
    (struct.get $type58 0
     (local.get $1)
    )
    (struct.get $environment135 0
     (local.get $2)
    )
    (struct.get $type155 0
     (local.get $3)
    )
   )
  )
 )
 (func $function137 (type $111) (param $0 (ref $type172)) (param $1 (ref $type173)) (param $2 i32) (param $3 i32) (param $4 (ref $type31)) (param $5 (ref $type59)) (result (ref $type31))
  (local $6 (ref $type58))
  (if
   (i32.eqz
    (global.get $ready442)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global442)
   )
  )
  (if (result (ref $type32))
   (if (result i32)
    (ref.test (ref $type60)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type61)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready319)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global319)
     )
    )
    (if
     (i32.eqz
      (global.get $ready171)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type101 1
      (global.get $global171)
     )
    )
    (if (result (ref $type32))
     (if (result i32)
      (ref.test (ref $type32)
       (local.get $4)
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (struct.new_default $type32)
     )
     (else
      (return_call $function103
       (i32.const 0)
       (i32.const 1)
       (local.get $4)
       (struct.new_default $type32)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type60)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call172
      (struct.get $type172 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type61 0
        (ref.cast (ref $type61)
         (local.get $5)
        )
       )
      )
      (struct.get $type172 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready155)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global155)
       )
      )
      (local.set $4
       (struct.new $type33
        (struct.get $type58 1
         (local.get $6)
        )
        (struct.new $type34
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready448)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global448)
     )
    )
    (if
     (ref.test (ref $type60)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type62 0
      (struct.get $type61 1
       (ref.cast (ref $type61)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function137
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function140 (type $call172) (param $0 (ref struct)) (param $1 (ref $type58)) (result i32)
  (local $2 (ref $environment140))
  (local $3 (ref $type155))
  (local.set $3
   (struct.get $environment140 1
    (local.tee $2
     (ref.cast (ref $environment140)
      (local.get $0)
     )
    )
   )
  )
  (i64.eq
   (call_ref $call155
    (struct.get $type58 0
     (local.get $1)
    )
    (struct.get $environment140 0
     (local.get $2)
    )
    (struct.get $type155 0
     (local.get $3)
    )
   )
   (i64.const 2)
  )
 )
 (func $function141 (type $call98) (param $0 structref) (param $1 (ref $type26)) (result i32)
  (local $2 (ref $type31))
  (local $3 (ref $environment141))
  (local $4 (ref $type98))
  (local.set $2
   (struct.get $environment141 1
    (ref.cast (ref $environment141)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready333)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global333)
   )
  )
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (local.set $4
   (struct.new $type98
    (ref.func $function142)
    (struct.new $environment142
     (struct.get $environment141 0
      (local.tee $3
       (ref.cast (ref $environment141)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type32)
      (local.get $2)
     )
     (then
      (i32.const 1)
     )
     (else
      (drop
       (ref.cast (ref $type33)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (call $function109
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready333)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global333)
     )
    )
    (if
     (i32.eqz
      (global.get $ready171)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type101 1
      (global.get $global171)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type32)
       (local.tee $2
        (struct.get $environment141 2
         (local.get $3)
        )
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (drop
        (ref.cast (ref $type33)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function109
       (struct.new $type98
        (ref.func $function143)
        (struct.new $environment143
         (struct.get $environment141 0
          (local.get $3)
         )
         (local.get $1)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function142 (type $call98) (param $0 structref) (param $1 (ref $type26)) (result i32)
  (local $2 (ref $environment142))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function84
    (struct.get $type157 0
     (struct.get $environment142 0
      (local.tee $2
       (ref.cast (ref $environment142)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment142 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function143 (type $call98) (param $0 structref) (param $1 (ref $type26)) (result i32)
  (local $2 (ref $environment143))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function84
    (struct.get $type157 0
     (struct.get $environment143 0
      (local.tee $2
       (ref.cast (ref $environment143)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment143 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function146 (type $call214) (param $0 (ref $type195)) (param $1 (ref $type193)) (param $2 (ref $type65)) (param $3 (ref $type31)) (param $4 (ref $type215)) (param $5 (ref $type139)) (result i64)
  (local $6 (ref $type26))
  (local $7 (ref $type26))
  (local $8 (ref $type137))
  (local $9 (ref $type157))
  (local $10 (ref $type163))
  (if
   (i32.eqz
    (global.get $ready171)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type101 1
    (global.get $global171)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type32)
     (local.get $3)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type33)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (ref.test (ref $type32)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type33 0
      (ref.cast (ref $type33)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready176)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global176)
     )
    )
    (if
     (ref.test (ref $type32)
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.new $type137
      (ref.func $function147)
      (struct.new $environment147
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (struct.get $type34 0
        (struct.get $type33 1
         (ref.cast (ref $type33)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready472)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global472)
     )
    )
    (if
     (i32.eqz
      (global.get $ready481)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global481)
     )
    )
    (local.set $7
     (call $function152
      (struct.new $type175
       (ref.func $function150)
       (struct.new $environment150
        (local.get $6)
        (local.tee $9
         (struct.get $type195 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type176)
      (i32.const 0)
      (i32.const 1)
      (struct.new_default $type27)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready481)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global481)
     )
    )
    (local.set $6
     (call $function78
      (struct.new $type163
       (ref.func $function156)
       (struct.new $environment156
        (struct.get $type193 1
         (local.get $1)
        )
        (local.get $7)
        (call $function152
         (struct.new $type175
          (ref.func $function155)
          (struct.new $environment155
           (local.get $6)
           (local.get $9)
          )
         )
         (struct.new_default $type176)
         (i32.const 0)
         (i32.const 1)
         (struct.new_default $type27)
         (local.get $2)
        )
       )
      )
      (block (result i32)
       (if
        (i32.eqz
         (global.get $ready228)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global228)
        )
       )
       (i32.const 0)
      )
      (i32.const 1)
      (struct.new_default $type27)
      (struct.get $type193 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready387)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global387)
     )
    )
    (return_call_ref $call139
     (struct.get $type139 1
      (local.get $5)
     )
     (call $function123
      (local.get $8)
      (local.get $6)
     )
     (struct.get $type139 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function147 (type $call137) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment147))
  (local $3 (ref $type195))
  (return_call $function146
   (struct.get $environment147 0
    (local.tee $2
     (ref.cast (ref $environment147)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type193))
    (if
     (i32.eqz
      (global.get $ready469)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global469)
     )
    )
    (if
     (i32.eqz
      (global.get $ready459)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global459)
     )
    )
    (struct.get $environment147 1
     (local.get $2)
    )
   )
   (struct.new $type67
    (struct.new $type64
     (struct.get $environment147 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type68
     (struct.get $environment147 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment147 6
    (local.get $2)
   )
   (struct.get $environment147 3
    (local.get $2)
   )
   (struct.get $environment147 4
    (local.get $2)
   )
  )
 )
 (func $function150 (type $call175) (param $0 (ref struct)) (param $1 (ref $type64)) (result i32)
  (local $2 (ref $environment150))
  (i64.eqz
   (call $function84
    (struct.get $type157 0
     (struct.get $environment150 1
      (local.tee $2
       (ref.cast (ref $environment150)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type64 0
     (local.get $1)
    )
    (struct.get $environment150 0
     (local.get $2)
    )
   )
  )
 )
 (func $function152 (type $97) (param $0 (ref $type175)) (param $1 (ref $type176)) (param $2 i32) (param $3 i32) (param $4 (ref $type26)) (param $5 (ref $type65)) (result (ref $type26))
  (local $6 (ref $type64))
  (if
   (i32.eqz
    (global.get $ready488)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global488)
   )
  )
  (if (result (ref $type27))
   (if (result i32)
    (ref.test (ref $type66)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type67)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready207)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global207)
     )
    )
    (if
     (i32.eqz
      (global.get $ready112)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type98 1
      (global.get $global112)
     )
    )
    (if (result (ref $type27))
     (if (result i32)
      (ref.test (ref $type28)
       (local.get $4)
      )
      (then
       (drop
        (ref.cast (ref $type28)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (struct.new_default $type27)
     )
     (else
      (return_call $function69
       (i32.const 0)
       (i32.const 1)
       (local.get $4)
       (struct.new_default $type27)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type66)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call175
      (struct.get $type175 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type67 0
        (ref.cast (ref $type67)
         (local.get $5)
        )
       )
      )
      (struct.get $type175 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready121)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global121)
       )
      )
      (local.set $4
       (struct.new $type28
        (struct.get $type64 1
         (local.get $6)
        )
        (struct.new $type29
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready494)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global494)
     )
    )
    (if
     (ref.test (ref $type66)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type68 0
      (struct.get $type67 1
       (ref.cast (ref $type67)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function152
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function155 (type $call175) (param $0 (ref struct)) (param $1 (ref $type64)) (result i32)
  (local $2 (ref $environment155))
  (i64.eq
   (call $function84
    (struct.get $type157 0
     (struct.get $environment155 1
      (local.tee $2
       (ref.cast (ref $environment155)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type64 0
     (local.get $1)
    )
    (struct.get $environment155 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function156 (type $call163) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type26))
  (local $3 (ref $environment156))
  (local $4 (ref $type163))
  (local.set $2
   (struct.get $environment156 1
    (ref.cast (ref $environment156)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready221)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global221)
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type98 1
    (global.get $global112)
   )
  )
  (local.set $4
   (struct.new $type163
    (ref.func $function157)
    (struct.new $environment157
     (struct.get $environment156 0
      (local.tee $3
       (ref.cast (ref $environment156)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type28)
      (local.get $2)
     )
     (then
      (drop
       (ref.cast (ref $type28)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
     (else
      (i32.const 1)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (call $function75
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready221)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global221)
     )
    )
    (if
     (i32.eqz
      (global.get $ready112)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type98 1
      (global.get $global112)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type28)
       (local.tee $2
        (struct.get $environment156 2
         (local.get $3)
        )
       )
      )
      (then
       (drop
        (ref.cast (ref $type28)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function75
       (struct.new $type163
        (ref.func $function158)
        (struct.new $environment158
         (struct.get $environment156 0
          (local.get $3)
         )
         (local.get $1)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function157 (type $call163) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment157))
  (local $3 (ref $type155))
  (local $4 (ref $type28))
  (local $scratch (ref $type28))
  (local.set $3
   (struct.get $environment157 0
    (local.tee $2
     (ref.cast (ref $environment157)
      (local.get $0)
     )
    )
   )
  )
  (return_call $function41
   (call_ref $call155
    (local.get $1)
    (struct.get $environment157 1
     (local.get $2)
    )
    (struct.get $type155 0
     (local.get $3)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function158 (type $call163) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment158))
  (local $3 (ref $type155))
  (local $4 (ref $type28))
  (local $scratch (ref $type28))
  (local.set $3
   (struct.get $environment158 0
    (local.tee $2
     (ref.cast (ref $environment158)
      (local.get $0)
     )
    )
   )
  )
  (return_call $function41
   (call_ref $call155
    (local.get $1)
    (struct.get $environment158 1
     (local.get $2)
    )
    (struct.get $type155 0
     (local.get $3)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function161 (type $call216) (param $0 (ref $type199)) (param $1 (ref $type199)) (param $2 (ref $type71)) (param $3 (ref $type42)) (param $4 (ref $type217)) (param $5 (ref $type139)) (result i64)
  (local $6 (ref $type31))
  (local $7 (ref $type141))
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready166)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global166)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.new $type141
      (ref.func $function162)
      (struct.new $environment162
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (struct.get $type45 0
        (struct.get $type44 1
         (ref.cast (ref $type44)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready520)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global520)
     )
    )
    (local.set $3
     (call $function164
      (local.get $0)
      (local.get $1)
      (local.get $2)
      (local.get $6)
     )
    )
    (if
     (i32.eqz
      (global.get $ready571)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global571)
     )
    )
    (return_call_ref $call139
     (struct.get $type139 1
      (local.get $5)
     )
     (call $function181
      (local.get $7)
      (local.get $3)
     )
     (struct.get $type139 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function162 (type $call141) (param $0 (ref struct)) (param $1 (ref $type31)) (result i64)
  (local $2 (ref $environment162))
  (local $3 (ref $type199))
  (return_call $function161
   (struct.get $environment162 0
    (local.tee $2
     (ref.cast (ref $environment162)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type199))
    (if
     (i32.eqz
      (global.get $ready517)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global517)
     )
    )
    (if
     (i32.eqz
      (global.get $ready507)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global507)
     )
    )
    (struct.get $environment162 1
     (local.get $2)
    )
   )
   (struct.new $type73
    (struct.new $type70
     (struct.get $environment162 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type74
     (struct.get $environment162 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment162 6
    (local.get $2)
   )
   (struct.get $environment162 3
    (local.get $2)
   )
   (struct.get $environment162 4
    (local.get $2)
   )
  )
 )
 (func $function164 (type $call198) (param $0 (ref $type199)) (param $1 (ref $type199)) (param $2 (ref $type71)) (param $3 (ref $type31)) (result (ref $type42))
  (local $4 (ref $type159))
  (local $5 (ref $type178))
  (local $6 (ref $type42))
  (local $7 (ref $type101))
  (local.set $6
   (call $function167
    (struct.new $type178
     (ref.func $function165)
     (struct.new $environment165
      (local.get $3)
      (local.tee $4
       (struct.get $type199 1
        (local.get $0)
       )
      )
     )
    )
    (block (result (ref (exact $type143)))
     (if
      (i32.eqz
       (global.get $ready529)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global529)
      )
     )
     (struct.new_default $type143)
    )
    (i32.const 0)
    (i32.const 1)
    (struct.new_default $type43)
    (local.get $2)
   )
  )
  (if
   (i32.eqz
    (global.get $ready529)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global529)
   )
  )
  (return_call $function180
   (struct.new $type101
    (ref.func $function174)
    (struct.new $environment174
     (struct.get $type199 1
      (local.get $1)
     )
     (local.get $6)
     (call $function167
      (struct.new $type178
       (ref.func $function173)
       (struct.new $environment173
        (local.get $3)
        (local.get $4)
       )
      )
      (struct.new_default $type143)
      (i32.const 0)
      (i32.const 1)
      (struct.new_default $type43)
      (local.get $2)
     )
    )
   )
   (block (result i32)
    (if
     (i32.eqz
      (global.get $ready564)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global564)
     )
    )
    (i32.const 0)
   )
   (i32.const 1)
   (struct.new_default $type43)
   (struct.get $type199 0
    (local.get $1)
   )
  )
 )
 (func $function165 (type $call178) (param $0 (ref struct)) (param $1 (ref $type70)) (result i32)
  (local $2 (ref $environment165))
  (i64.eqz
   (call $function118
    (struct.get $type159 0
     (struct.get $environment165 1
      (local.tee $2
       (ref.cast (ref $environment165)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type70 0
     (local.get $1)
    )
    (struct.get $environment165 0
     (local.get $2)
    )
   )
  )
 )
 (func $function167 (type $80) (param $0 (ref $type178)) (param $1 (ref $type143)) (param $2 i32) (param $3 i32) (param $4 (ref $type42)) (param $5 (ref $type71)) (result (ref $type42))
  (local $6 (ref $type70))
  (if
   (i32.eqz
    (global.get $ready536)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global536)
   )
  )
  (if (result (ref $type43))
   (if (result i32)
    (ref.test (ref $type72)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type73)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready541)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global541)
     )
    )
    (if
     (i32.eqz
      (global.get $ready161)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global161)
     )
    )
    (if (result (ref $type43))
     (if (result i32)
      (ref.test (ref $type44)
       (local.get $4)
      )
      (then
       (drop
        (ref.cast (ref $type44)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (struct.new_default $type43)
     )
     (else
      (return_call $function170
       (i32.const 0)
       (i32.const 1)
       (local.get $4)
       (struct.new_default $type43)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type72)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call178
      (struct.get $type178 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type73 0
        (ref.cast (ref $type73)
         (local.get $5)
        )
       )
      )
      (struct.get $type178 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready239)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global239)
       )
      )
      (local.set $4
       (struct.new $type44
        (struct.get $type70 1
         (local.get $6)
        )
        (struct.new $type45
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready551)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global551)
     )
    )
    (if
     (ref.test (ref $type72)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type74 0
      (struct.get $type73 1
       (ref.cast (ref $type73)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function167
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function170 (type $79) (param $0 i32) (param $1 i32) (param $2 (ref $type42)) (param $3 (ref $type42)) (result (ref $type42))
  (local $4 (ref $type42))
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global166)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type44)
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type45 0
    (struct.get $type44 1
     (ref.cast (ref $type44)
      (local.get $2)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready547)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global547)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type44)
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type45 0
   (struct.get $type44 1
    (ref.cast (ref $type44)
     (local.get $2)
    )
   )
   (local.get $3)
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result (ref $type42))
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function170
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $2)
    )
   )
  )
 )
 (func $function173 (type $call178) (param $0 (ref struct)) (param $1 (ref $type70)) (result i32)
  (local $2 (ref $environment173))
  (i64.eq
   (call $function118
    (struct.get $type159 0
     (struct.get $environment173 1
      (local.tee $2
       (ref.cast (ref $environment173)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type70 0
     (local.get $1)
    )
    (struct.get $environment173 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function174 (type $call101) (param $0 structref) (param $1 (ref $type31)) (result i32)
  (local $2 (ref $type42))
  (local $3 (ref $environment174))
  (local $4 (ref $type101))
  (local.set $2
   (struct.get $environment174 1
    (ref.cast (ref $environment174)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready557)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global557)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (local.set $4
   (struct.new $type101
    (ref.func $function175)
    (struct.new $environment175
     (struct.get $environment174 0
      (local.tee $3
       (ref.cast (ref $environment174)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type44)
      (local.get $2)
     )
     (then
      (drop
       (ref.cast (ref $type44)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
     (else
      (i32.const 1)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (call $function177
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready557)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global557)
     )
    )
    (if
     (i32.eqz
      (global.get $ready161)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global161)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type44)
       (local.tee $2
        (struct.get $environment174 2
         (local.get $3)
        )
       )
      )
      (then
       (drop
        (ref.cast (ref $type44)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function177
       (struct.new $type101
        (ref.func $function178)
        (struct.new $environment178
         (struct.get $environment174 0
          (local.get $3)
         )
         (local.get $1)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function175 (type $call101) (param $0 structref) (param $1 (ref $type31)) (result i32)
  (local $2 (ref $environment175))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function118
    (struct.get $type159 0
     (struct.get $environment175 0
      (local.tee $2
       (ref.cast (ref $environment175)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment175 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function177 (type $76) (param $0 (ref $type101)) (param $1 i32) (param $2 i32) (param $3 (ref $type42)) (result i32)
  (local $4 (ref $type42))
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global166)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type44)
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type45 0
    (struct.get $type44 1
     (ref.cast (ref $type44)
      (local.get $3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call101
     (struct.get $type101 1
      (local.get $0)
     )
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $3)
      )
     )
     (struct.get $type101 0
      (local.get $0)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call_ref $call101
      (struct.get $type101 1
       (local.get $0)
      )
      (struct.get $type44 0
       (ref.cast (ref $type44)
        (local.get $3)
       )
      )
      (struct.get $type101 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function177
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function178 (type $call101) (param $0 structref) (param $1 (ref $type31)) (result i32)
  (local $2 (ref $environment178))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function118
    (struct.get $type159 0
     (struct.get $environment178 0
      (local.tee $2
       (ref.cast (ref $environment178)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment178 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function180 (type $75) (param $0 (ref $type101)) (param $1 i32) (param $2 i32) (param $3 (ref $type42)) (param $4 (ref $type42)) (result (ref $type42))
  (local $5 (ref $type31))
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result (ref $type43))
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready541)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global541)
     )
    )
    (if
     (i32.eqz
      (global.get $ready161)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global161)
     )
    )
    (if (result (ref $type43))
     (if (result i32)
      (ref.test (ref $type44)
       (local.get $3)
      )
      (then
       (drop
        (ref.cast (ref $type44)
         (local.get $3)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (struct.new_default $type43)
     )
     (else
      (return_call $function170
       (i32.const 0)
       (i32.const 1)
       (local.get $3)
       (struct.new_default $type43)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call101
      (struct.get $type101 1
       (local.get $0)
      )
      (local.tee $5
       (struct.get $type44 0
        (ref.cast (ref $type44)
         (local.get $4)
        )
       )
      )
      (struct.get $type101 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready239)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global239)
       )
      )
      (local.set $3
       (struct.new $type44
        (local.get $5)
        (struct.new $type45
         (local.get $3)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready166)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global166)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type45 0
      (struct.get $type44 1
       (ref.cast (ref $type44)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function180
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function181 (type $call140) (param $0 (ref $type141)) (param $1 (ref $type42)) (result (ref $type26))
  (local $2 i64)
  (local $3 (ref $type26))
  (local $scratch (ref $type26))
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result (ref $type26))
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $1)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (struct.new_default $type27)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type28
     (call_ref $call141
      (struct.get $type141 1
       (local.get $0)
      )
      (struct.get $type44 0
       (ref.cast (ref $type44)
        (local.get $1)
       )
      )
      (struct.get $type141 0
       (local.get $0)
      )
     )
     (block (result (ref (exact $type29)))
      (if
       (i32.eqz
        (global.get $ready166)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global166)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type45 0
        (struct.get $type44 1
         (ref.cast (ref $type44)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready571)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global571)
       )
      )
      (struct.new $type29
       (block (result (ref $type26))
        (local.set $scratch
         (call $function181
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready121)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global121)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function184 (type $call142) (param $0 (ref $type143)) (param $1 (ref $type71)) (result (ref $type42))
  (local $2 (ref $type31))
  (local $3 (ref $type42))
  (local $scratch (ref $type42))
  (if
   (i32.eqz
    (global.get $ready536)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global536)
   )
  )
  (if (result (ref $type42))
   (if (result i32)
    (ref.test (ref $type72)
     (local.get $1)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type73)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (struct.new_default $type43)
   )
   (else
    (if
     (ref.test (ref $type72)
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type44
     (struct.get $type70 1
      (struct.get $type73 0
       (ref.cast (ref $type73)
        (local.get $1)
       )
      )
     )
     (block (result (ref (exact $type45)))
      (if
       (i32.eqz
        (global.get $ready551)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global551)
       )
      )
      (if
       (ref.test (ref $type72)
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type74 0
        (struct.get $type73 1
         (ref.cast (ref $type73)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready581)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global581)
       )
      )
      (struct.new $type45
       (block (result (ref $type42))
        (local.set $scratch
         (call $function184
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready239)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global239)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function185 (type $call153) (param $0 (ref $type76)) (result (ref $type53))
  (if
   (i32.eqz
    (global.get $ready586)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global586)
   )
  )
  (return_call $function186
   (local.get $0)
  )
 )
 (func $function186 (type $call153) (param $0 (ref $type76)) (result (ref $type53))
  (local $1 (ref $type76))
  (local $2 (ref $type53))
  (local $3 (ref $type53))
  (local $scratch (ref $type76))
  (local $scratch_5 (ref $type53))
  (if
   (i32.eqz
    (global.get $ready588)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global588)
   )
  )
  (if (result (ref $type53))
   (if (result i32)
    (ref.test (ref $type78)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type78)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (struct.new_default $type54)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready593)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global593)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type78)
       (local.get $0)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type79 0
      (struct.get $type78 1
       (ref.cast (ref $type78)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready588)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global588)
     )
    )
    (if (result (ref $type53))
     (if (result i32)
      (ref.test (ref $type78)
       (local.get $1)
      )
      (then
       (drop
        (ref.cast (ref $type78)
         (local.get $1)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (if
       (i32.eqz
        (ref.test (ref $type78)
         (local.get $0)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.get $type78 0
       (ref.cast (ref $type78)
        (local.get $0)
       )
      )
     )
     (else
      (if
       (i32.eqz
        (ref.test (ref $type78)
         (local.get $0)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function189
       (struct.get $type78 0
        (ref.cast (ref $type78)
         (local.get $0)
        )
       )
       (block (result (ref $type53))
        (if
         (i32.eqz
          (global.get $ready593)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global593)
         )
        )
        (if
         (i32.eqz
          (ref.test (ref $type78)
           (local.get $0)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $scratch_5
         (call $function186
          (block (result (ref $type76))
           (local.set $scratch
            (struct.get $type79 0
             (struct.get $type78 1
              (ref.cast (ref $type78)
               (local.get $0)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready586)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global586)
            )
           )
           (local.get $scratch)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready595)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global595)
         )
        )
        (local.get $scratch_5)
       )
      )
     )
    )
   )
  )
 )
 (func $function189 (type $call150) (param $0 (ref $type53)) (param $1 (ref $type53)) (result (ref $type53))
  (local $2 (ref $type42))
  (local $scratch (ref $type53))
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (if (result (ref $type53))
   (if (result i32)
    (ref.test (ref $type55)
     (local.get $0)
    )
    (then
     (drop
      (ref.cast (ref $type55)
       (local.get $0)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $0)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type55
     (struct.get $type55 0
      (ref.cast (ref $type55)
       (local.get $0)
      )
     )
     (block (result (ref (exact $type56)))
      (if
       (i32.eqz
        (global.get $ready285)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global285)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type55)
         (local.get $0)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type56
       (block (result (ref $type53))
        (local.set $scratch
         (call $function189
          (struct.get $type56 0
           (struct.get $type55 1
            (ref.cast (ref $type55)
             (local.get $0)
            )
           )
          )
          (block (result (ref $type53))
           (if
            (i32.eqz
             (global.get $ready595)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global595)
            )
           )
           (local.get $1)
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready351)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global351)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function190 (type $call218) (param $0 (ref $type199)) (param $1 (ref $type199)) (param $2 (ref $type71)) (param $3 (ref $type42)) (param $4 (ref $type219)) (param $5 (ref $type153)) (result (ref $type53))
  (local $6 (ref $type31))
  (local $7 (ref $type145))
  (local $scratch (ref $type42))
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result (ref $type55))
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready581)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global581)
     )
    )
    (struct.new $type55
     (call $function184
      (struct.new_default $type143)
      (local.get $2)
     )
     (block (result (ref (exact $type56)))
      (if
       (i32.eqz
        (global.get $ready351)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global351)
       )
      )
      (struct.new $type56
       (struct.new_default $type54)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready166)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global166)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call153
     (call $function192
      (struct.new $type145
       (struct.new $environment191
        (local.get $0)
        (local.get $1)
        (local.get $2)
        (local.get $4)
        (local.get $5)
        (local.get $6)
        (struct.get $type45 0
         (struct.get $type44 1
          (ref.cast (ref $type44)
           (local.get $3)
          )
         )
        )
       )
      )
      (block (result (ref $type42))
       (if
        (i32.eqz
         (global.get $ready520)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global520)
        )
       )
       (local.set $scratch
        (call $function164
         (local.get $0)
         (local.get $1)
         (local.get $2)
         (local.get $6)
        )
       )
       (if
        (i32.eqz
         (global.get $ready608)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global608)
        )
       )
       (local.get $scratch)
      )
     )
     (struct.get $type153 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function192 (type $call144) (param $0 (ref $type145)) (param $1 (ref $type42)) (result (ref $type76))
  (local $2 (ref $environment191))
  (local $3 (ref $type31))
  (local $4 (ref $type53))
  (local $5 (ref $type76))
  (local $scratch (ref $type76))
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result (ref $type76))
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $1)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (struct.new_default $type77)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready517)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global517)
     )
    )
    (if
     (i32.eqz
      (global.get $ready598)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global598)
     )
    )
    (struct.new $type78
     (call $function190
      (struct.get $environment191 0
       (local.tee $2
        (struct.get $type145 0
         (local.get $0)
        )
       )
      )
      (struct.get $environment191 1
       (local.get $2)
      )
      (struct.new $type73
       (struct.new $type70
        (struct.get $environment191 5
         (local.get $2)
        )
        (local.get $3)
       )
       (struct.new $type74
        (struct.get $environment191 2
         (local.get $2)
        )
       )
      )
      (struct.get $environment191 6
       (local.get $2)
      )
      (struct.get $environment191 3
       (local.get $2)
      )
      (struct.get $environment191 4
       (local.get $2)
      )
     )
     (block (result (ref (exact $type79)))
      (if
       (i32.eqz
        (global.get $ready166)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global166)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type45 0
        (struct.get $type44 1
         (ref.cast (ref $type44)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready608)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global608)
       )
      )
      (struct.new $type79
       (block (result (ref $type76))
        (local.set $scratch
         (call $function192
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready612)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global612)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function196 (type $63) (param $0 (ref $type159)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 (ref $type42)) (param $5 (ref $type42)) (result i64)
  (local $6 (ref $type31))
  (local $7 i64)
  (local $8 i32)
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (if (result i32)
      (local.tee $8
       (i64.eq
        (local.tee $7
         (call $function118
          (struct.get $type159 0
           (local.get $0)
          )
          (local.get $6)
          (struct.get $type44 0
           (ref.cast (ref $type44)
            (local.get $5)
           )
          )
         )
        )
        (i64.const 1)
       )
      )
      (then
       (local.get $8)
      )
      (else
       (i64.eq
        (local.get $1)
        (local.get $7)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready166)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global166)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (struct.get $type45 0
        (struct.get $type44 1
         (ref.cast (ref $type44)
          (local.get $4)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready166)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global166)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (struct.get $type45 0
        (struct.get $type44 1
         (ref.cast (ref $type44)
          (local.get $5)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function196
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (local.get $5)
      )
     )
     (else
      (i64.const 3)
     )
    )
   )
  )
 )
 (func $function197 (type $call161) (param $0 (ref $environment197)) (param $1 (ref $type42)) (param $2 (ref $type42)) (result i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type31))
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $1)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (if (result i32)
      (local.tee $4
       (i64.eqz
        (local.tee $3
         (call $function118
          (struct.get $type159 0
           (struct.get $environment197 0
            (local.get $0)
           )
          )
          (local.get $5)
          (struct.get $type44 0
           (ref.cast (ref $type44)
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.eq
        (local.get $3)
        (i64.const 2)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready166)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global166)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type45 0
        (struct.get $type44 1
         (ref.cast (ref $type44)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready166)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global166)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type44)
         (local.get $2)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function196
       (struct.get $environment197 0
        (local.get $0)
       )
       (local.get $3)
       (i32.const 0)
       (i32.const 1)
       (local.get $1)
       (struct.get $type45 0
        (struct.get $type44 1
         (ref.cast (ref $type44)
          (local.get $2)
         )
        )
       )
      )
     )
     (else
      (if (result i64)
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready166)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global166)
         )
        )
        (if
         (i32.eqz
          (ref.test (ref $type44)
           (local.get $1)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $1
         (struct.get $type45 0
          (struct.get $type44 1
           (ref.cast (ref $type44)
            (local.get $1)
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready166)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global166)
         )
        )
        (if
         (i32.eqz
          (ref.test (ref $type44)
           (local.get $2)
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $2
         (struct.get $type45 0
          (struct.get $type44 1
           (ref.cast (ref $type44)
            (local.get $2)
           )
          )
         )
        )
        (if
         (i32.eqz
          (struct.get $type240 0
           (struct.get $environment197 1
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function197
         (struct.get $type161 0
          (struct.get $type240 1
           (struct.get $environment197 1
            (local.get $0)
           )
          )
         )
         (local.get $1)
         (local.get $2)
        )
       )
       (else
        (if (result i64)
         (i64.eq
          (local.get $3)
          (i64.const 3)
         )
         (then
          (i64.const 3)
         )
         (else
          (unreachable)
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function200 (type $call220) (param $0 (ref $type199)) (param $1 (ref $type201)) (param $2 (ref $type82)) (param $3 (ref $type42)) (param $4 (ref $type221)) (param $5 (ref $type139)) (result i64)
  (local $6 (ref $type31))
  (local $7 (ref $type53))
  (local $8 (ref $type147))
  (local $9 (ref $type159))
  (local $10 (ref $type100))
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type44)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type44)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type44 0
      (ref.cast (ref $type44)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready166)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global166)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type44)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.new $type147
      (ref.func $function201)
      (struct.new $environment201
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (struct.get $type45 0
        (struct.get $type44 1
         (ref.cast (ref $type44)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready651)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global651)
     )
    )
    (if
     (i32.eqz
      (global.get $ready660)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global660)
     )
    )
    (local.set $7
     (call $function206
      (struct.new $type180
       (ref.func $function204)
       (struct.new $environment204
        (local.get $6)
        (local.tee $9
         (struct.get $type199 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type181)
      (i32.const 0)
      (i32.const 1)
      (struct.new_default $type54)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready660)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global660)
     )
    )
    (local.set $7
     (call $function219
      (struct.new $type100
       (ref.func $function213)
       (struct.new $environment213
        (struct.get $type201 1
         (local.get $1)
        )
        (local.get $7)
        (call $function206
         (struct.new $type180
          (ref.func $function212)
          (struct.new $environment212
           (local.get $6)
           (local.get $9)
          )
         )
         (struct.new_default $type181)
         (i32.const 0)
         (i32.const 1)
         (struct.new_default $type54)
         (local.get $2)
        )
       )
      )
      (block (result i32)
       (if
        (i32.eqz
         (global.get $ready695)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global695)
        )
       )
       (i32.const 0)
      )
      (i32.const 1)
      (struct.new_default $type54)
      (struct.get $type201 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready702)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global702)
     )
    )
    (return_call_ref $call139
     (struct.get $type139 1
      (local.get $5)
     )
     (call $function220
      (local.get $8)
      (local.get $7)
     )
     (struct.get $type139 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function201 (type $call147) (param $0 (ref struct)) (param $1 (ref $type42)) (result i64)
  (local $2 (ref $environment201))
  (local $3 (ref $type199))
  (return_call $function200
   (struct.get $environment201 0
    (local.tee $2
     (ref.cast (ref $environment201)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type201))
    (if
     (i32.eqz
      (global.get $ready648)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global648)
     )
    )
    (if
     (i32.eqz
      (global.get $ready638)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global638)
     )
    )
    (struct.get $environment201 1
     (local.get $2)
    )
   )
   (struct.new $type84
    (struct.new $type81
     (struct.get $environment201 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type85
     (struct.get $environment201 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment201 6
    (local.get $2)
   )
   (struct.get $environment201 3
    (local.get $2)
   )
   (struct.get $environment201 4
    (local.get $2)
   )
  )
 )
 (func $function204 (type $call180) (param $0 (ref struct)) (param $1 (ref $type81)) (result i32)
  (local $2 (ref $environment204))
  (i64.eqz
   (call $function118
    (struct.get $type159 0
     (struct.get $environment204 1
      (local.tee $2
       (ref.cast (ref $environment204)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type81 0
     (local.get $1)
    )
    (struct.get $environment204 0
     (local.get $2)
    )
   )
  )
 )
 (func $function206 (type $48) (param $0 (ref $type180)) (param $1 (ref $type181)) (param $2 i32) (param $3 i32) (param $4 (ref $type53)) (param $5 (ref $type82)) (result (ref $type53))
  (local $6 (ref $type81))
  (if
   (i32.eqz
    (global.get $ready667)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global667)
   )
  )
  (if (result (ref $type54))
   (if (result i32)
    (ref.test (ref $type83)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type84)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready672)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global672)
     )
    )
    (if
     (i32.eqz
      (global.get $ready280)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (if (result (ref $type54))
     (if (result i32)
      (ref.test (ref $type55)
       (local.get $4)
      )
      (then
       (drop
        (ref.cast (ref $type55)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (struct.new_default $type54)
     )
     (else
      (return_call $function209
       (i32.const 0)
       (i32.const 1)
       (local.get $4)
       (struct.new_default $type54)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type83)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call180
      (struct.get $type180 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type84 0
        (ref.cast (ref $type84)
         (local.get $5)
        )
       )
      )
      (struct.get $type180 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready351)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global351)
       )
      )
      (local.set $4
       (struct.new $type55
        (struct.get $type81 1
         (local.get $6)
        )
        (struct.new $type56
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready682)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global682)
     )
    )
    (if
     (ref.test (ref $type83)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type85 0
      (struct.get $type84 1
       (ref.cast (ref $type84)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function206
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function209 (type $47) (param $0 i32) (param $1 i32) (param $2 (ref $type53)) (param $3 (ref $type53)) (result (ref $type53))
  (local $4 (ref $type53))
  (if
   (i32.eqz
    (global.get $ready285)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global285)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type55)
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type56 0
    (struct.get $type55 1
     (ref.cast (ref $type55)
      (local.get $2)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready678)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global678)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type55)
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type56 0
   (struct.get $type55 1
    (ref.cast (ref $type55)
     (local.get $2)
    )
   )
   (local.get $3)
  )
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (if (result (ref $type53))
   (if (result i32)
    (ref.test (ref $type55)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type55)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function209
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $2)
    )
   )
  )
 )
 (func $function212 (type $call180) (param $0 (ref struct)) (param $1 (ref $type81)) (result i32)
  (local $2 (ref $environment212))
  (i64.eq
   (call $function118
    (struct.get $type159 0
     (struct.get $environment212 1
      (local.tee $2
       (ref.cast (ref $environment212)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type81 0
     (local.get $1)
    )
    (struct.get $environment212 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function213 (type $call100) (param $0 structref) (param $1 (ref $type42)) (result i32)
  (local $2 (ref $type53))
  (local $3 (ref $environment213))
  (local $4 (ref $type100))
  (local.set $2
   (struct.get $environment213 1
    (ref.cast (ref $environment213)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready688)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global688)
   )
  )
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (local.set $4
   (struct.new $type100
    (ref.func $function214)
    (struct.new $environment214
     (struct.get $environment213 0
      (local.tee $3
       (ref.cast (ref $environment213)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type55)
      (local.get $2)
     )
     (then
      (drop
       (ref.cast (ref $type55)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
     (else
      (i32.const 1)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (call $function216
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready688)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global688)
     )
    )
    (if
     (i32.eqz
      (global.get $ready280)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type55)
       (local.tee $2
        (struct.get $environment213 2
         (local.get $3)
        )
       )
      )
      (then
       (drop
        (ref.cast (ref $type55)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function216
       (struct.new $type100
        (ref.func $function217)
        (struct.new $environment217
         (struct.get $environment213 0
          (local.get $3)
         )
         (local.get $1)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function214 (type $call100) (param $0 structref) (param $1 (ref $type42)) (result i32)
  (local $2 (ref $environment214))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function197
    (struct.get $type161 0
     (struct.get $environment214 0
      (local.tee $2
       (ref.cast (ref $environment214)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment214 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function216 (type $44) (param $0 (ref $type100)) (param $1 i32) (param $2 i32) (param $3 (ref $type53)) (result i32)
  (local $4 (ref $type53))
  (if
   (i32.eqz
    (global.get $ready285)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global285)
   )
  )
  (if
   (i32.eqz
    (ref.test (ref $type55)
     (local.get $3)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type56 0
    (struct.get $type55 1
     (ref.cast (ref $type55)
      (local.get $3)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (if (result i32)
   (if (result i32)
    (ref.test (ref $type55)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type55)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call100
     (struct.get $type100 1
      (local.get $0)
     )
     (struct.get $type55 0
      (ref.cast (ref $type55)
       (local.get $3)
      )
     )
     (struct.get $type100 0
      (local.get $0)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call_ref $call100
      (struct.get $type100 1
       (local.get $0)
      )
      (struct.get $type55 0
       (ref.cast (ref $type55)
        (local.get $3)
       )
      )
      (struct.get $type100 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function216
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function217 (type $call100) (param $0 structref) (param $1 (ref $type42)) (result i32)
  (local $2 (ref $environment217))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function197
    (struct.get $type161 0
     (struct.get $environment217 0
      (local.tee $2
       (ref.cast (ref $environment217)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment217 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function219 (type $43) (param $0 (ref $type100)) (param $1 i32) (param $2 i32) (param $3 (ref $type53)) (param $4 (ref $type53)) (result (ref $type53))
  (local $5 (ref $type42))
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (if (result (ref $type54))
   (if (result i32)
    (ref.test (ref $type55)
     (local.get $4)
    )
    (then
     (drop
      (ref.cast (ref $type55)
       (local.get $4)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready672)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global672)
     )
    )
    (if
     (i32.eqz
      (global.get $ready280)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (if (result (ref $type54))
     (if (result i32)
      (ref.test (ref $type55)
       (local.get $3)
      )
      (then
       (drop
        (ref.cast (ref $type55)
         (local.get $3)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (struct.new_default $type54)
     )
     (else
      (return_call $function209
       (i32.const 0)
       (i32.const 1)
       (local.get $3)
       (struct.new_default $type54)
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call100
      (struct.get $type100 1
       (local.get $0)
      )
      (local.tee $5
       (struct.get $type55 0
        (ref.cast (ref $type55)
         (local.get $4)
        )
       )
      )
      (struct.get $type100 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready351)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global351)
       )
      )
      (local.set $3
       (struct.new $type55
        (local.get $5)
        (struct.new $type56
         (local.get $3)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready285)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global285)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $4)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type56 0
      (struct.get $type55 1
       (ref.cast (ref $type55)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function219
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
    )
   )
  )
 )
 (func $function220 (type $call146) (param $0 (ref $type147)) (param $1 (ref $type53)) (result (ref $type26))
  (local $2 i64)
  (local $3 (ref $type26))
  (local $scratch (ref $type26))
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (if (result (ref $type26))
   (if (result i32)
    (ref.test (ref $type55)
     (local.get $1)
    )
    (then
     (drop
      (ref.cast (ref $type55)
       (local.get $1)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (struct.new_default $type27)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $1)
      )
     )
     (then
      (unreachable)
     )
    )
    (struct.new $type28
     (call_ref $call147
      (struct.get $type147 1
       (local.get $0)
      )
      (struct.get $type55 0
       (ref.cast (ref $type55)
        (local.get $1)
       )
      )
      (struct.get $type147 0
       (local.get $0)
      )
     )
     (block (result (ref (exact $type29)))
      (if
       (i32.eqz
        (global.get $ready285)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global285)
       )
      )
      (if
       (i32.eqz
        (ref.test (ref $type55)
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type56 0
        (struct.get $type55 1
         (ref.cast (ref $type55)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready702)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global702)
       )
      )
      (struct.new $type29
       (block (result (ref $type26))
        (local.set $scratch
         (call $function220
          (local.get $0)
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready121)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global121)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
   )
  )
 )
 (func $function223 (type $call222) (param $0 (ref $type201)) (param $1 (ref $type199)) (param $2 (ref $type88)) (param $3 (ref $type53)) (param $4 (ref $type223)) (param $5 (ref $type139)) (result i64)
  (local $6 (ref $type42))
  (local $7 (ref $type42))
  (local $8 (ref $type141))
  (local $9 (ref $type161))
  (local $10 (ref $type101))
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type55)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type55)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type55 0
      (ref.cast (ref $type55)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready285)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global285)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (struct.new $type141
      (ref.func $function224)
      (struct.new $environment224
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (struct.get $type56 0
        (struct.get $type55 1
         (ref.cast (ref $type55)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready725)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global725)
     )
    )
    (if
     (i32.eqz
      (global.get $ready734)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global734)
     )
    )
    (local.set $7
     (call $function229
      (struct.new $type183
       (ref.func $function227)
       (struct.new $environment227
        (local.get $6)
        (local.tee $9
         (struct.get $type201 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type184)
      (i32.const 0)
      (i32.const 1)
      (struct.new_default $type43)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready734)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global734)
     )
    )
    (local.set $6
     (call $function180
      (struct.new $type101
       (ref.func $function233)
       (struct.new $environment233
        (struct.get $type199 1
         (local.get $1)
        )
        (local.get $7)
        (call $function229
         (struct.new $type183
          (ref.func $function232)
          (struct.new $environment232
           (local.get $6)
           (local.get $9)
          )
         )
         (struct.new_default $type184)
         (i32.const 0)
         (i32.const 1)
         (struct.new_default $type43)
         (local.get $2)
        )
       )
      )
      (block (result i32)
       (if
        (i32.eqz
         (global.get $ready564)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global564)
        )
       )
       (i32.const 0)
      )
      (i32.const 1)
      (struct.new_default $type43)
      (struct.get $type199 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready571)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global571)
     )
    )
    (return_call_ref $call139
     (struct.get $type139 1
      (local.get $5)
     )
     (call $function181
      (local.get $8)
      (local.get $6)
     )
     (struct.get $type139 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function224 (type $call141) (param $0 (ref struct)) (param $1 (ref $type31)) (result i64)
  (local $2 (ref $environment224))
  (local $3 (ref $type201))
  (return_call $function223
   (struct.get $environment224 0
    (local.tee $2
     (ref.cast (ref $environment224)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type199))
    (if
     (i32.eqz
      (global.get $ready722)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global722)
     )
    )
    (if
     (i32.eqz
      (global.get $ready712)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global712)
     )
    )
    (struct.get $environment224 1
     (local.get $2)
    )
   )
   (struct.new $type90
    (struct.new $type87
     (struct.get $environment224 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type91
     (struct.get $environment224 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment224 6
    (local.get $2)
   )
   (struct.get $environment224 3
    (local.get $2)
   )
   (struct.get $environment224 4
    (local.get $2)
   )
  )
 )
 (func $function227 (type $call183) (param $0 (ref struct)) (param $1 (ref $type87)) (result i32)
  (local $2 (ref $environment227))
  (i64.eqz
   (call $function197
    (struct.get $type161 0
     (struct.get $environment227 1
      (local.tee $2
       (ref.cast (ref $environment227)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type87 0
     (local.get $1)
    )
    (struct.get $environment227 0
     (local.get $2)
    )
   )
  )
 )
 (func $function229 (type $30) (param $0 (ref $type183)) (param $1 (ref $type184)) (param $2 i32) (param $3 i32) (param $4 (ref $type42)) (param $5 (ref $type88)) (result (ref $type42))
  (local $6 (ref $type87))
  (if
   (i32.eqz
    (global.get $ready741)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global741)
   )
  )
  (if (result (ref $type43))
   (if (result i32)
    (ref.test (ref $type89)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type90)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready541)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global541)
     )
    )
    (if
     (i32.eqz
      (global.get $ready161)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global161)
     )
    )
    (if (result (ref $type43))
     (if (result i32)
      (ref.test (ref $type44)
       (local.get $4)
      )
      (then
       (drop
        (ref.cast (ref $type44)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (struct.new_default $type43)
     )
     (else
      (return_call $function170
       (i32.const 0)
       (i32.const 1)
       (local.get $4)
       (struct.new_default $type43)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type89)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call183
      (struct.get $type183 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type90 0
        (ref.cast (ref $type90)
         (local.get $5)
        )
       )
      )
      (struct.get $type183 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready239)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global239)
       )
      )
      (local.set $4
       (struct.new $type44
        (struct.get $type87 1
         (local.get $6)
        )
        (struct.new $type45
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready747)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global747)
     )
    )
    (if
     (ref.test (ref $type89)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type91 0
      (struct.get $type90 1
       (ref.cast (ref $type90)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function229
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function232 (type $call183) (param $0 (ref struct)) (param $1 (ref $type87)) (result i32)
  (local $2 (ref $environment232))
  (i64.eq
   (call $function197
    (struct.get $type161 0
     (struct.get $environment232 1
      (local.tee $2
       (ref.cast (ref $environment232)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type87 0
     (local.get $1)
    )
    (struct.get $environment232 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function233 (type $call101) (param $0 structref) (param $1 (ref $type31)) (result i32)
  (local $2 (ref $type42))
  (local $3 (ref $environment233))
  (local $4 (ref $type101))
  (local.set $2
   (struct.get $environment233 1
    (ref.cast (ref $environment233)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready557)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global557)
   )
  )
  (if
   (i32.eqz
    (global.get $ready161)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type100 1
    (global.get $global161)
   )
  )
  (local.set $4
   (struct.new $type101
    (ref.func $function234)
    (struct.new $environment234
     (struct.get $environment233 0
      (local.tee $3
       (ref.cast (ref $environment233)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type44)
      (local.get $2)
     )
     (then
      (drop
       (ref.cast (ref $type44)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
     (else
      (i32.const 1)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (call $function177
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready557)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global557)
     )
    )
    (if
     (i32.eqz
      (global.get $ready161)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type100 1
      (global.get $global161)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type44)
       (local.tee $2
        (struct.get $environment233 2
         (local.get $3)
        )
       )
      )
      (then
       (drop
        (ref.cast (ref $type44)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function177
       (struct.new $type101
        (ref.func $function235)
        (struct.new $environment235
         (struct.get $environment233 0
          (local.get $3)
         )
         (local.get $1)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function234 (type $call101) (param $0 structref) (param $1 (ref $type31)) (result i32)
  (local $2 (ref $environment234))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function118
    (struct.get $type159 0
     (struct.get $environment234 0
      (local.tee $2
       (ref.cast (ref $environment234)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment234 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function235 (type $call101) (param $0 structref) (param $1 (ref $type31)) (result i32)
  (local $2 (ref $environment235))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function118
    (struct.get $type159 0
     (struct.get $environment235 0
      (local.tee $2
       (ref.cast (ref $environment235)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment235 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function238 (type $call224) (param $0 (ref $type201)) (param $1 (ref $type201)) (param $2 (ref $type94)) (param $3 (ref $type53)) (param $4 (ref $type225)) (param $5 (ref $type139)) (result i64)
  (local $6 (ref $type42))
  (local $7 (ref $type147))
  (local $8 (ref $type161))
  (local $9 (ref $type100))
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (if (result i64)
   (if (result i32)
    (ref.test (ref $type55)
     (local.get $3)
    )
    (then
     (drop
      (ref.cast (ref $type55)
       (local.get $3)
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type55 0
      (ref.cast (ref $type55)
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready285)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global285)
     )
    )
    (if
     (i32.eqz
      (ref.test (ref $type55)
       (local.get $3)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $7
     (struct.new $type147
      (ref.func $function239)
      (struct.new $environment239
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $4)
       (local.get $5)
       (local.get $6)
       (struct.get $type56 0
        (struct.get $type55 1
         (ref.cast (ref $type55)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready773)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global773)
     )
    )
    (if
     (i32.eqz
      (global.get $ready782)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global782)
     )
    )
    (local.set $3
     (call $function244
      (struct.new $type186
       (ref.func $function242)
       (struct.new $environment242
        (local.get $6)
        (local.tee $8
         (struct.get $type201 1
          (local.get $0)
         )
        )
       )
      )
      (struct.new_default $type187)
      (i32.const 0)
      (i32.const 1)
      (struct.new_default $type54)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (global.get $ready782)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global782)
     )
    )
    (local.set $3
     (call $function219
      (struct.new $type100
       (ref.func $function248)
       (struct.new $environment248
        (struct.get $type201 1
         (local.get $1)
        )
        (local.get $3)
        (call $function244
         (struct.new $type186
          (ref.func $function247)
          (struct.new $environment247
           (local.get $6)
           (local.get $8)
          )
         )
         (struct.new_default $type187)
         (i32.const 0)
         (i32.const 1)
         (struct.new_default $type54)
         (local.get $2)
        )
       )
      )
      (block (result i32)
       (if
        (i32.eqz
         (global.get $ready695)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global695)
        )
       )
       (i32.const 0)
      )
      (i32.const 1)
      (struct.new_default $type54)
      (struct.get $type201 0
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready702)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global702)
     )
    )
    (return_call_ref $call139
     (struct.get $type139 1
      (local.get $5)
     )
     (call $function220
      (local.get $7)
      (local.get $3)
     )
     (struct.get $type139 0
      (local.get $5)
     )
    )
   )
  )
 )
 (func $function239 (type $call147) (param $0 (ref struct)) (param $1 (ref $type42)) (result i64)
  (local $2 (ref $environment239))
  (local $3 (ref $type201))
  (return_call $function238
   (struct.get $environment239 0
    (local.tee $2
     (ref.cast (ref $environment239)
      (local.get $0)
     )
    )
   )
   (block (result (ref $type201))
    (if
     (i32.eqz
      (global.get $ready770)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global770)
     )
    )
    (if
     (i32.eqz
      (global.get $ready760)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global760)
     )
    )
    (struct.get $environment239 1
     (local.get $2)
    )
   )
   (struct.new $type96
    (struct.new $type93
     (struct.get $environment239 5
      (local.get $2)
     )
     (local.get $1)
    )
    (struct.new $type97
     (struct.get $environment239 2
      (local.get $2)
     )
    )
   )
   (struct.get $environment239 6
    (local.get $2)
   )
   (struct.get $environment239 3
    (local.get $2)
   )
   (struct.get $environment239 4
    (local.get $2)
   )
  )
 )
 (func $function242 (type $call186) (param $0 (ref struct)) (param $1 (ref $type93)) (result i32)
  (local $2 (ref $environment242))
  (i64.eqz
   (call $function197
    (struct.get $type161 0
     (struct.get $environment242 1
      (local.tee $2
       (ref.cast (ref $environment242)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type93 0
     (local.get $1)
    )
    (struct.get $environment242 0
     (local.get $2)
    )
   )
  )
 )
 (func $function244 (type $16) (param $0 (ref $type186)) (param $1 (ref $type187)) (param $2 i32) (param $3 i32) (param $4 (ref $type53)) (param $5 (ref $type94)) (result (ref $type53))
  (local $6 (ref $type93))
  (if
   (i32.eqz
    (global.get $ready789)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global789)
   )
  )
  (if (result (ref $type54))
   (if (result i32)
    (ref.test (ref $type95)
     (local.get $5)
    )
    (then
     (i32.const 1)
    )
    (else
     (drop
      (ref.cast (ref $type96)
       (local.get $5)
      )
     )
     (i32.const 0)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready672)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global672)
     )
    )
    (if
     (i32.eqz
      (global.get $ready280)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (if (result (ref $type54))
     (if (result i32)
      (ref.test (ref $type55)
       (local.get $4)
      )
      (then
       (drop
        (ref.cast (ref $type55)
         (local.get $4)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (struct.new_default $type54)
     )
     (else
      (return_call $function209
       (i32.const 0)
       (i32.const 1)
       (local.get $4)
       (struct.new_default $type54)
      )
     )
    )
   )
   (else
    (if
     (ref.test (ref $type95)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (if
     (call_ref $call186
      (struct.get $type186 1
       (local.get $0)
      )
      (local.tee $6
       (struct.get $type96 0
        (ref.cast (ref $type96)
         (local.get $5)
        )
       )
      )
      (struct.get $type186 0
       (local.get $0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready351)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global351)
       )
      )
      (local.set $4
       (struct.new $type55
        (struct.get $type93 1
         (local.get $6)
        )
        (struct.new $type56
         (local.get $4)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready795)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global795)
     )
    )
    (if
     (ref.test (ref $type95)
      (local.get $5)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type97 0
      (struct.get $type96 1
       (ref.cast (ref $type96)
        (local.get $5)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function244
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function247 (type $call186) (param $0 (ref struct)) (param $1 (ref $type93)) (result i32)
  (local $2 (ref $environment247))
  (i64.eq
   (call $function197
    (struct.get $type161 0
     (struct.get $environment247 1
      (local.tee $2
       (ref.cast (ref $environment247)
        (local.get $0)
       )
      )
     )
    )
    (struct.get $type93 0
     (local.get $1)
    )
    (struct.get $environment247 0
     (local.get $2)
    )
   )
   (i64.const 2)
  )
 )
 (func $function248 (type $call100) (param $0 structref) (param $1 (ref $type42)) (result i32)
  (local $2 (ref $type53))
  (local $3 (ref $environment248))
  (local $4 (ref $type100))
  (local.set $2
   (struct.get $environment248 1
    (ref.cast (ref $environment248)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready688)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global688)
   )
  )
  (if
   (i32.eqz
    (global.get $ready280)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global280)
   )
  )
  (local.set $4
   (struct.new $type100
    (ref.func $function249)
    (struct.new $environment249
     (struct.get $environment248 0
      (local.tee $3
       (ref.cast (ref $environment248)
        (local.get $0)
       )
      )
     )
     (local.get $1)
    )
   )
  )
  (if (result i32)
   (if (result i32)
    (if (result i32)
     (ref.test (ref $type55)
      (local.get $2)
     )
     (then
      (drop
       (ref.cast (ref $type55)
        (local.get $2)
       )
      )
      (i32.const 0)
     )
     (else
      (i32.const 1)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (call $function216
      (local.get $4)
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready688)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global688)
     )
    )
    (if
     (i32.eqz
      (global.get $ready280)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global280)
     )
    )
    (if (result i32)
     (if (result i32)
      (ref.test (ref $type55)
       (local.tee $2
        (struct.get $environment248 2
         (local.get $3)
        )
       )
      )
      (then
       (drop
        (ref.cast (ref $type55)
         (local.get $2)
        )
       )
       (i32.const 0)
      )
      (else
       (i32.const 1)
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (return_call $function216
       (struct.new $type100
        (ref.func $function250)
        (struct.new $environment250
         (struct.get $environment248 0
          (local.get $3)
         )
         (local.get $1)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function249 (type $call100) (param $0 structref) (param $1 (ref $type42)) (result i32)
  (local $2 (ref $environment249))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function197
    (struct.get $type161 0
     (struct.get $environment249 0
      (local.tee $2
       (ref.cast (ref $environment249)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment249 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function250 (type $call100) (param $0 structref) (param $1 (ref $type42)) (result i32)
  (local $2 (ref $environment250))
  (local $3 (ref $type28))
  (local $4 i64)
  (local $scratch (ref $type28))
  (return_call $function41
   (call $function197
    (struct.get $type161 0
     (struct.get $environment250 0
      (local.tee $2
       (ref.cast (ref $environment250)
        (local.get $0)
       )
      )
     )
    )
    (local.get $1)
    (struct.get $environment250 1
     (local.get $2)
    )
   )
   (block (result (ref $type28))
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (local.set $scratch
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global109)
     )
    )
    (local.get $scratch)
   )
  )
 )
 (func $function251 (type $call137) (param $0 structref) (param $1 i64) (result i64)
  (local $2 i64)
  (if
   (i64.le_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready802)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready805)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global805)
     )
    )
    (local.set $2
     (call $foreign0
      (global.get $global802)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function253
     (local.get $1)
     (i32.const 0)
     (i32.const 1)
     (i64.const 1)
     (call $function46
      (struct.get $type137 1
       (global.get $global128)
      )
      (local.get $2)
     )
    )
   )
  )
  (unreachable)
 )
 (func $function252 (type $call155) (param $0 i64) (param $1 i64) (result i64)
  (call $foreign0
   (local.get $1)
  )
 )
 (func $function253 (type $13) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready802)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready805)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global805)
     )
    )
    (local.set $4
     (call $foreign0
      (global.get $global802)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (call $function46
      (struct.get $type137 1
       (global.get $global128)
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function253
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (local.get $4)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready803)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type137 1
    (global.get $global803)
   )
  )
  (if
   (i64.le_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready802)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready805)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global805)
     )
    )
    (local.set $1
     (call $foreign0
      (global.get $global802)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function253
     (local.get $0)
     (i32.const 0)
     (i32.const 1)
     (i64.const 1)
     (call $function46
      (struct.get $type137 1
       (global.get $global128)
      )
      (local.get $1)
     )
    )
   )
  )
  (unreachable)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global121
   (struct.new_default $type25)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $global155
   (struct.new_default $type30)
  )
  (global.set $ready155
   (i32.const 1)
  )
  (global.set $global188
   (struct.new_default $type35)
  )
  (global.set $ready188
   (i32.const 1)
  )
  (global.set $global239
   (struct.new_default $type41)
  )
  (global.set $ready239
   (i32.const 1)
  )
  (global.set $global300
   (struct.new_default $type46)
  )
  (global.set $ready300
   (i32.const 1)
  )
  (global.set $global351
   (struct.new_default $type52)
  )
  (global.set $ready351
   (i32.const 1)
  )
  (global.set $global423
   (struct.new_default $type57)
  )
  (global.set $ready423
   (i32.const 1)
  )
  (global.set $global469
   (struct.new_default $type63)
  )
  (global.set $ready469
   (i32.const 1)
  )
  (global.set $global517
   (struct.new_default $type69)
  )
  (global.set $ready517
   (i32.const 1)
  )
  (global.set $global612
   (struct.new_default $type75)
  )
  (global.set $ready612
   (i32.const 1)
  )
  (global.set $global648
   (struct.new_default $type80)
  )
  (global.set $ready648
   (i32.const 1)
  )
  (global.set $global722
   (struct.new_default $type86)
  )
  (global.set $ready722
   (i32.const 1)
  )
  (global.set $global770
   (struct.new_default $type92)
  )
  (global.set $ready770
   (i32.const 1)
  )
  (global.set $global112
   (struct.new $type98
    (ref.func $function42)
    (ref.null none)
   )
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $global147
   (struct.new_default $type99)
  )
  (global.set $ready147
   (i32.const 1)
  )
  (global.set $global161
   (struct.new $type100
    (ref.func $function56)
    (ref.null none)
   )
  )
  (global.set $ready161
   (i32.const 1)
  )
  (global.set $global171
   (struct.new $type101
    (ref.func $function59)
    (ref.null none)
   )
  )
  (global.set $ready171
   (i32.const 1)
  )
  (global.set $global269
   (struct.new_default $type102)
  )
  (global.set $ready269
   (i32.const 1)
  )
  (global.set $global280
   (struct.new_default $type103)
  )
  (global.set $ready280
   (i32.const 1)
  )
  (global.set $global442
   (struct.new_default $type104)
  )
  (global.set $ready442
   (i32.const 1)
  )
  (global.set $global488
   (struct.new_default $type105)
  )
  (global.set $ready488
   (i32.const 1)
  )
  (global.set $global536
   (struct.new_default $type106)
  )
  (global.set $ready536
   (i32.const 1)
  )
  (global.set $global588
   (struct.new_default $type107)
  )
  (global.set $ready588
   (i32.const 1)
  )
  (global.set $global667
   (struct.new_default $type108)
  )
  (global.set $ready667
   (i32.const 1)
  )
  (global.set $global741
   (struct.new_default $type109)
  )
  (global.set $ready741
   (i32.const 1)
  )
  (global.set $global789
   (struct.new_default $type110)
  )
  (global.set $ready789
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type111)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global153
   (struct.new_default $type112)
  )
  (global.set $ready153
   (i32.const 1)
  )
  (global.set $global166
   (struct.new_default $type113)
  )
  (global.set $ready166
   (i32.const 1)
  )
  (global.set $global176
   (struct.new_default $type114)
  )
  (global.set $ready176
   (i32.const 1)
  )
  (global.set $global275
   (struct.new_default $type115)
  )
  (global.set $ready275
   (i32.const 1)
  )
  (global.set $global285
   (struct.new_default $type116)
  )
  (global.set $ready285
   (i32.const 1)
  )
  (global.set $global448
   (struct.new_default $type117)
  )
  (global.set $ready448
   (i32.const 1)
  )
  (global.set $global494
   (struct.new_default $type118)
  )
  (global.set $ready494
   (i32.const 1)
  )
  (global.set $global551
   (struct.new_default $type119)
  )
  (global.set $ready551
   (i32.const 1)
  )
  (global.set $global593
   (struct.new_default $type120)
  )
  (global.set $ready593
   (i32.const 1)
  )
  (global.set $global682
   (struct.new_default $type121)
  )
  (global.set $ready682
   (i32.const 1)
  )
  (global.set $global747
   (struct.new_default $type122)
  )
  (global.set $ready747
   (i32.const 1)
  )
  (global.set $global795
   (struct.new_default $type123)
  )
  (global.set $ready795
   (i32.const 1)
  )
  (global.set $global213
   (struct.new_default $type124)
  )
  (global.set $ready213
   (i32.const 1)
  )
  (global.set $global325
   (struct.new_default $type125)
  )
  (global.set $ready325
   (i32.const 1)
  )
  (global.set $global547
   (struct.new_default $type126)
  )
  (global.set $ready547
   (i32.const 1)
  )
  (global.set $global678
   (struct.new_default $type127)
  )
  (global.set $ready678
   (i32.const 1)
  )
  (global.set $global144
   (struct.new_default $type128)
  )
  (global.set $ready144
   (i32.const 1)
  )
  (global.set $global235
   (struct.new_default $type130)
  )
  (global.set $ready235
   (i32.const 1)
  )
  (global.set $global266
   (struct.new_default $type132)
  )
  (global.set $ready266
   (i32.const 1)
  )
  (global.set $global347
   (struct.new_default $type134)
  )
  (global.set $ready347
   (i32.const 1)
  )
  (global.set $global387
   (struct.new_default $type136)
  )
  (global.set $ready387
   (i32.const 1)
  )
  (global.set $global405
   (struct.new_default $type138)
  )
  (global.set $ready405
   (i32.const 1)
  )
  (global.set $global571
   (struct.new_default $type140)
  )
  (global.set $ready571
   (i32.const 1)
  )
  (global.set $global581
   (struct.new_default $type142)
  )
  (global.set $ready581
   (i32.const 1)
  )
  (global.set $global608
   (struct.new_default $type144)
  )
  (global.set $ready608
   (i32.const 1)
  )
  (global.set $global702
   (struct.new_default $type146)
  )
  (global.set $ready702
   (i32.const 1)
  )
  (global.set $global168
   (struct.new_default $type148)
  )
  (global.set $ready168
   (i32.const 1)
  )
  (global.set $global287
   (struct.new_default $type149)
  )
  (global.set $ready287
   (i32.const 1)
  )
  (global.set $global595
   (struct.new_default $type150)
  )
  (global.set $ready595
   (i32.const 1)
  )
  (global.set $global159
   (struct.new $type151
    (ref.func $function55)
   )
  )
  (global.set $ready159
   (i32.const 1)
  )
  (global.set $global278
   (struct.new $type152
    (ref.func $function91)
   )
  )
  (global.set $ready278
   (i32.const 1)
  )
  (global.set $global586
   (struct.new $type153
    (ref.func $function186)
   )
  )
  (global.set $ready586
   (i32.const 1)
  )
  (global.set $global109
   (struct.new_default $type154)
  )
  (global.set $ready109
   (i32.const 1)
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (global.set $global120
   (struct.new $type28
    (i64.const 0)
    (struct.new $type29
     (struct.new $type28
      (i64.const 1)
      (struct.new $type29
       (struct.new_default $type27)
      )
     )
    )
   )
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global124
   (struct.new $type28
    (i64.const 0)
    (struct.new $type29
     (struct.new $type28
      (i64.const 1)
      (struct.new $type29
       (struct.new_default $type27)
      )
     )
    )
   )
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global125
   (struct.new $type28
    (i64.const 2)
    (struct.new $type29
     (struct.new $type28
      (i64.const 1)
      (struct.new $type29
       (struct.new_default $type27)
      )
     )
    )
   )
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global805
   (struct.new $type155
    (ref.func $function252)
   )
  )
  (global.set $ready805
   (i32.const 1)
  )
  (global.set $global242
   (struct.new_default $type156)
  )
  (global.set $ready242
   (i32.const 1)
  )
  (global.set $global354
   (struct.new_default $type158)
  )
  (global.set $ready354
   (i32.const 1)
  )
  (global.set $global615
   (struct.new_default $type160)
  )
  (global.set $ready615
   (i32.const 1)
  )
  (global.set $global228
   (struct.new_default $type162)
  )
  (global.set $ready228
   (i32.const 1)
  )
  (global.set $global340
   (struct.new_default $type164)
  )
  (global.set $ready340
   (i32.const 1)
  )
  (global.set $global564
   (struct.new_default $type165)
  )
  (global.set $ready564
   (i32.const 1)
  )
  (global.set $global695
   (struct.new_default $type166)
  )
  (global.set $ready695
   (i32.const 1)
  )
  (global.set $global207
   (struct.new_default $type111)
  )
  (global.set $ready207
   (i32.const 1)
  )
  (global.set $global319
   (struct.new_default $type114)
  )
  (global.set $ready319
   (i32.const 1)
  )
  (global.set $global541
   (struct.new_default $type113)
  )
  (global.set $ready541
   (i32.const 1)
  )
  (global.set $global672
   (struct.new_default $type116)
  )
  (global.set $ready672
   (i32.const 1)
  )
  (global.set $global200
   (struct.new_default $type167)
  )
  (global.set $ready200
   (i32.const 1)
  )
  (global.set $global312
   (struct.new_default $type169)
  )
  (global.set $ready312
   (i32.const 1)
  )
  (global.set $global435
   (struct.new_default $type171)
  )
  (global.set $ready435
   (i32.const 1)
  )
  (global.set $global481
   (struct.new_default $type174)
  )
  (global.set $ready481
   (i32.const 1)
  )
  (global.set $global529
   (struct.new_default $type177)
  )
  (global.set $ready529
   (i32.const 1)
  )
  (global.set $global660
   (struct.new_default $type179)
  )
  (global.set $ready660
   (i32.const 1)
  )
  (global.set $global734
   (struct.new_default $type182)
  )
  (global.set $ready734
   (i32.const 1)
  )
  (global.set $global782
   (struct.new_default $type185)
  )
  (global.set $ready782
   (i32.const 1)
  )
  (global.set $global221
   (struct.new_default $type188)
  )
  (global.set $ready221
   (i32.const 1)
  )
  (global.set $global333
   (struct.new_default $type189)
  )
  (global.set $ready333
   (i32.const 1)
  )
  (global.set $global557
   (struct.new_default $type190)
  )
  (global.set $ready557
   (i32.const 1)
  )
  (global.set $global688
   (struct.new_default $type191)
  )
  (global.set $ready688
   (i32.const 1)
  )
  (global.set $global191
   (struct.new_default $type192)
  )
  (global.set $ready191
   (i32.const 1)
  )
  (global.set $global303
   (struct.new_default $type194)
  )
  (global.set $ready303
   (i32.const 1)
  )
  (global.set $global426
   (struct.new_default $type196)
  )
  (global.set $ready426
   (i32.const 1)
  )
  (global.set $global472
   (struct.new_default $type197)
  )
  (global.set $ready472
   (i32.const 1)
  )
  (global.set $global520
   (struct.new_default $type198)
  )
  (global.set $ready520
   (i32.const 1)
  )
  (global.set $global651
   (struct.new_default $type200)
  )
  (global.set $ready651
   (i32.const 1)
  )
  (global.set $global725
   (struct.new_default $type202)
  )
  (global.set $ready725
   (i32.const 1)
  )
  (global.set $global773
   (struct.new_default $type203)
  )
  (global.set $ready773
   (i32.const 1)
  )
  (global.set $global178
   (struct.new_default $type204)
  )
  (global.set $ready178
   (i32.const 1)
  )
  (global.set $global290
   (struct.new_default $type206)
  )
  (global.set $ready290
   (i32.const 1)
  )
  (global.set $global377
   (struct.new_default $type208)
  )
  (global.set $ready377
   (i32.const 1)
  )
  (global.set $global395
   (struct.new_default $type210)
  )
  (global.set $ready395
   (i32.const 1)
  )
  (global.set $global413
   (struct.new_default $type212)
  )
  (global.set $ready413
   (i32.const 1)
  )
  (global.set $global459
   (struct.new_default $type214)
  )
  (global.set $ready459
   (i32.const 1)
  )
  (global.set $global507
   (struct.new_default $type216)
  )
  (global.set $ready507
   (i32.const 1)
  )
  (global.set $global598
   (struct.new_default $type218)
  )
  (global.set $ready598
   (i32.const 1)
  )
  (global.set $global638
   (struct.new_default $type220)
  )
  (global.set $ready638
   (i32.const 1)
  )
  (global.set $global712
   (struct.new_default $type222)
  )
  (global.set $ready712
   (i32.const 1)
  )
  (global.set $global760
   (struct.new_default $type224)
  )
  (global.set $ready760
   (i32.const 1)
  )
  (global.set $global140
   (struct.new_default $type226)
  )
  (global.set $ready140
   (i32.const 1)
  )
  (global.set $global262
   (struct.new_default $type227)
  )
  (global.set $ready262
   (i32.const 1)
  )
  (global.set $global577
   (struct.new_default $type228)
  )
  (global.set $ready577
   (i32.const 1)
  )
  (global.set $global373
   (struct.new_default $type229)
  )
  (global.set $ready373
   (i32.const 1)
  )
  (global.set $global391
   (struct.new_default $type230)
  )
  (global.set $ready391
   (i32.const 1)
  )
  (global.set $global409
   (struct.new_default $type231)
  )
  (global.set $ready409
   (i32.const 1)
  )
  (global.set $global455
   (struct.new_default $type232)
  )
  (global.set $ready455
   (i32.const 1)
  )
  (global.set $global503
   (struct.new_default $type233)
  )
  (global.set $ready503
   (i32.const 1)
  )
  (global.set $global634
   (struct.new_default $type234)
  )
  (global.set $ready634
   (i32.const 1)
  )
  (global.set $global708
   (struct.new_default $type235)
  )
  (global.set $ready708
   (i32.const 1)
  )
  (global.set $global756
   (struct.new_default $type236)
  )
  (global.set $ready756
   (i32.const 1)
  )
  (global.set $global126
   (struct.new $type139
    (ref.func $function45)
    (ref.null none)
   )
  )
  (global.set $ready126
   (i32.const 1)
  )
  (global.set $global128
   (struct.new $type137
    (ref.func $function46)
    (ref.null none)
   )
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global802
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready802
   (i32.const 1)
  )
  (global.set $global803
   (struct.new $type137
    (ref.func $function251)
    (ref.null none)
   )
  )
  (global.set $ready803
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

