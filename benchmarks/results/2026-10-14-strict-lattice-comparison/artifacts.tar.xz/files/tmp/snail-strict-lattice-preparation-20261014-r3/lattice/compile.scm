(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-lattice-preparation-20261014-r3/lattice/program.scm" "/tmp/snail-strict-lattice-preparation-20261014-r3/lattice/program.so"))
