(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-lattice-preparation-20261014-r3/lattice/probe-original-chez/program.scm" "/tmp/snail-strict-lattice-preparation-20261014-r3/lattice/probe-original-chez/program.so"))
