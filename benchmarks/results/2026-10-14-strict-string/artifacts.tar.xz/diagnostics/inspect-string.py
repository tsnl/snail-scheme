"""Observe completed native String copies separately from canonical timing."""

from collections import Counter
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

SOURCE, OUTPUT = map(Path, sys.argv[1:])
OBSERVER = Path('/tmp/snail-strict-enumeration-profile-20261013/diagnostic-archive/diagnostics')
OUTPUT.mkdir(parents=True, exist_ok=False)
for name in ('observe-wat.py', 'profile-host.mjs'):
    shutil.copy2(OBSERVER / name, OUTPUT / name)
shutil.copy2(__file__, OUTPUT / 'inspect-string.py')
shutil.copy2(SOURCE / 'strict.optimized.wat', OUTPUT / 'original.wat')
spec = importlib.util.spec_from_file_location('observe', OUTPUT / 'observe-wat.py')
observe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(observe)
F = observe.Form
copy_helpers = {}


def copied_scalars(number):
    name = '$__profile_' + str(number)
    count = F(['i64.extend_i32_u', F(['local.get', '$count'])])
    return F(['global.set', name, F(['i64.add', F(['global.get', name]), count])])


class StringObservers(observe.Observers):
    def copy_completed(self, original, rewritten):
        calls = self.record(original, 'string copy completed', original[1])
        scalars = self.record(original, 'string scalars copied', original[1])
        name = '$__copy_' + str(calls)
        parameters = [('$destination', F(['ref', 'null', original[1]])), ('$at', 'i32'),
                      ('$source', F(['ref', 'null', original[2]])), ('$start', 'i32'), ('$count', 'i32')]
        operation = F(['array.copy', *original[1:3], *[F(['local.get', p]) for p, _ in parameters]])
        helper = F(['func', name, *[F(['param', p, t]) for p, t in parameters],
                    operation, observe.bump(calls), copied_scalars(scalars)])
        self.helpers.append(helper)
        copy_helpers[name] = original[1:3]
        return F(['call', name, *rewritten[3:]], line=original.line)

    def rewrite(self, node):
        if not isinstance(node, F):
            return node
        original = F(node, line=node.line)
        rewritten = F([self.rewrite(child) for child in node], line=node.line)
        if node[0].startswith('array.new'):
            number = self.record(original, 'array constructor completed', original[1])
            return self.passthrough(rewritten, F(['ref', F(['exact', node[1]])]), number)
        if node[0] == 'array.copy':
            return self.copy_completed(original, rewritten)
        if node[0] == 'struct.set':
            number = self.record(original, 'reference store completed', ':'.join(original[1:3]))
            return F(['block', rewritten, observe.bump(number)], line=node.line)
        return rewritten


base_erase = observe.erase_observers


def erase(node):
    if isinstance(node, F) and node[0] == 'call' and node[1] in copy_helpers:
        return F(['array.copy', *copy_helpers[node[1]], *map(erase, node[2:])], line=node.line)
    if (isinstance(node, F) and len(node) == 3 and node[0] == 'block'
            and isinstance(node[1], F) and node[1][0] == 'struct.set'
            and isinstance(node[2], F) and node[2][0] == 'global.set'
            and node[2][1].startswith('$__profile_')):
        return erase(node[1])
    return base_erase(node)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def invoke(command, path):
    environment = os.environ.copy()
    environment.pop('NODE_OPTIONS', None)
    run = subprocess.run(list(map(str, command)), capture_output=True, text=True, env=environment, timeout=240)
    record = dict(command=list(map(str, command)), returncode=run.returncode, stdout=run.stdout,
                  stderr=run.stderr, diagnostic_only=True, performance_sample=False)
    save(path, record)
    assert run.returncode == 0, record
    return record


observe.Observers = StringObservers
observe.erase_observers = erase
observe.observe(OUTPUT / 'original.wat', OUTPUT / 'counted.wat')
invoke([shutil.which('wasm-as'), OUTPUT / 'counted.wat', '--enable-gc', '--enable-reference-types',
        '--enable-tail-call', '-o', OUTPUT / 'counted.wasm'], OUTPUT / 'assemble.json')
sites = json.loads((OUTPUT / 'counted.json').read_text())['counters']
specification = json.loads((SOURCE / 'spec.json').read_text())
length, copies, scalars, grows = 6, 0, 0, 0
while length <= 500000:
    scalars += 6 * length + 29
    length = 2 * length + 10
    copies += 9
    grows += 1
assert (length, grows, copies, scalars) == (524278, 15, 135, 3145167)
summaries = []
for count in (1, 2, 100):
    target = OUTPUT / str(count)
    target.mkdir()
    save(target / 'spec.json', dict(specification, count=count))
    invoke([os.environ['NODE'], OUTPUT / 'profile-host.mjs', OUTPUT / 'counted.wasm', target / 'spec.json',
            '--validate', target, 'counters'], target / 'run.json')
    setup = json.loads((target / 'setup.counters.json').read_text())
    bench = json.loads((target / 'bench.counters.json').read_text())
    totals, by_site = Counter(), []
    for site in sites:
        key = 'counter' + str(site['id'])
        completed = int(bench[key]) - int(setup[key])
        totals[site['category']] += completed
        by_site.append(dict(site, completed=completed))
    assert totals['array constructor completed'] == count * 10 * grows * 4, totals
    assert totals['string copy completed'] == count * 10 * copies, totals
    assert totals['string scalars copied'] == count * 10 * scalars, totals
    assert totals['reference store completed'] == count * 10 * (2 * grows + 1), totals
    summaries.append(dict(count=count, totals=totals, sites=by_site, setup_subtracted=True,
                          physical_allocator_events=False))
save(OUTPUT / 'counts-summary.json', summaries)
print('String retained-work diagnostics passed; no timing samples.', flush=True)
