(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-string-preparation-20261013-r2/string/chez-alias-original/program.scm" "/tmp/snail-strict-string-preparation-20261013-r2/string/chez-alias-original/program.so"))
