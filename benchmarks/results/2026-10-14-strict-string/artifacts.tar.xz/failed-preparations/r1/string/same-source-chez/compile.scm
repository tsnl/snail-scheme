(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-string-preparation-20261013/string/same-source-chez/program.scm" "/tmp/snail-strict-string-preparation-20261013/string/same-source-chez/program.so"))
