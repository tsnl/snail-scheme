#!/bin/sh
set -eu
host_probe=/tmp/snail-native-host-cpu-20261016/probe
export SNAIL_PROCESS_RECORD=$host_probe/v8-mbrot-sync-process.json
/tmp/sfir-native-parity-baseline-20261016/toolchain/snail-native-supervisor --command 120000 -- /nix/store/lfaydgacdyngci7p60s8wwvgdm74fjkx-nodejs-24.19.0/bin/node --no-wasm-async-compilation --no-liftoff --no-wasm-lazy-compilation --print-wasm-code --print-wasm-code-function-index=5 /tmp/sfir-native-parity-baseline-20261016/source/benchmarks/sfir/support/scalar-host.mjs /tmp/sfir-native-parity-baseline-20261016/timing/artifacts/mbrot/program.wasm /tmp/sfir-native-parity-baseline-20261016/timing/artifacts/mbrot/spec.json > "$host_probe/v8-mbrot-sync.stdout" 2> "$host_probe/v8-mbrot-sync.stderr"
