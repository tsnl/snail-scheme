0000000000058cb0 <f.5>:
   58cb0:      	pushq	%rbp
   58cb1:      	pushq	%r15
   58cb3:      	pushq	%r14
   58cb5:      	pushq	%r13
   58cb7:      	pushq	%r12
   58cb9:      	pushq	%rbx
   58cba:      	subq	$0x98, %rsp
   58cc1:      	movq	%rsi, %rbx
   58cc4:      	movq	$0x7, 0x18(%rsp)
   58ccd:      	movq	$0x0, 0x20(%rsp)
   58cd6:      	movq	0x594b(%rip), %rcx      # 0x5e628 <native_roots.0>
   58cdd:      	movq	%rcx, 0x10(%rsp)
   58ce2:      	leaq	0x10(%rsp), %r13
   58ce7:      	movq	0x591a(%rip), %rax      # 0x5e608 <_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0>
   58cee:      	leaq	0x1(%rax), %rdx
   58cf2:      	movq	0x5917(%rip), %rsi      # 0x5e610 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0>
   58cf9:      	cmpq	%rsi, %rdx
   58cfc:      	cmovaq	%rdx, %rsi
   58d00:      	movq	%r13, 0x5921(%rip)      # 0x5e628 <native_roots.0>
   58d07:      	movq	%rdx, 0x58fa(%rip)      # 0x5e608 <_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0>
   58d0e:      	movq	%rsi, 0x58fb(%rip)      # 0x5e610 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0>
   58d15:      	movq	%rdi, 0x28(%rsp)
   58d1a:      	xorpd	%xmm0, %xmm0
   58d1e:      	movupd	%xmm0, 0x30(%rsp)
   58d24:      	movq	$0x0, 0x40(%rsp)
   58d2d:      	testq	%rbx, %rbx
   58d30:      	js	0x592b5 <f.5+0x605>
   58d36:      	movq	%rbx, %rax
   58d39:      	shrq	$0x20, %rax
   58d3d:      	movq	%rax, 0x68(%rsp)
   58d42:      	nopw	%cs:(%rax,%rax)
   58d50:      	cmpq	$0x0, 0x68(%rsp)
   58d56:      	jne	0x5938f <f.5+0x6df>
   58d5c:      	testq	%rdi, %rdi
   58d5f:      	je	0x5938f <f.5+0x6df>
   58d65:      	movl	%edi, %eax
   58d67:      	andl	$0x1, %eax
   58d6a:      	jne	0x5938f <f.5+0x6df>
   58d70:      	movq	0x58a9(%rip), %r15      # 0x5e620 <_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0>
   58d77:      	testq	%r15, %r15
   58d7a:      	je	0x5938f <f.5+0x6df>
   58d80:      	movq	(%rdi), %rax
   58d83:      	testq	%rax, %rax
   58d86:      	je	0x58df0 <f.5+0x140>
   58d88:      	cmpq	$0x16, %rax
   58d8c:      	je	0x58df0 <f.5+0x140>
   58d8e:      	movq	0x168(%r15), %rcx
   58d95:      	shrq	$0x2, %rax
   58d99:      	leaq	-0x1(%rax), %rdx
   58d9d:      	cmpq	%rcx, %rdx
   58da0:      	jae	0x5938f <f.5+0x6df>
   58da6:      	movq	0x160(%r15), %rdx
   58dad:      	movq	-0x8(%rdx,%rax,8), %rax
   58db2:      	testq	%rax, %rax
   58db5:      	je	0x58df0 <f.5+0x140>
   58db7:      	cmpq	$0x16, %rax
   58dbb:      	je	0x58df0 <f.5+0x140>
   58dbd:      	nopl	(%rax)
   58dc0:      	shrq	$0x2, %rax
   58dc4:      	leaq	-0x1(%rax), %rsi
   58dc8:      	cmpq	%rcx, %rsi
   58dcb:      	jae	0x5938f <f.5+0x6df>
   58dd1:      	movq	-0x8(%rdx,%rax,8), %rax
   58dd6:      	cmpq	$0x16, %rax
   58dda:      	je	0x58df0 <f.5+0x140>
   58ddc:      	testq	%rax, %rax
   58ddf:      	jne	0x58dc0 <f.5+0x110>
   58de1:      	nopw	%cs:(%rax,%rax)
   58df0:      	cmpq	$0x16, %rax
   58df4:      	jne	0x5938f <f.5+0x6df>
   58dfa:      	movq	%rdi, 0x30(%rsp)
   58dff:      	movq	0x8(%rdi), %rax
   58e03:      	testq	%rax, %rax
   58e06:      	je	0x5938f <f.5+0x6df>
   58e0c:      	testb	$0x1, %al
   58e0e:      	jne	0x5938f <f.5+0x6df>
   58e14:      	cmpq	0x8(%rax), %rbx
   58e18:      	jae	0x5938f <f.5+0x6df>
   58e1e:      	cmpb	$0x0, 0x58eb(%rip)      # 0x5e710 <g.4>
   58e25:      	je	0x5938f <f.5+0x6df>
   58e2b:      	cmpq	$0x0, 0x58d5(%rip)      # 0x5e708 <g.3>
   58e33:      	je	0x5938f <f.5+0x6df>
   58e39:      	movq	0x10(%rax,%rbx,8), %rbp
   58e3e:      	movq	%rbp, 0x48(%rsp)
   58e43:      	movq	$0x5, 0x20(%rsp)
   58e4c:      	movq	0x178(%r15), %rcx
   58e53:      	movq	%r13, %rdx
   58e56:      	testq	%rcx, %rcx
   58e59:      	je	0x58e9e <f.5+0x1ee>
   58e5b:      	movq	0x170(%r15), %rax
   58e62:      	incq	%rax
   58e65:      	movq	%rax, 0x170(%r15)
   58e6c:      	movq	%rax, %rdx
   58e6f:      	orq	%rcx, %rdx
   58e72:      	shrq	$0x20, %rdx
   58e76:      	je	0x59260 <f.5+0x5b0>
   58e7c:      	xorl	%edx, %edx
   58e7e:      	divq	%rcx
   58e81:      	movq	%rdx, %rax
   58e84:      	movq	%r13, %rdx
   58e87:      	testq	%rax, %rax
   58e8a:      	jne	0x58e9e <f.5+0x1ee>
   58e8c:      	movq	%r15, %rdi
   58e8f:      	movq	%r13, %rsi
   58e92:      	callq	0x56140 <_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E>
   58e97:      	movq	0x578a(%rip), %rdx      # 0x5e628 <native_roots.0>
   58e9e:      	movl	$0x18, %esi
   58ea3:      	movq	%r15, %rdi
   58ea6:      	callq	0x55f90 <_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE>
   58eab:      	testq	%rax, %rax
   58eae:      	je	0x59394 <f.5+0x6e4>
   58eb4:      	movq	%rax, %r15
   58eb7:      	movq	$0x12, (%rax)
   58ebe:      	movl	$0x0, 0x8(%rax)
   58ec5:      	movq	$0x0, 0x10(%rax)
   58ecd:      	movq	%rax, 0x38(%rsp)
   58ed2:      	cvtsi2sd	%rbx, %xmm1
   58ed7:      	movsd	-0x53407(%rip), %xmm0   # 0x5ad8 <writev+0x5ad8>
   58edf:      	mulsd	%xmm0, %xmm1
   58ee3:      	addsd	-0x5344b(%rip), %xmm1   # 0x5aa0 <writev+0x5aa0>
   58eeb:      	movq	0x30(%rsp), %rax
   58ef0:      	testq	%rax, %rax
   58ef3:      	je	0x5938f <f.5+0x6df>
   58ef9:      	movq	0x18(%rax), %r14
   58efd:      	cvtsi2sd	%r14, %xmm2
   58f02:      	mulsd	%xmm0, %xmm2
   58f06:      	addsd	-0x53456(%rip), %xmm2   # 0x5ab8 <writev+0x5ab8>
   58f0e:      	movapd	%xmm2, 0x70(%rsp)
   58f14:      	movq	%r15, 0x48(%rsp)
   58f19:      	movq	%r15, 0x50(%rsp)
   58f1e:      	movq	%rbp, 0x58(%rsp)
   58f23:      	movq	$0x7, 0x20(%rsp)
   58f2c:      	movq	0x56ed(%rip), %rdi      # 0x5e620 <_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0>
   58f33:      	testq	%rdi, %rdi
   58f36:      	je	0x5938f <f.5+0x6df>
   58f3c:      	movapd	%xmm1, 0x80(%rsp)
   58f45:      	movq	0x178(%rdi), %rcx
   58f4c:      	testq	%rcx, %rcx
   58f4f:      	je	0x58f8e <f.5+0x2de>
   58f51:      	movq	0x170(%rdi), %rax
   58f58:      	incq	%rax
   58f5b:      	movq	%rax, 0x170(%rdi)
   58f62:      	movq	%rax, %rdx
   58f65:      	orq	%rcx, %rdx
   58f68:      	shrq	$0x20, %rdx
   58f6c:      	je	0x59280 <f.5+0x5d0>
   58f72:      	xorl	%edx, %edx
   58f74:      	divq	%rcx
   58f77:      	testq	%rdx, %rdx
   58f7a:      	jne	0x58f8e <f.5+0x2de>
   58f7c:      	movq	0x56a5(%rip), %rsi      # 0x5e628 <native_roots.0>
   58f83:      	movq	%rdi, %r12
   58f86:      	callq	0x56140 <_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E>
   58f8b:      	movq	%r12, %rdi
   58f8e:      	movq	0x5693(%rip), %rdx      # 0x5e628 <native_roots.0>
   58f95:      	movl	$0x20, %esi
   58f9a:      	callq	0x55f90 <_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE>
   58f9f:      	testq	%rax, %rax
   58fa2:      	je	0x59394 <f.5+0x6e4>
   58fa8:      	movq	%rax, %r12
   58fab:      	movq	$0xe, (%rax)
   58fb2:      	movaps	0x80(%rsp), %xmm0
   58fba:      	movsd	%xmm0, 0x8(%rax)
   58fbf:      	movaps	0x70(%rsp), %xmm0
   58fc4:      	movsd	%xmm0, 0x10(%rax)
   58fc9:      	movq	%r15, 0x18(%rax)
   58fcd:      	movq	%rax, 0x48(%rsp)
   58fd2:      	movq	%r15, 0x50(%rsp)
   58fd7:      	movq	%rbp, 0x58(%rsp)
   58fdc:      	movq	$0x7, 0x20(%rsp)
   58fe5:      	movq	0x5634(%rip), %rdi      # 0x5e620 <_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0>
   58fec:      	testq	%rdi, %rdi
   58fef:      	je	0x5938f <f.5+0x6df>
   58ff5:      	movq	0x178(%rdi), %rcx
   58ffc:      	testq	%rcx, %rcx
   58fff:      	je	0x5904e <f.5+0x39e>
   59001:      	movq	0x170(%rdi), %rax
   59008:      	incq	%rax
   5900b:      	movq	%rax, 0x170(%rdi)
   59012:      	movq	%rax, %rdx
   59015:      	orq	%rcx, %rdx
   59018:      	shrq	$0x20, %rdx
   5901c:      	je	0x592a0 <f.5+0x5f0>
   59022:      	xorl	%edx, %edx
   59024:      	divq	%rcx
   59027:      	testq	%rdx, %rdx
   5902a:      	jne	0x5904e <f.5+0x39e>
   5902c:      	movq	0x55f5(%rip), %rsi      # 0x5e628 <native_roots.0>
   59033:      	movq	%rbx, 0x60(%rsp)
   59038:      	movq	%r13, %rbx
   5903b:      	movq	%rdi, %r13
   5903e:      	callq	0x56140 <_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E>
   59043:      	movq	%r13, %rdi
   59046:      	movq	%rbx, %r13
   59049:      	movq	0x60(%rsp), %rbx
   5904e:      	movq	0x55d3(%rip), %rdx      # 0x5e628 <native_roots.0>
   59055:      	movl	$0x10, %esi
   5905a:      	callq	0x55f90 <_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE>
   5905f:      	testq	%rax, %rax
   59062:      	je	0x59394 <f.5+0x6e4>
   59068:      	movq	$0xa, (%rax)
   5906f:      	movq	%r12, 0x8(%rax)
   59073:      	movq	%rax, 0x10(%r15)
   59077:      	movq	0x38(%rsp), %rax
   5907c:      	testq	%rax, %rax
   5907f:      	movsd	-0x535d7(%rip), %xmm3   # 0x5ab0 <writev+0x5ab0>
   59087:      	je	0x5938f <f.5+0x6df>
   5908d:      	movl	$0x1, 0x8(%rax)
   59094:      	movq	0x38(%rsp), %rax
   59099:      	testq	%rax, %rax
   5909c:      	movapd	0x80(%rsp), %xmm4
   590a5:      	je	0x5938f <f.5+0x6df>
   590ab:      	cmpl	$0x0, 0x8(%rax)
   590af:      	je	0x5938f <f.5+0x6df>
   590b5:      	movq	0x10(%rax), %rax
   590b9:      	testq	%rax, %rax
   590bc:      	je	0x5938f <f.5+0x6df>
   590c2:      	movq	0x8(%rax), %rcx
   590c6:      	movq	%rbp, 0x48(%rsp)
   590cb:      	movq	%rcx, 0x50(%rsp)
   590d0:      	movq	$0x6, 0x20(%rsp)
   590d9:      	unpcklpd	0x70(%rsp), %xmm4       # xmm4 = xmm4[0],mem[0]
   590df:      	xorl	%eax, %eax
   590e1:      	nopw	%cs:(%rax,%rax)
   590f0:      	movapd	%xmm4, %xmm0
   590f4:      	mulpd	%xmm4, %xmm0
   590f8:      	movapd	%xmm0, %xmm1
   590fc:      	unpckhpd	%xmm0, %xmm1            # xmm1 = xmm1[1],xmm0[1]
   59100:      	movapd	%xmm1, %xmm2
   59104:      	addsd	%xmm0, %xmm2
   59108:      	ucomisd	%xmm3, %xmm2
   5910c:      	ja	0x5916e <f.5+0x4be>
   5910e:      	testq	%rcx, %rcx
   59111:      	je	0x5938f <f.5+0x6df>
   59117:      	movq	0x18(%rcx), %rdx
   5911b:      	testq	%rdx, %rdx
   5911e:      	je	0x5938f <f.5+0x6df>
   59124:      	cmpl	$0x0, 0x8(%rdx)
   59128:      	je	0x5938f <f.5+0x6df>
   5912e:      	movq	0x10(%rdx), %rdx
   59132:      	testq	%rdx, %rdx
   59135:      	je	0x5938f <f.5+0x6df>
   5913b:      	movapd	%xmm4, %xmm2
   5913f:      	unpckhpd	%xmm4, %xmm2            # xmm2 = xmm2[1],xmm4[1]
   59143:      	mulsd	%xmm4, %xmm2
   59147:      	movupd	0x8(%rcx), %xmm4
   5914c:      	movq	0x8(%rdx), %rcx
   59150:      	addsd	%xmm2, %xmm2
   59154:      	subsd	%xmm1, %xmm0
   59158:      	unpcklpd	%xmm2, %xmm0            # xmm0 = xmm0[0],xmm2[0]
   5915c:      	addpd	%xmm0, %xmm4
   59160:      	incq	%rax
   59163:      	cmpq	$0x40, %rax
   59167:      	jne	0x590f0 <f.5+0x440>
   59169:      	movl	$0x40, %eax
   5916e:      	movq	%r14, %rcx
   59171:      	shrq	$0x20, %rcx
   59175:      	jne	0x5938f <f.5+0x6df>
   5917b:      	testq	%rbp, %rbp
   5917e:      	je	0x5938f <f.5+0x6df>
   59184:      	testb	$0x1, %bpl
   59188:      	jne	0x5938f <f.5+0x6df>
   5918e:      	cmpq	0x8(%rbp), %r14
   59192:      	jae	0x5938f <f.5+0x6df>
   59198:      	movq	%rax, 0x10(%rbp,%r14,8)
   5919d:      	movq	0x30(%rsp), %rax
   591a2:      	testq	%rax, %rax
   591a5:      	je	0x5938f <f.5+0x6df>
   591ab:      	movq	0x20(%rax), %rax
   591af:      	testq	%rax, %rax
   591b2:      	je	0x5938f <f.5+0x6df>
   591b8:      	cmpl	$0x0, 0x8(%rax)
   591bc:      	je	0x5938f <f.5+0x6df>
   591c2:      	movq	0x10(%rax), %rcx
   591c6:      	testq	%rcx, %rcx
   591c9:      	je	0x5938f <f.5+0x6df>
   591cf:      	xorl	%eax, %eax
   591d1:      	cmpq	$0x0, 0x18(%rsp)
   591d7:      	movq	%r13, %rdx
   591da:      	leaq	0x5447(%rip), %rsi      # 0x5e628 <native_roots.0>
   591e1:      	cmoveq	%rsi, %rdx
   591e5:      	sete	%al
   591e8:      	addq	0x5419(%rip), %rax      # 0x5e608 <_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0>
   591ef:      	movq	0x541a(%rip), %rsi      # 0x5e610 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0>
   591f6:      	cmpq	%rsi, %rax
   591f9:      	cmovaq	%rax, %rsi
   591fd:      	movq	0x10(%rcx), %rdi
   59201:      	movq	(%rdx), %rcx
   59204:      	movq	$0x7, 0x18(%rsp)
   5920d:      	movq	$0x0, 0x20(%rsp)
   59216:      	movq	%rcx, 0x10(%rsp)
   5921b:      	movq	%r13, 0x5406(%rip)      # 0x5e628 <native_roots.0>
   59222:      	movq	%rax, 0x53df(%rip)      # 0x5e608 <_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0>
   59229:      	movq	%rsi, 0x53e0(%rip)      # 0x5e610 <_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0>
   59230:      	movq	%rdi, 0x28(%rsp)
   59235:      	xorpd	%xmm0, %xmm0
   59239:      	leaq	0x30(%rsp), %rdx
   5923e:      	movupd	%xmm0, (%rdx)
   59242:      	movq	$0x0, 0x10(%rdx)
   5924a:      	subq	$0x1, %rbx
   5924e:      	jae	0x58d50 <f.5+0xa0>
   59254:      	jmp	0x592b2 <f.5+0x602>
   59256:      	nopw	%cs:(%rax,%rax)
   59260:      	xorl	%edx, %edx
   59262:      	divl	%ecx
   59264:      	movl	%edx, %eax
   59266:      	movq	%r13, %rdx
   59269:      	testq	%rax, %rax
   5926c:      	jne	0x58e9e <f.5+0x1ee>
   59272:      	jmp	0x58e8c <f.5+0x1dc>
   59277:      	nopw	(%rax,%rax)
   59280:      	xorl	%edx, %edx
   59282:      	divl	%ecx
   59284:      	testq	%rdx, %rdx
   59287:      	jne	0x58f8e <f.5+0x2de>
   5928d:      	jmp	0x58f7c <f.5+0x2cc>
   59292:      	nopw	%cs:(%rax,%rax)
   592a0:      	xorl	%edx, %edx
   592a2:      	divl	%ecx
   592a4:      	testq	%rdx, %rdx
   592a7:      	jne	0x5904e <f.5+0x39e>
   592ad:      	jmp	0x5902c <f.5+0x37c>
   592b2:      	decq	%rax
   592b5:      	testq	%rdi, %rdi
   592b8:      	je	0x5938f <f.5+0x6df>
   592be:      	movl	%edi, %edx
   592c0:      	andl	$0x1, %edx
   592c3:      	jne	0x5938f <f.5+0x6df>
   592c9:      	movq	0x5350(%rip), %r8       # 0x5e620 <_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0>
   592d0:      	testq	%r8, %r8
   592d3:      	je	0x5938f <f.5+0x6df>
   592d9:      	movq	(%rdi), %rdx
   592dc:      	testq	%rdx, %rdx
   592df:      	je	0x5933d <f.5+0x68d>
   592e1:      	cmpq	$0x16, %rdx
   592e5:      	je	0x5933d <f.5+0x68d>
   592e7:      	movq	0x168(%r8), %rsi
   592ee:      	shrq	$0x2, %rdx
   592f2:      	leaq	-0x1(%rdx), %r9
   592f6:      	cmpq	%rsi, %r9
   592f9:      	jae	0x5938f <f.5+0x6df>
   592ff:      	movq	0x160(%r8), %r8
   59306:      	movq	-0x8(%r8,%rdx,8), %rdx
   5930b:      	testq	%rdx, %rdx
   5930e:      	je	0x5933d <f.5+0x68d>
   59310:      	cmpq	$0x16, %rdx
   59314:      	je	0x5933d <f.5+0x68d>
   59316:      	nopw	%cs:(%rax,%rax)
   59320:      	shrq	$0x2, %rdx
   59324:      	leaq	-0x1(%rdx), %r9
   59328:      	cmpq	%rsi, %r9
   5932b:      	jae	0x5938f <f.5+0x6df>
   5932d:      	movq	-0x8(%r8,%rdx,8), %rdx
   59332:      	cmpq	$0x16, %rdx
   59336:      	je	0x5933d <f.5+0x68d>
   59338:      	testq	%rdx, %rdx
   5933b:      	jne	0x59320 <f.5+0x670>
   5933d:      	cmpq	$0x16, %rdx
   59341:      	jne	0x5938f <f.5+0x6df>
   59343:      	movq	%rdi, 0x30(%rsp)
   59348:      	movq	0x10(%rdi), %rdx
   5934c:      	testq	%rdx, %rdx
   5934f:      	je	0x5938f <f.5+0x6df>
   59351:      	cmpl	$0x0, 0x8(%rdx)
   59355:      	je	0x5938f <f.5+0x6df>
   59357:      	movq	0x10(%rdx), %rdx
   5935b:      	testq	%rdx, %rdx
   5935e:      	je	0x5938f <f.5+0x6df>
   59360:      	movq	0x18(%rdi), %rsi
   59364:      	movq	0x10(%rdx), %rdi
   59368:      	movq	%rcx, 0x52b9(%rip)      # 0x5e628 <native_roots.0>
   5936f:      	movq	%rax, 0x5292(%rip)      # 0x5e608 <_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0>
   59376:      	decq	%rsi
   59379:      	addq	$0x98, %rsp
   59380:      	popq	%rbx
   59381:      	popq	%r12
   59383:      	popq	%r13
   59385:      	popq	%r14
   59387:      	popq	%r15
   59389:      	popq	%rbp
   5938a:      	jmp	0x58890 <f.4>
   5938f:      	callq	0x54a40 <native_trap>
   59394:      	leaq	-0x504df(%rip), %rdi    # 0x8ebc <_RNvNtNtNtNtCsgEmfK2I1SDS_4core3num7flt2dec8strategy6dragon9POW5TO256+0x828>
   5939b:      	movl	$0x2f, %esi
   593a0:      	callq	0x55a40 <_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE>
   593a5:      	int3
   593a6:      	int3
   593a7:      	int3
   593a8:      	int3
   593a9:      	int3
   593aa:      	int3
   593ab:      	int3
   593ac:      	int3
   593ad:      	int3
   593ae:      	int3
   593af:      	int3
