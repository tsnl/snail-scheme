#!/bin/sh
set -eu
host_root=/tmp/snail-native-host-cpu-20261016
. "$host_root/probe/build-env.sh"
for host_arm in generic host; do
    host_output=$host_root/probe/mbrot/$host_arm
    export SNAIL_PROCESS_RECORD="$host_output/stat-process.json"
    "$ENV" -u SNAIL_NATIVE_GC_INTERVAL -u SNAIL_GC_STATS -u SNAIL_GC_HEAP_BYTES -u SNAIL_GC_INITIAL_BYTES -u SNAIL_GC_MIN_BYTES /nix/store/apffmxq24i2xf89m4llsz4yc2sc1bv94-perf-linux-7.2.3/bin/perf stat -x, --no-big-num -e cycles:u,instructions:u,branches:u,branch-misses:u,cache-misses:u -o "$host_output/stat.csv" -- "$TASKSET" -c 2 "$SNAIL_NATIVE_SUPERVISOR" --command 120000 -- "$host_output/program" > "$host_output/stat.stdout" 2> "$host_output/stat.stderr"
    printf 'Diagnostic predicate passed: %s\n' "$host_arm"
done
