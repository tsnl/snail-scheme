define internal tailcc noundef i32 @f.7(i64 %arg0, i64 %arg1) #106 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [4 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 4, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v927 = icmp sgt i64 %arg1, -1
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  br i1 %v927, label %then14.lr.ph.split, label %else13

then14.lr.ph.split:                               ; preds = %entry
  %v54 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v43.first_iter = icmp samesign ugt i64 %arg1, 4294967295
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %then14.preheader

9:                                                ; preds = %then14.lr.ph.split
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 38, label %.loopexit10
    i64 0, label %.loopexit10
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit9

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader8 [
    i64 38, label %.loopexit10
    i64 0, label %.loopexit10
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #114
  unreachable

.loopexit10:                                      ; preds = %32, %32, %21, %21, %14, %14
  %.in30 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %34, %32 ], [ %34, %32 ]
  %27 = icmp eq i64 %.in30, 38
  br label %then14.preheader

then14.preheader:                                 ; preds = %.loopexit10, %then14.lr.ph.split
  %phi.call.shrunk.ph = phi i1 [ false, %then14.lr.ph.split ], [ %27, %.loopexit10 ]
  br label %then14

.preheader8:                                      ; preds = %32, %21
  %28 = phi i64 [ %34, %32 ], [ %25, %21 ]
  %29 = lshr i64 %28, 2
  %30 = add nsw i64 %29, -1
  %31 = icmp ult i64 %30, %17
  br i1 %31, label %32, label %.loopexit9

.loopexit9:                                       ; preds = %.preheader8, %15
  call fastcc void @native_trap() #114
  unreachable

32:                                               ; preds = %.preheader8
  %33 = getelementptr inbounds nuw i64, ptr %23, i64 %30
  %34 = load i64, ptr %33, align 8, !noundef !39
  switch i64 %34, label %.preheader8 [
    i64 38, label %.loopexit10
    i64 0, label %.loopexit10
  ]

then14:                                           ; preds = %then14.backedge, %then14.preheader
  %phi.call.shrunk = phi i1 [ %phi.call.shrunk.ph, %then14.preheader ], [ %phi.call.shrunk.be, %then14.backedge ]
  %arg1.tr29 = phi i64 [ %arg1, %then14.preheader ], [ %v113, %then14.backedge ]
  %arg0.tr28 = phi i64 [ %arg0, %then14.preheader ], [ %v111, %then14.backedge ]
  br i1 %phi.call.shrunk, label %ok20, label %trap19

trap19:                                           ; preds = %then14
  call fastcc void @native_trap()
  unreachable

ok20:                                             ; preds = %then14
  store i64 %arg0.tr28, ptr %v3, align 8
  %v21.not = icmp eq i64 %arg0.tr28, 0
  br i1 %v21.not, label %trap22, label %ok23

trap22:                                           ; preds = %ok20
  call fastcc void @native_trap()
  unreachable

ok23:                                             ; preds = %ok20
  %v24 = inttoptr i64 %arg0.tr28 to ptr
  %v25 = getelementptr i8, ptr %v24, i64 16
  %v26 = load i64, ptr %v25, align 1
  %v34 = getelementptr i8, ptr %v24, i64 8
  %v35 = load i64, ptr %v34, align 1
  %v36 = icmp ugt i64 %v35, 4294967295
  br i1 %v36, label %then40, label %block38

then40:                                           ; preds = %ok23
  call fastcc void @native_trap()
  unreachable

block38:                                          ; preds = %ok23
  br i1 %v43.first_iter, label %then47, label %block45

then47:                                           ; preds = %block38
  call fastcc void @native_trap()
  unreachable

block45:                                          ; preds = %block38
  %v53 = trunc nuw i64 %v35 to i32
  store i64 %v26, ptr %v54, align 8
  store i64 4, ptr %1, align 8
  %v56 = call fastcc i64 @native_array_new(i64 43, i32 %v53, i64 0)
  %v57.not = icmp eq i64 %v26, 0
  br i1 %v57.not, label %trap58, label %ok59

trap58:                                           ; preds = %block45
  call fastcc void @native_trap()
  unreachable

ok59:                                             ; preds = %block45
  %v60 = and i64 %v26, 1
  %v61 = icmp eq i64 %v60, 0
  br i1 %v61, label %ok63, label %trap62

trap62:                                           ; preds = %ok59
  call fastcc void @native_trap()
  unreachable

ok63:                                             ; preds = %ok59
  %v64 = inttoptr i64 %v26 to ptr
  %v65 = getelementptr i8, ptr %v64, i64 8
  %v66 = load i64, ptr %v65, align 1
  %v68 = icmp ult i64 %arg1.tr29, %v66
  br i1 %v68, label %ok70, label %trap69

trap69:                                           ; preds = %ok63
  call fastcc void @native_trap()
  unreachable

ok70:                                             ; preds = %ok63
  %v72 = getelementptr i8, ptr %v64, i64 16
  %v73 = getelementptr i64, ptr %v72, i64 %arg1.tr29
  store i64 %v56, ptr %v73, align 1
  %v74 = load i64, ptr %v3, align 8
  %v75.not = icmp eq i64 %v74, 0
  br i1 %v75.not, label %trap76, label %ok77

trap76:                                           ; preds = %ok70
  call fastcc void @native_trap()
  unreachable

ok77:                                             ; preds = %ok70
  %v78 = inttoptr i64 %v74 to ptr
  %v79 = getelementptr i8, ptr %v78, i64 24
  %v80 = load i64, ptr %v79, align 1
  %v81.not = icmp eq i64 %v80, 0
  br i1 %v81.not, label %trap82, label %ok83

trap82:                                           ; preds = %ok77
  call fastcc void @native_trap()
  unreachable

ok83:                                             ; preds = %ok77
  %v84 = inttoptr i64 %v80 to ptr
  %v85 = getelementptr i8, ptr %v84, i64 8
  %v86 = load i32, ptr %v85, align 1
  %v87 = icmp eq i32 %v86, 0
  br i1 %v87, label %then91, label %ok102

then91:                                           ; preds = %ok83
  call fastcc void @native_trap()
  unreachable

ok102:                                            ; preds = %ok83
  %v104 = getelementptr i8, ptr %v84, i64 16
  %v105 = load i64, ptr %v104, align 1
  %v106.not = icmp eq i64 %v105, 0
  br i1 %v106.not, label %trap107, label %ok108

trap107:                                          ; preds = %ok102
  call fastcc void @native_trap()
  unreachable

ok108:                                            ; preds = %ok102
  %v109 = inttoptr i64 %v105 to ptr
  %v110 = getelementptr i8, ptr %v109, i64 16
  %v111 = load i64, ptr %v110, align 1
  %35 = load i64, ptr %0, align 8, !noundef !39
  %36 = icmp eq i64 %35, 0
  %.pre12 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %37 = zext i1 %36 to i64
  %38 = add i64 %.pre12, %37
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %39 = select i1 %36, ptr %native_roots.0.val, ptr %roots.val
  store i64 4, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %39, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %38, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %40 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8, !noundef !39
  %41 = call noundef i64 @llvm.umax.i64(i64 %38, i64 %40)
  store i64 %41, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8
  store i64 %v111, ptr %v1, align 8
  %v9.not = icmp eq i64 %arg1.tr29, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  br i1 %v9.not, label %else13.loopexit, label %ok108.split

ok108.split:                                      ; preds = %ok108
  %v113 = add nsw i64 %arg1.tr29, -1
  %42 = icmp ne i64 %v111, 0
  %43 = and i64 %v111, 1
  %.not.i3 = icmp eq i64 %43, 0
  %or.cond22 = and i1 %42, %.not.i3
  br i1 %or.cond22, label %44, label %then14.backedge

then14.backedge:                                  ; preds = %.loopexit6, %ok108.split
  %phi.call.shrunk.be = phi i1 [ false, %ok108.split ], [ %62, %.loopexit6 ]
  br label %then14

44:                                               ; preds = %ok108.split
  %45 = inttoptr i64 %v111 to ptr
  %46 = load i64, ptr %45, align 8, !noundef !39
  %47 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %48 = icmp eq ptr %47, null
  br i1 %48, label %61, label %49

49:                                               ; preds = %44
  switch i64 %46, label %50 [
    i64 38, label %.loopexit6
    i64 0, label %.loopexit6
  ]

50:                                               ; preds = %49
  %51 = getelementptr inbounds nuw i8, ptr %47, i64 360
  %52 = load i64, ptr %51, align 8, !noundef !39
  %53 = lshr i64 %46, 2
  %54 = add nsw i64 %53, -1
  %55 = icmp ult i64 %54, %52
  br i1 %55, label %56, label %.loopexit

56:                                               ; preds = %50
  %57 = getelementptr inbounds nuw i8, ptr %47, i64 352
  %58 = load ptr, ptr %57, align 8, !nonnull !39, !noundef !39
  %59 = getelementptr inbounds nuw i64, ptr %58, i64 %54
  %60 = load i64, ptr %59, align 8, !noundef !39
  switch i64 %60, label %.preheader [
    i64 38, label %.loopexit6
    i64 0, label %.loopexit6
  ]

61:                                               ; preds = %44
  call fastcc void @native_trap() #114
  unreachable

.loopexit6:                                       ; preds = %67, %67, %56, %56, %49, %49
  %.in = phi i64 [ %46, %49 ], [ %60, %56 ], [ %60, %56 ], [ %46, %49 ], [ %69, %67 ], [ %69, %67 ]
  %62 = icmp eq i64 %.in, 38
  br label %then14.backedge

.preheader:                                       ; preds = %67, %56
  %63 = phi i64 [ %69, %67 ], [ %60, %56 ]
  %64 = lshr i64 %63, 2
  %65 = add nsw i64 %64, -1
  %66 = icmp ult i64 %65, %52
  br i1 %66, label %67, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %50
  call fastcc void @native_trap() #114
  unreachable

67:                                               ; preds = %.preheader
  %68 = getelementptr inbounds nuw i64, ptr %58, i64 %65
  %69 = load i64, ptr %68, align 8, !noundef !39
  switch i64 %69, label %.preheader [
    i64 38, label %.loopexit6
    i64 0, label %.loopexit6
  ]

else13.loopexit:                                  ; preds = %ok108
  %.lcssa36 = phi i64 [ %38, %ok108 ]
  %.lcssa32 = phi ptr [ %39, %ok108 ]
  %70 = add i64 %.lcssa36, -1
  br label %else13

else13:                                           ; preds = %else13.loopexit, %entry
  %71 = phi i64 [ %70, %else13.loopexit ], [ %3, %entry ]
  %72 = phi ptr [ %.lcssa32, %else13.loopexit ], [ %2, %entry ]
  store ptr %72, ptr @native_roots.0, align 8
  store i64 %71, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  ret i32 0
}
