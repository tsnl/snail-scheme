define internal tailcc i32 @f.4(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [9 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 9, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v10 = icmp sgt i64 %arg1, -1
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v3, i8 0, i64 24, i1 false)
  br i1 %v10, label %then15, label %else14

then15:                                           ; preds = %entry
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap20

9:                                                ; preds = %then15
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #114
  unreachable

.preheader:                                       ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %15
  call fastcc void @native_trap() #114
  unreachable

31:                                               ; preds = %.preheader
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in, 30
  br i1 %34, label %ok21, label %trap20

trap20:                                           ; preds = %native_ref_test.exit, %then15
  call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %native_ref_test.exit
  store i64 %arg0, ptr %v4, align 8
  %v26 = getelementptr i8, ptr %10, i64 16
  %v27 = load i64, ptr %v26, align 1
  %v28 = add i64 %v27, -1
  store i64 4, ptr %1, align 8
  %35 = getelementptr inbounds nuw i8, ptr %12, i64 376
  %36 = load i64, ptr %35, align 8, !noundef !39
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %38, label %42

38:                                               ; preds = %48, %42, %ok21
  %39 = phi ptr [ %.pre, %48 ], [ %roots, %42 ], [ %roots, %ok21 ]
  %40 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %12, i64 noundef 24, ptr noundef %39) #84
  %41 = icmp eq ptr %40, null
  br i1 %41, label %49, label %ok33

42:                                               ; preds = %ok21
  %43 = getelementptr inbounds nuw i8, ptr %12, i64 368
  %44 = load i64, ptr %43, align 8, !noundef !39
  %45 = add i64 %44, 1
  store i64 %45, ptr %43, align 8
  %46 = urem i64 %45, %36
  %47 = icmp eq i64 %46, 0
  br i1 %47, label %48, label %38

48:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %12, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %38

49:                                               ; preds = %38
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

ok33:                                             ; preds = %38
  %50 = ptrtoint ptr %40 to i64
  store i64 58, ptr %40, align 1
  %v40 = getelementptr i8, ptr %40, i64 8
  store i32 0, ptr %v40, align 1
  %v45 = getelementptr i8, ptr %40, i64 16
  store i64 0, ptr %v45, align 1
  store i64 %50, ptr %v3, align 8
  %v46 = load i64, ptr %v4, align 8
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %ok33
  call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %ok33
  %v50 = inttoptr i64 %v46 to ptr
  %v51 = getelementptr i8, ptr %v50, i64 8
  %v52 = load i64, ptr %v51, align 1
  %v58 = getelementptr i8, ptr %v50, i64 24
  %v59 = load i64, ptr %v58, align 1
  %v62 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 %50, ptr %v62, align 8
  %v63 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %v59, ptr %v63, align 8
  %v64 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  store i64 %v52, ptr %v64, align 8
  %v65 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  store i64 ptrtoint (ptr @ref.5 to i64), ptr %v65, align 8
  %v66 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  store i64 %50, ptr %v66, align 8
  store i64 9, ptr %1, align 8
  %51 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %52 = icmp eq ptr %51, null
  br i1 %52, label %53, label %54

53:                                               ; preds = %ok49
  call fastcc void @native_trap() #114
  unreachable

54:                                               ; preds = %ok49
  %55 = getelementptr inbounds nuw i8, ptr %51, i64 376
  %56 = load i64, ptr %55, align 8, !noundef !39
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %58, label %62

58:                                               ; preds = %68, %62, %54
  %59 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %60 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %51, i64 noundef 40, ptr noundef %59) #84
  %61 = icmp eq ptr %60, null
  br i1 %61, label %70, label %ok71

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw i8, ptr %51, i64 368
  %64 = load i64, ptr %63, align 8, !noundef !39
  %65 = add i64 %64, 1
  store i64 %65, ptr %63, align 8
  %66 = urem i64 %65, %56
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %68, label %58

68:                                               ; preds = %62
  %69 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %51, ptr noundef %69) #84
  br label %58

70:                                               ; preds = %58
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

ok71:                                             ; preds = %58
  %71 = ptrtoint ptr %60 to i64
  store i64 22, ptr %60, align 1
  %v78 = getelementptr i8, ptr %60, i64 8
  store i64 %v52, ptr %v78, align 1
  %v83 = getelementptr i8, ptr %60, i64 16
  store i64 %v59, ptr %v83, align 1
  %v88 = getelementptr i8, ptr %60, i64 24
  store i64 %arg1, ptr %v88, align 1
  %v93 = getelementptr i8, ptr %60, i64 32
  store i64 %50, ptr %v93, align 1
  store i64 %71, ptr %v62, align 8
  store i64 ptrtoint (ptr @ref.5 to i64), ptr %v63, align 8
  store i64 %50, ptr %v64, align 8
  store i64 7, ptr %1, align 8
  %72 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %73 = icmp eq ptr %72, null
  br i1 %73, label %74, label %75

74:                                               ; preds = %ok71
  call fastcc void @native_trap() #114
  unreachable

75:                                               ; preds = %ok71
  %76 = getelementptr inbounds nuw i8, ptr %72, i64 376
  %77 = load i64, ptr %76, align 8, !noundef !39
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %79, label %83

79:                                               ; preds = %89, %83, %75
  %80 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %81 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %72, i64 noundef 24, ptr noundef %80) #84
  %82 = icmp eq ptr %81, null
  br i1 %82, label %91, label %ok101

83:                                               ; preds = %75
  %84 = getelementptr inbounds nuw i8, ptr %72, i64 368
  %85 = load i64, ptr %84, align 8, !noundef !39
  %86 = add i64 %85, 1
  store i64 %86, ptr %84, align 8
  %87 = urem i64 %86, %77
  %88 = icmp eq i64 %87, 0
  br i1 %88, label %89, label %79

89:                                               ; preds = %83
  %90 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %72, ptr noundef %90) #84
  br label %79

91:                                               ; preds = %79
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

ok101:                                            ; preds = %79
  %92 = ptrtoint ptr %81 to i64
  store i64 54, ptr %81, align 1
  %v108 = getelementptr i8, ptr %81, i64 8
  store i64 ptrtoint (ptr @ref.5 to i64), ptr %v108, align 1
  %v113 = getelementptr i8, ptr %81, i64 16
  store i64 %71, ptr %v113, align 1
  store i64 %92, ptr %v45, align 1
  %v119 = load i64, ptr %v3, align 8
  %v120.not = icmp eq i64 %v119, 0
  br i1 %v120.not, label %trap121, label %ok122

trap121:                                          ; preds = %ok101
  call fastcc void @native_trap()
  unreachable

ok122:                                            ; preds = %ok101
  %v123 = inttoptr i64 %v119 to ptr
  %v124 = getelementptr i8, ptr %v123, i64 8
  store i32 1, ptr %v124, align 1
  %v125 = load i64, ptr %v3, align 8
  %v126.not = icmp eq i64 %v125, 0
  br i1 %v126.not, label %trap127, label %ok128

trap127:                                          ; preds = %ok122
  call fastcc void @native_trap()
  unreachable

ok128:                                            ; preds = %ok122
  %v129 = inttoptr i64 %v125 to ptr
  %v130 = getelementptr i8, ptr %v129, i64 8
  %v131 = load i32, ptr %v130, align 1
  %v132 = icmp eq i32 %v131, 0
  br i1 %v132, label %then136, label %ok141

then136:                                          ; preds = %ok128
  call fastcc void @native_trap()
  unreachable

ok141:                                            ; preds = %ok128
  %v143 = getelementptr i8, ptr %v129, i64 16
  %v144 = load i64, ptr %v143, align 1
  %v145.not = icmp eq i64 %v144, 0
  br i1 %v145.not, label %trap146, label %ok147

trap146:                                          ; preds = %ok141
  call fastcc void @native_trap()
  unreachable

ok147:                                            ; preds = %ok141
  store i64 %v144, ptr %v5, align 8
  %v151 = inttoptr i64 %v144 to ptr
  %v160 = getelementptr i8, ptr %v151, i64 8
  %v161 = load i64, ptr %v160, align 1
  %v162.not = icmp eq i64 %v161, 0
  br i1 %v162.not, label %trap163, label %ok164

trap163:                                          ; preds = %ok147
  call fastcc void @native_trap()
  unreachable

common.ret:                                       ; preds = %else14, %native_roots_leave.exit
  %common.ret.op = phi i32 [ %v168, %native_roots_leave.exit ], [ 0, %else14 ]
  ret i32 %common.ret.op

ok164:                                            ; preds = %ok147
  %v152 = getelementptr i8, ptr %v151, i64 16
  %v153 = load i64, ptr %v152, align 1
  %v165 = inttoptr i64 %v161 to ptr
  %v166 = getelementptr i8, ptr %v165, i64 8
  %v167 = load ptr, ptr %v166, align 1
  %93 = load i64, ptr %0, align 8, !noundef !39
  %94 = icmp eq i64 %93, 0
  br i1 %94, label %native_roots_leave.exit, label %95

95:                                               ; preds = %ok164
  %96 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %96, ptr @native_roots.0, align 8
  %97 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8, !noundef !39
  %98 = add i64 %97, -1
  store i64 %98, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %95, %ok164
  %v168 = tail call tailcc i32 %v167(i64 %v153, i64 %v28)
  br label %common.ret

else14:                                           ; preds = %entry
  store ptr %2, ptr @native_roots.0, align 8
  store i64 %3, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  br label %common.ret
}
