define internal tailcc i64 @f.2(i64 %arg0, i64 %arg1, i64 %arg2) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [8 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 8, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v10.not44 = icmp eq i64 %arg0, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  br i1 %v10.not44, label %trap11, label %ok12.lr.ph

ok12.lr.ph:                                       ; preds = %entry
  %v84 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v85 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v92 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v99 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v13153 = inttoptr i64 %arg0 to ptr
  %v14154 = getelementptr i8, ptr %v13153, i64 8
  %v15155 = load i64, ptr %v14154, align 1
  %v17156 = icmp sgt i64 %v15155, %arg1
  br i1 %v17156, label %then22, label %else21

trap11:                                           ; preds = %ok406, %entry
  call fastcc void @native_trap()
  unreachable

ok12:                                             ; preds = %ok406
  %v411 = add nsw i64 %arg1.tr46157, 1
  %v13 = inttoptr i64 %v409 to ptr
  %v14 = getelementptr i8, ptr %v13, i64 8
  %v15 = load i64, ptr %v14, align 1
  %v17 = icmp sgt i64 %v15, %v411
  br i1 %v17, label %then22, label %else21.loopexit

then22:                                           ; preds = %ok12, %ok12.lr.ph
  %arg1.tr46157 = phi i64 [ %v411, %ok12 ], [ %arg1, %ok12.lr.ph ]
  %v24.b = load i1, ptr @g.10, align 1
  br i1 %v24.b, label %block27, label %then29

then29:                                           ; preds = %then22
  call fastcc void @native_trap()
  unreachable

block27:                                          ; preds = %then22
  %v31.b = load i1, ptr @g.2, align 1
  br i1 %v31.b, label %block34, label %then36

then36:                                           ; preds = %block27
  call fastcc void @native_trap()
  unreachable

block34:                                          ; preds = %block27
  %v38 = load i64, ptr @g.1, align 8
  %v39.not = icmp eq i64 %v38, 0
  br i1 %v39.not, label %trap40, label %native_roots_leave.exit

trap40:                                           ; preds = %block34
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit:                          ; preds = %block34
  %v45 = load i64, ptr @g.9, align 8
  store i64 4, ptr %1, align 8
  %v2.i = call i64 @benchmark_opaque_hide_i64(i64 %v45)
  %v48.b = load i1, ptr @g.8, align 1
  br i1 %v48.b, label %block51, label %then53

then53:                                           ; preds = %native_roots_leave.exit
  call fastcc void @native_trap()
  unreachable

block51:                                          ; preds = %native_roots_leave.exit
  %v55 = load i64, ptr @g.7, align 8
  %v56.not = icmp eq i64 %v55, 0
  br i1 %v56.not, label %trap57, label %ok58

trap57:                                           ; preds = %block51
  call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %block51
  %v60 = icmp ugt i64 %v2.i, 4294967295
  br i1 %v60, label %then64, label %block62

then64:                                           ; preds = %ok58
  call fastcc void @native_trap()
  unreachable

block62:                                          ; preds = %ok58
  store i64 4, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %block62
  call fastcc void @native_trap() #114
  unreachable

10:                                               ; preds = %block62
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 24, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %26, label %ok70

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  %25 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef %25) #84
  br label %14

26:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

ok70:                                             ; preds = %14
  %27 = ptrtoint ptr %16 to i64
  store i64 58, ptr %16, align 1
  %v77 = getelementptr i8, ptr %16, i64 8
  store i32 0, ptr %v77, align 1
  %v82 = getelementptr i8, ptr %16, i64 16
  store i64 0, ptr %v82, align 1
  store i64 %27, ptr %v4, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v84, align 8
  store i64 %27, ptr %v85, align 8
  store i64 6, ptr %1, align 8
  %28 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %29 = icmp eq ptr %28, null
  br i1 %29, label %30, label %31

30:                                               ; preds = %ok70
  call fastcc void @native_trap() #114
  unreachable

31:                                               ; preds = %ok70
  %32 = getelementptr inbounds nuw i8, ptr %28, i64 376
  %33 = load i64, ptr %32, align 8, !noundef !39
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %35, label %39

35:                                               ; preds = %45, %39, %31
  %36 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %37 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %28, i64 noundef 16, ptr noundef %36) #84
  %38 = icmp eq ptr %37, null
  br i1 %38, label %47, label %48

39:                                               ; preds = %31
  %40 = getelementptr inbounds nuw i8, ptr %28, i64 368
  %41 = load i64, ptr %40, align 8, !noundef !39
  %42 = add i64 %41, 1
  store i64 %42, ptr %40, align 8
  %43 = urem i64 %42, %33
  %44 = icmp eq i64 %43, 0
  br i1 %44, label %45, label %35

45:                                               ; preds = %39
  %46 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %28, ptr noundef %46) #84
  br label %35

47:                                               ; preds = %35
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

48:                                               ; preds = %35
  %49 = ptrtoint ptr %37 to i64
  %50 = and i64 %49, 1
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %native_array_new.exit, label %52

52:                                               ; preds = %48
  call fastcc void @native_trap() #114
  unreachable

native_array_new.exit:                            ; preds = %48
  store i64 43, ptr %37, align 8
  %53 = getelementptr inbounds nuw i8, ptr %37, i64 8
  store i64 0, ptr %53, align 8
  %v89 = trunc nuw i64 %v2.i to i32
  store i64 %49, ptr %v84, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v85, align 8
  store i64 %27, ptr %v92, align 8
  store i64 7, ptr %1, align 8
  %v94 = call fastcc i64 @native_array_new(i64 51, i32 %v89, i64 %49)
  store i64 %v94, ptr %v6, align 8
  %v95 = load i64, ptr %v4, align 8
  store i64 %v95, ptr %v84, align 8
  store i64 %v94, ptr %v85, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v92, align 8
  store i64 %27, ptr %v99, align 8
  store i64 8, ptr %1, align 8
  %54 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %55 = icmp eq ptr %54, null
  br i1 %55, label %56, label %57

56:                                               ; preds = %native_array_new.exit
  call fastcc void @native_trap() #114
  unreachable

57:                                               ; preds = %native_array_new.exit
  %58 = getelementptr inbounds nuw i8, ptr %54, i64 376
  %59 = load i64, ptr %58, align 8, !noundef !39
  %60 = icmp eq i64 %59, 0
  br i1 %60, label %61, label %65

61:                                               ; preds = %71, %65, %57
  %62 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %63 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %54, i64 noundef 32, ptr noundef %62) #84
  %64 = icmp eq ptr %63, null
  br i1 %64, label %73, label %ok104

65:                                               ; preds = %57
  %66 = getelementptr inbounds nuw i8, ptr %54, i64 368
  %67 = load i64, ptr %66, align 8, !noundef !39
  %68 = add i64 %67, 1
  store i64 %68, ptr %66, align 8
  %69 = urem i64 %68, %59
  %70 = icmp eq i64 %69, 0
  br i1 %70, label %71, label %61

71:                                               ; preds = %65
  %72 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %54, ptr noundef %72) #84
  br label %61

73:                                               ; preds = %61
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

ok104:                                            ; preds = %61
  %74 = ptrtoint ptr %63 to i64
  store i64 38, ptr %63, align 1
  %v111 = getelementptr i8, ptr %63, i64 8
  store i64 %v2.i, ptr %v111, align 1
  %v116 = getelementptr i8, ptr %63, i64 16
  store i64 %v94, ptr %v116, align 1
  %v121 = getelementptr i8, ptr %63, i64 24
  store i64 %v95, ptr %v121, align 1
  store i64 %74, ptr %v84, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v85, align 8
  store i64 %27, ptr %v92, align 8
  store i64 7, ptr %1, align 8
  %75 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %76 = icmp eq ptr %75, null
  br i1 %76, label %77, label %78

77:                                               ; preds = %ok104
  call fastcc void @native_trap() #114
  unreachable

78:                                               ; preds = %ok104
  %79 = getelementptr inbounds nuw i8, ptr %75, i64 376
  %80 = load i64, ptr %79, align 8, !noundef !39
  %81 = icmp eq i64 %80, 0
  br i1 %81, label %82, label %86

82:                                               ; preds = %92, %86, %78
  %83 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %84 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %75, i64 noundef 24, ptr noundef %83) #84
  %85 = icmp eq ptr %84, null
  br i1 %85, label %94, label %ok129

86:                                               ; preds = %78
  %87 = getelementptr inbounds nuw i8, ptr %75, i64 368
  %88 = load i64, ptr %87, align 8, !noundef !39
  %89 = add i64 %88, 1
  store i64 %89, ptr %87, align 8
  %90 = urem i64 %89, %80
  %91 = icmp eq i64 %90, 0
  br i1 %91, label %92, label %82

92:                                               ; preds = %86
  %93 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %75, ptr noundef %93) #84
  br label %82

94:                                               ; preds = %82
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

ok129:                                            ; preds = %82
  %95 = ptrtoint ptr %84 to i64
  store i64 54, ptr %84, align 1
  %v136 = getelementptr i8, ptr %84, i64 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v136, align 1
  %v141 = getelementptr i8, ptr %84, i64 16
  store i64 %74, ptr %v141, align 1
  store i64 %95, ptr %v82, align 1
  %v147 = load i64, ptr %v4, align 8
  %v148.not = icmp eq i64 %v147, 0
  br i1 %v148.not, label %trap149, label %ok150

trap149:                                          ; preds = %ok129
  call fastcc void @native_trap()
  unreachable

ok150:                                            ; preds = %ok129
  %v151 = inttoptr i64 %v147 to ptr
  %v152 = getelementptr i8, ptr %v151, i64 8
  store i32 1, ptr %v152, align 1
  %v153 = load i64, ptr %v4, align 8
  %v154.not = icmp eq i64 %v153, 0
  br i1 %v154.not, label %trap155, label %ok156

trap155:                                          ; preds = %ok150
  call fastcc void @native_trap()
  unreachable

ok156:                                            ; preds = %ok150
  %v157 = inttoptr i64 %v153 to ptr
  %v158 = getelementptr i8, ptr %v157, i64 8
  %v159 = load i32, ptr %v158, align 1
  %v160 = icmp eq i32 %v159, 0
  br i1 %v160, label %then164, label %ok169

then164:                                          ; preds = %ok156
  call fastcc void @native_trap()
  unreachable

ok169:                                            ; preds = %ok156
  %v171 = getelementptr i8, ptr %v157, i64 16
  %v172 = load i64, ptr %v171, align 1
  %v173.not = icmp eq i64 %v172, 0
  br i1 %v173.not, label %trap174, label %ok175

trap174:                                          ; preds = %ok169
  call fastcc void @native_trap()
  unreachable

ok175:                                            ; preds = %ok169
  store i64 %v172, ptr %v5, align 8
  %v179 = inttoptr i64 %v172 to ptr
  %v183 = add nsw i64 %v2.i, -1
  %v189 = getelementptr i8, ptr %v179, i64 8
  %v190 = load i64, ptr %v189, align 1
  %v191.not = icmp eq i64 %v190, 0
  br i1 %v191.not, label %trap192, label %ok193

trap192:                                          ; preds = %ok175
  call fastcc void @native_trap()
  unreachable

ok193:                                            ; preds = %ok175
  %v180 = getelementptr i8, ptr %v179, i64 16
  %v181 = load i64, ptr %v180, align 1
  %v194 = inttoptr i64 %v190 to ptr
  %v195 = getelementptr i8, ptr %v194, i64 8
  %v196 = load ptr, ptr %v195, align 1
  store i64 %v181, ptr %v84, align 8
  store i64 5, ptr %1, align 8
  %v199 = call tailcc i32 %v196(i64 %v181, i64 %v183)
  %v200.b = load i1, ptr @g.6, align 1
  br i1 %v200.b, label %block203, label %then205

then205:                                          ; preds = %ok193
  call fastcc void @native_trap()
  unreachable

block203:                                         ; preds = %ok193
  %v207 = load i64, ptr @g.5, align 8
  %v208.not = icmp eq i64 %v207, 0
  br i1 %v208.not, label %trap209, label %ok210

trap209:                                          ; preds = %block203
  call fastcc void @native_trap()
  unreachable

ok210:                                            ; preds = %block203
  store i64 4, ptr %1, align 8
  %96 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %97 = icmp eq ptr %96, null
  br i1 %97, label %98, label %99

98:                                               ; preds = %ok210
  call fastcc void @native_trap() #114
  unreachable

99:                                               ; preds = %ok210
  %100 = getelementptr inbounds nuw i8, ptr %96, i64 376
  %101 = load i64, ptr %100, align 8, !noundef !39
  %102 = icmp eq i64 %101, 0
  br i1 %102, label %103, label %107

103:                                              ; preds = %113, %107, %99
  %104 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %105 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %96, i64 noundef 24, ptr noundef %104) #84
  %106 = icmp eq ptr %105, null
  br i1 %106, label %115, label %ok215

107:                                              ; preds = %99
  %108 = getelementptr inbounds nuw i8, ptr %96, i64 368
  %109 = load i64, ptr %108, align 8, !noundef !39
  %110 = add i64 %109, 1
  store i64 %110, ptr %108, align 8
  %111 = urem i64 %110, %101
  %112 = icmp eq i64 %111, 0
  br i1 %112, label %113, label %103

113:                                              ; preds = %107
  %114 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %96, ptr noundef %114) #84
  br label %103

115:                                              ; preds = %103
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

ok215:                                            ; preds = %103
  %116 = ptrtoint ptr %105 to i64
  store i64 58, ptr %105, align 1
  %v222 = getelementptr i8, ptr %105, i64 8
  store i32 0, ptr %v222, align 1
  %v227 = getelementptr i8, ptr %105, i64 16
  store i64 0, ptr %v227, align 1
  store i64 %116, ptr %v4, align 8
  %v228 = load i64, ptr %v6, align 8
  store i64 %116, ptr %v84, align 8
  store i64 %v228, ptr %v85, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v92, align 8
  store i64 %116, ptr %v99, align 8
  store i64 8, ptr %1, align 8
  %117 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %118 = icmp eq ptr %117, null
  br i1 %118, label %119, label %120

119:                                              ; preds = %ok215
  call fastcc void @native_trap() #114
  unreachable

120:                                              ; preds = %ok215
  %121 = getelementptr inbounds nuw i8, ptr %117, i64 376
  %122 = load i64, ptr %121, align 8, !noundef !39
  %123 = icmp eq i64 %122, 0
  br i1 %123, label %124, label %128

124:                                              ; preds = %134, %128, %120
  %125 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %126 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %117, i64 noundef 32, ptr noundef %125) #84
  %127 = icmp eq ptr %126, null
  br i1 %127, label %136, label %ok239

128:                                              ; preds = %120
  %129 = getelementptr inbounds nuw i8, ptr %117, i64 368
  %130 = load i64, ptr %129, align 8, !noundef !39
  %131 = add i64 %130, 1
  store i64 %131, ptr %129, align 8
  %132 = urem i64 %131, %122
  %133 = icmp eq i64 %132, 0
  br i1 %133, label %134, label %124

134:                                              ; preds = %128
  %135 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %117, ptr noundef %135) #84
  br label %124

136:                                              ; preds = %124
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

ok239:                                            ; preds = %124
  %137 = ptrtoint ptr %126 to i64
  store i64 30, ptr %126, align 1
  %v246 = getelementptr i8, ptr %126, i64 8
  store i64 %v228, ptr %v246, align 1
  %v251 = getelementptr i8, ptr %126, i64 16
  store i64 %v2.i, ptr %v251, align 1
  %v256 = getelementptr i8, ptr %126, i64 24
  store i64 %116, ptr %v256, align 1
  store i64 %137, ptr %v84, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v85, align 8
  store i64 %116, ptr %v92, align 8
  store i64 7, ptr %1, align 8
  %138 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %139 = icmp eq ptr %138, null
  br i1 %139, label %140, label %141

140:                                              ; preds = %ok239
  call fastcc void @native_trap() #114
  unreachable

141:                                              ; preds = %ok239
  %142 = getelementptr inbounds nuw i8, ptr %138, i64 376
  %143 = load i64, ptr %142, align 8, !noundef !39
  %144 = icmp eq i64 %143, 0
  br i1 %144, label %145, label %149

145:                                              ; preds = %155, %149, %141
  %146 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %147 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %138, i64 noundef 24, ptr noundef %146) #84
  %148 = icmp eq ptr %147, null
  br i1 %148, label %157, label %ok264

149:                                              ; preds = %141
  %150 = getelementptr inbounds nuw i8, ptr %138, i64 368
  %151 = load i64, ptr %150, align 8, !noundef !39
  %152 = add i64 %151, 1
  store i64 %152, ptr %150, align 8
  %153 = urem i64 %152, %143
  %154 = icmp eq i64 %153, 0
  br i1 %154, label %155, label %145

155:                                              ; preds = %149
  %156 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %138, ptr noundef %156) #84
  br label %145

157:                                              ; preds = %145
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #114
  unreachable

ok264:                                            ; preds = %145
  %158 = ptrtoint ptr %147 to i64
  store i64 54, ptr %147, align 1
  %v271 = getelementptr i8, ptr %147, i64 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v271, align 1
  %v276 = getelementptr i8, ptr %147, i64 16
  store i64 %137, ptr %v276, align 1
  store i64 %158, ptr %v227, align 1
  %v282 = load i64, ptr %v4, align 8
  %v283.not = icmp eq i64 %v282, 0
  br i1 %v283.not, label %trap284, label %ok285

trap284:                                          ; preds = %ok264
  call fastcc void @native_trap()
  unreachable

ok285:                                            ; preds = %ok264
  %v286 = inttoptr i64 %v282 to ptr
  %v287 = getelementptr i8, ptr %v286, i64 8
  store i32 1, ptr %v287, align 1
  %v288 = load i64, ptr %v4, align 8
  %v289.not = icmp eq i64 %v288, 0
  br i1 %v289.not, label %trap290, label %ok291

trap290:                                          ; preds = %ok285
  call fastcc void @native_trap()
  unreachable

ok291:                                            ; preds = %ok285
  %v292 = inttoptr i64 %v288 to ptr
  %v293 = getelementptr i8, ptr %v292, i64 8
  %v294 = load i32, ptr %v293, align 1
  %v295 = icmp eq i32 %v294, 0
  br i1 %v295, label %then299, label %ok304

then299:                                          ; preds = %ok291
  call fastcc void @native_trap()
  unreachable

ok304:                                            ; preds = %ok291
  %v306 = getelementptr i8, ptr %v292, i64 16
  %v307 = load i64, ptr %v306, align 1
  %v308.not = icmp eq i64 %v307, 0
  br i1 %v308.not, label %trap309, label %ok310

trap309:                                          ; preds = %ok304
  call fastcc void @native_trap()
  unreachable

ok310:                                            ; preds = %ok304
  store i64 %v307, ptr %v5, align 8
  %v314 = inttoptr i64 %v307 to ptr
  %v324 = getelementptr i8, ptr %v314, i64 8
  %v325 = load i64, ptr %v324, align 1
  %v326.not = icmp eq i64 %v325, 0
  br i1 %v326.not, label %trap327, label %ok328

trap327:                                          ; preds = %ok310
  call fastcc void @native_trap()
  unreachable

ok328:                                            ; preds = %ok310
  %v315 = getelementptr i8, ptr %v314, i64 16
  %v316 = load i64, ptr %v315, align 1
  %v329 = inttoptr i64 %v325 to ptr
  %v330 = getelementptr i8, ptr %v329, i64 8
  %v331 = load ptr, ptr %v330, align 1
  store i64 %v316, ptr %v84, align 8
  store i64 5, ptr %1, align 8
  %v334 = call tailcc i32 %v331(i64 %v316, i64 %v183)
  %v335 = load i64, ptr %v6, align 8
  %v336.not = icmp eq i64 %v335, 0
  br i1 %v336.not, label %trap337, label %ok338

trap337:                                          ; preds = %ok328
  call fastcc void @native_trap()
  unreachable

ok338:                                            ; preds = %ok328
  %v339 = and i64 %v335, 1
  %v340 = icmp eq i64 %v339, 0
  br i1 %v340, label %ok342, label %trap341

trap341:                                          ; preds = %ok338
  call fastcc void @native_trap()
  unreachable

ok342:                                            ; preds = %ok338
  %v343 = inttoptr i64 %v335 to ptr
  %v344 = getelementptr i8, ptr %v343, i64 8
  %v345 = load i64, ptr %v344, align 1
  %v347.not = icmp eq i64 %v345, 0
  br i1 %v347.not, label %trap348, label %ok349

trap348:                                          ; preds = %ok342
  call fastcc void @native_trap()
  unreachable

ok349:                                            ; preds = %ok342
  %v351 = getelementptr i8, ptr %v343, i64 16
  %v353 = load i64, ptr %v351, align 1
  %v354.not = icmp eq i64 %v353, 0
  br i1 %v354.not, label %trap355, label %ok356

trap355:                                          ; preds = %ok349
  call fastcc void @native_trap()
  unreachable

ok356:                                            ; preds = %ok349
  %v357 = and i64 %v353, 1
  %v358 = icmp eq i64 %v357, 0
  br i1 %v358, label %ok360, label %trap359

trap359:                                          ; preds = %ok356
  call fastcc void @native_trap()
  unreachable

ok360:                                            ; preds = %ok356
  %v361 = inttoptr i64 %v353 to ptr
  %v362 = getelementptr i8, ptr %v361, i64 8
  %v363 = load i64, ptr %v362, align 1
  %v365.not = icmp eq i64 %v363, 0
  br i1 %v365.not, label %trap366, label %ok367

trap366:                                          ; preds = %ok360
  call fastcc void @native_trap()
  unreachable

ok367:                                            ; preds = %ok360
  %v369 = getelementptr i8, ptr %v361, i64 16
  %v371 = load i64, ptr %v369, align 1
  %v372 = load i64, ptr %v1, align 8
  %v373.not = icmp eq i64 %v372, 0
  br i1 %v373.not, label %trap374, label %ok375

trap374:                                          ; preds = %ok367
  call fastcc void @native_trap()
  unreachable

ok375:                                            ; preds = %ok367
  %v376 = inttoptr i64 %v372 to ptr
  %v377 = getelementptr i8, ptr %v376, i64 16
  %v378 = load i64, ptr %v377, align 1
  %v379.not = icmp eq i64 %v378, 0
  br i1 %v379.not, label %trap380, label %ok381

trap380:                                          ; preds = %ok375
  call fastcc void @native_trap()
  unreachable

ok381:                                            ; preds = %ok375
  %v382 = inttoptr i64 %v378 to ptr
  %v383 = getelementptr i8, ptr %v382, i64 8
  %v384 = load i32, ptr %v383, align 1
  %v385 = icmp eq i32 %v384, 0
  br i1 %v385, label %then389, label %ok400

then389:                                          ; preds = %ok381
  call fastcc void @native_trap()
  unreachable

ok400:                                            ; preds = %ok381
  %v402 = getelementptr i8, ptr %v382, i64 16
  %v403 = load i64, ptr %v402, align 1
  %v404.not = icmp eq i64 %v403, 0
  br i1 %v404.not, label %trap405, label %ok406

trap405:                                          ; preds = %ok400
  call fastcc void @native_trap()
  unreachable

ok406:                                            ; preds = %ok400
  %v407 = inttoptr i64 %v403 to ptr
  %v408 = getelementptr i8, ptr %v407, i64 16
  %v409 = load i64, ptr %v408, align 1
  %159 = load i64, ptr %0, align 8, !noundef !39
  %160 = icmp eq i64 %159, 0
  %.pre13 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %161 = zext i1 %160 to i64
  %162 = add i64 %.pre13, %161
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %163 = select i1 %160, ptr %native_roots.0.val, ptr %roots.val
  store i64 8, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %163, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %162, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %164 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8, !noundef !39
  %165 = call noundef i64 @llvm.umax.i64(i64 %162, i64 %164)
  store i64 %165, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8
  store i64 %v409, ptr %v1, align 8
  %v10.not = icmp eq i64 %v409, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  br i1 %v10.not, label %trap11, label %ok12

else21.loopexit:                                  ; preds = %ok12
  %.lcssa49 = phi i64 [ %162, %ok12 ]
  %.lcssa47 = phi ptr [ %163, %ok12 ]
  %v371.lcssa46 = phi i64 [ %v371, %ok12 ]
  %166 = add i64 %.lcssa49, -1
  br label %else21

else21:                                           ; preds = %else21.loopexit, %ok12.lr.ph
  %167 = phi i64 [ %3, %ok12.lr.ph ], [ %166, %else21.loopexit ]
  %168 = phi ptr [ %2, %ok12.lr.ph ], [ %.lcssa47, %else21.loopexit ]
  %arg2.tr47.lcssa = phi i64 [ %arg2, %ok12.lr.ph ], [ %v371.lcssa46, %else21.loopexit ]
  store ptr %168, ptr @native_roots.0, align 8
  store i64 %167, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  ret i64 %arg2.tr47.lcssa
}
