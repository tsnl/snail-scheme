define internal tailcc i32 @f.5(i64 %arg0, i64 %arg1) #107 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [7 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 7, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v1363 = icmp sgt i64 %arg1, -1
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v3, i8 0, i64 24, i1 false)
  br i1 %v1363, label %then17.lr.ph, label %else16

then17.lr.ph:                                     ; preds = %entry
  %v70 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v104 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v105 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v20.first_iter = icmp samesign ugt i64 %arg1, 4294967295
  br label %then17

then17:                                           ; preds = %ok248, %then17.lr.ph
  %arg1.tr65 = phi i64 [ %arg1, %then17.lr.ph ], [ %v253, %ok248 ]
  %arg0.tr64 = phi i64 [ %arg0, %then17.lr.ph ], [ %v251, %ok248 ]
  br i1 %v20.first_iter, label %then24, label %block22

then24:                                           ; preds = %then17
  call fastcc void @native_trap()
  unreachable

block22:                                          ; preds = %then17
  %7 = icmp ne i64 %arg0.tr64, 0
  %8 = and i64 %arg0.tr64, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap29

9:                                                ; preds = %block22
  %10 = inttoptr i64 %arg0.tr64 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 22, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit13

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader12 [
    i64 22, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #117
  unreachable

.preheader12:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit13

.loopexit13:                                      ; preds = %.preheader12, %15
  call fastcc void @native_trap() #117
  unreachable

31:                                               ; preds = %.preheader12
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader12 [
    i64 22, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in37 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in37, 22
  br i1 %34, label %ok30, label %trap29

trap29:                                           ; preds = %native_ref_test.exit, %block22
  call fastcc void @native_trap()
  unreachable

ok30:                                             ; preds = %native_ref_test.exit
  store i64 %arg0.tr64, ptr %v3, align 8
  %v35 = getelementptr i8, ptr %10, i64 8
  %v36 = load i64, ptr %v35, align 1
  %v39.not = icmp eq i64 %v36, 0
  br i1 %v39.not, label %trap40, label %ok41

trap40:                                           ; preds = %ok30
  call fastcc void @native_trap()
  unreachable

ok41:                                             ; preds = %ok30
  %v42 = and i64 %v36, 1
  %v43 = icmp eq i64 %v42, 0
  br i1 %v43, label %ok45, label %trap44

trap44:                                           ; preds = %ok41
  call fastcc void @native_trap()
  unreachable

ok45:                                             ; preds = %ok41
  %v46 = inttoptr i64 %v36 to ptr
  %v47 = getelementptr i8, ptr %v46, i64 8
  %v48 = load i64, ptr %v47, align 1
  %v50 = icmp ult i64 %arg1.tr65, %v48
  br i1 %v50, label %ok52, label %trap51

trap51:                                           ; preds = %ok45
  call fastcc void @native_trap()
  unreachable

ok52:                                             ; preds = %ok45
  %v54 = getelementptr i8, ptr %v46, i64 16
  %v55 = getelementptr i64, ptr %v54, i64 %arg1.tr65
  %v56 = load i64, ptr %v55, align 1
  %v59.b = load i1, ptr @g.4, align 1
  br i1 %v59.b, label %block62, label %then64

then64:                                           ; preds = %ok52
  call fastcc void @native_trap()
  unreachable

block62:                                          ; preds = %ok52
  %v66 = load i64, ptr @g.3, align 8
  %v67.not = icmp eq i64 %v66, 0
  br i1 %v67.not, label %trap68, label %ok69

trap68:                                           ; preds = %block62
  call fastcc void @native_trap()
  unreachable

ok69:                                             ; preds = %block62
  store i64 %v56, ptr %v70, align 8
  store i64 5, ptr %1, align 8
  %35 = getelementptr inbounds nuw i8, ptr %12, i64 376
  %36 = load i64, ptr %35, align 8, !noundef !39
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %38, label %42

38:                                               ; preds = %48, %42, %ok69
  %39 = phi ptr [ %.pre, %48 ], [ %roots, %42 ], [ %roots, %ok69 ]
  %40 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %12, i64 noundef 24, ptr noundef %39) #85
  %41 = icmp eq ptr %40, null
  br i1 %41, label %49, label %ok75

42:                                               ; preds = %ok69
  %43 = getelementptr inbounds nuw i8, ptr %12, i64 368
  %44 = load i64, ptr %43, align 8, !noundef !39
  %45 = add i64 %44, 1
  store i64 %45, ptr %43, align 8
  %46 = urem i64 %45, %36
  %47 = icmp eq i64 %46, 0
  br i1 %47, label %48, label %38

48:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %12, ptr noundef nonnull %roots) #85
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %38

49:                                               ; preds = %38
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #117
  unreachable

ok75:                                             ; preds = %38
  %50 = ptrtoint ptr %40 to i64
  store i64 18, ptr %40, align 1
  %v82 = getelementptr i8, ptr %40, i64 8
  store i32 0, ptr %v82, align 1
  %v87 = getelementptr i8, ptr %40, i64 16
  store i64 0, ptr %v87, align 1
  store i64 %50, ptr %v4, align 8
  %v89 = uitofp nneg i64 %arg1.tr65 to double
  %v90 = fmul double %v89, 5.000000e-03
  %v91 = fadd double %v90, -1.000000e+00
  %v92 = load i64, ptr %v3, align 8
  %v93.not = icmp eq i64 %v92, 0
  br i1 %v93.not, label %trap94, label %ok95

trap94:                                           ; preds = %ok75
  call fastcc void @native_trap()
  unreachable

ok95:                                             ; preds = %ok75
  %v96 = inttoptr i64 %v92 to ptr
  %v97 = getelementptr i8, ptr %v96, i64 24
  %v98 = load i64, ptr %v97, align 1
  %v99 = sitofp i64 %v98 to double
  %v100 = fmul double %v99, 5.000000e-03
  %v101 = fadd double %v100, -5.000000e-01
  store i64 %50, ptr %v70, align 8
  store i64 %50, ptr %v104, align 8
  store i64 %v56, ptr %v105, align 8
  store i64 7, ptr %1, align 8
  %51 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %52 = icmp eq ptr %51, null
  br i1 %52, label %53, label %54

53:                                               ; preds = %ok95
  call fastcc void @native_trap() #117
  unreachable

54:                                               ; preds = %ok95
  %55 = getelementptr inbounds nuw i8, ptr %51, i64 376
  %56 = load i64, ptr %55, align 8, !noundef !39
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %58, label %62

58:                                               ; preds = %68, %62, %54
  %59 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %60 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %51, i64 noundef 32, ptr noundef %59) #85
  %61 = icmp eq ptr %60, null
  br i1 %61, label %70, label %ok110

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw i8, ptr %51, i64 368
  %64 = load i64, ptr %63, align 8, !noundef !39
  %65 = add i64 %64, 1
  store i64 %65, ptr %63, align 8
  %66 = urem i64 %65, %56
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %68, label %58

68:                                               ; preds = %62
  %69 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %51, ptr noundef %69) #85
  br label %58

70:                                               ; preds = %58
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #117
  unreachable

ok110:                                            ; preds = %58
  %71 = ptrtoint ptr %60 to i64
  store i64 14, ptr %60, align 1
  %v117 = getelementptr i8, ptr %60, i64 8
  store double %v91, ptr %v117, align 1
  %v122 = getelementptr i8, ptr %60, i64 16
  store double %v101, ptr %v122, align 1
  %v127 = getelementptr i8, ptr %60, i64 24
  store i64 %50, ptr %v127, align 1
  store i64 %71, ptr %v70, align 8
  store i64 %50, ptr %v104, align 8
  store i64 %v56, ptr %v105, align 8
  store i64 7, ptr %1, align 8
  %72 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %73 = icmp eq ptr %72, null
  br i1 %73, label %74, label %75

74:                                               ; preds = %ok110
  call fastcc void @native_trap() #117
  unreachable

75:                                               ; preds = %ok110
  %76 = getelementptr inbounds nuw i8, ptr %72, i64 376
  %77 = load i64, ptr %76, align 8, !noundef !39
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %79, label %83

79:                                               ; preds = %89, %83, %75
  %80 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %81 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h84c6bba62da30640E(ptr noalias noundef align 8 dereferenceable(344) %72, i64 noundef 16, ptr noundef %80) #85
  %82 = icmp eq ptr %81, null
  br i1 %82, label %91, label %ok135

83:                                               ; preds = %75
  %84 = getelementptr inbounds nuw i8, ptr %72, i64 368
  %85 = load i64, ptr %84, align 8, !noundef !39
  %86 = add i64 %85, 1
  store i64 %86, ptr %84, align 8
  %87 = urem i64 %86, %77
  %88 = icmp eq i64 %87, 0
  br i1 %88, label %89, label %79

89:                                               ; preds = %83
  %90 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17heae86bbb5f0d121cE(ptr noalias noundef align 8 dereferenceable(344) %72, ptr noundef %90) #85
  br label %79

91:                                               ; preds = %79
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hd8678915bcbaf8a2E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.f8c21de22003f301606242b7d3d0dd3e.425, i64 noundef 47) #117
  unreachable

ok135:                                            ; preds = %79
  %92 = ptrtoint ptr %81 to i64
  store i64 10, ptr %81, align 1
  %v142 = getelementptr i8, ptr %81, i64 8
  store i64 %71, ptr %v142, align 1
  store i64 %92, ptr %v87, align 1
  %v148 = load i64, ptr %v4, align 8
  %v149.not = icmp eq i64 %v148, 0
  br i1 %v149.not, label %trap150, label %ok151

trap150:                                          ; preds = %ok135
  call fastcc void @native_trap()
  unreachable

ok151:                                            ; preds = %ok135
  %v152 = inttoptr i64 %v148 to ptr
  %v153 = getelementptr i8, ptr %v152, i64 8
  store i32 1, ptr %v153, align 1
  %v154 = load i64, ptr %v4, align 8
  %v155.not = icmp eq i64 %v154, 0
  br i1 %v155.not, label %trap156, label %ok157

trap156:                                          ; preds = %ok151
  call fastcc void @native_trap()
  unreachable

ok157:                                            ; preds = %ok151
  %v158 = inttoptr i64 %v154 to ptr
  %v159 = getelementptr i8, ptr %v158, i64 8
  %v160 = load i32, ptr %v159, align 1
  %v161 = icmp eq i32 %v160, 0
  br i1 %v161, label %then165, label %ok170

then165:                                          ; preds = %ok157
  call fastcc void @native_trap()
  unreachable

ok170:                                            ; preds = %ok157
  %v172 = getelementptr i8, ptr %v158, i64 16
  %v173 = load i64, ptr %v172, align 1
  %v174.not = icmp eq i64 %v173, 0
  br i1 %v174.not, label %trap175, label %ok176

trap175:                                          ; preds = %ok170
  call fastcc void @native_trap()
  unreachable

ok176:                                            ; preds = %ok170
  %v177 = inttoptr i64 %v173 to ptr
  %v178 = getelementptr i8, ptr %v177, i64 8
  %v179 = load i64, ptr %v178, align 1
  store i64 %v56, ptr %v70, align 8
  store i64 %v179, ptr %v104, align 8
  store i64 6, ptr %1, align 8
  br label %else15.i

else15.i:                                         ; preds = %ok84.i.1, %ok176
  %arg3.tr12.i = phi i64 [ 0, %ok176 ], [ %v90.i.1, %ok84.i.1 ]
  %arg2.tr11.i = phi double [ %v101, %ok176 ], [ %v88.i.1, %ok84.i.1 ]
  %arg1.tr10.i = phi double [ %v91, %ok176 ], [ %v76.i.1, %ok84.i.1 ]
  %arg0.tr9.i = phi i64 [ %v179, %ok176 ], [ %v65.i.1, %ok84.i.1 ]
  %v21.i = fmul double %arg1.tr10.i, %arg1.tr10.i
  %v24.i = fmul double %arg2.tr11.i, %arg2.tr11.i
  %v25.i = fadd double %v24.i, %v21.i
  %v26.i = fcmp ogt double %v25.i, 1.600000e+01
  br i1 %v26.i, label %native_roots_leave.exit3, label %else30.i

else30.i:                                         ; preds = %else15.i
  %v35.not.i = icmp eq i64 %arg0.tr9.i, 0
  br i1 %v35.not.i, label %trap36.i, label %ok37.i

trap36.i:                                         ; preds = %else30.i.1, %else30.i
  call fastcc void @native_trap()
  unreachable

ok37.i:                                           ; preds = %else30.i
  %v38.i = inttoptr i64 %arg0.tr9.i to ptr
  %v39.i = getelementptr i8, ptr %v38.i, i64 24
  %v40.i = load i64, ptr %v39.i, align 1
  %v41.not.i = icmp eq i64 %v40.i, 0
  br i1 %v41.not.i, label %trap42.i, label %ok43.i

trap42.i:                                         ; preds = %ok37.i.1, %ok37.i
  call fastcc void @native_trap()
  unreachable

ok43.i:                                           ; preds = %ok37.i
  %v44.i = inttoptr i64 %v40.i to ptr
  %v45.i = getelementptr i8, ptr %v44.i, i64 8
  %v46.i = load i32, ptr %v45.i, align 1
  %v47.i = icmp eq i32 %v46.i, 0
  br i1 %v47.i, label %then51.i, label %ok56.i

then51.i:                                         ; preds = %ok43.i.1, %ok43.i
  call fastcc void @native_trap()
  unreachable

ok56.i:                                           ; preds = %ok43.i
  %v58.i = getelementptr i8, ptr %v44.i, i64 16
  %v59.i = load i64, ptr %v58.i, align 1
  %v60.not.i = icmp eq i64 %v59.i, 0
  br i1 %v60.not.i, label %trap61.i, label %ok84.i

trap61.i:                                         ; preds = %ok56.i.1, %ok56.i
  call fastcc void @native_trap()
  unreachable

ok84.i:                                           ; preds = %ok56.i
  %v63.i = inttoptr i64 %v59.i to ptr
  %v64.i = getelementptr i8, ptr %v63.i, i64 8
  %v65.i = load i64, ptr %v64.i, align 1
  %v79.i = fmul double %arg2.tr11.i, %arg1.tr10.i
  %v80.i = fmul double %v79.i, 2.000000e+00
  %v68.i = fsub double %v21.i, %v24.i
  %v74.i = getelementptr i8, ptr %v38.i, i64 8
  %v75.i = load double, ptr %v74.i, align 1
  %v76.i = fadd double %v68.i, %v75.i
  %v86.i = getelementptr i8, ptr %v38.i, i64 16
  %v87.i = load double, ptr %v86.i, align 1
  %v88.i = fadd double %v80.i, %v87.i
  %v21.i.1 = fmul double %v76.i, %v76.i
  %v24.i.1 = fmul double %v88.i, %v88.i
  %v25.i.1 = fadd double %v24.i.1, %v21.i.1
  %v26.i.1 = fcmp ogt double %v25.i.1, 1.600000e+01
  br i1 %v26.i.1, label %native_roots_leave.exit3.split.loop.exit42, label %else30.i.1

else30.i.1:                                       ; preds = %ok84.i
  %v35.not.i.1 = icmp eq i64 %v65.i, 0
  br i1 %v35.not.i.1, label %trap36.i, label %ok37.i.1

ok37.i.1:                                         ; preds = %else30.i.1
  %v38.i.1 = inttoptr i64 %v65.i to ptr
  %v39.i.1 = getelementptr i8, ptr %v38.i.1, i64 24
  %v40.i.1 = load i64, ptr %v39.i.1, align 1
  %v41.not.i.1 = icmp eq i64 %v40.i.1, 0
  br i1 %v41.not.i.1, label %trap42.i, label %ok43.i.1

ok43.i.1:                                         ; preds = %ok37.i.1
  %v44.i.1 = inttoptr i64 %v40.i.1 to ptr
  %v45.i.1 = getelementptr i8, ptr %v44.i.1, i64 8
  %v46.i.1 = load i32, ptr %v45.i.1, align 1
  %v47.i.1 = icmp eq i32 %v46.i.1, 0
  br i1 %v47.i.1, label %then51.i, label %ok56.i.1

ok56.i.1:                                         ; preds = %ok43.i.1
  %v58.i.1 = getelementptr i8, ptr %v44.i.1, i64 16
  %v59.i.1 = load i64, ptr %v58.i.1, align 1
  %v60.not.i.1 = icmp eq i64 %v59.i.1, 0
  br i1 %v60.not.i.1, label %trap61.i, label %ok84.i.1

ok84.i.1:                                         ; preds = %ok56.i.1
  %v63.i.1 = inttoptr i64 %v59.i.1 to ptr
  %v64.i.1 = getelementptr i8, ptr %v63.i.1, i64 8
  %v65.i.1 = load i64, ptr %v64.i.1, align 1
  %v79.i.1 = fmul double %v88.i, %v76.i
  %v80.i.1 = fmul double %v79.i.1, 2.000000e+00
  %v68.i.1 = fsub double %v21.i.1, %v24.i.1
  %v74.i.1 = getelementptr i8, ptr %v38.i.1, i64 8
  %v75.i.1 = load double, ptr %v74.i.1, align 1
  %v76.i.1 = fadd double %v68.i.1, %v75.i.1
  %v86.i.1 = getelementptr i8, ptr %v38.i.1, i64 16
  %v87.i.1 = load double, ptr %v86.i.1, align 1
  %v88.i.1 = fadd double %v80.i.1, %v87.i.1
  %v90.i.1 = add nuw nsw i64 %arg3.tr12.i, 2
  %v11.i.1 = icmp eq i64 %v90.i.1, 64
  br i1 %v11.i.1, label %native_roots_leave.exit3, label %else15.i

native_roots_leave.exit3.split.loop.exit42:       ; preds = %ok84.i
  %arg3.tr12.i.lcssa = phi i64 [ %arg3.tr12.i, %ok84.i ]
  %v90.i.le = or disjoint i64 %arg3.tr12.i.lcssa, 1
  br label %native_roots_leave.exit3

native_roots_leave.exit3:                         ; preds = %native_roots_leave.exit3.split.loop.exit42, %ok84.i.1, %else15.i
  %arg3.tr.lcssa.i = phi i64 [ %v90.i.le, %native_roots_leave.exit3.split.loop.exit42 ], [ %arg3.tr12.i, %else15.i ], [ 64, %ok84.i.1 ]
  %v187 = icmp ugt i64 %v98, 4294967295
  br i1 %v187, label %then191, label %block189

then191:                                          ; preds = %native_roots_leave.exit3
  call fastcc void @native_trap()
  unreachable

block189:                                         ; preds = %native_roots_leave.exit3
  %v197.not = icmp eq i64 %v56, 0
  br i1 %v197.not, label %trap198, label %ok199

trap198:                                          ; preds = %block189
  call fastcc void @native_trap()
  unreachable

ok199:                                            ; preds = %block189
  %v200 = and i64 %v56, 1
  %v201 = icmp eq i64 %v200, 0
  br i1 %v201, label %ok203, label %trap202

trap202:                                          ; preds = %ok199
  call fastcc void @native_trap()
  unreachable

ok203:                                            ; preds = %ok199
  %v204 = inttoptr i64 %v56 to ptr
  %v205 = getelementptr i8, ptr %v204, i64 8
  %v206 = load i64, ptr %v205, align 1
  %v208 = icmp ult i64 %v98, %v206
  br i1 %v208, label %ok210, label %trap209

trap209:                                          ; preds = %ok203
  call fastcc void @native_trap()
  unreachable

ok210:                                            ; preds = %ok203
  %v212 = getelementptr i8, ptr %v204, i64 16
  %v213 = getelementptr i64, ptr %v212, i64 %v98
  store i64 %arg3.tr.lcssa.i, ptr %v213, align 1
  %v214 = load i64, ptr %v3, align 8
  %v215.not = icmp eq i64 %v214, 0
  br i1 %v215.not, label %trap216, label %ok217

trap216:                                          ; preds = %ok210
  call fastcc void @native_trap()
  unreachable

ok217:                                            ; preds = %ok210
  %v218 = inttoptr i64 %v214 to ptr
  %v219 = getelementptr i8, ptr %v218, i64 32
  %v220 = load i64, ptr %v219, align 1
  %v221.not = icmp eq i64 %v220, 0
  br i1 %v221.not, label %trap222, label %ok223

trap222:                                          ; preds = %ok217
  call fastcc void @native_trap()
  unreachable

ok223:                                            ; preds = %ok217
  %v224 = inttoptr i64 %v220 to ptr
  %v225 = getelementptr i8, ptr %v224, i64 8
  %v226 = load i32, ptr %v225, align 1
  %v227 = icmp eq i32 %v226, 0
  br i1 %v227, label %then231, label %ok242

then231:                                          ; preds = %ok223
  call fastcc void @native_trap()
  unreachable

ok242:                                            ; preds = %ok223
  %v244 = getelementptr i8, ptr %v224, i64 16
  %v245 = load i64, ptr %v244, align 1
  %v246.not = icmp eq i64 %v245, 0
  br i1 %v246.not, label %trap247, label %ok248

trap247:                                          ; preds = %ok242
  call fastcc void @native_trap()
  unreachable

ok248:                                            ; preds = %ok242
  %v249 = inttoptr i64 %v245 to ptr
  %v250 = getelementptr i8, ptr %v249, i64 16
  %v251 = load i64, ptr %v250, align 1
  %v253 = add nsw i64 %arg1.tr65, -1
  %93 = load i64, ptr %0, align 8, !noundef !39
  %94 = icmp eq i64 %93, 0
  %.pre17 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %95 = zext i1 %94 to i64
  %96 = add i64 %.pre17, %95
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %97 = select i1 %94, ptr %native_roots.0.val, ptr %roots.val
  store i64 7, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %97, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %96, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %98 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8, !noundef !39
  %99 = call noundef i64 @llvm.umax.i64(i64 %96, i64 %98)
  store i64 %99, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h7eddf1ce2ed4fd20E.0, align 8
  store i64 %v251, ptr %v1, align 8
  %v13.not = icmp eq i64 %arg1.tr65, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v3, i8 0, i64 24, i1 false)
  br i1 %v13.not, label %else16.loopexit, label %then17

else16.loopexit:                                  ; preds = %ok248
  %v251.lcssa = phi i64 [ %v251, %ok248 ]
  %.lcssa41 = phi i64 [ %96, %ok248 ]
  %.lcssa40 = phi ptr [ %97, %ok248 ]
  %100 = add i64 %.lcssa41, -1
  br label %else16

else16:                                           ; preds = %else16.loopexit, %entry
  %101 = phi i64 [ %3, %entry ], [ %100, %else16.loopexit ]
  %102 = phi ptr [ %2, %entry ], [ %.lcssa40, %else16.loopexit ]
  %arg0.tr.lcssa = phi i64 [ %arg0, %entry ], [ %v251.lcssa, %else16.loopexit ]
  %103 = icmp ne i64 %arg0.tr.lcssa, 0
  %104 = and i64 %arg0.tr.lcssa, 1
  %.not.i5 = icmp eq i64 %104, 0
  %or.cond21 = and i1 %103, %.not.i5
  br i1 %or.cond21, label %105, label %trap258

105:                                              ; preds = %else16
  %106 = inttoptr i64 %arg0.tr.lcssa to ptr
  %107 = load i64, ptr %106, align 8, !noundef !39
  %108 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hfde66c94db85c853E.0, align 8, !noundef !39
  %109 = icmp eq ptr %108, null
  br i1 %109, label %122, label %110

110:                                              ; preds = %105
  switch i64 %107, label %111 [
    i64 22, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

111:                                              ; preds = %110
  %112 = getelementptr inbounds nuw i8, ptr %108, i64 360
  %113 = load i64, ptr %112, align 8, !noundef !39
  %114 = lshr i64 %107, 2
  %115 = add nsw i64 %114, -1
  %116 = icmp ult i64 %115, %113
  br i1 %116, label %117, label %.loopexit

117:                                              ; preds = %111
  %118 = getelementptr inbounds nuw i8, ptr %108, i64 352
  %119 = load ptr, ptr %118, align 8, !nonnull !39, !noundef !39
  %120 = getelementptr inbounds nuw i64, ptr %119, i64 %115
  %121 = load i64, ptr %120, align 8, !noundef !39
  switch i64 %121, label %.preheader [
    i64 22, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

122:                                              ; preds = %105
  call fastcc void @native_trap() #117
  unreachable

.preheader:                                       ; preds = %127, %117
  %123 = phi i64 [ %129, %127 ], [ %121, %117 ]
  %124 = lshr i64 %123, 2
  %125 = add nsw i64 %124, -1
  %126 = icmp ult i64 %125, %113
  br i1 %126, label %127, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %111
  call fastcc void @native_trap() #117
  unreachable

127:                                              ; preds = %.preheader
  %128 = getelementptr inbounds nuw i64, ptr %119, i64 %125
  %129 = load i64, ptr %128, align 8, !noundef !39
  switch i64 %129, label %.preheader [
    i64 22, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

native_ref_test.exit6:                            ; preds = %127, %127, %117, %117, %110, %110
  %.in = phi i64 [ %107, %110 ], [ %121, %117 ], [ %121, %117 ], [ %107, %110 ], [ %129, %127 ], [ %129, %127 ]
  %130 = icmp eq i64 %.in, 22
  br i1 %130, label %ok259, label %trap258

trap258:                                          ; preds = %native_ref_test.exit6, %else16
  call fastcc void @native_trap()
  unreachable

ok259:                                            ; preds = %native_ref_test.exit6
  store i64 %arg0.tr.lcssa, ptr %v3, align 8
  %v264 = getelementptr i8, ptr %106, i64 24
  %v265 = load i64, ptr %v264, align 1
  %v271 = getelementptr i8, ptr %106, i64 16
  %v272 = load i64, ptr %v271, align 1
  %v273.not = icmp eq i64 %v272, 0
  br i1 %v273.not, label %trap274, label %ok275

trap274:                                          ; preds = %ok259
  call fastcc void @native_trap()
  unreachable

ok275:                                            ; preds = %ok259
  %v276 = inttoptr i64 %v272 to ptr
  %v277 = getelementptr i8, ptr %v276, i64 8
  %v278 = load i32, ptr %v277, align 1
  %v279 = icmp eq i32 %v278, 0
  br i1 %v279, label %then283, label %ok294

then283:                                          ; preds = %ok275
  call fastcc void @native_trap()
  unreachable

ok294:                                            ; preds = %ok275
  %v296 = getelementptr i8, ptr %v276, i64 16
  %v297 = load i64, ptr %v296, align 1
  %v298.not = icmp eq i64 %v297, 0
  br i1 %v298.not, label %trap299, label %ok300

trap299:                                          ; preds = %ok294
  call fastcc void @native_trap()
  unreachable

ok300:                                            ; preds = %ok294
  %v301 = inttoptr i64 %v297 to ptr
  %v302 = getelementptr i8, ptr %v301, i64 16
  %v303 = load i64, ptr %v302, align 1
  store ptr %102, ptr @native_roots.0, align 8
  store i64 %101, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17hf44e4e47dcdcc8e2E.0, align 8
  %v305 = add i64 %v265, -1
  %v306 = tail call tailcc i32 @f.4(i64 %v303, i64 %v305)
  ret i32 %v306
}
