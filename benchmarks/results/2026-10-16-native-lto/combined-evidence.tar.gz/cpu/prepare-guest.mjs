import fs from "node:fs";
const [input, output, cpu] = process.argv.slice(2);
const text = fs.readFileSync(input, "utf8");
const transformed = text.replace(/^(define[^\n]*) \{$/gm,
  (_, definition) => `${definition} "target-cpu"="${cpu}" "target-features"="-fma" {`);
if (text === transformed) throw new Error("No guest definitions found");
fs.writeFileSync(output, transformed);
