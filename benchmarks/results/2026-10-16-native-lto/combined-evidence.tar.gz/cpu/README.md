# Bounded Mandelbrot host-CPU prototype

Two executables are frozen and ready for a coordinated clean window:

| Arm | Path | SHA-256 |
| --- | --- | --- |
| Portable control | `mbrot/generic/program` | `31bf2c40566f449faf3af4d95392c5819ea1140abf128ed416c185201e75be5f` |
| Explicit host | `mbrot/host/program` | `d646cf78e316db1f362f4828de2a6506839d54e314c0c72352691ca47a1d8387` |

Paths are relative to `/tmp/snail-native-host-cpu-20261016/probe`.
`freeze.json` records provenance, source/runtime/config/flags/executable hashes,
exact opt arguments, decoded Rust flags, target proof, complete process records,
and diagnostic counters. Cargo's full verbose command is retained per arm.
The isolated branch is `prototype-host-cpu-20261016`, based on `cf411e29`, with
no tracked product changes. Existing frozen arms and inputs remain unchanged.

Both programs passed the unchanged complete predicate: input 75, count 1000,
expected result 5. Both supervisors report exit 0, no timeout and all children
reaped. No clean timing has been taken here; all heavy jobs are stopped.

## Why this pair was justified

The existing generic native loop uses SSE2 packed and scalar instructions,
destructive operands, register copies and unpack shuffles. An actual TurboFan
code dump of the same optimized Wasm uses AVX three-operand scalar
`vmulsd`/`vaddsd`/`vsubsd` instructions. These are AVX VEX-encoded 128-bit forms,
not AVX-512. The host's frozen Rust toolchain recognizes native CPU
`arrowlake-s` (Intel Core Ultra 7 270K Plus).

Only this Mandelbrot pair was built. Array1's carried pointer-load chain gave
weaker instruction-selection evidence, so the experiment did not expand there.

## Exact treatment and semantics

Both arms use the exact original guest LLVM body from the fixed six-case
prototype. A mechanical transform adds only function CPU/feature attributes.
Control uses `x86-64`; treatment uses `arrowlake-s`. Both explicitly disable
FMA in guest and Rust/runtime code. The same settings are passed to prelink
`opt default<O3>` and Cargo's explicit-target fat/plugin LTO. No fast-math,
contract, reassociation or alias metadata is introduced.

Final combined IR verifies the intended CPU and `-fma` on every guest function,
Rust runtime `native_array_new`, and Rust provider `input_i64`. The evidence
therefore covers actual function attributes rather than only linker defaults.
The guest hot loop has no FMA intrinsic/instruction and no AVX-512 operands.

Wasm, benchmark source, input/config, native entry, provider and all 18 opaque
machine-code boundary hooks are unchanged. The boundary object SHA-256 remains
`7799e6fee0ef6ed37d5c9ae7cfb0c3a429e2fc990274873f39291c64cb40dd32`.
It prevents CPU tuning from exposing constant benchmark inputs or identity
barriers to LTO.

`ir-proof-summary.json`, per-arm `proof.json`, and extracted function IR retain
the actual work. Both outer work SCCs contain the opaque hide call, two indirect
guest-call sites and eight allocation sites. Both retain Mandelbrot floating
recurrence work. The host loop uses two scalar recurrence steps per unrolled
cycle; the generic loop uses one recurrence with packed SSE operations. Static
floating instruction counts consequently differ (20 versus 10 in the enclosing
work SCC), without changing the workload bounds or final predicate.

## Diagnostic evidence only

One hardware-counter run per arm under concurrent correctness work reported:

| Counter | Generic | Host |
| --- | ---: | ---: |
| Core cycles | 2,653,262,924 | 1,725,547,470 |
| Instructions | 8,004,969,436 | 6,595,328,668 |
| Branch misses | 3,145,935 | 933,434 |

These are instrumented diagnostic observations, not clean measurements. The
gain cannot be attributed solely to AVX encoding: target-specific costing also
changes scalar versus packed selection, unrolling and branch layout. Raw
stdout retains diagnostic seconds. The parent will run the clean paired
schedule; no extra samples or variants are planned here.

## Commands and failures

`build-mbrot.sh` prepares each guest and links via the frozen native supervisor.
`prepare-guest.mjs` adds only CPU/feature attributes. `build-env.sh` and each
`rustflags.encoded` preserve exact settings. Both builds succeeded, with Cargo
reporting 8.97s and 6.01s; these cached preparation values are not clean build
costs. Save-temps were copied immediately to `0.0.preopt.{bc,ll}` and
`0.4.opt.{bc,ll}`. Final assembly and the hot function extract are beside them.

`stat-mbrot.sh` performs the diagnostic counter runs, pins CPU 2 and clears GC
diagnostic overrides. CPU-atom startup event values are not used; analyze the
`cpu_core` records.

The first V8 code-dump attempt returned exit 13 with an unsettled top-level
await. Its process record/stdout/stderr remain unchanged as `v8-mbrot.*`.
The retry adds `--no-wasm-async-compilation`, alongside `--no-liftoff`, eager
compilation and code printing. It passed and retained actual TurboFan code as
`v8-mbrot-sync.stdout`; `dump-v8-sync.sh` records the command. This is a codegen
diagnostic rather than a V8 performance result.
