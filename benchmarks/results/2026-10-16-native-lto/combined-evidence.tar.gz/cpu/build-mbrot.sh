#!/bin/sh
set -eu
host_root=/tmp/snail-native-host-cpu-20261016
host_probe=$host_root/probe
host_package=opaque_mbrot_timing_lto
host_boundary=/tmp/snail-native-lto-20261016/probe/six/boundary.o
host_original=/tmp/snail-native-lto-20261016/probe/six/mbrot/native/module.ll
. "$host_probe/build-env.sh"
host_base_flags=$CARGO_ENCODED_RUSTFLAGS
host_separator=$(printf '\037')
for host_arm in generic host; do
    host_output=$host_probe/mbrot/$host_arm
    mkdir -p "$host_output"
    if test "$host_arm" = generic; then host_cpu=x86-64; else host_cpu=arrowlake-s; fi
    node "$host_probe/prepare-guest.mjs" "$host_original" "$host_output/module.ll" "$host_cpu"
    export SNAIL_PROCESS_RECORD="$host_output/bitcode-process.json"
    "$SNAIL_NATIVE_SUPERVISOR" --command 60000 -- "$LLVM_OPT" '-passes=default<O3>' "-mcpu=$host_cpu" -mattr=-fma "$host_output/module.ll" -o "$host_output/module.bc" > "$host_output/bitcode.stdout" 2> "$host_output/bitcode.stderr"
    export CARGO_ENCODED_RUSTFLAGS="$host_base_flags$host_separator-C${host_separator}target-cpu=$host_cpu$host_separator-C${host_separator}target-feature=-fma"
    printf '%s' "$CARGO_ENCODED_RUSTFLAGS" > "$host_output/rustflags.encoded"
    printf 'fn main() { println!("cargo:rustc-link-arg={}", "%s"); println!("cargo:rustc-link-arg={}", "%s"); }\n' "$host_output/module.bc" "$host_boundary" > "$host_probe/mbrot/build/build.rs"
    cp "$host_probe/mbrot/build/build.rs" "$host_output/build.rs"
    export SNAIL_PROCESS_RECORD="$host_output/build-process.json"
    set +e
    "$SNAIL_NATIVE_SUPERVISOR" --command 90000 -- "$CARGO" build --offline --release --target x86_64-unknown-linux-gnu --manifest-path "$host_probe/mbrot/build/Cargo.toml" --target-dir "$host_probe/target" -v > "$host_output/build.stdout" 2> "$host_output/build.stderr"
    host_result=$?
    set -e
    printf '%s\n' "$host_result" > "$host_output/build.exit"
    if test "$host_result" -ne 0; then tail -n 10 "$host_output/build.stderr"; exit "$host_result"; fi
    host_suffix=$(sed -n "/--crate-name $host_package /s/.*-C extra-filename=\([^ ]*\).*/\1/p" "$host_output/build.stderr")
    test -n "$host_suffix"
    cp "$host_probe/target/x86_64-unknown-linux-gnu/release/$host_package" "$host_output/program"
    for host_stage in 0.0.preopt 0.4.opt; do
        cp "$host_probe/target/x86_64-unknown-linux-gnu/release/deps/$host_package$host_suffix.$host_stage.bc" "$host_output/$host_stage.bc"
        llvm-dis "$host_output/$host_stage.bc" -o "$host_output/$host_stage.ll"
    done
    llvm-objdump -d --no-show-raw-insn "$host_output/program" > "$host_output/assembly.txt"
    printf 'Built %s: ' "$host_arm"
    tail -n 1 "$host_output/build.stderr"
done
