fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-runtime-pair-20261016/gcbench/module.o");
}
