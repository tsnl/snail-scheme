(import (scheme base) (scheme file) (scheme process-context) (scheme write)
        (srfi 1) (srfi 95) (except (chibi filesystem) file-exists?)
        (only (chibi string) string-prefix? string-suffix? string-join)
        (wasm-native process) (only (sfir support) copy-file))

(define output "/tmp/sfir-native-lto-evidence-20261016-v2")
(define root "/tmp/snail-native-parity-20261016")
(define files '())
(when (file-exists? output) (error "choose a fresh evidence directory" output))
(create-directory* output)

(define (retain source relative)
  (unless (and (file-regular? source) (not (file-link? source)))
    (error "evidence must be an ordinary file" source))
  (let ((target (path-join output relative)))
    (create-directory* (path-directory target))
    (copy-file source target)
    (set! files (cons relative files))))

(define (evidence-file? path name)
  (or (member name '("stdout" "stderr" "stdin" "Cargo.lock"))
      (any (lambda (suffix) (string-suffix? suffix name))
           '(".json" ".rs" ".toml" ".md" ".txt" ".stdout" ".stderr" ".bin"))
      (and (string-suffix? ".scm" name) (not (string-suffix? "reader.scm" name)))
      (and (string-suffix? ".ll" name) (string-prefix? "f." name))))

(define (retain-tree source relative select?)
  (for-each
   (lambda (name)
     (let ((path (path-join source name)) (destination (path-join relative name)))
       (unless (or (member name '("." ".." ".git" "target" "runtime" "runs" "inputs" "toolchain"))
                   (file-link? path))
         (cond ((file-directory? path) (retain-tree path destination select?))
               ((and (file-regular? path) (select? destination name)) (retain path destination))))))
   (sort (directory-files source) string<?)))

(for-each
 (lambda (campaign)
   (retain-tree (cdr campaign) (car campaign) (lambda (path name) #t)))
 '(("pilot" . "/tmp/sfir-native-parity-pilot-20261016")
   ("six" . "/tmp/sfir-native-parity-six-20261016")))

(for-each
 (lambda (name)
   (retain (path-join "/tmp/sfir-native-parity-baseline-20261016" name)
           (path-join "preparation" name)))
 '("manifest.json" "machine.json" "validation.json" "timing/plan.json"))

(for-each
 (lambda (probe)
   (retain-tree (cdr probe) (car probe) evidence-file?))
 '(("prototypes/six" . "/tmp/snail-native-lto-20261016/probe/six")
   ("prototypes/pilot" . "/tmp/snail-native-lto-20261016/probe/opaque-pilot")
   ("prototypes/final-types" . "/tmp/snail-native-allocator-20261016/probe/lto-final-target")))

(for-each
 (lambda (name)
   (retain (path-join "/tmp/snail-native-lto-20261016/probe" name)
           (path-join "prototypes/helpers" name)))
 '("lower-opaque.scm" "build-six.mjs" "validate-six.mjs" "prove-six.mjs"))

(for-each
 (lambda (name)
   (retain (path-join "/tmp/snail-native-allocator-20261016/probe/lto-profile" name)
           (path-join "profile" name)))
 '("summary.json" "native-summary.json" "native-report.txt" "v8-symbol-summary.json"
   "v8-pinned-report.txt" "native-f16.annotate.txt" "v8-index-16-TurboFan.txt"))

(for-each
 (lambda (name) (retain (path-join root "build" name) (path-join "host" name)))
 '("pilot-process-before.txt" "pilot-process-after.txt" "six-process-before.txt" "six-process-after.txt"))

(retain "/tmp/snail-native-allocator-arms-20261016/array1/timing/provenance.json"
        "prototypes/array-zero-fill.json")
(retain (path-join root "build/summarize-native-parity.scm") "summarize.scm")
(retain (car (command-line)) "archive.scm")

(write-text (path-join output "evidence-files.sha256")
            (run-command! (append '("sha256sum" "--") (sort files string<?))
                          `((directory . ,output))))
(display (length files)) (display " retained files\n")
