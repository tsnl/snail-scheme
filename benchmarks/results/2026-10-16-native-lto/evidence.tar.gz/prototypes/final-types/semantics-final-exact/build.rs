fn main() { println!("cargo:rustc-link-arg={}", "/tmp/snail-native-allocator-20261016/probe/lto-final-target/semantics-final-exact.bc"); }
