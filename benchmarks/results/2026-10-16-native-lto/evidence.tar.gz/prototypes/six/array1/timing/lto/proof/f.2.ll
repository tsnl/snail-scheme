define internal tailcc i64 @f.2(i64 %arg0, i64 %arg1, i64 %arg2) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [6 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 6, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v4, i8 0, i64 16, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap12

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 34, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit24

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader23 [
    i64 34, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #113
  unreachable

.preheader23:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit24

.loopexit24:                                      ; preds = %.preheader23, %15
  call fastcc void @native_trap() #113
  unreachable

31:                                               ; preds = %.preheader23
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader23 [
    i64 34, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in220 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in220, 34
  br i1 %34, label %ok13.lr.ph, label %trap12

ok13.lr.ph:                                       ; preds = %native_ref_test.exit
  %v123 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v124 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v125 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  br label %ok16

trap12:                                           ; preds = %native_ref_test.exit10, %ok262, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok16:                                             ; preds = %native_ref_test.exit10, %ok13.lr.ph
  %35 = phi i64 [ %3, %ok13.lr.ph ], [ %155, %native_ref_test.exit10 ]
  %36 = phi ptr [ %2, %ok13.lr.ph ], [ %156, %native_ref_test.exit10 ]
  %arg2.tr38 = phi i64 [ %arg2, %ok13.lr.ph ], [ %v219, %native_ref_test.exit10 ]
  %arg1.tr37 = phi i64 [ %arg1, %ok13.lr.ph ], [ %v267, %native_ref_test.exit10 ]
  %arg0.tr36 = phi i64 [ %arg0, %ok13.lr.ph ], [ %v265, %native_ref_test.exit10 ]
  %v17 = inttoptr i64 %arg0.tr36 to ptr
  %v18 = getelementptr i8, ptr %v17, i64 8
  %v19 = load i64, ptr %v18, align 1
  %v21 = icmp sgt i64 %v19, %arg1.tr37
  br i1 %v21, label %then26, label %else25

then26:                                           ; preds = %ok16
  %v28.b = load i1, ptr @g.12, align 1
  br i1 %v28.b, label %block38, label %then33

then33:                                           ; preds = %then26
  call fastcc void @native_trap()
  unreachable

block38:                                          ; preds = %then26
  %v42.b = load i1, ptr @g.2, align 1
  br i1 %v42.b, label %block45, label %then47

then47:                                           ; preds = %block38
  call fastcc void @native_trap()
  unreachable

block45:                                          ; preds = %block38
  %v49 = load i64, ptr @g.1, align 8
  %v50.not = icmp eq i64 %v49, 0
  br i1 %v50.not, label %trap51, label %native_roots_leave.exit

trap51:                                           ; preds = %block45
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit:                          ; preds = %block45
  %v56 = load i64, ptr @g.11, align 8
  store i64 3, ptr %1, align 8
  %v2.i = call i64 @benchmark_opaque_hide_i64(i64 %v56)
  %v59.b = load i1, ptr @g.12, align 1
  br i1 %v59.b, label %block62, label %then64

then64:                                           ; preds = %native_roots_leave.exit
  call fastcc void @native_trap()
  unreachable

block62:                                          ; preds = %native_roots_leave.exit
  %v66.b = load i1, ptr @g.14, align 1
  br i1 %v66.b, label %block69, label %then71

then71:                                           ; preds = %block62
  call fastcc void @native_trap()
  unreachable

block69:                                          ; preds = %block62
  %v73.b = load i1, ptr @g.2, align 1
  br i1 %v73.b, label %block76, label %then78

then78:                                           ; preds = %block69
  call fastcc void @native_trap()
  unreachable

block76:                                          ; preds = %block69
  %v80 = load i64, ptr @g.1, align 8
  %v81.not = icmp eq i64 %v80, 0
  br i1 %v81.not, label %trap82, label %native_roots_leave.exit1

trap82:                                           ; preds = %block76
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit1:                         ; preds = %block76
  %v87 = load i64, ptr @g.13, align 8
  store i64 3, ptr %1, align 8
  %v2.i6 = call i64 @benchmark_opaque_hide_i64(i64 %v87)
  %v90.b = load i1, ptr @g.10, align 1
  br i1 %v90.b, label %block93, label %then95

then95:                                           ; preds = %native_roots_leave.exit1
  call fastcc void @native_trap()
  unreachable

block93:                                          ; preds = %native_roots_leave.exit1
  %v97 = load i64, ptr @g.9, align 8
  %v98.not = icmp eq i64 %v97, 0
  br i1 %v98.not, label %trap99, label %ok100

trap99:                                           ; preds = %block93
  call fastcc void @native_trap()
  unreachable

ok100:                                            ; preds = %block93
  store i64 3, ptr %1, align 8
  %37 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %38 = icmp eq ptr %37, null
  br i1 %38, label %39, label %40

39:                                               ; preds = %ok100
  call fastcc void @native_trap() #113
  unreachable

40:                                               ; preds = %ok100
  %41 = getelementptr inbounds nuw i8, ptr %37, i64 376
  %42 = load i64, ptr %41, align 8, !noundef !39
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %44, label %48

44:                                               ; preds = %54, %48, %40
  %45 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %46 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %37, i64 noundef 24, ptr noundef %45) #84
  %47 = icmp eq ptr %46, null
  br i1 %47, label %56, label %ok108

48:                                               ; preds = %40
  %49 = getelementptr inbounds nuw i8, ptr %37, i64 368
  %50 = load i64, ptr %49, align 8, !noundef !39
  %51 = add i64 %50, 1
  store i64 %51, ptr %49, align 8
  %52 = urem i64 %51, %42
  %53 = icmp eq i64 %52, 0
  br i1 %53, label %54, label %44

54:                                               ; preds = %48
  %55 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %37, ptr noundef %55) #84
  br label %44

56:                                               ; preds = %44
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok108:                                            ; preds = %44
  %57 = ptrtoint ptr %46 to i64
  store i64 38, ptr %46, align 1
  %v115 = getelementptr i8, ptr %46, i64 8
  store i32 0, ptr %v115, align 1
  %v120 = getelementptr i8, ptr %46, i64 16
  store i64 0, ptr %v120, align 1
  store i64 %57, ptr %v4, align 8
  store i64 %57, ptr %v123, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v124, align 8
  store i64 %57, ptr %v125, align 8
  store i64 6, ptr %1, align 8
  %58 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %59 = icmp eq ptr %58, null
  br i1 %59, label %60, label %61

60:                                               ; preds = %ok108
  call fastcc void @native_trap() #113
  unreachable

61:                                               ; preds = %ok108
  %62 = getelementptr inbounds nuw i8, ptr %58, i64 376
  %63 = load i64, ptr %62, align 8, !noundef !39
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %65, label %69

65:                                               ; preds = %75, %69, %61
  %66 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %67 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %58, i64 noundef 24, ptr noundef %66) #84
  %68 = icmp eq ptr %67, null
  br i1 %68, label %77, label %ok130

69:                                               ; preds = %61
  %70 = getelementptr inbounds nuw i8, ptr %58, i64 368
  %71 = load i64, ptr %70, align 8, !noundef !39
  %72 = add i64 %71, 1
  store i64 %72, ptr %70, align 8
  %73 = urem i64 %72, %63
  %74 = icmp eq i64 %73, 0
  br i1 %74, label %75, label %65

75:                                               ; preds = %69
  %76 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %58, ptr noundef %76) #84
  br label %65

77:                                               ; preds = %65
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok130:                                            ; preds = %65
  %78 = ptrtoint ptr %67 to i64
  store i64 30, ptr %67, align 1
  %v137 = getelementptr i8, ptr %67, i64 8
  store i64 %v2.i6, ptr %v137, align 1
  %v142 = getelementptr i8, ptr %67, i64 16
  store i64 %57, ptr %v142, align 1
  store i64 %78, ptr %v123, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v124, align 8
  store i64 %57, ptr %v125, align 8
  store i64 6, ptr %1, align 8
  %79 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %80 = icmp eq ptr %79, null
  br i1 %80, label %81, label %82

81:                                               ; preds = %ok130
  call fastcc void @native_trap() #113
  unreachable

82:                                               ; preds = %ok130
  %83 = getelementptr inbounds nuw i8, ptr %79, i64 376
  %84 = load i64, ptr %83, align 8, !noundef !39
  %85 = icmp eq i64 %84, 0
  br i1 %85, label %86, label %90

86:                                               ; preds = %96, %90, %82
  %87 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %88 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %79, i64 noundef 24, ptr noundef %87) #84
  %89 = icmp eq ptr %88, null
  br i1 %89, label %98, label %ok150

90:                                               ; preds = %82
  %91 = getelementptr inbounds nuw i8, ptr %79, i64 368
  %92 = load i64, ptr %91, align 8, !noundef !39
  %93 = add i64 %92, 1
  store i64 %93, ptr %91, align 8
  %94 = urem i64 %93, %84
  %95 = icmp eq i64 %94, 0
  br i1 %95, label %96, label %86

96:                                               ; preds = %90
  %97 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %79, ptr noundef %97) #84
  br label %86

98:                                               ; preds = %86
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok150:                                            ; preds = %86
  %99 = ptrtoint ptr %88 to i64
  store i64 58, ptr %88, align 1
  %v157 = getelementptr i8, ptr %88, i64 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v157, align 1
  %v162 = getelementptr i8, ptr %88, i64 16
  store i64 %78, ptr %v162, align 1
  store i64 %99, ptr %v120, align 1
  %v168 = load i64, ptr %v4, align 8
  %v169.not = icmp eq i64 %v168, 0
  br i1 %v169.not, label %trap170, label %ok171

trap170:                                          ; preds = %ok150
  call fastcc void @native_trap()
  unreachable

ok171:                                            ; preds = %ok150
  %v172 = inttoptr i64 %v168 to ptr
  %v173 = getelementptr i8, ptr %v172, i64 8
  store i32 1, ptr %v173, align 1
  %v174 = load i64, ptr %v4, align 8
  %v175.not = icmp eq i64 %v174, 0
  br i1 %v175.not, label %trap176, label %ok177

trap176:                                          ; preds = %ok171
  call fastcc void @native_trap()
  unreachable

ok177:                                            ; preds = %ok171
  %v178 = inttoptr i64 %v174 to ptr
  %v179 = getelementptr i8, ptr %v178, i64 8
  %v180 = load i32, ptr %v179, align 1
  %v181 = icmp eq i32 %v180, 0
  br i1 %v181, label %then185, label %ok190

then185:                                          ; preds = %ok177
  call fastcc void @native_trap()
  unreachable

ok190:                                            ; preds = %ok177
  %v192 = getelementptr i8, ptr %v178, i64 16
  %v193 = load i64, ptr %v192, align 1
  %v194.not = icmp eq i64 %v193, 0
  br i1 %v194.not, label %trap195, label %ok196

trap195:                                          ; preds = %ok190
  call fastcc void @native_trap()
  unreachable

ok196:                                            ; preds = %ok190
  store i64 %v193, ptr %v5, align 8
  %v200 = inttoptr i64 %v193 to ptr
  %v209 = getelementptr i8, ptr %v200, i64 8
  %v210 = load i64, ptr %v209, align 1
  %v211.not = icmp eq i64 %v210, 0
  br i1 %v211.not, label %trap212, label %ok213

trap212:                                          ; preds = %ok196
  call fastcc void @native_trap()
  unreachable

ok213:                                            ; preds = %ok196
  %v201 = getelementptr i8, ptr %v200, i64 16
  %v202 = load i64, ptr %v201, align 1
  %v214 = inttoptr i64 %v210 to ptr
  %v215 = getelementptr i8, ptr %v214, i64 8
  %v216 = load ptr, ptr %v215, align 1
  store i64 %v202, ptr %v123, align 8
  store i64 4, ptr %1, align 8
  %v219 = call tailcc i64 %v216(i64 %v202, i64 %v2.i, i64 0)
  %v220 = load i64, ptr %v1, align 8
  %100 = icmp ne i64 %v220, 0
  %101 = and i64 %v220, 1
  %.not.i4 = icmp eq i64 %101, 0
  %or.cond196 = and i1 %100, %.not.i4
  br i1 %or.cond196, label %102, label %trap223

102:                                              ; preds = %ok213
  %103 = inttoptr i64 %v220 to ptr
  %104 = load i64, ptr %103, align 8, !noundef !39
  %105 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %106 = icmp eq ptr %105, null
  br i1 %106, label %121, label %107

107:                                              ; preds = %102
  %108 = icmp eq i64 %104, 34
  switch i64 %104, label %109 [
    i64 34, label %native_ref_test.exit5
    i64 0, label %native_ref_test.exit5
  ]

109:                                              ; preds = %107
  %110 = getelementptr inbounds nuw i8, ptr %105, i64 360
  %111 = load i64, ptr %110, align 8, !noundef !39
  %112 = lshr i64 %104, 2
  %113 = add nsw i64 %112, -1
  %114 = icmp ult i64 %113, %111
  br i1 %114, label %115, label %.loopexit19

115:                                              ; preds = %109
  %116 = getelementptr inbounds nuw i8, ptr %105, i64 352
  %117 = load ptr, ptr %116, align 8, !nonnull !39, !noundef !39
  %118 = getelementptr inbounds nuw i64, ptr %117, i64 %113
  %119 = load i64, ptr %118, align 8, !noundef !39
  %120 = icmp eq i64 %119, 34
  switch i64 %119, label %.preheader18 [
    i64 34, label %native_ref_test.exit5
    i64 0, label %native_ref_test.exit5
  ]

121:                                              ; preds = %102
  call fastcc void @native_trap() #113
  unreachable

.preheader18:                                     ; preds = %126, %115
  %122 = phi i64 [ %128, %126 ], [ %119, %115 ]
  %123 = lshr i64 %122, 2
  %124 = add nsw i64 %123, -1
  %125 = icmp ult i64 %124, %111
  br i1 %125, label %126, label %.loopexit19

.loopexit19:                                      ; preds = %.preheader18, %109
  call fastcc void @native_trap() #113
  unreachable

126:                                              ; preds = %.preheader18
  %127 = getelementptr inbounds nuw i64, ptr %117, i64 %124
  %128 = load i64, ptr %127, align 8, !noundef !39
  switch i64 %128, label %.preheader18 [
    i64 34, label %native_ref_test.exit5.loopexit
    i64 0, label %native_ref_test.exit5.loopexit
  ]

native_ref_test.exit5.loopexit:                   ; preds = %126, %126
  %.lcssa328 = phi i64 [ %128, %126 ], [ %128, %126 ]
  %129 = icmp eq i64 %.lcssa328, 34
  br i1 %129, label %ok227, label %trap223

native_ref_test.exit5:                            ; preds = %115, %115, %107, %107
  %130 = phi i1 [ %108, %107 ], [ %120, %115 ], [ %120, %115 ], [ %108, %107 ]
  br i1 %130, label %ok227, label %trap223

trap223:                                          ; preds = %native_ref_test.exit5, %native_ref_test.exit5.loopexit, %ok213
  call fastcc void @native_trap()
  unreachable

ok227:                                            ; preds = %native_ref_test.exit5, %native_ref_test.exit5.loopexit
  %v229 = getelementptr i8, ptr %103, i64 16
  %v230 = load i64, ptr %v229, align 1
  %v231.not = icmp eq i64 %v230, 0
  br i1 %v231.not, label %trap232, label %ok233

trap232:                                          ; preds = %ok227
  call fastcc void @native_trap()
  unreachable

ok233:                                            ; preds = %ok227
  %v234 = inttoptr i64 %v230 to ptr
  %v235 = getelementptr i8, ptr %v234, i64 8
  %v236 = load i32, ptr %v235, align 1
  %v237 = icmp eq i32 %v236, 0
  br i1 %v237, label %then241, label %block239

then241:                                          ; preds = %ok233
  call fastcc void @native_trap()
  unreachable

block239:                                         ; preds = %ok233
  switch i64 %104, label %131 [
    i64 34, label %native_ref_test.exit7
    i64 0, label %native_ref_test.exit7
  ]

131:                                              ; preds = %block239
  %132 = getelementptr inbounds nuw i8, ptr %105, i64 360
  %133 = load i64, ptr %132, align 8, !noundef !39
  %134 = lshr i64 %104, 2
  %135 = add nsw i64 %134, -1
  %136 = icmp ult i64 %135, %133
  br i1 %136, label %137, label %.loopexit17

137:                                              ; preds = %131
  %138 = getelementptr inbounds nuw i8, ptr %105, i64 352
  %139 = load ptr, ptr %138, align 8, !nonnull !39, !noundef !39
  %140 = getelementptr inbounds nuw i64, ptr %139, i64 %135
  %141 = load i64, ptr %140, align 8, !noundef !39
  %142 = icmp eq i64 %141, 34
  switch i64 %141, label %.preheader16 [
    i64 34, label %native_ref_test.exit7
    i64 0, label %native_ref_test.exit7
  ]

.preheader16:                                     ; preds = %147, %137
  %143 = phi i64 [ %149, %147 ], [ %141, %137 ]
  %144 = lshr i64 %143, 2
  %145 = add nsw i64 %144, -1
  %146 = icmp ult i64 %145, %133
  br i1 %146, label %147, label %.loopexit17

.loopexit17:                                      ; preds = %.preheader16, %131
  call fastcc void @native_trap() #113
  unreachable

147:                                              ; preds = %.preheader16
  %148 = getelementptr inbounds nuw i64, ptr %139, i64 %145
  %149 = load i64, ptr %148, align 8, !noundef !39
  switch i64 %149, label %.preheader16 [
    i64 34, label %native_ref_test.exit7.loopexit
    i64 0, label %native_ref_test.exit7.loopexit
  ]

native_ref_test.exit7.loopexit:                   ; preds = %147, %147
  %.lcssa = phi i64 [ %149, %147 ], [ %149, %147 ]
  %150 = icmp eq i64 %.lcssa, 34
  br i1 %150, label %ok256, label %trap246

native_ref_test.exit7:                            ; preds = %137, %137, %block239, %block239
  %151 = phi i1 [ %108, %block239 ], [ %142, %137 ], [ %142, %137 ], [ %108, %block239 ]
  br i1 %151, label %ok256, label %trap246

trap246:                                          ; preds = %native_ref_test.exit7, %native_ref_test.exit7.loopexit
  call fastcc void @native_trap()
  unreachable

ok256:                                            ; preds = %native_ref_test.exit7, %native_ref_test.exit7.loopexit
  %v258 = getelementptr i8, ptr %v234, i64 16
  %v259 = load i64, ptr %v258, align 1
  %v260.not = icmp eq i64 %v259, 0
  br i1 %v260.not, label %trap261, label %ok262

trap261:                                          ; preds = %ok256
  call fastcc void @native_trap()
  unreachable

ok262:                                            ; preds = %ok256
  %v263 = inttoptr i64 %v259 to ptr
  %v264 = getelementptr i8, ptr %v263, i64 16
  %v265 = load i64, ptr %v264, align 1
  %v267 = add nsw i64 %arg1.tr37, 1
  %152 = load i64, ptr %0, align 8, !noundef !39
  %153 = icmp ne i64 %152, 0
  %.pre67 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %154 = sext i1 %153 to i64
  %155 = add i64 %.pre67, %154
  %roots.val = load ptr, ptr %roots, align 8
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %156 = select i1 %153, ptr %roots.val, ptr %native_roots.0.val
  store i64 6, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %156, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %157 = add i64 %155, 1
  store i64 %157, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %158 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %159 = call noundef i64 @llvm.umax.i64(i64 %157, i64 %158)
  store i64 %159, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v265, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v4, i8 0, i64 16, i1 false)
  %160 = icmp ne i64 %v265, 0
  %161 = and i64 %v265, 1
  %.not.i9 = icmp eq i64 %161, 0
  %or.cond197 = and i1 %160, %.not.i9
  br i1 %or.cond197, label %162, label %trap12

162:                                              ; preds = %ok262
  %163 = inttoptr i64 %v265 to ptr
  %164 = load i64, ptr %163, align 8, !noundef !39
  switch i64 %164, label %165 [
    i64 34, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

165:                                              ; preds = %162
  %166 = getelementptr inbounds nuw i8, ptr %105, i64 360
  %167 = load i64, ptr %166, align 8, !noundef !39
  %168 = lshr i64 %164, 2
  %169 = add nsw i64 %168, -1
  %170 = icmp ult i64 %169, %167
  br i1 %170, label %171, label %.loopexit

171:                                              ; preds = %165
  %172 = getelementptr inbounds nuw i8, ptr %105, i64 352
  %173 = load ptr, ptr %172, align 8, !nonnull !39, !noundef !39
  %174 = getelementptr inbounds nuw i64, ptr %173, i64 %169
  %175 = load i64, ptr %174, align 8, !noundef !39
  switch i64 %175, label %.preheader [
    i64 34, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

.preheader:                                       ; preds = %180, %171
  %176 = phi i64 [ %182, %180 ], [ %175, %171 ]
  %177 = lshr i64 %176, 2
  %178 = add nsw i64 %177, -1
  %179 = icmp ult i64 %178, %167
  br i1 %179, label %180, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %165
  call fastcc void @native_trap() #113
  unreachable

180:                                              ; preds = %.preheader
  %181 = getelementptr inbounds nuw i64, ptr %173, i64 %178
  %182 = load i64, ptr %181, align 8, !noundef !39
  switch i64 %182, label %.preheader [
    i64 34, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

native_ref_test.exit10:                           ; preds = %180, %180, %171, %171, %162, %162
  %.in = phi i64 [ %164, %162 ], [ %175, %171 ], [ %175, %171 ], [ %164, %162 ], [ %182, %180 ], [ %182, %180 ]
  %183 = icmp eq i64 %.in, 34
  br i1 %183, label %ok16, label %trap12

else25:                                           ; preds = %ok16
  %.lcssa293 = phi i64 [ %35, %ok16 ]
  %.lcssa259 = phi ptr [ %36, %ok16 ]
  %arg2.tr38.lcssa = phi i64 [ %arg2.tr38, %ok16 ]
  store ptr %.lcssa259, ptr @native_roots.0, align 8
  store i64 %.lcssa293, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  ret i64 %arg2.tr38.lcssa
}
