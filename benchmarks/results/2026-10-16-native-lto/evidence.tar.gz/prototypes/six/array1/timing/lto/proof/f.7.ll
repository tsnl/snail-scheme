define internal tailcc i64 @f.7(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [7 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 7, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v8 = icmp ugt i64 %arg1, 4294967295
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  br i1 %v8, label %then12, label %block10

then12:                                           ; preds = %entry
  call fastcc void @native_trap()
  unreachable

block10:                                          ; preds = %entry
  store i64 3, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %block10
  call fastcc void @native_trap() #113
  unreachable

10:                                               ; preds = %block10
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = phi ptr [ %.pre, %24 ], [ %roots, %18 ], [ %roots, %10 ]
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 24, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %25, label %ok18

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %14

25:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok18:                                             ; preds = %14
  %26 = ptrtoint ptr %16 to i64
  store i64 26, ptr %16, align 1
  %v25 = getelementptr i8, ptr %16, i64 8
  store i32 0, ptr %v25, align 1
  %v30 = getelementptr i8, ptr %16, i64 16
  store i64 0, ptr %v30, align 1
  store i64 %26, ptr %v3, align 8
  %v33 = trunc nuw i64 %arg1 to i32
  %v34 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v34, align 8
  %v35 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 %26, ptr %v35, align 8
  store i64 5, ptr %1, align 8
  %v37 = call fastcc i64 @native_array_new(i32 %v33)
  store i64 %v37, ptr %v34, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v35, align 8
  %v40 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %26, ptr %v40, align 8
  store i64 6, ptr %1, align 8
  %27 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %28 = icmp eq ptr %27, null
  br i1 %28, label %29, label %30

29:                                               ; preds = %ok18
  call fastcc void @native_trap() #113
  unreachable

30:                                               ; preds = %ok18
  %31 = getelementptr inbounds nuw i8, ptr %27, i64 376
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %34, label %38

34:                                               ; preds = %44, %38, %30
  %35 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %36 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %27, i64 noundef 16, ptr noundef %35) #84
  %37 = icmp eq ptr %36, null
  br i1 %37, label %46, label %ok45

38:                                               ; preds = %30
  %39 = getelementptr inbounds nuw i8, ptr %27, i64 368
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = add i64 %40, 1
  store i64 %41, ptr %39, align 8
  %42 = urem i64 %41, %32
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %44, label %34

44:                                               ; preds = %38
  %45 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %27, ptr noundef %45) #84
  br label %34

46:                                               ; preds = %34
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok45:                                             ; preds = %34
  %47 = ptrtoint ptr %36 to i64
  store i64 18, ptr %36, align 1
  %v52 = getelementptr i8, ptr %36, i64 8
  store i64 %v37, ptr %v52, align 1
  %v53 = load i64, ptr %v3, align 8
  store i64 %v53, ptr %v34, align 8
  store i64 %47, ptr %v35, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v40, align 8
  %v57 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  store i64 %26, ptr %v57, align 8
  store i64 7, ptr %1, align 8
  %48 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %ok45
  call fastcc void @native_trap() #113
  unreachable

51:                                               ; preds = %ok45
  %52 = getelementptr inbounds nuw i8, ptr %48, i64 376
  %53 = load i64, ptr %52, align 8, !noundef !39
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %55, label %59

55:                                               ; preds = %65, %59, %51
  %56 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %57 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %48, i64 noundef 32, ptr noundef %56) #84
  %58 = icmp eq ptr %57, null
  br i1 %58, label %67, label %ok62

59:                                               ; preds = %51
  %60 = getelementptr inbounds nuw i8, ptr %48, i64 368
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = add i64 %61, 1
  store i64 %62, ptr %60, align 8
  %63 = urem i64 %62, %53
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %65, label %55

65:                                               ; preds = %59
  %66 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %48, ptr noundef %66) #84
  br label %55

67:                                               ; preds = %55
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok62:                                             ; preds = %55
  %68 = ptrtoint ptr %57 to i64
  store i64 14, ptr %57, align 1
  %v69 = getelementptr i8, ptr %57, i64 8
  store i64 %arg1, ptr %v69, align 1
  %v74 = getelementptr i8, ptr %57, i64 16
  store i64 %47, ptr %v74, align 1
  %v79 = getelementptr i8, ptr %57, i64 24
  store i64 %v53, ptr %v79, align 1
  store i64 %68, ptr %v34, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v35, align 8
  store i64 %26, ptr %v40, align 8
  store i64 6, ptr %1, align 8
  %69 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %70 = icmp eq ptr %69, null
  br i1 %70, label %71, label %72

71:                                               ; preds = %ok62
  call fastcc void @native_trap() #113
  unreachable

72:                                               ; preds = %ok62
  %73 = getelementptr inbounds nuw i8, ptr %69, i64 376
  %74 = load i64, ptr %73, align 8, !noundef !39
  %75 = icmp eq i64 %74, 0
  br i1 %75, label %76, label %80

76:                                               ; preds = %86, %80, %72
  %77 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %78 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %69, i64 noundef 24, ptr noundef %77) #84
  %79 = icmp eq ptr %78, null
  br i1 %79, label %88, label %ok87

80:                                               ; preds = %72
  %81 = getelementptr inbounds nuw i8, ptr %69, i64 368
  %82 = load i64, ptr %81, align 8, !noundef !39
  %83 = add i64 %82, 1
  store i64 %83, ptr %81, align 8
  %84 = urem i64 %83, %74
  %85 = icmp eq i64 %84, 0
  br i1 %85, label %86, label %76

86:                                               ; preds = %80
  %87 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %69, ptr noundef %87) #84
  br label %76

88:                                               ; preds = %76
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok87:                                             ; preds = %76
  %89 = ptrtoint ptr %78 to i64
  store i64 54, ptr %78, align 1
  %v94 = getelementptr i8, ptr %78, i64 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v94, align 1
  %v99 = getelementptr i8, ptr %78, i64 16
  store i64 %68, ptr %v99, align 1
  store i64 %89, ptr %v30, align 1
  %v105 = load i64, ptr %v3, align 8
  %v106.not = icmp eq i64 %v105, 0
  br i1 %v106.not, label %trap107, label %ok108

trap107:                                          ; preds = %ok87
  call fastcc void @native_trap()
  unreachable

ok108:                                            ; preds = %ok87
  %v109 = inttoptr i64 %v105 to ptr
  %v110 = getelementptr i8, ptr %v109, i64 8
  store i32 1, ptr %v110, align 1
  %v111 = load i64, ptr %v3, align 8
  %v112.not = icmp eq i64 %v111, 0
  br i1 %v112.not, label %trap113, label %ok114

trap113:                                          ; preds = %ok108
  call fastcc void @native_trap()
  unreachable

ok114:                                            ; preds = %ok108
  %v115 = inttoptr i64 %v111 to ptr
  %v116 = getelementptr i8, ptr %v115, i64 8
  %v117 = load i32, ptr %v116, align 1
  %v118 = icmp eq i32 %v117, 0
  br i1 %v118, label %then122, label %ok127

then122:                                          ; preds = %ok114
  call fastcc void @native_trap()
  unreachable

ok127:                                            ; preds = %ok114
  %v129 = getelementptr i8, ptr %v115, i64 16
  %v130 = load i64, ptr %v129, align 1
  %v131.not = icmp eq i64 %v130, 0
  br i1 %v131.not, label %trap132, label %ok133

trap132:                                          ; preds = %ok127
  call fastcc void @native_trap()
  unreachable

ok133:                                            ; preds = %ok127
  store i64 %v130, ptr %v4, align 8
  %v137 = inttoptr i64 %v130 to ptr
  %v145 = getelementptr i8, ptr %v137, i64 8
  %v146 = load i64, ptr %v145, align 1
  %v147.not = icmp eq i64 %v146, 0
  br i1 %v147.not, label %trap148, label %ok149

trap148:                                          ; preds = %ok133
  call fastcc void @native_trap()
  unreachable

ok149:                                            ; preds = %ok133
  %v138 = getelementptr i8, ptr %v137, i64 16
  %v139 = load i64, ptr %v138, align 1
  %v150 = inttoptr i64 %v146 to ptr
  %v151 = getelementptr i8, ptr %v150, i64 8
  %v152 = load ptr, ptr %v151, align 1
  %90 = load i64, ptr %0, align 8, !noundef !39
  %91 = icmp eq i64 %90, 0
  br i1 %91, label %native_roots_leave.exit, label %92

92:                                               ; preds = %ok149
  %93 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %93, ptr @native_roots.0, align 8
  %94 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %95 = add i64 %94, -1
  store i64 %95, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %92, %ok149
  %v153 = tail call tailcc i64 %v152(i64 %v139, i64 0)
  ret i64 %v153
}
