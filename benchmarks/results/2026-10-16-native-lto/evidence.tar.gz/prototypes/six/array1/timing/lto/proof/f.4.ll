define internal tailcc i64 @f.4(i64 %arg0, i64 %arg1, i64 %arg2) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [9 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 9, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v1046 = icmp sgt i64 %arg1, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  br i1 %v1046, label %then15.lr.ph.split, label %else14

then15.lr.ph.split:                               ; preds = %entry
  %v80 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v81 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v86 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v103 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v262 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %then15.preheader

9:                                                ; preds = %then15.lr.ph.split
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 30, label %.loopexit28
    i64 0, label %.loopexit28
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit27

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader26 [
    i64 30, label %.loopexit28
    i64 0, label %.loopexit28
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #113
  unreachable

.loopexit28:                                      ; preds = %32, %32, %21, %21, %14, %14
  %.in117 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %34, %32 ], [ %34, %32 ]
  %27 = icmp eq i64 %.in117, 30
  br label %then15.preheader

then15.preheader:                                 ; preds = %.loopexit28, %then15.lr.ph.split
  %phi.call.shrunk.ph = phi i1 [ false, %then15.lr.ph.split ], [ %27, %.loopexit28 ]
  br label %then15

.preheader26:                                     ; preds = %32, %21
  %28 = phi i64 [ %34, %32 ], [ %25, %21 ]
  %29 = lshr i64 %28, 2
  %30 = add nsw i64 %29, -1
  %31 = icmp ult i64 %30, %17
  br i1 %31, label %32, label %.loopexit27

.loopexit27:                                      ; preds = %.preheader26, %15
  call fastcc void @native_trap() #113
  unreachable

32:                                               ; preds = %.preheader26
  %33 = getelementptr inbounds nuw i64, ptr %23, i64 %30
  %34 = load i64, ptr %33, align 8, !noundef !39
  switch i64 %34, label %.preheader26 [
    i64 30, label %.loopexit28
    i64 0, label %.loopexit28
  ]

then15:                                           ; preds = %then15.backedge, %then15.preheader
  %phi.call.shrunk = phi i1 [ %phi.call.shrunk.ph, %then15.preheader ], [ %phi.call.shrunk.be, %then15.backedge ]
  %arg1.tr48 = phi i64 [ %arg1, %then15.preheader ], [ %v422, %then15.backedge ]
  %arg0.tr47 = phi i64 [ %arg0, %then15.preheader ], [ %v420, %then15.backedge ]
  br i1 %phi.call.shrunk, label %ok21, label %trap20

trap20:                                           ; preds = %then15
  call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %then15
  %v22.not = icmp eq i64 %arg0.tr47, 0
  br i1 %v22.not, label %trap23, label %ok24

trap23:                                           ; preds = %ok21
  call fastcc void @native_trap()
  unreachable

ok24:                                             ; preds = %ok21
  %v25 = inttoptr i64 %arg0.tr47 to ptr
  %v26 = getelementptr i8, ptr %v25, i64 8
  %v27 = load i64, ptr %v26, align 1
  %v28.b = load i1, ptr @g.8, align 1
  br i1 %v28.b, label %block31, label %then33

then33:                                           ; preds = %ok24
  call fastcc void @native_trap()
  unreachable

block31:                                          ; preds = %ok24
  %v35 = load i64, ptr @g.7, align 8
  %v36.not = icmp eq i64 %v35, 0
  br i1 %v36.not, label %trap37, label %ok38

trap37:                                           ; preds = %block31
  call fastcc void @native_trap()
  unreachable

ok38:                                             ; preds = %block31
  %v39.b = load i1, ptr @g.4, align 1
  br i1 %v39.b, label %block42, label %then44

then44:                                           ; preds = %ok38
  call fastcc void @native_trap()
  unreachable

block42:                                          ; preds = %ok38
  %v46 = load i64, ptr @g.3, align 8
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %block42
  call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %block42
  %v54 = icmp ugt i64 %v27, 4294967295
  br i1 %v54, label %then58, label %block56

then58:                                           ; preds = %ok49
  call fastcc void @native_trap()
  unreachable

block56:                                          ; preds = %ok49
  store i64 4, ptr %1, align 8
  %35 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %36 = icmp eq ptr %35, null
  br i1 %36, label %37, label %38

37:                                               ; preds = %block56
  call fastcc void @native_trap() #113
  unreachable

38:                                               ; preds = %block56
  %39 = getelementptr inbounds nuw i8, ptr %35, i64 376
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = icmp eq i64 %40, 0
  br i1 %41, label %42, label %46

42:                                               ; preds = %52, %46, %38
  %43 = phi ptr [ %.pre, %52 ], [ %roots, %46 ], [ %roots, %38 ]
  %44 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %35, i64 noundef 24, ptr noundef %43) #84
  %45 = icmp eq ptr %44, null
  br i1 %45, label %53, label %ok64

46:                                               ; preds = %38
  %47 = getelementptr inbounds nuw i8, ptr %35, i64 368
  %48 = load i64, ptr %47, align 8, !noundef !39
  %49 = add i64 %48, 1
  store i64 %49, ptr %47, align 8
  %50 = urem i64 %49, %40
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %52, label %42

52:                                               ; preds = %46
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %35, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %42

53:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok64:                                             ; preds = %42
  %54 = ptrtoint ptr %44 to i64
  store i64 26, ptr %44, align 1
  %v71 = getelementptr i8, ptr %44, i64 8
  store i32 0, ptr %v71, align 1
  %v76 = getelementptr i8, ptr %44, i64 16
  store i64 0, ptr %v76, align 1
  store i64 %54, ptr %v4, align 8
  %v79 = trunc nuw i64 %v27 to i32
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v80, align 8
  store i64 %54, ptr %v81, align 8
  store i64 6, ptr %1, align 8
  %v83 = call fastcc i64 @native_array_new(i32 %v79)
  store i64 %v83, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v81, align 8
  store i64 %54, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %55 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %56 = icmp eq ptr %55, null
  br i1 %56, label %57, label %58

57:                                               ; preds = %ok64
  call fastcc void @native_trap() #113
  unreachable

58:                                               ; preds = %ok64
  %59 = getelementptr inbounds nuw i8, ptr %55, i64 376
  %60 = load i64, ptr %59, align 8, !noundef !39
  %61 = icmp eq i64 %60, 0
  br i1 %61, label %62, label %66

62:                                               ; preds = %72, %66, %58
  %63 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %64 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %55, i64 noundef 16, ptr noundef %63) #84
  %65 = icmp eq ptr %64, null
  br i1 %65, label %74, label %ok91

66:                                               ; preds = %58
  %67 = getelementptr inbounds nuw i8, ptr %55, i64 368
  %68 = load i64, ptr %67, align 8, !noundef !39
  %69 = add i64 %68, 1
  store i64 %69, ptr %67, align 8
  %70 = urem i64 %69, %60
  %71 = icmp eq i64 %70, 0
  br i1 %71, label %72, label %62

72:                                               ; preds = %66
  %73 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %55, ptr noundef %73) #84
  br label %62

74:                                               ; preds = %62
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok91:                                             ; preds = %62
  %75 = ptrtoint ptr %64 to i64
  store i64 18, ptr %64, align 1
  %v98 = getelementptr i8, ptr %64, i64 8
  store i64 %v83, ptr %v98, align 1
  %v99 = load i64, ptr %v4, align 8
  store i64 %v99, ptr %v80, align 8
  store i64 %75, ptr %v81, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v86, align 8
  store i64 %54, ptr %v103, align 8
  store i64 8, ptr %1, align 8
  %76 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %77 = icmp eq ptr %76, null
  br i1 %77, label %78, label %79

78:                                               ; preds = %ok91
  call fastcc void @native_trap() #113
  unreachable

79:                                               ; preds = %ok91
  %80 = getelementptr inbounds nuw i8, ptr %76, i64 376
  %81 = load i64, ptr %80, align 8, !noundef !39
  %82 = icmp eq i64 %81, 0
  br i1 %82, label %83, label %87

83:                                               ; preds = %93, %87, %79
  %84 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %85 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %76, i64 noundef 32, ptr noundef %84) #84
  %86 = icmp eq ptr %85, null
  br i1 %86, label %95, label %ok108

87:                                               ; preds = %79
  %88 = getelementptr inbounds nuw i8, ptr %76, i64 368
  %89 = load i64, ptr %88, align 8, !noundef !39
  %90 = add i64 %89, 1
  store i64 %90, ptr %88, align 8
  %91 = urem i64 %90, %81
  %92 = icmp eq i64 %91, 0
  br i1 %92, label %93, label %83

93:                                               ; preds = %87
  %94 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %76, ptr noundef %94) #84
  br label %83

95:                                               ; preds = %83
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok108:                                            ; preds = %83
  %96 = ptrtoint ptr %85 to i64
  store i64 14, ptr %85, align 1
  %v115 = getelementptr i8, ptr %85, i64 8
  store i64 %v27, ptr %v115, align 1
  %v120 = getelementptr i8, ptr %85, i64 16
  store i64 %75, ptr %v120, align 1
  %v125 = getelementptr i8, ptr %85, i64 24
  store i64 %v99, ptr %v125, align 1
  store i64 %96, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v81, align 8
  store i64 %54, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %97 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %98 = icmp eq ptr %97, null
  br i1 %98, label %99, label %100

99:                                               ; preds = %ok108
  call fastcc void @native_trap() #113
  unreachable

100:                                              ; preds = %ok108
  %101 = getelementptr inbounds nuw i8, ptr %97, i64 376
  %102 = load i64, ptr %101, align 8, !noundef !39
  %103 = icmp eq i64 %102, 0
  br i1 %103, label %104, label %108

104:                                              ; preds = %114, %108, %100
  %105 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %106 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %97, i64 noundef 24, ptr noundef %105) #84
  %107 = icmp eq ptr %106, null
  br i1 %107, label %116, label %ok133

108:                                              ; preds = %100
  %109 = getelementptr inbounds nuw i8, ptr %97, i64 368
  %110 = load i64, ptr %109, align 8, !noundef !39
  %111 = add i64 %110, 1
  store i64 %111, ptr %109, align 8
  %112 = urem i64 %111, %102
  %113 = icmp eq i64 %112, 0
  br i1 %113, label %114, label %104

114:                                              ; preds = %108
  %115 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %97, ptr noundef %115) #84
  br label %104

116:                                              ; preds = %104
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok133:                                            ; preds = %104
  %117 = ptrtoint ptr %106 to i64
  store i64 54, ptr %106, align 1
  %v140 = getelementptr i8, ptr %106, i64 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v140, align 1
  %v145 = getelementptr i8, ptr %106, i64 16
  store i64 %96, ptr %v145, align 1
  store i64 %117, ptr %v76, align 1
  %v151 = load i64, ptr %v4, align 8
  %v152.not = icmp eq i64 %v151, 0
  br i1 %v152.not, label %trap153, label %ok154

trap153:                                          ; preds = %ok133
  call fastcc void @native_trap()
  unreachable

ok154:                                            ; preds = %ok133
  %v155 = inttoptr i64 %v151 to ptr
  %v156 = getelementptr i8, ptr %v155, i64 8
  store i32 1, ptr %v156, align 1
  %v157 = load i64, ptr %v4, align 8
  %v158.not = icmp eq i64 %v157, 0
  br i1 %v158.not, label %trap159, label %ok160

trap159:                                          ; preds = %ok154
  call fastcc void @native_trap()
  unreachable

ok160:                                            ; preds = %ok154
  %v161 = inttoptr i64 %v157 to ptr
  %v162 = getelementptr i8, ptr %v161, i64 8
  %v163 = load i32, ptr %v162, align 1
  %v164 = icmp eq i32 %v163, 0
  br i1 %v164, label %then168, label %ok173

then168:                                          ; preds = %ok160
  call fastcc void @native_trap()
  unreachable

ok173:                                            ; preds = %ok160
  %v175 = getelementptr i8, ptr %v161, i64 16
  %v176 = load i64, ptr %v175, align 1
  %v177.not = icmp eq i64 %v176, 0
  br i1 %v177.not, label %trap178, label %ok179

trap178:                                          ; preds = %ok173
  call fastcc void @native_trap()
  unreachable

ok179:                                            ; preds = %ok173
  store i64 %v176, ptr %v5, align 8
  %v183 = inttoptr i64 %v176 to ptr
  %v191 = getelementptr i8, ptr %v183, i64 8
  %v192 = load i64, ptr %v191, align 1
  %v193.not = icmp eq i64 %v192, 0
  br i1 %v193.not, label %trap194, label %ok195

trap194:                                          ; preds = %ok179
  call fastcc void @native_trap()
  unreachable

ok195:                                            ; preds = %ok179
  %v184 = getelementptr i8, ptr %v183, i64 16
  %v185 = load i64, ptr %v184, align 1
  %v196 = inttoptr i64 %v192 to ptr
  %v197 = getelementptr i8, ptr %v196, i64 8
  %v198 = load ptr, ptr %v197, align 1
  store i64 %v185, ptr %v80, align 8
  store i64 5, ptr %1, align 8
  %v201 = call tailcc i64 %v198(i64 %v185, i64 0)
  store i64 %v201, ptr %v6, align 8
  %v202.b = load i1, ptr @g.6, align 1
  br i1 %v202.b, label %block205, label %then207

then207:                                          ; preds = %ok195
  call fastcc void @native_trap()
  unreachable

block205:                                         ; preds = %ok195
  %v209 = load i64, ptr @g.5, align 8
  %v210.not = icmp eq i64 %v209, 0
  br i1 %v210.not, label %trap211, label %ok212

trap211:                                          ; preds = %block205
  call fastcc void @native_trap()
  unreachable

ok212:                                            ; preds = %block205
  %v214.not = icmp eq i64 %v201, 0
  br i1 %v214.not, label %trap215, label %ok216

trap215:                                          ; preds = %ok212
  call fastcc void @native_trap()
  unreachable

ok216:                                            ; preds = %ok212
  %v217 = and i64 %v201, 1
  %v218 = icmp eq i64 %v217, 0
  br i1 %v218, label %ok220, label %trap219

trap219:                                          ; preds = %ok216
  call fastcc void @native_trap()
  unreachable

ok220:                                            ; preds = %ok216
  %v221 = inttoptr i64 %v201 to ptr
  %v222 = getelementptr i8, ptr %v221, i64 8
  %v223 = load i64, ptr %v222, align 1
  %v225 = and i64 %v223, 4294967295
  store i64 4, ptr %1, align 8
  %118 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %119 = icmp eq ptr %118, null
  br i1 %119, label %120, label %121

120:                                              ; preds = %ok220
  call fastcc void @native_trap() #113
  unreachable

121:                                              ; preds = %ok220
  %122 = getelementptr inbounds nuw i8, ptr %118, i64 376
  %123 = load i64, ptr %122, align 8, !noundef !39
  %124 = icmp eq i64 %123, 0
  br i1 %124, label %125, label %129

125:                                              ; preds = %135, %129, %121
  %126 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %127 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %118, i64 noundef 24, ptr noundef %126) #84
  %128 = icmp eq ptr %127, null
  br i1 %128, label %137, label %ok236

129:                                              ; preds = %121
  %130 = getelementptr inbounds nuw i8, ptr %118, i64 368
  %131 = load i64, ptr %130, align 8, !noundef !39
  %132 = add i64 %131, 1
  store i64 %132, ptr %130, align 8
  %133 = urem i64 %132, %123
  %134 = icmp eq i64 %133, 0
  br i1 %134, label %135, label %125

135:                                              ; preds = %129
  %136 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %118, ptr noundef %136) #84
  br label %125

137:                                              ; preds = %125
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok236:                                            ; preds = %125
  %138 = ptrtoint ptr %127 to i64
  %v224 = trunc i64 %v223 to i32
  store i64 26, ptr %127, align 1
  %v243 = getelementptr i8, ptr %127, i64 8
  store i32 0, ptr %v243, align 1
  %v248 = getelementptr i8, ptr %127, i64 16
  store i64 0, ptr %v248, align 1
  store i64 %138, ptr %v4, align 8
  %v249 = load i64, ptr %v6, align 8
  store i64 %v249, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v81, align 8
  store i64 %138, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %v256 = call fastcc i64 @native_array_new(i32 %v224)
  %v257 = load i64, ptr %v4, align 8
  store i64 %v257, ptr %v80, align 8
  store i64 %v256, ptr %v81, align 8
  store i64 %v249, ptr %v86, align 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v103, align 8
  store i64 %138, ptr %v262, align 8
  store i64 9, ptr %1, align 8
  %139 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %140 = icmp eq ptr %139, null
  br i1 %140, label %141, label %142

141:                                              ; preds = %ok236
  call fastcc void @native_trap() #113
  unreachable

142:                                              ; preds = %ok236
  %143 = getelementptr inbounds nuw i8, ptr %139, i64 376
  %144 = load i64, ptr %143, align 8, !noundef !39
  %145 = icmp eq i64 %144, 0
  br i1 %145, label %146, label %150

146:                                              ; preds = %156, %150, %142
  %147 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %148 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %139, i64 noundef 32, ptr noundef %147) #84
  %149 = icmp eq ptr %148, null
  br i1 %149, label %158, label %ok267

150:                                              ; preds = %142
  %151 = getelementptr inbounds nuw i8, ptr %139, i64 368
  %152 = load i64, ptr %151, align 8, !noundef !39
  %153 = add i64 %152, 1
  store i64 %153, ptr %151, align 8
  %154 = urem i64 %153, %144
  %155 = icmp eq i64 %154, 0
  br i1 %155, label %156, label %146

156:                                              ; preds = %150
  %157 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %139, ptr noundef %157) #84
  br label %146

158:                                              ; preds = %146
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok267:                                            ; preds = %146
  %159 = ptrtoint ptr %148 to i64
  store i64 6, ptr %148, align 1
  %v274 = getelementptr i8, ptr %148, i64 8
  store i64 %v249, ptr %v274, align 1
  %v279 = getelementptr i8, ptr %148, i64 16
  store i64 %v256, ptr %v279, align 1
  %v284 = getelementptr i8, ptr %148, i64 24
  store i64 %v257, ptr %v284, align 1
  store i64 %159, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v81, align 8
  store i64 %138, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %160 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %161 = icmp eq ptr %160, null
  br i1 %161, label %162, label %163

162:                                              ; preds = %ok267
  call fastcc void @native_trap() #113
  unreachable

163:                                              ; preds = %ok267
  %164 = getelementptr inbounds nuw i8, ptr %160, i64 376
  %165 = load i64, ptr %164, align 8, !noundef !39
  %166 = icmp eq i64 %165, 0
  br i1 %166, label %167, label %171

167:                                              ; preds = %177, %171, %163
  %168 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %169 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %160, i64 noundef 24, ptr noundef %168) #84
  %170 = icmp eq ptr %169, null
  br i1 %170, label %179, label %ok292

171:                                              ; preds = %163
  %172 = getelementptr inbounds nuw i8, ptr %160, i64 368
  %173 = load i64, ptr %172, align 8, !noundef !39
  %174 = add i64 %173, 1
  store i64 %174, ptr %172, align 8
  %175 = urem i64 %174, %165
  %176 = icmp eq i64 %175, 0
  br i1 %176, label %177, label %167

177:                                              ; preds = %171
  %178 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %160, ptr noundef %178) #84
  br label %167

179:                                              ; preds = %167
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok292:                                            ; preds = %167
  %180 = ptrtoint ptr %169 to i64
  store i64 54, ptr %169, align 1
  %v299 = getelementptr i8, ptr %169, i64 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v299, align 1
  %v304 = getelementptr i8, ptr %169, i64 16
  store i64 %159, ptr %v304, align 1
  store i64 %180, ptr %v248, align 1
  %v310 = load i64, ptr %v4, align 8
  %v311.not = icmp eq i64 %v310, 0
  br i1 %v311.not, label %trap312, label %ok313

trap312:                                          ; preds = %ok292
  call fastcc void @native_trap()
  unreachable

ok313:                                            ; preds = %ok292
  %v314 = inttoptr i64 %v310 to ptr
  %v315 = getelementptr i8, ptr %v314, i64 8
  store i32 1, ptr %v315, align 1
  %v316 = load i64, ptr %v4, align 8
  %v317.not = icmp eq i64 %v316, 0
  br i1 %v317.not, label %trap318, label %ok319

trap318:                                          ; preds = %ok313
  call fastcc void @native_trap()
  unreachable

ok319:                                            ; preds = %ok313
  %v320 = inttoptr i64 %v316 to ptr
  %v321 = getelementptr i8, ptr %v320, i64 8
  %v322 = load i32, ptr %v321, align 1
  %v323 = icmp eq i32 %v322, 0
  br i1 %v323, label %then327, label %ok332

then327:                                          ; preds = %ok319
  call fastcc void @native_trap()
  unreachable

ok332:                                            ; preds = %ok319
  %v334 = getelementptr i8, ptr %v320, i64 16
  %v335 = load i64, ptr %v334, align 1
  %v336.not = icmp eq i64 %v335, 0
  br i1 %v336.not, label %trap337, label %ok338

trap337:                                          ; preds = %ok332
  call fastcc void @native_trap()
  unreachable

ok338:                                            ; preds = %ok332
  store i64 %v335, ptr %v5, align 8
  %v342 = inttoptr i64 %v335 to ptr
  %v352 = getelementptr i8, ptr %v342, i64 8
  %v353 = load i64, ptr %v352, align 1
  %v354.not = icmp eq i64 %v353, 0
  br i1 %v354.not, label %trap355, label %ok356

trap355:                                          ; preds = %ok338
  call fastcc void @native_trap()
  unreachable

ok356:                                            ; preds = %ok338
  %v346 = add nsw i64 %v225, -1
  %v343 = getelementptr i8, ptr %v342, i64 16
  %v344 = load i64, ptr %v343, align 1
  %v357 = inttoptr i64 %v353 to ptr
  %v358 = getelementptr i8, ptr %v357, i64 8
  %v359 = load ptr, ptr %v358, align 1
  store i64 %v344, ptr %v80, align 8
  store i64 5, ptr %1, align 8
  %v362 = call tailcc i64 %v359(i64 %v344, i64 %v346)
  %v363.not = icmp eq i64 %v362, 0
  br i1 %v363.not, label %trap364, label %ok365

trap364:                                          ; preds = %ok356
  call fastcc void @native_trap()
  unreachable

ok365:                                            ; preds = %ok356
  %v366 = and i64 %v362, 1
  %v367 = icmp eq i64 %v366, 0
  br i1 %v367, label %ok369, label %trap368

trap368:                                          ; preds = %ok365
  call fastcc void @native_trap()
  unreachable

ok369:                                            ; preds = %ok365
  %v370 = inttoptr i64 %v362 to ptr
  %v371 = getelementptr i8, ptr %v370, i64 8
  %v372 = load i64, ptr %v371, align 1
  %v375 = load i64, ptr %v1, align 8
  %181 = icmp ne i64 %v375, 0
  %182 = and i64 %v375, 1
  %.not.i9 = icmp eq i64 %182, 0
  %or.cond81 = and i1 %181, %.not.i9
  br i1 %or.cond81, label %183, label %trap378

183:                                              ; preds = %ok369
  %184 = inttoptr i64 %v375 to ptr
  %185 = load i64, ptr %184, align 8, !noundef !39
  %186 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %187 = icmp eq ptr %186, null
  br i1 %187, label %202, label %188

188:                                              ; preds = %183
  %189 = icmp eq i64 %185, 30
  switch i64 %185, label %190 [
    i64 30, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

190:                                              ; preds = %188
  %191 = getelementptr inbounds nuw i8, ptr %186, i64 360
  %192 = load i64, ptr %191, align 8, !noundef !39
  %193 = lshr i64 %185, 2
  %194 = add nsw i64 %193, -1
  %195 = icmp ult i64 %194, %192
  br i1 %195, label %196, label %.loopexit22

196:                                              ; preds = %190
  %197 = getelementptr inbounds nuw i8, ptr %186, i64 352
  %198 = load ptr, ptr %197, align 8, !nonnull !39, !noundef !39
  %199 = getelementptr inbounds nuw i64, ptr %198, i64 %194
  %200 = load i64, ptr %199, align 8, !noundef !39
  %201 = icmp eq i64 %200, 30
  switch i64 %200, label %.preheader21 [
    i64 30, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

202:                                              ; preds = %183
  call fastcc void @native_trap() #113
  unreachable

.preheader21:                                     ; preds = %207, %196
  %203 = phi i64 [ %209, %207 ], [ %200, %196 ]
  %204 = lshr i64 %203, 2
  %205 = add nsw i64 %204, -1
  %206 = icmp ult i64 %205, %192
  br i1 %206, label %207, label %.loopexit22

.loopexit22:                                      ; preds = %.preheader21, %190
  call fastcc void @native_trap() #113
  unreachable

207:                                              ; preds = %.preheader21
  %208 = getelementptr inbounds nuw i64, ptr %198, i64 %205
  %209 = load i64, ptr %208, align 8, !noundef !39
  switch i64 %209, label %.preheader21 [
    i64 30, label %native_ref_test.exit10.loopexit
    i64 0, label %native_ref_test.exit10.loopexit
  ]

native_ref_test.exit10.loopexit:                  ; preds = %207, %207
  %.lcssa142 = phi i64 [ %209, %207 ], [ %209, %207 ]
  %210 = icmp eq i64 %.lcssa142, 30
  br i1 %210, label %ok382, label %trap378

native_ref_test.exit10:                           ; preds = %196, %196, %188, %188
  %211 = phi i1 [ %189, %188 ], [ %201, %196 ], [ %201, %196 ], [ %189, %188 ]
  br i1 %211, label %ok382, label %trap378

trap378:                                          ; preds = %native_ref_test.exit10, %native_ref_test.exit10.loopexit, %ok369
  call fastcc void @native_trap()
  unreachable

ok382:                                            ; preds = %native_ref_test.exit10, %native_ref_test.exit10.loopexit
  %v384 = getelementptr i8, ptr %184, i64 16
  %v385 = load i64, ptr %v384, align 1
  %v386.not = icmp eq i64 %v385, 0
  br i1 %v386.not, label %trap387, label %ok388

trap387:                                          ; preds = %ok382
  call fastcc void @native_trap()
  unreachable

ok388:                                            ; preds = %ok382
  %v389 = inttoptr i64 %v385 to ptr
  %v390 = getelementptr i8, ptr %v389, i64 8
  %v391 = load i32, ptr %v390, align 1
  %v392 = icmp eq i32 %v391, 0
  br i1 %v392, label %then396, label %block394

then396:                                          ; preds = %ok388
  call fastcc void @native_trap()
  unreachable

block394:                                         ; preds = %ok388
  switch i64 %185, label %212 [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

212:                                              ; preds = %block394
  %213 = getelementptr inbounds nuw i8, ptr %186, i64 360
  %214 = load i64, ptr %213, align 8, !noundef !39
  %215 = lshr i64 %185, 2
  %216 = add nsw i64 %215, -1
  %217 = icmp ult i64 %216, %214
  br i1 %217, label %218, label %.loopexit20

218:                                              ; preds = %212
  %219 = getelementptr inbounds nuw i8, ptr %186, i64 352
  %220 = load ptr, ptr %219, align 8, !nonnull !39, !noundef !39
  %221 = getelementptr inbounds nuw i64, ptr %220, i64 %216
  %222 = load i64, ptr %221, align 8, !noundef !39
  %223 = icmp eq i64 %222, 30
  switch i64 %222, label %.preheader19 [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

.preheader19:                                     ; preds = %228, %218
  %224 = phi i64 [ %230, %228 ], [ %222, %218 ]
  %225 = lshr i64 %224, 2
  %226 = add nsw i64 %225, -1
  %227 = icmp ult i64 %226, %214
  br i1 %227, label %228, label %.loopexit20

.loopexit20:                                      ; preds = %.preheader19, %212
  call fastcc void @native_trap() #113
  unreachable

228:                                              ; preds = %.preheader19
  %229 = getelementptr inbounds nuw i64, ptr %220, i64 %226
  %230 = load i64, ptr %229, align 8, !noundef !39
  switch i64 %230, label %.preheader19 [
    i64 30, label %native_ref_test.exit12.loopexit
    i64 0, label %native_ref_test.exit12.loopexit
  ]

native_ref_test.exit12.loopexit:                  ; preds = %228, %228
  %.lcssa = phi i64 [ %230, %228 ], [ %230, %228 ]
  %231 = icmp eq i64 %.lcssa, 30
  br i1 %231, label %ok411, label %trap401

native_ref_test.exit12:                           ; preds = %218, %218, %block394, %block394
  %232 = phi i1 [ %189, %block394 ], [ %223, %218 ], [ %223, %218 ], [ %189, %block394 ]
  br i1 %232, label %ok411, label %trap401

trap401:                                          ; preds = %native_ref_test.exit12, %native_ref_test.exit12.loopexit
  call fastcc void @native_trap()
  unreachable

ok411:                                            ; preds = %native_ref_test.exit12, %native_ref_test.exit12.loopexit
  %v413 = getelementptr i8, ptr %v389, i64 16
  %v414 = load i64, ptr %v413, align 1
  %v415.not = icmp eq i64 %v414, 0
  br i1 %v415.not, label %trap416, label %ok417

trap416:                                          ; preds = %ok411
  call fastcc void @native_trap()
  unreachable

ok417:                                            ; preds = %ok411
  %v418 = inttoptr i64 %v414 to ptr
  %v419 = getelementptr i8, ptr %v418, i64 16
  %v420 = load i64, ptr %v419, align 1
  %233 = load i64, ptr %0, align 8, !noundef !39
  %234 = icmp eq i64 %233, 0
  %.pre50 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %235 = zext i1 %234 to i64
  %236 = add i64 %.pre50, %235
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %237 = select i1 %234, ptr %native_roots.0.val, ptr %roots.val
  store i64 9, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %237, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %236, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %238 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %239 = call noundef i64 @llvm.umax.i64(i64 %236, i64 %238)
  store i64 %239, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v420, ptr %v1, align 8
  %v10 = icmp sgt i64 %arg1.tr48, 1
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  br i1 %v10, label %ok417.split, label %tailrecurse.else14_crit_edge

ok417.split:                                      ; preds = %ok417
  %v422 = add nsw i64 %arg1.tr48, -1
  %240 = icmp ne i64 %v420, 0
  %241 = and i64 %v420, 1
  %.not.i13 = icmp eq i64 %241, 0
  %or.cond82 = and i1 %240, %.not.i13
  br i1 %or.cond82, label %242, label %then15.backedge

then15.backedge:                                  ; preds = %.loopexit18, %ok417.split
  %phi.call.shrunk.be = phi i1 [ false, %ok417.split ], [ %256, %.loopexit18 ]
  br label %then15

242:                                              ; preds = %ok417.split
  %243 = inttoptr i64 %v420 to ptr
  %244 = load i64, ptr %243, align 8, !noundef !39
  switch i64 %244, label %245 [
    i64 30, label %.loopexit18
    i64 0, label %.loopexit18
  ]

245:                                              ; preds = %242
  %246 = getelementptr inbounds nuw i8, ptr %186, i64 360
  %247 = load i64, ptr %246, align 8, !noundef !39
  %248 = lshr i64 %244, 2
  %249 = add nsw i64 %248, -1
  %250 = icmp ult i64 %249, %247
  br i1 %250, label %251, label %.loopexit

251:                                              ; preds = %245
  %252 = getelementptr inbounds nuw i8, ptr %186, i64 352
  %253 = load ptr, ptr %252, align 8, !nonnull !39, !noundef !39
  %254 = getelementptr inbounds nuw i64, ptr %253, i64 %249
  %255 = load i64, ptr %254, align 8, !noundef !39
  switch i64 %255, label %.preheader [
    i64 30, label %.loopexit18
    i64 0, label %.loopexit18
  ]

.loopexit18:                                      ; preds = %261, %261, %251, %251, %242, %242
  %.in = phi i64 [ %244, %242 ], [ %255, %251 ], [ %255, %251 ], [ %244, %242 ], [ %263, %261 ], [ %263, %261 ]
  %256 = icmp eq i64 %.in, 30
  br label %then15.backedge

.preheader:                                       ; preds = %261, %251
  %257 = phi i64 [ %263, %261 ], [ %255, %251 ]
  %258 = lshr i64 %257, 2
  %259 = add nsw i64 %258, -1
  %260 = icmp ult i64 %259, %247
  br i1 %260, label %261, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %245
  call fastcc void @native_trap() #113
  unreachable

261:                                              ; preds = %.preheader
  %262 = getelementptr inbounds nuw i64, ptr %253, i64 %259
  %263 = load i64, ptr %262, align 8, !noundef !39
  switch i64 %263, label %.preheader [
    i64 30, label %.loopexit18
    i64 0, label %.loopexit18
  ]

tailrecurse.else14_crit_edge:                     ; preds = %ok417
  %.lcssa138 = phi i64 [ %236, %ok417 ]
  %.lcssa135 = phi ptr [ %237, %ok417 ]
  %v372.lcssa132 = phi i64 [ %v372, %ok417 ]
  %v374.le = and i64 %v372.lcssa132, 4294967295
  %264 = add i64 %.lcssa138, -1
  br label %else14

else14:                                           ; preds = %tailrecurse.else14_crit_edge, %entry
  %265 = phi i64 [ %264, %tailrecurse.else14_crit_edge ], [ %3, %entry ]
  %266 = phi ptr [ %.lcssa135, %tailrecurse.else14_crit_edge ], [ %2, %entry ]
  %arg2.tr.lcssa = phi i64 [ %v374.le, %tailrecurse.else14_crit_edge ], [ %arg2, %entry ]
  store ptr %266, ptr @native_roots.0, align 8
  store i64 %265, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  ret i64 %arg2.tr.lcssa
}
