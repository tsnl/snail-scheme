# Six-case shared-LTO harness

No clean timing is performed by these scripts. The parent owns measurement.
All programs are built from `/tmp/sfir-native-parity-baseline-20261016/timing/artifacts/`.
Frozen sources/artifacts remain untouched. Product source stays at `cf411e29`.

`node ../build-six.mjs` rebuilds six cases. `node ../validate-six.mjs CASE...` runs
one correctness execution per timing/diagnostic arm, under the frozen native
supervisor. `node ../prove-six.mjs CASE...` records guest LLVM control-flow cycles.
The builder uses public `(wasm-native)` raw-Wasm lowering via `../lower-opaque.scm`;
the helper's `(scheme cxr)` import has been fixed.

Each case requires both the optimized-Wasm SHA-256 and generated guest LLVM to
match the frozen native/V8 input, with only explicit native benchmark import
symbols renamed. `CASE/evidence.json` stores those checks, exact copied timing
provider/config/entry hashes and both executable hashes. Canonical SFIR sources,
benchmark inputs and complete entry predicates remain unchanged.

All 18 benchmark `export_name` hooks are behind the same `boundary.o` in both
arms. `boundary.rs` is a no_std Rust forwarding module, compiled to real machine
code with LLVM bitcode embedding disabled. It introduces no standard-library or
second snail-runtime dependency. The original Rust scalar provider stays intact
and links as its ordinary Cargo crate. The guest cannot see through the machine
trampolines, so input/hide/barrier bodies remain opaque even under shared LTO.
`boundary-assembly.stdout` retains each tail jump and its target relocation.

Both arms use identical target-only fat-LTO Rust flags and the same boundary
object. `matched-native` passes a guest machine object; `lto` passes guest bitcode.
The current/frozen baseline remains a separate control because the new machine
boundary adds a tail jump per benchmark hook. Shared optimization of the runtime
and ordinary product providers remains enabled; the opacity treatment is confined
to this benchmark harness.

Executable paths for later parent-owned clean measurements:

```
/tmp/snail-native-lto-20261016/probe/six/CASE/timing/matched-native/program
/tmp/snail-native-lto-20261016/probe/six/CASE/timing/lto/program
```

Diagnostic programs are under `CASE/diagnostic/ARM/program` and must not be used
for timing. Their configuration differs only by OBSERVE_BARRIERS=true; their entry
is the original full validation predicate. Correctness output and native process
records are retained beside every arm under `correctness/`.

`CASE/timing/lto/{pre-lto.ll,post-lto.ll,assembly.stdout}` retain the uninstrumented
IR and final assembly. `proof.json` and `proof/f.*.ll` expose complete guest
functions and CFG cycles, including work in the same cycle as each opaque hide.
The fib/fibfp outer cycle includes 1,024 static recurrence-worker call sites
(Binaryen's existing unrolling), while the recursive workers retain two recursive
calls and their addition. The workers are nounwind only; the optimizer has not
proved them memory(none) or willreturn. Calls therefore remain before each outer
loop backedge, and final assembly still calls the worker inside that loop.
Matrix and array kernels retain allocation and update cycles; full functions and
machine code are retained for inspection rather than inferred from hook counts.

Cargo is invoked with `--target x86_64-unknown-linux-gnu`. That keeps the fat-LTO
flags off host build scripts. The existing package rustc-native wrapper gives
those host scripts their ordinary Rust linker/libc configuration. Final outputs
are found under `target/<triple>/release`. An eventual product cleanup must set
that host wrapper explicitly instead of depending on ambient environment state.
