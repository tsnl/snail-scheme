define internal tailcc i32 @f.4(i64 %arg0, i32 %arg1) unnamed_addr #105 personality ptr @rust_eh_personality {
entry:
  %v10.not = icmp eq i64 %arg0, 0
  br i1 %v10.not, label %trap11, label %ok12

trap11:                                           ; preds = %entry
  tail call fastcc void @native_trap()
  unreachable

ok12:                                             ; preds = %entry
  %v13 = inttoptr i64 %arg0 to ptr
  %v14 = getelementptr i8, ptr %v13, i64 8
  %v15 = load i32, ptr %v14, align 1
  %v17 = icmp ult i32 %v15, %arg1
  br i1 %v17, label %then21, label %ok27

then21:                                           ; preds = %ok12
  tail call fastcc void @native_trap()
  unreachable

ok27:                                             ; preds = %ok12
  %v29 = getelementptr i8, ptr %v13, i64 16
  %v30 = load i32, ptr %v29, align 1
  %v31 = icmp eq i32 %v15, %v30
  br i1 %v31, label %native_roots_leave.exit, label %ok49

native_roots_leave.exit:                          ; preds = %ok208, %ok27
  %common.ret.op = phi i32 [ %slot4.3.lcssa, %ok208 ], [ %arg1, %ok27 ]
  ret i32 %common.ret.op

ok49:                                             ; preds = %ok27
  %v43 = getelementptr i8, ptr %v13, i64 40
  %v44 = load i32, ptr %v43, align 1
  %v51 = getelementptr i8, ptr %v13, i64 32
  %v52 = load i32, ptr %v51, align 1
  %v54 = sub i32 %v52, %arg1
  %v57 = sub i32 %arg1, %v52
  %v60 = icmp ult i32 %arg1, %v52
  %v63 = select i1 %v60, i32 %v54, i32 %v57
  %v64 = icmp ult i32 %arg1, %v63
  %spec.select = select i1 %v64, i32 0, i32 %v44
  %spec.select29 = select i1 %v64, i32 0, i32 %v52
  %v72 = sub i32 %v15, %arg1
  %v75 = sub i32 %spec.select29, %arg1
  %v78 = sub i32 %arg1, %spec.select29
  %v81 = icmp ult i32 %arg1, %spec.select29
  %v84 = select i1 %v81, i32 %v75, i32 %v78
  %v85 = icmp ult i32 %v72, %v84
  %spec.select30 = select i1 %v85, i32 %v30, i32 %spec.select
  %spec.select31 = select i1 %v85, i32 %v15, i32 %spec.select29
  %v104 = getelementptr i8, ptr %v13, i64 24
  %v105 = load i64, ptr %v104, align 1
  %v11044 = icmp ugt i32 %arg1, %spec.select31
  br i1 %v11044, label %then114.lr.ph, label %loop164.preheader

then114.lr.ph:                                    ; preds = %ok49
  %v118.not = icmp eq i64 %v105, 0
  %v125 = inttoptr i64 %v105 to ptr
  %v126 = getelementptr i8, ptr %v125, i64 8
  %v133 = getelementptr i8, ptr %v125, i64 16
  br i1 %v118.not, label %trap119, label %then114.lr.ph.split

then114.lr.ph.split:                              ; preds = %then114.lr.ph
  %v121 = and i64 %v105, 1
  %v122 = icmp eq i64 %v121, 0
  br i1 %v122, label %then114.lr.ph.split.split, label %trap123

then114.lr.ph.split.split:                        ; preds = %then114.lr.ph.split
  %v127 = load i64, ptr %v126, align 1
  br label %then114

loop164.preheader:                                ; preds = %ok49
  %v16748 = icmp ult i32 %arg1, %spec.select31
  br i1 %v16748, label %loop174.preheader.lr.ph, label %ok208

loop174.preheader.lr.ph:                          ; preds = %loop164.preheader
  %v178.not = icmp eq i64 %v105, 0
  %v185 = inttoptr i64 %v105 to ptr
  %v186 = getelementptr i8, ptr %v185, i64 8
  %v193 = getelementptr i8, ptr %v185, i64 16
  br i1 %v178.not, label %trap179, label %loop174.preheader.lr.ph.split

loop174.preheader.lr.ph.split:                    ; preds = %loop174.preheader.lr.ph
  %v181 = and i64 %v105, 1
  %v182 = icmp eq i64 %v181, 0
  br i1 %v182, label %loop174.preheader.lr.ph.split.split, label %trap183

loop174.preheader.lr.ph.split.split:              ; preds = %loop174.preheader.lr.ph.split
  %v187 = load i64, ptr %v186, align 1
  br label %loop174.preheader

then114:                                          ; preds = %ok131, %then114.lr.ph.split.split
  %slot3.246 = phi i32 [ %spec.select31, %then114.lr.ph.split.split ], [ %v162, %ok131 ]
  %slot4.245 = phi i32 [ %spec.select30, %then114.lr.ph.split.split ], [ %v160, %ok131 ]
  %v128 = zext i32 %slot4.245 to i64
  %v129 = icmp ugt i64 %v127, %v128
  br i1 %v129, label %ok131, label %trap130

trap119:                                          ; preds = %then114.lr.ph
  tail call fastcc void @native_trap()
  unreachable

trap123:                                          ; preds = %then114.lr.ph.split
  tail call fastcc void @native_trap()
  unreachable

trap130:                                          ; preds = %then114
  tail call fastcc void @native_trap()
  unreachable

ok131:                                            ; preds = %then114
  %v134 = getelementptr i8, ptr %v133, i64 %v128
  %v135 = load i8, ptr %v134, align 1
  %v137 = icmp sgt i8 %v135, -1
  %v145 = icmp ult i8 %v135, -32
  %v153 = icmp ult i8 %v135, -16
  %v156 = select i1 %v153, i32 3, i32 4
  %slot147.0 = select i1 %v145, i32 2, i32 %v156
  %slot139.0 = select i1 %v137, i32 1, i32 %slot147.0
  %v160 = add i32 %slot139.0, %slot4.245
  %v162 = add nuw i32 %slot3.246, 1
  %exitcond.not = icmp eq i32 %v162, %arg1
  br i1 %exitcond.not, label %ok208, label %then114

loop174.preheader:                                ; preds = %block173, %loop174.preheader.lr.ph.split.split
  %slot3.350 = phi i32 [ %spec.select31, %loop174.preheader.lr.ph.split.split ], [ %v203, %block173 ]
  %slot4.349 = phi i32 [ %spec.select30, %loop174.preheader.lr.ph.split.split ], [ %v177.lcssa5, %block173 ]
  br label %loop174

loop174:                                          ; preds = %ok191, %loop174.preheader
  %slot4.4 = phi i32 [ %v177, %ok191 ], [ %slot4.349, %loop174.preheader ]
  %v177 = add i32 %slot4.4, -1
  %v188 = zext i32 %v177 to i64
  %v189 = icmp ugt i64 %v187, %v188
  br i1 %v189, label %ok191, label %trap190

trap179:                                          ; preds = %loop174.preheader.lr.ph
  tail call fastcc void @native_trap()
  unreachable

trap183:                                          ; preds = %loop174.preheader.lr.ph.split
  tail call fastcc void @native_trap()
  unreachable

trap190:                                          ; preds = %loop174
  tail call fastcc void @native_trap()
  unreachable

ok191:                                            ; preds = %loop174
  %v194 = getelementptr i8, ptr %v193, i64 %v188
  %v195 = load i8, ptr %v194, align 1
  %v198 = icmp slt i8 %v195, -64
  br i1 %v198, label %loop174, label %block173

block173:                                         ; preds = %ok191
  %v177.lcssa5 = phi i32 [ %v177, %ok191 ]
  %v203 = add i32 %slot3.350, -1
  %v167 = icmp ult i32 %arg1, %v203
  br i1 %v167, label %loop174.preheader, label %ok208

ok208:                                            ; preds = %block173, %ok131, %loop164.preheader
  %slot4.3.lcssa = phi i32 [ %spec.select30, %loop164.preheader ], [ %v160, %ok131 ], [ %v177.lcssa5, %block173 ]
  store i32 %arg1, ptr %v51, align 1
  store i32 %slot4.3.lcssa, ptr %v43, align 1
  br label %native_roots_leave.exit
}
