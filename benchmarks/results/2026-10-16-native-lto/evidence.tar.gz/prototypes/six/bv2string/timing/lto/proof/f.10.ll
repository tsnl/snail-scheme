define internal tailcc noundef i32 @f.10(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [15 x i64] }, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v7 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v8 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v9 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v10 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v11 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v12 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v13 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  %v14 = getelementptr inbounds nuw i8, ptr %roots, i64 96
  %v121 = getelementptr inbounds nuw i8, ptr %roots, i64 104
  %v122 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %v173 = getelementptr inbounds nuw i8, ptr %roots, i64 112
  %v174 = getelementptr inbounds nuw i8, ptr %roots, i64 120
  %v181 = getelementptr inbounds nuw i8, ptr %roots, i64 128
  %v199 = getelementptr inbounds nuw i8, ptr %roots, i64 136
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 15, ptr %0, align 8
  store i64 0, ptr %v122, align 8
  %1 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %1, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %2 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %3 = add i64 %2, 1
  store i64 %3, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %4 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %5 = call noundef i64 @llvm.umax.i64(i64 %3, i64 %4)
  store i64 %5, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %arg0, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(72) %v6, i8 0, i64 72, i1 false)
  %6 = icmp ne i64 %arg0, 0
  %7 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %7, 0
  %or.cond = and i1 %6, %.not.i
  br i1 %or.cond, label %8, label %trap20

8:                                                ; preds = %entry
  %9 = inttoptr i64 %arg0 to ptr
  %10 = load i64, ptr %9, align 8, !noundef !39
  %11 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %12 = icmp eq ptr %11, null
  br i1 %12, label %25, label %13

13:                                               ; preds = %8
  switch i64 %10, label %14 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

14:                                               ; preds = %13
  %15 = getelementptr inbounds nuw i8, ptr %11, i64 360
  %16 = load i64, ptr %15, align 8, !noundef !39
  %17 = lshr i64 %10, 2
  %18 = add nsw i64 %17, -1
  %19 = icmp ult i64 %18, %16
  br i1 %19, label %20, label %.loopexit25

20:                                               ; preds = %14
  %21 = getelementptr inbounds nuw i8, ptr %11, i64 352
  %22 = load ptr, ptr %21, align 8, !nonnull !39, !noundef !39
  %23 = getelementptr inbounds nuw i64, ptr %22, i64 %18
  %24 = load i64, ptr %23, align 8, !noundef !39
  switch i64 %24, label %.preheader24 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

25:                                               ; preds = %8
  call fastcc void @native_trap() #113
  unreachable

.preheader24:                                     ; preds = %30, %20
  %26 = phi i64 [ %32, %30 ], [ %24, %20 ]
  %27 = lshr i64 %26, 2
  %28 = add nsw i64 %27, -1
  %29 = icmp ult i64 %28, %16
  br i1 %29, label %30, label %.loopexit25

.loopexit25:                                      ; preds = %.preheader24, %14
  call fastcc void @native_trap() #113
  unreachable

30:                                               ; preds = %.preheader24
  %31 = getelementptr inbounds nuw i64, ptr %22, i64 %28
  %32 = load i64, ptr %31, align 8, !noundef !39
  switch i64 %32, label %.preheader24 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %30, %30, %20, %20, %13, %13
  %.in191 = phi i64 [ %10, %13 ], [ %24, %20 ], [ %24, %20 ], [ %10, %13 ], [ %32, %30 ], [ %32, %30 ]
  %33 = icmp eq i64 %.in191, 30
  br i1 %33, label %ok24, label %trap20

trap20:                                           ; preds = %native_ref_test.exit12, %ok481, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok24:                                             ; preds = %native_ref_test.exit12, %native_ref_test.exit
  %34 = phi i64 [ %239, %native_ref_test.exit12 ], [ %3, %native_ref_test.exit ]
  %35 = phi ptr [ %240, %native_ref_test.exit12 ], [ %1, %native_ref_test.exit ]
  %36 = phi ptr [ %248, %native_ref_test.exit12 ], [ %11, %native_ref_test.exit ]
  %37 = phi i64 [ %247, %native_ref_test.exit12 ], [ %10, %native_ref_test.exit ]
  %arg1.tr96 = phi i64 [ %v486, %native_ref_test.exit12 ], [ %arg1, %native_ref_test.exit ]
  %v36 = phi i64 [ %v484, %native_ref_test.exit12 ], [ %arg0, %native_ref_test.exit ]
  %v25 = inttoptr i64 %v36 to ptr
  %v26 = getelementptr i8, ptr %v25, i64 8
  %v27 = load i64, ptr %v26, align 1
  %v29 = icmp eq i64 %v27, %arg1.tr96
  br i1 %v29, label %then34, label %else33

then34:                                           ; preds = %ok24
  %.lcssa255 = phi i64 [ %34, %ok24 ]
  %.lcssa199 = phi ptr [ %35, %ok24 ]
  store ptr %.lcssa199, ptr @native_roots.0, align 8
  %38 = add i64 %.lcssa255, -1
  store i64 %38, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  ret i32 0

else33:                                           ; preds = %ok24
  %39 = and i64 %v36, 1
  %.not.i1 = icmp eq i64 %39, 0
  br i1 %.not.i1, label %40, label %trap39

40:                                               ; preds = %else33
  switch i64 %37, label %41 [
    i64 30, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

41:                                               ; preds = %40
  %42 = getelementptr inbounds nuw i8, ptr %36, i64 360
  %43 = load i64, ptr %42, align 8, !noundef !39
  %44 = lshr i64 %37, 2
  %45 = add nsw i64 %44, -1
  %46 = icmp ult i64 %45, %43
  br i1 %46, label %47, label %.loopexit20

47:                                               ; preds = %41
  %48 = getelementptr inbounds nuw i8, ptr %36, i64 352
  %49 = load ptr, ptr %48, align 8, !nonnull !39, !noundef !39
  %50 = getelementptr inbounds nuw i64, ptr %49, i64 %45
  %51 = load i64, ptr %50, align 8, !noundef !39
  switch i64 %51, label %.preheader19 [
    i64 30, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader19:                                     ; preds = %56, %47
  %52 = phi i64 [ %58, %56 ], [ %51, %47 ]
  %53 = lshr i64 %52, 2
  %54 = add nsw i64 %53, -1
  %55 = icmp ult i64 %54, %43
  br i1 %55, label %56, label %.loopexit20

.loopexit20:                                      ; preds = %.preheader19, %41
  call fastcc void @native_trap() #113
  unreachable

56:                                               ; preds = %.preheader19
  %57 = getelementptr inbounds nuw i64, ptr %49, i64 %54
  %58 = load i64, ptr %57, align 8, !noundef !39
  switch i64 %58, label %.preheader19 [
    i64 30, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

native_ref_test.exit2:                            ; preds = %56, %56, %47, %47, %40, %40
  %.in192 = phi i64 [ %37, %40 ], [ %51, %47 ], [ %51, %47 ], [ %37, %40 ], [ %58, %56 ], [ %58, %56 ]
  %59 = icmp eq i64 %.in192, 30
  br i1 %59, label %ok40, label %trap39

trap39:                                           ; preds = %native_ref_test.exit2, %else33
  call fastcc void @native_trap()
  unreachable

ok40:                                             ; preds = %native_ref_test.exit2
  store i64 %v36, ptr %v6, align 8
  %v45 = getelementptr i8, ptr %v25, i64 16
  %v46 = load i64, ptr %v45, align 1
  %v52 = getelementptr i8, ptr %v25, i64 24
  %v53 = load i64, ptr %v52, align 1
  %v54.not = icmp eq i64 %v53, 0
  br i1 %v54.not, label %trap55, label %ok56

trap55:                                           ; preds = %ok40
  call fastcc void @native_trap()
  unreachable

ok56:                                             ; preds = %ok40
  %v57 = inttoptr i64 %v53 to ptr
  %v58 = getelementptr i8, ptr %v57, i64 8
  %v59 = load i32, ptr %v58, align 1
  %v60 = icmp eq i32 %v59, 0
  br i1 %v60, label %then64, label %ok75

then64:                                           ; preds = %ok56
  call fastcc void @native_trap()
  unreachable

ok75:                                             ; preds = %ok56
  %v77 = getelementptr i8, ptr %v57, i64 16
  %v78 = load i64, ptr %v77, align 1
  %v79.not = icmp eq i64 %v78, 0
  br i1 %v79.not, label %trap80, label %ok81

trap80:                                           ; preds = %ok75
  call fastcc void @native_trap()
  unreachable

ok81:                                             ; preds = %ok75
  %v82 = inttoptr i64 %v78 to ptr
  %v83 = getelementptr i8, ptr %v82, i64 16
  %v84 = load i64, ptr %v83, align 1
  %60 = icmp ne i64 %v84, 0
  %61 = and i64 %v84, 1
  %.not.i3 = icmp eq i64 %61, 0
  %or.cond157 = and i1 %60, %.not.i3
  br i1 %or.cond157, label %62, label %trap87

62:                                               ; preds = %ok81
  %63 = inttoptr i64 %v84 to ptr
  %64 = load i64, ptr %63, align 8, !noundef !39
  switch i64 %64, label %65 [
    i64 74, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

65:                                               ; preds = %62
  %66 = getelementptr inbounds nuw i8, ptr %36, i64 360
  %67 = load i64, ptr %66, align 8, !noundef !39
  %68 = lshr i64 %64, 2
  %69 = add nsw i64 %68, -1
  %70 = icmp ult i64 %69, %67
  br i1 %70, label %71, label %.loopexit18

71:                                               ; preds = %65
  %72 = getelementptr inbounds nuw i8, ptr %36, i64 352
  %73 = load ptr, ptr %72, align 8, !nonnull !39, !noundef !39
  %74 = getelementptr inbounds nuw i64, ptr %73, i64 %69
  %75 = load i64, ptr %74, align 8, !noundef !39
  switch i64 %75, label %.preheader17 [
    i64 74, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

.preheader17:                                     ; preds = %80, %71
  %76 = phi i64 [ %82, %80 ], [ %75, %71 ]
  %77 = lshr i64 %76, 2
  %78 = add nsw i64 %77, -1
  %79 = icmp ult i64 %78, %67
  br i1 %79, label %80, label %.loopexit18

.loopexit18:                                      ; preds = %.preheader17, %65
  call fastcc void @native_trap() #113
  unreachable

80:                                               ; preds = %.preheader17
  %81 = getelementptr inbounds nuw i64, ptr %73, i64 %78
  %82 = load i64, ptr %81, align 8, !noundef !39
  switch i64 %82, label %.preheader17 [
    i64 74, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

native_ref_test.exit4:                            ; preds = %80, %80, %71, %71, %62, %62
  %.in193 = phi i64 [ %64, %62 ], [ %75, %71 ], [ %75, %71 ], [ %64, %62 ], [ %82, %80 ], [ %82, %80 ]
  %83 = icmp eq i64 %.in193, 74
  br i1 %83, label %ok88, label %trap87

trap87:                                           ; preds = %native_ref_test.exit4, %ok81
  call fastcc void @native_trap()
  unreachable

ok88:                                             ; preds = %native_ref_test.exit4
  store i64 %v84, ptr %v11, align 8
  %v93 = getelementptr i8, ptr %63, i64 8
  %v94 = load i64, ptr %v93, align 1
  %v95.not = icmp eq i64 %v94, 0
  br i1 %v95.not, label %trap96, label %ok97

trap96:                                           ; preds = %ok88
  call fastcc void @native_trap()
  unreachable

ok97:                                             ; preds = %ok88
  %v98 = inttoptr i64 %v94 to ptr
  %v99 = getelementptr i8, ptr %v98, i64 8
  %v100 = load i64, ptr %v99, align 1
  store i64 %v100, ptr %v12, align 8
  %v101.not = icmp eq i64 %v100, 0
  br i1 %v101.not, label %trap102, label %ok103

trap102:                                          ; preds = %ok97
  call fastcc void @native_trap()
  unreachable

ok103:                                            ; preds = %ok97
  %v104 = inttoptr i64 %v100 to ptr
  %v113 = getelementptr i8, ptr %v104, i64 8
  %v114 = load i64, ptr %v113, align 1
  %v115.not = icmp eq i64 %v114, 0
  br i1 %v115.not, label %trap116, label %ok117

trap116:                                          ; preds = %ok103
  call fastcc void @native_trap()
  unreachable

ok117:                                            ; preds = %ok103
  %v105 = getelementptr i8, ptr %v104, i64 16
  %v106 = load i64, ptr %v105, align 1
  %v118 = inttoptr i64 %v114 to ptr
  %v119 = getelementptr i8, ptr %v118, i64 8
  %v120 = load ptr, ptr %v119, align 1
  store i64 %v106, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %v123 = call tailcc i64 %v120(i64 %v106, i64 %v46)
  %v124.b = load i1, ptr @g.4, align 1
  br i1 %v124.b, label %block127, label %then129

then129:                                          ; preds = %ok117
  call fastcc void @native_trap()
  unreachable

block127:                                         ; preds = %ok117
  %v131 = load i64, ptr @g.3, align 8
  %v132.not = icmp eq i64 %v131, 0
  br i1 %v132.not, label %trap133, label %ok134

trap133:                                          ; preds = %block127
  call fastcc void @native_trap()
  unreachable

ok134:                                            ; preds = %block127
  %v139 = icmp ugt i64 %v123, 4294967295
  br i1 %v139, label %then143, label %block141

then143:                                          ; preds = %ok134
  call fastcc void @native_trap()
  unreachable

block141:                                         ; preds = %ok134
  store i64 10, ptr %v122, align 8
  %84 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %85 = icmp eq ptr %84, null
  br i1 %85, label %86, label %87

86:                                               ; preds = %block141
  call fastcc void @native_trap() #113
  unreachable

87:                                               ; preds = %block141
  %88 = getelementptr inbounds nuw i8, ptr %84, i64 376
  %89 = load i64, ptr %88, align 8, !noundef !39
  %90 = icmp eq i64 %89, 0
  br i1 %90, label %91, label %95

91:                                               ; preds = %101, %95, %87
  %92 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %93 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %84, i64 noundef 24, ptr noundef %92) #84
  %94 = icmp eq ptr %93, null
  br i1 %94, label %103, label %ok149

95:                                               ; preds = %87
  %96 = getelementptr inbounds nuw i8, ptr %84, i64 368
  %97 = load i64, ptr %96, align 8, !noundef !39
  %98 = add i64 %97, 1
  store i64 %98, ptr %96, align 8
  %99 = urem i64 %98, %89
  %100 = icmp eq i64 %99, 0
  br i1 %100, label %101, label %91

101:                                              ; preds = %95
  %102 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %84, ptr noundef %102) #84
  br label %91

103:                                              ; preds = %91
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok149:                                            ; preds = %91
  %104 = ptrtoint ptr %93 to i64
  store i64 102, ptr %93, align 1
  %v156 = getelementptr i8, ptr %93, i64 8
  store i32 0, ptr %v156, align 1
  %v161 = getelementptr i8, ptr %93, i64 16
  store i64 0, ptr %v161, align 1
  store i64 %104, ptr %v7, align 8
  %v162 = load i64, ptr %v11, align 8
  %v163.not = icmp eq i64 %v162, 0
  br i1 %v163.not, label %trap164, label %ok165

trap164:                                          ; preds = %ok149
  call fastcc void @native_trap()
  unreachable

ok165:                                            ; preds = %ok149
  %v166 = inttoptr i64 %v162 to ptr
  %v167 = getelementptr i8, ptr %v166, i64 8
  %v168 = load i64, ptr %v167, align 1
  %v171 = trunc nuw i64 %v123 to i32
  store i64 %v168, ptr %v121, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v173, align 8
  store i64 %104, ptr %v174, align 8
  store i64 13, ptr %v122, align 8
  %v177 = call fastcc i64 @native_array_new(i32 %v171)
  store i64 %v177, ptr %v121, align 8
  store i64 %v168, ptr %v173, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v174, align 8
  store i64 %104, ptr %v181, align 8
  store i64 14, ptr %v122, align 8
  %105 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %106 = icmp eq ptr %105, null
  br i1 %106, label %107, label %108

107:                                              ; preds = %ok165
  call fastcc void @native_trap() #113
  unreachable

108:                                              ; preds = %ok165
  %109 = getelementptr inbounds nuw i8, ptr %105, i64 376
  %110 = load i64, ptr %109, align 8, !noundef !39
  %111 = icmp eq i64 %110, 0
  br i1 %111, label %112, label %116

112:                                              ; preds = %122, %116, %108
  %113 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %114 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %105, i64 noundef 16, ptr noundef %113) #84
  %115 = icmp eq ptr %114, null
  br i1 %115, label %124, label %ok186

116:                                              ; preds = %108
  %117 = getelementptr inbounds nuw i8, ptr %105, i64 368
  %118 = load i64, ptr %117, align 8, !noundef !39
  %119 = add i64 %118, 1
  store i64 %119, ptr %117, align 8
  %120 = urem i64 %119, %110
  %121 = icmp eq i64 %120, 0
  br i1 %121, label %122, label %112

122:                                              ; preds = %116
  %123 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %105, ptr noundef %123) #84
  br label %112

124:                                              ; preds = %112
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok186:                                            ; preds = %112
  %125 = ptrtoint ptr %114 to i64
  store i64 130, ptr %114, align 1
  %v193 = getelementptr i8, ptr %114, i64 8
  store i64 %v177, ptr %v193, align 1
  %v194 = load i64, ptr %v7, align 8
  store i64 %v194, ptr %v121, align 8
  store i64 %125, ptr %v173, align 8
  store i64 %v168, ptr %v174, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v181, align 8
  store i64 %104, ptr %v199, align 8
  store i64 15, ptr %v122, align 8
  %126 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %127 = icmp eq ptr %126, null
  br i1 %127, label %128, label %129

128:                                              ; preds = %ok186
  call fastcc void @native_trap() #113
  unreachable

129:                                              ; preds = %ok186
  %130 = getelementptr inbounds nuw i8, ptr %126, i64 376
  %131 = load i64, ptr %130, align 8, !noundef !39
  %132 = icmp eq i64 %131, 0
  br i1 %132, label %133, label %137

133:                                              ; preds = %143, %137, %129
  %134 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %135 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %126, i64 noundef 40, ptr noundef %134) #84
  %136 = icmp eq ptr %135, null
  br i1 %136, label %145, label %ok204

137:                                              ; preds = %129
  %138 = getelementptr inbounds nuw i8, ptr %126, i64 368
  %139 = load i64, ptr %138, align 8, !noundef !39
  %140 = add i64 %139, 1
  store i64 %140, ptr %138, align 8
  %141 = urem i64 %140, %131
  %142 = icmp eq i64 %141, 0
  br i1 %142, label %143, label %133

143:                                              ; preds = %137
  %144 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %126, ptr noundef %144) #84
  br label %133

145:                                              ; preds = %133
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok204:                                            ; preds = %133
  %146 = ptrtoint ptr %135 to i64
  store i64 42, ptr %135, align 1
  %v211 = getelementptr i8, ptr %135, i64 8
  store i64 %v168, ptr %v211, align 1
  %v216 = getelementptr i8, ptr %135, i64 16
  store i64 %v123, ptr %v216, align 1
  %v221 = getelementptr i8, ptr %135, i64 24
  store i64 %125, ptr %v221, align 1
  %v226 = getelementptr i8, ptr %135, i64 32
  store i64 %v194, ptr %v226, align 1
  store i64 %146, ptr %v121, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v173, align 8
  store i64 %104, ptr %v174, align 8
  store i64 13, ptr %v122, align 8
  %147 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %148 = icmp eq ptr %147, null
  br i1 %148, label %149, label %150

149:                                              ; preds = %ok204
  call fastcc void @native_trap() #113
  unreachable

150:                                              ; preds = %ok204
  %151 = getelementptr inbounds nuw i8, ptr %147, i64 376
  %152 = load i64, ptr %151, align 8, !noundef !39
  %153 = icmp eq i64 %152, 0
  br i1 %153, label %154, label %158

154:                                              ; preds = %164, %158, %150
  %155 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %156 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %147, i64 noundef 24, ptr noundef %155) #84
  %157 = icmp eq ptr %156, null
  br i1 %157, label %166, label %ok234

158:                                              ; preds = %150
  %159 = getelementptr inbounds nuw i8, ptr %147, i64 368
  %160 = load i64, ptr %159, align 8, !noundef !39
  %161 = add i64 %160, 1
  store i64 %161, ptr %159, align 8
  %162 = urem i64 %161, %152
  %163 = icmp eq i64 %162, 0
  br i1 %163, label %164, label %154

164:                                              ; preds = %158
  %165 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %147, ptr noundef %165) #84
  br label %154

166:                                              ; preds = %154
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok234:                                            ; preds = %154
  %167 = ptrtoint ptr %156 to i64
  store i64 194, ptr %156, align 1
  %v241 = getelementptr i8, ptr %156, i64 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v241, align 1
  %v246 = getelementptr i8, ptr %156, i64 16
  store i64 %146, ptr %v246, align 1
  store i64 %167, ptr %v161, align 1
  %v252 = load i64, ptr %v7, align 8
  %v253.not = icmp eq i64 %v252, 0
  br i1 %v253.not, label %trap254, label %ok255

trap254:                                          ; preds = %ok234
  call fastcc void @native_trap()
  unreachable

ok255:                                            ; preds = %ok234
  %v256 = inttoptr i64 %v252 to ptr
  %v257 = getelementptr i8, ptr %v256, i64 8
  store i32 1, ptr %v257, align 1
  %v258 = load i64, ptr %v7, align 8
  %v259.not = icmp eq i64 %v258, 0
  br i1 %v259.not, label %trap260, label %ok261

trap260:                                          ; preds = %ok255
  call fastcc void @native_trap()
  unreachable

ok261:                                            ; preds = %ok255
  %v262 = inttoptr i64 %v258 to ptr
  %v263 = getelementptr i8, ptr %v262, i64 8
  %v264 = load i32, ptr %v263, align 1
  %v265 = icmp eq i32 %v264, 0
  br i1 %v265, label %then269, label %ok274

then269:                                          ; preds = %ok261
  call fastcc void @native_trap()
  unreachable

ok274:                                            ; preds = %ok261
  %v276 = getelementptr i8, ptr %v262, i64 16
  %v277 = load i64, ptr %v276, align 1
  %v278.not = icmp eq i64 %v277, 0
  br i1 %v278.not, label %trap279, label %ok280

trap279:                                          ; preds = %ok274
  call fastcc void @native_trap()
  unreachable

ok280:                                            ; preds = %ok274
  store i64 %v277, ptr %v13, align 8
  %v284 = inttoptr i64 %v277 to ptr
  %v292 = getelementptr i8, ptr %v284, i64 8
  %v293 = load i64, ptr %v292, align 1
  %v294.not = icmp eq i64 %v293, 0
  br i1 %v294.not, label %trap295, label %ok296

trap295:                                          ; preds = %ok280
  call fastcc void @native_trap()
  unreachable

ok296:                                            ; preds = %ok280
  %v285 = getelementptr i8, ptr %v284, i64 16
  %v286 = load i64, ptr %v285, align 1
  %v297 = inttoptr i64 %v293 to ptr
  %v298 = getelementptr i8, ptr %v297, i64 8
  %v299 = load ptr, ptr %v298, align 1
  store i64 %v286, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %v302 = call tailcc i64 %v299(i64 %v286, i64 0)
  store i64 %v302, ptr %v9, align 8
  %v303.b = load i1, ptr @g.6, align 1
  br i1 %v303.b, label %block306, label %then308

then308:                                          ; preds = %ok296
  call fastcc void @native_trap()
  unreachable

block306:                                         ; preds = %ok296
  %v310 = load i64, ptr @g.5, align 8
  %v311.not = icmp eq i64 %v310, 0
  br i1 %v311.not, label %trap312, label %ok313

trap312:                                          ; preds = %block306
  call fastcc void @native_trap()
  unreachable

ok313:                                            ; preds = %block306
  %v314.b = load i1, ptr @g.8, align 1
  br i1 %v314.b, label %block317, label %then319

then319:                                          ; preds = %ok313
  call fastcc void @native_trap()
  unreachable

block317:                                         ; preds = %ok313
  %v321 = load i64, ptr @g.7, align 8
  %v322.not = icmp eq i64 %v321, 0
  br i1 %v322.not, label %trap323, label %ok324

trap323:                                          ; preds = %block317
  call fastcc void @native_trap()
  unreachable

ok324:                                            ; preds = %block317
  %v327.not = icmp eq i64 %v302, 0
  br i1 %v327.not, label %trap328, label %ok329

trap328:                                          ; preds = %ok324
  call fastcc void @native_trap()
  unreachable

ok329:                                            ; preds = %ok324
  %v330 = inttoptr i64 %v302 to ptr
  %v331 = getelementptr i8, ptr %v330, i64 8
  %v332 = load i64, ptr %v331, align 1
  %v333.not = icmp eq i64 %v332, 0
  br i1 %v333.not, label %trap334, label %ok335

trap334:                                          ; preds = %ok329
  call fastcc void @native_trap()
  unreachable

ok335:                                            ; preds = %ok329
  %v336 = and i64 %v332, 1
  %v337 = icmp eq i64 %v336, 0
  br i1 %v337, label %ok339, label %trap338

trap338:                                          ; preds = %ok335
  call fastcc void @native_trap()
  unreachable

ok339:                                            ; preds = %ok335
  %v340 = inttoptr i64 %v332 to ptr
  %v341 = getelementptr i8, ptr %v340, i64 8
  %v342 = load i64, ptr %v341, align 1
  %v344 = and i64 %v342, 4294967295
  store i64 %v302, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %v347 = call tailcc i64 @f.5(i64 %v302, i64 %v344)
  store i64 %v347, ptr %v8, align 8
  store i64 %v347, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %168 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %169 = icmp eq ptr %168, null
  br i1 %169, label %170, label %171

170:                                              ; preds = %ok339
  call fastcc void @native_trap() #113
  unreachable

171:                                              ; preds = %ok339
  %172 = getelementptr inbounds nuw i8, ptr %168, i64 376
  %173 = load i64, ptr %172, align 8, !noundef !39
  %174 = icmp eq i64 %173, 0
  br i1 %174, label %175, label %179

175:                                              ; preds = %185, %179, %171
  %176 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %177 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %168, i64 noundef 16, ptr noundef %176) #84
  %178 = icmp eq ptr %177, null
  br i1 %178, label %187, label %ok353

179:                                              ; preds = %171
  %180 = getelementptr inbounds nuw i8, ptr %168, i64 368
  %181 = load i64, ptr %180, align 8, !noundef !39
  %182 = add i64 %181, 1
  store i64 %182, ptr %180, align 8
  %183 = urem i64 %182, %173
  %184 = icmp eq i64 %183, 0
  br i1 %184, label %185, label %175

185:                                              ; preds = %179
  %186 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %168, ptr noundef %186) #84
  br label %175

187:                                              ; preds = %175
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok353:                                            ; preds = %175
  %188 = ptrtoint ptr %177 to i64
  store i64 34, ptr %177, align 1
  %v360 = getelementptr i8, ptr %177, i64 8
  store i64 %v347, ptr %v360, align 1
  %v363 = load i64, ptr %v8, align 8
  %v364.not = icmp eq i64 %v363, 0
  br i1 %v364.not, label %trap365, label %block374

trap365:                                          ; preds = %ok353
  call fastcc void @native_trap()
  unreachable

block374:                                         ; preds = %ok353
  %v367 = inttoptr i64 %v363 to ptr
  %v368 = getelementptr i8, ptr %v367, i64 8
  %v369 = load i32, ptr %v368, align 1
  store i64 %188, ptr %v121, align 8
  store i64 %v363, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  %v382 = call tailcc i32 @f.4(i64 %v363, i32 0)
  %v383 = load i64, ptr %v8, align 8
  store i64 %188, ptr %v121, align 8
  store i64 %v383, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  %v389 = call tailcc i32 @f.4(i64 %v383, i32 %v369)
  %v391 = sub i32 %v389, %v382
  store i64 %188, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %v395 = call fastcc i64 @native_array_new(i32 %v391)
  store i64 %v395, ptr %v14, align 8
  %v396 = load i64, ptr %v8, align 8
  %v397.not = icmp eq i64 %v396, 0
  br i1 %v397.not, label %trap398, label %ok399

trap398:                                          ; preds = %block374
  call fastcc void @native_trap()
  unreachable

ok399:                                            ; preds = %block374
  %v400 = inttoptr i64 %v396 to ptr
  %v401 = getelementptr i8, ptr %v400, i64 24
  %v402 = load i64, ptr %v401, align 1
  %189 = and i64 %v395, 1
  %190 = icmp eq i64 %189, 0
  br i1 %190, label %192, label %191

191:                                              ; preds = %ok399
  call fastcc void @native_trap() #113
  unreachable

192:                                              ; preds = %ok399
  %193 = inttoptr i64 %v395 to ptr
  %194 = icmp ne i64 %v402, 0
  %195 = and i64 %v402, 1
  %196 = icmp eq i64 %195, 0
  %197 = and i1 %194, %196
  br i1 %197, label %199, label %198

198:                                              ; preds = %192
  call fastcc void @native_trap() #113
  unreachable

199:                                              ; preds = %192
  %200 = inttoptr i64 %v402 to ptr
  %201 = zext i32 %v391 to i64
  %202 = getelementptr inbounds nuw i8, ptr %193, i64 8
  %203 = load i64, ptr %202, align 8, !noundef !39
  %204 = icmp ult i64 %203, %201
  br i1 %204, label %211, label %205

205:                                              ; preds = %199
  %206 = zext i32 %v382 to i64
  %207 = add nuw nsw i64 %201, %206
  %208 = getelementptr inbounds nuw i8, ptr %200, i64 8
  %209 = load i64, ptr %208, align 8, !noundef !39
  %210 = icmp ugt i64 %207, %209
  br i1 %210, label %211, label %native_array_copy.exit

211:                                              ; preds = %205, %199
  call fastcc void @native_trap() #113
  unreachable

native_array_copy.exit:                           ; preds = %205
  %212 = getelementptr inbounds nuw i8, ptr %200, i64 16
  %213 = getelementptr inbounds nuw i8, ptr %212, i64 %206
  %214 = getelementptr inbounds nuw i8, ptr %193, i64 16
  call void @llvm.memmove.p0.p0.i64(ptr nonnull align 1 %214, ptr nonnull align 1 %213, i64 %201, i1 false)
  %v405 = load i64, ptr %v14, align 8
  store i64 %v405, ptr %v121, align 8
  store i64 %188, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  %215 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %216 = icmp eq ptr %215, null
  br i1 %216, label %217, label %218

217:                                              ; preds = %native_array_copy.exit
  call fastcc void @native_trap() #113
  unreachable

218:                                              ; preds = %native_array_copy.exit
  %219 = getelementptr inbounds nuw i8, ptr %215, i64 376
  %220 = load i64, ptr %219, align 8, !noundef !39
  %221 = icmp eq i64 %220, 0
  br i1 %221, label %222, label %226

222:                                              ; preds = %232, %226, %218
  %223 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %224 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %215, i64 noundef 16, ptr noundef %223) #84
  %225 = icmp eq ptr %224, null
  br i1 %225, label %234, label %ok412

226:                                              ; preds = %218
  %227 = getelementptr inbounds nuw i8, ptr %215, i64 368
  %228 = load i64, ptr %227, align 8, !noundef !39
  %229 = add i64 %228, 1
  store i64 %229, ptr %227, align 8
  %230 = urem i64 %229, %220
  %231 = icmp eq i64 %230, 0
  br i1 %231, label %232, label %222

232:                                              ; preds = %226
  %233 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %215, ptr noundef %233) #84
  br label %222

234:                                              ; preds = %222
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok412:                                            ; preds = %222
  %235 = ptrtoint ptr %224 to i64
  store i64 130, ptr %224, align 1
  %v419 = getelementptr i8, ptr %224, i64 8
  store i64 %v405, ptr %v419, align 1
  store i64 %235, ptr %v10, align 8
  %v426 = load i64, ptr %v419, align 1
  %v427.not = icmp eq i64 %v426, 0
  br i1 %v427.not, label %trap428, label %ok429

trap428:                                          ; preds = %ok412
  call fastcc void @native_trap()
  unreachable

ok429:                                            ; preds = %ok412
  %v430 = and i64 %v426, 1
  %v431 = icmp eq i64 %v430, 0
  br i1 %v431, label %ok433, label %trap432

trap432:                                          ; preds = %ok429
  call fastcc void @native_trap()
  unreachable

ok433:                                            ; preds = %ok429
  %v434 = inttoptr i64 %v426 to ptr
  %v435 = getelementptr i8, ptr %v434, i64 8
  %v436 = load i64, ptr %v435, align 1
  %v438 = and i64 %v436, 4294967295
  store i64 %188, ptr %v121, align 8
  store i64 %235, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  %v442 = call tailcc i64 @f.5(i64 %235, i64 %v438)
  store i64 %188, ptr %v121, align 8
  store i64 %v442, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  call tailcc void @f.11(i64 %188, i64 %v442)
  %v447 = load i64, ptr %v6, align 8
  %v448.not = icmp eq i64 %v447, 0
  br i1 %v448.not, label %trap449, label %ok450

trap449:                                          ; preds = %ok433
  call fastcc void @native_trap()
  unreachable

ok450:                                            ; preds = %ok433
  %v451 = inttoptr i64 %v447 to ptr
  %v452 = getelementptr i8, ptr %v451, i64 32
  %v453 = load i64, ptr %v452, align 1
  %v454.not = icmp eq i64 %v453, 0
  br i1 %v454.not, label %trap455, label %ok456

trap455:                                          ; preds = %ok450
  call fastcc void @native_trap()
  unreachable

ok456:                                            ; preds = %ok450
  %v457 = inttoptr i64 %v453 to ptr
  %v458 = getelementptr i8, ptr %v457, i64 8
  %v459 = load i32, ptr %v458, align 1
  %v460 = icmp eq i32 %v459, 0
  br i1 %v460, label %then464, label %ok475

then464:                                          ; preds = %ok456
  call fastcc void @native_trap()
  unreachable

ok475:                                            ; preds = %ok456
  %v477 = getelementptr i8, ptr %v457, i64 16
  %v478 = load i64, ptr %v477, align 1
  %v479.not = icmp eq i64 %v478, 0
  br i1 %v479.not, label %trap480, label %ok481

trap480:                                          ; preds = %ok475
  call fastcc void @native_trap()
  unreachable

ok481:                                            ; preds = %ok475
  %v482 = inttoptr i64 %v478 to ptr
  %v483 = getelementptr i8, ptr %v482, i64 16
  %v484 = load i64, ptr %v483, align 1
  %v486 = add i64 %arg1.tr96, 1
  %236 = load i64, ptr %0, align 8, !noundef !39
  %237 = icmp eq i64 %236, 0
  %.pre29 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %238 = zext i1 %237 to i64
  %239 = add i64 %.pre29, %238
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %240 = select i1 %237, ptr %native_roots.0.val, ptr %roots.val
  store i64 15, ptr %0, align 8
  store i64 0, ptr %v122, align 8
  store ptr %240, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %239, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %241 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %242 = call noundef i64 @llvm.umax.i64(i64 %239, i64 %241)
  store i64 %242, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v484, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(72) %v6, i8 0, i64 72, i1 false)
  %243 = icmp ne i64 %v484, 0
  %244 = and i64 %v484, 1
  %.not.i11 = icmp eq i64 %244, 0
  %or.cond158 = and i1 %243, %.not.i11
  br i1 %or.cond158, label %245, label %trap20

245:                                              ; preds = %ok481
  %246 = inttoptr i64 %v484 to ptr
  %247 = load i64, ptr %246, align 8, !noundef !39
  %248 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %249 = icmp eq ptr %248, null
  br i1 %249, label %262, label %250

250:                                              ; preds = %245
  switch i64 %247, label %251 [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

251:                                              ; preds = %250
  %252 = getelementptr inbounds nuw i8, ptr %248, i64 360
  %253 = load i64, ptr %252, align 8, !noundef !39
  %254 = lshr i64 %247, 2
  %255 = add nsw i64 %254, -1
  %256 = icmp ult i64 %255, %253
  br i1 %256, label %257, label %.loopexit

257:                                              ; preds = %251
  %258 = getelementptr inbounds nuw i8, ptr %248, i64 352
  %259 = load ptr, ptr %258, align 8, !nonnull !39, !noundef !39
  %260 = getelementptr inbounds nuw i64, ptr %259, i64 %255
  %261 = load i64, ptr %260, align 8, !noundef !39
  switch i64 %261, label %.preheader [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

262:                                              ; preds = %245
  call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %267, %257
  %263 = phi i64 [ %269, %267 ], [ %261, %257 ]
  %264 = lshr i64 %263, 2
  %265 = add nsw i64 %264, -1
  %266 = icmp ult i64 %265, %253
  br i1 %266, label %267, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %251
  call fastcc void @native_trap() #113
  unreachable

267:                                              ; preds = %.preheader
  %268 = getelementptr inbounds nuw i64, ptr %259, i64 %265
  %269 = load i64, ptr %268, align 8, !noundef !39
  switch i64 %269, label %.preheader [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

native_ref_test.exit12:                           ; preds = %267, %267, %257, %257, %250, %250
  %.in = phi i64 [ %247, %250 ], [ %261, %257 ], [ %261, %257 ], [ %247, %250 ], [ %269, %267 ], [ %269, %267 ]
  %270 = icmp eq i64 %.in, 30
  br i1 %270, label %ok24, label %trap20
}
