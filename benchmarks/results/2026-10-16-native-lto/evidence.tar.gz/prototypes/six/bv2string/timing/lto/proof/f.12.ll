define internal tailcc i64 @f.12(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [10 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 10, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %v3, i8 0, i64 32, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap12

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %15
  call fastcc void @native_trap() #113
  unreachable

31:                                               ; preds = %.preheader
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in, 74
  br i1 %34, label %ok13, label %trap12

trap12:                                           ; preds = %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok13:                                             ; preds = %native_ref_test.exit
  store i64 %arg0, ptr %v4, align 8
  %v18 = getelementptr i8, ptr %10, i64 8
  %v19 = load i64, ptr %v18, align 1
  %v20.not = icmp eq i64 %v19, 0
  br i1 %v20.not, label %trap21, label %ok22

trap21:                                           ; preds = %ok13
  call fastcc void @native_trap()
  unreachable

ok22:                                             ; preds = %ok13
  %v23 = inttoptr i64 %v19 to ptr
  %v24 = getelementptr i8, ptr %v23, i64 8
  %v25 = load i64, ptr %v24, align 1
  store i64 %v25, ptr %v5, align 8
  %v26.not = icmp eq i64 %v25, 0
  br i1 %v26.not, label %trap27, label %ok28

trap27:                                           ; preds = %ok22
  call fastcc void @native_trap()
  unreachable

ok28:                                             ; preds = %ok22
  %v29 = inttoptr i64 %v25 to ptr
  %v38 = getelementptr i8, ptr %v29, i64 8
  %v39 = load i64, ptr %v38, align 1
  %v40.not = icmp eq i64 %v39, 0
  br i1 %v40.not, label %trap41, label %ok42

trap41:                                           ; preds = %ok28
  call fastcc void @native_trap()
  unreachable

ok42:                                             ; preds = %ok28
  %v30 = getelementptr i8, ptr %v29, i64 16
  %v31 = load i64, ptr %v30, align 1
  %v43 = inttoptr i64 %v39 to ptr
  %v44 = getelementptr i8, ptr %v43, i64 8
  %v45 = load ptr, ptr %v44, align 1
  %v46 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %v31, ptr %v46, align 8
  store i64 6, ptr %1, align 8
  %v48 = call tailcc i64 %v45(i64 %v31, i64 %arg1)
  %v49.b = load i1, ptr @g.4, align 1
  br i1 %v49.b, label %block52, label %then54

then54:                                           ; preds = %ok42
  call fastcc void @native_trap()
  unreachable

block52:                                          ; preds = %ok42
  %v56 = load i64, ptr @g.3, align 8
  %v57.not = icmp eq i64 %v56, 0
  br i1 %v57.not, label %trap58, label %ok59

trap58:                                           ; preds = %block52
  call fastcc void @native_trap()
  unreachable

ok59:                                             ; preds = %block52
  %v64 = icmp ugt i64 %v48, 4294967295
  br i1 %v64, label %then68, label %block66

then68:                                           ; preds = %ok59
  call fastcc void @native_trap()
  unreachable

block66:                                          ; preds = %ok59
  store i64 5, ptr %1, align 8
  %35 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %36 = icmp eq ptr %35, null
  br i1 %36, label %37, label %38

37:                                               ; preds = %block66
  call fastcc void @native_trap() #113
  unreachable

38:                                               ; preds = %block66
  %39 = getelementptr inbounds nuw i8, ptr %35, i64 376
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = icmp eq i64 %40, 0
  br i1 %41, label %42, label %46

42:                                               ; preds = %52, %46, %38
  %43 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %44 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %35, i64 noundef 24, ptr noundef %43) #84
  %45 = icmp eq ptr %44, null
  br i1 %45, label %54, label %ok74

46:                                               ; preds = %38
  %47 = getelementptr inbounds nuw i8, ptr %35, i64 368
  %48 = load i64, ptr %47, align 8, !noundef !39
  %49 = add i64 %48, 1
  store i64 %49, ptr %47, align 8
  %50 = urem i64 %49, %40
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %52, label %42

52:                                               ; preds = %46
  %53 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %35, ptr noundef %53) #84
  br label %42

54:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok74:                                             ; preds = %42
  %55 = ptrtoint ptr %44 to i64
  store i64 102, ptr %44, align 1
  %v81 = getelementptr i8, ptr %44, i64 8
  store i32 0, ptr %v81, align 1
  %v86 = getelementptr i8, ptr %44, i64 16
  store i64 0, ptr %v86, align 1
  store i64 %55, ptr %v3, align 8
  %v87 = load i64, ptr %v4, align 8
  %v88.not = icmp eq i64 %v87, 0
  br i1 %v88.not, label %trap89, label %ok90

trap89:                                           ; preds = %ok74
  call fastcc void @native_trap()
  unreachable

ok90:                                             ; preds = %ok74
  %v91 = inttoptr i64 %v87 to ptr
  %v92 = getelementptr i8, ptr %v91, i64 8
  %v93 = load i64, ptr %v92, align 1
  %v96 = trunc nuw i64 %v48 to i32
  store i64 %v93, ptr %v46, align 8
  %v98 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v98, align 8
  %v99 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  store i64 %55, ptr %v99, align 8
  store i64 8, ptr %1, align 8
  %v102 = call fastcc i64 @native_array_new(i32 %v96)
  store i64 %v102, ptr %v46, align 8
  store i64 %v93, ptr %v98, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v99, align 8
  %v106 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  store i64 %55, ptr %v106, align 8
  store i64 9, ptr %1, align 8
  %56 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %57 = icmp eq ptr %56, null
  br i1 %57, label %58, label %59

58:                                               ; preds = %ok90
  call fastcc void @native_trap() #113
  unreachable

59:                                               ; preds = %ok90
  %60 = getelementptr inbounds nuw i8, ptr %56, i64 376
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = icmp eq i64 %61, 0
  br i1 %62, label %63, label %67

63:                                               ; preds = %73, %67, %59
  %64 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %65 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %56, i64 noundef 16, ptr noundef %64) #84
  %66 = icmp eq ptr %65, null
  br i1 %66, label %75, label %ok111

67:                                               ; preds = %59
  %68 = getelementptr inbounds nuw i8, ptr %56, i64 368
  %69 = load i64, ptr %68, align 8, !noundef !39
  %70 = add i64 %69, 1
  store i64 %70, ptr %68, align 8
  %71 = urem i64 %70, %61
  %72 = icmp eq i64 %71, 0
  br i1 %72, label %73, label %63

73:                                               ; preds = %67
  %74 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %56, ptr noundef %74) #84
  br label %63

75:                                               ; preds = %63
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok111:                                            ; preds = %63
  %76 = ptrtoint ptr %65 to i64
  store i64 130, ptr %65, align 1
  %v118 = getelementptr i8, ptr %65, i64 8
  store i64 %v102, ptr %v118, align 1
  %v119 = load i64, ptr %v3, align 8
  store i64 %v119, ptr %v46, align 8
  store i64 %76, ptr %v98, align 8
  store i64 %v93, ptr %v99, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v106, align 8
  %v124 = getelementptr inbounds nuw i8, ptr %roots, i64 96
  store i64 %55, ptr %v124, align 8
  store i64 10, ptr %1, align 8
  %77 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %78 = icmp eq ptr %77, null
  br i1 %78, label %79, label %80

79:                                               ; preds = %ok111
  call fastcc void @native_trap() #113
  unreachable

80:                                               ; preds = %ok111
  %81 = getelementptr inbounds nuw i8, ptr %77, i64 376
  %82 = load i64, ptr %81, align 8, !noundef !39
  %83 = icmp eq i64 %82, 0
  br i1 %83, label %84, label %88

84:                                               ; preds = %94, %88, %80
  %85 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %86 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %77, i64 noundef 40, ptr noundef %85) #84
  %87 = icmp eq ptr %86, null
  br i1 %87, label %96, label %ok129

88:                                               ; preds = %80
  %89 = getelementptr inbounds nuw i8, ptr %77, i64 368
  %90 = load i64, ptr %89, align 8, !noundef !39
  %91 = add i64 %90, 1
  store i64 %91, ptr %89, align 8
  %92 = urem i64 %91, %82
  %93 = icmp eq i64 %92, 0
  br i1 %93, label %94, label %84

94:                                               ; preds = %88
  %95 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %77, ptr noundef %95) #84
  br label %84

96:                                               ; preds = %84
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok129:                                            ; preds = %84
  %97 = ptrtoint ptr %86 to i64
  store i64 42, ptr %86, align 1
  %v136 = getelementptr i8, ptr %86, i64 8
  store i64 %v93, ptr %v136, align 1
  %v141 = getelementptr i8, ptr %86, i64 16
  store i64 %v48, ptr %v141, align 1
  %v146 = getelementptr i8, ptr %86, i64 24
  store i64 %76, ptr %v146, align 1
  %v151 = getelementptr i8, ptr %86, i64 32
  store i64 %v119, ptr %v151, align 1
  store i64 %97, ptr %v46, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v98, align 8
  store i64 %55, ptr %v99, align 8
  store i64 8, ptr %1, align 8
  %98 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %99 = icmp eq ptr %98, null
  br i1 %99, label %100, label %101

100:                                              ; preds = %ok129
  call fastcc void @native_trap() #113
  unreachable

101:                                              ; preds = %ok129
  %102 = getelementptr inbounds nuw i8, ptr %98, i64 376
  %103 = load i64, ptr %102, align 8, !noundef !39
  %104 = icmp eq i64 %103, 0
  br i1 %104, label %105, label %109

105:                                              ; preds = %115, %109, %101
  %106 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %107 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %98, i64 noundef 24, ptr noundef %106) #84
  %108 = icmp eq ptr %107, null
  br i1 %108, label %117, label %ok159

109:                                              ; preds = %101
  %110 = getelementptr inbounds nuw i8, ptr %98, i64 368
  %111 = load i64, ptr %110, align 8, !noundef !39
  %112 = add i64 %111, 1
  store i64 %112, ptr %110, align 8
  %113 = urem i64 %112, %103
  %114 = icmp eq i64 %113, 0
  br i1 %114, label %115, label %105

115:                                              ; preds = %109
  %116 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %98, ptr noundef %116) #84
  br label %105

117:                                              ; preds = %105
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok159:                                            ; preds = %105
  %118 = ptrtoint ptr %107 to i64
  store i64 194, ptr %107, align 1
  %v166 = getelementptr i8, ptr %107, i64 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v166, align 1
  %v171 = getelementptr i8, ptr %107, i64 16
  store i64 %97, ptr %v171, align 1
  store i64 %118, ptr %v86, align 1
  %v177 = load i64, ptr %v3, align 8
  %v178.not = icmp eq i64 %v177, 0
  br i1 %v178.not, label %trap179, label %ok180

trap179:                                          ; preds = %ok159
  call fastcc void @native_trap()
  unreachable

ok180:                                            ; preds = %ok159
  %v181 = inttoptr i64 %v177 to ptr
  %v182 = getelementptr i8, ptr %v181, i64 8
  store i32 1, ptr %v182, align 1
  %v183 = load i64, ptr %v3, align 8
  %v184.not = icmp eq i64 %v183, 0
  br i1 %v184.not, label %trap185, label %ok186

trap185:                                          ; preds = %ok180
  call fastcc void @native_trap()
  unreachable

ok186:                                            ; preds = %ok180
  %v187 = inttoptr i64 %v183 to ptr
  %v188 = getelementptr i8, ptr %v187, i64 8
  %v189 = load i32, ptr %v188, align 1
  %v190 = icmp eq i32 %v189, 0
  br i1 %v190, label %then194, label %ok199

then194:                                          ; preds = %ok186
  call fastcc void @native_trap()
  unreachable

ok199:                                            ; preds = %ok186
  %v201 = getelementptr i8, ptr %v187, i64 16
  %v202 = load i64, ptr %v201, align 1
  %v203.not = icmp eq i64 %v202, 0
  br i1 %v203.not, label %trap204, label %ok205

trap204:                                          ; preds = %ok199
  call fastcc void @native_trap()
  unreachable

ok205:                                            ; preds = %ok199
  store i64 %v202, ptr %v6, align 8
  %v209 = inttoptr i64 %v202 to ptr
  %v217 = getelementptr i8, ptr %v209, i64 8
  %v218 = load i64, ptr %v217, align 1
  %v219.not = icmp eq i64 %v218, 0
  br i1 %v219.not, label %trap220, label %ok221

trap220:                                          ; preds = %ok205
  call fastcc void @native_trap()
  unreachable

ok221:                                            ; preds = %ok205
  %v210 = getelementptr i8, ptr %v209, i64 16
  %v211 = load i64, ptr %v210, align 1
  %v222 = inttoptr i64 %v218 to ptr
  %v223 = getelementptr i8, ptr %v222, i64 8
  %v224 = load ptr, ptr %v223, align 1
  %119 = load i64, ptr %0, align 8, !noundef !39
  %120 = icmp eq i64 %119, 0
  br i1 %120, label %native_roots_leave.exit, label %121

121:                                              ; preds = %ok221
  %122 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %122, ptr @native_roots.0, align 8
  %123 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %124 = add i64 %123, -1
  store i64 %124, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %121, %ok221
  %v225 = tail call tailcc i64 %v224(i64 %v211, i64 0)
  ret i64 %v225
}
