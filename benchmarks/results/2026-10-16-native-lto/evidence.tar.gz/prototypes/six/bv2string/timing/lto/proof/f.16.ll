define internal tailcc noundef range(i64 -1152921504606846976, 1152921504606846976) i64 @f.16(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  %0 = icmp ne i64 %arg0, 0
  %1 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %1, 0
  %or.cond = and i1 %0, %.not.i
  br i1 %or.cond, label %2, label %trap11

2:                                                ; preds = %entry
  %3 = inttoptr i64 %arg0 to ptr
  %4 = load i64, ptr %3, align 8, !noundef !39
  %5 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %6 = icmp eq ptr %5, null
  br i1 %6, label %21, label %7

7:                                                ; preds = %2
  %8 = icmp eq i64 %4, 62
  switch i64 %4, label %9 [
    i64 62, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

9:                                                ; preds = %7
  %10 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = lshr i64 %4, 2
  %13 = add nsw i64 %12, -1
  %14 = icmp ult i64 %13, %11
  br i1 %14, label %15, label %.loopexit7

15:                                               ; preds = %9
  %16 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %17 = load ptr, ptr %16, align 8, !nonnull !39, !noundef !39
  %18 = getelementptr inbounds nuw i64, ptr %17, i64 %13
  %19 = load i64, ptr %18, align 8, !noundef !39
  %20 = icmp eq i64 %19, 62
  switch i64 %19, label %.preheader6 [
    i64 62, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

21:                                               ; preds = %2
  tail call fastcc void @native_trap() #113
  unreachable

.preheader6:                                      ; preds = %26, %15
  %22 = phi i64 [ %28, %26 ], [ %19, %15 ]
  %23 = lshr i64 %22, 2
  %24 = add nsw i64 %23, -1
  %25 = icmp ult i64 %24, %11
  br i1 %25, label %26, label %.loopexit7

.loopexit7:                                       ; preds = %.preheader6, %9
  tail call fastcc void @native_trap() #113
  unreachable

26:                                               ; preds = %.preheader6
  %27 = getelementptr inbounds nuw i64, ptr %17, i64 %24
  %28 = load i64, ptr %27, align 8, !noundef !39
  switch i64 %28, label %.preheader6 [
    i64 62, label %native_ref_test.exit.loopexit
    i64 0, label %native_ref_test.exit.loopexit
  ]

native_ref_test.exit.loopexit:                    ; preds = %26, %26
  %.lcssa17 = phi i64 [ %28, %26 ], [ %28, %26 ]
  %29 = icmp eq i64 %.lcssa17, 62
  br i1 %29, label %ok15, label %trap11

native_ref_test.exit:                             ; preds = %15, %15, %7, %7
  %30 = phi i1 [ %8, %7 ], [ %20, %15 ], [ %20, %15 ], [ %8, %7 ]
  br i1 %30, label %ok15, label %trap11

trap11:                                           ; preds = %native_ref_test.exit, %native_ref_test.exit.loopexit, %entry
  tail call fastcc void @native_trap()
  unreachable

ok15:                                             ; preds = %native_ref_test.exit, %native_ref_test.exit.loopexit
  %v17 = getelementptr i8, ptr %3, i64 16
  %v18 = load i64, ptr %v17, align 1
  %v19.not = icmp eq i64 %v18, 0
  br i1 %v19.not, label %trap20, label %ok21

trap20:                                           ; preds = %ok15
  tail call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %ok15
  %v22 = inttoptr i64 %v18 to ptr
  %v23 = getelementptr i8, ptr %v22, i64 8
  %v24 = load i32, ptr %v23, align 1
  %v25 = icmp eq i32 %v24, 0
  br i1 %v25, label %then29, label %block27

then29:                                           ; preds = %ok21
  tail call fastcc void @native_trap()
  unreachable

block27:                                          ; preds = %ok21
  switch i64 %4, label %31 [
    i64 62, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

31:                                               ; preds = %block27
  %32 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %33 = load i64, ptr %32, align 8, !noundef !39
  %34 = lshr i64 %4, 2
  %35 = add nsw i64 %34, -1
  %36 = icmp ult i64 %35, %33
  br i1 %36, label %37, label %.loopexit

37:                                               ; preds = %31
  %38 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %39 = load ptr, ptr %38, align 8, !nonnull !39, !noundef !39
  %40 = getelementptr inbounds nuw i64, ptr %39, i64 %35
  %41 = load i64, ptr %40, align 8, !noundef !39
  %42 = icmp eq i64 %41, 62
  switch i64 %41, label %.preheader [
    i64 62, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader:                                       ; preds = %47, %37
  %43 = phi i64 [ %49, %47 ], [ %41, %37 ]
  %44 = lshr i64 %43, 2
  %45 = add nsw i64 %44, -1
  %46 = icmp ult i64 %45, %33
  br i1 %46, label %47, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %31
  tail call fastcc void @native_trap() #113
  unreachable

47:                                               ; preds = %.preheader
  %48 = getelementptr inbounds nuw i64, ptr %39, i64 %45
  %49 = load i64, ptr %48, align 8, !noundef !39
  switch i64 %49, label %.preheader [
    i64 62, label %native_ref_test.exit2.loopexit
    i64 0, label %native_ref_test.exit2.loopexit
  ]

native_ref_test.exit2.loopexit:                   ; preds = %47, %47
  %.lcssa18 = phi i64 [ %49, %47 ], [ %49, %47 ]
  %50 = icmp eq i64 %.lcssa18, 62
  br i1 %50, label %ok44, label %trap34

native_ref_test.exit2:                            ; preds = %37, %37, %block27, %block27
  %51 = phi i1 [ %8, %block27 ], [ %42, %37 ], [ %42, %37 ], [ %8, %block27 ]
  br i1 %51, label %ok44, label %trap34

trap34:                                           ; preds = %native_ref_test.exit2, %native_ref_test.exit2.loopexit
  tail call fastcc void @native_trap()
  unreachable

ok44:                                             ; preds = %native_ref_test.exit2, %native_ref_test.exit2.loopexit
  %v46 = getelementptr i8, ptr %v22, i64 16
  %v47 = load i64, ptr %v46, align 1
  %v48.not = icmp eq i64 %v47, 0
  br i1 %v48.not, label %trap49, label %ok56

trap49:                                           ; preds = %ok44
  tail call fastcc void @native_trap()
  unreachable

ok56:                                             ; preds = %ok44
  %v58 = getelementptr i8, ptr %3, i64 8
  %v59 = load i64, ptr %v58, align 1
  %v60.not = icmp eq i64 %v59, 0
  br i1 %v60.not, label %trap61, label %ok62

trap61:                                           ; preds = %ok56
  tail call fastcc void @native_trap()
  unreachable

ok62:                                             ; preds = %ok56
  %v63 = inttoptr i64 %v59 to ptr
  %v64 = getelementptr i8, ptr %v63, i64 8
  %v65 = load i32, ptr %v64, align 1
  %v66 = icmp eq i32 %v65, 0
  br i1 %v66, label %then70, label %ok106

then70:                                           ; preds = %ok62
  tail call fastcc void @native_trap()
  unreachable

ok106:                                            ; preds = %ok62
  %v107 = inttoptr i64 %v47 to ptr
  %v108 = getelementptr i8, ptr %v107, i64 8
  %v109 = load i64, ptr %v108, align 1
  %v117 = getelementptr i8, ptr %3, i64 24
  %v118 = load i64, ptr %v117, align 1
  %v119.not = icmp eq i64 %v118, 0
  br i1 %v119.not, label %trap120, label %ok121

trap120:                                          ; preds = %ok106
  tail call fastcc void @native_trap()
  unreachable

ok121:                                            ; preds = %ok106
  %v122 = inttoptr i64 %v118 to ptr
  %v123 = getelementptr i8, ptr %v122, i64 8
  %v124 = load i32, ptr %v123, align 1
  %v125 = icmp eq i32 %v124, 0
  br i1 %v125, label %then129, label %ok134

then129:                                          ; preds = %ok121
  tail call fastcc void @native_trap()
  unreachable

ok134:                                            ; preds = %ok121
  %v136 = getelementptr i8, ptr %3, i64 32
  %v137 = load i64, ptr %v136, align 1
  %v138.not = icmp eq i64 %v137, 0
  br i1 %v138.not, label %trap139, label %ok140

trap139:                                          ; preds = %ok134
  tail call fastcc void @native_trap()
  unreachable

ok140:                                            ; preds = %ok134
  %v141 = inttoptr i64 %v137 to ptr
  %v142 = getelementptr i8, ptr %v141, i64 8
  %v143 = load i32, ptr %v142, align 1
  %v144 = icmp eq i32 %v143, 0
  br i1 %v144, label %then148, label %ok159

then148:                                          ; preds = %ok140
  tail call fastcc void @native_trap()
  unreachable

ok159:                                            ; preds = %ok140
  %v190 = getelementptr i8, ptr %v141, i64 16
  %v191 = load i64, ptr %v190, align 1
  switch i64 %v191, label %53 [
    i64 -1, label %52
    i64 -2, label %native_i64_rem_s.exit
  ], !prof !86535

52:                                               ; preds = %ok159
  tail call fastcc void @native_trap() #113
  unreachable

53:                                               ; preds = %ok159
  %v192 = add i64 %v191, 1
  %v161 = getelementptr i8, ptr %v63, i64 16
  %v162 = load i64, ptr %v161, align 1
  %v164 = mul i64 %v162, %v109
  %v176 = getelementptr i8, ptr %v122, i64 16
  %v177 = load i64, ptr %v176, align 1
  %v178 = add i64 %v164, %v177
  %54 = srem i64 %v178, %v192
  br label %native_i64_rem_s.exit

native_i64_rem_s.exit:                            ; preds = %53, %ok159
  %55 = phi i64 [ %54, %53 ], [ 0, %ok159 ]
  store i64 %55, ptr %v108, align 1
  %v206 = load i64, ptr %v17, align 1
  %v207.not = icmp eq i64 %v206, 0
  br i1 %v207.not, label %trap208, label %ok209

trap208:                                          ; preds = %native_i64_rem_s.exit
  tail call fastcc void @native_trap()
  unreachable

ok209:                                            ; preds = %native_i64_rem_s.exit
  %v210 = inttoptr i64 %v206 to ptr
  %v211 = getelementptr i8, ptr %v210, i64 8
  %v212 = load i32, ptr %v211, align 1
  %v213 = icmp eq i32 %v212, 0
  br i1 %v213, label %then217, label %ok228

then217:                                          ; preds = %ok209
  tail call fastcc void @native_trap()
  unreachable

ok228:                                            ; preds = %ok209
  %v230 = getelementptr i8, ptr %v210, i64 16
  %v231 = load i64, ptr %v230, align 1
  %v232.not = icmp eq i64 %v231, 0
  br i1 %v232.not, label %trap233, label %ok234

trap233:                                          ; preds = %ok228
  tail call fastcc void @native_trap()
  unreachable

ok234:                                            ; preds = %ok228
  switch i64 %arg1, label %57 [
    i64 0, label %56
    i64 -1, label %native_roots_leave.exit
  ], !prof !86535

56:                                               ; preds = %ok234
  tail call fastcc void @native_trap() #113
  unreachable

57:                                               ; preds = %ok234
  %v235 = inttoptr i64 %v231 to ptr
  %v236 = getelementptr i8, ptr %v235, i64 8
  %v237 = load i64, ptr %v236, align 1
  %58 = sdiv i64 %v237, 8
  %59 = srem i64 %58, %arg1
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %57, %ok234
  %60 = phi i64 [ %59, %57 ], [ 0, %ok234 ]
  ret i64 %60
}
