define internal tailcc noundef range(i64 1, 0) i64 @f.5(i64 range(i64 1, 0) %arg0, i64 range(i64 0, 4294967296) %arg1) unnamed_addr #105 personality ptr @rust_eh_personality {
ok16:
  %roots = alloca { ptr, i64, i64, [4 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 4, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v8 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v9 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v8, i8 0, i64 16, i1 false)
  %v17 = inttoptr i64 %arg0 to ptr
  %v18 = getelementptr i8, ptr %v17, i64 8
  %v19 = load i64, ptr %v18, align 1
  store i64 %v19, ptr %v8, align 8
  %v20.not = icmp eq i64 %v19, 0
  br i1 %v20.not, label %trap21, label %ok22

trap21:                                           ; preds = %ok16
  call fastcc void @native_trap()
  unreachable

ok22:                                             ; preds = %ok16
  %v23 = and i64 %v19, 1
  %v24 = icmp eq i64 %v23, 0
  br i1 %v24, label %ok26, label %trap25

trap25:                                           ; preds = %ok22
  call fastcc void @native_trap()
  unreachable

ok26:                                             ; preds = %ok22
  %v27 = inttoptr i64 %v19 to ptr
  %v28 = getelementptr i8, ptr %v27, i64 8
  %v29 = load i64, ptr %v28, align 1
  %v31 = and i64 %v29, 4294967295
  %v32 = icmp samesign ugt i64 %arg1, %v31
  br i1 %v32, label %then36, label %block34

then36:                                           ; preds = %ok26
  call fastcc void @native_trap()
  unreachable

block34:                                          ; preds = %ok26
  %v39 = trunc nuw i64 %arg1 to i32
  %v44.not36 = icmp eq i64 %arg1, 0
  br i1 %v44.not36, label %block213, label %then48.lr.ph

then48.lr.ph:                                     ; preds = %block34
  %v161 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  br label %then48

then48:                                           ; preds = %block73, %then48.lr.ph
  %slot7.038 = phi i32 [ 0, %then48.lr.ph ], [ %v209, %block73 ]
  %slot4.037 = phi i32 [ 0, %then48.lr.ph ], [ %v207, %block73 ]
  %v50 = load i64, ptr %v8, align 8
  %v52.not = icmp eq i64 %v50, 0
  br i1 %v52.not, label %trap53, label %ok54

trap53:                                           ; preds = %then48
  call fastcc void @native_trap()
  unreachable

ok54:                                             ; preds = %then48
  %v55 = and i64 %v50, 1
  %v56 = icmp eq i64 %v55, 0
  br i1 %v56, label %ok58, label %trap57

trap57:                                           ; preds = %ok54
  call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %ok54
  %v59 = inttoptr i64 %v50 to ptr
  %v60 = getelementptr i8, ptr %v59, i64 8
  %v61 = load i64, ptr %v60, align 1
  %v62 = zext i32 %slot4.037 to i64
  %v63 = icmp ugt i64 %v61, %v62
  br i1 %v63, label %ok65, label %trap64

trap64:                                           ; preds = %ok58
  call fastcc void @native_trap()
  unreachable

ok65:                                             ; preds = %ok58
  %v67 = getelementptr i8, ptr %v59, i64 16
  %v68 = getelementptr i8, ptr %v67, i64 %v62
  %v69 = load i8, ptr %v68, align 1
  %v71 = icmp slt i8 %v69, 0
  br i1 %v71, label %then75, label %block73

then75:                                           ; preds = %ok65
  %7 = add nsw i8 %v69, 11
  %v8325 = icmp ult i8 %7, -51
  br i1 %v8325, label %then86, label %else93

then86:                                           ; preds = %then75
  call fastcc void @native_trap()
  unreachable

else93:                                           ; preds = %then75
  %v97 = icmp samesign ult i8 %v69, -32
  %v105 = icmp samesign ult i8 %v69, -16
  %v108 = select i1 %v105, i32 3, i32 4
  %slot99.0 = select i1 %v97, i32 2, i32 %v108
  %v113 = sub i32 %v39, %slot4.037
  %v114 = icmp ugt i32 %slot99.0, %v113
  br i1 %v114, label %then118, label %ok132.preheader

ok132.preheader:                                  ; preds = %else93
  %wide.trip.count = zext nneg i32 %slot99.0 to i64
  br label %ok132

then118:                                          ; preds = %else93
  call fastcc void @native_trap()
  unreachable

ok132:                                            ; preds = %block148, %ok132.preheader
  %indvars.iv = phi i64 [ 1, %ok132.preheader ], [ %indvars.iv.next, %block148 ]
  %8 = trunc nuw nsw i64 %indvars.iv to i32
  %v125 = add i32 %slot4.037, %8
  %v136 = zext i32 %v125 to i64
  %v137 = icmp ugt i64 %v61, %v136
  br i1 %v137, label %ok139, label %trap138

trap138:                                          ; preds = %ok132
  call fastcc void @native_trap()
  unreachable

ok139:                                            ; preds = %ok132
  %v142 = getelementptr i8, ptr %v67, i64 %v136
  %v143 = load i8, ptr %v142, align 1
  %v146.not = icmp slt i8 %v143, -64
  br i1 %v146.not, label %block148, label %then150

then150:                                          ; preds = %ok139
  call fastcc void @native_trap()
  unreachable

block148:                                         ; preds = %ok139
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %block120, label %ok132

block120:                                         ; preds = %block148
  store i64 %v50, ptr %v161, align 8
  store i64 4, ptr %1, align 8
  %v163 = call tailcc i32 @f.3(i64 %v50, i32 %slot4.037)
  %v164 = icmp ult i32 %v163, 128
  br i1 %v164, label %then191, label %else168

else168:                                          ; preds = %block120
  %v172 = icmp ult i32 %v163, 2048
  %v180 = icmp ult i32 %v163, 65536
  %v183 = select i1 %v180, i32 3, i32 4
  %9 = icmp eq i32 %v183, %slot99.0
  %10 = select i1 %v172, i1 %v97, i1 %9
  br i1 %10, label %block189, label %then191

then191:                                          ; preds = %else168, %block120
  call fastcc void @native_trap()
  unreachable

block189:                                         ; preds = %else168
  %11 = and i32 %v163, -2048
  %v195 = icmp eq i32 %11, 55296
  %v198 = icmp ugt i32 %v163, 1114111
  %v20026 = or i1 %v198, %v195
  br i1 %v20026, label %then203, label %block73

then203:                                          ; preds = %block189
  call fastcc void @native_trap()
  unreachable

block73:                                          ; preds = %block189, %ok65
  %slot5.0 = phi i32 [ %slot99.0, %block189 ], [ 1, %ok65 ]
  %v207 = add i32 %slot5.0, %slot4.037
  %v209 = add i32 %slot7.038, 1
  %v44.not = icmp eq i32 %v207, %v39
  br i1 %v44.not, label %block40, label %then48

block40:                                          ; preds = %block73
  %v209.lcssa = phi i32 [ %v209, %block73 ]
  %v211 = icmp eq i64 %arg1, 4294967295
  br i1 %v211, label %then215, label %block213

then215:                                          ; preds = %block40
  call fastcc void @native_trap()
  unreachable

block213:                                         ; preds = %block40, %block34
  %slot7.0.lcssa42 = phi i32 [ %v209.lcssa, %block40 ], [ 0, %block34 ]
  store i64 3, ptr %1, align 8
  %v221 = call fastcc i64 @native_array_new(i32 %v39)
  store i64 %v221, ptr %v9, align 8
  %v222 = load i64, ptr %v8, align 8
  %12 = and i64 %v221, 1
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %15, label %14

14:                                               ; preds = %block213
  call fastcc void @native_trap() #113
  unreachable

15:                                               ; preds = %block213
  %16 = inttoptr i64 %v221 to ptr
  %17 = icmp ne i64 %v222, 0
  %18 = and i64 %v222, 1
  %19 = icmp eq i64 %18, 0
  %20 = and i1 %17, %19
  br i1 %20, label %22, label %21

21:                                               ; preds = %15
  call fastcc void @native_trap() #113
  unreachable

22:                                               ; preds = %15
  %23 = inttoptr i64 %v222 to ptr
  %24 = getelementptr inbounds nuw i8, ptr %16, i64 8
  %25 = load i64, ptr %24, align 8, !noundef !39
  %26 = icmp ult i64 %25, %arg1
  br i1 %26, label %31, label %27

27:                                               ; preds = %22
  %28 = getelementptr inbounds nuw i8, ptr %23, i64 8
  %29 = load i64, ptr %28, align 8, !noundef !39
  %30 = icmp ugt i64 %arg1, %29
  br i1 %30, label %31, label %native_array_copy.exit

31:                                               ; preds = %27, %22
  call fastcc void @native_trap() #113
  unreachable

native_array_copy.exit:                           ; preds = %27
  %32 = getelementptr inbounds nuw i8, ptr %23, i64 16
  %33 = getelementptr inbounds nuw i8, ptr %16, i64 16
  call void @llvm.memmove.p0.p0.i64(ptr nonnull align 1 %33, ptr nonnull align 1 %32, i64 %arg1, i1 false)
  %v226 = load i64, ptr %v9, align 8
  %v227 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 %v226, ptr %v227, align 8
  store i64 4, ptr %1, align 8
  %34 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %35 = icmp eq ptr %34, null
  br i1 %35, label %36, label %37

36:                                               ; preds = %native_array_copy.exit
  call fastcc void @native_trap() #113
  unreachable

37:                                               ; preds = %native_array_copy.exit
  %38 = getelementptr inbounds nuw i8, ptr %34, i64 376
  %39 = load i64, ptr %38, align 8, !noundef !39
  %40 = icmp eq i64 %39, 0
  br i1 %40, label %41, label %45

41:                                               ; preds = %51, %45, %37
  %42 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %43 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %34, i64 noundef 48, ptr noundef %42) #84
  %44 = icmp eq ptr %43, null
  br i1 %44, label %53, label %ok232

45:                                               ; preds = %37
  %46 = getelementptr inbounds nuw i8, ptr %34, i64 368
  %47 = load i64, ptr %46, align 8, !noundef !39
  %48 = add i64 %47, 1
  store i64 %48, ptr %46, align 8
  %49 = urem i64 %48, %39
  %50 = icmp eq i64 %49, 0
  br i1 %50, label %51, label %41

51:                                               ; preds = %45
  %52 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %34, ptr noundef %52) #84
  br label %41

53:                                               ; preds = %41
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok232:                                            ; preds = %41
  store i64 198, ptr %43, align 1
  %v239 = getelementptr i8, ptr %43, i64 8
  store i32 %slot7.0.lcssa42, ptr %v239, align 1
  %v244 = getelementptr i8, ptr %43, i64 16
  store i32 %v39, ptr %v244, align 1
  %v249 = getelementptr i8, ptr %43, i64 24
  store i64 %v226, ptr %v249, align 1
  %v254 = getelementptr i8, ptr %43, i64 32
  store i32 0, ptr %v254, align 1
  %v259 = getelementptr i8, ptr %43, i64 40
  store i32 0, ptr %v259, align 1
  %54 = load i64, ptr %0, align 8, !noundef !39
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %native_roots_leave.exit, label %56

56:                                               ; preds = %ok232
  %57 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %57, ptr @native_roots.0, align 8
  %58 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %59 = add i64 %58, -1
  store i64 %59, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %56, %ok232
  %60 = ptrtoint ptr %43 to i64
  ret i64 %60
}
