define internal tailcc void @f.11(i64 range(i64 1, 0) %arg0, i64 range(i64 1, 0) %arg1) unnamed_addr #104 personality ptr @rust_eh_personality {
ok20:
  %roots = alloca { ptr, i64, i64, [12 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 12, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v2 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  store i64 %arg1, ptr %v2, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v7 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %v3, i8 0, i64 48, i1 false)
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v21 = inttoptr i64 %arg0 to ptr
  %v22 = getelementptr i8, ptr %v21, i64 8
  %v23 = load i64, ptr %v22, align 1
  store i64 %v23, ptr %v5, align 8
  %v25 = icmp eq i64 %v23, %arg1
  br i1 %v25, label %block16, label %next28

next28:                                           ; preds = %ok20
  %v30.not = icmp eq i64 %v23, 0
  br i1 %v30.not, label %trap31, label %ok39

trap31:                                           ; preds = %next28
  call fastcc void @native_trap()
  unreachable

ok39:                                             ; preds = %next28
  %v33 = inttoptr i64 %v23 to ptr
  %v34 = getelementptr i8, ptr %v33, i64 16
  %v35 = load i32, ptr %v34, align 1
  %v40 = inttoptr i64 %arg1 to ptr
  %v41 = getelementptr i8, ptr %v40, i64 16
  %v42 = load i32, ptr %v41, align 1
  %v43.not = icmp eq i32 %v35, %v42
  br i1 %v43.not, label %ok57, label %block16

ok57:                                             ; preds = %ok39
  %v52 = getelementptr i8, ptr %v33, i64 24
  %v53 = load i64, ptr %v52, align 1
  store i64 %v53, ptr %v6, align 8
  %v59 = getelementptr i8, ptr %v40, i64 24
  %v60 = load i64, ptr %v59, align 1
  %v60.fr = freeze i64 %v60
  store i64 %v60.fr, ptr %v7, align 8
  %v65.not4 = icmp eq i32 %v35, 0
  br i1 %v65.not4, label %block16, label %then69.lr.ph

then69.lr.ph:                                     ; preds = %ok57
  %v73.not = icmp eq i64 %v53, 0
  %v80 = inttoptr i64 %v53 to ptr
  %v81 = getelementptr i8, ptr %v80, i64 8
  %v88 = getelementptr i8, ptr %v80, i64 16
  %v94.not = icmp eq i64 %v60.fr, 0
  %v97 = and i64 %v60.fr, 1
  %v98 = icmp eq i64 %v97, 0
  %v101 = inttoptr i64 %v60.fr to ptr
  %v102 = getelementptr i8, ptr %v101, i64 8
  %v109 = getelementptr i8, ptr %v101, i64 16
  br i1 %v73.not, label %trap74, label %then69.lr.ph.split

then69.lr.ph.split:                               ; preds = %then69.lr.ph
  %v76 = and i64 %v53, 1
  %v77 = icmp eq i64 %v76, 0
  br i1 %v77, label %then69.lr.ph.split.split, label %trap78

then69.lr.ph.split.split:                         ; preds = %then69.lr.ph.split
  %v82 = load i64, ptr %v81, align 1
  br i1 %v94.not, label %then69.us, label %then69.lr.ph.split.split.split

then69.us:                                        ; preds = %then69.lr.ph.split.split
  %v84.us.not = icmp eq i64 %v82, 0
  br i1 %v84.us.not, label %trap85, label %ok86.us

ok86.us:                                          ; preds = %then69.us
  call fastcc void @native_trap()
  unreachable

then69.lr.ph.split.split.split:                   ; preds = %then69.lr.ph.split.split
  br i1 %v98, label %then69.us7.preheader, label %then69

then69.us7.preheader:                             ; preds = %then69.lr.ph.split.split.split
  %7 = zext i32 %v35 to i64
  br label %then69.us7

then69.us7:                                       ; preds = %ok107.us, %then69.us7.preheader
  %indvars.iv = phi i64 [ 0, %then69.us7.preheader ], [ %indvars.iv.next, %ok107.us ]
  %exitcond.not = icmp eq i64 %indvars.iv, %v82
  br i1 %exitcond.not, label %trap85, label %ok86.us11

ok86.us11:                                        ; preds = %then69.us7
  %v103.us = load i64, ptr %v102, align 1
  %v105.us = icmp ugt i64 %v103.us, %indvars.iv
  br i1 %v105.us, label %ok107.us, label %trap106

ok107.us:                                         ; preds = %ok86.us11
  %v89.us12 = getelementptr i8, ptr %v88, i64 %indvars.iv
  %v90.us13 = load i8, ptr %v89.us12, align 1
  %v110.us = getelementptr i8, ptr %v109, i64 %indvars.iv
  %v111.us = load i8, ptr %v110.us, align 1
  %v113.not.us.not = icmp ne i8 %v90.us13, %v111.us
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %v65.not.us = icmp eq i64 %indvars.iv.next, %7
  %or.cond = select i1 %v113.not.us.not, i1 true, i1 %v65.not.us
  br i1 %or.cond, label %block16, label %then69.us7

then69:                                           ; preds = %then69.lr.ph.split.split.split
  %v84.not = icmp eq i64 %v82, 0
  br i1 %v84.not, label %trap85, label %ok86

trap74:                                           ; preds = %then69.lr.ph
  call fastcc void @native_trap()
  unreachable

trap78:                                           ; preds = %then69.lr.ph.split
  call fastcc void @native_trap()
  unreachable

trap85:                                           ; preds = %then69, %then69.us7, %then69.us
  call fastcc void @native_trap()
  unreachable

ok86:                                             ; preds = %then69
  call fastcc void @native_trap()
  unreachable

trap106:                                          ; preds = %ok86.us11
  call fastcc void @native_trap()
  unreachable

block16:                                          ; preds = %ok107.us, %ok57, %ok39, %ok20
  %v146 = phi i1 [ false, %ok20 ], [ true, %ok39 ], [ false, %ok57 ], [ %v113.not.us.not, %ok107.us ]
  %v122.b = load i1, ptr @g.24, align 1
  br i1 %v122.b, label %block125, label %then127

then127:                                          ; preds = %block16
  call fastcc void @native_trap()
  unreachable

block125:                                         ; preds = %block16
  %v129 = load i64, ptr @g.23, align 8
  %v130.not = icmp eq i64 %v129, 0
  br i1 %v130.not, label %trap131, label %ok132

trap131:                                          ; preds = %block125
  call fastcc void @native_trap()
  unreachable

ok132:                                            ; preds = %block125
  %v133.b = load i1, ptr @g.12, align 1
  br i1 %v133.b, label %block136, label %then138

then138:                                          ; preds = %ok132
  call fastcc void @native_trap()
  unreachable

block136:                                         ; preds = %ok132
  %v140 = load i64, ptr @g.11, align 8
  %v141.not = icmp eq i64 %v140, 0
  br i1 %v141.not, label %trap142, label %ok143

trap142:                                          ; preds = %block136
  call fastcc void @native_trap()
  unreachable

ok143:                                            ; preds = %block136
  br i1 %v146, label %then150, label %.critedge

then150:                                          ; preds = %ok143
  %v152.b = load i1, ptr @g.16, align 1
  br i1 %v152.b, label %block155, label %then157

then157:                                          ; preds = %then150
  call fastcc void @native_trap()
  unreachable

block155:                                         ; preds = %then150
  %v159 = load i64, ptr @g.15, align 8
  %v160.not = icmp eq i64 %v159, 0
  br i1 %v160.not, label %trap161, label %ok162

trap161:                                          ; preds = %block155
  call fastcc void @native_trap()
  unreachable

ok162:                                            ; preds = %block155
  store i64 8, ptr %1, align 8
  %8 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %9 = icmp eq ptr %8, null
  br i1 %9, label %10, label %11

10:                                               ; preds = %ok162
  call fastcc void @native_trap() #113
  unreachable

11:                                               ; preds = %ok162
  %12 = getelementptr inbounds nuw i8, ptr %8, i64 376
  %13 = load i64, ptr %12, align 8, !noundef !39
  %14 = icmp eq i64 %13, 0
  br i1 %14, label %15, label %19

15:                                               ; preds = %25, %19, %11
  %16 = phi ptr [ %.pre, %25 ], [ %roots, %19 ], [ %roots, %11 ]
  %17 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %8, i64 noundef 24, ptr noundef %16) #84
  %18 = icmp eq ptr %17, null
  br i1 %18, label %26, label %ok167

19:                                               ; preds = %11
  %20 = getelementptr inbounds nuw i8, ptr %8, i64 368
  %21 = load i64, ptr %20, align 8, !noundef !39
  %22 = add i64 %21, 1
  store i64 %22, ptr %20, align 8
  %23 = urem i64 %22, %13
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %25, label %15

25:                                               ; preds = %19
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %8, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %15

26:                                               ; preds = %15
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok167:                                            ; preds = %15
  %27 = ptrtoint ptr %17 to i64
  store i64 98, ptr %17, align 1
  %v174 = getelementptr i8, ptr %17, i64 8
  store i32 0, ptr %v174, align 1
  %v179 = getelementptr i8, ptr %17, i64 16
  store i64 0, ptr %v179, align 1
  store i64 %27, ptr %v3, align 8
  %v182 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  store i64 %27, ptr %v182, align 8
  %v183 = getelementptr inbounds nuw i8, ptr %roots, i64 96
  store i64 ptrtoint (ptr @object.2.1 to i64), ptr %v183, align 8
  %v184 = getelementptr inbounds nuw i8, ptr %roots, i64 104
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v184, align 8
  %v185 = getelementptr inbounds nuw i8, ptr %roots, i64 112
  store i64 %27, ptr %v185, align 8
  store i64 12, ptr %1, align 8
  %28 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %29 = icmp eq ptr %28, null
  br i1 %29, label %30, label %31

30:                                               ; preds = %ok167
  call fastcc void @native_trap() #113
  unreachable

31:                                               ; preds = %ok167
  %32 = getelementptr inbounds nuw i8, ptr %28, i64 376
  %33 = load i64, ptr %32, align 8, !noundef !39
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %35, label %39

35:                                               ; preds = %45, %39, %31
  %36 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %37 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %28, i64 noundef 24, ptr noundef %36) #84
  %38 = icmp eq ptr %37, null
  br i1 %38, label %47, label %ok190

39:                                               ; preds = %31
  %40 = getelementptr inbounds nuw i8, ptr %28, i64 368
  %41 = load i64, ptr %40, align 8, !noundef !39
  %42 = add i64 %41, 1
  store i64 %42, ptr %40, align 8
  %43 = urem i64 %42, %33
  %44 = icmp eq i64 %43, 0
  br i1 %44, label %45, label %35

45:                                               ; preds = %39
  %46 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %28, ptr noundef %46) #84
  br label %35

47:                                               ; preds = %35
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok190:                                            ; preds = %35
  %48 = ptrtoint ptr %37 to i64
  store i64 10, ptr %37, align 1
  %v197 = getelementptr i8, ptr %37, i64 8
  store i64 ptrtoint (ptr @object.2.1 to i64), ptr %v197, align 1
  %v202 = getelementptr i8, ptr %37, i64 16
  store i64 %27, ptr %v202, align 1
  store i64 %48, ptr %v182, align 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v183, align 8
  store i64 %27, ptr %v184, align 8
  store i64 11, ptr %1, align 8
  %49 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %50 = icmp eq ptr %49, null
  br i1 %50, label %51, label %52

51:                                               ; preds = %ok190
  call fastcc void @native_trap() #113
  unreachable

52:                                               ; preds = %ok190
  %53 = getelementptr inbounds nuw i8, ptr %49, i64 376
  %54 = load i64, ptr %53, align 8, !noundef !39
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %56, label %60

56:                                               ; preds = %66, %60, %52
  %57 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %58 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %49, i64 noundef 24, ptr noundef %57) #84
  %59 = icmp eq ptr %58, null
  br i1 %59, label %68, label %ok210

60:                                               ; preds = %52
  %61 = getelementptr inbounds nuw i8, ptr %49, i64 368
  %62 = load i64, ptr %61, align 8, !noundef !39
  %63 = add i64 %62, 1
  store i64 %63, ptr %61, align 8
  %64 = urem i64 %63, %54
  %65 = icmp eq i64 %64, 0
  br i1 %65, label %66, label %56

66:                                               ; preds = %60
  %67 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %49, ptr noundef %67) #84
  br label %56

68:                                               ; preds = %56
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok210:                                            ; preds = %56
  %69 = ptrtoint ptr %58 to i64
  store i64 66, ptr %58, align 1
  %v217 = getelementptr i8, ptr %58, i64 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v217, align 1
  %v222 = getelementptr i8, ptr %58, i64 16
  store i64 %48, ptr %v222, align 1
  store i64 %69, ptr %v179, align 1
  %v228 = load i64, ptr %v3, align 8
  %v229.not = icmp eq i64 %v228, 0
  br i1 %v229.not, label %trap230, label %ok231

trap230:                                          ; preds = %ok210
  call fastcc void @native_trap()
  unreachable

ok231:                                            ; preds = %ok210
  %v232 = inttoptr i64 %v228 to ptr
  %v233 = getelementptr i8, ptr %v232, i64 8
  store i32 1, ptr %v233, align 1
  %v234 = load i64, ptr %v3, align 8
  %v235.not = icmp eq i64 %v234, 0
  br i1 %v235.not, label %trap236, label %ok237

trap236:                                          ; preds = %ok231
  call fastcc void @native_trap()
  unreachable

ok237:                                            ; preds = %ok231
  %v238 = inttoptr i64 %v234 to ptr
  %v239 = getelementptr i8, ptr %v238, i64 8
  %v240 = load i32, ptr %v239, align 1
  %v241 = icmp eq i32 %v240, 0
  br i1 %v241, label %then245, label %ok250

then245:                                          ; preds = %ok237
  call fastcc void @native_trap()
  unreachable

ok250:                                            ; preds = %ok237
  %v252 = getelementptr i8, ptr %v238, i64 16
  %v253 = load i64, ptr %v252, align 1
  %v254.not = icmp eq i64 %v253, 0
  br i1 %v254.not, label %trap255, label %ok256

trap255:                                          ; preds = %ok250
  call fastcc void @native_trap()
  unreachable

ok256:                                            ; preds = %ok250
  store i64 %v253, ptr %v4, align 8
  %v260 = inttoptr i64 %v253 to ptr
  %v268 = getelementptr i8, ptr %v260, i64 8
  %v269 = load i64, ptr %v268, align 1
  %v270.not = icmp eq i64 %v269, 0
  br i1 %v270.not, label %trap271, label %ok272

trap271:                                          ; preds = %ok256
  call fastcc void @native_trap()
  unreachable

ok272:                                            ; preds = %ok256
  %v261 = getelementptr i8, ptr %v260, i64 16
  %v262 = load i64, ptr %v261, align 1
  %v273 = inttoptr i64 %v269 to ptr
  %v274 = getelementptr i8, ptr %v273, i64 8
  %v275 = load ptr, ptr %v274, align 1
  store i64 %v262, ptr %v182, align 8
  store i64 9, ptr %1, align 8
  %v278 = call tailcc i32 %v275(i64 %v262, i64 0)
  %v279.b = load i1, ptr @g.16, align 1
  br i1 %v279.b, label %block282, label %then284

then284:                                          ; preds = %ok272
  call fastcc void @native_trap()
  unreachable

block282:                                         ; preds = %ok272
  %v286 = load i64, ptr @g.15, align 8
  %v287.not = icmp eq i64 %v286, 0
  br i1 %v287.not, label %trap288, label %ok289

trap288:                                          ; preds = %block282
  call fastcc void @native_trap()
  unreachable

ok289:                                            ; preds = %block282
  store i64 8, ptr %1, align 8
  %70 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %71 = icmp eq ptr %70, null
  br i1 %71, label %72, label %73

72:                                               ; preds = %ok289
  call fastcc void @native_trap() #113
  unreachable

73:                                               ; preds = %ok289
  %74 = getelementptr inbounds nuw i8, ptr %70, i64 376
  %75 = load i64, ptr %74, align 8, !noundef !39
  %76 = icmp eq i64 %75, 0
  br i1 %76, label %77, label %81

77:                                               ; preds = %87, %81, %73
  %78 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %79 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %70, i64 noundef 24, ptr noundef %78) #84
  %80 = icmp eq ptr %79, null
  br i1 %80, label %89, label %ok294

81:                                               ; preds = %73
  %82 = getelementptr inbounds nuw i8, ptr %70, i64 368
  %83 = load i64, ptr %82, align 8, !noundef !39
  %84 = add i64 %83, 1
  store i64 %84, ptr %82, align 8
  %85 = urem i64 %84, %75
  %86 = icmp eq i64 %85, 0
  br i1 %86, label %87, label %77

87:                                               ; preds = %81
  %88 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %70, ptr noundef %88) #84
  br label %77

89:                                               ; preds = %77
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok294:                                            ; preds = %77
  %90 = ptrtoint ptr %79 to i64
  store i64 98, ptr %79, align 1
  %v301 = getelementptr i8, ptr %79, i64 8
  store i32 0, ptr %v301, align 1
  %v306 = getelementptr i8, ptr %79, i64 16
  store i64 0, ptr %v306, align 1
  store i64 %90, ptr %v3, align 8
  store i64 %90, ptr %v182, align 8
  store i64 ptrtoint (ptr @object.1.1 to i64), ptr %v183, align 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v184, align 8
  store i64 %90, ptr %v185, align 8
  store i64 12, ptr %1, align 8
  %91 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %92 = icmp eq ptr %91, null
  br i1 %92, label %93, label %94

93:                                               ; preds = %ok294
  call fastcc void @native_trap() #113
  unreachable

94:                                               ; preds = %ok294
  %95 = getelementptr inbounds nuw i8, ptr %91, i64 376
  %96 = load i64, ptr %95, align 8, !noundef !39
  %97 = icmp eq i64 %96, 0
  br i1 %97, label %98, label %102

98:                                               ; preds = %108, %102, %94
  %99 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %100 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %91, i64 noundef 24, ptr noundef %99) #84
  %101 = icmp eq ptr %100, null
  br i1 %101, label %110, label %ok317

102:                                              ; preds = %94
  %103 = getelementptr inbounds nuw i8, ptr %91, i64 368
  %104 = load i64, ptr %103, align 8, !noundef !39
  %105 = add i64 %104, 1
  store i64 %105, ptr %103, align 8
  %106 = urem i64 %105, %96
  %107 = icmp eq i64 %106, 0
  br i1 %107, label %108, label %98

108:                                              ; preds = %102
  %109 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %91, ptr noundef %109) #84
  br label %98

110:                                              ; preds = %98
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok317:                                            ; preds = %98
  %111 = ptrtoint ptr %100 to i64
  store i64 10, ptr %100, align 1
  %v324 = getelementptr i8, ptr %100, i64 8
  store i64 ptrtoint (ptr @object.1.1 to i64), ptr %v324, align 1
  %v329 = getelementptr i8, ptr %100, i64 16
  store i64 %90, ptr %v329, align 1
  store i64 %111, ptr %v182, align 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v183, align 8
  store i64 %90, ptr %v184, align 8
  store i64 11, ptr %1, align 8
  %112 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %113 = icmp eq ptr %112, null
  br i1 %113, label %114, label %115

114:                                              ; preds = %ok317
  call fastcc void @native_trap() #113
  unreachable

115:                                              ; preds = %ok317
  %116 = getelementptr inbounds nuw i8, ptr %112, i64 376
  %117 = load i64, ptr %116, align 8, !noundef !39
  %118 = icmp eq i64 %117, 0
  br i1 %118, label %119, label %123

119:                                              ; preds = %129, %123, %115
  %120 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %121 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %112, i64 noundef 24, ptr noundef %120) #84
  %122 = icmp eq ptr %121, null
  br i1 %122, label %131, label %ok337

123:                                              ; preds = %115
  %124 = getelementptr inbounds nuw i8, ptr %112, i64 368
  %125 = load i64, ptr %124, align 8, !noundef !39
  %126 = add i64 %125, 1
  store i64 %126, ptr %124, align 8
  %127 = urem i64 %126, %117
  %128 = icmp eq i64 %127, 0
  br i1 %128, label %129, label %119

129:                                              ; preds = %123
  %130 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %112, ptr noundef %130) #84
  br label %119

131:                                              ; preds = %119
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok337:                                            ; preds = %119
  %132 = ptrtoint ptr %121 to i64
  store i64 66, ptr %121, align 1
  %v344 = getelementptr i8, ptr %121, i64 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v344, align 1
  %v349 = getelementptr i8, ptr %121, i64 16
  store i64 %111, ptr %v349, align 1
  store i64 %132, ptr %v306, align 1
  %v355 = load i64, ptr %v3, align 8
  %v356.not = icmp eq i64 %v355, 0
  br i1 %v356.not, label %trap357, label %ok358

trap357:                                          ; preds = %ok337
  call fastcc void @native_trap()
  unreachable

ok358:                                            ; preds = %ok337
  %v359 = inttoptr i64 %v355 to ptr
  %v360 = getelementptr i8, ptr %v359, i64 8
  store i32 1, ptr %v360, align 1
  %v361 = load i64, ptr %v3, align 8
  %v362.not = icmp eq i64 %v361, 0
  br i1 %v362.not, label %trap363, label %ok364

trap363:                                          ; preds = %ok358
  call fastcc void @native_trap()
  unreachable

ok364:                                            ; preds = %ok358
  %v365 = inttoptr i64 %v361 to ptr
  %v366 = getelementptr i8, ptr %v365, i64 8
  %v367 = load i32, ptr %v366, align 1
  %v368 = icmp eq i32 %v367, 0
  br i1 %v368, label %then372, label %ok377

then372:                                          ; preds = %ok364
  call fastcc void @native_trap()
  unreachable

ok377:                                            ; preds = %ok364
  %v379 = getelementptr i8, ptr %v365, i64 16
  %v380 = load i64, ptr %v379, align 1
  %v381.not = icmp eq i64 %v380, 0
  br i1 %v381.not, label %trap382, label %ok383

trap382:                                          ; preds = %ok377
  call fastcc void @native_trap()
  unreachable

ok383:                                            ; preds = %ok377
  store i64 %v380, ptr %v4, align 8
  %v387 = inttoptr i64 %v380 to ptr
  %v395 = getelementptr i8, ptr %v387, i64 8
  %v396 = load i64, ptr %v395, align 1
  %v397.not = icmp eq i64 %v396, 0
  br i1 %v397.not, label %trap398, label %ok399

trap398:                                          ; preds = %ok383
  call fastcc void @native_trap()
  unreachable

ok399:                                            ; preds = %ok383
  %v388 = getelementptr i8, ptr %v387, i64 16
  %v389 = load i64, ptr %v388, align 1
  %v400 = inttoptr i64 %v396 to ptr
  %v401 = getelementptr i8, ptr %v400, i64 8
  %v402 = load ptr, ptr %v401, align 1
  store i64 %v389, ptr %v182, align 8
  store i64 9, ptr %1, align 8
  %v405 = call tailcc i32 %v402(i64 %v389, i64 0)
  %v406.b = load i1, ptr @g.18, align 1
  br i1 %v406.b, label %block409, label %then411

then411:                                          ; preds = %ok399
  call fastcc void @native_trap()
  unreachable

block409:                                         ; preds = %ok399
  %v413 = load i64, ptr @g.17, align 8
  %v414.not = icmp eq i64 %v413, 0
  br i1 %v414.not, label %trap415, label %native_roots_leave.exit

trap415:                                          ; preds = %block409
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit:                          ; preds = %block409
  store i64 8, ptr %1, align 8
  call void @benchmark_opaque_write_character(i32 10)
  %v418.b = load i1, ptr @g.22, align 1
  br i1 %v418.b, label %block421, label %then423

then423:                                          ; preds = %native_roots_leave.exit
  call fastcc void @native_trap()
  unreachable

block421:                                         ; preds = %native_roots_leave.exit
  %v425 = load i64, ptr @g.21, align 8
  %v426.not = icmp eq i64 %v425, 0
  br i1 %v426.not, label %trap427, label %ok441

trap427:                                          ; preds = %block421
  call fastcc void @native_trap()
  unreachable

ok441:                                            ; preds = %block421
  %v442 = inttoptr i64 %v425 to ptr
  %v443 = getelementptr i8, ptr %v442, i64 8
  %v444 = load i64, ptr %v443, align 1
  store i64 %v444, ptr %v182, align 8
  store i64 %v425, ptr %v183, align 8
  store i64 10, ptr %1, align 8
  %133 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %134 = icmp eq ptr %133, null
  br i1 %134, label %135, label %136

135:                                              ; preds = %ok441
  call fastcc void @native_trap() #113
  unreachable

136:                                              ; preds = %ok441
  %137 = getelementptr inbounds nuw i8, ptr %133, i64 376
  %138 = load i64, ptr %137, align 8, !noundef !39
  %139 = icmp eq i64 %138, 0
  br i1 %139, label %140, label %144

140:                                              ; preds = %150, %144, %136
  %141 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %142 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %133, i64 noundef 16, ptr noundef %141) #84
  %143 = icmp eq ptr %142, null
  br i1 %143, label %152, label %ok451

144:                                              ; preds = %136
  %145 = getelementptr inbounds nuw i8, ptr %133, i64 368
  %146 = load i64, ptr %145, align 8, !noundef !39
  %147 = add i64 %146, 1
  store i64 %147, ptr %145, align 8
  %148 = urem i64 %147, %138
  %149 = icmp eq i64 %148, 0
  br i1 %149, label %150, label %140

150:                                              ; preds = %144
  %151 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %133, ptr noundef %151) #84
  br label %140

152:                                              ; preds = %140
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok451:                                            ; preds = %140
  %153 = ptrtoint ptr %142 to i64
  store i64 110, ptr %142, align 1
  %v458 = getelementptr i8, ptr %142, i64 8
  store i64 %v444, ptr %v458, align 1
  store i64 %153, ptr %v443, align 1
  %.pre8 = load i64, ptr %0, align 8
  %154 = icmp eq i64 %.pre8, 0
  br i1 %154, label %native_roots_leave.exit7, label %.critedge

.critedge:                                        ; preds = %ok451, %ok143
  %155 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %155, ptr @native_roots.0, align 8
  %156 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %157 = add i64 %156, -1
  store i64 %157, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit7

native_roots_leave.exit7:                         ; preds = %.critedge, %ok451
  ret void
}
