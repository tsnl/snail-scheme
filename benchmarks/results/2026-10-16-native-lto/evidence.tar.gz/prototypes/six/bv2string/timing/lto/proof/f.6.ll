define internal tailcc i64 @f.6(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [6 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 6, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  store i64 3, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %entry
  call fastcc void @native_trap() #113
  unreachable

10:                                               ; preds = %entry
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = phi ptr [ %.pre, %24 ], [ %roots, %18 ], [ %roots, %10 ]
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 24, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %25, label %ok11

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %14

25:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok11:                                             ; preds = %14
  %26 = ptrtoint ptr %16 to i64
  store i64 122, ptr %16, align 1
  %v18 = getelementptr i8, ptr %16, i64 8
  store i32 0, ptr %v18, align 1
  %v23 = getelementptr i8, ptr %16, i64 16
  store i64 0, ptr %v23, align 1
  store i64 %26, ptr %v3, align 8
  %v26 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 %26, ptr %v26, align 8
  %v27 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v27, align 8
  %v28 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %26, ptr %v28, align 8
  store i64 6, ptr %1, align 8
  %27 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %28 = icmp eq ptr %27, null
  br i1 %28, label %29, label %30

29:                                               ; preds = %ok11
  call fastcc void @native_trap() #113
  unreachable

30:                                               ; preds = %ok11
  %31 = getelementptr inbounds nuw i8, ptr %27, i64 376
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %34, label %38

34:                                               ; preds = %44, %38, %30
  %35 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %36 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %27, i64 noundef 24, ptr noundef %35) #84
  %37 = icmp eq ptr %36, null
  br i1 %37, label %46, label %ok33

38:                                               ; preds = %30
  %39 = getelementptr inbounds nuw i8, ptr %27, i64 368
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = add i64 %40, 1
  store i64 %41, ptr %39, align 8
  %42 = urem i64 %41, %32
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %44, label %34

44:                                               ; preds = %38
  %45 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %27, ptr noundef %45) #84
  br label %34

46:                                               ; preds = %34
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok33:                                             ; preds = %34
  %47 = ptrtoint ptr %36 to i64
  store i64 118, ptr %36, align 1
  %v40 = getelementptr i8, ptr %36, i64 8
  store i64 %arg1, ptr %v40, align 1
  %v45 = getelementptr i8, ptr %36, i64 16
  store i64 %26, ptr %v45, align 1
  store i64 %47, ptr %v26, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v27, align 8
  store i64 %26, ptr %v28, align 8
  store i64 6, ptr %1, align 8
  %48 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %ok33
  call fastcc void @native_trap() #113
  unreachable

51:                                               ; preds = %ok33
  %52 = getelementptr inbounds nuw i8, ptr %48, i64 376
  %53 = load i64, ptr %52, align 8, !noundef !39
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %55, label %59

55:                                               ; preds = %65, %59, %51
  %56 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %57 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %48, i64 noundef 24, ptr noundef %56) #84
  %58 = icmp eq ptr %57, null
  br i1 %58, label %67, label %ok53

59:                                               ; preds = %51
  %60 = getelementptr inbounds nuw i8, ptr %48, i64 368
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = add i64 %61, 1
  store i64 %62, ptr %60, align 8
  %63 = urem i64 %62, %53
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %65, label %55

65:                                               ; preds = %59
  %66 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %48, ptr noundef %66) #84
  br label %55

67:                                               ; preds = %55
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok53:                                             ; preds = %55
  %68 = ptrtoint ptr %57 to i64
  store i64 162, ptr %57, align 1
  %v60 = getelementptr i8, ptr %57, i64 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v60, align 1
  %v65 = getelementptr i8, ptr %57, i64 16
  store i64 %47, ptr %v65, align 1
  store i64 %68, ptr %v23, align 1
  %v71 = load i64, ptr %v3, align 8
  %v72.not = icmp eq i64 %v71, 0
  br i1 %v72.not, label %trap73, label %ok74

trap73:                                           ; preds = %ok53
  call fastcc void @native_trap()
  unreachable

ok74:                                             ; preds = %ok53
  %v75 = inttoptr i64 %v71 to ptr
  %v76 = getelementptr i8, ptr %v75, i64 8
  store i32 1, ptr %v76, align 1
  %v77 = load i64, ptr %v3, align 8
  %v78.not = icmp eq i64 %v77, 0
  br i1 %v78.not, label %trap79, label %ok80

trap79:                                           ; preds = %ok74
  call fastcc void @native_trap()
  unreachable

ok80:                                             ; preds = %ok74
  %v81 = inttoptr i64 %v77 to ptr
  %v82 = getelementptr i8, ptr %v81, i64 8
  %v83 = load i32, ptr %v82, align 1
  %v84 = icmp eq i32 %v83, 0
  br i1 %v84, label %then88, label %ok93

then88:                                           ; preds = %ok80
  call fastcc void @native_trap()
  unreachable

ok93:                                             ; preds = %ok80
  %v95 = getelementptr i8, ptr %v81, i64 16
  %v96 = load i64, ptr %v95, align 1
  %v97.not = icmp eq i64 %v96, 0
  br i1 %v97.not, label %trap98, label %ok99

trap98:                                           ; preds = %ok93
  call fastcc void @native_trap()
  unreachable

ok99:                                             ; preds = %ok93
  store i64 %v96, ptr %v4, align 8
  %v103 = inttoptr i64 %v96 to ptr
  %v111 = getelementptr i8, ptr %v103, i64 8
  %v112 = load i64, ptr %v111, align 1
  %v113.not = icmp eq i64 %v112, 0
  br i1 %v113.not, label %trap114, label %ok115

trap114:                                          ; preds = %ok99
  call fastcc void @native_trap()
  unreachable

ok115:                                            ; preds = %ok99
  %v104 = getelementptr i8, ptr %v103, i64 16
  %v105 = load i64, ptr %v104, align 1
  %v116 = inttoptr i64 %v112 to ptr
  %v117 = getelementptr i8, ptr %v116, i64 8
  %v118 = load ptr, ptr %v117, align 1
  %69 = load i64, ptr %0, align 8, !noundef !39
  %70 = icmp eq i64 %69, 0
  br i1 %70, label %native_roots_leave.exit, label %71

71:                                               ; preds = %ok115
  %72 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %72, ptr @native_roots.0, align 8
  %73 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %74 = add i64 %73, -1
  store i64 %74, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %71, %ok115
  %v119 = tail call tailcc i64 %v118(i64 %v105, i64 0, i64 0)
  ret i64 %v119
}
