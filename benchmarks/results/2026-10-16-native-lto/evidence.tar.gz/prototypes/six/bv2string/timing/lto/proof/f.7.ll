define internal tailcc range(i64 0, 2) i64 @f.7(i64 %arg0, i64 %arg1, i64 %arg2) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [26 x i64] }, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v7 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v8 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v9 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v10 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v11 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  %v12 = getelementptr inbounds nuw i8, ptr %roots, i64 96
  %v13 = getelementptr inbounds nuw i8, ptr %roots, i64 104
  %v14 = getelementptr inbounds nuw i8, ptr %roots, i64 112
  %v15 = getelementptr inbounds nuw i8, ptr %roots, i64 120
  %v16 = getelementptr inbounds nuw i8, ptr %roots, i64 128
  %v17 = getelementptr inbounds nuw i8, ptr %roots, i64 136
  %v18 = getelementptr inbounds nuw i8, ptr %roots, i64 144
  %v19 = getelementptr inbounds nuw i8, ptr %roots, i64 152
  %v20 = getelementptr inbounds nuw i8, ptr %roots, i64 160
  %v21 = getelementptr inbounds nuw i8, ptr %roots, i64 168
  %v22 = getelementptr inbounds nuw i8, ptr %roots, i64 176
  %v23 = getelementptr inbounds nuw i8, ptr %roots, i64 184
  %v67 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %v111 = getelementptr inbounds nuw i8, ptr %roots, i64 192
  %v130 = getelementptr inbounds nuw i8, ptr %roots, i64 200
  %v150 = getelementptr inbounds nuw i8, ptr %roots, i64 208
  %v171 = getelementptr inbounds nuw i8, ptr %roots, i64 216
  %v193 = getelementptr inbounds nuw i8, ptr %roots, i64 224
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 26, ptr %0, align 8
  store i64 0, ptr %v67, align 8
  %1 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %1, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %2 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %3 = add i64 %2, 1
  store i64 %3, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %4 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %5 = call noundef i64 @llvm.umax.i64(i64 %3, i64 %4)
  store i64 %5, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %arg0, ptr %v1, align 8
  %v31.not1197 = icmp eq i64 %arg0, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(160) %v4, i8 0, i64 160, i1 false)
  br i1 %v31.not1197, label %trap32, label %ok33

trap32:                                           ; preds = %ok1903, %entry
  call fastcc void @native_trap()
  unreachable

ok33:                                             ; preds = %ok1903, %entry
  %6 = phi i64 [ %674, %ok1903 ], [ %2, %entry ]
  %7 = phi ptr [ %675, %ok1903 ], [ %1, %entry ]
  %arg2.tr1200 = phi i64 [ %slot1111.0, %ok1903 ], [ %arg2, %entry ]
  %arg1.tr1199 = phi i64 [ %v1908, %ok1903 ], [ %arg1, %entry ]
  %arg0.tr1198 = phi i64 [ %v1906, %ok1903 ], [ %arg0, %entry ]
  %v34 = inttoptr i64 %arg0.tr1198 to ptr
  %v35 = getelementptr i8, ptr %v34, i64 8
  %v36 = load i64, ptr %v35, align 1
  %v38 = icmp sgt i64 %v36, %arg1.tr1199
  br i1 %v38, label %then43, label %else42

then43:                                           ; preds = %ok33
  %v45.b = load i1, ptr @g.28, align 1
  br i1 %v45.b, label %block48, label %then50

then50:                                           ; preds = %then43
  call fastcc void @native_trap()
  unreachable

block48:                                          ; preds = %then43
  %v52.b = load i1, ptr @g.20, align 1
  br i1 %v52.b, label %block55, label %then57

then57:                                           ; preds = %block48
  call fastcc void @native_trap()
  unreachable

block55:                                          ; preds = %block48
  %v59 = load i64, ptr @g.19, align 8
  %v60.not = icmp eq i64 %v59, 0
  br i1 %v60.not, label %trap61, label %native_roots_leave.exit

trap61:                                           ; preds = %block55
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit:                          ; preds = %block55
  %v66 = load i64, ptr @g.27, align 8
  store i64 21, ptr %v67, align 8
  %v2.i = call i64 @benchmark_opaque_hide_i64(i64 %v66)
  %v69 = load i64, ptr %v1, align 8
  %v70.not = icmp eq i64 %v69, 0
  br i1 %v70.not, label %trap71, label %ok72

trap71:                                           ; preds = %native_roots_leave.exit
  call fastcc void @native_trap()
  unreachable

ok72:                                             ; preds = %native_roots_leave.exit
  %v76.b = load i1, ptr @g.30, align 1
  br i1 %v76.b, label %block79, label %then81

then81:                                           ; preds = %ok72
  call fastcc void @native_trap()
  unreachable

block79:                                          ; preds = %ok72
  %v83.b = load i1, ptr @g.20, align 1
  br i1 %v83.b, label %block86, label %then88

then88:                                           ; preds = %block79
  call fastcc void @native_trap()
  unreachable

block86:                                          ; preds = %block79
  %v90 = load i64, ptr @g.19, align 8
  %v91.not = icmp eq i64 %v90, 0
  br i1 %v91.not, label %trap92, label %native_roots_leave.exit1

trap92:                                           ; preds = %block86
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit1:                         ; preds = %block86
  %v97 = load i64, ptr @g.29, align 8
  store i64 21, ptr %v67, align 8
  %v2.i12 = call i64 @benchmark_opaque_hide_i64(i64 %v97)
  %v100.b = load i1, ptr @g.26, align 1
  br i1 %v100.b, label %block103, label %then105

then105:                                          ; preds = %native_roots_leave.exit1
  call fastcc void @native_trap()
  unreachable

block103:                                         ; preds = %native_roots_leave.exit1
  %v107 = load i64, ptr @g.25, align 8
  %v108.not = icmp eq i64 %v107, 0
  br i1 %v108.not, label %trap109, label %ok110

trap109:                                          ; preds = %block103
  call fastcc void @native_trap()
  unreachable

ok110:                                            ; preds = %block103
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %8 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %9 = icmp eq ptr %8, null
  br i1 %9, label %10, label %11

10:                                               ; preds = %ok110
  call fastcc void @native_trap() #113
  unreachable

11:                                               ; preds = %ok110
  %12 = getelementptr inbounds nuw i8, ptr %8, i64 376
  %13 = load i64, ptr %12, align 8, !noundef !39
  %14 = icmp eq i64 %13, 0
  br i1 %14, label %15, label %19

15:                                               ; preds = %25, %19, %11
  %16 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %17 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %8, i64 noundef 24, ptr noundef %16) #84
  %18 = icmp eq ptr %17, null
  br i1 %18, label %27, label %ok116

19:                                               ; preds = %11
  %20 = getelementptr inbounds nuw i8, ptr %8, i64 368
  %21 = load i64, ptr %20, align 8, !noundef !39
  %22 = add i64 %21, 1
  store i64 %22, ptr %20, align 8
  %23 = urem i64 %22, %13
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %25, label %15

25:                                               ; preds = %19
  %26 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %8, ptr noundef %26) #84
  br label %15

27:                                               ; preds = %15
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok116:                                            ; preds = %15
  %28 = ptrtoint ptr %17 to i64
  store i64 86, ptr %17, align 1
  %v123 = getelementptr i8, ptr %17, i64 8
  store i32 0, ptr %v123, align 1
  %v128 = getelementptr i8, ptr %17, i64 16
  store i64 0, ptr %v128, align 1
  store i64 %28, ptr %v12, align 8
  store i64 %28, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %29 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %30 = icmp eq ptr %29, null
  br i1 %30, label %31, label %32

31:                                               ; preds = %ok116
  call fastcc void @native_trap() #113
  unreachable

32:                                               ; preds = %ok116
  %33 = getelementptr inbounds nuw i8, ptr %29, i64 376
  %34 = load i64, ptr %33, align 8, !noundef !39
  %35 = icmp eq i64 %34, 0
  br i1 %35, label %36, label %40

36:                                               ; preds = %46, %40, %32
  %37 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %38 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %29, i64 noundef 24, ptr noundef %37) #84
  %39 = icmp eq ptr %38, null
  br i1 %39, label %48, label %ok135

40:                                               ; preds = %32
  %41 = getelementptr inbounds nuw i8, ptr %29, i64 368
  %42 = load i64, ptr %41, align 8, !noundef !39
  %43 = add i64 %42, 1
  store i64 %43, ptr %41, align 8
  %44 = urem i64 %43, %34
  %45 = icmp eq i64 %44, 0
  br i1 %45, label %46, label %36

46:                                               ; preds = %40
  %47 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %29, ptr noundef %47) #84
  br label %36

48:                                               ; preds = %36
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok135:                                            ; preds = %36
  %49 = ptrtoint ptr %38 to i64
  store i64 82, ptr %38, align 1
  %v142 = getelementptr i8, ptr %38, i64 8
  store i32 0, ptr %v142, align 1
  %v147 = getelementptr i8, ptr %38, i64 16
  store i64 0, ptr %v147, align 1
  store i64 %49, ptr %v15, align 8
  store i64 %49, ptr %v111, align 8
  store i64 %28, ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %50 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %51 = icmp eq ptr %50, null
  br i1 %51, label %52, label %53

52:                                               ; preds = %ok135
  call fastcc void @native_trap() #113
  unreachable

53:                                               ; preds = %ok135
  %54 = getelementptr inbounds nuw i8, ptr %50, i64 376
  %55 = load i64, ptr %54, align 8, !noundef !39
  %56 = icmp eq i64 %55, 0
  br i1 %56, label %57, label %61

57:                                               ; preds = %67, %61, %53
  %58 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %59 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %50, i64 noundef 24, ptr noundef %58) #84
  %60 = icmp eq ptr %59, null
  br i1 %60, label %69, label %ok155

61:                                               ; preds = %53
  %62 = getelementptr inbounds nuw i8, ptr %50, i64 368
  %63 = load i64, ptr %62, align 8, !noundef !39
  %64 = add i64 %63, 1
  store i64 %64, ptr %62, align 8
  %65 = urem i64 %64, %55
  %66 = icmp eq i64 %65, 0
  br i1 %66, label %67, label %57

67:                                               ; preds = %61
  %68 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %50, ptr noundef %68) #84
  br label %57

69:                                               ; preds = %57
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok155:                                            ; preds = %57
  %70 = ptrtoint ptr %59 to i64
  store i64 86, ptr %59, align 1
  %v162 = getelementptr i8, ptr %59, i64 8
  store i32 0, ptr %v162, align 1
  %v167 = getelementptr i8, ptr %59, i64 16
  store i64 0, ptr %v167, align 1
  store i64 %70, ptr %v13, align 8
  store i64 %70, ptr %v111, align 8
  store i64 %49, ptr %v130, align 8
  store i64 %28, ptr %v150, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v171, align 8
  store i64 25, ptr %v67, align 8
  %71 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %72 = icmp eq ptr %71, null
  br i1 %72, label %73, label %74

73:                                               ; preds = %ok155
  call fastcc void @native_trap() #113
  unreachable

74:                                               ; preds = %ok155
  %75 = getelementptr inbounds nuw i8, ptr %71, i64 376
  %76 = load i64, ptr %75, align 8, !noundef !39
  %77 = icmp eq i64 %76, 0
  br i1 %77, label %78, label %82

78:                                               ; preds = %88, %82, %74
  %79 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %80 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %71, i64 noundef 24, ptr noundef %79) #84
  %81 = icmp eq ptr %80, null
  br i1 %81, label %90, label %ok176

82:                                               ; preds = %74
  %83 = getelementptr inbounds nuw i8, ptr %71, i64 368
  %84 = load i64, ptr %83, align 8, !noundef !39
  %85 = add i64 %84, 1
  store i64 %85, ptr %83, align 8
  %86 = urem i64 %85, %76
  %87 = icmp eq i64 %86, 0
  br i1 %87, label %88, label %78

88:                                               ; preds = %82
  %89 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %71, ptr noundef %89) #84
  br label %78

90:                                               ; preds = %78
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok176:                                            ; preds = %78
  %91 = ptrtoint ptr %80 to i64
  store i64 86, ptr %80, align 1
  %v183 = getelementptr i8, ptr %80, i64 8
  store i32 0, ptr %v183, align 1
  %v188 = getelementptr i8, ptr %80, i64 16
  store i64 0, ptr %v188, align 1
  store i64 %91, ptr %v14, align 8
  store i64 %91, ptr %v111, align 8
  store i64 %70, ptr %v130, align 8
  store i64 %49, ptr %v150, align 8
  store i64 %28, ptr %v171, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v193, align 8
  store i64 26, ptr %v67, align 8
  %92 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %93 = icmp eq ptr %92, null
  br i1 %93, label %94, label %95

94:                                               ; preds = %ok176
  call fastcc void @native_trap() #113
  unreachable

95:                                               ; preds = %ok176
  %96 = getelementptr inbounds nuw i8, ptr %92, i64 376
  %97 = load i64, ptr %96, align 8, !noundef !39
  %98 = icmp eq i64 %97, 0
  br i1 %98, label %99, label %103

99:                                               ; preds = %109, %103, %95
  %100 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %101 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %92, i64 noundef 40, ptr noundef %100) #84
  %102 = icmp eq ptr %101, null
  br i1 %102, label %111, label %ok198

103:                                              ; preds = %95
  %104 = getelementptr inbounds nuw i8, ptr %92, i64 368
  %105 = load i64, ptr %104, align 8, !noundef !39
  %106 = add i64 %105, 1
  store i64 %106, ptr %104, align 8
  %107 = urem i64 %106, %97
  %108 = icmp eq i64 %107, 0
  br i1 %108, label %109, label %99

109:                                              ; preds = %103
  %110 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %92, ptr noundef %110) #84
  br label %99

111:                                              ; preds = %99
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok198:                                            ; preds = %99
  %112 = ptrtoint ptr %101 to i64
  store i64 62, ptr %101, align 1
  %v205 = getelementptr i8, ptr %101, i64 8
  store i64 %28, ptr %v205, align 1
  %v210 = getelementptr i8, ptr %101, i64 16
  store i64 %49, ptr %v210, align 1
  %v215 = getelementptr i8, ptr %101, i64 24
  store i64 %70, ptr %v215, align 1
  %v220 = getelementptr i8, ptr %101, i64 32
  store i64 %91, ptr %v220, align 1
  store i64 %112, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %113 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %114 = icmp eq ptr %113, null
  br i1 %114, label %115, label %116

115:                                              ; preds = %ok198
  call fastcc void @native_trap() #113
  unreachable

116:                                              ; preds = %ok198
  %117 = getelementptr inbounds nuw i8, ptr %113, i64 376
  %118 = load i64, ptr %117, align 8, !noundef !39
  %119 = icmp eq i64 %118, 0
  br i1 %119, label %120, label %124

120:                                              ; preds = %130, %124, %116
  %121 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %122 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %113, i64 noundef 24, ptr noundef %121) #84
  %123 = icmp eq ptr %122, null
  br i1 %123, label %132, label %ok227

124:                                              ; preds = %116
  %125 = getelementptr inbounds nuw i8, ptr %113, i64 368
  %126 = load i64, ptr %125, align 8, !noundef !39
  %127 = add i64 %126, 1
  store i64 %127, ptr %125, align 8
  %128 = urem i64 %127, %118
  %129 = icmp eq i64 %128, 0
  br i1 %129, label %130, label %120

130:                                              ; preds = %124
  %131 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %113, ptr noundef %131) #84
  br label %120

132:                                              ; preds = %120
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok227:                                            ; preds = %120
  %133 = ptrtoint ptr %122 to i64
  store i64 146, ptr %122, align 1
  %v234 = getelementptr i8, ptr %122, i64 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v234, align 1
  %v239 = getelementptr i8, ptr %122, i64 16
  store i64 %112, ptr %v239, align 1
  store i64 %133, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %134 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %135 = icmp eq ptr %134, null
  br i1 %135, label %136, label %137

136:                                              ; preds = %ok227
  call fastcc void @native_trap() #113
  unreachable

137:                                              ; preds = %ok227
  %138 = getelementptr inbounds nuw i8, ptr %134, i64 376
  %139 = load i64, ptr %138, align 8, !noundef !39
  %140 = icmp eq i64 %139, 0
  br i1 %140, label %141, label %145

141:                                              ; preds = %151, %145, %137
  %142 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %143 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %134, i64 noundef 16, ptr noundef %142) #84
  %144 = icmp eq ptr %143, null
  br i1 %144, label %153, label %ok245

145:                                              ; preds = %137
  %146 = getelementptr inbounds nuw i8, ptr %134, i64 368
  %147 = load i64, ptr %146, align 8, !noundef !39
  %148 = add i64 %147, 1
  store i64 %148, ptr %146, align 8
  %149 = urem i64 %148, %139
  %150 = icmp eq i64 %149, 0
  br i1 %150, label %151, label %141

151:                                              ; preds = %145
  %152 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %134, ptr noundef %152) #84
  br label %141

153:                                              ; preds = %141
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok245:                                            ; preds = %141
  %154 = ptrtoint ptr %143 to i64
  store i64 78, ptr %143, align 1
  %v252 = getelementptr i8, ptr %143, i64 8
  store i64 %133, ptr %v252, align 1
  store i64 %154, ptr %v16, align 8
  %v253 = load i64, ptr %v12, align 8
  %v254.not = icmp eq i64 %v253, 0
  br i1 %v254.not, label %trap255, label %ok256

trap255:                                          ; preds = %ok245
  call fastcc void @native_trap()
  unreachable

ok256:                                            ; preds = %ok245
  %v257 = inttoptr i64 %v253 to ptr
  %v258 = getelementptr i8, ptr %v257, i64 16
  store i64 701, ptr %v258, align 1
  %v259 = load i64, ptr %v12, align 8
  %v260.not = icmp eq i64 %v259, 0
  br i1 %v260.not, label %trap261, label %ok262

trap261:                                          ; preds = %ok256
  call fastcc void @native_trap()
  unreachable

ok262:                                            ; preds = %ok256
  %v263 = inttoptr i64 %v259 to ptr
  %v264 = getelementptr i8, ptr %v263, i64 8
  store i32 1, ptr %v264, align 1
  %v265 = load i64, ptr %v15, align 8
  store i64 %v265, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %155 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %156 = icmp eq ptr %155, null
  br i1 %156, label %157, label %158

157:                                              ; preds = %ok262
  call fastcc void @native_trap() #113
  unreachable

158:                                              ; preds = %ok262
  %159 = getelementptr inbounds nuw i8, ptr %155, i64 376
  %160 = load i64, ptr %159, align 8, !noundef !39
  %161 = icmp eq i64 %160, 0
  br i1 %161, label %162, label %166

162:                                              ; preds = %172, %166, %158
  %163 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %164 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %155, i64 noundef 16, ptr noundef %163) #84
  %165 = icmp eq ptr %164, null
  br i1 %165, label %174, label %ok271

166:                                              ; preds = %158
  %167 = getelementptr inbounds nuw i8, ptr %155, i64 368
  %168 = load i64, ptr %167, align 8, !noundef !39
  %169 = add i64 %168, 1
  store i64 %169, ptr %167, align 8
  %170 = urem i64 %169, %160
  %171 = icmp eq i64 %170, 0
  br i1 %171, label %172, label %162

172:                                              ; preds = %166
  %173 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %155, ptr noundef %173) #84
  br label %162

174:                                              ; preds = %162
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok271:                                            ; preds = %162
  store i64 58, ptr %164, align 1
  %v278 = getelementptr i8, ptr %164, i64 8
  store i64 1, ptr %v278, align 1
  %v279.not = icmp eq i64 %v265, 0
  br i1 %v279.not, label %trap280, label %ok281

trap280:                                          ; preds = %ok271
  call fastcc void @native_trap()
  unreachable

ok281:                                            ; preds = %ok271
  %175 = ptrtoint ptr %164 to i64
  %v282 = inttoptr i64 %v265 to ptr
  %v283 = getelementptr i8, ptr %v282, i64 16
  store i64 %175, ptr %v283, align 1
  %v284 = load i64, ptr %v15, align 8
  %v285.not = icmp eq i64 %v284, 0
  br i1 %v285.not, label %trap286, label %ok287

trap286:                                          ; preds = %ok281
  call fastcc void @native_trap()
  unreachable

ok287:                                            ; preds = %ok281
  %v288 = inttoptr i64 %v284 to ptr
  %v289 = getelementptr i8, ptr %v288, i64 8
  store i32 1, ptr %v289, align 1
  %v290 = load i64, ptr %v13, align 8
  %v291.not = icmp eq i64 %v290, 0
  br i1 %v291.not, label %trap292, label %ok293

trap292:                                          ; preds = %ok287
  call fastcc void @native_trap()
  unreachable

ok293:                                            ; preds = %ok287
  %v294 = inttoptr i64 %v290 to ptr
  %v295 = getelementptr i8, ptr %v294, i64 16
  store i64 743483, ptr %v295, align 1
  %v296 = load i64, ptr %v13, align 8
  %v297.not = icmp eq i64 %v296, 0
  br i1 %v297.not, label %trap298, label %ok299

trap298:                                          ; preds = %ok293
  call fastcc void @native_trap()
  unreachable

ok299:                                            ; preds = %ok293
  %v300 = inttoptr i64 %v296 to ptr
  %v301 = getelementptr i8, ptr %v300, i64 8
  store i32 1, ptr %v301, align 1
  %v302 = load i64, ptr %v14, align 8
  %v303.not = icmp eq i64 %v302, 0
  br i1 %v303.not, label %trap304, label %ok305

trap304:                                          ; preds = %ok299
  call fastcc void @native_trap()
  unreachable

ok305:                                            ; preds = %ok299
  %v306 = inttoptr i64 %v302 to ptr
  %v307 = getelementptr i8, ptr %v306, i64 16
  store i64 524287, ptr %v307, align 1
  %v308 = load i64, ptr %v14, align 8
  %v309.not = icmp eq i64 %v308, 0
  br i1 %v309.not, label %trap310, label %ok311

trap310:                                          ; preds = %ok305
  call fastcc void @native_trap()
  unreachable

ok311:                                            ; preds = %ok305
  %v312 = inttoptr i64 %v308 to ptr
  %v313 = getelementptr i8, ptr %v312, i64 8
  store i32 1, ptr %v313, align 1
  store i64 21, ptr %v67, align 8
  %176 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %177 = icmp eq ptr %176, null
  br i1 %177, label %178, label %179

178:                                              ; preds = %ok311
  call fastcc void @native_trap() #113
  unreachable

179:                                              ; preds = %ok311
  %180 = getelementptr inbounds nuw i8, ptr %176, i64 376
  %181 = load i64, ptr %180, align 8, !noundef !39
  %182 = icmp eq i64 %181, 0
  br i1 %182, label %183, label %187

183:                                              ; preds = %193, %187, %179
  %184 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %185 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %176, i64 noundef 24, ptr noundef %184) #84
  %186 = icmp eq ptr %185, null
  br i1 %186, label %195, label %ok318

187:                                              ; preds = %179
  %188 = getelementptr inbounds nuw i8, ptr %176, i64 368
  %189 = load i64, ptr %188, align 8, !noundef !39
  %190 = add i64 %189, 1
  store i64 %190, ptr %188, align 8
  %191 = urem i64 %190, %181
  %192 = icmp eq i64 %191, 0
  br i1 %192, label %193, label %183

193:                                              ; preds = %187
  %194 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %176, ptr noundef %194) #84
  br label %183

195:                                              ; preds = %183
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok318:                                            ; preds = %183
  %196 = ptrtoint ptr %185 to i64
  store i64 90, ptr %185, align 1
  %v325 = getelementptr i8, ptr %185, i64 8
  store i32 0, ptr %v325, align 1
  %v330 = getelementptr i8, ptr %185, i64 16
  store i64 0, ptr %v330, align 1
  store i64 %196, ptr %v11, align 8
  %v331 = load i64, ptr %v16, align 8
  store i64 %196, ptr %v111, align 8
  store i64 %v331, ptr %v130, align 8
  store i64 %196, ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %197 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %198 = icmp eq ptr %197, null
  br i1 %198, label %199, label %200

199:                                              ; preds = %ok318
  call fastcc void @native_trap() #113
  unreachable

200:                                              ; preds = %ok318
  %201 = getelementptr inbounds nuw i8, ptr %197, i64 376
  %202 = load i64, ptr %201, align 8, !noundef !39
  %203 = icmp eq i64 %202, 0
  br i1 %203, label %204, label %208

204:                                              ; preds = %214, %208, %200
  %205 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %206 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %197, i64 noundef 24, ptr noundef %205) #84
  %207 = icmp eq ptr %206, null
  br i1 %207, label %216, label %ok340

208:                                              ; preds = %200
  %209 = getelementptr inbounds nuw i8, ptr %197, i64 368
  %210 = load i64, ptr %209, align 8, !noundef !39
  %211 = add i64 %210, 1
  store i64 %211, ptr %209, align 8
  %212 = urem i64 %211, %202
  %213 = icmp eq i64 %212, 0
  br i1 %213, label %214, label %204

214:                                              ; preds = %208
  %215 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %197, ptr noundef %215) #84
  br label %204

216:                                              ; preds = %204
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok340:                                            ; preds = %204
  %217 = ptrtoint ptr %206 to i64
  store i64 54, ptr %206, align 1
  %v347 = getelementptr i8, ptr %206, i64 8
  store i64 %v331, ptr %v347, align 1
  %v352 = getelementptr i8, ptr %206, i64 16
  store i64 %196, ptr %v352, align 1
  store i64 %217, ptr %v111, align 8
  store i64 %196, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %218 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %219 = icmp eq ptr %218, null
  br i1 %219, label %220, label %221

220:                                              ; preds = %ok340
  call fastcc void @native_trap() #113
  unreachable

221:                                              ; preds = %ok340
  %222 = getelementptr inbounds nuw i8, ptr %218, i64 376
  %223 = load i64, ptr %222, align 8, !noundef !39
  %224 = icmp eq i64 %223, 0
  br i1 %224, label %225, label %229

225:                                              ; preds = %235, %229, %221
  %226 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %227 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %218, i64 noundef 16, ptr noundef %226) #84
  %228 = icmp eq ptr %227, null
  br i1 %228, label %237, label %ok359

229:                                              ; preds = %221
  %230 = getelementptr inbounds nuw i8, ptr %218, i64 368
  %231 = load i64, ptr %230, align 8, !noundef !39
  %232 = add i64 %231, 1
  store i64 %232, ptr %230, align 8
  %233 = urem i64 %232, %223
  %234 = icmp eq i64 %233, 0
  br i1 %234, label %235, label %225

235:                                              ; preds = %229
  %236 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %218, ptr noundef %236) #84
  br label %225

237:                                              ; preds = %225
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok359:                                            ; preds = %225
  %238 = ptrtoint ptr %227 to i64
  store i64 50, ptr %227, align 1
  %v366 = getelementptr i8, ptr %227, i64 8
  store i64 %217, ptr %v366, align 1
  store i64 %238, ptr %v330, align 1
  %v372 = load i64, ptr %v11, align 8
  %v373.not = icmp eq i64 %v372, 0
  br i1 %v373.not, label %trap374, label %ok375

trap374:                                          ; preds = %ok359
  call fastcc void @native_trap()
  unreachable

ok375:                                            ; preds = %ok359
  %v376 = inttoptr i64 %v372 to ptr
  %v377 = getelementptr i8, ptr %v376, i64 8
  store i32 1, ptr %v377, align 1
  %v378 = load i64, ptr %v16, align 8
  %v379 = load i64, ptr %v11, align 8
  store i64 %v379, ptr %v111, align 8
  store i64 %v378, ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.14 to i64), ptr %v150, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v171, align 8
  store i64 25, ptr %v67, align 8
  %239 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %240 = icmp eq ptr %239, null
  br i1 %240, label %241, label %242

241:                                              ; preds = %ok375
  call fastcc void @native_trap() #113
  unreachable

242:                                              ; preds = %ok375
  %243 = getelementptr inbounds nuw i8, ptr %239, i64 376
  %244 = load i64, ptr %243, align 8, !noundef !39
  %245 = icmp eq i64 %244, 0
  br i1 %245, label %246, label %250

246:                                              ; preds = %256, %250, %242
  %247 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %248 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %239, i64 noundef 24, ptr noundef %247) #84
  %249 = icmp eq ptr %248, null
  br i1 %249, label %258, label %ok388

250:                                              ; preds = %242
  %251 = getelementptr inbounds nuw i8, ptr %239, i64 368
  %252 = load i64, ptr %251, align 8, !noundef !39
  %253 = add i64 %252, 1
  store i64 %253, ptr %251, align 8
  %254 = urem i64 %253, %244
  %255 = icmp eq i64 %254, 0
  br i1 %255, label %256, label %246

256:                                              ; preds = %250
  %257 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %239, ptr noundef %257) #84
  br label %246

258:                                              ; preds = %246
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok388:                                            ; preds = %246
  %259 = ptrtoint ptr %248 to i64
  store i64 46, ptr %248, align 1
  %v395 = getelementptr i8, ptr %248, i64 8
  store i64 %v378, ptr %v395, align 1
  %v400 = getelementptr i8, ptr %248, i64 16
  store i64 %v379, ptr %v400, align 1
  store i64 %259, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.14 to i64), ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %260 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %261 = icmp eq ptr %260, null
  br i1 %261, label %262, label %263

262:                                              ; preds = %ok388
  call fastcc void @native_trap() #113
  unreachable

263:                                              ; preds = %ok388
  %264 = getelementptr inbounds nuw i8, ptr %260, i64 376
  %265 = load i64, ptr %264, align 8, !noundef !39
  %266 = icmp eq i64 %265, 0
  br i1 %266, label %267, label %271

267:                                              ; preds = %277, %271, %263
  %268 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %269 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %260, i64 noundef 24, ptr noundef %268) #84
  %270 = icmp eq ptr %269, null
  br i1 %270, label %279, label %ok408

271:                                              ; preds = %263
  %272 = getelementptr inbounds nuw i8, ptr %260, i64 368
  %273 = load i64, ptr %272, align 8, !noundef !39
  %274 = add i64 %273, 1
  store i64 %274, ptr %272, align 8
  %275 = urem i64 %274, %265
  %276 = icmp eq i64 %275, 0
  br i1 %276, label %277, label %267

277:                                              ; preds = %271
  %278 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %260, ptr noundef %278) #84
  br label %267

279:                                              ; preds = %267
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok408:                                            ; preds = %267
  %280 = ptrtoint ptr %269 to i64
  store i64 146, ptr %269, align 1
  %v415 = getelementptr i8, ptr %269, i64 8
  store i64 ptrtoint (ptr @ref.14 to i64), ptr %v415, align 1
  %v420 = getelementptr i8, ptr %269, i64 16
  store i64 %259, ptr %v420, align 1
  store i64 %280, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %281 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %282 = icmp eq ptr %281, null
  br i1 %282, label %283, label %284

283:                                              ; preds = %ok408
  call fastcc void @native_trap() #113
  unreachable

284:                                              ; preds = %ok408
  %285 = getelementptr inbounds nuw i8, ptr %281, i64 376
  %286 = load i64, ptr %285, align 8, !noundef !39
  %287 = icmp eq i64 %286, 0
  br i1 %287, label %288, label %292

288:                                              ; preds = %298, %292, %284
  %289 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %290 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %281, i64 noundef 16, ptr noundef %289) #84
  %291 = icmp eq ptr %290, null
  br i1 %291, label %300, label %ok427

292:                                              ; preds = %284
  %293 = getelementptr inbounds nuw i8, ptr %281, i64 368
  %294 = load i64, ptr %293, align 8, !noundef !39
  %295 = add i64 %294, 1
  store i64 %295, ptr %293, align 8
  %296 = urem i64 %295, %286
  %297 = icmp eq i64 %296, 0
  br i1 %297, label %298, label %288

298:                                              ; preds = %292
  %299 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %281, ptr noundef %299) #84
  br label %288

300:                                              ; preds = %288
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok427:                                            ; preds = %288
  %301 = ptrtoint ptr %290 to i64
  store i64 78, ptr %290, align 1
  %v434 = getelementptr i8, ptr %290, i64 8
  store i64 %280, ptr %v434, align 1
  store i64 %301, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %302 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %303 = icmp eq ptr %302, null
  br i1 %303, label %304, label %305

304:                                              ; preds = %ok427
  call fastcc void @native_trap() #113
  unreachable

305:                                              ; preds = %ok427
  %306 = getelementptr inbounds nuw i8, ptr %302, i64 376
  %307 = load i64, ptr %306, align 8, !noundef !39
  %308 = icmp eq i64 %307, 0
  br i1 %308, label %309, label %313

309:                                              ; preds = %319, %313, %305
  %310 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %311 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %302, i64 noundef 16, ptr noundef %310) #84
  %312 = icmp eq ptr %311, null
  br i1 %312, label %321, label %ok441

313:                                              ; preds = %305
  %314 = getelementptr inbounds nuw i8, ptr %302, i64 368
  %315 = load i64, ptr %314, align 8, !noundef !39
  %316 = add i64 %315, 1
  store i64 %316, ptr %314, align 8
  %317 = urem i64 %316, %307
  %318 = icmp eq i64 %317, 0
  br i1 %318, label %319, label %309

319:                                              ; preds = %313
  %320 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %302, ptr noundef %320) #84
  br label %309

321:                                              ; preds = %309
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok441:                                            ; preds = %309
  %322 = ptrtoint ptr %311 to i64
  store i64 74, ptr %311, align 1
  %v448 = getelementptr i8, ptr %311, i64 8
  store i64 %301, ptr %v448, align 1
  store i64 %322, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %323 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %324 = icmp eq ptr %323, null
  br i1 %324, label %325, label %326

325:                                              ; preds = %ok441
  call fastcc void @native_trap() #113
  unreachable

326:                                              ; preds = %ok441
  %327 = getelementptr inbounds nuw i8, ptr %323, i64 376
  %328 = load i64, ptr %327, align 8, !noundef !39
  %329 = icmp eq i64 %328, 0
  br i1 %329, label %330, label %334

330:                                              ; preds = %340, %334, %326
  %331 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %332 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %323, i64 noundef 24, ptr noundef %331) #84
  %333 = icmp eq ptr %332, null
  br i1 %333, label %342, label %ok455

334:                                              ; preds = %326
  %335 = getelementptr inbounds nuw i8, ptr %323, i64 368
  %336 = load i64, ptr %335, align 8, !noundef !39
  %337 = add i64 %336, 1
  store i64 %337, ptr %335, align 8
  %338 = urem i64 %337, %328
  %339 = icmp eq i64 %338, 0
  br i1 %339, label %340, label %330

340:                                              ; preds = %334
  %341 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %323, ptr noundef %341) #84
  br label %330

342:                                              ; preds = %330
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok455:                                            ; preds = %330
  %343 = ptrtoint ptr %332 to i64
  store i64 194, ptr %332, align 1
  %v462 = getelementptr i8, ptr %332, i64 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v462, align 1
  %v467 = getelementptr i8, ptr %332, i64 16
  store i64 %322, ptr %v467, align 1
  store i64 %343, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %344 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %345 = icmp eq ptr %344, null
  br i1 %345, label %346, label %347

346:                                              ; preds = %ok455
  call fastcc void @native_trap() #113
  unreachable

347:                                              ; preds = %ok455
  %348 = getelementptr inbounds nuw i8, ptr %344, i64 376
  %349 = load i64, ptr %348, align 8, !noundef !39
  %350 = icmp eq i64 %349, 0
  br i1 %350, label %351, label %355

351:                                              ; preds = %361, %355, %347
  %352 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %353 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %344, i64 noundef 24, ptr noundef %352) #84
  %354 = icmp eq ptr %353, null
  br i1 %354, label %363, label %ok473

355:                                              ; preds = %347
  %356 = getelementptr inbounds nuw i8, ptr %344, i64 368
  %357 = load i64, ptr %356, align 8, !noundef !39
  %358 = add i64 %357, 1
  store i64 %358, ptr %356, align 8
  %359 = urem i64 %358, %349
  %360 = icmp eq i64 %359, 0
  br i1 %360, label %361, label %351

361:                                              ; preds = %355
  %362 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %344, ptr noundef %362) #84
  br label %351

363:                                              ; preds = %351
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok473:                                            ; preds = %351
  %364 = ptrtoint ptr %353 to i64
  store i64 102, ptr %353, align 1
  %v480 = getelementptr i8, ptr %353, i64 8
  store i32 1, ptr %v480, align 1
  %v485 = getelementptr i8, ptr %353, i64 16
  store i64 %343, ptr %v485, align 1
  store i64 %364, ptr %v7, align 8
  %v491 = load i32, ptr %v480, align 1
  %v492 = icmp eq i32 %v491, 0
  br i1 %v492, label %then496, label %ok501

then496:                                          ; preds = %ok473
  call fastcc void @native_trap()
  unreachable

ok501:                                            ; preds = %ok473
  %v504 = load i64, ptr %v485, align 1
  %v505.not = icmp eq i64 %v504, 0
  br i1 %v505.not, label %trap506, label %ok507

trap506:                                          ; preds = %ok501
  call fastcc void @native_trap()
  unreachable

ok507:                                            ; preds = %ok501
  %v508 = inttoptr i64 %v504 to ptr
  %v509 = getelementptr i8, ptr %v508, i64 16
  %v510 = load i64, ptr %v509, align 1
  %365 = icmp ne i64 %v510, 0
  %366 = and i64 %v510, 1
  %.not.i = icmp eq i64 %366, 0
  %or.cond = and i1 %365, %.not.i
  br i1 %or.cond, label %367, label %trap513

367:                                              ; preds = %ok507
  %368 = inttoptr i64 %v510 to ptr
  %369 = load i64, ptr %368, align 8, !noundef !39
  %370 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %371 = icmp eq ptr %370, null
  br i1 %371, label %384, label %372

372:                                              ; preds = %367
  switch i64 %369, label %373 [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

373:                                              ; preds = %372
  %374 = getelementptr inbounds nuw i8, ptr %370, i64 360
  %375 = load i64, ptr %374, align 8, !noundef !39
  %376 = lshr i64 %369, 2
  %377 = add nsw i64 %376, -1
  %378 = icmp ult i64 %377, %375
  br i1 %378, label %379, label %.loopexit

379:                                              ; preds = %373
  %380 = getelementptr inbounds nuw i8, ptr %370, i64 352
  %381 = load ptr, ptr %380, align 8, !nonnull !39, !noundef !39
  %382 = getelementptr inbounds nuw i64, ptr %381, i64 %377
  %383 = load i64, ptr %382, align 8, !noundef !39
  switch i64 %383, label %.preheader [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

384:                                              ; preds = %367
  call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %389, %379
  %385 = phi i64 [ %391, %389 ], [ %383, %379 ]
  %386 = lshr i64 %385, 2
  %387 = add nsw i64 %386, -1
  %388 = icmp ult i64 %387, %375
  br i1 %388, label %389, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %373
  call fastcc void @native_trap() #113
  unreachable

389:                                              ; preds = %.preheader
  %390 = getelementptr inbounds nuw i64, ptr %381, i64 %387
  %391 = load i64, ptr %390, align 8, !noundef !39
  switch i64 %391, label %.preheader [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %389, %389, %379, %379, %372, %372
  %.in1255 = phi i64 [ %369, %372 ], [ %383, %379 ], [ %383, %379 ], [ %369, %372 ], [ %391, %389 ], [ %391, %389 ]
  %392 = icmp eq i64 %.in1255, 74
  br i1 %392, label %ok514, label %trap513

trap513:                                          ; preds = %native_ref_test.exit, %ok507
  call fastcc void @native_trap()
  unreachable

ok514:                                            ; preds = %native_ref_test.exit
  store i64 %v510, ptr %v19, align 8
  %v519 = getelementptr i8, ptr %368, i64 8
  %v520 = load i64, ptr %v519, align 1
  %v521.not = icmp eq i64 %v520, 0
  br i1 %v521.not, label %trap522, label %ok523

trap522:                                          ; preds = %ok514
  call fastcc void @native_trap()
  unreachable

ok523:                                            ; preds = %ok514
  %v524 = inttoptr i64 %v520 to ptr
  %v525 = getelementptr i8, ptr %v524, i64 8
  %v526 = load i64, ptr %v525, align 1
  store i64 %v526, ptr %v20, align 8
  %v527.not = icmp eq i64 %v526, 0
  br i1 %v527.not, label %trap528, label %ok529

trap528:                                          ; preds = %ok523
  call fastcc void @native_trap()
  unreachable

ok529:                                            ; preds = %ok523
  %v530 = inttoptr i64 %v526 to ptr
  %v538 = getelementptr i8, ptr %v530, i64 8
  %v539 = load i64, ptr %v538, align 1
  %v540.not = icmp eq i64 %v539, 0
  br i1 %v540.not, label %trap541, label %ok542

trap541:                                          ; preds = %ok529
  call fastcc void @native_trap()
  unreachable

ok542:                                            ; preds = %ok529
  %v531 = getelementptr i8, ptr %v530, i64 16
  %v532 = load i64, ptr %v531, align 1
  %v543 = inttoptr i64 %v539 to ptr
  %v544 = getelementptr i8, ptr %v543, i64 8
  %v545 = load ptr, ptr %v544, align 1
  store i64 %v532, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v548 = call tailcc i64 %v545(i64 %v532, i64 10)
  %v549.b = load i1, ptr @g.4, align 1
  br i1 %v549.b, label %block552, label %then554

then554:                                          ; preds = %ok542
  call fastcc void @native_trap()
  unreachable

block552:                                         ; preds = %ok542
  %v556 = load i64, ptr @g.3, align 8
  %v557.not = icmp eq i64 %v556, 0
  br i1 %v557.not, label %trap558, label %ok559

trap558:                                          ; preds = %block552
  call fastcc void @native_trap()
  unreachable

ok559:                                            ; preds = %block552
  %v564 = icmp ugt i64 %v548, 4294967295
  br i1 %v564, label %then568, label %block566

then568:                                          ; preds = %ok559
  call fastcc void @native_trap()
  unreachable

block566:                                         ; preds = %ok559
  store i64 21, ptr %v67, align 8
  %393 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %394 = icmp eq ptr %393, null
  br i1 %394, label %395, label %396

395:                                              ; preds = %block566
  call fastcc void @native_trap() #113
  unreachable

396:                                              ; preds = %block566
  %397 = getelementptr inbounds nuw i8, ptr %393, i64 376
  %398 = load i64, ptr %397, align 8, !noundef !39
  %399 = icmp eq i64 %398, 0
  br i1 %399, label %400, label %404

400:                                              ; preds = %410, %404, %396
  %401 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %402 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %393, i64 noundef 24, ptr noundef %401) #84
  %403 = icmp eq ptr %402, null
  br i1 %403, label %412, label %ok574

404:                                              ; preds = %396
  %405 = getelementptr inbounds nuw i8, ptr %393, i64 368
  %406 = load i64, ptr %405, align 8, !noundef !39
  %407 = add i64 %406, 1
  store i64 %407, ptr %405, align 8
  %408 = urem i64 %407, %398
  %409 = icmp eq i64 %408, 0
  br i1 %409, label %410, label %400

410:                                              ; preds = %404
  %411 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %393, ptr noundef %411) #84
  br label %400

412:                                              ; preds = %400
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok574:                                            ; preds = %400
  %413 = ptrtoint ptr %402 to i64
  store i64 102, ptr %402, align 1
  %v581 = getelementptr i8, ptr %402, i64 8
  store i32 0, ptr %v581, align 1
  %v586 = getelementptr i8, ptr %402, i64 16
  store i64 0, ptr %v586, align 1
  store i64 %413, ptr %v6, align 8
  %v587 = load i64, ptr %v19, align 8
  %v588.not = icmp eq i64 %v587, 0
  br i1 %v588.not, label %trap589, label %ok590

trap589:                                          ; preds = %ok574
  call fastcc void @native_trap()
  unreachable

ok590:                                            ; preds = %ok574
  %v591 = inttoptr i64 %v587 to ptr
  %v592 = getelementptr i8, ptr %v591, i64 8
  %v593 = load i64, ptr %v592, align 1
  %v596 = trunc nuw i64 %v548 to i32
  store i64 %v593, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v130, align 8
  store i64 %413, ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %v602 = call fastcc i64 @native_array_new(i32 %v596)
  store i64 %v602, ptr %v111, align 8
  store i64 %v593, ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v150, align 8
  store i64 %413, ptr %v171, align 8
  store i64 25, ptr %v67, align 8
  %414 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %415 = icmp eq ptr %414, null
  br i1 %415, label %416, label %417

416:                                              ; preds = %ok590
  call fastcc void @native_trap() #113
  unreachable

417:                                              ; preds = %ok590
  %418 = getelementptr inbounds nuw i8, ptr %414, i64 376
  %419 = load i64, ptr %418, align 8, !noundef !39
  %420 = icmp eq i64 %419, 0
  br i1 %420, label %421, label %425

421:                                              ; preds = %431, %425, %417
  %422 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %423 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %414, i64 noundef 16, ptr noundef %422) #84
  %424 = icmp eq ptr %423, null
  br i1 %424, label %433, label %ok611

425:                                              ; preds = %417
  %426 = getelementptr inbounds nuw i8, ptr %414, i64 368
  %427 = load i64, ptr %426, align 8, !noundef !39
  %428 = add i64 %427, 1
  store i64 %428, ptr %426, align 8
  %429 = urem i64 %428, %419
  %430 = icmp eq i64 %429, 0
  br i1 %430, label %431, label %421

431:                                              ; preds = %425
  %432 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %414, ptr noundef %432) #84
  br label %421

433:                                              ; preds = %421
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok611:                                            ; preds = %421
  %434 = ptrtoint ptr %423 to i64
  store i64 130, ptr %423, align 1
  %v618 = getelementptr i8, ptr %423, i64 8
  store i64 %v602, ptr %v618, align 1
  %v619 = load i64, ptr %v6, align 8
  store i64 %v619, ptr %v111, align 8
  store i64 %434, ptr %v130, align 8
  store i64 %v593, ptr %v150, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v171, align 8
  store i64 %413, ptr %v193, align 8
  store i64 26, ptr %v67, align 8
  %435 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %436 = icmp eq ptr %435, null
  br i1 %436, label %437, label %438

437:                                              ; preds = %ok611
  call fastcc void @native_trap() #113
  unreachable

438:                                              ; preds = %ok611
  %439 = getelementptr inbounds nuw i8, ptr %435, i64 376
  %440 = load i64, ptr %439, align 8, !noundef !39
  %441 = icmp eq i64 %440, 0
  br i1 %441, label %442, label %446

442:                                              ; preds = %452, %446, %438
  %443 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %444 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %435, i64 noundef 40, ptr noundef %443) #84
  %445 = icmp eq ptr %444, null
  br i1 %445, label %454, label %ok629

446:                                              ; preds = %438
  %447 = getelementptr inbounds nuw i8, ptr %435, i64 368
  %448 = load i64, ptr %447, align 8, !noundef !39
  %449 = add i64 %448, 1
  store i64 %449, ptr %447, align 8
  %450 = urem i64 %449, %440
  %451 = icmp eq i64 %450, 0
  br i1 %451, label %452, label %442

452:                                              ; preds = %446
  %453 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %435, ptr noundef %453) #84
  br label %442

454:                                              ; preds = %442
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok629:                                            ; preds = %442
  %455 = ptrtoint ptr %444 to i64
  store i64 42, ptr %444, align 1
  %v636 = getelementptr i8, ptr %444, i64 8
  store i64 %v593, ptr %v636, align 1
  %v641 = getelementptr i8, ptr %444, i64 16
  store i64 %v548, ptr %v641, align 1
  %v646 = getelementptr i8, ptr %444, i64 24
  store i64 %434, ptr %v646, align 1
  %v651 = getelementptr i8, ptr %444, i64 32
  store i64 %v619, ptr %v651, align 1
  store i64 %455, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v130, align 8
  store i64 %413, ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %456 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %457 = icmp eq ptr %456, null
  br i1 %457, label %458, label %459

458:                                              ; preds = %ok629
  call fastcc void @native_trap() #113
  unreachable

459:                                              ; preds = %ok629
  %460 = getelementptr inbounds nuw i8, ptr %456, i64 376
  %461 = load i64, ptr %460, align 8, !noundef !39
  %462 = icmp eq i64 %461, 0
  br i1 %462, label %463, label %467

463:                                              ; preds = %473, %467, %459
  %464 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %465 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %456, i64 noundef 24, ptr noundef %464) #84
  %466 = icmp eq ptr %465, null
  br i1 %466, label %475, label %ok659

467:                                              ; preds = %459
  %468 = getelementptr inbounds nuw i8, ptr %456, i64 368
  %469 = load i64, ptr %468, align 8, !noundef !39
  %470 = add i64 %469, 1
  store i64 %470, ptr %468, align 8
  %471 = urem i64 %470, %461
  %472 = icmp eq i64 %471, 0
  br i1 %472, label %473, label %463

473:                                              ; preds = %467
  %474 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %456, ptr noundef %474) #84
  br label %463

475:                                              ; preds = %463
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok659:                                            ; preds = %463
  %476 = ptrtoint ptr %465 to i64
  store i64 194, ptr %465, align 1
  %v666 = getelementptr i8, ptr %465, i64 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v666, align 1
  %v671 = getelementptr i8, ptr %465, i64 16
  store i64 %455, ptr %v671, align 1
  store i64 %476, ptr %v586, align 1
  %v677 = load i64, ptr %v6, align 8
  %v678.not = icmp eq i64 %v677, 0
  br i1 %v678.not, label %trap679, label %ok680

trap679:                                          ; preds = %ok659
  call fastcc void @native_trap()
  unreachable

ok680:                                            ; preds = %ok659
  %v681 = inttoptr i64 %v677 to ptr
  %v682 = getelementptr i8, ptr %v681, i64 8
  store i32 1, ptr %v682, align 1
  %v683 = load i64, ptr %v6, align 8
  %v684.not = icmp eq i64 %v683, 0
  br i1 %v684.not, label %trap685, label %ok686

trap685:                                          ; preds = %ok680
  call fastcc void @native_trap()
  unreachable

ok686:                                            ; preds = %ok680
  %v687 = inttoptr i64 %v683 to ptr
  %v688 = getelementptr i8, ptr %v687, i64 8
  %v689 = load i32, ptr %v688, align 1
  %v690 = icmp eq i32 %v689, 0
  br i1 %v690, label %then694, label %ok699

then694:                                          ; preds = %ok686
  call fastcc void @native_trap()
  unreachable

ok699:                                            ; preds = %ok686
  %v701 = getelementptr i8, ptr %v687, i64 16
  %v702 = load i64, ptr %v701, align 1
  %v703.not = icmp eq i64 %v702, 0
  br i1 %v703.not, label %trap704, label %ok705

trap704:                                          ; preds = %ok699
  call fastcc void @native_trap()
  unreachable

ok705:                                            ; preds = %ok699
  store i64 %v702, ptr %v21, align 8
  %v709 = inttoptr i64 %v702 to ptr
  %v717 = getelementptr i8, ptr %v709, i64 8
  %v718 = load i64, ptr %v717, align 1
  %v719.not = icmp eq i64 %v718, 0
  br i1 %v719.not, label %trap720, label %ok721

trap720:                                          ; preds = %ok705
  call fastcc void @native_trap()
  unreachable

ok721:                                            ; preds = %ok705
  %v710 = getelementptr i8, ptr %v709, i64 16
  %v711 = load i64, ptr %v710, align 1
  %v722 = inttoptr i64 %v718 to ptr
  %v723 = getelementptr i8, ptr %v722, i64 8
  %v724 = load ptr, ptr %v723, align 1
  store i64 %v711, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v727 = call tailcc i64 %v724(i64 %v711, i64 0)
  store i64 %v727, ptr %v17, align 8
  %v728.b = load i1, ptr @g.6, align 1
  br i1 %v728.b, label %block731, label %then733

then733:                                          ; preds = %ok721
  call fastcc void @native_trap()
  unreachable

block731:                                         ; preds = %ok721
  %v735 = load i64, ptr @g.5, align 8
  %v736.not = icmp eq i64 %v735, 0
  br i1 %v736.not, label %trap737, label %ok738

trap737:                                          ; preds = %block731
  call fastcc void @native_trap()
  unreachable

ok738:                                            ; preds = %block731
  %v739.b = load i1, ptr @g.8, align 1
  br i1 %v739.b, label %block742, label %then744

then744:                                          ; preds = %ok738
  call fastcc void @native_trap()
  unreachable

block742:                                         ; preds = %ok738
  %v746 = load i64, ptr @g.7, align 8
  %v747.not = icmp eq i64 %v746, 0
  br i1 %v747.not, label %trap748, label %ok749

trap748:                                          ; preds = %block742
  call fastcc void @native_trap()
  unreachable

ok749:                                            ; preds = %block742
  %v752.not = icmp eq i64 %v727, 0
  br i1 %v752.not, label %trap753, label %ok754

trap753:                                          ; preds = %ok749
  call fastcc void @native_trap()
  unreachable

ok754:                                            ; preds = %ok749
  %v755 = inttoptr i64 %v727 to ptr
  %v756 = getelementptr i8, ptr %v755, i64 8
  %v757 = load i64, ptr %v756, align 1
  %v758.not = icmp eq i64 %v757, 0
  br i1 %v758.not, label %trap759, label %ok760

trap759:                                          ; preds = %ok754
  call fastcc void @native_trap()
  unreachable

ok760:                                            ; preds = %ok754
  %v761 = and i64 %v757, 1
  %v762 = icmp eq i64 %v761, 0
  br i1 %v762, label %ok764, label %trap763

trap763:                                          ; preds = %ok760
  call fastcc void @native_trap()
  unreachable

ok764:                                            ; preds = %ok760
  %v765 = inttoptr i64 %v757 to ptr
  %v766 = getelementptr i8, ptr %v765, i64 8
  %v767 = load i64, ptr %v766, align 1
  %v769 = and i64 %v767, 4294967295
  store i64 %v727, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v772 = call tailcc i64 @f.5(i64 %v727, i64 %v769)
  store i64 %v772, ptr %v8, align 8
  store i64 %v772, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %477 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %478 = icmp eq ptr %477, null
  br i1 %478, label %479, label %480

479:                                              ; preds = %ok764
  call fastcc void @native_trap() #113
  unreachable

480:                                              ; preds = %ok764
  %481 = getelementptr inbounds nuw i8, ptr %477, i64 376
  %482 = load i64, ptr %481, align 8, !noundef !39
  %483 = icmp eq i64 %482, 0
  br i1 %483, label %484, label %488

484:                                              ; preds = %494, %488, %480
  %485 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %486 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %477, i64 noundef 16, ptr noundef %485) #84
  %487 = icmp eq ptr %486, null
  br i1 %487, label %496, label %ok778

488:                                              ; preds = %480
  %489 = getelementptr inbounds nuw i8, ptr %477, i64 368
  %490 = load i64, ptr %489, align 8, !noundef !39
  %491 = add i64 %490, 1
  store i64 %491, ptr %489, align 8
  %492 = urem i64 %491, %482
  %493 = icmp eq i64 %492, 0
  br i1 %493, label %494, label %484

494:                                              ; preds = %488
  %495 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %477, ptr noundef %495) #84
  br label %484

496:                                              ; preds = %484
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok778:                                            ; preds = %484
  %497 = ptrtoint ptr %486 to i64
  store i64 34, ptr %486, align 1
  %v785 = getelementptr i8, ptr %486, i64 8
  store i64 %v772, ptr %v785, align 1
  %v788 = load i64, ptr %v8, align 8
  %v789.not = icmp eq i64 %v788, 0
  br i1 %v789.not, label %trap790, label %block799

trap790:                                          ; preds = %ok778
  call fastcc void @native_trap()
  unreachable

block799:                                         ; preds = %ok778
  %v792 = inttoptr i64 %v788 to ptr
  %v793 = getelementptr i8, ptr %v792, i64 8
  %v794 = load i32, ptr %v793, align 1
  store i64 %497, ptr %v111, align 8
  store i64 %v788, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %v807 = call tailcc i32 @f.4(i64 %v788, i32 0)
  %v808 = load i64, ptr %v8, align 8
  store i64 %497, ptr %v111, align 8
  store i64 %v808, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %v814 = call tailcc i32 @f.4(i64 %v808, i32 %v794)
  %v816 = sub i32 %v814, %v807
  store i64 %497, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v820 = call fastcc i64 @native_array_new(i32 %v816)
  store i64 %v820, ptr %v22, align 8
  %v821 = load i64, ptr %v8, align 8
  %v822.not = icmp eq i64 %v821, 0
  br i1 %v822.not, label %trap823, label %ok824

trap823:                                          ; preds = %block799
  call fastcc void @native_trap()
  unreachable

ok824:                                            ; preds = %block799
  %v825 = inttoptr i64 %v821 to ptr
  %v826 = getelementptr i8, ptr %v825, i64 24
  %v827 = load i64, ptr %v826, align 1
  %498 = and i64 %v820, 1
  %499 = icmp eq i64 %498, 0
  br i1 %499, label %501, label %500

500:                                              ; preds = %ok824
  call fastcc void @native_trap() #113
  unreachable

501:                                              ; preds = %ok824
  %502 = inttoptr i64 %v820 to ptr
  %503 = icmp ne i64 %v827, 0
  %504 = and i64 %v827, 1
  %505 = icmp eq i64 %504, 0
  %506 = and i1 %503, %505
  br i1 %506, label %508, label %507

507:                                              ; preds = %501
  call fastcc void @native_trap() #113
  unreachable

508:                                              ; preds = %501
  %509 = inttoptr i64 %v827 to ptr
  %510 = zext i32 %v816 to i64
  %511 = getelementptr inbounds nuw i8, ptr %502, i64 8
  %512 = load i64, ptr %511, align 8, !noundef !39
  %513 = icmp ult i64 %512, %510
  br i1 %513, label %520, label %514

514:                                              ; preds = %508
  %515 = zext i32 %v807 to i64
  %516 = add nuw nsw i64 %510, %515
  %517 = getelementptr inbounds nuw i8, ptr %509, i64 8
  %518 = load i64, ptr %517, align 8, !noundef !39
  %519 = icmp ugt i64 %516, %518
  br i1 %519, label %520, label %native_array_copy.exit

520:                                              ; preds = %514, %508
  call fastcc void @native_trap() #113
  unreachable

native_array_copy.exit:                           ; preds = %514
  %521 = getelementptr inbounds nuw i8, ptr %509, i64 16
  %522 = getelementptr inbounds nuw i8, ptr %521, i64 %515
  %523 = getelementptr inbounds nuw i8, ptr %502, i64 16
  call void @llvm.memmove.p0.p0.i64(ptr nonnull align 1 %523, ptr nonnull align 1 %522, i64 %510, i1 false)
  %v830 = load i64, ptr %v22, align 8
  store i64 %v830, ptr %v111, align 8
  store i64 %497, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %524 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %525 = icmp eq ptr %524, null
  br i1 %525, label %526, label %527

526:                                              ; preds = %native_array_copy.exit
  call fastcc void @native_trap() #113
  unreachable

527:                                              ; preds = %native_array_copy.exit
  %528 = getelementptr inbounds nuw i8, ptr %524, i64 376
  %529 = load i64, ptr %528, align 8, !noundef !39
  %530 = icmp eq i64 %529, 0
  br i1 %530, label %531, label %535

531:                                              ; preds = %541, %535, %527
  %532 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %533 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %524, i64 noundef 16, ptr noundef %532) #84
  %534 = icmp eq ptr %533, null
  br i1 %534, label %543, label %ok837

535:                                              ; preds = %527
  %536 = getelementptr inbounds nuw i8, ptr %524, i64 368
  %537 = load i64, ptr %536, align 8, !noundef !39
  %538 = add i64 %537, 1
  store i64 %538, ptr %536, align 8
  %539 = urem i64 %538, %529
  %540 = icmp eq i64 %539, 0
  br i1 %540, label %541, label %531

541:                                              ; preds = %535
  %542 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %524, ptr noundef %542) #84
  br label %531

543:                                              ; preds = %531
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok837:                                            ; preds = %531
  %544 = ptrtoint ptr %533 to i64
  store i64 130, ptr %533, align 1
  %v844 = getelementptr i8, ptr %533, i64 8
  store i64 %v830, ptr %v844, align 1
  store i64 %544, ptr %v18, align 8
  %v851 = load i64, ptr %v844, align 1
  %v852.not = icmp eq i64 %v851, 0
  br i1 %v852.not, label %trap853, label %ok854

trap853:                                          ; preds = %ok837
  call fastcc void @native_trap()
  unreachable

ok854:                                            ; preds = %ok837
  %v855 = and i64 %v851, 1
  %v856 = icmp eq i64 %v855, 0
  br i1 %v856, label %ok858, label %trap857

trap857:                                          ; preds = %ok854
  call fastcc void @native_trap()
  unreachable

ok858:                                            ; preds = %ok854
  %v859 = inttoptr i64 %v851 to ptr
  %v860 = getelementptr i8, ptr %v859, i64 8
  %v861 = load i64, ptr %v860, align 1
  %v863 = and i64 %v861, 4294967295
  store i64 %497, ptr %v111, align 8
  store i64 %544, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %v867 = call tailcc i64 @f.5(i64 %544, i64 %v863)
  store i64 %497, ptr %v111, align 8
  store i64 %v867, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  call tailcc void @f.11(i64 %497, i64 %v867)
  store i64 21, ptr %v67, align 8
  %545 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %546 = icmp eq ptr %545, null
  br i1 %546, label %547, label %548

547:                                              ; preds = %ok858
  call fastcc void @native_trap() #113
  unreachable

548:                                              ; preds = %ok858
  %549 = getelementptr inbounds nuw i8, ptr %545, i64 376
  %550 = load i64, ptr %549, align 8, !noundef !39
  %551 = icmp eq i64 %550, 0
  br i1 %551, label %552, label %556

552:                                              ; preds = %562, %556, %548
  %553 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %554 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %545, i64 noundef 24, ptr noundef %553) #84
  %555 = icmp eq ptr %554, null
  br i1 %555, label %564, label %ok876

556:                                              ; preds = %548
  %557 = getelementptr inbounds nuw i8, ptr %545, i64 368
  %558 = load i64, ptr %557, align 8, !noundef !39
  %559 = add i64 %558, 1
  store i64 %559, ptr %557, align 8
  %560 = urem i64 %559, %550
  %561 = icmp eq i64 %560, 0
  br i1 %561, label %562, label %552

562:                                              ; preds = %556
  %563 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %545, ptr noundef %563) #84
  br label %552

564:                                              ; preds = %552
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok876:                                            ; preds = %552
  %565 = ptrtoint ptr %554 to i64
  store i64 98, ptr %554, align 1
  %v883 = getelementptr i8, ptr %554, i64 8
  store i32 0, ptr %v883, align 1
  %v888 = getelementptr i8, ptr %554, i64 16
  store i64 0, ptr %v888, align 1
  store i64 %565, ptr %v9, align 8
  %v891 = load i64, ptr %v7, align 8
  store i64 %565, ptr %v111, align 8
  store i64 %v891, ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.10 to i64), ptr %v150, align 8
  store i64 %565, ptr %v171, align 8
  store i64 25, ptr %v67, align 8
  %566 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %567 = icmp eq ptr %566, null
  br i1 %567, label %568, label %569

568:                                              ; preds = %ok876
  call fastcc void @native_trap() #113
  unreachable

569:                                              ; preds = %ok876
  %570 = getelementptr inbounds nuw i8, ptr %566, i64 376
  %571 = load i64, ptr %570, align 8, !noundef !39
  %572 = icmp eq i64 %571, 0
  br i1 %572, label %573, label %577

573:                                              ; preds = %583, %577, %569
  %574 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %575 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %566, i64 noundef 40, ptr noundef %574) #84
  %576 = icmp eq ptr %575, null
  br i1 %576, label %585, label %ok901

577:                                              ; preds = %569
  %578 = getelementptr inbounds nuw i8, ptr %566, i64 368
  %579 = load i64, ptr %578, align 8, !noundef !39
  %580 = add i64 %579, 1
  store i64 %580, ptr %578, align 8
  %581 = urem i64 %580, %571
  %582 = icmp eq i64 %581, 0
  br i1 %582, label %583, label %573

583:                                              ; preds = %577
  %584 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %566, ptr noundef %584) #84
  br label %573

585:                                              ; preds = %573
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok901:                                            ; preds = %573
  %586 = ptrtoint ptr %575 to i64
  store i64 30, ptr %575, align 1
  %v908 = getelementptr i8, ptr %575, i64 8
  store i64 %v2.i, ptr %v908, align 1
  %v913 = getelementptr i8, ptr %575, i64 16
  store i64 %v2.i12, ptr %v913, align 1
  %v918 = getelementptr i8, ptr %575, i64 24
  store i64 %v891, ptr %v918, align 1
  %v923 = getelementptr i8, ptr %575, i64 32
  store i64 %565, ptr %v923, align 1
  store i64 %586, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.10 to i64), ptr %v130, align 8
  store i64 %565, ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %587 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %588 = icmp eq ptr %587, null
  br i1 %588, label %589, label %590

589:                                              ; preds = %ok901
  call fastcc void @native_trap() #113
  unreachable

590:                                              ; preds = %ok901
  %591 = getelementptr inbounds nuw i8, ptr %587, i64 376
  %592 = load i64, ptr %591, align 8, !noundef !39
  %593 = icmp eq i64 %592, 0
  br i1 %593, label %594, label %598

594:                                              ; preds = %604, %598, %590
  %595 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %596 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %587, i64 noundef 24, ptr noundef %595) #84
  %597 = icmp eq ptr %596, null
  br i1 %597, label %606, label %ok931

598:                                              ; preds = %590
  %599 = getelementptr inbounds nuw i8, ptr %587, i64 368
  %600 = load i64, ptr %599, align 8, !noundef !39
  %601 = add i64 %600, 1
  store i64 %601, ptr %599, align 8
  %602 = urem i64 %601, %592
  %603 = icmp eq i64 %602, 0
  br i1 %603, label %604, label %594

604:                                              ; preds = %598
  %605 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %587, ptr noundef %605) #84
  br label %594

606:                                              ; preds = %594
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok931:                                            ; preds = %594
  %607 = ptrtoint ptr %596 to i64
  store i64 66, ptr %596, align 1
  %v938 = getelementptr i8, ptr %596, i64 8
  store i64 ptrtoint (ptr @ref.10 to i64), ptr %v938, align 1
  %v943 = getelementptr i8, ptr %596, i64 16
  store i64 %586, ptr %v943, align 1
  store i64 %607, ptr %v888, align 1
  %v949 = load i64, ptr %v9, align 8
  %v950.not = icmp eq i64 %v949, 0
  br i1 %v950.not, label %trap951, label %ok952

trap951:                                          ; preds = %ok931
  call fastcc void @native_trap()
  unreachable

ok952:                                            ; preds = %ok931
  %v953 = inttoptr i64 %v949 to ptr
  %v954 = getelementptr i8, ptr %v953, i64 8
  store i32 1, ptr %v954, align 1
  %v955 = load i64, ptr %v9, align 8
  %v956.not = icmp eq i64 %v955, 0
  br i1 %v956.not, label %trap957, label %ok958

trap957:                                          ; preds = %ok952
  call fastcc void @native_trap()
  unreachable

ok958:                                            ; preds = %ok952
  %v959 = inttoptr i64 %v955 to ptr
  %v960 = getelementptr i8, ptr %v959, i64 8
  %v961 = load i32, ptr %v960, align 1
  %v962 = icmp eq i32 %v961, 0
  br i1 %v962, label %then966, label %ok971

then966:                                          ; preds = %ok958
  call fastcc void @native_trap()
  unreachable

ok971:                                            ; preds = %ok958
  %v973 = getelementptr i8, ptr %v959, i64 16
  %v974 = load i64, ptr %v973, align 1
  %v975.not = icmp eq i64 %v974, 0
  br i1 %v975.not, label %trap976, label %ok977

trap976:                                          ; preds = %ok971
  call fastcc void @native_trap()
  unreachable

ok977:                                            ; preds = %ok971
  store i64 %v974, ptr %v23, align 8
  %v981 = inttoptr i64 %v974 to ptr
  %v989 = getelementptr i8, ptr %v981, i64 8
  %v990 = load i64, ptr %v989, align 1
  %v991.not = icmp eq i64 %v990, 0
  br i1 %v991.not, label %trap992, label %ok993

trap992:                                          ; preds = %ok977
  call fastcc void @native_trap()
  unreachable

ok993:                                            ; preds = %ok977
  %v982 = getelementptr i8, ptr %v981, i64 16
  %v983 = load i64, ptr %v982, align 1
  %v994 = inttoptr i64 %v990 to ptr
  %v995 = getelementptr i8, ptr %v994, i64 8
  %v996 = load ptr, ptr %v995, align 1
  store i64 %v983, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v999 = call tailcc i32 %v996(i64 %v983, i64 0)
  %v1000.b = load i1, ptr @g.22, align 1
  br i1 %v1000.b, label %block1003, label %then1005

then1005:                                         ; preds = %ok993
  call fastcc void @native_trap()
  unreachable

block1003:                                        ; preds = %ok993
  %v1007 = load i64, ptr @g.21, align 8
  %v1008.not = icmp eq i64 %v1007, 0
  br i1 %v1008.not, label %trap1009, label %ok1010

trap1009:                                         ; preds = %block1003
  call fastcc void @native_trap()
  unreachable

ok1010:                                           ; preds = %block1003
  %v1011 = inttoptr i64 %v1007 to ptr
  %v1012 = getelementptr i8, ptr %v1011, i64 8
  %v1013 = load i64, ptr %v1012, align 1
  store i64 %v1013, ptr %v4, align 8
  %v1014.b = load i1, ptr @g.10, align 1
  br i1 %v1014.b, label %block1017, label %then1019

then1019:                                         ; preds = %ok1010
  call fastcc void @native_trap()
  unreachable

block1017:                                        ; preds = %ok1010
  %v1021 = load i64, ptr @g.9, align 8
  %v1022.not = icmp eq i64 %v1021, 0
  br i1 %v1022.not, label %trap1023, label %ok1024

trap1023:                                         ; preds = %block1017
  call fastcc void @native_trap()
  unreachable

ok1024:                                           ; preds = %block1017
  store i64 21, ptr %v67, align 8
  %608 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %609 = icmp eq ptr %608, null
  br i1 %609, label %610, label %611

610:                                              ; preds = %ok1024
  call fastcc void @native_trap() #113
  unreachable

611:                                              ; preds = %ok1024
  %612 = getelementptr inbounds nuw i8, ptr %608, i64 376
  %613 = load i64, ptr %612, align 8, !noundef !39
  %614 = icmp eq i64 %613, 0
  br i1 %614, label %615, label %619

615:                                              ; preds = %625, %619, %611
  %616 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %617 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %608, i64 noundef 24, ptr noundef %616) #84
  %618 = icmp eq ptr %617, null
  br i1 %618, label %627, label %ok1029

619:                                              ; preds = %611
  %620 = getelementptr inbounds nuw i8, ptr %608, i64 368
  %621 = load i64, ptr %620, align 8, !noundef !39
  %622 = add i64 %621, 1
  store i64 %622, ptr %620, align 8
  %623 = urem i64 %622, %613
  %624 = icmp eq i64 %623, 0
  br i1 %624, label %625, label %615

625:                                              ; preds = %619
  %626 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %608, ptr noundef %626) #84
  br label %615

627:                                              ; preds = %615
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok1029:                                           ; preds = %615
  %628 = ptrtoint ptr %617 to i64
  store i64 94, ptr %617, align 1
  %v1036 = getelementptr i8, ptr %617, i64 8
  store i32 0, ptr %v1036, align 1
  %v1041 = getelementptr i8, ptr %617, i64 16
  store i64 0, ptr %v1041, align 1
  store i64 %628, ptr %v10, align 8
  store i64 %628, ptr %v111, align 8
  store i64 %628, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %629 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %630 = icmp eq ptr %629, null
  br i1 %630, label %631, label %632

631:                                              ; preds = %ok1029
  call fastcc void @native_trap() #113
  unreachable

632:                                              ; preds = %ok1029
  %633 = getelementptr inbounds nuw i8, ptr %629, i64 376
  %634 = load i64, ptr %633, align 8, !noundef !39
  %635 = icmp eq i64 %634, 0
  br i1 %635, label %636, label %640

636:                                              ; preds = %646, %640, %632
  %637 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %638 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %629, i64 noundef 16, ptr noundef %637) #84
  %639 = icmp eq ptr %638, null
  br i1 %639, label %648, label %ok1049

640:                                              ; preds = %632
  %641 = getelementptr inbounds nuw i8, ptr %629, i64 368
  %642 = load i64, ptr %641, align 8, !noundef !39
  %643 = add i64 %642, 1
  store i64 %643, ptr %641, align 8
  %644 = urem i64 %643, %634
  %645 = icmp eq i64 %644, 0
  br i1 %645, label %646, label %636

646:                                              ; preds = %640
  %647 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %629, ptr noundef %647) #84
  br label %636

648:                                              ; preds = %636
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok1049:                                           ; preds = %636
  %649 = ptrtoint ptr %638 to i64
  store i64 106, ptr %638, align 1
  %v1056 = getelementptr i8, ptr %638, i64 8
  store i64 %628, ptr %v1056, align 1
  store i64 %649, ptr %v111, align 8
  store i64 %628, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %650 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %651 = icmp eq ptr %650, null
  br i1 %651, label %652, label %653

652:                                              ; preds = %ok1049
  call fastcc void @native_trap() #113
  unreachable

653:                                              ; preds = %ok1049
  %654 = getelementptr inbounds nuw i8, ptr %650, i64 376
  %655 = load i64, ptr %654, align 8, !noundef !39
  %656 = icmp eq i64 %655, 0
  br i1 %656, label %657, label %661

657:                                              ; preds = %667, %661, %653
  %658 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %659 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %650, i64 noundef 16, ptr noundef %658) #84
  %660 = icmp eq ptr %659, null
  br i1 %660, label %669, label %ok1063

661:                                              ; preds = %653
  %662 = getelementptr inbounds nuw i8, ptr %650, i64 368
  %663 = load i64, ptr %662, align 8, !noundef !39
  %664 = add i64 %663, 1
  store i64 %664, ptr %662, align 8
  %665 = urem i64 %664, %655
  %666 = icmp eq i64 %665, 0
  br i1 %666, label %667, label %657

667:                                              ; preds = %661
  %668 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %650, ptr noundef %668) #84
  br label %657

669:                                              ; preds = %657
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok1063:                                           ; preds = %657
  %670 = ptrtoint ptr %659 to i64
  store i64 22, ptr %659, align 1
  %v1070 = getelementptr i8, ptr %659, i64 8
  store i64 %649, ptr %v1070, align 1
  store i64 %670, ptr %v1041, align 1
  %v1076 = load i64, ptr %v10, align 8
  %v1077.not = icmp eq i64 %v1076, 0
  br i1 %v1077.not, label %trap1078, label %ok1079

trap1078:                                         ; preds = %ok1063
  call fastcc void @native_trap()
  unreachable

ok1079:                                           ; preds = %ok1063
  %v1080 = inttoptr i64 %v1076 to ptr
  %v1081 = getelementptr i8, ptr %v1080, i64 8
  store i32 1, ptr %v1081, align 1
  %v1082 = load i64, ptr %v10, align 8
  %v1083.not = icmp eq i64 %v1082, 0
  br i1 %v1083.not, label %trap1084, label %ok1085

trap1084:                                         ; preds = %ok1079
  call fastcc void @native_trap()
  unreachable

ok1085:                                           ; preds = %ok1079
  %v1086 = inttoptr i64 %v1082 to ptr
  %v1087 = getelementptr i8, ptr %v1086, i64 8
  %v1088 = load i32, ptr %v1087, align 1
  %v1089 = icmp eq i32 %v1088, 0
  br i1 %v1089, label %then1093, label %ok1098

then1093:                                         ; preds = %ok1085
  call fastcc void @native_trap()
  unreachable

ok1098:                                           ; preds = %ok1085
  %v1100 = getelementptr i8, ptr %v1086, i64 16
  %v1101 = load i64, ptr %v1100, align 1
  %v1102.not = icmp eq i64 %v1101, 0
  br i1 %v1102.not, label %trap1103, label %ok1104

trap1103:                                         ; preds = %ok1098
  call fastcc void @native_trap()
  unreachable

ok1104:                                           ; preds = %ok1098
  %v1105 = inttoptr i64 %v1101 to ptr
  %v1106 = getelementptr i8, ptr %v1105, i64 8
  %v1107 = load i64, ptr %v1106, align 1
  store i64 %v1107, ptr %v5, align 8
  %v1108 = load i64, ptr %v4, align 8
  %v1109 = icmp eq i64 %v1108, 0
  br i1 %v1109, label %block1112, label %ok1119

ok1119:                                           ; preds = %ok1104
  %v1120 = inttoptr i64 %v1108 to ptr
  %v1121 = getelementptr i8, ptr %v1120, i64 8
  %v1122 = load i64, ptr %v1121, align 1
  store i64 %v1122, ptr %v4, align 8
  %v1124.not = icmp eq i64 %v1107, 0
  br i1 %v1124.not, label %trap1125, label %ok1126

trap1125:                                         ; preds = %ok1119
  call fastcc void @native_trap()
  unreachable

ok1126:                                           ; preds = %ok1119
  %v1127 = inttoptr i64 %v1107 to ptr
  %v1128 = getelementptr i8, ptr %v1127, i64 8
  %v1129 = load i64, ptr %v1128, align 1
  %v1130.not = icmp eq i64 %v1129, 0
  br i1 %v1130.not, label %trap1131, label %ok1132

trap1131:                                         ; preds = %ok1126
  call fastcc void @native_trap()
  unreachable

ok1132:                                           ; preds = %ok1126
  %v1133 = inttoptr i64 %v1129 to ptr
  %v1134 = getelementptr i8, ptr %v1133, i64 8
  %v1135 = load i32, ptr %v1134, align 1
  %v1136 = icmp eq i32 %v1135, 0
  br i1 %v1136, label %then1140, label %ok1151

then1140:                                         ; preds = %ok1132
  call fastcc void @native_trap()
  unreachable

ok1151:                                           ; preds = %ok1132
  %v1153 = getelementptr i8, ptr %v1133, i64 16
  %v1154 = load i64, ptr %v1153, align 1
  %v1155.not = icmp eq i64 %v1154, 0
  br i1 %v1155.not, label %trap1156, label %ok1157

trap1156:                                         ; preds = %ok1151
  call fastcc void @native_trap()
  unreachable

ok1157:                                           ; preds = %ok1151
  %v1158 = inttoptr i64 %v1154 to ptr
  %v1159 = getelementptr i8, ptr %v1158, i64 8
  %v1160 = load i64, ptr %v1159, align 1
  store i64 %v1160, ptr %v5, align 8
  %v1162 = icmp eq i64 %v1122, 0
  br i1 %v1162, label %block1112, label %ok1172

ok1172:                                           ; preds = %ok1157
  %v1173 = inttoptr i64 %v1122 to ptr
  %v1174 = getelementptr i8, ptr %v1173, i64 8
  %v1175 = load i64, ptr %v1174, align 1
  store i64 %v1175, ptr %v4, align 8
  %v1177.not = icmp eq i64 %v1160, 0
  br i1 %v1177.not, label %trap1178, label %ok1179

trap1178:                                         ; preds = %ok1172
  call fastcc void @native_trap()
  unreachable

ok1179:                                           ; preds = %ok1172
  %v1180 = inttoptr i64 %v1160 to ptr
  %v1181 = getelementptr i8, ptr %v1180, i64 8
  %v1182 = load i64, ptr %v1181, align 1
  %v1183.not = icmp eq i64 %v1182, 0
  br i1 %v1183.not, label %trap1184, label %ok1185

trap1184:                                         ; preds = %ok1179
  call fastcc void @native_trap()
  unreachable

ok1185:                                           ; preds = %ok1179
  %v1186 = inttoptr i64 %v1182 to ptr
  %v1187 = getelementptr i8, ptr %v1186, i64 8
  %v1188 = load i32, ptr %v1187, align 1
  %v1189 = icmp eq i32 %v1188, 0
  br i1 %v1189, label %then1193, label %ok1204

then1193:                                         ; preds = %ok1185
  call fastcc void @native_trap()
  unreachable

ok1204:                                           ; preds = %ok1185
  %v1206 = getelementptr i8, ptr %v1186, i64 16
  %v1207 = load i64, ptr %v1206, align 1
  %v1208.not = icmp eq i64 %v1207, 0
  br i1 %v1208.not, label %trap1209, label %ok1210

trap1209:                                         ; preds = %ok1204
  call fastcc void @native_trap()
  unreachable

ok1210:                                           ; preds = %ok1204
  %v1211 = inttoptr i64 %v1207 to ptr
  %v1212 = getelementptr i8, ptr %v1211, i64 8
  %v1213 = load i64, ptr %v1212, align 1
  store i64 %v1213, ptr %v5, align 8
  %v1215 = icmp eq i64 %v1175, 0
  br i1 %v1215, label %block1112, label %ok1225

ok1225:                                           ; preds = %ok1210
  %v1226 = inttoptr i64 %v1175 to ptr
  %v1227 = getelementptr i8, ptr %v1226, i64 8
  %v1228 = load i64, ptr %v1227, align 1
  store i64 %v1228, ptr %v4, align 8
  %v1230.not = icmp eq i64 %v1213, 0
  br i1 %v1230.not, label %trap1231, label %ok1232

trap1231:                                         ; preds = %ok1225
  call fastcc void @native_trap()
  unreachable

ok1232:                                           ; preds = %ok1225
  %v1233 = inttoptr i64 %v1213 to ptr
  %v1234 = getelementptr i8, ptr %v1233, i64 8
  %v1235 = load i64, ptr %v1234, align 1
  %v1236.not = icmp eq i64 %v1235, 0
  br i1 %v1236.not, label %trap1237, label %ok1238

trap1237:                                         ; preds = %ok1232
  call fastcc void @native_trap()
  unreachable

ok1238:                                           ; preds = %ok1232
  %v1239 = inttoptr i64 %v1235 to ptr
  %v1240 = getelementptr i8, ptr %v1239, i64 8
  %v1241 = load i32, ptr %v1240, align 1
  %v1242 = icmp eq i32 %v1241, 0
  br i1 %v1242, label %then1246, label %ok1257

then1246:                                         ; preds = %ok1238
  call fastcc void @native_trap()
  unreachable

ok1257:                                           ; preds = %ok1238
  %v1259 = getelementptr i8, ptr %v1239, i64 16
  %v1260 = load i64, ptr %v1259, align 1
  %v1261.not = icmp eq i64 %v1260, 0
  br i1 %v1261.not, label %trap1262, label %ok1263

trap1262:                                         ; preds = %ok1257
  call fastcc void @native_trap()
  unreachable

ok1263:                                           ; preds = %ok1257
  %v1264 = inttoptr i64 %v1260 to ptr
  %v1265 = getelementptr i8, ptr %v1264, i64 8
  %v1266 = load i64, ptr %v1265, align 1
  store i64 %v1266, ptr %v5, align 8
  %v1268 = icmp eq i64 %v1228, 0
  br i1 %v1268, label %block1112, label %ok1278

ok1278:                                           ; preds = %ok1263
  %v1279 = inttoptr i64 %v1228 to ptr
  %v1280 = getelementptr i8, ptr %v1279, i64 8
  %v1281 = load i64, ptr %v1280, align 1
  store i64 %v1281, ptr %v4, align 8
  %v1283.not = icmp eq i64 %v1266, 0
  br i1 %v1283.not, label %trap1284, label %ok1285

trap1284:                                         ; preds = %ok1278
  call fastcc void @native_trap()
  unreachable

ok1285:                                           ; preds = %ok1278
  %v1286 = inttoptr i64 %v1266 to ptr
  %v1287 = getelementptr i8, ptr %v1286, i64 8
  %v1288 = load i64, ptr %v1287, align 1
  %v1289.not = icmp eq i64 %v1288, 0
  br i1 %v1289.not, label %trap1290, label %ok1291

trap1290:                                         ; preds = %ok1285
  call fastcc void @native_trap()
  unreachable

ok1291:                                           ; preds = %ok1285
  %v1292 = inttoptr i64 %v1288 to ptr
  %v1293 = getelementptr i8, ptr %v1292, i64 8
  %v1294 = load i32, ptr %v1293, align 1
  %v1295 = icmp eq i32 %v1294, 0
  br i1 %v1295, label %then1299, label %ok1310

then1299:                                         ; preds = %ok1291
  call fastcc void @native_trap()
  unreachable

ok1310:                                           ; preds = %ok1291
  %v1312 = getelementptr i8, ptr %v1292, i64 16
  %v1313 = load i64, ptr %v1312, align 1
  %v1314.not = icmp eq i64 %v1313, 0
  br i1 %v1314.not, label %trap1315, label %ok1316

trap1315:                                         ; preds = %ok1310
  call fastcc void @native_trap()
  unreachable

ok1316:                                           ; preds = %ok1310
  %v1317 = inttoptr i64 %v1313 to ptr
  %v1318 = getelementptr i8, ptr %v1317, i64 8
  %v1319 = load i64, ptr %v1318, align 1
  store i64 %v1319, ptr %v5, align 8
  %v1321 = icmp eq i64 %v1281, 0
  br i1 %v1321, label %block1112, label %ok1331

ok1331:                                           ; preds = %ok1316
  %v1332 = inttoptr i64 %v1281 to ptr
  %v1333 = getelementptr i8, ptr %v1332, i64 8
  %v1334 = load i64, ptr %v1333, align 1
  store i64 %v1334, ptr %v4, align 8
  %v1336.not = icmp eq i64 %v1319, 0
  br i1 %v1336.not, label %trap1337, label %ok1338

trap1337:                                         ; preds = %ok1331
  call fastcc void @native_trap()
  unreachable

ok1338:                                           ; preds = %ok1331
  %v1339 = inttoptr i64 %v1319 to ptr
  %v1340 = getelementptr i8, ptr %v1339, i64 8
  %v1341 = load i64, ptr %v1340, align 1
  %v1342.not = icmp eq i64 %v1341, 0
  br i1 %v1342.not, label %trap1343, label %ok1344

trap1343:                                         ; preds = %ok1338
  call fastcc void @native_trap()
  unreachable

ok1344:                                           ; preds = %ok1338
  %v1345 = inttoptr i64 %v1341 to ptr
  %v1346 = getelementptr i8, ptr %v1345, i64 8
  %v1347 = load i32, ptr %v1346, align 1
  %v1348 = icmp eq i32 %v1347, 0
  br i1 %v1348, label %then1352, label %ok1363

then1352:                                         ; preds = %ok1344
  call fastcc void @native_trap()
  unreachable

ok1363:                                           ; preds = %ok1344
  %v1365 = getelementptr i8, ptr %v1345, i64 16
  %v1366 = load i64, ptr %v1365, align 1
  %v1367.not = icmp eq i64 %v1366, 0
  br i1 %v1367.not, label %trap1368, label %ok1369

trap1368:                                         ; preds = %ok1363
  call fastcc void @native_trap()
  unreachable

ok1369:                                           ; preds = %ok1363
  %v1370 = inttoptr i64 %v1366 to ptr
  %v1371 = getelementptr i8, ptr %v1370, i64 8
  %v1372 = load i64, ptr %v1371, align 1
  store i64 %v1372, ptr %v5, align 8
  %v1374 = icmp eq i64 %v1334, 0
  br i1 %v1374, label %block1112, label %ok1384

ok1384:                                           ; preds = %ok1369
  %v1385 = inttoptr i64 %v1334 to ptr
  %v1386 = getelementptr i8, ptr %v1385, i64 8
  %v1387 = load i64, ptr %v1386, align 1
  store i64 %v1387, ptr %v4, align 8
  %v1389.not = icmp eq i64 %v1372, 0
  br i1 %v1389.not, label %trap1390, label %ok1391

trap1390:                                         ; preds = %ok1384
  call fastcc void @native_trap()
  unreachable

ok1391:                                           ; preds = %ok1384
  %v1392 = inttoptr i64 %v1372 to ptr
  %v1393 = getelementptr i8, ptr %v1392, i64 8
  %v1394 = load i64, ptr %v1393, align 1
  %v1395.not = icmp eq i64 %v1394, 0
  br i1 %v1395.not, label %trap1396, label %ok1397

trap1396:                                         ; preds = %ok1391
  call fastcc void @native_trap()
  unreachable

ok1397:                                           ; preds = %ok1391
  %v1398 = inttoptr i64 %v1394 to ptr
  %v1399 = getelementptr i8, ptr %v1398, i64 8
  %v1400 = load i32, ptr %v1399, align 1
  %v1401 = icmp eq i32 %v1400, 0
  br i1 %v1401, label %then1405, label %ok1416

then1405:                                         ; preds = %ok1397
  call fastcc void @native_trap()
  unreachable

ok1416:                                           ; preds = %ok1397
  %v1418 = getelementptr i8, ptr %v1398, i64 16
  %v1419 = load i64, ptr %v1418, align 1
  %v1420.not = icmp eq i64 %v1419, 0
  br i1 %v1420.not, label %trap1421, label %ok1422

trap1421:                                         ; preds = %ok1416
  call fastcc void @native_trap()
  unreachable

ok1422:                                           ; preds = %ok1416
  %v1423 = inttoptr i64 %v1419 to ptr
  %v1424 = getelementptr i8, ptr %v1423, i64 8
  %v1425 = load i64, ptr %v1424, align 1
  store i64 %v1425, ptr %v5, align 8
  %v1427 = icmp eq i64 %v1387, 0
  br i1 %v1427, label %block1112, label %ok1437

ok1437:                                           ; preds = %ok1422
  %v1438 = inttoptr i64 %v1387 to ptr
  %v1439 = getelementptr i8, ptr %v1438, i64 8
  %v1440 = load i64, ptr %v1439, align 1
  store i64 %v1440, ptr %v4, align 8
  %v1442.not = icmp eq i64 %v1425, 0
  br i1 %v1442.not, label %trap1443, label %ok1444

trap1443:                                         ; preds = %ok1437
  call fastcc void @native_trap()
  unreachable

ok1444:                                           ; preds = %ok1437
  %v1445 = inttoptr i64 %v1425 to ptr
  %v1446 = getelementptr i8, ptr %v1445, i64 8
  %v1447 = load i64, ptr %v1446, align 1
  %v1448.not = icmp eq i64 %v1447, 0
  br i1 %v1448.not, label %trap1449, label %ok1450

trap1449:                                         ; preds = %ok1444
  call fastcc void @native_trap()
  unreachable

ok1450:                                           ; preds = %ok1444
  %v1451 = inttoptr i64 %v1447 to ptr
  %v1452 = getelementptr i8, ptr %v1451, i64 8
  %v1453 = load i32, ptr %v1452, align 1
  %v1454 = icmp eq i32 %v1453, 0
  br i1 %v1454, label %then1458, label %ok1469

then1458:                                         ; preds = %ok1450
  call fastcc void @native_trap()
  unreachable

ok1469:                                           ; preds = %ok1450
  %v1471 = getelementptr i8, ptr %v1451, i64 16
  %v1472 = load i64, ptr %v1471, align 1
  %v1473.not = icmp eq i64 %v1472, 0
  br i1 %v1473.not, label %trap1474, label %ok1475

trap1474:                                         ; preds = %ok1469
  call fastcc void @native_trap()
  unreachable

ok1475:                                           ; preds = %ok1469
  %v1476 = inttoptr i64 %v1472 to ptr
  %v1477 = getelementptr i8, ptr %v1476, i64 8
  %v1478 = load i64, ptr %v1477, align 1
  store i64 %v1478, ptr %v5, align 8
  %v1480 = icmp eq i64 %v1440, 0
  br i1 %v1480, label %block1112, label %ok1490

ok1490:                                           ; preds = %ok1475
  %v1491 = inttoptr i64 %v1440 to ptr
  %v1492 = getelementptr i8, ptr %v1491, i64 8
  %v1493 = load i64, ptr %v1492, align 1
  store i64 %v1493, ptr %v4, align 8
  %v1495.not = icmp eq i64 %v1478, 0
  br i1 %v1495.not, label %trap1496, label %ok1497

trap1496:                                         ; preds = %ok1490
  call fastcc void @native_trap()
  unreachable

ok1497:                                           ; preds = %ok1490
  %v1498 = inttoptr i64 %v1478 to ptr
  %v1499 = getelementptr i8, ptr %v1498, i64 8
  %v1500 = load i64, ptr %v1499, align 1
  %v1501.not = icmp eq i64 %v1500, 0
  br i1 %v1501.not, label %trap1502, label %ok1503

trap1502:                                         ; preds = %ok1497
  call fastcc void @native_trap()
  unreachable

ok1503:                                           ; preds = %ok1497
  %v1504 = inttoptr i64 %v1500 to ptr
  %v1505 = getelementptr i8, ptr %v1504, i64 8
  %v1506 = load i32, ptr %v1505, align 1
  %v1507 = icmp eq i32 %v1506, 0
  br i1 %v1507, label %then1511, label %ok1522

then1511:                                         ; preds = %ok1503
  call fastcc void @native_trap()
  unreachable

ok1522:                                           ; preds = %ok1503
  %v1524 = getelementptr i8, ptr %v1504, i64 16
  %v1525 = load i64, ptr %v1524, align 1
  %v1526.not = icmp eq i64 %v1525, 0
  br i1 %v1526.not, label %trap1527, label %ok1528

trap1527:                                         ; preds = %ok1522
  call fastcc void @native_trap()
  unreachable

ok1528:                                           ; preds = %ok1522
  %v1529 = inttoptr i64 %v1525 to ptr
  %v1530 = getelementptr i8, ptr %v1529, i64 8
  %v1531 = load i64, ptr %v1530, align 1
  store i64 %v1531, ptr %v5, align 8
  %v1533 = icmp eq i64 %v1493, 0
  br i1 %v1533, label %block1112, label %ok1543

ok1543:                                           ; preds = %ok1528
  %v1544 = inttoptr i64 %v1493 to ptr
  %v1545 = getelementptr i8, ptr %v1544, i64 8
  %v1546 = load i64, ptr %v1545, align 1
  store i64 %v1546, ptr %v4, align 8
  %v1548.not = icmp eq i64 %v1531, 0
  br i1 %v1548.not, label %trap1549, label %ok1550

trap1549:                                         ; preds = %ok1543
  call fastcc void @native_trap()
  unreachable

ok1550:                                           ; preds = %ok1543
  %v1551 = inttoptr i64 %v1531 to ptr
  %v1552 = getelementptr i8, ptr %v1551, i64 8
  %v1553 = load i64, ptr %v1552, align 1
  %v1554.not = icmp eq i64 %v1553, 0
  br i1 %v1554.not, label %trap1555, label %ok1556

trap1555:                                         ; preds = %ok1550
  call fastcc void @native_trap()
  unreachable

ok1556:                                           ; preds = %ok1550
  %v1557 = inttoptr i64 %v1553 to ptr
  %v1558 = getelementptr i8, ptr %v1557, i64 8
  %v1559 = load i32, ptr %v1558, align 1
  %v1560 = icmp eq i32 %v1559, 0
  br i1 %v1560, label %then1564, label %ok1575

then1564:                                         ; preds = %ok1556
  call fastcc void @native_trap()
  unreachable

ok1575:                                           ; preds = %ok1556
  %v1577 = getelementptr i8, ptr %v1557, i64 16
  %v1578 = load i64, ptr %v1577, align 1
  %v1579.not = icmp eq i64 %v1578, 0
  br i1 %v1579.not, label %trap1580, label %ok1581

trap1580:                                         ; preds = %ok1575
  call fastcc void @native_trap()
  unreachable

ok1581:                                           ; preds = %ok1575
  %v1582 = inttoptr i64 %v1578 to ptr
  %v1583 = getelementptr i8, ptr %v1582, i64 8
  %v1584 = load i64, ptr %v1583, align 1
  store i64 %v1584, ptr %v5, align 8
  %v1586 = icmp eq i64 %v1546, 0
  br i1 %v1586, label %block1112, label %ok1596

ok1596:                                           ; preds = %ok1581
  %v1597 = inttoptr i64 %v1546 to ptr
  %v1598 = getelementptr i8, ptr %v1597, i64 8
  %v1599 = load i64, ptr %v1598, align 1
  store i64 %v1599, ptr %v4, align 8
  %v1601.not = icmp eq i64 %v1584, 0
  br i1 %v1601.not, label %trap1602, label %ok1603

trap1602:                                         ; preds = %ok1596
  call fastcc void @native_trap()
  unreachable

ok1603:                                           ; preds = %ok1596
  %v1604 = inttoptr i64 %v1584 to ptr
  %v1605 = getelementptr i8, ptr %v1604, i64 8
  %v1606 = load i64, ptr %v1605, align 1
  %v1607.not = icmp eq i64 %v1606, 0
  br i1 %v1607.not, label %trap1608, label %ok1609

trap1608:                                         ; preds = %ok1603
  call fastcc void @native_trap()
  unreachable

ok1609:                                           ; preds = %ok1603
  %v1610 = inttoptr i64 %v1606 to ptr
  %v1611 = getelementptr i8, ptr %v1610, i64 8
  %v1612 = load i32, ptr %v1611, align 1
  %v1613 = icmp eq i32 %v1612, 0
  br i1 %v1613, label %then1617, label %ok1628

then1617:                                         ; preds = %ok1609
  call fastcc void @native_trap()
  unreachable

ok1628:                                           ; preds = %ok1609
  %v1630 = getelementptr i8, ptr %v1610, i64 16
  %v1631 = load i64, ptr %v1630, align 1
  %v1632.not = icmp eq i64 %v1631, 0
  br i1 %v1632.not, label %trap1633, label %ok1634

trap1633:                                         ; preds = %ok1628
  call fastcc void @native_trap()
  unreachable

ok1634:                                           ; preds = %ok1628
  %v1635 = inttoptr i64 %v1631 to ptr
  %v1636 = getelementptr i8, ptr %v1635, i64 8
  %v1637 = load i64, ptr %v1636, align 1
  store i64 %v1637, ptr %v5, align 8
  %v1639 = icmp eq i64 %v1599, 0
  br i1 %v1639, label %block1112, label %ok1649

ok1649:                                           ; preds = %ok1634
  %v1650 = inttoptr i64 %v1599 to ptr
  %v1651 = getelementptr i8, ptr %v1650, i64 8
  %v1652 = load i64, ptr %v1651, align 1
  store i64 %v1652, ptr %v4, align 8
  %v1654.not = icmp eq i64 %v1637, 0
  br i1 %v1654.not, label %trap1655, label %ok1656

trap1655:                                         ; preds = %ok1649
  call fastcc void @native_trap()
  unreachable

ok1656:                                           ; preds = %ok1649
  %v1657 = inttoptr i64 %v1637 to ptr
  %v1658 = getelementptr i8, ptr %v1657, i64 8
  %v1659 = load i64, ptr %v1658, align 1
  %v1660.not = icmp eq i64 %v1659, 0
  br i1 %v1660.not, label %trap1661, label %ok1662

trap1661:                                         ; preds = %ok1656
  call fastcc void @native_trap()
  unreachable

ok1662:                                           ; preds = %ok1656
  %v1663 = inttoptr i64 %v1659 to ptr
  %v1664 = getelementptr i8, ptr %v1663, i64 8
  %v1665 = load i32, ptr %v1664, align 1
  %v1666 = icmp eq i32 %v1665, 0
  br i1 %v1666, label %then1670, label %ok1681

then1670:                                         ; preds = %ok1662
  call fastcc void @native_trap()
  unreachable

ok1681:                                           ; preds = %ok1662
  %v1683 = getelementptr i8, ptr %v1663, i64 16
  %v1684 = load i64, ptr %v1683, align 1
  %v1685.not = icmp eq i64 %v1684, 0
  br i1 %v1685.not, label %trap1686, label %ok1687

trap1686:                                         ; preds = %ok1681
  call fastcc void @native_trap()
  unreachable

ok1687:                                           ; preds = %ok1681
  %v1688 = inttoptr i64 %v1684 to ptr
  %v1689 = getelementptr i8, ptr %v1688, i64 8
  %v1690 = load i64, ptr %v1689, align 1
  store i64 %v1690, ptr %v5, align 8
  %v1692 = icmp eq i64 %v1652, 0
  br i1 %v1692, label %block1112, label %ok1702

ok1702:                                           ; preds = %ok1687
  %v1703 = inttoptr i64 %v1652 to ptr
  %v1704 = getelementptr i8, ptr %v1703, i64 8
  %v1705 = load i64, ptr %v1704, align 1
  store i64 %v1705, ptr %v4, align 8
  %v1707.not = icmp eq i64 %v1690, 0
  br i1 %v1707.not, label %trap1708, label %ok1709

trap1708:                                         ; preds = %ok1702
  call fastcc void @native_trap()
  unreachable

ok1709:                                           ; preds = %ok1702
  %v1710 = inttoptr i64 %v1690 to ptr
  %v1711 = getelementptr i8, ptr %v1710, i64 8
  %v1712 = load i64, ptr %v1711, align 1
  %v1713.not = icmp eq i64 %v1712, 0
  br i1 %v1713.not, label %trap1714, label %ok1715

trap1714:                                         ; preds = %ok1709
  call fastcc void @native_trap()
  unreachable

ok1715:                                           ; preds = %ok1709
  %v1716 = inttoptr i64 %v1712 to ptr
  %v1717 = getelementptr i8, ptr %v1716, i64 8
  %v1718 = load i32, ptr %v1717, align 1
  %v1719 = icmp eq i32 %v1718, 0
  br i1 %v1719, label %then1723, label %ok1734

then1723:                                         ; preds = %ok1715
  call fastcc void @native_trap()
  unreachable

ok1734:                                           ; preds = %ok1715
  %v1736 = getelementptr i8, ptr %v1716, i64 16
  %v1737 = load i64, ptr %v1736, align 1
  %v1738.not = icmp eq i64 %v1737, 0
  br i1 %v1738.not, label %trap1739, label %ok1740

trap1739:                                         ; preds = %ok1734
  call fastcc void @native_trap()
  unreachable

ok1740:                                           ; preds = %ok1734
  %v1741 = inttoptr i64 %v1737 to ptr
  %v1742 = getelementptr i8, ptr %v1741, i64 8
  %v1743 = load i64, ptr %v1742, align 1
  store i64 %v1743, ptr %v5, align 8
  %v1745 = icmp eq i64 %v1705, 0
  br i1 %v1745, label %block1112, label %ok1755

ok1755:                                           ; preds = %ok1740
  %v1756 = inttoptr i64 %v1705 to ptr
  %v1757 = getelementptr i8, ptr %v1756, i64 8
  %v1758 = load i64, ptr %v1757, align 1
  store i64 %v1758, ptr %v4, align 8
  %v1760.not = icmp eq i64 %v1743, 0
  br i1 %v1760.not, label %trap1761, label %ok1762

trap1761:                                         ; preds = %ok1755
  call fastcc void @native_trap()
  unreachable

ok1762:                                           ; preds = %ok1755
  %v1763 = inttoptr i64 %v1743 to ptr
  %v1764 = getelementptr i8, ptr %v1763, i64 8
  %v1765 = load i64, ptr %v1764, align 1
  %v1766.not = icmp eq i64 %v1765, 0
  br i1 %v1766.not, label %trap1767, label %ok1768

trap1767:                                         ; preds = %ok1762
  call fastcc void @native_trap()
  unreachable

ok1768:                                           ; preds = %ok1762
  %v1769 = inttoptr i64 %v1765 to ptr
  %v1770 = getelementptr i8, ptr %v1769, i64 8
  %v1771 = load i32, ptr %v1770, align 1
  %v1772 = icmp eq i32 %v1771, 0
  br i1 %v1772, label %then1776, label %ok1787

then1776:                                         ; preds = %ok1768
  call fastcc void @native_trap()
  unreachable

ok1787:                                           ; preds = %ok1768
  %v1789 = getelementptr i8, ptr %v1769, i64 16
  %v1790 = load i64, ptr %v1789, align 1
  %v1791.not = icmp eq i64 %v1790, 0
  br i1 %v1791.not, label %trap1792, label %ok1793

trap1792:                                         ; preds = %ok1787
  call fastcc void @native_trap()
  unreachable

ok1793:                                           ; preds = %ok1787
  %v1794 = inttoptr i64 %v1790 to ptr
  %v1795 = getelementptr i8, ptr %v1794, i64 8
  %v1796 = load i64, ptr %v1795, align 1
  store i64 %v1796, ptr %v5, align 8
  %v1798 = icmp eq i64 %v1758, 0
  br i1 %v1798, label %block1112, label %ok1808

ok1808:                                           ; preds = %ok1793
  %v1809 = inttoptr i64 %v1758 to ptr
  %v1810 = getelementptr i8, ptr %v1809, i64 8
  %v1811 = load i64, ptr %v1810, align 1
  store i64 %v1811, ptr %v4, align 8
  %v1813.not = icmp eq i64 %v1796, 0
  br i1 %v1813.not, label %trap1814, label %ok1815

trap1814:                                         ; preds = %ok1808
  call fastcc void @native_trap()
  unreachable

ok1815:                                           ; preds = %ok1808
  %v1816 = inttoptr i64 %v1796 to ptr
  %v1817 = getelementptr i8, ptr %v1816, i64 8
  %v1818 = load i64, ptr %v1817, align 1
  %v1819.not = icmp eq i64 %v1818, 0
  br i1 %v1819.not, label %trap1820, label %ok1821

trap1820:                                         ; preds = %ok1815
  call fastcc void @native_trap()
  unreachable

ok1821:                                           ; preds = %ok1815
  %v1822 = inttoptr i64 %v1818 to ptr
  %v1823 = getelementptr i8, ptr %v1822, i64 8
  %v1824 = load i32, ptr %v1823, align 1
  %v1825 = icmp eq i32 %v1824, 0
  br i1 %v1825, label %then1829, label %ok1840

then1829:                                         ; preds = %ok1821
  call fastcc void @native_trap()
  unreachable

ok1840:                                           ; preds = %ok1821
  %v1842 = getelementptr i8, ptr %v1822, i64 16
  %v1843 = load i64, ptr %v1842, align 1
  %v1844.not = icmp eq i64 %v1843, 0
  br i1 %v1844.not, label %trap1845, label %ok1846

trap1845:                                         ; preds = %ok1840
  call fastcc void @native_trap()
  unreachable

ok1846:                                           ; preds = %ok1840
  %v1847 = inttoptr i64 %v1843 to ptr
  %v1848 = getelementptr i8, ptr %v1847, i64 8
  %v1849 = load i64, ptr %v1848, align 1
  store i64 %v1849, ptr %v111, align 8
  store i64 %v1811, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %v76.i = icmp eq i64 %v1811, 0
  br i1 %v76.i, label %block1112, label %ok18.i

ok18.i:                                           ; preds = %ok56.i, %ok1846
  %arg2.tr9.i = phi i64 [ %v62.i, %ok56.i ], [ 14, %ok1846 ]
  %arg1.tr8.i = phi i64 [ %v21.i, %ok56.i ], [ %v1811, %ok1846 ]
  %arg0.tr7.i = phi i64 [ %v59.i, %ok56.i ], [ %v1849, %ok1846 ]
  %v19.i = inttoptr i64 %arg1.tr8.i to ptr
  %v20.i = getelementptr i8, ptr %v19.i, i64 8
  %v21.i = load i64, ptr %v20.i, align 1
  %v23.not.i = icmp eq i64 %arg0.tr7.i, 0
  br i1 %v23.not.i, label %trap24.i, label %ok25.i

trap24.i:                                         ; preds = %ok18.i
  call fastcc void @native_trap()
  unreachable

ok25.i:                                           ; preds = %ok18.i
  %v26.i = inttoptr i64 %arg0.tr7.i to ptr
  %v27.i = getelementptr i8, ptr %v26.i, i64 8
  %v28.i = load i64, ptr %v27.i, align 1
  %v29.not.i = icmp eq i64 %v28.i, 0
  br i1 %v29.not.i, label %trap30.i, label %ok31.i

trap30.i:                                         ; preds = %ok25.i
  call fastcc void @native_trap()
  unreachable

ok31.i:                                           ; preds = %ok25.i
  %v32.i = inttoptr i64 %v28.i to ptr
  %v33.i = getelementptr i8, ptr %v32.i, i64 8
  %v34.i = load i32, ptr %v33.i, align 1
  %v35.i = icmp eq i32 %v34.i, 0
  br i1 %v35.i, label %then39.i, label %ok50.i

then39.i:                                         ; preds = %ok31.i
  call fastcc void @native_trap()
  unreachable

ok50.i:                                           ; preds = %ok31.i
  %v52.i = getelementptr i8, ptr %v32.i, i64 16
  %v53.i = load i64, ptr %v52.i, align 1
  %v54.not.i = icmp eq i64 %v53.i, 0
  br i1 %v54.not.i, label %trap55.i, label %ok56.i

trap55.i:                                         ; preds = %ok50.i
  call fastcc void @native_trap()
  unreachable

ok56.i:                                           ; preds = %ok50.i
  %v57.i = inttoptr i64 %v53.i to ptr
  %v58.i = getelementptr i8, ptr %v57.i, i64 8
  %v59.i = load i64, ptr %v58.i, align 1
  %v62.i = add i64 %arg2.tr9.i, 1
  %v7.i = icmp eq i64 %v21.i, 0
  br i1 %v7.i, label %block1112, label %ok18.i

block1112:                                        ; preds = %ok56.i, %ok1846, %ok1793, %ok1740, %ok1687, %ok1634, %ok1581, %ok1528, %ok1475, %ok1422, %ok1369, %ok1316, %ok1263, %ok1210, %ok1157, %ok1104
  %slot1111.0 = phi i64 [ 0, %ok1104 ], [ 1, %ok1157 ], [ 2, %ok1210 ], [ 3, %ok1263 ], [ 4, %ok1316 ], [ 5, %ok1369 ], [ 6, %ok1422 ], [ 7, %ok1475 ], [ 8, %ok1528 ], [ 9, %ok1581 ], [ 10, %ok1634 ], [ 11, %ok1687 ], [ 12, %ok1740 ], [ 13, %ok1793 ], [ 14, %ok1846 ], [ %v62.i, %ok56.i ]
  %v1869 = load i64, ptr %v1, align 8
  %v1870.not = icmp eq i64 %v1869, 0
  br i1 %v1870.not, label %trap1871, label %ok1872

trap1871:                                         ; preds = %block1112
  call fastcc void @native_trap()
  unreachable

ok1872:                                           ; preds = %block1112
  %v1873 = inttoptr i64 %v1869 to ptr
  %v1874 = getelementptr i8, ptr %v1873, i64 16
  %v1875 = load i64, ptr %v1874, align 1
  %v1876.not = icmp eq i64 %v1875, 0
  br i1 %v1876.not, label %trap1877, label %ok1878

trap1877:                                         ; preds = %ok1872
  call fastcc void @native_trap()
  unreachable

ok1878:                                           ; preds = %ok1872
  %v1879 = inttoptr i64 %v1875 to ptr
  %v1880 = getelementptr i8, ptr %v1879, i64 8
  %v1881 = load i32, ptr %v1880, align 1
  %v1882 = icmp eq i32 %v1881, 0
  br i1 %v1882, label %then1886, label %ok1897

then1886:                                         ; preds = %ok1878
  call fastcc void @native_trap()
  unreachable

ok1897:                                           ; preds = %ok1878
  %v1899 = getelementptr i8, ptr %v1879, i64 16
  %v1900 = load i64, ptr %v1899, align 1
  %v1901.not = icmp eq i64 %v1900, 0
  br i1 %v1901.not, label %trap1902, label %ok1903

trap1902:                                         ; preds = %ok1897
  call fastcc void @native_trap()
  unreachable

ok1903:                                           ; preds = %ok1897
  %v1904 = inttoptr i64 %v1900 to ptr
  %v1905 = getelementptr i8, ptr %v1904, i64 16
  %v1906 = load i64, ptr %v1905, align 1
  %v1908 = add nsw i64 %arg1.tr1199, 1
  %671 = load i64, ptr %0, align 8, !noundef !39
  %672 = icmp ne i64 %671, 0
  %.pre413 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %673 = sext i1 %672 to i64
  %674 = add i64 %.pre413, %673
  %roots.val = load ptr, ptr %roots, align 8
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %675 = select i1 %672, ptr %roots.val, ptr %native_roots.0.val
  store i64 26, ptr %0, align 8
  store i64 0, ptr %v67, align 8
  store ptr %675, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %676 = add i64 %674, 1
  store i64 %676, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %677 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %678 = call noundef i64 @llvm.umax.i64(i64 %676, i64 %677)
  store i64 %678, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v1906, ptr %v1, align 8
  %v31.not = icmp eq i64 %v1906, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(160) %v4, i8 0, i64 160, i1 false)
  br i1 %v31.not, label %trap32, label %ok33

else42:                                           ; preds = %ok33
  %.lcssa1816 = phi i64 [ %6, %ok33 ]
  %.lcssa1629 = phi ptr [ %7, %ok33 ]
  %arg2.tr1200.lcssa = phi i64 [ %arg2.tr1200, %ok33 ]
  %arg1.tr1199.lcssa = phi i64 [ %arg1.tr1199, %ok33 ]
  %v1912 = icmp sgt i64 %arg1.tr1199.lcssa, 0
  br i1 %v1912, label %then1917, label %block1915

then1917:                                         ; preds = %else42
  %v1919.b = load i1, ptr @g.32, align 1
  br i1 %v1919.b, label %block1922, label %then1924

then1924:                                         ; preds = %then1917
  call fastcc void @native_trap()
  unreachable

block1922:                                        ; preds = %then1917
  %v1926 = load i64, ptr @g.31, align 8
  %v1928 = icmp eq i64 %v1926, %arg2.tr1200.lcssa
  %679 = zext i1 %v1928 to i64
  br label %block1915

block1915:                                        ; preds = %block1922, %else42
  %slot1914.0 = phi i64 [ %679, %block1922 ], [ 0, %else42 ]
  store ptr %.lcssa1629, ptr @native_roots.0, align 8
  store i64 %.lcssa1816, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  ret i64 %slot1914.0
}
