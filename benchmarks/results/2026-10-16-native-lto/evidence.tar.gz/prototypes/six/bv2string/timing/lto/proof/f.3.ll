define internal tailcc i32 @f.3(i64 %arg0, i32 %arg1) unnamed_addr #105 personality ptr @rust_eh_personality {
entry:
  %v10.not = icmp eq i64 %arg0, 0
  br i1 %v10.not, label %trap11, label %ok12

trap11:                                           ; preds = %entry
  tail call fastcc void @native_trap()
  unreachable

ok12:                                             ; preds = %entry
  %v13 = and i64 %arg0, 1
  %v14 = icmp eq i64 %v13, 0
  br i1 %v14, label %ok16, label %trap15

trap15:                                           ; preds = %ok12
  tail call fastcc void @native_trap()
  unreachable

ok16:                                             ; preds = %ok12
  %v17 = inttoptr i64 %arg0 to ptr
  %v18 = getelementptr i8, ptr %v17, i64 8
  %v19 = load i64, ptr %v18, align 1
  %v20 = zext i32 %arg1 to i64
  %v21 = icmp ugt i64 %v19, %v20
  br i1 %v21, label %ok23, label %trap22

trap22:                                           ; preds = %ok16
  tail call fastcc void @native_trap()
  unreachable

ok23:                                             ; preds = %ok16
  %v25 = getelementptr i8, ptr %v17, i64 16
  %v26 = getelementptr i8, ptr %v25, i64 %v20
  %v27 = load i8, ptr %v26, align 1
  %v28 = zext i8 %v27 to i32
  %v29 = icmp sgt i8 %v27, -1
  br i1 %v29, label %native_roots_leave.exit, label %else42

native_roots_leave.exit:                          ; preds = %ok82, %ok23
  %common.ret.op = phi i32 [ %v28, %ok23 ], [ %v92, %ok82 ]
  ret i32 %common.ret.op

else42:                                           ; preds = %ok23
  %v46 = icmp samesign ult i8 %v27, -32
  %v54 = icmp samesign ult i8 %v27, -16
  %v57 = select i1 %v54, i32 3, i32 4
  %slot48.0 = select i1 %v46, i32 2, i32 %v57
  %v61 = lshr i32 127, %slot48.0
  %v62 = and i32 %v61, %v28
  %wide.trip.count = zext nneg i32 %slot48.0 to i64
  br label %ok75

ok75:                                             ; preds = %ok82, %else42
  %indvars.iv = phi i64 [ %indvars.iv.next, %ok82 ], [ 1, %else42 ]
  %slot3.0 = phi i32 [ %v92, %ok82 ], [ %v62, %else42 ]
  %0 = trunc nuw nsw i64 %indvars.iv to i32
  %v68 = add i32 %arg1, %0
  %v79 = zext i32 %v68 to i64
  %v80 = icmp ugt i64 %v19, %v79
  br i1 %v80, label %ok82, label %trap81

trap81:                                           ; preds = %ok75
  tail call fastcc void @native_trap()
  unreachable

ok82:                                             ; preds = %ok75
  %v85 = getelementptr i8, ptr %v25, i64 %v79
  %v86 = load i8, ptr %v85, align 1
  %1 = and i8 %v86, 63
  %v88 = zext nneg i8 %1 to i32
  %v91 = shl i32 %slot3.0, 6
  %v92 = or disjoint i32 %v91, %v88
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %native_roots_leave.exit, label %ok75
}
