define internal tailcc noundef range(i64 1, 0) i64 @f.18(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [2 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 2, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v6 = icmp ugt i64 %arg1, 4294967295
  br i1 %v6, label %then10, label %block8

then10:                                           ; preds = %entry
  call fastcc void @native_trap()
  unreachable

block8:                                           ; preds = %entry
  %v13 = trunc nuw i64 %arg1 to i32
  store i64 1, ptr %1, align 8
  %v16 = call fastcc i64 @native_array_new(i32 %v13)
  %v17 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  store i64 %v16, ptr %v17, align 8
  store i64 2, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %block8
  call fastcc void @native_trap() #113
  unreachable

10:                                               ; preds = %block8
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 16, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %26, label %ok22

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  %25 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef %25) #84
  br label %14

26:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #113
  unreachable

ok22:                                             ; preds = %14
  store i64 130, ptr %16, align 1
  %v29 = getelementptr i8, ptr %16, i64 8
  store i64 %v16, ptr %v29, align 1
  %27 = load i64, ptr %0, align 8, !noundef !39
  %28 = icmp eq i64 %27, 0
  br i1 %28, label %native_roots_leave.exit, label %29

29:                                               ; preds = %ok22
  %30 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %30, ptr @native_roots.0, align 8
  %31 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %32 = add i64 %31, -1
  store i64 %32, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %29, %ok22
  %33 = ptrtoint ptr %16 to i64
  ret i64 %33
}
