define internal tailcc noundef i64 @f.14(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  %roots.i = alloca { ptr, i64, i64, [2 x i64] }, align 8
  %roots = alloca { ptr, i64, i64, [3 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 3, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  store i64 0, ptr %v3, align 8
  %v8 = icmp slt i64 %arg1, 16384
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %native_ref_test.exit.thread

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 46, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader [
    i64 46, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %15
  call fastcc void @native_trap() #113
  unreachable

31:                                               ; preds = %.preheader
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader [
    i64 46, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in49 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp ne i64 %.in49, 46
  br i1 %v8, label %then12, label %else11

native_ref_test.exit.thread:                      ; preds = %entry
  br i1 %v8, label %trap17, label %trap42

then12:                                           ; preds = %native_ref_test.exit
  br i1 %34, label %trap17, label %ok18

trap17:                                           ; preds = %then12, %native_ref_test.exit.thread
  call fastcc void @native_trap()
  unreachable

ok18:                                             ; preds = %then12
  br i1 %7, label %ok21, label %trap20

trap20:                                           ; preds = %ok18
  call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %ok18
  %v22 = inttoptr i64 %arg0 to ptr
  %v23 = getelementptr i8, ptr %v22, i64 8
  %v24 = load i64, ptr %v23, align 1
  %v25.not = icmp eq i64 %v24, 0
  br i1 %v25.not, label %trap26, label %ok27

trap26:                                           ; preds = %ok21
  call fastcc void @native_trap()
  unreachable

ok27:                                             ; preds = %ok21
  %v28 = inttoptr i64 %v24 to ptr
  %v29 = getelementptr i8, ptr %v28, i64 8
  %v30 = load i64, ptr %v29, align 1
  %v31.not = icmp eq i64 %v30, 0
  br i1 %v31.not, label %trap32, label %ok33

trap32:                                           ; preds = %ok27
  call fastcc void @native_trap()
  unreachable

common.ret:                                       ; preds = %native_i64_rem_s.exit, %ok33
  %common.ret.op = phi i64 [ %v38, %ok33 ], [ %53, %native_i64_rem_s.exit ]
  ret i64 %common.ret.op

ok33:                                             ; preds = %ok27
  %v34 = inttoptr i64 %v30 to ptr
  %v35 = getelementptr i8, ptr %v34, i64 16
  %v36 = load i64, ptr %v35, align 1
  store ptr %2, ptr @native_roots.0, align 8
  store i64 %3, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %v38 = tail call tailcc i64 @f.16(i64 %v36, i64 %arg1)
  br label %common.ret

else11:                                           ; preds = %native_ref_test.exit
  br i1 %34, label %trap42, label %ok43

trap42:                                           ; preds = %else11, %native_ref_test.exit.thread
  call fastcc void @native_trap()
  unreachable

ok43:                                             ; preds = %else11
  store i64 %arg0, ptr %v3, align 8
  br i1 %7, label %ok46, label %trap45

trap45:                                           ; preds = %ok43
  call fastcc void @native_trap()
  unreachable

ok46:                                             ; preds = %ok43
  %v47 = inttoptr i64 %arg0 to ptr
  %v48 = getelementptr i8, ptr %v47, i64 8
  %v49 = load i64, ptr %v48, align 1
  %v50.not = icmp eq i64 %v49, 0
  br i1 %v50.not, label %trap51, label %ok52

trap51:                                           ; preds = %ok46
  call fastcc void @native_trap()
  unreachable

ok52:                                             ; preds = %ok46
  %v53 = inttoptr i64 %v49 to ptr
  %v54 = getelementptr i8, ptr %v53, i64 8
  %v55 = load i64, ptr %v54, align 1
  %v56.not = icmp eq i64 %v55, 0
  br i1 %v56.not, label %trap57, label %ok58

trap57:                                           ; preds = %ok52
  call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %ok52
  %v59 = inttoptr i64 %v55 to ptr
  %v60 = getelementptr i8, ptr %v59, i64 16
  %v61 = load i64, ptr %v60, align 1
  %v62 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  store i64 %v61, ptr %v62, align 8
  store i64 3, ptr %1, align 8
  %v64 = call tailcc i64 @f.16(i64 %v61, i64 16384)
  %v65 = load i64, ptr %v3, align 8
  %v66.not = icmp eq i64 %v65, 0
  br i1 %v66.not, label %trap67, label %ok68

trap67:                                           ; preds = %ok58
  call fastcc void @native_trap()
  unreachable

ok68:                                             ; preds = %ok58
  %v69 = inttoptr i64 %v65 to ptr
  %v70 = getelementptr i8, ptr %v69, i64 16
  %v71 = load i64, ptr %v70, align 1
  %v72.not = icmp eq i64 %v71, 0
  br i1 %v72.not, label %trap73, label %ok74

trap73:                                           ; preds = %ok68
  call fastcc void @native_trap()
  unreachable

ok74:                                             ; preds = %ok68
  %v75 = inttoptr i64 %v71 to ptr
  %v76 = getelementptr i8, ptr %v75, i64 8
  %v77 = load i32, ptr %v76, align 1
  %v78 = icmp eq i32 %v77, 0
  br i1 %v78, label %then82, label %ok93

then82:                                           ; preds = %ok74
  call fastcc void @native_trap()
  unreachable

ok93:                                             ; preds = %ok74
  %v95 = getelementptr i8, ptr %v75, i64 16
  %v96 = load i64, ptr %v95, align 1
  %v97.not = icmp eq i64 %v96, 0
  br i1 %v97.not, label %trap98, label %ok99

trap98:                                           ; preds = %ok93
  call fastcc void @native_trap()
  unreachable

ok99:                                             ; preds = %ok93
  %v100 = inttoptr i64 %v96 to ptr
  %v101 = getelementptr i8, ptr %v100, i64 8
  %v102 = load i64, ptr %v101, align 1
  %35 = load i64, ptr %0, align 8, !noundef !39
  %36 = icmp eq i64 %35, 0
  %.pre14 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %37 = zext i1 %36 to i64
  %38 = add i64 %.pre14, %37
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %39 = select i1 %36, ptr %native_roots.0.val, ptr %roots.val
  call void @llvm.lifetime.start.p0(ptr nonnull %roots.i)
  %40 = getelementptr inbounds nuw i8, ptr %roots.i, i64 8
  store i64 2, ptr %40, align 8
  %41 = getelementptr inbounds nuw i8, ptr %roots.i, i64 16
  store i64 0, ptr %41, align 8
  store ptr %39, ptr %roots.i, align 8
  store ptr %roots.i, ptr @native_roots.0, align 8
  store i64 %38, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %42 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %43 = call noundef i64 @llvm.umax.i64(i64 %38, i64 %42)
  store i64 %43, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1.i = getelementptr inbounds nuw i8, ptr %roots.i, i64 24
  store i64 %v102, ptr %v1.i, align 8
  %v8.b13.i = load i1, ptr @g.14, align 1
  br i1 %v8.b13.i, label %block11.lr.ph.i, label %then13.i

block11.lr.ph.i:                                  ; preds = %ok99
  %v49.i = getelementptr inbounds nuw i8, ptr %roots.i, i64 32
  br label %block11.i

then13.i:                                         ; preds = %ok86.i, %ok99
  call fastcc void @native_trap()
  unreachable

block11.i:                                        ; preds = %ok86.i, %block11.lr.ph.i
  %44 = phi i64 [ %38, %block11.lr.ph.i ], [ %49, %ok86.i ]
  %45 = phi ptr [ %39, %block11.lr.ph.i ], [ %50, %ok86.i ]
  %arg2.tr16.i = phi i64 [ %v64, %block11.lr.ph.i ], [ %v96.i, %ok86.i ]
  %arg1.tr15.i.in = phi i64 [ %arg1, %block11.lr.ph.i ], [ %arg1.tr15.i, %ok86.i ]
  %arg0.tr14.i = phi i64 [ %v102, %block11.lr.ph.i ], [ %v89.i, %ok86.i ]
  %arg1.tr15.i = lshr i64 %arg1.tr15.i.in, 14
  %v15.i = load i64, ptr @g.13, align 8
  %v16.not.i = icmp eq i64 %v15.i, 0
  br i1 %v16.not.i, label %trap17.i, label %ok18.i

trap17.i:                                         ; preds = %block11.i
  call fastcc void @native_trap()
  unreachable

ok18.i:                                           ; preds = %block11.i
  %v20.i = icmp eq i64 %arg1.tr15.i, 0
  br i1 %v20.i, label %native_i64_rem_s.exit, label %else24.i

else24.i:                                         ; preds = %ok18.i
  %v31.not.i = icmp eq i64 %arg0.tr14.i, 0
  br i1 %v31.not.i, label %trap32.i, label %ok33.i

trap32.i:                                         ; preds = %else24.i
  call fastcc void @native_trap()
  unreachable

ok33.i:                                           ; preds = %else24.i
  %v34.i = inttoptr i64 %arg0.tr14.i to ptr
  %v35.i = getelementptr i8, ptr %v34.i, i64 8
  %v36.i = load i64, ptr %v35.i, align 1
  %v37.not.i = icmp eq i64 %v36.i, 0
  br i1 %v37.not.i, label %trap38.i, label %ok39.i

trap38.i:                                         ; preds = %ok33.i
  call fastcc void @native_trap()
  unreachable

ok39.i:                                           ; preds = %ok33.i
  %v40.i = inttoptr i64 %v36.i to ptr
  %v41.i = getelementptr i8, ptr %v40.i, i64 8
  %v42.i = load i64, ptr %v41.i, align 1
  %v43.not.i = icmp eq i64 %v42.i, 0
  br i1 %v43.not.i, label %trap44.i, label %ok45.i

trap44.i:                                         ; preds = %ok39.i
  call fastcc void @native_trap()
  unreachable

ok45.i:                                           ; preds = %ok39.i
  %v46.i = inttoptr i64 %v42.i to ptr
  %v47.i = getelementptr i8, ptr %v46.i, i64 16
  %v48.i = load i64, ptr %v47.i, align 1
  store i64 %v48.i, ptr %v49.i, align 8
  store i64 2, ptr %41, align 8
  %v51.i = call tailcc i64 @f.16(i64 %v48.i, i64 16384)
  %v52.i = load i64, ptr %v1.i, align 8
  %v53.not.i = icmp eq i64 %v52.i, 0
  br i1 %v53.not.i, label %trap54.i, label %ok55.i

trap54.i:                                         ; preds = %ok45.i
  call fastcc void @native_trap()
  unreachable

ok55.i:                                           ; preds = %ok45.i
  %v56.i = inttoptr i64 %v52.i to ptr
  %v57.i = getelementptr i8, ptr %v56.i, i64 16
  %v58.i = load i64, ptr %v57.i, align 1
  %v59.not.i = icmp eq i64 %v58.i, 0
  br i1 %v59.not.i, label %trap60.i, label %ok61.i

trap60.i:                                         ; preds = %ok55.i
  call fastcc void @native_trap()
  unreachable

ok61.i:                                           ; preds = %ok55.i
  %v62.i = inttoptr i64 %v58.i to ptr
  %v63.i = getelementptr i8, ptr %v62.i, i64 8
  %v64.i = load i32, ptr %v63.i, align 1
  %v65.i = icmp eq i32 %v64.i, 0
  br i1 %v65.i, label %then69.i, label %ok80.i

then69.i:                                         ; preds = %ok61.i
  call fastcc void @native_trap()
  unreachable

ok80.i:                                           ; preds = %ok61.i
  %v82.i = getelementptr i8, ptr %v62.i, i64 16
  %v83.i = load i64, ptr %v82.i, align 1
  %v84.not.i = icmp eq i64 %v83.i, 0
  br i1 %v84.not.i, label %trap85.i, label %ok86.i

trap85.i:                                         ; preds = %ok80.i
  call fastcc void @native_trap()
  unreachable

ok86.i:                                           ; preds = %ok80.i
  %v87.i = inttoptr i64 %v83.i to ptr
  %v88.i = getelementptr i8, ptr %v87.i, i64 8
  %v89.i = load i64, ptr %v88.i, align 1
  %v95.i = shl i64 %arg2.tr16.i, 14
  %v96.i = add i64 %v51.i, %v95.i
  %46 = load i64, ptr %40, align 8, !noundef !39
  %47 = icmp eq i64 %46, 0
  %.pre16 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %48 = zext i1 %47 to i64
  %49 = add i64 %.pre16, %48
  %native_roots.0.val50 = load ptr, ptr @native_roots.0, align 8
  %roots.i.val = load ptr, ptr %roots.i, align 8
  %50 = select i1 %47, ptr %native_roots.0.val50, ptr %roots.i.val
  store i64 2, ptr %40, align 8
  store i64 0, ptr %41, align 8
  store ptr %50, ptr %roots.i, align 8
  store ptr %roots.i, ptr @native_roots.0, align 8
  store i64 %49, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %51 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %52 = call noundef i64 @llvm.umax.i64(i64 %49, i64 %51)
  store i64 %52, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v89.i, ptr %v1.i, align 8
  %v8.b.i = load i1, ptr @g.14, align 1
  br i1 %v8.b.i, label %block11.i, label %then13.i

native_i64_rem_s.exit:                            ; preds = %ok18.i
  %.lcssa70 = phi i64 [ %44, %ok18.i ]
  %.lcssa60 = phi ptr [ %45, %ok18.i ]
  %arg2.tr16.i.lcssa51 = phi i64 [ %arg2.tr16.i, %ok18.i ]
  %53 = srem i64 %arg2.tr16.i.lcssa51, %arg1
  store ptr %.lcssa60, ptr @native_roots.0, align 8
  %54 = add i64 %.lcssa70, -1
  store i64 %54, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %roots.i)
  br label %common.ret
}
