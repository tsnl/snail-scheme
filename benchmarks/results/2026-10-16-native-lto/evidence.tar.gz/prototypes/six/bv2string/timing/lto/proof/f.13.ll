define internal tailcc i64 @f.13(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [4 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 4, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap11

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 42, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit8

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader7 [
    i64 42, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #113
  unreachable

.preheader7:                                      ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit8

.loopexit8:                                       ; preds = %.preheader7, %15
  call fastcc void @native_trap() #113
  unreachable

31:                                               ; preds = %.preheader7
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader7 [
    i64 42, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in96 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in96, 42
  br i1 %34, label %ok12.lr.ph, label %trap11

ok12.lr.ph:                                       ; preds = %native_ref_test.exit
  %v66 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  br label %ok12

trap11:                                           ; preds = %native_ref_test.exit3, %ok152, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok12:                                             ; preds = %native_ref_test.exit3, %ok12.lr.ph
  %35 = phi i64 [ %4, %ok12.lr.ph ], [ %41, %native_ref_test.exit3 ]
  %36 = phi ptr [ %2, %ok12.lr.ph ], [ %42, %native_ref_test.exit3 ]
  %arg1.tr22 = phi i64 [ %arg1, %ok12.lr.ph ], [ %v157, %native_ref_test.exit3 ]
  %arg0.tr21 = phi i64 [ %arg0, %ok12.lr.ph ], [ %v155, %native_ref_test.exit3 ]
  store i64 %arg0.tr21, ptr %v3, align 8
  %v16 = inttoptr i64 %arg0.tr21 to ptr
  %v17 = getelementptr i8, ptr %v16, i64 16
  %v18 = load i64, ptr %v17, align 1
  %v20 = icmp eq i64 %v18, %arg1.tr22
  br i1 %v20, label %ok30, label %ok37

ok30:                                             ; preds = %ok12
  %.lcssa135 = phi i64 [ %35, %ok12 ]
  %.lcssa116 = phi ptr [ %36, %ok12 ]
  %v16.lcssa = phi ptr [ %v16, %ok12 ]
  %v32 = getelementptr i8, ptr %v16.lcssa, i64 24
  %v33 = load i64, ptr %v32, align 1
  store ptr %.lcssa116, ptr @native_roots.0, align 8
  %37 = add i64 %.lcssa135, -1
  store i64 %37, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  ret i64 %v33

ok37:                                             ; preds = %ok12
  %v39 = getelementptr i8, ptr %v16, i64 8
  %v40 = load i64, ptr %v39, align 1
  %v41.not = icmp eq i64 %v40, 0
  br i1 %v41.not, label %trap42, label %ok43

trap42:                                           ; preds = %ok37
  call fastcc void @native_trap()
  unreachable

ok43:                                             ; preds = %ok37
  %v44 = inttoptr i64 %v40 to ptr
  %v45 = getelementptr i8, ptr %v44, i64 8
  %v46 = load i64, ptr %v45, align 1
  store i64 %v46, ptr %v4, align 8
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %ok43
  call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %ok43
  %v50 = inttoptr i64 %v46 to ptr
  %v58 = getelementptr i8, ptr %v50, i64 8
  %v59 = load i64, ptr %v58, align 1
  %v60.not = icmp eq i64 %v59, 0
  br i1 %v60.not, label %trap61, label %ok62

trap61:                                           ; preds = %ok49
  call fastcc void @native_trap()
  unreachable

ok62:                                             ; preds = %ok49
  %v51 = getelementptr i8, ptr %v50, i64 16
  %v52 = load i64, ptr %v51, align 1
  %v63 = inttoptr i64 %v59 to ptr
  %v64 = getelementptr i8, ptr %v63, i64 8
  %v65 = load ptr, ptr %v64, align 1
  store i64 %v52, ptr %v66, align 8
  store i64 4, ptr %1, align 8
  %v68 = call tailcc i64 %v65(i64 %v52, i64 128)
  %v70 = icmp ugt i64 %arg1.tr22, 4294967295
  br i1 %v70, label %then74, label %block72

then74:                                           ; preds = %ok62
  call fastcc void @native_trap()
  unreachable

block72:                                          ; preds = %ok62
  %v77 = icmp ugt i64 %v68, 255
  br i1 %v77, label %then81, label %block79

then81:                                           ; preds = %block72
  call fastcc void @native_trap()
  unreachable

block79:                                          ; preds = %block72
  %v83 = load i64, ptr %v3, align 8
  %v84.not = icmp eq i64 %v83, 0
  br i1 %v84.not, label %trap85, label %ok86

trap85:                                           ; preds = %block79
  call fastcc void @native_trap()
  unreachable

ok86:                                             ; preds = %block79
  %v87 = inttoptr i64 %v83 to ptr
  %v88 = getelementptr i8, ptr %v87, i64 24
  %v89 = load i64, ptr %v88, align 1
  %v90.not = icmp eq i64 %v89, 0
  br i1 %v90.not, label %trap91, label %ok92

trap91:                                           ; preds = %ok86
  call fastcc void @native_trap()
  unreachable

ok92:                                             ; preds = %ok86
  %v93 = inttoptr i64 %v89 to ptr
  %v94 = getelementptr i8, ptr %v93, i64 8
  %v95 = load i64, ptr %v94, align 1
  %v100.not = icmp eq i64 %v95, 0
  br i1 %v100.not, label %trap101, label %ok102

trap101:                                          ; preds = %ok92
  call fastcc void @native_trap()
  unreachable

ok102:                                            ; preds = %ok92
  %v103 = and i64 %v95, 1
  %v104 = icmp eq i64 %v103, 0
  br i1 %v104, label %ok106, label %trap105

trap105:                                          ; preds = %ok102
  call fastcc void @native_trap()
  unreachable

ok106:                                            ; preds = %ok102
  %v107 = inttoptr i64 %v95 to ptr
  %v108 = getelementptr i8, ptr %v107, i64 8
  %v109 = load i64, ptr %v108, align 1
  %v111 = icmp ult i64 %arg1.tr22, %v109
  br i1 %v111, label %ok113, label %trap112

trap112:                                          ; preds = %ok106
  call fastcc void @native_trap()
  unreachable

ok113:                                            ; preds = %ok106
  %v115 = getelementptr i8, ptr %v107, i64 16
  %v116 = getelementptr i8, ptr %v115, i64 %arg1.tr22
  %v117 = trunc nuw i64 %v68 to i8
  store i8 %v117, ptr %v116, align 1
  %v118 = load i64, ptr %v3, align 8
  %v119.not = icmp eq i64 %v118, 0
  br i1 %v119.not, label %trap120, label %ok121

trap120:                                          ; preds = %ok113
  call fastcc void @native_trap()
  unreachable

ok121:                                            ; preds = %ok113
  %v122 = inttoptr i64 %v118 to ptr
  %v123 = getelementptr i8, ptr %v122, i64 32
  %v124 = load i64, ptr %v123, align 1
  %v125.not = icmp eq i64 %v124, 0
  br i1 %v125.not, label %trap126, label %ok127

trap126:                                          ; preds = %ok121
  call fastcc void @native_trap()
  unreachable

ok127:                                            ; preds = %ok121
  %v128 = inttoptr i64 %v124 to ptr
  %v129 = getelementptr i8, ptr %v128, i64 8
  %v130 = load i32, ptr %v129, align 1
  %v131 = icmp eq i32 %v130, 0
  br i1 %v131, label %then135, label %ok146

then135:                                          ; preds = %ok127
  call fastcc void @native_trap()
  unreachable

ok146:                                            ; preds = %ok127
  %v148 = getelementptr i8, ptr %v128, i64 16
  %v149 = load i64, ptr %v148, align 1
  %v150.not = icmp eq i64 %v149, 0
  br i1 %v150.not, label %trap151, label %ok152

trap151:                                          ; preds = %ok146
  call fastcc void @native_trap()
  unreachable

ok152:                                            ; preds = %ok146
  %v153 = inttoptr i64 %v149 to ptr
  %v154 = getelementptr i8, ptr %v153, i64 16
  %v155 = load i64, ptr %v154, align 1
  %v157 = add nuw nsw i64 %arg1.tr22, 1
  %38 = load i64, ptr %0, align 8, !noundef !39
  %39 = icmp eq i64 %38, 0
  %.pre28 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %40 = zext i1 %39 to i64
  %41 = add i64 %.pre28, %40
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %42 = select i1 %39, ptr %native_roots.0.val, ptr %roots.val
  store i64 4, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %42, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %41, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %43 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %44 = call noundef i64 @llvm.umax.i64(i64 %41, i64 %43)
  store i64 %44, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v155, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %45 = icmp ne i64 %v155, 0
  %46 = and i64 %v155, 1
  %.not.i2 = icmp eq i64 %46, 0
  %or.cond88 = and i1 %45, %.not.i2
  br i1 %or.cond88, label %47, label %trap11

47:                                               ; preds = %ok152
  %48 = inttoptr i64 %v155 to ptr
  %49 = load i64, ptr %48, align 8, !noundef !39
  %50 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %51 = icmp eq ptr %50, null
  br i1 %51, label %64, label %52

52:                                               ; preds = %47
  switch i64 %49, label %53 [
    i64 42, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

53:                                               ; preds = %52
  %54 = getelementptr inbounds nuw i8, ptr %50, i64 360
  %55 = load i64, ptr %54, align 8, !noundef !39
  %56 = lshr i64 %49, 2
  %57 = add nsw i64 %56, -1
  %58 = icmp ult i64 %57, %55
  br i1 %58, label %59, label %.loopexit

59:                                               ; preds = %53
  %60 = getelementptr inbounds nuw i8, ptr %50, i64 352
  %61 = load ptr, ptr %60, align 8, !nonnull !39, !noundef !39
  %62 = getelementptr inbounds nuw i64, ptr %61, i64 %57
  %63 = load i64, ptr %62, align 8, !noundef !39
  switch i64 %63, label %.preheader [
    i64 42, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

64:                                               ; preds = %47
  call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %69, %59
  %65 = phi i64 [ %71, %69 ], [ %63, %59 ]
  %66 = lshr i64 %65, 2
  %67 = add nsw i64 %66, -1
  %68 = icmp ult i64 %67, %55
  br i1 %68, label %69, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %53
  call fastcc void @native_trap() #113
  unreachable

69:                                               ; preds = %.preheader
  %70 = getelementptr inbounds nuw i64, ptr %61, i64 %67
  %71 = load i64, ptr %70, align 8, !noundef !39
  switch i64 %71, label %.preheader [
    i64 42, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

native_ref_test.exit3:                            ; preds = %69, %69, %59, %59, %52, %52
  %.in = phi i64 [ %49, %52 ], [ %63, %59 ], [ %63, %59 ], [ %49, %52 ], [ %71, %69 ], [ %71, %69 ]
  %72 = icmp eq i64 %.in, 42
  br i1 %72, label %ok12, label %trap11
}
