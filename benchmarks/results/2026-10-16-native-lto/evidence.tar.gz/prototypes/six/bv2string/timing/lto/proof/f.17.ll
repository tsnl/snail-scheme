define internal tailcc noundef i32 @f.17(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [5 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 5, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap11

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 10, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit15

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader14 [
    i64 10, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #113
  unreachable

.preheader14:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit15

.loopexit15:                                      ; preds = %.preheader14, %15
  call fastcc void @native_trap() #113
  unreachable

31:                                               ; preds = %.preheader14
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader14 [
    i64 10, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in70 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in70, 10
  br i1 %34, label %ok12.lr.ph, label %trap11

ok12.lr.ph:                                       ; preds = %native_ref_test.exit
  %v68 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v69 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  br label %ok15

trap11:                                           ; preds = %native_ref_test.exit6, %ok110, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok15:                                             ; preds = %native_ref_test.exit6, %ok12.lr.ph
  %35 = phi i64 [ %4, %ok12.lr.ph ], [ %64, %native_ref_test.exit6 ]
  %36 = phi ptr [ %2, %ok12.lr.ph ], [ %65, %native_ref_test.exit6 ]
  %37 = phi ptr [ %12, %ok12.lr.ph ], [ %73, %native_ref_test.exit6 ]
  %38 = phi i64 [ %11, %ok12.lr.ph ], [ %72, %native_ref_test.exit6 ]
  %arg1.tr30 = phi i64 [ %arg1, %ok12.lr.ph ], [ %v115, %native_ref_test.exit6 ]
  %v34 = phi i64 [ %arg0, %ok12.lr.ph ], [ %v113, %native_ref_test.exit6 ]
  %v16 = inttoptr i64 %v34 to ptr
  %v17 = getelementptr i8, ptr %v16, i64 8
  %v18 = load i64, ptr %v17, align 1
  %v19.not = icmp eq i64 %v18, 0
  br i1 %v19.not, label %trap20, label %ok21

trap20:                                           ; preds = %ok15
  call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %ok15
  %v22 = inttoptr i64 %v18 to ptr
  %v23 = getelementptr i8, ptr %v22, i64 8
  %v24 = load i32, ptr %v23, align 1
  %v25 = zext i32 %v24 to i64
  %v26 = icmp eq i64 %arg1.tr30, %v25
  br i1 %v26, label %then31, label %else30

then31:                                           ; preds = %ok21
  %.lcssa91 = phi i64 [ %35, %ok21 ]
  %.lcssa76 = phi ptr [ %36, %ok21 ]
  store ptr %.lcssa76, ptr @native_roots.0, align 8
  %39 = add i64 %.lcssa91, -1
  store i64 %39, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  ret i32 0

else30:                                           ; preds = %ok21
  %40 = and i64 %v34, 1
  %.not.i1 = icmp eq i64 %40, 0
  br i1 %.not.i1, label %41, label %trap37

41:                                               ; preds = %else30
  switch i64 %38, label %42 [
    i64 10, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

42:                                               ; preds = %41
  %43 = getelementptr inbounds nuw i8, ptr %37, i64 360
  %44 = load i64, ptr %43, align 8, !noundef !39
  %45 = lshr i64 %38, 2
  %46 = add nsw i64 %45, -1
  %47 = icmp ult i64 %46, %44
  br i1 %47, label %48, label %.loopexit11

48:                                               ; preds = %42
  %49 = getelementptr inbounds nuw i8, ptr %37, i64 352
  %50 = load ptr, ptr %49, align 8, !nonnull !39, !noundef !39
  %51 = getelementptr inbounds nuw i64, ptr %50, i64 %46
  %52 = load i64, ptr %51, align 8, !noundef !39
  switch i64 %52, label %.preheader10 [
    i64 10, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader10:                                     ; preds = %57, %48
  %53 = phi i64 [ %59, %57 ], [ %52, %48 ]
  %54 = lshr i64 %53, 2
  %55 = add nsw i64 %54, -1
  %56 = icmp ult i64 %55, %44
  br i1 %56, label %57, label %.loopexit11

.loopexit11:                                      ; preds = %.preheader10, %42
  call fastcc void @native_trap() #113
  unreachable

57:                                               ; preds = %.preheader10
  %58 = getelementptr inbounds nuw i64, ptr %50, i64 %55
  %59 = load i64, ptr %58, align 8, !noundef !39
  switch i64 %59, label %.preheader10 [
    i64 10, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

native_ref_test.exit2:                            ; preds = %57, %57, %48, %48, %41, %41
  %.in71 = phi i64 [ %38, %41 ], [ %52, %48 ], [ %52, %48 ], [ %38, %41 ], [ %59, %57 ], [ %59, %57 ]
  %60 = icmp eq i64 %.in71, 10
  br i1 %60, label %ok38, label %trap37

trap37:                                           ; preds = %native_ref_test.exit2, %else30
  call fastcc void @native_trap()
  unreachable

ok38:                                             ; preds = %native_ref_test.exit2
  store i64 %v34, ptr %v3, align 8
  %v44 = load i64, ptr %v17, align 1
  store i64 %v44, ptr %v4, align 8
  %v45.not = icmp eq i64 %v44, 0
  br i1 %v45.not, label %trap46, label %ok47

trap46:                                           ; preds = %ok38
  call fastcc void @native_trap()
  unreachable

ok47:                                             ; preds = %ok38
  %v48 = inttoptr i64 %v44 to ptr
  %v49 = getelementptr i8, ptr %v48, i64 8
  %v50 = load i32, ptr %v49, align 1
  %v51 = zext i32 %v50 to i64
  %v52.not = icmp ult i64 %arg1.tr30, %v51
  br i1 %v52.not, label %native_roots_leave.exit3, label %then56

then56:                                           ; preds = %ok47
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit3:                         ; preds = %ok47
  %v63 = getelementptr i8, ptr %v48, i64 24
  %v64 = load i64, ptr %v63, align 1
  %v67 = trunc nuw i64 %arg1.tr30 to i32
  store i64 %v64, ptr %v68, align 8
  store i64 %v44, ptr %v69, align 8
  store i64 5, ptr %1, align 8
  %v71 = call tailcc i32 @f.4(i64 %v44, i32 %v67)
  store i64 %v64, ptr %v68, align 8
  store i64 4, ptr %1, align 8
  %v74 = call tailcc i32 @f.3(i64 %v64, i32 %v71)
  store i64 3, ptr %1, align 8
  call void @benchmark_opaque_write_character(i32 %v74)
  %v76 = load i64, ptr %v3, align 8
  %v77.not = icmp eq i64 %v76, 0
  br i1 %v77.not, label %trap78, label %ok79

trap78:                                           ; preds = %native_roots_leave.exit3
  call fastcc void @native_trap()
  unreachable

ok79:                                             ; preds = %native_roots_leave.exit3
  %v80 = inttoptr i64 %v76 to ptr
  %v81 = getelementptr i8, ptr %v80, i64 16
  %v82 = load i64, ptr %v81, align 1
  %v83.not = icmp eq i64 %v82, 0
  br i1 %v83.not, label %trap84, label %ok85

trap84:                                           ; preds = %ok79
  call fastcc void @native_trap()
  unreachable

ok85:                                             ; preds = %ok79
  %v86 = inttoptr i64 %v82 to ptr
  %v87 = getelementptr i8, ptr %v86, i64 8
  %v88 = load i32, ptr %v87, align 1
  %v89 = icmp eq i32 %v88, 0
  br i1 %v89, label %then93, label %ok104

then93:                                           ; preds = %ok85
  call fastcc void @native_trap()
  unreachable

ok104:                                            ; preds = %ok85
  %v106 = getelementptr i8, ptr %v86, i64 16
  %v107 = load i64, ptr %v106, align 1
  %v108.not = icmp eq i64 %v107, 0
  br i1 %v108.not, label %trap109, label %ok110

trap109:                                          ; preds = %ok104
  call fastcc void @native_trap()
  unreachable

ok110:                                            ; preds = %ok104
  %v111 = inttoptr i64 %v107 to ptr
  %v112 = getelementptr i8, ptr %v111, i64 16
  %v113 = load i64, ptr %v112, align 1
  %v115 = add nuw nsw i64 %arg1.tr30, 1
  %61 = load i64, ptr %0, align 8, !noundef !39
  %62 = icmp eq i64 %61, 0
  %.pre18 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %63 = zext i1 %62 to i64
  %64 = add i64 %.pre18, %63
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %65 = select i1 %62, ptr %native_roots.0.val, ptr %roots.val
  store i64 5, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %65, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %66 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %67 = call noundef i64 @llvm.umax.i64(i64 %64, i64 %66)
  store i64 %67, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v113, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %68 = icmp ne i64 %v113, 0
  %69 = and i64 %v113, 1
  %.not.i5 = icmp eq i64 %69, 0
  %or.cond59 = and i1 %68, %.not.i5
  br i1 %or.cond59, label %70, label %trap11

70:                                               ; preds = %ok110
  %71 = inttoptr i64 %v113 to ptr
  %72 = load i64, ptr %71, align 8, !noundef !39
  %73 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %74 = icmp eq ptr %73, null
  br i1 %74, label %87, label %75

75:                                               ; preds = %70
  switch i64 %72, label %76 [
    i64 10, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

76:                                               ; preds = %75
  %77 = getelementptr inbounds nuw i8, ptr %73, i64 360
  %78 = load i64, ptr %77, align 8, !noundef !39
  %79 = lshr i64 %72, 2
  %80 = add nsw i64 %79, -1
  %81 = icmp ult i64 %80, %78
  br i1 %81, label %82, label %.loopexit

82:                                               ; preds = %76
  %83 = getelementptr inbounds nuw i8, ptr %73, i64 352
  %84 = load ptr, ptr %83, align 8, !nonnull !39, !noundef !39
  %85 = getelementptr inbounds nuw i64, ptr %84, i64 %80
  %86 = load i64, ptr %85, align 8, !noundef !39
  switch i64 %86, label %.preheader [
    i64 10, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

87:                                               ; preds = %70
  call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %92, %82
  %88 = phi i64 [ %94, %92 ], [ %86, %82 ]
  %89 = lshr i64 %88, 2
  %90 = add nsw i64 %89, -1
  %91 = icmp ult i64 %90, %78
  br i1 %91, label %92, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %76
  call fastcc void @native_trap() #113
  unreachable

92:                                               ; preds = %.preheader
  %93 = getelementptr inbounds nuw i64, ptr %84, i64 %90
  %94 = load i64, ptr %93, align 8, !noundef !39
  switch i64 %94, label %.preheader [
    i64 10, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

native_ref_test.exit6:                            ; preds = %92, %92, %82, %82, %75, %75
  %.in = phi i64 [ %72, %75 ], [ %86, %82 ], [ %86, %82 ], [ %72, %75 ], [ %94, %92 ], [ %94, %92 ]
  %95 = icmp eq i64 %.in, 10
  br i1 %95, label %ok15, label %trap11
}
