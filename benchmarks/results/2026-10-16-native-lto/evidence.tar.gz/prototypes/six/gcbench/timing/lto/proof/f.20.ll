define internal tailcc range(i64 1, 0) i64 @f.20(i64 %arg0, i64 range(i64 0, 9223372036854775800) %arg1) unnamed_addr #105 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [5 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 5, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v8 = icmp eq i64 %arg1, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  br i1 %v8, label %then12, label %else11

common.ret:                                       ; preds = %native_roots_leave.exit1, %then12
  %common.ret.op = phi i64 [ %v14, %then12 ], [ %v99, %native_roots_leave.exit1 ]
  ret i64 %common.ret.op

then12:                                           ; preds = %entry
  store ptr %2, ptr @native_roots.0, align 8
  store i64 %3, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %v14 = tail call tailcc i64 @f.9()
  br label %common.ret

else11:                                           ; preds = %entry
  %v16.not = icmp eq i64 %arg0, 0
  br i1 %v16.not, label %trap17, label %ok18

trap17:                                           ; preds = %else11
  call fastcc void @native_trap()
  unreachable

ok18:                                             ; preds = %else11
  %v19 = inttoptr i64 %arg0 to ptr
  %v20 = getelementptr i8, ptr %v19, i64 16
  %v21 = load i64, ptr %v20, align 1
  %v22.not = icmp eq i64 %v21, 0
  br i1 %v22.not, label %trap23, label %ok24

trap23:                                           ; preds = %ok18
  call fastcc void @native_trap()
  unreachable

ok24:                                             ; preds = %ok18
  %v25 = inttoptr i64 %v21 to ptr
  %v26 = getelementptr i8, ptr %v25, i64 8
  %v27 = load i32, ptr %v26, align 1
  %v28 = icmp eq i32 %v27, 0
  br i1 %v28, label %then32, label %ok37

then32:                                           ; preds = %ok24
  call fastcc void @native_trap()
  unreachable

ok37:                                             ; preds = %ok24
  store i64 %v21, ptr %v3, align 8
  %v45 = getelementptr i8, ptr %v25, i64 16
  %v46 = load i64, ptr %v45, align 1
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %ok37
  call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %ok37
  %v50 = inttoptr i64 %v46 to ptr
  %v51 = getelementptr i8, ptr %v50, i64 8
  %v52 = load i64, ptr %v51, align 1
  %v54 = add nsw i64 %arg1, -1
  %v55 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 %v52, ptr %v55, align 8
  store i64 4, ptr %1, align 8
  %v57 = call tailcc i64 @f.20(i64 %v52, i64 %v54)
  %v60 = load i64, ptr %v3, align 8
  %v61.not = icmp eq i64 %v60, 0
  br i1 %v61.not, label %trap62, label %ok63

trap62:                                           ; preds = %ok49
  call fastcc void @native_trap()
  unreachable

ok63:                                             ; preds = %ok49
  %v64 = inttoptr i64 %v60 to ptr
  %v65 = getelementptr i8, ptr %v64, i64 8
  %v66 = load i32, ptr %v65, align 1
  %v67 = icmp eq i32 %v66, 0
  br i1 %v67, label %then71, label %block69

then71:                                           ; preds = %ok63
  call fastcc void @native_trap()
  unreachable

block69:                                          ; preds = %ok63
  %v73 = load i64, ptr %v1, align 8
  %v74.not = icmp eq i64 %v73, 0
  br i1 %v74.not, label %trap75, label %ok76

trap75:                                           ; preds = %block69
  call fastcc void @native_trap()
  unreachable

ok76:                                             ; preds = %block69
  %v77 = inttoptr i64 %v73 to ptr
  %v78 = getelementptr i8, ptr %v77, i64 16
  %v79 = load i64, ptr %v78, align 1
  %v80.not = icmp eq i64 %v79, 0
  br i1 %v80.not, label %trap81, label %ok82

trap81:                                           ; preds = %ok76
  call fastcc void @native_trap()
  unreachable

ok82:                                             ; preds = %ok76
  %v83 = inttoptr i64 %v79 to ptr
  %v84 = getelementptr i8, ptr %v83, i64 16
  %v85 = load i64, ptr %v84, align 1
  %v86.not = icmp eq i64 %v85, 0
  br i1 %v86.not, label %trap87, label %ok88

trap87:                                           ; preds = %ok82
  call fastcc void @native_trap()
  unreachable

ok88:                                             ; preds = %ok82
  %v89 = inttoptr i64 %v85 to ptr
  %v90 = getelementptr i8, ptr %v89, i64 8
  %v91 = load i64, ptr %v90, align 1
  store i64 %v57, ptr %v55, align 8
  %v95 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 %v91, ptr %v95, align 8
  store i64 5, ptr %1, align 8
  %v97 = call tailcc i64 @f.20(i64 %v91, i64 %v54)
  %7 = load i64, ptr %0, align 8, !noundef !39
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %native_roots_leave.exit1, label %9

9:                                                ; preds = %ok88
  %10 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %10, ptr @native_roots.0, align 8
  %11 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %12 = add i64 %11, -1
  store i64 %12, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit1

native_roots_leave.exit1:                         ; preds = %9, %ok88
  %v99 = tail call tailcc i64 @f.10(i64 %v57, i64 %v97)
  br label %common.ret
}
