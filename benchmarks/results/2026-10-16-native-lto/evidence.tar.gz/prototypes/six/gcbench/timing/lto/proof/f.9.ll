define internal tailcc noundef range(i64 1, 0) i64 @f.9() unnamed_addr #105 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [2 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 2, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v3.b = load i1, ptr @g.5, align 1
  br i1 %v3.b, label %block6, label %then8

then8:                                            ; preds = %entry
  call fastcc void @native_trap()
  unreachable

block6:                                           ; preds = %entry
  %v10 = load i64, ptr @g.4, align 8
  %v11.not = icmp eq i64 %v10, 0
  br i1 %v11.not, label %trap12, label %ok13

trap12:                                           ; preds = %block6
  call fastcc void @native_trap()
  unreachable

ok13:                                             ; preds = %block6
  %v15 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v15, align 8
  store i64 1, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %ok13
  call fastcc void @native_trap() #114
  unreachable

10:                                               ; preds = %ok13
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = phi ptr [ %.pre, %24 ], [ %roots, %18 ], [ %roots, %10 ]
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 16, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %25, label %ok20

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %14

25:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok20:                                             ; preds = %14
  %26 = ptrtoint ptr %16 to i64
  store i64 62, ptr %16, align 1
  %v27 = getelementptr i8, ptr %16, i64 8
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v27, align 1
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v15, align 8
  %v30 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  store i64 %26, ptr %v30, align 8
  store i64 2, ptr %1, align 8
  %27 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %28 = icmp eq ptr %27, null
  br i1 %28, label %29, label %30

29:                                               ; preds = %ok20
  call fastcc void @native_trap() #114
  unreachable

30:                                               ; preds = %ok20
  %31 = getelementptr inbounds nuw i8, ptr %27, i64 376
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %34, label %38

34:                                               ; preds = %44, %38, %30
  %35 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %36 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %27, i64 noundef 16, ptr noundef %35) #84
  %37 = icmp eq ptr %36, null
  br i1 %37, label %46, label %ok35

38:                                               ; preds = %30
  %39 = getelementptr inbounds nuw i8, ptr %27, i64 368
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = add i64 %40, 1
  store i64 %41, ptr %39, align 8
  %42 = urem i64 %41, %32
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %44, label %34

44:                                               ; preds = %38
  %45 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %27, ptr noundef %45) #84
  br label %34

46:                                               ; preds = %34
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok35:                                             ; preds = %34
  %47 = ptrtoint ptr %36 to i64
  store i64 62, ptr %36, align 1
  %v42 = getelementptr i8, ptr %36, i64 8
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v42, align 1
  store i64 %47, ptr %v15, align 8
  store i64 %26, ptr %v30, align 8
  store i64 2, ptr %1, align 8
  %48 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %ok35
  call fastcc void @native_trap() #114
  unreachable

51:                                               ; preds = %ok35
  %52 = getelementptr inbounds nuw i8, ptr %48, i64 376
  %53 = load i64, ptr %52, align 8, !noundef !39
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %55, label %59

55:                                               ; preds = %65, %59, %51
  %56 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %57 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %48, i64 noundef 24, ptr noundef %56) #84
  %58 = icmp eq ptr %57, null
  br i1 %58, label %67, label %ok49

59:                                               ; preds = %51
  %60 = getelementptr inbounds nuw i8, ptr %48, i64 368
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = add i64 %61, 1
  store i64 %62, ptr %60, align 8
  %63 = urem i64 %62, %53
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %65, label %55

65:                                               ; preds = %59
  %66 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %48, ptr noundef %66) #84
  br label %55

67:                                               ; preds = %55
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok49:                                             ; preds = %55
  store i64 82, ptr %57, align 1
  %v56 = getelementptr i8, ptr %57, i64 8
  store i64 %26, ptr %v56, align 1
  %v61 = getelementptr i8, ptr %57, i64 16
  store i64 %47, ptr %v61, align 1
  %68 = load i64, ptr %0, align 8, !noundef !39
  %69 = icmp eq i64 %68, 0
  br i1 %69, label %native_roots_leave.exit, label %70

70:                                               ; preds = %ok49
  %71 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %71, ptr @native_roots.0, align 8
  %72 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %73 = add i64 %72, -1
  store i64 %73, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %70, %ok49
  %74 = ptrtoint ptr %57 to i64
  ret i64 %74
}
