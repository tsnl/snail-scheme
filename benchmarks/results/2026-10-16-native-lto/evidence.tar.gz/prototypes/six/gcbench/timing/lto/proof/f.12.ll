define internal tailcc noundef i32 @f.12(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [6 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 6, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap11

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 46, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit32

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader31 [
    i64 46, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #114
  unreachable

.preheader31:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit32

.loopexit32:                                      ; preds = %.preheader31, %15
  call fastcc void @native_trap() #114
  unreachable

31:                                               ; preds = %.preheader31
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader31 [
    i64 46, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in154 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in154, 46
  br i1 %34, label %ok12.lr.ph, label %trap11

ok12.lr.ph:                                       ; preds = %native_ref_test.exit
  %v101 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v127 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v128 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  br label %ok15

trap11:                                           ; preds = %native_ref_test.exit11, %ok194, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok15:                                             ; preds = %native_ref_test.exit11, %ok12.lr.ph
  %35 = phi i64 [ %4, %ok12.lr.ph ], [ %157, %native_ref_test.exit11 ]
  %36 = phi ptr [ %2, %ok12.lr.ph ], [ %158, %native_ref_test.exit11 ]
  %37 = phi ptr [ %12, %ok12.lr.ph ], [ %166, %native_ref_test.exit11 ]
  %38 = phi i64 [ %11, %ok12.lr.ph ], [ %165, %native_ref_test.exit11 ]
  %arg1.tr50 = phi i64 [ %arg1, %ok12.lr.ph ], [ %v199, %native_ref_test.exit11 ]
  %v50 = phi i64 [ %arg0, %ok12.lr.ph ], [ %v197, %native_ref_test.exit11 ]
  %v16 = inttoptr i64 %v50 to ptr
  %v17 = getelementptr i8, ptr %v16, i64 8
  %v18 = load i64, ptr %v17, align 1
  %v20 = icmp slt i64 %v18, %arg1.tr50
  br i1 %v20, label %then25, label %else24

then25:                                           ; preds = %ok15
  %.lcssa194 = phi i64 [ %35, %ok15 ]
  %.lcssa164 = phi ptr [ %36, %ok15 ]
  store ptr %.lcssa164, ptr @native_roots.0, align 8
  %39 = add i64 %.lcssa194, -1
  store i64 %39, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  ret i32 0

else24:                                           ; preds = %ok15
  %40 = and i64 %v50, 1
  %.not.i1 = icmp eq i64 %40, 0
  br i1 %.not.i1, label %41, label %trap30

41:                                               ; preds = %else24
  %42 = icmp eq i64 %38, 46
  switch i64 %38, label %43 [
    i64 46, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

43:                                               ; preds = %41
  %44 = getelementptr inbounds nuw i8, ptr %37, i64 360
  %45 = load i64, ptr %44, align 8, !noundef !39
  %46 = lshr i64 %38, 2
  %47 = add nsw i64 %46, -1
  %48 = icmp ult i64 %47, %45
  br i1 %48, label %49, label %.loopexit25

49:                                               ; preds = %43
  %50 = getelementptr inbounds nuw i8, ptr %37, i64 352
  %51 = load ptr, ptr %50, align 8, !nonnull !39, !noundef !39
  %52 = getelementptr inbounds nuw i64, ptr %51, i64 %47
  %53 = load i64, ptr %52, align 8, !noundef !39
  %54 = icmp eq i64 %53, 46
  switch i64 %53, label %.preheader24 [
    i64 46, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader24:                                     ; preds = %59, %49
  %55 = phi i64 [ %61, %59 ], [ %53, %49 ]
  %56 = lshr i64 %55, 2
  %57 = add nsw i64 %56, -1
  %58 = icmp ult i64 %57, %45
  br i1 %58, label %59, label %.loopexit25

.loopexit25:                                      ; preds = %.preheader24, %43
  call fastcc void @native_trap() #114
  unreachable

59:                                               ; preds = %.preheader24
  %60 = getelementptr inbounds nuw i64, ptr %51, i64 %57
  %61 = load i64, ptr %60, align 8, !noundef !39
  switch i64 %61, label %.preheader24 [
    i64 46, label %native_ref_test.exit2.loopexit
    i64 0, label %native_ref_test.exit2.loopexit
  ]

native_ref_test.exit2.loopexit:                   ; preds = %59, %59
  %.lcssa225 = phi i64 [ %61, %59 ], [ %61, %59 ]
  %62 = icmp eq i64 %.lcssa225, 46
  br i1 %62, label %ok34, label %trap30

native_ref_test.exit2:                            ; preds = %49, %49, %41, %41
  %63 = phi i1 [ %42, %41 ], [ %54, %49 ], [ %54, %49 ], [ %42, %41 ]
  br i1 %63, label %ok34, label %trap30

trap30:                                           ; preds = %native_ref_test.exit2, %native_ref_test.exit2.loopexit, %else24
  call fastcc void @native_trap()
  unreachable

ok34:                                             ; preds = %native_ref_test.exit2, %native_ref_test.exit2.loopexit
  %v36 = getelementptr i8, ptr %v16, i64 24
  %v37 = load i64, ptr %v36, align 1
  %v38.not = icmp eq i64 %v37, 0
  br i1 %v38.not, label %trap39, label %ok40

trap39:                                           ; preds = %ok34
  call fastcc void @native_trap()
  unreachable

ok40:                                             ; preds = %ok34
  %v41 = inttoptr i64 %v37 to ptr
  %v42 = getelementptr i8, ptr %v41, i64 8
  %v43 = load i32, ptr %v42, align 1
  %v44 = icmp eq i32 %v43, 0
  br i1 %v44, label %then48, label %block46

then48:                                           ; preds = %ok40
  call fastcc void @native_trap()
  unreachable

block46:                                          ; preds = %ok40
  switch i64 %38, label %64 [
    i64 46, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

64:                                               ; preds = %block46
  %65 = getelementptr inbounds nuw i8, ptr %37, i64 360
  %66 = load i64, ptr %65, align 8, !noundef !39
  %67 = lshr i64 %38, 2
  %68 = add nsw i64 %67, -1
  %69 = icmp ult i64 %68, %66
  br i1 %69, label %70, label %.loopexit23

70:                                               ; preds = %64
  %71 = getelementptr inbounds nuw i8, ptr %37, i64 352
  %72 = load ptr, ptr %71, align 8, !nonnull !39, !noundef !39
  %73 = getelementptr inbounds nuw i64, ptr %72, i64 %68
  %74 = load i64, ptr %73, align 8, !noundef !39
  %75 = icmp eq i64 %74, 46
  switch i64 %74, label %.preheader22 [
    i64 46, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

.preheader22:                                     ; preds = %80, %70
  %76 = phi i64 [ %82, %80 ], [ %74, %70 ]
  %77 = lshr i64 %76, 2
  %78 = add nsw i64 %77, -1
  %79 = icmp ult i64 %78, %66
  br i1 %79, label %80, label %.loopexit23

.loopexit23:                                      ; preds = %.preheader22, %64
  call fastcc void @native_trap() #114
  unreachable

80:                                               ; preds = %.preheader22
  %81 = getelementptr inbounds nuw i64, ptr %72, i64 %78
  %82 = load i64, ptr %81, align 8, !noundef !39
  switch i64 %82, label %.preheader22 [
    i64 46, label %native_ref_test.exit4.loopexit
    i64 0, label %native_ref_test.exit4.loopexit
  ]

native_ref_test.exit4.loopexit:                   ; preds = %80, %80
  %.lcssa = phi i64 [ %82, %80 ], [ %82, %80 ]
  %83 = icmp eq i64 %.lcssa, 46
  br i1 %83, label %ok54, label %trap53

native_ref_test.exit4:                            ; preds = %70, %70, %block46, %block46
  %84 = phi i1 [ %42, %block46 ], [ %75, %70 ], [ %75, %70 ], [ %42, %block46 ]
  br i1 %84, label %ok54, label %trap53

trap53:                                           ; preds = %native_ref_test.exit4, %native_ref_test.exit4.loopexit
  call fastcc void @native_trap()
  unreachable

ok54:                                             ; preds = %native_ref_test.exit4, %native_ref_test.exit4.loopexit
  store i64 %v50, ptr %v4, align 8
  %v60 = load i64, ptr %v36, align 1
  %v61.not = icmp eq i64 %v60, 0
  br i1 %v61.not, label %trap62, label %ok63

trap62:                                           ; preds = %ok54
  call fastcc void @native_trap()
  unreachable

ok63:                                             ; preds = %ok54
  %v64 = inttoptr i64 %v60 to ptr
  %v65 = getelementptr i8, ptr %v64, i64 16
  %v66 = load i64, ptr %v65, align 1
  %v67.not = icmp eq i64 %v66, 0
  br i1 %v67.not, label %trap68, label %ok69

trap68:                                           ; preds = %ok63
  call fastcc void @native_trap()
  unreachable

ok69:                                             ; preds = %ok63
  %v70 = inttoptr i64 %v66 to ptr
  %v71 = getelementptr i8, ptr %v70, i64 16
  %v72 = load i64, ptr %v71, align 1
  store i64 %v72, ptr %v1, align 8
  %85 = icmp ne i64 %v72, 0
  %86 = and i64 %v72, 1
  %.not.i5 = icmp eq i64 %86, 0
  %or.cond130 = and i1 %85, %.not.i5
  br i1 %or.cond130, label %87, label %trap75

87:                                               ; preds = %ok69
  %88 = inttoptr i64 %v72 to ptr
  %89 = load i64, ptr %88, align 8, !noundef !39
  %90 = icmp eq i64 %89, 50
  switch i64 %89, label %91 [
    i64 50, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

91:                                               ; preds = %87
  %92 = getelementptr inbounds nuw i8, ptr %37, i64 360
  %93 = load i64, ptr %92, align 8, !noundef !39
  %94 = lshr i64 %89, 2
  %95 = add nsw i64 %94, -1
  %96 = icmp ult i64 %95, %93
  br i1 %96, label %97, label %.loopexit21

97:                                               ; preds = %91
  %98 = getelementptr inbounds nuw i8, ptr %37, i64 352
  %99 = load ptr, ptr %98, align 8, !nonnull !39, !noundef !39
  %100 = getelementptr inbounds nuw i64, ptr %99, i64 %95
  %101 = load i64, ptr %100, align 8, !noundef !39
  %102 = icmp eq i64 %101, 50
  switch i64 %101, label %.preheader20 [
    i64 50, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

.preheader20:                                     ; preds = %107, %97
  %103 = phi i64 [ %109, %107 ], [ %101, %97 ]
  %104 = lshr i64 %103, 2
  %105 = add nsw i64 %104, -1
  %106 = icmp ult i64 %105, %93
  br i1 %106, label %107, label %.loopexit21

.loopexit21:                                      ; preds = %.preheader20, %91
  call fastcc void @native_trap() #114
  unreachable

107:                                              ; preds = %.preheader20
  %108 = getelementptr inbounds nuw i64, ptr %99, i64 %105
  %109 = load i64, ptr %108, align 8, !noundef !39
  switch i64 %109, label %.preheader20 [
    i64 50, label %native_ref_test.exit6.loopexit
    i64 0, label %native_ref_test.exit6.loopexit
  ]

native_ref_test.exit6.loopexit:                   ; preds = %107, %107
  %.lcssa226 = phi i64 [ %109, %107 ], [ %109, %107 ]
  %110 = icmp eq i64 %.lcssa226, 50
  br i1 %110, label %ok76, label %trap75

native_ref_test.exit6:                            ; preds = %97, %97, %87, %87
  %111 = phi i1 [ %90, %87 ], [ %102, %97 ], [ %102, %97 ], [ %90, %87 ]
  br i1 %111, label %ok76, label %trap75

trap75:                                           ; preds = %native_ref_test.exit6, %native_ref_test.exit6.loopexit, %ok69
  call fastcc void @native_trap()
  unreachable

ok76:                                             ; preds = %native_ref_test.exit6, %native_ref_test.exit6.loopexit
  switch i64 %89, label %112 [
    i64 50, label %native_ref_test.exit8
    i64 0, label %native_ref_test.exit8
  ]

112:                                              ; preds = %ok76
  %113 = getelementptr inbounds nuw i8, ptr %37, i64 360
  %114 = load i64, ptr %113, align 8, !noundef !39
  %115 = lshr i64 %89, 2
  %116 = add nsw i64 %115, -1
  %117 = icmp ult i64 %116, %114
  br i1 %117, label %118, label %.loopexit19

118:                                              ; preds = %112
  %119 = getelementptr inbounds nuw i8, ptr %37, i64 352
  %120 = load ptr, ptr %119, align 8, !nonnull !39, !noundef !39
  %121 = getelementptr inbounds nuw i64, ptr %120, i64 %116
  %122 = load i64, ptr %121, align 8, !noundef !39
  %123 = icmp eq i64 %122, 50
  switch i64 %122, label %.preheader18 [
    i64 50, label %native_ref_test.exit8
    i64 0, label %native_ref_test.exit8
  ]

.preheader18:                                     ; preds = %128, %118
  %124 = phi i64 [ %130, %128 ], [ %122, %118 ]
  %125 = lshr i64 %124, 2
  %126 = add nsw i64 %125, -1
  %127 = icmp ult i64 %126, %114
  br i1 %127, label %128, label %.loopexit19

.loopexit19:                                      ; preds = %.preheader18, %112
  call fastcc void @native_trap() #114
  unreachable

128:                                              ; preds = %.preheader18
  %129 = getelementptr inbounds nuw i64, ptr %120, i64 %126
  %130 = load i64, ptr %129, align 8, !noundef !39
  switch i64 %130, label %.preheader18 [
    i64 50, label %native_ref_test.exit8.loopexit
    i64 0, label %native_ref_test.exit8.loopexit
  ]

native_ref_test.exit8.loopexit:                   ; preds = %128, %128
  %.lcssa227 = phi i64 [ %130, %128 ], [ %130, %128 ]
  %131 = icmp eq i64 %.lcssa227, 50
  br i1 %131, label %ok81, label %trap80

native_ref_test.exit8:                            ; preds = %118, %118, %ok76, %ok76
  %132 = phi i1 [ %90, %ok76 ], [ %123, %118 ], [ %123, %118 ], [ %90, %ok76 ]
  br i1 %132, label %ok81, label %trap80

trap80:                                           ; preds = %native_ref_test.exit8, %native_ref_test.exit8.loopexit
  call fastcc void @native_trap()
  unreachable

ok81:                                             ; preds = %native_ref_test.exit8, %native_ref_test.exit8.loopexit
  store i64 %v72, ptr %v3, align 8
  %v86 = getelementptr i8, ptr %88, i64 32
  %v87 = load i64, ptr %v86, align 1
  %v88.not = icmp eq i64 %v87, 0
  br i1 %v88.not, label %trap89, label %ok90

trap89:                                           ; preds = %ok81
  call fastcc void @native_trap()
  unreachable

ok90:                                             ; preds = %ok81
  %v91 = inttoptr i64 %v87 to ptr
  %v92 = getelementptr i8, ptr %v91, i64 16
  %v93 = load i64, ptr %v92, align 1
  %v94.not = icmp eq i64 %v93, 0
  br i1 %v94.not, label %trap95, label %ok96

trap95:                                           ; preds = %ok90
  call fastcc void @native_trap()
  unreachable

ok96:                                             ; preds = %ok90
  %v97 = inttoptr i64 %v93 to ptr
  %v98 = getelementptr i8, ptr %v97, i64 8
  %v99 = load i64, ptr %v98, align 1
  store i64 %v99, ptr %v101, align 8
  store i64 4, ptr %1, align 8
  %v103 = call tailcc i64 @f.17(i64 %v99, i64 %arg1.tr50)
  %v104 = load i64, ptr %v3, align 8
  %v105.not = icmp eq i64 %v104, 0
  br i1 %v105.not, label %trap106, label %ok107

trap106:                                          ; preds = %ok96
  call fastcc void @native_trap()
  unreachable

ok107:                                            ; preds = %ok96
  %v108 = inttoptr i64 %v104 to ptr
  %v109 = getelementptr i8, ptr %v108, i64 8
  %v110 = load i64, ptr %v109, align 1
  %v116 = getelementptr i8, ptr %v108, i64 16
  %v117 = load i64, ptr %v116, align 1
  %v123 = getelementptr i8, ptr %v108, i64 24
  %v124 = load i64, ptr %v123, align 1
  store i64 %v124, ptr %v101, align 8
  store i64 %v117, ptr %v127, align 8
  store i64 %v110, ptr %v128, align 8
  store i64 6, ptr %1, align 8
  %133 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %134 = icmp eq ptr %133, null
  br i1 %134, label %135, label %136

135:                                              ; preds = %ok107
  call fastcc void @native_trap() #114
  unreachable

136:                                              ; preds = %ok107
  %137 = getelementptr inbounds nuw i8, ptr %133, i64 376
  %138 = load i64, ptr %137, align 8, !noundef !39
  %139 = icmp eq i64 %138, 0
  br i1 %139, label %140, label %144

140:                                              ; preds = %150, %144, %136
  %141 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %142 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %133, i64 noundef 40, ptr noundef %141) #84
  %143 = icmp eq ptr %142, null
  br i1 %143, label %152, label %ok133

144:                                              ; preds = %136
  %145 = getelementptr inbounds nuw i8, ptr %133, i64 368
  %146 = load i64, ptr %145, align 8, !noundef !39
  %147 = add i64 %146, 1
  store i64 %147, ptr %145, align 8
  %148 = urem i64 %147, %138
  %149 = icmp eq i64 %148, 0
  br i1 %149, label %150, label %140

150:                                              ; preds = %144
  %151 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %133, ptr noundef %151) #84
  br label %140

152:                                              ; preds = %140
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok133:                                            ; preds = %140
  %153 = ptrtoint ptr %142 to i64
  store i64 34, ptr %142, align 1
  %v140 = getelementptr i8, ptr %142, i64 8
  store i64 %v110, ptr %v140, align 1
  %v145 = getelementptr i8, ptr %142, i64 16
  store i64 %v117, ptr %v145, align 1
  %v150 = getelementptr i8, ptr %142, i64 24
  store i64 %v124, ptr %v150, align 1
  %v155 = getelementptr i8, ptr %142, i64 32
  store i64 %arg1.tr50, ptr %v155, align 1
  store i64 %153, ptr %v101, align 8
  store i64 4, ptr %1, align 8
  %v159 = call tailcc i32 @f.14(i64 %153, i64 %v103)
  %v160 = load i64, ptr %v4, align 8
  %v161.not = icmp eq i64 %v160, 0
  br i1 %v161.not, label %trap162, label %ok163

trap162:                                          ; preds = %ok133
  call fastcc void @native_trap()
  unreachable

ok163:                                            ; preds = %ok133
  %v164 = inttoptr i64 %v160 to ptr
  %v165 = getelementptr i8, ptr %v164, i64 16
  %v166 = load i64, ptr %v165, align 1
  %v167.not = icmp eq i64 %v166, 0
  br i1 %v167.not, label %trap168, label %ok169

trap168:                                          ; preds = %ok163
  call fastcc void @native_trap()
  unreachable

ok169:                                            ; preds = %ok163
  %v170 = inttoptr i64 %v166 to ptr
  %v171 = getelementptr i8, ptr %v170, i64 8
  %v172 = load i32, ptr %v171, align 1
  %v173 = icmp eq i32 %v172, 0
  br i1 %v173, label %then177, label %ok188

then177:                                          ; preds = %ok169
  call fastcc void @native_trap()
  unreachable

ok188:                                            ; preds = %ok169
  %v190 = getelementptr i8, ptr %v170, i64 16
  %v191 = load i64, ptr %v190, align 1
  %v192.not = icmp eq i64 %v191, 0
  br i1 %v192.not, label %trap193, label %ok194

trap193:                                          ; preds = %ok188
  call fastcc void @native_trap()
  unreachable

ok194:                                            ; preds = %ok188
  %v195 = inttoptr i64 %v191 to ptr
  %v196 = getelementptr i8, ptr %v195, i64 16
  %v197 = load i64, ptr %v196, align 1
  %v199 = add i64 %arg1.tr50, 2
  %154 = load i64, ptr %0, align 8, !noundef !39
  %155 = icmp eq i64 %154, 0
  %.pre38 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %156 = zext i1 %155 to i64
  %157 = add i64 %.pre38, %156
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %158 = select i1 %155, ptr %native_roots.0.val, ptr %roots.val
  store i64 6, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %158, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %157, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %159 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %160 = call noundef i64 @llvm.umax.i64(i64 %157, i64 %159)
  store i64 %160, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v197, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %161 = icmp ne i64 %v197, 0
  %162 = and i64 %v197, 1
  %.not.i10 = icmp eq i64 %162, 0
  %or.cond131 = and i1 %161, %.not.i10
  br i1 %or.cond131, label %163, label %trap11

163:                                              ; preds = %ok194
  %164 = inttoptr i64 %v197 to ptr
  %165 = load i64, ptr %164, align 8, !noundef !39
  %166 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %167 = icmp eq ptr %166, null
  br i1 %167, label %180, label %168

168:                                              ; preds = %163
  switch i64 %165, label %169 [
    i64 46, label %native_ref_test.exit11
    i64 0, label %native_ref_test.exit11
  ]

169:                                              ; preds = %168
  %170 = getelementptr inbounds nuw i8, ptr %166, i64 360
  %171 = load i64, ptr %170, align 8, !noundef !39
  %172 = lshr i64 %165, 2
  %173 = add nsw i64 %172, -1
  %174 = icmp ult i64 %173, %171
  br i1 %174, label %175, label %.loopexit

175:                                              ; preds = %169
  %176 = getelementptr inbounds nuw i8, ptr %166, i64 352
  %177 = load ptr, ptr %176, align 8, !nonnull !39, !noundef !39
  %178 = getelementptr inbounds nuw i64, ptr %177, i64 %173
  %179 = load i64, ptr %178, align 8, !noundef !39
  switch i64 %179, label %.preheader [
    i64 46, label %native_ref_test.exit11
    i64 0, label %native_ref_test.exit11
  ]

180:                                              ; preds = %163
  call fastcc void @native_trap() #114
  unreachable

.preheader:                                       ; preds = %185, %175
  %181 = phi i64 [ %187, %185 ], [ %179, %175 ]
  %182 = lshr i64 %181, 2
  %183 = add nsw i64 %182, -1
  %184 = icmp ult i64 %183, %171
  br i1 %184, label %185, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %169
  call fastcc void @native_trap() #114
  unreachable

185:                                              ; preds = %.preheader
  %186 = getelementptr inbounds nuw i64, ptr %177, i64 %183
  %187 = load i64, ptr %186, align 8, !noundef !39
  switch i64 %187, label %.preheader [
    i64 46, label %native_ref_test.exit11
    i64 0, label %native_ref_test.exit11
  ]

native_ref_test.exit11:                           ; preds = %185, %185, %175, %175, %168, %168
  %.in = phi i64 [ %165, %168 ], [ %179, %175 ], [ %179, %175 ], [ %165, %168 ], [ %187, %185 ], [ %187, %185 ]
  %188 = icmp eq i64 %.in, 46
  br i1 %188, label %ok15, label %trap11
}
