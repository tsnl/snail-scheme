define internal tailcc void @f.19(i64 range(i64 1, 0) %arg0, i64 range(i64 0, 9223372036854775807) %arg1) unnamed_addr #105 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [7 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 7, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v5, align 8
  %v9.b105 = load i1, ptr @g.5, align 1
  br i1 %v9.b105, label %block12.lr.ph, label %then14

block12.lr.ph:                                    ; preds = %entry
  %v55 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v56 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v72 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %7 = inttoptr i64 %arg0 to ptr
  br label %block12

then14:                                           ; preds = %ok452, %entry
  call fastcc void @native_trap()
  unreachable

block12:                                          ; preds = %ok452, %block12.lr.ph
  %arg1.tr107 = phi i64 [ %arg1, %block12.lr.ph ], [ %v471, %ok452 ]
  %arg0.tr106 = phi ptr [ %7, %block12.lr.ph ], [ %365, %ok452 ]
  %v16 = load i64, ptr @g.4, align 8
  %v17.not = icmp eq i64 %v16, 0
  br i1 %v17.not, label %trap18, label %ok19

trap18:                                           ; preds = %block12
  call fastcc void @native_trap()
  unreachable

ok19:                                             ; preds = %block12
  %v20.b = load i1, ptr @g.11, align 1
  br i1 %v20.b, label %block23, label %then25

then25:                                           ; preds = %ok19
  call fastcc void @native_trap()
  unreachable

block23:                                          ; preds = %ok19
  %v27 = load i64, ptr @g.10, align 8
  %v28.not = icmp eq i64 %v27, 0
  br i1 %v28.not, label %trap29, label %ok34

trap29:                                           ; preds = %block23
  call fastcc void @native_trap()
  unreachable

ok34:                                             ; preds = %block23
  %v36 = getelementptr i8, ptr %arg0.tr106, i64 24
  %v37 = load i64, ptr %v36, align 1
  store i64 %v37, ptr %v3, align 8
  %8 = icmp ne i64 %v37, 0
  %9 = and i64 %v37, 1
  %.not.i = icmp eq i64 %9, 0
  %or.cond = and i1 %8, %.not.i
  br i1 %or.cond, label %10, label %trap46

10:                                               ; preds = %ok34
  %11 = inttoptr i64 %v37 to ptr
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %14 = icmp eq ptr %13, null
  br i1 %14, label %27, label %15

15:                                               ; preds = %10
  switch i64 %12, label %16 [
    i64 190, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

16:                                               ; preds = %15
  %17 = getelementptr inbounds nuw i8, ptr %13, i64 360
  %18 = load i64, ptr %17, align 8, !noundef !39
  %19 = lshr i64 %12, 2
  %20 = add nsw i64 %19, -1
  %21 = icmp ult i64 %20, %18
  br i1 %21, label %22, label %.loopexit60

22:                                               ; preds = %16
  %23 = getelementptr inbounds nuw i8, ptr %13, i64 352
  %24 = load ptr, ptr %23, align 8, !nonnull !39, !noundef !39
  %25 = getelementptr inbounds nuw i64, ptr %24, i64 %20
  %26 = load i64, ptr %25, align 8, !noundef !39
  switch i64 %26, label %.preheader59 [
    i64 190, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

27:                                               ; preds = %10
  call fastcc void @native_trap() #114
  unreachable

.preheader59:                                     ; preds = %32, %22
  %28 = phi i64 [ %34, %32 ], [ %26, %22 ]
  %29 = lshr i64 %28, 2
  %30 = add nsw i64 %29, -1
  %31 = icmp ult i64 %30, %18
  br i1 %31, label %32, label %.loopexit60

.loopexit60:                                      ; preds = %.preheader59, %16
  call fastcc void @native_trap() #114
  unreachable

32:                                               ; preds = %.preheader59
  %33 = getelementptr inbounds nuw i64, ptr %24, i64 %30
  %34 = load i64, ptr %33, align 8, !noundef !39
  switch i64 %34, label %.preheader59 [
    i64 190, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %32, %32, %22, %22, %15, %15
  %.in136 = phi i64 [ %12, %15 ], [ %26, %22 ], [ %26, %22 ], [ %12, %15 ], [ %34, %32 ], [ %34, %32 ]
  %35 = icmp eq i64 %.in136, 190
  br i1 %35, label %then41, label %block39.thread32

then41:                                           ; preds = %native_ref_test.exit
  call fastcc void @native_trap()
  unreachable

block39.thread32:                                 ; preds = %native_ref_test.exit
  %36 = inttoptr i64 %v37 to ptr
  %37 = load i64, ptr %36, align 8, !noundef !39
  %38 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %39 = icmp eq ptr %38, null
  br i1 %39, label %52, label %40

40:                                               ; preds = %block39.thread32
  switch i64 %37, label %41 [
    i64 82, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

41:                                               ; preds = %40
  %42 = getelementptr inbounds nuw i8, ptr %38, i64 360
  %43 = load i64, ptr %42, align 8, !noundef !39
  %44 = lshr i64 %37, 2
  %45 = add nsw i64 %44, -1
  %46 = icmp ult i64 %45, %43
  br i1 %46, label %47, label %.loopexit58

47:                                               ; preds = %41
  %48 = getelementptr inbounds nuw i8, ptr %38, i64 352
  %49 = load ptr, ptr %48, align 8, !nonnull !39, !noundef !39
  %50 = getelementptr inbounds nuw i64, ptr %49, i64 %45
  %51 = load i64, ptr %50, align 8, !noundef !39
  switch i64 %51, label %.preheader57 [
    i64 82, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

52:                                               ; preds = %block39.thread32
  call fastcc void @native_trap() #114
  unreachable

.preheader57:                                     ; preds = %57, %47
  %53 = phi i64 [ %59, %57 ], [ %51, %47 ]
  %54 = lshr i64 %53, 2
  %55 = add nsw i64 %54, -1
  %56 = icmp ult i64 %55, %43
  br i1 %56, label %57, label %.loopexit58

.loopexit58:                                      ; preds = %.preheader57, %41
  call fastcc void @native_trap() #114
  unreachable

57:                                               ; preds = %.preheader57
  %58 = getelementptr inbounds nuw i64, ptr %49, i64 %55
  %59 = load i64, ptr %58, align 8, !noundef !39
  switch i64 %59, label %.preheader57 [
    i64 82, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

native_ref_test.exit2:                            ; preds = %57, %57, %47, %47, %40, %40
  %.in137 = phi i64 [ %37, %40 ], [ %51, %47 ], [ %51, %47 ], [ %37, %40 ], [ %59, %57 ], [ %59, %57 ]
  %60 = icmp eq i64 %.in137, 82
  br i1 %60, label %ok50, label %trap46

trap46:                                           ; preds = %native_ref_test.exit2, %ok34
  call fastcc void @native_trap()
  unreachable

ok50:                                             ; preds = %native_ref_test.exit2
  %v52 = getelementptr i8, ptr %36, i64 8
  %v53 = load i64, ptr %v52, align 1
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v55, align 8
  store i64 %v53, ptr %v56, align 8
  store i64 6, ptr %1, align 8
  %61 = getelementptr inbounds nuw i8, ptr %38, i64 376
  %62 = load i64, ptr %61, align 8, !noundef !39
  %63 = icmp eq i64 %62, 0
  br i1 %63, label %64, label %68

64:                                               ; preds = %74, %68, %ok50
  %65 = phi ptr [ %.pre, %74 ], [ %roots, %68 ], [ %roots, %ok50 ]
  %66 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %38, i64 noundef 16, ptr noundef %65) #84
  %67 = icmp eq ptr %66, null
  br i1 %67, label %75, label %ok61

68:                                               ; preds = %ok50
  %69 = getelementptr inbounds nuw i8, ptr %38, i64 368
  %70 = load i64, ptr %69, align 8, !noundef !39
  %71 = add i64 %70, 1
  store i64 %71, ptr %69, align 8
  %72 = urem i64 %71, %62
  %73 = icmp eq i64 %72, 0
  br i1 %73, label %74, label %64

74:                                               ; preds = %68
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %38, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %64

75:                                               ; preds = %64
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok61:                                             ; preds = %64
  %76 = ptrtoint ptr %66 to i64
  store i64 62, ptr %66, align 1
  %v68 = getelementptr i8, ptr %66, i64 8
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v68, align 1
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v55, align 8
  store i64 %76, ptr %v56, align 8
  store i64 %v53, ptr %v72, align 8
  store i64 7, ptr %1, align 8
  %77 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %78 = icmp eq ptr %77, null
  br i1 %78, label %79, label %80

79:                                               ; preds = %ok61
  call fastcc void @native_trap() #114
  unreachable

80:                                               ; preds = %ok61
  %81 = getelementptr inbounds nuw i8, ptr %77, i64 376
  %82 = load i64, ptr %81, align 8, !noundef !39
  %83 = icmp eq i64 %82, 0
  br i1 %83, label %84, label %88

84:                                               ; preds = %94, %88, %80
  %85 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %86 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %77, i64 noundef 16, ptr noundef %85) #84
  %87 = icmp eq ptr %86, null
  br i1 %87, label %96, label %ok77

88:                                               ; preds = %80
  %89 = getelementptr inbounds nuw i8, ptr %77, i64 368
  %90 = load i64, ptr %89, align 8, !noundef !39
  %91 = add i64 %90, 1
  store i64 %91, ptr %89, align 8
  %92 = urem i64 %91, %82
  %93 = icmp eq i64 %92, 0
  br i1 %93, label %94, label %84

94:                                               ; preds = %88
  %95 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %77, ptr noundef %95) #84
  br label %84

96:                                               ; preds = %84
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok77:                                             ; preds = %84
  %97 = ptrtoint ptr %86 to i64
  store i64 62, ptr %86, align 1
  %v84 = getelementptr i8, ptr %86, i64 8
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v84, align 1
  store i64 %97, ptr %v55, align 8
  store i64 %76, ptr %v56, align 8
  store i64 %v53, ptr %v72, align 8
  store i64 7, ptr %1, align 8
  %98 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %99 = icmp eq ptr %98, null
  br i1 %99, label %100, label %101

100:                                              ; preds = %ok77
  call fastcc void @native_trap() #114
  unreachable

101:                                              ; preds = %ok77
  %102 = getelementptr inbounds nuw i8, ptr %98, i64 376
  %103 = load i64, ptr %102, align 8, !noundef !39
  %104 = icmp eq i64 %103, 0
  br i1 %104, label %105, label %109

105:                                              ; preds = %115, %109, %101
  %106 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %107 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %98, i64 noundef 24, ptr noundef %106) #84
  %108 = icmp eq ptr %107, null
  br i1 %108, label %117, label %ok92

109:                                              ; preds = %101
  %110 = getelementptr inbounds nuw i8, ptr %98, i64 368
  %111 = load i64, ptr %110, align 8, !noundef !39
  %112 = add i64 %111, 1
  store i64 %112, ptr %110, align 8
  %113 = urem i64 %112, %103
  %114 = icmp eq i64 %113, 0
  br i1 %114, label %115, label %105

115:                                              ; preds = %109
  %116 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %98, ptr noundef %116) #84
  br label %105

117:                                              ; preds = %105
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok92:                                             ; preds = %105
  store i64 82, ptr %107, align 1
  %v99 = getelementptr i8, ptr %107, i64 8
  store i64 %76, ptr %v99, align 1
  %v104 = getelementptr i8, ptr %107, i64 16
  store i64 %97, ptr %v104, align 1
  %v105.not = icmp eq i64 %v53, 0
  br i1 %v105.not, label %trap106, label %ok107

trap106:                                          ; preds = %ok92
  call fastcc void @native_trap()
  unreachable

ok107:                                            ; preds = %ok92
  %118 = ptrtoint ptr %107 to i64
  %v108 = inttoptr i64 %v53 to ptr
  %v109 = getelementptr i8, ptr %v108, i64 8
  store i64 %118, ptr %v109, align 1
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v5, align 8
  %v111.b = load i1, ptr @g.5, align 1
  br i1 %v111.b, label %block114, label %then116

then116:                                          ; preds = %ok107
  call fastcc void @native_trap()
  unreachable

block114:                                         ; preds = %ok107
  %v118 = load i64, ptr @g.4, align 8
  %v119.not = icmp eq i64 %v118, 0
  br i1 %v119.not, label %trap120, label %ok121

trap120:                                          ; preds = %block114
  call fastcc void @native_trap()
  unreachable

ok121:                                            ; preds = %block114
  %v122.b = load i1, ptr @g.13, align 1
  br i1 %v122.b, label %block125, label %then127

then127:                                          ; preds = %ok121
  call fastcc void @native_trap()
  unreachable

block125:                                         ; preds = %ok121
  %v129 = load i64, ptr @g.12, align 8
  %v130.not = icmp eq i64 %v129, 0
  br i1 %v130.not, label %trap131, label %ok132

trap131:                                          ; preds = %block125
  call fastcc void @native_trap()
  unreachable

ok132:                                            ; preds = %block125
  %v133 = load i64, ptr %v1, align 8
  %v134.not = icmp eq i64 %v133, 0
  br i1 %v134.not, label %trap135, label %ok136

trap135:                                          ; preds = %ok132
  call fastcc void @native_trap()
  unreachable

ok136:                                            ; preds = %ok132
  %v137 = inttoptr i64 %v133 to ptr
  %v138 = getelementptr i8, ptr %v137, i64 24
  %v139 = load i64, ptr %v138, align 1
  store i64 %v139, ptr %v3, align 8
  %119 = icmp ne i64 %v139, 0
  %120 = and i64 %v139, 1
  %.not.i5 = icmp eq i64 %120, 0
  %or.cond159 = and i1 %119, %.not.i5
  br i1 %or.cond159, label %121, label %trap148

121:                                              ; preds = %ok136
  %122 = inttoptr i64 %v139 to ptr
  %123 = load i64, ptr %122, align 8, !noundef !39
  %124 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %125 = icmp eq ptr %124, null
  br i1 %125, label %138, label %126

126:                                              ; preds = %121
  switch i64 %123, label %127 [
    i64 190, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

127:                                              ; preds = %126
  %128 = getelementptr inbounds nuw i8, ptr %124, i64 360
  %129 = load i64, ptr %128, align 8, !noundef !39
  %130 = lshr i64 %123, 2
  %131 = add nsw i64 %130, -1
  %132 = icmp ult i64 %131, %129
  br i1 %132, label %133, label %.loopexit56

133:                                              ; preds = %127
  %134 = getelementptr inbounds nuw i8, ptr %124, i64 352
  %135 = load ptr, ptr %134, align 8, !nonnull !39, !noundef !39
  %136 = getelementptr inbounds nuw i64, ptr %135, i64 %131
  %137 = load i64, ptr %136, align 8, !noundef !39
  switch i64 %137, label %.preheader55 [
    i64 190, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

138:                                              ; preds = %121
  call fastcc void @native_trap() #114
  unreachable

.preheader55:                                     ; preds = %143, %133
  %139 = phi i64 [ %145, %143 ], [ %137, %133 ]
  %140 = lshr i64 %139, 2
  %141 = add nsw i64 %140, -1
  %142 = icmp ult i64 %141, %129
  br i1 %142, label %143, label %.loopexit56

.loopexit56:                                      ; preds = %.preheader55, %127
  call fastcc void @native_trap() #114
  unreachable

143:                                              ; preds = %.preheader55
  %144 = getelementptr inbounds nuw i64, ptr %135, i64 %141
  %145 = load i64, ptr %144, align 8, !noundef !39
  switch i64 %145, label %.preheader55 [
    i64 190, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

native_ref_test.exit6:                            ; preds = %143, %143, %133, %133, %126, %126
  %.in138 = phi i64 [ %123, %126 ], [ %137, %133 ], [ %137, %133 ], [ %123, %126 ], [ %145, %143 ], [ %145, %143 ]
  %146 = icmp eq i64 %.in138, 190
  br i1 %146, label %then143, label %block141.thread36

then143:                                          ; preds = %native_ref_test.exit6
  call fastcc void @native_trap()
  unreachable

block141.thread36:                                ; preds = %native_ref_test.exit6
  %147 = inttoptr i64 %v139 to ptr
  %148 = load i64, ptr %147, align 8, !noundef !39
  %149 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %150 = icmp eq ptr %149, null
  br i1 %150, label %163, label %151

151:                                              ; preds = %block141.thread36
  switch i64 %148, label %152 [
    i64 82, label %native_ref_test.exit8
    i64 0, label %native_ref_test.exit8
  ]

152:                                              ; preds = %151
  %153 = getelementptr inbounds nuw i8, ptr %149, i64 360
  %154 = load i64, ptr %153, align 8, !noundef !39
  %155 = lshr i64 %148, 2
  %156 = add nsw i64 %155, -1
  %157 = icmp ult i64 %156, %154
  br i1 %157, label %158, label %.loopexit54

158:                                              ; preds = %152
  %159 = getelementptr inbounds nuw i8, ptr %149, i64 352
  %160 = load ptr, ptr %159, align 8, !nonnull !39, !noundef !39
  %161 = getelementptr inbounds nuw i64, ptr %160, i64 %156
  %162 = load i64, ptr %161, align 8, !noundef !39
  switch i64 %162, label %.preheader53 [
    i64 82, label %native_ref_test.exit8
    i64 0, label %native_ref_test.exit8
  ]

163:                                              ; preds = %block141.thread36
  call fastcc void @native_trap() #114
  unreachable

.preheader53:                                     ; preds = %168, %158
  %164 = phi i64 [ %170, %168 ], [ %162, %158 ]
  %165 = lshr i64 %164, 2
  %166 = add nsw i64 %165, -1
  %167 = icmp ult i64 %166, %154
  br i1 %167, label %168, label %.loopexit54

.loopexit54:                                      ; preds = %.preheader53, %152
  call fastcc void @native_trap() #114
  unreachable

168:                                              ; preds = %.preheader53
  %169 = getelementptr inbounds nuw i64, ptr %160, i64 %166
  %170 = load i64, ptr %169, align 8, !noundef !39
  switch i64 %170, label %.preheader53 [
    i64 82, label %native_ref_test.exit8
    i64 0, label %native_ref_test.exit8
  ]

native_ref_test.exit8:                            ; preds = %168, %168, %158, %158, %151, %151
  %.in139 = phi i64 [ %148, %151 ], [ %162, %158 ], [ %162, %158 ], [ %148, %151 ], [ %170, %168 ], [ %170, %168 ]
  %171 = icmp eq i64 %.in139, 82
  br i1 %171, label %ok152, label %trap148

trap148:                                          ; preds = %native_ref_test.exit8, %ok136
  call fastcc void @native_trap()
  unreachable

ok152:                                            ; preds = %native_ref_test.exit8
  %v154 = getelementptr i8, ptr %147, i64 16
  %v155 = load i64, ptr %v154, align 1
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v55, align 8
  store i64 %v155, ptr %v56, align 8
  store i64 6, ptr %1, align 8
  %172 = getelementptr inbounds nuw i8, ptr %149, i64 376
  %173 = load i64, ptr %172, align 8, !noundef !39
  %174 = icmp eq i64 %173, 0
  br i1 %174, label %175, label %179

175:                                              ; preds = %185, %179, %ok152
  %176 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %177 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %149, i64 noundef 16, ptr noundef %176) #84
  %178 = icmp eq ptr %177, null
  br i1 %178, label %187, label %ok163

179:                                              ; preds = %ok152
  %180 = getelementptr inbounds nuw i8, ptr %149, i64 368
  %181 = load i64, ptr %180, align 8, !noundef !39
  %182 = add i64 %181, 1
  store i64 %182, ptr %180, align 8
  %183 = urem i64 %182, %173
  %184 = icmp eq i64 %183, 0
  br i1 %184, label %185, label %175

185:                                              ; preds = %179
  %186 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %149, ptr noundef %186) #84
  br label %175

187:                                              ; preds = %175
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok163:                                            ; preds = %175
  %188 = ptrtoint ptr %177 to i64
  store i64 62, ptr %177, align 1
  %v170 = getelementptr i8, ptr %177, i64 8
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v170, align 1
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v55, align 8
  store i64 %188, ptr %v56, align 8
  store i64 %v155, ptr %v72, align 8
  store i64 7, ptr %1, align 8
  %189 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %190 = icmp eq ptr %189, null
  br i1 %190, label %191, label %192

191:                                              ; preds = %ok163
  call fastcc void @native_trap() #114
  unreachable

192:                                              ; preds = %ok163
  %193 = getelementptr inbounds nuw i8, ptr %189, i64 376
  %194 = load i64, ptr %193, align 8, !noundef !39
  %195 = icmp eq i64 %194, 0
  br i1 %195, label %196, label %200

196:                                              ; preds = %206, %200, %192
  %197 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %198 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %189, i64 noundef 16, ptr noundef %197) #84
  %199 = icmp eq ptr %198, null
  br i1 %199, label %208, label %ok179

200:                                              ; preds = %192
  %201 = getelementptr inbounds nuw i8, ptr %189, i64 368
  %202 = load i64, ptr %201, align 8, !noundef !39
  %203 = add i64 %202, 1
  store i64 %203, ptr %201, align 8
  %204 = urem i64 %203, %194
  %205 = icmp eq i64 %204, 0
  br i1 %205, label %206, label %196

206:                                              ; preds = %200
  %207 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %189, ptr noundef %207) #84
  br label %196

208:                                              ; preds = %196
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok179:                                            ; preds = %196
  %209 = ptrtoint ptr %198 to i64
  store i64 62, ptr %198, align 1
  %v186 = getelementptr i8, ptr %198, i64 8
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v186, align 1
  store i64 %209, ptr %v55, align 8
  store i64 %188, ptr %v56, align 8
  store i64 %v155, ptr %v72, align 8
  store i64 7, ptr %1, align 8
  %210 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %211 = icmp eq ptr %210, null
  br i1 %211, label %212, label %213

212:                                              ; preds = %ok179
  call fastcc void @native_trap() #114
  unreachable

213:                                              ; preds = %ok179
  %214 = getelementptr inbounds nuw i8, ptr %210, i64 376
  %215 = load i64, ptr %214, align 8, !noundef !39
  %216 = icmp eq i64 %215, 0
  br i1 %216, label %217, label %221

217:                                              ; preds = %227, %221, %213
  %218 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %219 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %210, i64 noundef 24, ptr noundef %218) #84
  %220 = icmp eq ptr %219, null
  br i1 %220, label %229, label %ok194

221:                                              ; preds = %213
  %222 = getelementptr inbounds nuw i8, ptr %210, i64 368
  %223 = load i64, ptr %222, align 8, !noundef !39
  %224 = add i64 %223, 1
  store i64 %224, ptr %222, align 8
  %225 = urem i64 %224, %215
  %226 = icmp eq i64 %225, 0
  br i1 %226, label %227, label %217

227:                                              ; preds = %221
  %228 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %210, ptr noundef %228) #84
  br label %217

229:                                              ; preds = %217
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok194:                                            ; preds = %217
  store i64 82, ptr %219, align 1
  %v201 = getelementptr i8, ptr %219, i64 8
  store i64 %188, ptr %v201, align 1
  %v206 = getelementptr i8, ptr %219, i64 16
  store i64 %209, ptr %v206, align 1
  %v207.not = icmp eq i64 %v155, 0
  br i1 %v207.not, label %trap208, label %ok209

trap208:                                          ; preds = %ok194
  call fastcc void @native_trap()
  unreachable

ok209:                                            ; preds = %ok194
  %230 = ptrtoint ptr %219 to i64
  %v210 = inttoptr i64 %v155 to ptr
  %v211 = getelementptr i8, ptr %v210, i64 8
  store i64 %230, ptr %v211, align 1
  %v212.b = load i1, ptr @g.7, align 1
  br i1 %v212.b, label %block215, label %then217

then217:                                          ; preds = %ok209
  call fastcc void @native_trap()
  unreachable

block215:                                         ; preds = %ok209
  %v219 = load i64, ptr @g.6, align 8
  %v220.not = icmp eq i64 %v219, 0
  br i1 %v220.not, label %trap221, label %ok222

trap221:                                          ; preds = %block215
  call fastcc void @native_trap()
  unreachable

ok222:                                            ; preds = %block215
  %v223 = load i64, ptr %v1, align 8
  %v224.not = icmp eq i64 %v223, 0
  br i1 %v224.not, label %trap225, label %ok226

trap225:                                          ; preds = %ok222
  call fastcc void @native_trap()
  unreachable

ok226:                                            ; preds = %ok222
  %v227 = inttoptr i64 %v223 to ptr
  %v228 = getelementptr i8, ptr %v227, i64 24
  %v229 = load i64, ptr %v228, align 1
  store i64 %v229, ptr %v3, align 8
  %231 = icmp ne i64 %v229, 0
  %232 = and i64 %v229, 1
  %.not.i12 = icmp eq i64 %232, 0
  %or.cond160 = and i1 %231, %.not.i12
  br i1 %or.cond160, label %233, label %trap238

233:                                              ; preds = %ok226
  %234 = inttoptr i64 %v229 to ptr
  %235 = load i64, ptr %234, align 8, !noundef !39
  %236 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %237 = icmp eq ptr %236, null
  br i1 %237, label %250, label %238

238:                                              ; preds = %233
  switch i64 %235, label %239 [
    i64 190, label %native_ref_test.exit13
    i64 0, label %native_ref_test.exit13
  ]

239:                                              ; preds = %238
  %240 = getelementptr inbounds nuw i8, ptr %236, i64 360
  %241 = load i64, ptr %240, align 8, !noundef !39
  %242 = lshr i64 %235, 2
  %243 = add nsw i64 %242, -1
  %244 = icmp ult i64 %243, %241
  br i1 %244, label %245, label %.loopexit52

245:                                              ; preds = %239
  %246 = getelementptr inbounds nuw i8, ptr %236, i64 352
  %247 = load ptr, ptr %246, align 8, !nonnull !39, !noundef !39
  %248 = getelementptr inbounds nuw i64, ptr %247, i64 %243
  %249 = load i64, ptr %248, align 8, !noundef !39
  switch i64 %249, label %.preheader51 [
    i64 190, label %native_ref_test.exit13
    i64 0, label %native_ref_test.exit13
  ]

250:                                              ; preds = %233
  call fastcc void @native_trap() #114
  unreachable

.preheader51:                                     ; preds = %255, %245
  %251 = phi i64 [ %257, %255 ], [ %249, %245 ]
  %252 = lshr i64 %251, 2
  %253 = add nsw i64 %252, -1
  %254 = icmp ult i64 %253, %241
  br i1 %254, label %255, label %.loopexit52

.loopexit52:                                      ; preds = %.preheader51, %239
  call fastcc void @native_trap() #114
  unreachable

255:                                              ; preds = %.preheader51
  %256 = getelementptr inbounds nuw i64, ptr %247, i64 %253
  %257 = load i64, ptr %256, align 8, !noundef !39
  switch i64 %257, label %.preheader51 [
    i64 190, label %native_ref_test.exit13
    i64 0, label %native_ref_test.exit13
  ]

native_ref_test.exit13:                           ; preds = %255, %255, %245, %245, %238, %238
  %.in140 = phi i64 [ %235, %238 ], [ %249, %245 ], [ %249, %245 ], [ %235, %238 ], [ %257, %255 ], [ %257, %255 ]
  %258 = icmp eq i64 %.in140, 190
  br i1 %258, label %then233, label %block231.thread40

then233:                                          ; preds = %native_ref_test.exit13
  call fastcc void @native_trap()
  unreachable

block231.thread40:                                ; preds = %native_ref_test.exit13
  %259 = inttoptr i64 %v229 to ptr
  %260 = load i64, ptr %259, align 8, !noundef !39
  %261 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %262 = icmp eq ptr %261, null
  br i1 %262, label %275, label %263

263:                                              ; preds = %block231.thread40
  switch i64 %260, label %264 [
    i64 82, label %native_ref_test.exit15
    i64 0, label %native_ref_test.exit15
  ]

264:                                              ; preds = %263
  %265 = getelementptr inbounds nuw i8, ptr %261, i64 360
  %266 = load i64, ptr %265, align 8, !noundef !39
  %267 = lshr i64 %260, 2
  %268 = add nsw i64 %267, -1
  %269 = icmp ult i64 %268, %266
  br i1 %269, label %270, label %.loopexit50

270:                                              ; preds = %264
  %271 = getelementptr inbounds nuw i8, ptr %261, i64 352
  %272 = load ptr, ptr %271, align 8, !nonnull !39, !noundef !39
  %273 = getelementptr inbounds nuw i64, ptr %272, i64 %268
  %274 = load i64, ptr %273, align 8, !noundef !39
  switch i64 %274, label %.preheader49 [
    i64 82, label %native_ref_test.exit15
    i64 0, label %native_ref_test.exit15
  ]

275:                                              ; preds = %block231.thread40
  call fastcc void @native_trap() #114
  unreachable

.preheader49:                                     ; preds = %280, %270
  %276 = phi i64 [ %282, %280 ], [ %274, %270 ]
  %277 = lshr i64 %276, 2
  %278 = add nsw i64 %277, -1
  %279 = icmp ult i64 %278, %266
  br i1 %279, label %280, label %.loopexit50

.loopexit50:                                      ; preds = %.preheader49, %264
  call fastcc void @native_trap() #114
  unreachable

280:                                              ; preds = %.preheader49
  %281 = getelementptr inbounds nuw i64, ptr %272, i64 %278
  %282 = load i64, ptr %281, align 8, !noundef !39
  switch i64 %282, label %.preheader49 [
    i64 82, label %native_ref_test.exit15
    i64 0, label %native_ref_test.exit15
  ]

native_ref_test.exit15:                           ; preds = %280, %280, %270, %270, %263, %263
  %.in141 = phi i64 [ %260, %263 ], [ %274, %270 ], [ %274, %270 ], [ %260, %263 ], [ %282, %280 ], [ %282, %280 ]
  %283 = icmp eq i64 %.in141, 82
  br i1 %283, label %ok242, label %trap238

trap238:                                          ; preds = %native_ref_test.exit15, %ok226
  call fastcc void @native_trap()
  unreachable

ok242:                                            ; preds = %native_ref_test.exit15
  %v244 = getelementptr i8, ptr %259, i64 8
  %v245 = load i64, ptr %v244, align 1
  %v246.not = icmp eq i64 %v245, 0
  br i1 %v246.not, label %trap247, label %ok248

trap247:                                          ; preds = %ok242
  call fastcc void @native_trap()
  unreachable

ok248:                                            ; preds = %ok242
  %v249 = inttoptr i64 %v245 to ptr
  %v250 = getelementptr i8, ptr %v249, i64 8
  %v251 = load i64, ptr %v250, align 1
  store i64 %v251, ptr %v3, align 8
  %v257 = getelementptr i8, ptr %v227, i64 16
  %v258 = load i64, ptr %v257, align 1
  %v259.not = icmp eq i64 %v258, 0
  br i1 %v259.not, label %trap260, label %ok261

trap260:                                          ; preds = %ok248
  call fastcc void @native_trap()
  unreachable

ok261:                                            ; preds = %ok248
  %v262 = inttoptr i64 %v258 to ptr
  %v263 = getelementptr i8, ptr %v262, i64 8
  %v264 = load i32, ptr %v263, align 1
  %v265 = icmp eq i32 %v264, 0
  br i1 %v265, label %then269, label %ok280

then269:                                          ; preds = %ok261
  call fastcc void @native_trap()
  unreachable

ok280:                                            ; preds = %ok261
  %v282 = getelementptr i8, ptr %v262, i64 16
  %v283 = load i64, ptr %v282, align 1
  %v284.not = icmp eq i64 %v283, 0
  br i1 %v284.not, label %trap285, label %ok286

trap285:                                          ; preds = %ok280
  call fastcc void @native_trap()
  unreachable

ok286:                                            ; preds = %ok280
  %v287 = inttoptr i64 %v283 to ptr
  %v288 = getelementptr i8, ptr %v287, i64 8
  %v289 = load i64, ptr %v288, align 1
  store i64 %v289, ptr %v4, align 8
  %v291 = icmp slt i64 %arg1.tr107, 1
  br i1 %v291, label %block294, label %else295

else295:                                          ; preds = %ok286
  %v299.not = icmp eq i64 %v289, 0
  br i1 %v299.not, label %trap300, label %ok301

trap300:                                          ; preds = %else295
  call fastcc void @native_trap()
  unreachable

ok301:                                            ; preds = %else295
  %v302 = inttoptr i64 %v289 to ptr
  %v303 = getelementptr i8, ptr %v302, i64 8
  %v304 = load i64, ptr %v303, align 1
  %v310 = getelementptr i8, ptr %v302, i64 16
  %v311 = load i64, ptr %v310, align 1
  store i64 %v251, ptr %v55, align 8
  store i64 %v311, ptr %v56, align 8
  store i64 %v304, ptr %v72, align 8
  store i64 7, ptr %1, align 8
  %284 = getelementptr inbounds nuw i8, ptr %261, i64 376
  %285 = load i64, ptr %284, align 8, !noundef !39
  %286 = icmp eq i64 %285, 0
  br i1 %286, label %287, label %291

287:                                              ; preds = %297, %291, %ok301
  %288 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %289 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %261, i64 noundef 32, ptr noundef %288) #84
  %290 = icmp eq ptr %289, null
  br i1 %290, label %299, label %ok320

291:                                              ; preds = %ok301
  %292 = getelementptr inbounds nuw i8, ptr %261, i64 368
  %293 = load i64, ptr %292, align 8, !noundef !39
  %294 = add i64 %293, 1
  store i64 %294, ptr %292, align 8
  %295 = urem i64 %294, %285
  %296 = icmp eq i64 %295, 0
  br i1 %296, label %297, label %287

297:                                              ; preds = %291
  %298 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %261, ptr noundef %298) #84
  br label %287

299:                                              ; preds = %287
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok320:                                            ; preds = %287
  %300 = ptrtoint ptr %289 to i64
  store i64 58, ptr %289, align 1
  %v327 = getelementptr i8, ptr %289, i64 8
  store i64 %v304, ptr %v327, align 1
  %v332 = getelementptr i8, ptr %289, i64 16
  store i64 %v311, ptr %v332, align 1
  %v337 = getelementptr i8, ptr %289, i64 24
  store i64 %v251, ptr %v337, align 1
  %v339 = add nsw i64 %arg1.tr107, -1
  store i64 %300, ptr %v55, align 8
  store i64 5, ptr %1, align 8
  call tailcc void @f.19(i64 %300, i64 %v339)
  br label %block294

block294:                                         ; preds = %ok320, %ok286
  %v344.b = load i1, ptr @g.9, align 1
  br i1 %v344.b, label %block347, label %then349

then349:                                          ; preds = %block294
  call fastcc void @native_trap()
  unreachable

block347:                                         ; preds = %block294
  %v351 = load i64, ptr @g.8, align 8
  %v352.not = icmp eq i64 %v351, 0
  br i1 %v352.not, label %trap353, label %ok354

trap353:                                          ; preds = %block347
  call fastcc void @native_trap()
  unreachable

ok354:                                            ; preds = %block347
  %v355 = load i64, ptr %v1, align 8
  %v356.not = icmp eq i64 %v355, 0
  br i1 %v356.not, label %trap357, label %ok358

trap357:                                          ; preds = %ok354
  call fastcc void @native_trap()
  unreachable

ok358:                                            ; preds = %ok354
  %v359 = inttoptr i64 %v355 to ptr
  %v360 = getelementptr i8, ptr %v359, i64 24
  %v361 = load i64, ptr %v360, align 1
  store i64 %v361, ptr %v3, align 8
  %301 = icmp ne i64 %v361, 0
  %302 = and i64 %v361, 1
  %.not.i17 = icmp eq i64 %302, 0
  %or.cond161 = and i1 %301, %.not.i17
  br i1 %or.cond161, label %303, label %trap370

303:                                              ; preds = %ok358
  %304 = inttoptr i64 %v361 to ptr
  %305 = load i64, ptr %304, align 8, !noundef !39
  %306 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %307 = icmp eq ptr %306, null
  br i1 %307, label %320, label %308

308:                                              ; preds = %303
  switch i64 %305, label %309 [
    i64 190, label %native_ref_test.exit18
    i64 0, label %native_ref_test.exit18
  ]

309:                                              ; preds = %308
  %310 = getelementptr inbounds nuw i8, ptr %306, i64 360
  %311 = load i64, ptr %310, align 8, !noundef !39
  %312 = lshr i64 %305, 2
  %313 = add nsw i64 %312, -1
  %314 = icmp ult i64 %313, %311
  br i1 %314, label %315, label %.loopexit48

315:                                              ; preds = %309
  %316 = getelementptr inbounds nuw i8, ptr %306, i64 352
  %317 = load ptr, ptr %316, align 8, !nonnull !39, !noundef !39
  %318 = getelementptr inbounds nuw i64, ptr %317, i64 %313
  %319 = load i64, ptr %318, align 8, !noundef !39
  switch i64 %319, label %.preheader47 [
    i64 190, label %native_ref_test.exit18
    i64 0, label %native_ref_test.exit18
  ]

320:                                              ; preds = %303
  call fastcc void @native_trap() #114
  unreachable

.preheader47:                                     ; preds = %325, %315
  %321 = phi i64 [ %327, %325 ], [ %319, %315 ]
  %322 = lshr i64 %321, 2
  %323 = add nsw i64 %322, -1
  %324 = icmp ult i64 %323, %311
  br i1 %324, label %325, label %.loopexit48

.loopexit48:                                      ; preds = %.preheader47, %309
  call fastcc void @native_trap() #114
  unreachable

325:                                              ; preds = %.preheader47
  %326 = getelementptr inbounds nuw i64, ptr %317, i64 %323
  %327 = load i64, ptr %326, align 8, !noundef !39
  switch i64 %327, label %.preheader47 [
    i64 190, label %native_ref_test.exit18
    i64 0, label %native_ref_test.exit18
  ]

native_ref_test.exit18:                           ; preds = %325, %325, %315, %315, %308, %308
  %.in142 = phi i64 [ %305, %308 ], [ %319, %315 ], [ %319, %315 ], [ %305, %308 ], [ %327, %325 ], [ %327, %325 ]
  %328 = icmp eq i64 %.in142, 190
  br i1 %328, label %then365, label %block363.thread44

then365:                                          ; preds = %native_ref_test.exit18
  call fastcc void @native_trap()
  unreachable

block363.thread44:                                ; preds = %native_ref_test.exit18
  %329 = inttoptr i64 %v361 to ptr
  %330 = load i64, ptr %329, align 8, !noundef !39
  %331 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %332 = icmp eq ptr %331, null
  br i1 %332, label %345, label %333

333:                                              ; preds = %block363.thread44
  switch i64 %330, label %334 [
    i64 82, label %native_ref_test.exit20
    i64 0, label %native_ref_test.exit20
  ]

334:                                              ; preds = %333
  %335 = getelementptr inbounds nuw i8, ptr %331, i64 360
  %336 = load i64, ptr %335, align 8, !noundef !39
  %337 = lshr i64 %330, 2
  %338 = add nsw i64 %337, -1
  %339 = icmp ult i64 %338, %336
  br i1 %339, label %340, label %.loopexit

340:                                              ; preds = %334
  %341 = getelementptr inbounds nuw i8, ptr %331, i64 352
  %342 = load ptr, ptr %341, align 8, !nonnull !39, !noundef !39
  %343 = getelementptr inbounds nuw i64, ptr %342, i64 %338
  %344 = load i64, ptr %343, align 8, !noundef !39
  switch i64 %344, label %.preheader [
    i64 82, label %native_ref_test.exit20
    i64 0, label %native_ref_test.exit20
  ]

345:                                              ; preds = %block363.thread44
  call fastcc void @native_trap() #114
  unreachable

.preheader:                                       ; preds = %350, %340
  %346 = phi i64 [ %352, %350 ], [ %344, %340 ]
  %347 = lshr i64 %346, 2
  %348 = add nsw i64 %347, -1
  %349 = icmp ult i64 %348, %336
  br i1 %349, label %350, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %334
  call fastcc void @native_trap() #114
  unreachable

350:                                              ; preds = %.preheader
  %351 = getelementptr inbounds nuw i64, ptr %342, i64 %348
  %352 = load i64, ptr %351, align 8, !noundef !39
  switch i64 %352, label %.preheader [
    i64 82, label %native_ref_test.exit20
    i64 0, label %native_ref_test.exit20
  ]

native_ref_test.exit20:                           ; preds = %350, %350, %340, %340, %333, %333
  %.in143 = phi i64 [ %330, %333 ], [ %344, %340 ], [ %344, %340 ], [ %330, %333 ], [ %352, %350 ], [ %352, %350 ]
  %353 = icmp eq i64 %.in143, 82
  br i1 %353, label %ok374, label %trap370

trap370:                                          ; preds = %native_ref_test.exit20, %ok358
  call fastcc void @native_trap()
  unreachable

ok374:                                            ; preds = %native_ref_test.exit20
  %v376 = getelementptr i8, ptr %329, i64 16
  %v377 = load i64, ptr %v376, align 1
  %v378.not = icmp eq i64 %v377, 0
  br i1 %v378.not, label %trap379, label %ok380

trap379:                                          ; preds = %ok374
  call fastcc void @native_trap()
  unreachable

ok380:                                            ; preds = %ok374
  %v381 = inttoptr i64 %v377 to ptr
  %v382 = getelementptr i8, ptr %v381, i64 8
  %v383 = load i64, ptr %v382, align 1
  store i64 %v383, ptr %v3, align 8
  %v389 = getelementptr i8, ptr %v359, i64 16
  %v390 = load i64, ptr %v389, align 1
  %v391.not = icmp eq i64 %v390, 0
  br i1 %v391.not, label %trap392, label %ok393

trap392:                                          ; preds = %ok380
  call fastcc void @native_trap()
  unreachable

ok393:                                            ; preds = %ok380
  %v394 = inttoptr i64 %v390 to ptr
  %v395 = getelementptr i8, ptr %v394, i64 8
  %v396 = load i32, ptr %v395, align 1
  %v397 = icmp eq i32 %v396, 0
  br i1 %v397, label %then401, label %ok412

then401:                                          ; preds = %ok393
  call fastcc void @native_trap()
  unreachable

ok412:                                            ; preds = %ok393
  %v414 = getelementptr i8, ptr %v394, i64 16
  %v415 = load i64, ptr %v414, align 1
  %v416.not = icmp eq i64 %v415, 0
  br i1 %v416.not, label %trap417, label %ok418

trap417:                                          ; preds = %ok412
  call fastcc void @native_trap()
  unreachable

ok418:                                            ; preds = %ok412
  %v419 = inttoptr i64 %v415 to ptr
  %v420 = getelementptr i8, ptr %v419, i64 8
  %v421 = load i64, ptr %v420, align 1
  store i64 %v421, ptr %v4, align 8
  br i1 %v291, label %then428, label %else427

then428:                                          ; preds = %ok418
  %354 = load i64, ptr %0, align 8, !noundef !39
  %355 = icmp eq i64 %354, 0
  br i1 %355, label %native_roots_leave.exit, label %356

356:                                              ; preds = %then428
  %357 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %357, ptr @native_roots.0, align 8
  %358 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %359 = add i64 %358, -1
  store i64 %359, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %356, %then428
  ret void

else427:                                          ; preds = %ok418
  %v431.not = icmp eq i64 %v421, 0
  br i1 %v431.not, label %trap432, label %ok433

trap432:                                          ; preds = %else427
  call fastcc void @native_trap()
  unreachable

ok433:                                            ; preds = %else427
  %v434 = inttoptr i64 %v421 to ptr
  %v435 = getelementptr i8, ptr %v434, i64 8
  %v436 = load i64, ptr %v435, align 1
  %v442 = getelementptr i8, ptr %v434, i64 16
  %v443 = load i64, ptr %v442, align 1
  store i64 %v383, ptr %v55, align 8
  store i64 %v443, ptr %v56, align 8
  store i64 %v436, ptr %v72, align 8
  store i64 7, ptr %1, align 8
  %360 = getelementptr inbounds nuw i8, ptr %331, i64 376
  %361 = load i64, ptr %360, align 8, !noundef !39
  %362 = icmp eq i64 %361, 0
  br i1 %362, label %363, label %367

363:                                              ; preds = %373, %367, %ok433
  %364 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %365 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %331, i64 noundef 32, ptr noundef %364) #84
  %366 = icmp eq ptr %365, null
  br i1 %366, label %375, label %ok452

367:                                              ; preds = %ok433
  %368 = getelementptr inbounds nuw i8, ptr %331, i64 368
  %369 = load i64, ptr %368, align 8, !noundef !39
  %370 = add i64 %369, 1
  store i64 %370, ptr %368, align 8
  %371 = urem i64 %370, %361
  %372 = icmp eq i64 %371, 0
  br i1 %372, label %373, label %363

373:                                              ; preds = %367
  %374 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %331, ptr noundef %374) #84
  br label %363

375:                                              ; preds = %363
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok452:                                            ; preds = %363
  %376 = ptrtoint ptr %365 to i64
  store i64 58, ptr %365, align 1
  %v459 = getelementptr i8, ptr %365, i64 8
  store i64 %v436, ptr %v459, align 1
  %v464 = getelementptr i8, ptr %365, i64 16
  store i64 %v443, ptr %v464, align 1
  %v469 = getelementptr i8, ptr %365, i64 24
  store i64 %v383, ptr %v469, align 1
  %v471 = add nsw i64 %arg1.tr107, -1
  %377 = load i64, ptr %0, align 8, !noundef !39
  %378 = icmp eq i64 %377, 0
  %.pre77 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %379 = zext i1 %378 to i64
  %380 = add i64 %.pre77, %379
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %381 = select i1 %378, ptr %native_roots.0.val, ptr %roots.val
  store i64 7, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %381, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %380, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %382 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %383 = call noundef i64 @llvm.umax.i64(i64 %380, i64 %382)
  store i64 %383, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %376, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v5, align 8
  %v9.b = load i1, ptr @g.5, align 1
  br i1 %v9.b, label %block12, label %then14
}
