define internal tailcc i64 @f.21(i64 %arg0, i64 %arg1, i64 %arg2) #105 personality ptr @rust_eh_personality {
entry:
  %v77 = icmp eq i64 %arg1, 0
  br i1 %v77, label %native_roots_leave.exit, label %else11

native_roots_leave.exit:                          ; preds = %ok49, %entry
  %arg2.tr.lcssa = phi i64 [ %arg2, %entry ], [ %v57, %ok49 ]
  ret i64 %arg2.tr.lcssa

else11:                                           ; preds = %ok49, %entry
  %arg2.tr10 = phi i64 [ %v57, %ok49 ], [ %arg2, %entry ]
  %arg1.tr9 = phi i64 [ %v54, %ok49 ], [ %arg1, %entry ]
  %arg0.tr8 = phi i64 [ %v52, %ok49 ], [ %arg0, %entry ]
  %v16.not = icmp eq i64 %arg0.tr8, 0
  br i1 %v16.not, label %trap17, label %ok18

trap17:                                           ; preds = %else11
  tail call fastcc void @native_trap()
  unreachable

ok18:                                             ; preds = %else11
  %v19 = inttoptr i64 %arg0.tr8 to ptr
  %v20 = getelementptr i8, ptr %v19, i64 8
  %v21 = load i64, ptr %v20, align 1
  %v22.not = icmp eq i64 %v21, 0
  br i1 %v22.not, label %trap23, label %ok24

trap23:                                           ; preds = %ok18
  tail call fastcc void @native_trap()
  unreachable

ok24:                                             ; preds = %ok18
  %v25 = inttoptr i64 %v21 to ptr
  %v26 = getelementptr i8, ptr %v25, i64 8
  %v27 = load i32, ptr %v26, align 1
  %v28 = icmp eq i32 %v27, 0
  br i1 %v28, label %then32, label %ok43

then32:                                           ; preds = %ok24
  tail call fastcc void @native_trap()
  unreachable

ok43:                                             ; preds = %ok24
  %v45 = getelementptr i8, ptr %v25, i64 16
  %v46 = load i64, ptr %v45, align 1
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %ok43
  tail call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %ok43
  %v50 = inttoptr i64 %v46 to ptr
  %v51 = getelementptr i8, ptr %v50, i64 16
  %v52 = load i64, ptr %v51, align 1
  %v54 = add i64 %arg1.tr9, -1
  %v57 = shl i64 %arg2.tr10, 1
  %v7 = icmp eq i64 %v54, 0
  br i1 %v7, label %native_roots_leave.exit, label %else11
}
