define internal tailcc i32 @f.13(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [5 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 5, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  store i64 0, ptr %v3, align 8
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap10

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %28, label %14

14:                                               ; preds = %9
  %15 = icmp eq i64 %11, 50
  switch i64 %11, label %16 [
    i64 50, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

16:                                               ; preds = %14
  %17 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %18 = load i64, ptr %17, align 8, !noundef !39
  %19 = lshr i64 %11, 2
  %20 = add nsw i64 %19, -1
  %21 = icmp ult i64 %20, %18
  br i1 %21, label %22, label %.loopexit6

22:                                               ; preds = %16
  %23 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %24 = load ptr, ptr %23, align 8, !nonnull !39, !noundef !39
  %25 = getelementptr inbounds nuw i64, ptr %24, i64 %20
  %26 = load i64, ptr %25, align 8, !noundef !39
  %27 = icmp eq i64 %26, 50
  switch i64 %26, label %.preheader5 [
    i64 50, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

28:                                               ; preds = %9
  call fastcc void @native_trap() #114
  unreachable

.preheader5:                                      ; preds = %33, %22
  %29 = phi i64 [ %35, %33 ], [ %26, %22 ]
  %30 = lshr i64 %29, 2
  %31 = add nsw i64 %30, -1
  %32 = icmp ult i64 %31, %18
  br i1 %32, label %33, label %.loopexit6

.loopexit6:                                       ; preds = %.preheader5, %16
  call fastcc void @native_trap() #114
  unreachable

33:                                               ; preds = %.preheader5
  %34 = getelementptr inbounds nuw i64, ptr %24, i64 %31
  %35 = load i64, ptr %34, align 8, !noundef !39
  switch i64 %35, label %.preheader5 [
    i64 50, label %native_ref_test.exit.loopexit
    i64 0, label %native_ref_test.exit.loopexit
  ]

native_ref_test.exit.loopexit:                    ; preds = %33, %33
  %.lcssa19 = phi i64 [ %35, %33 ], [ %35, %33 ]
  %36 = icmp eq i64 %.lcssa19, 50
  br i1 %36, label %ok11, label %trap10

native_ref_test.exit:                             ; preds = %22, %22, %14, %14
  %37 = phi i1 [ %15, %14 ], [ %27, %22 ], [ %27, %22 ], [ %15, %14 ]
  br i1 %37, label %ok11, label %trap10

trap10:                                           ; preds = %native_ref_test.exit, %native_ref_test.exit.loopexit, %entry
  call fastcc void @native_trap()
  unreachable

ok11:                                             ; preds = %native_ref_test.exit, %native_ref_test.exit.loopexit
  switch i64 %11, label %38 [
    i64 50, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

38:                                               ; preds = %ok11
  %39 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = lshr i64 %11, 2
  %42 = add nsw i64 %41, -1
  %43 = icmp ult i64 %42, %40
  br i1 %43, label %44, label %.loopexit

44:                                               ; preds = %38
  %45 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %46 = load ptr, ptr %45, align 8, !nonnull !39, !noundef !39
  %47 = getelementptr inbounds nuw i64, ptr %46, i64 %42
  %48 = load i64, ptr %47, align 8, !noundef !39
  %49 = icmp eq i64 %48, 50
  switch i64 %48, label %.preheader [
    i64 50, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader:                                       ; preds = %54, %44
  %50 = phi i64 [ %56, %54 ], [ %48, %44 ]
  %51 = lshr i64 %50, 2
  %52 = add nsw i64 %51, -1
  %53 = icmp ult i64 %52, %40
  br i1 %53, label %54, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %38
  call fastcc void @native_trap() #114
  unreachable

54:                                               ; preds = %.preheader
  %55 = getelementptr inbounds nuw i64, ptr %46, i64 %52
  %56 = load i64, ptr %55, align 8, !noundef !39
  switch i64 %56, label %.preheader [
    i64 50, label %native_ref_test.exit2.loopexit
    i64 0, label %native_ref_test.exit2.loopexit
  ]

native_ref_test.exit2.loopexit:                   ; preds = %54, %54
  %.lcssa20 = phi i64 [ %56, %54 ], [ %56, %54 ]
  %57 = icmp eq i64 %.lcssa20, 50
  br i1 %57, label %ok16, label %trap15

native_ref_test.exit2:                            ; preds = %44, %44, %ok11, %ok11
  %58 = phi i1 [ %15, %ok11 ], [ %49, %44 ], [ %49, %44 ], [ %15, %ok11 ]
  br i1 %58, label %ok16, label %trap15

trap15:                                           ; preds = %native_ref_test.exit2, %native_ref_test.exit2.loopexit
  call fastcc void @native_trap()
  unreachable

ok16:                                             ; preds = %native_ref_test.exit2, %native_ref_test.exit2.loopexit
  store i64 %arg0, ptr %v3, align 8
  %v21 = getelementptr i8, ptr %10, i64 32
  %v22 = load i64, ptr %v21, align 1
  %v23.not = icmp eq i64 %v22, 0
  br i1 %v23.not, label %trap24, label %ok25

trap24:                                           ; preds = %ok16
  call fastcc void @native_trap()
  unreachable

ok25:                                             ; preds = %ok16
  %v26 = inttoptr i64 %v22 to ptr
  %v27 = getelementptr i8, ptr %v26, i64 16
  %v28 = load i64, ptr %v27, align 1
  %v29.not = icmp eq i64 %v28, 0
  br i1 %v29.not, label %trap30, label %ok31

trap30:                                           ; preds = %ok25
  call fastcc void @native_trap()
  unreachable

ok31:                                             ; preds = %ok25
  %v32 = inttoptr i64 %v28 to ptr
  %v33 = getelementptr i8, ptr %v32, i64 8
  %v34 = load i64, ptr %v33, align 1
  %v36 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  store i64 %v34, ptr %v36, align 8
  store i64 3, ptr %1, align 8
  %v38 = call tailcc i64 @f.17(i64 %v34, i64 %arg1)
  %v39 = load i64, ptr %v3, align 8
  %v40.not = icmp eq i64 %v39, 0
  br i1 %v40.not, label %trap41, label %ok42

trap41:                                           ; preds = %ok31
  call fastcc void @native_trap()
  unreachable

ok42:                                             ; preds = %ok31
  %v43 = inttoptr i64 %v39 to ptr
  %v44 = getelementptr i8, ptr %v43, i64 8
  %v45 = load i64, ptr %v44, align 1
  %v51 = getelementptr i8, ptr %v43, i64 16
  %v52 = load i64, ptr %v51, align 1
  %v58 = getelementptr i8, ptr %v43, i64 24
  %v59 = load i64, ptr %v58, align 1
  store i64 %v59, ptr %v36, align 8
  %v62 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 %v52, ptr %v62, align 8
  %v63 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 %v45, ptr %v63, align 8
  store i64 5, ptr %1, align 8
  %59 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %60 = icmp eq ptr %59, null
  br i1 %60, label %61, label %62

61:                                               ; preds = %ok42
  call fastcc void @native_trap() #114
  unreachable

62:                                               ; preds = %ok42
  %63 = getelementptr inbounds nuw i8, ptr %59, i64 376
  %64 = load i64, ptr %63, align 8, !noundef !39
  %65 = icmp eq i64 %64, 0
  br i1 %65, label %66, label %70

66:                                               ; preds = %76, %70, %62
  %67 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %68 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %59, i64 noundef 40, ptr noundef %67) #84
  %69 = icmp eq ptr %68, null
  br i1 %69, label %78, label %ok68

70:                                               ; preds = %62
  %71 = getelementptr inbounds nuw i8, ptr %59, i64 368
  %72 = load i64, ptr %71, align 8, !noundef !39
  %73 = add i64 %72, 1
  store i64 %73, ptr %71, align 8
  %74 = urem i64 %73, %64
  %75 = icmp eq i64 %74, 0
  br i1 %75, label %76, label %66

76:                                               ; preds = %70
  %77 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %59, ptr noundef %77) #84
  br label %66

78:                                               ; preds = %66
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok68:                                             ; preds = %66
  store i64 34, ptr %68, align 1
  %v75 = getelementptr i8, ptr %68, i64 8
  store i64 %v45, ptr %v75, align 1
  %v80 = getelementptr i8, ptr %68, i64 16
  store i64 %v52, ptr %v80, align 1
  %v85 = getelementptr i8, ptr %68, i64 24
  store i64 %v59, ptr %v85, align 1
  %v90 = getelementptr i8, ptr %68, i64 32
  store i64 %arg1, ptr %v90, align 1
  %79 = load i64, ptr %0, align 8, !noundef !39
  %80 = icmp eq i64 %79, 0
  br i1 %80, label %native_roots_leave.exit, label %81

81:                                               ; preds = %ok68
  %82 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %82, ptr @native_roots.0, align 8
  %83 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %84 = add i64 %83, -1
  store i64 %84, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %81, %ok68
  %85 = ptrtoint ptr %68 to i64
  %v92 = tail call tailcc i32 @f.14(i64 %85, i64 %v38)
  ret i32 %v92
}
