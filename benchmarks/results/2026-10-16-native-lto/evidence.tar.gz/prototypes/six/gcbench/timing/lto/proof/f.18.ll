define internal tailcc noundef i32 @f.18(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  %0 = icmp ne i64 %arg0, 0
  %1 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %1, 0
  %or.cond = and i1 %0, %.not.i
  br i1 %or.cond, label %2, label %trap9

2:                                                ; preds = %entry
  %3 = inttoptr i64 %arg0 to ptr
  %4 = load i64, ptr %3, align 8, !noundef !39
  %5 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %6 = icmp eq ptr %5, null
  br i1 %6, label %19, label %7

7:                                                ; preds = %2
  switch i64 %4, label %8 [
    i64 54, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

8:                                                ; preds = %7
  %9 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %10 = load i64, ptr %9, align 8, !noundef !39
  %11 = lshr i64 %4, 2
  %12 = add nsw i64 %11, -1
  %13 = icmp ult i64 %12, %10
  br i1 %13, label %14, label %.loopexit30

14:                                               ; preds = %8
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %16 = load ptr, ptr %15, align 8, !nonnull !39, !noundef !39
  %17 = getelementptr inbounds nuw i64, ptr %16, i64 %12
  %18 = load i64, ptr %17, align 8, !noundef !39
  switch i64 %18, label %.preheader29 [
    i64 54, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

19:                                               ; preds = %2
  tail call fastcc void @native_trap() #114
  unreachable

.preheader29:                                     ; preds = %24, %14
  %20 = phi i64 [ %26, %24 ], [ %18, %14 ]
  %21 = lshr i64 %20, 2
  %22 = add nsw i64 %21, -1
  %23 = icmp ult i64 %22, %10
  br i1 %23, label %24, label %.loopexit30

.loopexit30:                                      ; preds = %.preheader29, %8
  tail call fastcc void @native_trap() #114
  unreachable

24:                                               ; preds = %.preheader29
  %25 = getelementptr inbounds nuw i64, ptr %16, i64 %22
  %26 = load i64, ptr %25, align 8, !noundef !39
  switch i64 %26, label %.preheader29 [
    i64 54, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %24, %24, %14, %14, %7, %7
  %.in = phi i64 [ %4, %7 ], [ %18, %14 ], [ %18, %14 ], [ %4, %7 ], [ %26, %24 ], [ %26, %24 ]
  %27 = icmp eq i64 %.in, 54
  br i1 %27, label %ok10.preheader, label %trap9

ok10.preheader:                                   ; preds = %native_ref_test.exit
  %v39.b = load i1, ptr @g.19, align 1
  br label %ok13

trap9:                                            ; preds = %native_ref_test.exit9, %ok123, %native_ref_test.exit, %entry
  tail call fastcc void @native_trap()
  unreachable

ok13:                                             ; preds = %native_ref_test.exit9, %ok10.preheader
  %28 = phi ptr [ %53, %native_ref_test.exit9 ], [ %5, %ok10.preheader ]
  %29 = phi i64 [ %104, %native_ref_test.exit9 ], [ %4, %ok10.preheader ]
  %roots.sroa.8.0 = phi i64 [ %v126, %native_ref_test.exit9 ], [ %arg0, %ok10.preheader ]
  %arg1.tr45 = phi i64 [ %v61, %native_ref_test.exit9 ], [ %arg1, %ok10.preheader ]
  %v14 = inttoptr i64 %roots.sroa.8.0 to ptr
  %v15 = getelementptr i8, ptr %v14, i64 8
  %v16 = load i64, ptr %v15, align 1
  %30 = sdiv i64 %v16, 2
  %v19.not = icmp sgt i64 %30, %arg1.tr45
  br i1 %v19.not, label %else23, label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %ok13
  ret i32 0

else23:                                           ; preds = %ok13
  %31 = and i64 %roots.sroa.8.0, 1
  %.not.i1 = icmp eq i64 %31, 0
  br i1 %.not.i1, label %32, label %trap29

32:                                               ; preds = %else23
  switch i64 %29, label %33 [
    i64 54, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

33:                                               ; preds = %32
  %34 = getelementptr inbounds nuw i8, ptr %28, i64 360
  %35 = load i64, ptr %34, align 8, !noundef !39
  %36 = lshr i64 %29, 2
  %37 = add nsw i64 %36, -1
  %38 = icmp ult i64 %37, %35
  br i1 %38, label %39, label %.loopexit24

39:                                               ; preds = %33
  %40 = getelementptr inbounds nuw i8, ptr %28, i64 352
  %41 = load ptr, ptr %40, align 8, !nonnull !39, !noundef !39
  %42 = getelementptr inbounds nuw i64, ptr %41, i64 %37
  %43 = load i64, ptr %42, align 8, !noundef !39
  switch i64 %43, label %.preheader23 [
    i64 54, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader23:                                     ; preds = %48, %39
  %44 = phi i64 [ %50, %48 ], [ %43, %39 ]
  %45 = lshr i64 %44, 2
  %46 = add nsw i64 %45, -1
  %47 = icmp ult i64 %46, %35
  br i1 %47, label %48, label %.loopexit24

.loopexit24:                                      ; preds = %.preheader23, %33
  tail call fastcc void @native_trap() #114
  unreachable

48:                                               ; preds = %.preheader23
  %49 = getelementptr inbounds nuw i64, ptr %41, i64 %46
  %50 = load i64, ptr %49, align 8, !noundef !39
  switch i64 %50, label %.preheader23 [
    i64 54, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

native_ref_test.exit2:                            ; preds = %48, %48, %39, %39, %32, %32
  %.in56 = phi i64 [ %29, %32 ], [ %43, %39 ], [ %43, %39 ], [ %29, %32 ], [ %50, %48 ], [ %50, %48 ]
  %51 = icmp eq i64 %.in56, 54
  br i1 %51, label %ok33, label %trap29

trap29:                                           ; preds = %native_ref_test.exit2, %else23
  tail call fastcc void @native_trap()
  unreachable

ok33:                                             ; preds = %native_ref_test.exit2
  %v35 = getelementptr i8, ptr %v14, i64 16
  %v36 = load i64, ptr %v35, align 1
  br i1 %v39.b, label %block42, label %then44

then44:                                           ; preds = %ok33
  tail call fastcc void @native_trap()
  unreachable

block42:                                          ; preds = %ok33
  %v46 = load i64, ptr @g.18, align 8
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %block42
  tail call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %block42
  %v51 = icmp ugt i64 %arg1.tr45, 4294967295
  br i1 %v51, label %then55, label %block53

then55:                                           ; preds = %ok49
  tail call fastcc void @native_trap()
  unreachable

block53:                                          ; preds = %ok49
  %v61 = add nuw nsw i64 %arg1.tr45, 1
  %v62 = uitofp nneg i64 %v61 to double
  %v63 = fdiv double 1.000000e+00, %v62
  %v64.not = icmp eq i64 %v36, 0
  br i1 %v64.not, label %trap65, label %ok66

trap65:                                           ; preds = %block53
  tail call fastcc void @native_trap()
  unreachable

ok66:                                             ; preds = %block53
  %v67 = and i64 %v36, 1
  %v68 = icmp eq i64 %v67, 0
  br i1 %v68, label %ok70, label %trap69

trap69:                                           ; preds = %ok66
  tail call fastcc void @native_trap()
  unreachable

ok70:                                             ; preds = %ok66
  %v71 = inttoptr i64 %v36 to ptr
  %v72 = getelementptr i8, ptr %v71, i64 8
  %v73 = load i64, ptr %v72, align 1
  %v75 = icmp ult i64 %arg1.tr45, %v73
  br i1 %v75, label %ok77, label %trap76

trap76:                                           ; preds = %ok70
  tail call fastcc void @native_trap()
  unreachable

ok77:                                             ; preds = %ok70
  %v79 = getelementptr i8, ptr %v71, i64 16
  %v80 = getelementptr double, ptr %v79, i64 %arg1.tr45
  store double %v63, ptr %v80, align 1
  %52 = load i64, ptr %v14, align 8, !noundef !39
  %53 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %54 = icmp eq ptr %53, null
  br i1 %54, label %69, label %55

55:                                               ; preds = %ok77
  %56 = icmp eq i64 %52, 54
  switch i64 %52, label %57 [
    i64 54, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

57:                                               ; preds = %55
  %58 = getelementptr inbounds nuw i8, ptr %53, i64 360
  %59 = load i64, ptr %58, align 8, !noundef !39
  %60 = lshr i64 %52, 2
  %61 = add nsw i64 %60, -1
  %62 = icmp ult i64 %61, %59
  br i1 %62, label %63, label %.loopexit22

63:                                               ; preds = %57
  %64 = getelementptr inbounds nuw i8, ptr %53, i64 352
  %65 = load ptr, ptr %64, align 8, !nonnull !39, !noundef !39
  %66 = getelementptr inbounds nuw i64, ptr %65, i64 %61
  %67 = load i64, ptr %66, align 8, !noundef !39
  %68 = icmp eq i64 %67, 54
  switch i64 %67, label %.preheader21 [
    i64 54, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

69:                                               ; preds = %ok77
  tail call fastcc void @native_trap() #114
  unreachable

.preheader21:                                     ; preds = %74, %63
  %70 = phi i64 [ %76, %74 ], [ %67, %63 ]
  %71 = lshr i64 %70, 2
  %72 = add nsw i64 %71, -1
  %73 = icmp ult i64 %72, %59
  br i1 %73, label %74, label %.loopexit22

.loopexit22:                                      ; preds = %.preheader21, %57
  tail call fastcc void @native_trap() #114
  unreachable

74:                                               ; preds = %.preheader21
  %75 = getelementptr inbounds nuw i64, ptr %65, i64 %72
  %76 = load i64, ptr %75, align 8, !noundef !39
  switch i64 %76, label %.preheader21 [
    i64 54, label %native_ref_test.exit4.loopexit
    i64 0, label %native_ref_test.exit4.loopexit
  ]

native_ref_test.exit4.loopexit:                   ; preds = %74, %74
  %.lcssa66 = phi i64 [ %76, %74 ], [ %76, %74 ]
  %77 = icmp eq i64 %.lcssa66, 54
  br i1 %77, label %ok88, label %trap84

native_ref_test.exit4:                            ; preds = %63, %63, %55, %55
  %78 = phi i1 [ %56, %55 ], [ %68, %63 ], [ %68, %63 ], [ %56, %55 ]
  br i1 %78, label %ok88, label %trap84

trap84:                                           ; preds = %native_ref_test.exit4, %native_ref_test.exit4.loopexit
  tail call fastcc void @native_trap()
  unreachable

ok88:                                             ; preds = %native_ref_test.exit4, %native_ref_test.exit4.loopexit
  %v90 = getelementptr i8, ptr %v14, i64 24
  %v91 = load i64, ptr %v90, align 1
  %v92.not = icmp eq i64 %v91, 0
  br i1 %v92.not, label %trap93, label %ok94

trap93:                                           ; preds = %ok88
  tail call fastcc void @native_trap()
  unreachable

ok94:                                             ; preds = %ok88
  %v95 = inttoptr i64 %v91 to ptr
  %v96 = getelementptr i8, ptr %v95, i64 8
  %v97 = load i32, ptr %v96, align 1
  %v98 = icmp eq i32 %v97, 0
  br i1 %v98, label %then102, label %block100

then102:                                          ; preds = %ok94
  tail call fastcc void @native_trap()
  unreachable

block100:                                         ; preds = %ok94
  switch i64 %52, label %79 [
    i64 54, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

79:                                               ; preds = %block100
  %80 = getelementptr inbounds nuw i8, ptr %53, i64 360
  %81 = load i64, ptr %80, align 8, !noundef !39
  %82 = lshr i64 %52, 2
  %83 = add nsw i64 %82, -1
  %84 = icmp ult i64 %83, %81
  br i1 %84, label %85, label %.loopexit20

85:                                               ; preds = %79
  %86 = getelementptr inbounds nuw i8, ptr %53, i64 352
  %87 = load ptr, ptr %86, align 8, !nonnull !39, !noundef !39
  %88 = getelementptr inbounds nuw i64, ptr %87, i64 %83
  %89 = load i64, ptr %88, align 8, !noundef !39
  %90 = icmp eq i64 %89, 54
  switch i64 %89, label %.preheader19 [
    i64 54, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

.preheader19:                                     ; preds = %95, %85
  %91 = phi i64 [ %97, %95 ], [ %89, %85 ]
  %92 = lshr i64 %91, 2
  %93 = add nsw i64 %92, -1
  %94 = icmp ult i64 %93, %81
  br i1 %94, label %95, label %.loopexit20

.loopexit20:                                      ; preds = %.preheader19, %79
  tail call fastcc void @native_trap() #114
  unreachable

95:                                               ; preds = %.preheader19
  %96 = getelementptr inbounds nuw i64, ptr %87, i64 %93
  %97 = load i64, ptr %96, align 8, !noundef !39
  switch i64 %97, label %.preheader19 [
    i64 54, label %native_ref_test.exit6.loopexit
    i64 0, label %native_ref_test.exit6.loopexit
  ]

native_ref_test.exit6.loopexit:                   ; preds = %95, %95
  %.lcssa67 = phi i64 [ %97, %95 ], [ %97, %95 ]
  %98 = icmp eq i64 %.lcssa67, 54
  br i1 %98, label %ok117, label %trap107

native_ref_test.exit6:                            ; preds = %85, %85, %block100, %block100
  %99 = phi i1 [ %56, %block100 ], [ %90, %85 ], [ %90, %85 ], [ %56, %block100 ]
  br i1 %99, label %ok117, label %trap107

trap107:                                          ; preds = %native_ref_test.exit6, %native_ref_test.exit6.loopexit
  tail call fastcc void @native_trap()
  unreachable

ok117:                                            ; preds = %native_ref_test.exit6, %native_ref_test.exit6.loopexit
  %v119 = getelementptr i8, ptr %v95, i64 16
  %v120 = load i64, ptr %v119, align 1
  %v121.not = icmp eq i64 %v120, 0
  br i1 %v121.not, label %trap122, label %ok123

trap122:                                          ; preds = %ok117
  tail call fastcc void @native_trap()
  unreachable

ok123:                                            ; preds = %ok117
  %v124 = inttoptr i64 %v120 to ptr
  %v125 = getelementptr i8, ptr %v124, i64 16
  %v126 = load i64, ptr %v125, align 1
  %100 = icmp ne i64 %v126, 0
  %101 = and i64 %v126, 1
  %.not.i8 = icmp eq i64 %101, 0
  %or.cond39 = and i1 %100, %.not.i8
  br i1 %or.cond39, label %102, label %trap9

102:                                              ; preds = %ok123
  %103 = inttoptr i64 %v126 to ptr
  %104 = load i64, ptr %103, align 8, !noundef !39
  switch i64 %104, label %105 [
    i64 54, label %native_ref_test.exit9
    i64 0, label %native_ref_test.exit9
  ]

105:                                              ; preds = %102
  %106 = getelementptr inbounds nuw i8, ptr %53, i64 360
  %107 = load i64, ptr %106, align 8, !noundef !39
  %108 = lshr i64 %104, 2
  %109 = add nsw i64 %108, -1
  %110 = icmp ult i64 %109, %107
  br i1 %110, label %111, label %.loopexit

111:                                              ; preds = %105
  %112 = getelementptr inbounds nuw i8, ptr %53, i64 352
  %113 = load ptr, ptr %112, align 8, !nonnull !39, !noundef !39
  %114 = getelementptr inbounds nuw i64, ptr %113, i64 %109
  %115 = load i64, ptr %114, align 8, !noundef !39
  switch i64 %115, label %.preheader [
    i64 54, label %native_ref_test.exit9
    i64 0, label %native_ref_test.exit9
  ]

.preheader:                                       ; preds = %120, %111
  %116 = phi i64 [ %122, %120 ], [ %115, %111 ]
  %117 = lshr i64 %116, 2
  %118 = add nsw i64 %117, -1
  %119 = icmp ult i64 %118, %107
  br i1 %119, label %120, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %105
  tail call fastcc void @native_trap() #114
  unreachable

120:                                              ; preds = %.preheader
  %121 = getelementptr inbounds nuw i64, ptr %113, i64 %118
  %122 = load i64, ptr %121, align 8, !noundef !39
  switch i64 %122, label %.preheader [
    i64 54, label %native_ref_test.exit9
    i64 0, label %native_ref_test.exit9
  ]

native_ref_test.exit9:                            ; preds = %120, %120, %111, %111, %102, %102
  %.in57 = phi i64 [ %104, %102 ], [ %115, %111 ], [ %115, %111 ], [ %104, %102 ], [ %122, %120 ], [ %122, %120 ]
  %123 = icmp eq i64 %.in57, 54
  br i1 %123, label %ok13, label %trap9
}
