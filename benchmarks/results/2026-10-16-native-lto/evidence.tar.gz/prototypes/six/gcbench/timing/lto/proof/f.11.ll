define internal tailcc i64 @f.11(i64 %arg0, i64 %arg1, i64 %arg2) #106 personality ptr @rust_eh_personality {
native_roots_leave.exit:
  %v13 = tail call i64 @llvm.smin.i64(i64 %arg1, i64 %arg2)
  ret i64 %v13
}
