define internal tailcc noundef i32 @f.16(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [9 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 9, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v8 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(40) %v3, i8 0, i64 40, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap14

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 26, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit17

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader16 [
    i64 26, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #114
  unreachable

.preheader16:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit17

.loopexit17:                                      ; preds = %.preheader16, %15
  call fastcc void @native_trap() #114
  unreachable

31:                                               ; preds = %.preheader16
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader16 [
    i64 26, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in111 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in111, 26
  br i1 %34, label %ok15.lr.ph, label %trap14

ok15.lr.ph:                                       ; preds = %native_ref_test.exit
  %v76 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v91 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v167 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  br label %ok18

trap14:                                           ; preds = %native_ref_test.exit8, %ok230, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok18:                                             ; preds = %native_ref_test.exit8, %ok15.lr.ph
  %35 = phi ptr [ %12, %ok15.lr.ph ], [ %152, %native_ref_test.exit8 ]
  %36 = phi i64 [ %11, %ok15.lr.ph ], [ %151, %native_ref_test.exit8 ]
  %37 = phi i64 [ %3, %ok15.lr.ph ], [ %142, %native_ref_test.exit8 ]
  %38 = phi ptr [ %2, %ok15.lr.ph ], [ %143, %native_ref_test.exit8 ]
  %arg1.tr47 = phi i64 [ %arg1, %ok15.lr.ph ], [ %v235, %native_ref_test.exit8 ]
  %v30 = phi i64 [ %arg0, %ok15.lr.ph ], [ %v233, %native_ref_test.exit8 ]
  %v19 = inttoptr i64 %v30 to ptr
  %v20 = getelementptr i8, ptr %v19, i64 32
  %v21 = load i64, ptr %v20, align 1
  %v23.not = icmp sgt i64 %v21, %arg1.tr47
  br i1 %v23.not, label %else27, label %then28

then28:                                           ; preds = %ok18
  %.lcssa143 = phi i64 [ %37, %ok18 ]
  %.lcssa116 = phi ptr [ %38, %ok18 ]
  store ptr %.lcssa116, ptr @native_roots.0, align 8
  store i64 %.lcssa143, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  ret i32 0

else27:                                           ; preds = %ok18
  %39 = and i64 %v30, 1
  %.not.i1 = icmp eq i64 %39, 0
  br i1 %.not.i1, label %40, label %trap33

40:                                               ; preds = %else27
  switch i64 %36, label %41 [
    i64 26, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

41:                                               ; preds = %40
  %42 = getelementptr inbounds nuw i8, ptr %35, i64 360
  %43 = load i64, ptr %42, align 8, !noundef !39
  %44 = lshr i64 %36, 2
  %45 = add nsw i64 %44, -1
  %46 = icmp ult i64 %45, %43
  br i1 %46, label %47, label %.loopexit13

47:                                               ; preds = %41
  %48 = getelementptr inbounds nuw i8, ptr %35, i64 352
  %49 = load ptr, ptr %48, align 8, !nonnull !39, !noundef !39
  %50 = getelementptr inbounds nuw i64, ptr %49, i64 %45
  %51 = load i64, ptr %50, align 8, !noundef !39
  switch i64 %51, label %.preheader12 [
    i64 26, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader12:                                     ; preds = %56, %47
  %52 = phi i64 [ %58, %56 ], [ %51, %47 ]
  %53 = lshr i64 %52, 2
  %54 = add nsw i64 %53, -1
  %55 = icmp ult i64 %54, %43
  br i1 %55, label %56, label %.loopexit13

.loopexit13:                                      ; preds = %.preheader12, %41
  call fastcc void @native_trap() #114
  unreachable

56:                                               ; preds = %.preheader12
  %57 = getelementptr inbounds nuw i64, ptr %49, i64 %54
  %58 = load i64, ptr %57, align 8, !noundef !39
  switch i64 %58, label %.preheader12 [
    i64 26, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

native_ref_test.exit2:                            ; preds = %56, %56, %47, %47, %40, %40
  %.in112 = phi i64 [ %36, %40 ], [ %51, %47 ], [ %51, %47 ], [ %36, %40 ], [ %58, %56 ], [ %58, %56 ]
  %59 = icmp eq i64 %.in112, 26
  br i1 %59, label %ok34, label %trap33

trap33:                                           ; preds = %native_ref_test.exit2, %else27
  call fastcc void @native_trap()
  unreachable

ok34:                                             ; preds = %native_ref_test.exit2
  store i64 %v30, ptr %v3, align 8
  %v39 = getelementptr i8, ptr %v19, i64 24
  %v40 = load i64, ptr %v39, align 1
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v8, align 8
  %v44.b = load i1, ptr @g.5, align 1
  br i1 %v44.b, label %block47, label %then49

then49:                                           ; preds = %ok34
  call fastcc void @native_trap()
  unreachable

block47:                                          ; preds = %ok34
  %v51 = load i64, ptr @g.4, align 8
  %v52.not = icmp eq i64 %v51, 0
  br i1 %v52.not, label %trap53, label %ok58

trap53:                                           ; preds = %block47
  call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %block47
  %v60 = getelementptr i8, ptr %v19, i64 16
  %v61 = load i64, ptr %v60, align 1
  %v62.not = icmp eq i64 %v61, 0
  br i1 %v62.not, label %trap63, label %ok64

trap63:                                           ; preds = %ok58
  call fastcc void @native_trap()
  unreachable

ok64:                                             ; preds = %ok58
  %v65 = inttoptr i64 %v61 to ptr
  %v66 = getelementptr i8, ptr %v65, i64 8
  %v67 = load i32, ptr %v66, align 1
  %v68 = icmp eq i32 %v67, 0
  br i1 %v68, label %then72, label %block70

then72:                                           ; preds = %ok64
  call fastcc void @native_trap()
  unreachable

block70:                                          ; preds = %ok64
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v76, align 8
  store i64 7, ptr %1, align 8
  %60 = getelementptr inbounds nuw i8, ptr %35, i64 376
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = icmp eq i64 %61, 0
  br i1 %62, label %63, label %67

63:                                               ; preds = %73, %67, %block70
  %64 = phi ptr [ %.pre, %73 ], [ %roots, %67 ], [ %roots, %block70 ]
  %65 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %35, i64 noundef 16, ptr noundef %64) #84
  %66 = icmp eq ptr %65, null
  br i1 %66, label %74, label %ok81

67:                                               ; preds = %block70
  %68 = getelementptr inbounds nuw i8, ptr %35, i64 368
  %69 = load i64, ptr %68, align 8, !noundef !39
  %70 = add i64 %69, 1
  store i64 %70, ptr %68, align 8
  %71 = urem i64 %70, %61
  %72 = icmp eq i64 %71, 0
  br i1 %72, label %73, label %63

73:                                               ; preds = %67
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %35, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %63

74:                                               ; preds = %63
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok81:                                             ; preds = %63
  %75 = ptrtoint ptr %65 to i64
  store i64 62, ptr %65, align 1
  %v88 = getelementptr i8, ptr %65, i64 8
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v88, align 1
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v76, align 8
  store i64 %75, ptr %v91, align 8
  store i64 8, ptr %1, align 8
  %76 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %77 = icmp eq ptr %76, null
  br i1 %77, label %78, label %79

78:                                               ; preds = %ok81
  call fastcc void @native_trap() #114
  unreachable

79:                                               ; preds = %ok81
  %80 = getelementptr inbounds nuw i8, ptr %76, i64 376
  %81 = load i64, ptr %80, align 8, !noundef !39
  %82 = icmp eq i64 %81, 0
  br i1 %82, label %83, label %87

83:                                               ; preds = %93, %87, %79
  %84 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %85 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %76, i64 noundef 16, ptr noundef %84) #84
  %86 = icmp eq ptr %85, null
  br i1 %86, label %95, label %ok96

87:                                               ; preds = %79
  %88 = getelementptr inbounds nuw i8, ptr %76, i64 368
  %89 = load i64, ptr %88, align 8, !noundef !39
  %90 = add i64 %89, 1
  store i64 %90, ptr %88, align 8
  %91 = urem i64 %90, %81
  %92 = icmp eq i64 %91, 0
  br i1 %92, label %93, label %83

93:                                               ; preds = %87
  %94 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %76, ptr noundef %94) #84
  br label %83

95:                                               ; preds = %83
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok96:                                             ; preds = %83
  %96 = ptrtoint ptr %85 to i64
  store i64 62, ptr %85, align 1
  %v103 = getelementptr i8, ptr %85, i64 8
  store i64 ptrtoint (ptr @object.1.0 to i64), ptr %v103, align 1
  store i64 %96, ptr %v76, align 8
  store i64 %75, ptr %v91, align 8
  store i64 8, ptr %1, align 8
  %97 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %98 = icmp eq ptr %97, null
  br i1 %98, label %99, label %100

99:                                               ; preds = %ok96
  call fastcc void @native_trap() #114
  unreachable

100:                                              ; preds = %ok96
  %101 = getelementptr inbounds nuw i8, ptr %97, i64 376
  %102 = load i64, ptr %101, align 8, !noundef !39
  %103 = icmp eq i64 %102, 0
  br i1 %103, label %104, label %108

104:                                              ; preds = %114, %108, %100
  %105 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %106 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %97, i64 noundef 24, ptr noundef %105) #84
  %107 = icmp eq ptr %106, null
  br i1 %107, label %116, label %ok110

108:                                              ; preds = %100
  %109 = getelementptr inbounds nuw i8, ptr %97, i64 368
  %110 = load i64, ptr %109, align 8, !noundef !39
  %111 = add i64 %110, 1
  store i64 %111, ptr %109, align 8
  %112 = urem i64 %111, %102
  %113 = icmp eq i64 %112, 0
  br i1 %113, label %114, label %104

114:                                              ; preds = %108
  %115 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %97, ptr noundef %115) #84
  br label %104

116:                                              ; preds = %104
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok110:                                            ; preds = %104
  %117 = ptrtoint ptr %106 to i64
  store i64 82, ptr %106, align 1
  %v117 = getelementptr i8, ptr %106, i64 8
  store i64 %75, ptr %v117, align 1
  %v122 = getelementptr i8, ptr %106, i64 16
  store i64 %96, ptr %v122, align 1
  store i64 %117, ptr %v6, align 8
  %v123 = load i64, ptr %v3, align 8
  %v124.not = icmp eq i64 %v123, 0
  br i1 %v124.not, label %trap125, label %ok126

trap125:                                          ; preds = %ok110
  call fastcc void @native_trap()
  unreachable

ok126:                                            ; preds = %ok110
  %v127 = inttoptr i64 %v123 to ptr
  %v128 = getelementptr i8, ptr %v127, i64 16
  %v129 = load i64, ptr %v128, align 1
  %v130.not = icmp eq i64 %v129, 0
  br i1 %v130.not, label %trap131, label %ok132

trap131:                                          ; preds = %ok126
  call fastcc void @native_trap()
  unreachable

ok132:                                            ; preds = %ok126
  %v133 = inttoptr i64 %v129 to ptr
  %v134 = getelementptr i8, ptr %v133, i64 16
  %v135 = load i64, ptr %v134, align 1
  %v136.not = icmp eq i64 %v135, 0
  br i1 %v136.not, label %trap137, label %ok138

trap137:                                          ; preds = %ok132
  call fastcc void @native_trap()
  unreachable

ok138:                                            ; preds = %ok132
  %v139 = inttoptr i64 %v135 to ptr
  %v140 = getelementptr i8, ptr %v139, i64 8
  %v141 = load i64, ptr %v140, align 1
  store i64 %v141, ptr %v4, align 8
  %v143 = icmp slt i64 %v40, 1
  br i1 %v143, label %ok199, label %else147

else147:                                          ; preds = %ok138
  %v151.not = icmp eq i64 %v141, 0
  br i1 %v151.not, label %trap152, label %ok153

trap152:                                          ; preds = %else147
  call fastcc void @native_trap()
  unreachable

ok153:                                            ; preds = %else147
  %v154 = inttoptr i64 %v141 to ptr
  %v155 = getelementptr i8, ptr %v154, i64 8
  %v156 = load i64, ptr %v155, align 1
  %v162 = getelementptr i8, ptr %v154, i64 16
  %v163 = load i64, ptr %v162, align 1
  store i64 %117, ptr %v76, align 8
  store i64 %v163, ptr %v91, align 8
  store i64 %v156, ptr %v167, align 8
  store i64 9, ptr %1, align 8
  %118 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %119 = icmp eq ptr %118, null
  br i1 %119, label %120, label %121

120:                                              ; preds = %ok153
  call fastcc void @native_trap() #114
  unreachable

121:                                              ; preds = %ok153
  %122 = getelementptr inbounds nuw i8, ptr %118, i64 376
  %123 = load i64, ptr %122, align 8, !noundef !39
  %124 = icmp eq i64 %123, 0
  br i1 %124, label %125, label %129

125:                                              ; preds = %135, %129, %121
  %126 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %127 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %118, i64 noundef 32, ptr noundef %126) #84
  %128 = icmp eq ptr %127, null
  br i1 %128, label %137, label %block146

129:                                              ; preds = %121
  %130 = getelementptr inbounds nuw i8, ptr %118, i64 368
  %131 = load i64, ptr %130, align 8, !noundef !39
  %132 = add i64 %131, 1
  store i64 %132, ptr %130, align 8
  %133 = urem i64 %132, %123
  %134 = icmp eq i64 %133, 0
  br i1 %134, label %135, label %125

135:                                              ; preds = %129
  %136 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %118, ptr noundef %136) #84
  br label %125

137:                                              ; preds = %125
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

block146:                                         ; preds = %125
  %138 = ptrtoint ptr %127 to i64
  store i64 58, ptr %127, align 1
  %v179 = getelementptr i8, ptr %127, i64 8
  store i64 %v156, ptr %v179, align 1
  %v184 = getelementptr i8, ptr %127, i64 16
  store i64 %v163, ptr %v184, align 1
  %v189 = getelementptr i8, ptr %127, i64 24
  store i64 %117, ptr %v189, align 1
  %v191 = add nsw i64 %v40, -1
  store i64 %138, ptr %v76, align 8
  store i64 7, ptr %1, align 8
  call tailcc void @f.19(i64 %138, i64 %v191)
  %v196.pre = load i64, ptr %v3, align 8
  %v197.not = icmp eq i64 %v196.pre, 0
  br i1 %v197.not, label %trap198, label %block146.ok199_crit_edge

block146.ok199_crit_edge:                         ; preds = %block146
  %.pre22 = inttoptr i64 %v196.pre to ptr
  br label %ok199

trap198:                                          ; preds = %block146
  call fastcc void @native_trap()
  unreachable

ok199:                                            ; preds = %block146.ok199_crit_edge, %ok138
  %v200.pre-phi = phi ptr [ %.pre22, %block146.ok199_crit_edge ], [ %v127, %ok138 ]
  %v201 = getelementptr i8, ptr %v200.pre-phi, i64 40
  %v202 = load i64, ptr %v201, align 1
  %v203.not = icmp eq i64 %v202, 0
  br i1 %v203.not, label %trap204, label %ok205

trap204:                                          ; preds = %ok199
  call fastcc void @native_trap()
  unreachable

ok205:                                            ; preds = %ok199
  %v206 = inttoptr i64 %v202 to ptr
  %v207 = getelementptr i8, ptr %v206, i64 8
  %v208 = load i32, ptr %v207, align 1
  %v209 = icmp eq i32 %v208, 0
  br i1 %v209, label %then213, label %ok224

then213:                                          ; preds = %ok205
  call fastcc void @native_trap()
  unreachable

ok224:                                            ; preds = %ok205
  %v226 = getelementptr i8, ptr %v206, i64 16
  %v227 = load i64, ptr %v226, align 1
  %v228.not = icmp eq i64 %v227, 0
  br i1 %v228.not, label %trap229, label %ok230

trap229:                                          ; preds = %ok224
  call fastcc void @native_trap()
  unreachable

ok230:                                            ; preds = %ok224
  %v231 = inttoptr i64 %v227 to ptr
  %v232 = getelementptr i8, ptr %v231, i64 16
  %v233 = load i64, ptr %v232, align 1
  %v235 = add nsw i64 %arg1.tr47, 1
  %139 = load i64, ptr %0, align 8, !noundef !39
  %140 = icmp ne i64 %139, 0
  %.pre21 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %141 = sext i1 %140 to i64
  %142 = add i64 %.pre21, %141
  %roots.val = load ptr, ptr %roots, align 8
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %143 = select i1 %140, ptr %roots.val, ptr %native_roots.0.val
  store i64 9, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %143, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %144 = add i64 %142, 1
  store i64 %144, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %145 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %146 = call noundef i64 @llvm.umax.i64(i64 %144, i64 %145)
  store i64 %146, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v233, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(40) %v3, i8 0, i64 40, i1 false)
  %147 = icmp ne i64 %v233, 0
  %148 = and i64 %v233, 1
  %.not.i7 = icmp eq i64 %148, 0
  %or.cond89 = and i1 %147, %.not.i7
  br i1 %or.cond89, label %149, label %trap14

149:                                              ; preds = %ok230
  %150 = inttoptr i64 %v233 to ptr
  %151 = load i64, ptr %150, align 8, !noundef !39
  %152 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %153 = icmp eq ptr %152, null
  br i1 %153, label %166, label %154

154:                                              ; preds = %149
  switch i64 %151, label %155 [
    i64 26, label %native_ref_test.exit8
    i64 0, label %native_ref_test.exit8
  ]

155:                                              ; preds = %154
  %156 = getelementptr inbounds nuw i8, ptr %152, i64 360
  %157 = load i64, ptr %156, align 8, !noundef !39
  %158 = lshr i64 %151, 2
  %159 = add nsw i64 %158, -1
  %160 = icmp ult i64 %159, %157
  br i1 %160, label %161, label %.loopexit

161:                                              ; preds = %155
  %162 = getelementptr inbounds nuw i8, ptr %152, i64 352
  %163 = load ptr, ptr %162, align 8, !nonnull !39, !noundef !39
  %164 = getelementptr inbounds nuw i64, ptr %163, i64 %159
  %165 = load i64, ptr %164, align 8, !noundef !39
  switch i64 %165, label %.preheader [
    i64 26, label %native_ref_test.exit8
    i64 0, label %native_ref_test.exit8
  ]

166:                                              ; preds = %149
  call fastcc void @native_trap() #114
  unreachable

.preheader:                                       ; preds = %171, %161
  %167 = phi i64 [ %173, %171 ], [ %165, %161 ]
  %168 = lshr i64 %167, 2
  %169 = add nsw i64 %168, -1
  %170 = icmp ult i64 %169, %157
  br i1 %170, label %171, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %155
  call fastcc void @native_trap() #114
  unreachable

171:                                              ; preds = %.preheader
  %172 = getelementptr inbounds nuw i64, ptr %163, i64 %169
  %173 = load i64, ptr %172, align 8, !noundef !39
  switch i64 %173, label %.preheader [
    i64 26, label %native_ref_test.exit8
    i64 0, label %native_ref_test.exit8
  ]

native_ref_test.exit8:                            ; preds = %171, %171, %161, %161, %154, %154
  %.in = phi i64 [ %151, %154 ], [ %165, %161 ], [ %165, %161 ], [ %151, %154 ], [ %173, %171 ], [ %173, %171 ]
  %174 = icmp eq i64 %.in, 26
  br i1 %174, label %ok18, label %trap14
}
