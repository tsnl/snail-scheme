define internal tailcc noundef i32 @f.5(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [7 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 7, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap12

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 134, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit35

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader34 [
    i64 134, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #114
  unreachable

.preheader34:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit35

.loopexit35:                                      ; preds = %.preheader34, %15
  call fastcc void @native_trap() #114
  unreachable

31:                                               ; preds = %.preheader34
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader34 [
    i64 134, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in204 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in204, 134
  br i1 %34, label %ok13.lr.ph, label %trap12

ok13.lr.ph:                                       ; preds = %native_ref_test.exit
  %v84 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v184 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v185 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  br label %ok16

trap12:                                           ; preds = %native_ref_test.exit18, %ok356, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok16:                                             ; preds = %native_ref_test.exit18, %ok13.lr.ph
  %35 = phi i64 [ %4, %ok13.lr.ph ], [ %305, %native_ref_test.exit18 ]
  %36 = phi ptr [ %2, %ok13.lr.ph ], [ %306, %native_ref_test.exit18 ]
  %37 = phi ptr [ %12, %ok13.lr.ph ], [ %255, %native_ref_test.exit18 ]
  %38 = phi i64 [ %11, %ok13.lr.ph ], [ %313, %native_ref_test.exit18 ]
  %arg1.tr73 = phi i64 [ %arg1, %ok13.lr.ph ], [ %v361, %native_ref_test.exit18 ]
  %v28 = phi i64 [ %arg0, %ok13.lr.ph ], [ %v359, %native_ref_test.exit18 ]
  %v17 = inttoptr i64 %v28 to ptr
  %v18 = getelementptr i8, ptr %v17, i64 8
  %v19 = load i64, ptr %v18, align 1
  %v21 = icmp eq i64 %v19, %arg1.tr73
  br i1 %v21, label %then26, label %else25

then26:                                           ; preds = %ok16
  %.lcssa260 = phi i64 [ %35, %ok16 ]
  %.lcssa213 = phi ptr [ %36, %ok16 ]
  store ptr %.lcssa213, ptr @native_roots.0, align 8
  %39 = add i64 %.lcssa260, -1
  store i64 %39, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  ret i32 0

else25:                                           ; preds = %ok16
  %40 = and i64 %v28, 1
  %.not.i1 = icmp eq i64 %40, 0
  br i1 %.not.i1, label %41, label %trap31

41:                                               ; preds = %else25
  switch i64 %38, label %42 [
    i64 134, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

42:                                               ; preds = %41
  %43 = getelementptr inbounds nuw i8, ptr %37, i64 360
  %44 = load i64, ptr %43, align 8, !noundef !39
  %45 = lshr i64 %38, 2
  %46 = add nsw i64 %45, -1
  %47 = icmp ult i64 %46, %44
  br i1 %47, label %48, label %.loopexit29

48:                                               ; preds = %42
  %49 = getelementptr inbounds nuw i8, ptr %37, i64 352
  %50 = load ptr, ptr %49, align 8, !nonnull !39, !noundef !39
  %51 = getelementptr inbounds nuw i64, ptr %50, i64 %46
  %52 = load i64, ptr %51, align 8, !noundef !39
  switch i64 %52, label %.preheader28 [
    i64 134, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader28:                                     ; preds = %57, %48
  %53 = phi i64 [ %59, %57 ], [ %52, %48 ]
  %54 = lshr i64 %53, 2
  %55 = add nsw i64 %54, -1
  %56 = icmp ult i64 %55, %44
  br i1 %56, label %57, label %.loopexit29

.loopexit29:                                      ; preds = %.preheader28, %42
  call fastcc void @native_trap() #114
  unreachable

57:                                               ; preds = %.preheader28
  %58 = getelementptr inbounds nuw i64, ptr %50, i64 %55
  %59 = load i64, ptr %58, align 8, !noundef !39
  switch i64 %59, label %.preheader28 [
    i64 134, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

native_ref_test.exit2:                            ; preds = %57, %57, %48, %48, %41, %41
  %.in205 = phi i64 [ %38, %41 ], [ %52, %48 ], [ %52, %48 ], [ %38, %41 ], [ %59, %57 ], [ %59, %57 ]
  %60 = icmp eq i64 %.in205, 134
  br i1 %60, label %ok32, label %trap31

trap31:                                           ; preds = %native_ref_test.exit2, %else25
  call fastcc void @native_trap()
  unreachable

ok32:                                             ; preds = %native_ref_test.exit2
  %v33.b = load i1, ptr @g.29, align 1
  br i1 %v33.b, label %block36, label %then38

then38:                                           ; preds = %ok32
  call fastcc void @native_trap()
  unreachable

block36:                                          ; preds = %ok32
  %v40.b = load i1, ptr @g.21, align 1
  br i1 %v40.b, label %block43, label %then45

then45:                                           ; preds = %block36
  call fastcc void @native_trap()
  unreachable

block43:                                          ; preds = %block36
  %v47 = load i64, ptr @g.20, align 8
  %v48.not = icmp eq i64 %v47, 0
  br i1 %v48.not, label %trap49, label %native_roots_leave.exit3

trap49:                                           ; preds = %block43
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit3:                         ; preds = %block43
  %v54 = load i64, ptr @g.28, align 8
  store i64 4, ptr %1, align 8
  %v2.i = call i64 @benchmark_opaque_hide_i64(i64 %v54)
  %v57.b = load i1, ptr @g.27, align 1
  br i1 %v57.b, label %block60, label %then62

then62:                                           ; preds = %native_roots_leave.exit3
  call fastcc void @native_trap()
  unreachable

block60:                                          ; preds = %native_roots_leave.exit3
  %v64 = load i64, ptr @g.26, align 8
  %v65.not = icmp eq i64 %v64, 0
  br i1 %v65.not, label %trap66, label %ok67

trap66:                                           ; preds = %block60
  call fastcc void @native_trap()
  unreachable

ok67:                                             ; preds = %block60
  store i64 4, ptr %1, align 8
  %61 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %62 = icmp eq ptr %61, null
  br i1 %62, label %63, label %64

63:                                               ; preds = %ok67
  call fastcc void @native_trap() #114
  unreachable

64:                                               ; preds = %ok67
  %65 = getelementptr inbounds nuw i8, ptr %61, i64 376
  %66 = load i64, ptr %65, align 8, !noundef !39
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %68, label %72

68:                                               ; preds = %78, %72, %64
  %69 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %70 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %61, i64 noundef 16, ptr noundef %69) #84
  %71 = icmp eq ptr %70, null
  br i1 %71, label %80, label %ok76

72:                                               ; preds = %64
  %73 = getelementptr inbounds nuw i8, ptr %61, i64 368
  %74 = load i64, ptr %73, align 8, !noundef !39
  %75 = add i64 %74, 1
  store i64 %75, ptr %73, align 8
  %76 = urem i64 %75, %66
  %77 = icmp eq i64 %76, 0
  br i1 %77, label %78, label %68

78:                                               ; preds = %72
  %79 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %61, ptr noundef %79) #84
  br label %68

80:                                               ; preds = %68
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok76:                                             ; preds = %68
  %81 = ptrtoint ptr %70 to i64
  store i64 170, ptr %70, align 1
  %v83 = getelementptr i8, ptr %70, i64 8
  store i64 0, ptr %v83, align 1
  store i64 %81, ptr %v84, align 8
  store i64 5, ptr %1, align 8
  %82 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %83 = icmp eq ptr %82, null
  br i1 %83, label %84, label %85

84:                                               ; preds = %ok76
  call fastcc void @native_trap() #114
  unreachable

85:                                               ; preds = %ok76
  %86 = getelementptr inbounds nuw i8, ptr %82, i64 376
  %87 = load i64, ptr %86, align 8, !noundef !39
  %88 = icmp eq i64 %87, 0
  br i1 %88, label %89, label %93

89:                                               ; preds = %99, %93, %85
  %90 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %91 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %82, i64 noundef 24, ptr noundef %90) #84
  %92 = icmp eq ptr %91, null
  br i1 %92, label %101, label %ok89

93:                                               ; preds = %85
  %94 = getelementptr inbounds nuw i8, ptr %82, i64 368
  %95 = load i64, ptr %94, align 8, !noundef !39
  %96 = add i64 %95, 1
  store i64 %96, ptr %94, align 8
  %97 = urem i64 %96, %87
  %98 = icmp eq i64 %97, 0
  br i1 %98, label %99, label %89

99:                                               ; preds = %93
  %100 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %82, ptr noundef %100) #84
  br label %89

101:                                              ; preds = %89
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok89:                                             ; preds = %89
  %102 = ptrtoint ptr %91 to i64
  store i64 138, ptr %91, align 1
  %v96 = getelementptr i8, ptr %91, i64 8
  store i32 1, ptr %v96, align 1
  %v101 = getelementptr i8, ptr %91, i64 16
  store i64 %81, ptr %v101, align 1
  store i64 %102, ptr %v84, align 8
  store i64 5, ptr %1, align 8
  %103 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %104 = icmp eq ptr %103, null
  br i1 %104, label %105, label %106

105:                                              ; preds = %ok89
  call fastcc void @native_trap() #114
  unreachable

106:                                              ; preds = %ok89
  %107 = getelementptr inbounds nuw i8, ptr %103, i64 376
  %108 = load i64, ptr %107, align 8, !noundef !39
  %109 = icmp eq i64 %108, 0
  br i1 %109, label %110, label %114

110:                                              ; preds = %120, %114, %106
  %111 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %112 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %103, i64 noundef 24, ptr noundef %111) #84
  %113 = icmp eq ptr %112, null
  br i1 %113, label %122, label %ok107

114:                                              ; preds = %106
  %115 = getelementptr inbounds nuw i8, ptr %103, i64 368
  %116 = load i64, ptr %115, align 8, !noundef !39
  %117 = add i64 %116, 1
  store i64 %117, ptr %115, align 8
  %118 = urem i64 %117, %108
  %119 = icmp eq i64 %118, 0
  br i1 %119, label %120, label %110

120:                                              ; preds = %114
  %121 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %103, ptr noundef %121) #84
  br label %110

122:                                              ; preds = %110
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok107:                                            ; preds = %110
  %123 = ptrtoint ptr %112 to i64
  store i64 130, ptr %112, align 1
  %v114 = getelementptr i8, ptr %112, i64 8
  store i64 %v2.i, ptr %v114, align 1
  %v119 = getelementptr i8, ptr %112, i64 16
  store i64 %102, ptr %v119, align 1
  store i64 %123, ptr %v84, align 8
  store i64 5, ptr %1, align 8
  %124 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %125 = icmp eq ptr %124, null
  br i1 %125, label %126, label %127

126:                                              ; preds = %ok107
  call fastcc void @native_trap() #114
  unreachable

127:                                              ; preds = %ok107
  %128 = getelementptr inbounds nuw i8, ptr %124, i64 376
  %129 = load i64, ptr %128, align 8, !noundef !39
  %130 = icmp eq i64 %129, 0
  br i1 %130, label %131, label %135

131:                                              ; preds = %141, %135, %127
  %132 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %133 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %124, i64 noundef 16, ptr noundef %132) #84
  %134 = icmp eq ptr %133, null
  br i1 %134, label %143, label %ok125

135:                                              ; preds = %127
  %136 = getelementptr inbounds nuw i8, ptr %124, i64 368
  %137 = load i64, ptr %136, align 8, !noundef !39
  %138 = add i64 %137, 1
  store i64 %138, ptr %136, align 8
  %139 = urem i64 %138, %129
  %140 = icmp eq i64 %139, 0
  br i1 %140, label %141, label %131

141:                                              ; preds = %135
  %142 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %124, ptr noundef %142) #84
  br label %131

143:                                              ; preds = %131
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok125:                                            ; preds = %131
  %144 = ptrtoint ptr %133 to i64
  store i64 170, ptr %133, align 1
  %v132 = getelementptr i8, ptr %133, i64 8
  store i64 %123, ptr %v132, align 1
  store i64 %144, ptr %v84, align 8
  store i64 5, ptr %1, align 8
  %145 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %146 = icmp eq ptr %145, null
  br i1 %146, label %147, label %148

147:                                              ; preds = %ok125
  call fastcc void @native_trap() #114
  unreachable

148:                                              ; preds = %ok125
  %149 = getelementptr inbounds nuw i8, ptr %145, i64 376
  %150 = load i64, ptr %149, align 8, !noundef !39
  %151 = icmp eq i64 %150, 0
  br i1 %151, label %152, label %156

152:                                              ; preds = %162, %156, %148
  %153 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %154 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %145, i64 noundef 24, ptr noundef %153) #84
  %155 = icmp eq ptr %154, null
  br i1 %155, label %164, label %ok138

156:                                              ; preds = %148
  %157 = getelementptr inbounds nuw i8, ptr %145, i64 368
  %158 = load i64, ptr %157, align 8, !noundef !39
  %159 = add i64 %158, 1
  store i64 %159, ptr %157, align 8
  %160 = urem i64 %159, %150
  %161 = icmp eq i64 %160, 0
  br i1 %161, label %162, label %152

162:                                              ; preds = %156
  %163 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %145, ptr noundef %163) #84
  br label %152

164:                                              ; preds = %152
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok138:                                            ; preds = %152
  %165 = ptrtoint ptr %154 to i64
  store i64 138, ptr %154, align 1
  %v145 = getelementptr i8, ptr %154, i64 8
  store i32 1, ptr %v145, align 1
  %v150 = getelementptr i8, ptr %154, i64 16
  store i64 %144, ptr %v150, align 1
  store i64 %165, ptr %v5, align 8
  %v151.b = load i1, ptr @g.15, align 1
  br i1 %v151.b, label %block154, label %then156

then156:                                          ; preds = %ok138
  call fastcc void @native_trap()
  unreachable

block154:                                         ; preds = %ok138
  %v158 = load i64, ptr @g.14, align 8
  %v159.not = icmp eq i64 %v158, 0
  br i1 %v159.not, label %trap160, label %ok161

trap160:                                          ; preds = %block154
  call fastcc void @native_trap()
  unreachable

ok161:                                            ; preds = %block154
  store i64 4, ptr %1, align 8
  %166 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %167 = icmp eq ptr %166, null
  br i1 %167, label %168, label %169

168:                                              ; preds = %ok161
  call fastcc void @native_trap() #114
  unreachable

169:                                              ; preds = %ok161
  %170 = getelementptr inbounds nuw i8, ptr %166, i64 376
  %171 = load i64, ptr %170, align 8, !noundef !39
  %172 = icmp eq i64 %171, 0
  br i1 %172, label %173, label %177

173:                                              ; preds = %183, %177, %169
  %174 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %175 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %166, i64 noundef 24, ptr noundef %174) #84
  %176 = icmp eq ptr %175, null
  br i1 %176, label %185, label %ok169

177:                                              ; preds = %169
  %178 = getelementptr inbounds nuw i8, ptr %166, i64 368
  %179 = load i64, ptr %178, align 8, !noundef !39
  %180 = add i64 %179, 1
  store i64 %180, ptr %178, align 8
  %181 = urem i64 %180, %171
  %182 = icmp eq i64 %181, 0
  br i1 %182, label %183, label %173

183:                                              ; preds = %177
  %184 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %166, ptr noundef %184) #84
  br label %173

185:                                              ; preds = %173
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok169:                                            ; preds = %173
  %186 = ptrtoint ptr %175 to i64
  store i64 142, ptr %175, align 1
  %v176 = getelementptr i8, ptr %175, i64 8
  store i32 0, ptr %v176, align 1
  %v181 = getelementptr i8, ptr %175, i64 16
  store i64 0, ptr %v181, align 1
  store i64 %186, ptr %v4, align 8
  store i64 %186, ptr %v84, align 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v184, align 8
  store i64 %186, ptr %v185, align 8
  store i64 7, ptr %1, align 8
  %187 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %188 = icmp eq ptr %187, null
  br i1 %188, label %189, label %190

189:                                              ; preds = %ok169
  call fastcc void @native_trap() #114
  unreachable

190:                                              ; preds = %ok169
  %191 = getelementptr inbounds nuw i8, ptr %187, i64 376
  %192 = load i64, ptr %191, align 8, !noundef !39
  %193 = icmp eq i64 %192, 0
  br i1 %193, label %194, label %198

194:                                              ; preds = %204, %198, %190
  %195 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %196 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %187, i64 noundef 16, ptr noundef %195) #84
  %197 = icmp eq ptr %196, null
  br i1 %197, label %206, label %ok190

198:                                              ; preds = %190
  %199 = getelementptr inbounds nuw i8, ptr %187, i64 368
  %200 = load i64, ptr %199, align 8, !noundef !39
  %201 = add i64 %200, 1
  store i64 %201, ptr %199, align 8
  %202 = urem i64 %201, %192
  %203 = icmp eq i64 %202, 0
  br i1 %203, label %204, label %194

204:                                              ; preds = %198
  %205 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %187, ptr noundef %205) #84
  br label %194

206:                                              ; preds = %194
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok190:                                            ; preds = %194
  %207 = ptrtoint ptr %196 to i64
  store i64 126, ptr %196, align 1
  %v197 = getelementptr i8, ptr %196, i64 8
  store i64 %186, ptr %v197, align 1
  store i64 %207, ptr %v84, align 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v184, align 8
  store i64 %186, ptr %v185, align 8
  store i64 7, ptr %1, align 8
  %208 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %209 = icmp eq ptr %208, null
  br i1 %209, label %210, label %211

210:                                              ; preds = %ok190
  call fastcc void @native_trap() #114
  unreachable

211:                                              ; preds = %ok190
  %212 = getelementptr inbounds nuw i8, ptr %208, i64 376
  %213 = load i64, ptr %212, align 8, !noundef !39
  %214 = icmp eq i64 %213, 0
  br i1 %214, label %215, label %219

215:                                              ; preds = %225, %219, %211
  %216 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %217 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %208, i64 noundef 24, ptr noundef %216) #84
  %218 = icmp eq ptr %217, null
  br i1 %218, label %227, label %ok205

219:                                              ; preds = %211
  %220 = getelementptr inbounds nuw i8, ptr %208, i64 368
  %221 = load i64, ptr %220, align 8, !noundef !39
  %222 = add i64 %221, 1
  store i64 %222, ptr %220, align 8
  %223 = urem i64 %222, %213
  %224 = icmp eq i64 %223, 0
  br i1 %224, label %225, label %215

225:                                              ; preds = %219
  %226 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %208, ptr noundef %226) #84
  br label %215

227:                                              ; preds = %215
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok205:                                            ; preds = %215
  %228 = ptrtoint ptr %217 to i64
  store i64 166, ptr %217, align 1
  %v212 = getelementptr i8, ptr %217, i64 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v212, align 1
  %v217 = getelementptr i8, ptr %217, i64 16
  store i64 %207, ptr %v217, align 1
  store i64 %228, ptr %v181, align 1
  %v223 = load i64, ptr %v4, align 8
  %v224.not = icmp eq i64 %v223, 0
  br i1 %v224.not, label %trap225, label %ok226

trap225:                                          ; preds = %ok205
  call fastcc void @native_trap()
  unreachable

ok226:                                            ; preds = %ok205
  %v227 = inttoptr i64 %v223 to ptr
  %v228 = getelementptr i8, ptr %v227, i64 8
  store i32 1, ptr %v228, align 1
  %v229 = load i64, ptr %v4, align 8
  %v230.not = icmp eq i64 %v229, 0
  br i1 %v230.not, label %trap231, label %ok232

trap231:                                          ; preds = %ok226
  call fastcc void @native_trap()
  unreachable

ok232:                                            ; preds = %ok226
  %v233 = inttoptr i64 %v229 to ptr
  %v234 = getelementptr i8, ptr %v233, i64 8
  %v235 = load i32, ptr %v234, align 1
  %v236 = icmp eq i32 %v235, 0
  br i1 %v236, label %then240, label %block238

then240:                                          ; preds = %ok232
  call fastcc void @native_trap()
  unreachable

block238:                                         ; preds = %ok232
  %v244 = add i64 %v2.i, -2
  %v250 = getelementptr i8, ptr %v233, i64 16
  %v251 = load i64, ptr %v250, align 1
  %v252.not = icmp eq i64 %v251, 0
  br i1 %v252.not, label %trap253, label %ok254

trap253:                                          ; preds = %block238
  call fastcc void @native_trap()
  unreachable

ok254:                                            ; preds = %block238
  store i64 %v251, ptr %v6, align 8
  %v258 = inttoptr i64 %v251 to ptr
  %v268 = getelementptr i8, ptr %v258, i64 8
  %v269 = load i64, ptr %v268, align 1
  %v270.not = icmp eq i64 %v269, 0
  br i1 %v270.not, label %trap271, label %ok272

trap271:                                          ; preds = %ok254
  call fastcc void @native_trap()
  unreachable

ok272:                                            ; preds = %ok254
  %v262 = add i64 %v2.i, -1
  %v259 = getelementptr i8, ptr %v258, i64 16
  %v260 = load i64, ptr %v259, align 1
  %v273 = inttoptr i64 %v269 to ptr
  %v274 = getelementptr i8, ptr %v273, i64 8
  %v275 = load ptr, ptr %v274, align 1
  store i64 %v260, ptr %v84, align 8
  store i64 5, ptr %1, align 8
  %v278 = call tailcc i64 %v275(i64 %v260, i64 %v262, i64 1)
  %v282 = load i64, ptr %v5, align 8
  store i64 %v282, ptr %v84, align 8
  store i64 5, ptr %1, align 8
  %229 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %230 = icmp eq ptr %229, null
  br i1 %230, label %231, label %232

231:                                              ; preds = %ok272
  call fastcc void @native_trap() #114
  unreachable

232:                                              ; preds = %ok272
  %233 = getelementptr inbounds nuw i8, ptr %229, i64 376
  %234 = load i64, ptr %233, align 8, !noundef !39
  %235 = icmp eq i64 %234, 0
  br i1 %235, label %236, label %240

236:                                              ; preds = %246, %240, %232
  %237 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %238 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %229, i64 noundef 40, ptr noundef %237) #84
  %239 = icmp eq ptr %238, null
  br i1 %239, label %248, label %ok288

240:                                              ; preds = %232
  %241 = getelementptr inbounds nuw i8, ptr %229, i64 368
  %242 = load i64, ptr %241, align 8, !noundef !39
  %243 = add i64 %242, 1
  store i64 %243, ptr %241, align 8
  %244 = urem i64 %243, %234
  %245 = icmp eq i64 %244, 0
  br i1 %245, label %246, label %236

246:                                              ; preds = %240
  %247 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %229, ptr noundef %247) #84
  br label %236

248:                                              ; preds = %236
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok288:                                            ; preds = %236
  %249 = ptrtoint ptr %238 to i64
  %v279 = shl i64 %v278, 2
  %v281 = add i64 %v279, -4
  store i64 118, ptr %238, align 1
  %v295 = getelementptr i8, ptr %238, i64 8
  store i64 %v2.i, ptr %v295, align 1
  %v300 = getelementptr i8, ptr %238, i64 16
  store i64 %v244, ptr %v300, align 1
  %v305 = getelementptr i8, ptr %238, i64 24
  store i64 %v281, ptr %v305, align 1
  %v310 = getelementptr i8, ptr %238, i64 32
  store i64 %v282, ptr %v310, align 1
  store i64 %249, ptr %v84, align 8
  store i64 5, ptr %1, align 8
  call tailcc void @f.8(i64 %249)
  %v314 = load i64, ptr %v1, align 8
  %250 = icmp ne i64 %v314, 0
  %251 = and i64 %v314, 1
  %.not.i12 = icmp eq i64 %251, 0
  %or.cond159 = and i1 %250, %.not.i12
  br i1 %or.cond159, label %252, label %trap317

252:                                              ; preds = %ok288
  %253 = inttoptr i64 %v314 to ptr
  %254 = load i64, ptr %253, align 8, !noundef !39
  %255 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %256 = icmp eq ptr %255, null
  br i1 %256, label %271, label %257

257:                                              ; preds = %252
  %258 = icmp eq i64 %254, 134
  switch i64 %254, label %259 [
    i64 134, label %native_ref_test.exit13
    i64 0, label %native_ref_test.exit13
  ]

259:                                              ; preds = %257
  %260 = getelementptr inbounds nuw i8, ptr %255, i64 360
  %261 = load i64, ptr %260, align 8, !noundef !39
  %262 = lshr i64 %254, 2
  %263 = add nsw i64 %262, -1
  %264 = icmp ult i64 %263, %261
  br i1 %264, label %265, label %.loopexit27

265:                                              ; preds = %259
  %266 = getelementptr inbounds nuw i8, ptr %255, i64 352
  %267 = load ptr, ptr %266, align 8, !nonnull !39, !noundef !39
  %268 = getelementptr inbounds nuw i64, ptr %267, i64 %263
  %269 = load i64, ptr %268, align 8, !noundef !39
  %270 = icmp eq i64 %269, 134
  switch i64 %269, label %.preheader26 [
    i64 134, label %native_ref_test.exit13
    i64 0, label %native_ref_test.exit13
  ]

271:                                              ; preds = %252
  call fastcc void @native_trap() #114
  unreachable

.preheader26:                                     ; preds = %276, %265
  %272 = phi i64 [ %278, %276 ], [ %269, %265 ]
  %273 = lshr i64 %272, 2
  %274 = add nsw i64 %273, -1
  %275 = icmp ult i64 %274, %261
  br i1 %275, label %276, label %.loopexit27

.loopexit27:                                      ; preds = %.preheader26, %259
  call fastcc void @native_trap() #114
  unreachable

276:                                              ; preds = %.preheader26
  %277 = getelementptr inbounds nuw i64, ptr %267, i64 %274
  %278 = load i64, ptr %277, align 8, !noundef !39
  switch i64 %278, label %.preheader26 [
    i64 134, label %native_ref_test.exit13.loopexit
    i64 0, label %native_ref_test.exit13.loopexit
  ]

native_ref_test.exit13.loopexit:                  ; preds = %276, %276
  %.lcssa308 = phi i64 [ %278, %276 ], [ %278, %276 ]
  %279 = icmp eq i64 %.lcssa308, 134
  br i1 %279, label %ok321, label %trap317

native_ref_test.exit13:                           ; preds = %265, %265, %257, %257
  %280 = phi i1 [ %258, %257 ], [ %270, %265 ], [ %270, %265 ], [ %258, %257 ]
  br i1 %280, label %ok321, label %trap317

trap317:                                          ; preds = %native_ref_test.exit13, %native_ref_test.exit13.loopexit, %ok288
  call fastcc void @native_trap()
  unreachable

ok321:                                            ; preds = %native_ref_test.exit13, %native_ref_test.exit13.loopexit
  %v323 = getelementptr i8, ptr %253, i64 16
  %v324 = load i64, ptr %v323, align 1
  %v325.not = icmp eq i64 %v324, 0
  br i1 %v325.not, label %trap326, label %ok327

trap326:                                          ; preds = %ok321
  call fastcc void @native_trap()
  unreachable

ok327:                                            ; preds = %ok321
  %v328 = inttoptr i64 %v324 to ptr
  %v329 = getelementptr i8, ptr %v328, i64 8
  %v330 = load i32, ptr %v329, align 1
  %v331 = icmp eq i32 %v330, 0
  br i1 %v331, label %then335, label %block333

then335:                                          ; preds = %ok327
  call fastcc void @native_trap()
  unreachable

block333:                                         ; preds = %ok327
  switch i64 %254, label %281 [
    i64 134, label %native_ref_test.exit15
    i64 0, label %native_ref_test.exit15
  ]

281:                                              ; preds = %block333
  %282 = getelementptr inbounds nuw i8, ptr %255, i64 360
  %283 = load i64, ptr %282, align 8, !noundef !39
  %284 = lshr i64 %254, 2
  %285 = add nsw i64 %284, -1
  %286 = icmp ult i64 %285, %283
  br i1 %286, label %287, label %.loopexit25

287:                                              ; preds = %281
  %288 = getelementptr inbounds nuw i8, ptr %255, i64 352
  %289 = load ptr, ptr %288, align 8, !nonnull !39, !noundef !39
  %290 = getelementptr inbounds nuw i64, ptr %289, i64 %285
  %291 = load i64, ptr %290, align 8, !noundef !39
  %292 = icmp eq i64 %291, 134
  switch i64 %291, label %.preheader24 [
    i64 134, label %native_ref_test.exit15
    i64 0, label %native_ref_test.exit15
  ]

.preheader24:                                     ; preds = %297, %287
  %293 = phi i64 [ %299, %297 ], [ %291, %287 ]
  %294 = lshr i64 %293, 2
  %295 = add nsw i64 %294, -1
  %296 = icmp ult i64 %295, %283
  br i1 %296, label %297, label %.loopexit25

.loopexit25:                                      ; preds = %.preheader24, %281
  call fastcc void @native_trap() #114
  unreachable

297:                                              ; preds = %.preheader24
  %298 = getelementptr inbounds nuw i64, ptr %289, i64 %295
  %299 = load i64, ptr %298, align 8, !noundef !39
  switch i64 %299, label %.preheader24 [
    i64 134, label %native_ref_test.exit15.loopexit
    i64 0, label %native_ref_test.exit15.loopexit
  ]

native_ref_test.exit15.loopexit:                  ; preds = %297, %297
  %.lcssa309 = phi i64 [ %299, %297 ], [ %299, %297 ]
  %300 = icmp eq i64 %.lcssa309, 134
  br i1 %300, label %ok350, label %trap340

native_ref_test.exit15:                           ; preds = %287, %287, %block333, %block333
  %301 = phi i1 [ %258, %block333 ], [ %292, %287 ], [ %292, %287 ], [ %258, %block333 ]
  br i1 %301, label %ok350, label %trap340

trap340:                                          ; preds = %native_ref_test.exit15, %native_ref_test.exit15.loopexit
  call fastcc void @native_trap()
  unreachable

ok350:                                            ; preds = %native_ref_test.exit15, %native_ref_test.exit15.loopexit
  %v352 = getelementptr i8, ptr %v328, i64 16
  %v353 = load i64, ptr %v352, align 1
  %v354.not = icmp eq i64 %v353, 0
  br i1 %v354.not, label %trap355, label %ok356

trap355:                                          ; preds = %ok350
  call fastcc void @native_trap()
  unreachable

ok356:                                            ; preds = %ok350
  %v357 = inttoptr i64 %v353 to ptr
  %v358 = getelementptr i8, ptr %v357, i64 16
  %v359 = load i64, ptr %v358, align 1
  %v361 = add i64 %arg1.tr73, 1
  %302 = load i64, ptr %0, align 8, !noundef !39
  %303 = icmp eq i64 %302, 0
  %.pre40 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %304 = zext i1 %303 to i64
  %305 = add i64 %.pre40, %304
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %306 = select i1 %303, ptr %native_roots.0.val, ptr %roots.val
  store i64 7, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %306, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %305, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %307 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %308 = call noundef i64 @llvm.umax.i64(i64 %305, i64 %307)
  store i64 %308, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  store i64 %v359, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  %309 = icmp ne i64 %v359, 0
  %310 = and i64 %v359, 1
  %.not.i17 = icmp eq i64 %310, 0
  %or.cond160 = and i1 %309, %.not.i17
  br i1 %or.cond160, label %311, label %trap12

311:                                              ; preds = %ok356
  %312 = inttoptr i64 %v359 to ptr
  %313 = load i64, ptr %312, align 8, !noundef !39
  switch i64 %313, label %314 [
    i64 134, label %native_ref_test.exit18
    i64 0, label %native_ref_test.exit18
  ]

314:                                              ; preds = %311
  %315 = getelementptr inbounds nuw i8, ptr %255, i64 360
  %316 = load i64, ptr %315, align 8, !noundef !39
  %317 = lshr i64 %313, 2
  %318 = add nsw i64 %317, -1
  %319 = icmp ult i64 %318, %316
  br i1 %319, label %320, label %.loopexit

320:                                              ; preds = %314
  %321 = getelementptr inbounds nuw i8, ptr %255, i64 352
  %322 = load ptr, ptr %321, align 8, !nonnull !39, !noundef !39
  %323 = getelementptr inbounds nuw i64, ptr %322, i64 %318
  %324 = load i64, ptr %323, align 8, !noundef !39
  switch i64 %324, label %.preheader [
    i64 134, label %native_ref_test.exit18
    i64 0, label %native_ref_test.exit18
  ]

.preheader:                                       ; preds = %329, %320
  %325 = phi i64 [ %331, %329 ], [ %324, %320 ]
  %326 = lshr i64 %325, 2
  %327 = add nsw i64 %326, -1
  %328 = icmp ult i64 %327, %316
  br i1 %328, label %329, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %314
  call fastcc void @native_trap() #114
  unreachable

329:                                              ; preds = %.preheader
  %330 = getelementptr inbounds nuw i64, ptr %322, i64 %327
  %331 = load i64, ptr %330, align 8, !noundef !39
  switch i64 %331, label %.preheader [
    i64 134, label %native_ref_test.exit18
    i64 0, label %native_ref_test.exit18
  ]

native_ref_test.exit18:                           ; preds = %329, %329, %320, %320, %311, %311
  %.in = phi i64 [ %313, %311 ], [ %324, %320 ], [ %324, %320 ], [ %313, %311 ], [ %331, %329 ], [ %331, %329 ]
  %332 = icmp eq i64 %.in, 134
  br i1 %332, label %ok16, label %trap12
}
