define internal tailcc noundef i64 @f.17(i64 %arg0, i64 %arg1) unnamed_addr #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [6 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 6, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v9.not = icmp eq i64 %arg0, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  br i1 %v9.not, label %trap10, label %ok11

trap10:                                           ; preds = %entry
  call fastcc void @native_trap()
  unreachable

ok11:                                             ; preds = %entry
  %v12 = inttoptr i64 %arg0 to ptr
  %v13 = getelementptr i8, ptr %v12, i64 8
  %v14 = load i64, ptr %v13, align 1
  %v29.b = load i1, ptr @g.15, align 1
  br i1 %v29.b, label %block32, label %then34

then34:                                           ; preds = %ok11
  call fastcc void @native_trap()
  unreachable

block32:                                          ; preds = %ok11
  %v36 = load i64, ptr @g.14, align 8
  %v37.not = icmp eq i64 %v36, 0
  br i1 %v37.not, label %trap38, label %ok39

trap38:                                           ; preds = %block32
  call fastcc void @native_trap()
  unreachable

ok39:                                             ; preds = %block32
  store i64 3, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %ok39
  call fastcc void @native_trap() #114
  unreachable

10:                                               ; preds = %ok39
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = phi ptr [ %.pre, %24 ], [ %roots, %18 ], [ %roots, %10 ]
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 24, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %25, label %ok47

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %14

25:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok47:                                             ; preds = %14
  %26 = ptrtoint ptr %16 to i64
  store i64 142, ptr %16, align 1
  %v54 = getelementptr i8, ptr %16, i64 8
  store i32 0, ptr %v54, align 1
  %v59 = getelementptr i8, ptr %16, i64 16
  store i64 0, ptr %v59, align 1
  store i64 %26, ptr %v3, align 8
  %v61 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 %26, ptr %v61, align 8
  %v62 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v62, align 8
  %v63 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %26, ptr %v63, align 8
  store i64 6, ptr %1, align 8
  %27 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %28 = icmp eq ptr %27, null
  br i1 %28, label %29, label %30

29:                                               ; preds = %ok47
  call fastcc void @native_trap() #114
  unreachable

30:                                               ; preds = %ok47
  %31 = getelementptr inbounds nuw i8, ptr %27, i64 376
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %34, label %38

34:                                               ; preds = %44, %38, %30
  %35 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %36 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %27, i64 noundef 16, ptr noundef %35) #84
  %37 = icmp eq ptr %36, null
  br i1 %37, label %46, label %ok68

38:                                               ; preds = %30
  %39 = getelementptr inbounds nuw i8, ptr %27, i64 368
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = add i64 %40, 1
  store i64 %41, ptr %39, align 8
  %42 = urem i64 %41, %32
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %44, label %34

44:                                               ; preds = %38
  %45 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %27, ptr noundef %45) #84
  br label %34

46:                                               ; preds = %34
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok68:                                             ; preds = %34
  %47 = ptrtoint ptr %36 to i64
  store i64 126, ptr %36, align 1
  %v75 = getelementptr i8, ptr %36, i64 8
  store i64 %26, ptr %v75, align 1
  store i64 %47, ptr %v61, align 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v62, align 8
  store i64 %26, ptr %v63, align 8
  store i64 6, ptr %1, align 8
  %48 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %ok68
  call fastcc void @native_trap() #114
  unreachable

51:                                               ; preds = %ok68
  %52 = getelementptr inbounds nuw i8, ptr %48, i64 376
  %53 = load i64, ptr %52, align 8, !noundef !39
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %55, label %59

55:                                               ; preds = %65, %59, %51
  %56 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %57 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %48, i64 noundef 24, ptr noundef %56) #84
  %58 = icmp eq ptr %57, null
  br i1 %58, label %67, label %ok83

59:                                               ; preds = %51
  %60 = getelementptr inbounds nuw i8, ptr %48, i64 368
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = add i64 %61, 1
  store i64 %62, ptr %60, align 8
  %63 = urem i64 %62, %53
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %65, label %55

65:                                               ; preds = %59
  %66 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %48, ptr noundef %66) #84
  br label %55

67:                                               ; preds = %55
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok83:                                             ; preds = %55
  %68 = ptrtoint ptr %57 to i64
  store i64 166, ptr %57, align 1
  %v90 = getelementptr i8, ptr %57, i64 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v90, align 1
  %v95 = getelementptr i8, ptr %57, i64 16
  store i64 %47, ptr %v95, align 1
  store i64 %68, ptr %v59, align 1
  %v101 = load i64, ptr %v3, align 8
  %v102.not = icmp eq i64 %v101, 0
  br i1 %v102.not, label %trap103, label %ok104

trap103:                                          ; preds = %ok83
  call fastcc void @native_trap()
  unreachable

ok104:                                            ; preds = %ok83
  %v105 = inttoptr i64 %v101 to ptr
  %v106 = getelementptr i8, ptr %v105, i64 8
  store i32 1, ptr %v106, align 1
  %v107 = load i64, ptr %v3, align 8
  %v108.not = icmp eq i64 %v107, 0
  br i1 %v108.not, label %trap109, label %ok110

trap109:                                          ; preds = %ok104
  call fastcc void @native_trap()
  unreachable

ok110:                                            ; preds = %ok104
  %v111 = inttoptr i64 %v107 to ptr
  %v112 = getelementptr i8, ptr %v111, i64 8
  %v113 = load i32, ptr %v112, align 1
  %v114 = icmp eq i32 %v113, 0
  br i1 %v114, label %then118, label %ok123

then118:                                          ; preds = %ok110
  call fastcc void @native_trap()
  unreachable

ok123:                                            ; preds = %ok110
  %v125 = getelementptr i8, ptr %v111, i64 16
  %v126 = load i64, ptr %v125, align 1
  %v127.not = icmp eq i64 %v126, 0
  br i1 %v127.not, label %trap128, label %ok129

trap128:                                          ; preds = %ok123
  call fastcc void @native_trap()
  unreachable

ok129:                                            ; preds = %ok123
  store i64 %v126, ptr %v4, align 8
  %v133 = inttoptr i64 %v126 to ptr
  %v143 = getelementptr i8, ptr %v133, i64 8
  %v144 = load i64, ptr %v143, align 1
  %v145.not = icmp eq i64 %v144, 0
  br i1 %v145.not, label %trap146, label %ok147

trap146:                                          ; preds = %ok129
  call fastcc void @native_trap()
  unreachable

ok147:                                            ; preds = %ok129
  %v137 = add i64 %v14, 1
  %v134 = getelementptr i8, ptr %v133, i64 16
  %v135 = load i64, ptr %v134, align 1
  %v148 = inttoptr i64 %v144 to ptr
  %v149 = getelementptr i8, ptr %v148, i64 8
  %v150 = load ptr, ptr %v149, align 1
  store i64 %v135, ptr %v61, align 8
  store i64 4, ptr %1, align 8
  %v153 = call tailcc i64 %v150(i64 %v135, i64 %v137, i64 1)
  %v157 = load i64, ptr %v1, align 8
  %v158.not = icmp eq i64 %v157, 0
  br i1 %v158.not, label %trap159, label %ok160

trap159:                                          ; preds = %ok147
  call fastcc void @native_trap()
  unreachable

ok160:                                            ; preds = %ok147
  %v164.b = load i1, ptr @g.15, align 1
  br i1 %v164.b, label %block167, label %then169

then169:                                          ; preds = %ok160
  call fastcc void @native_trap()
  unreachable

block167:                                         ; preds = %ok160
  %v171 = load i64, ptr @g.14, align 8
  %v172.not = icmp eq i64 %v171, 0
  br i1 %v172.not, label %trap173, label %ok174

trap173:                                          ; preds = %block167
  call fastcc void @native_trap()
  unreachable

ok174:                                            ; preds = %block167
  store i64 3, ptr %1, align 8
  %69 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %70 = icmp eq ptr %69, null
  br i1 %70, label %71, label %72

71:                                               ; preds = %ok174
  call fastcc void @native_trap() #114
  unreachable

72:                                               ; preds = %ok174
  %73 = getelementptr inbounds nuw i8, ptr %69, i64 376
  %74 = load i64, ptr %73, align 8, !noundef !39
  %75 = icmp eq i64 %74, 0
  br i1 %75, label %76, label %80

76:                                               ; preds = %86, %80, %72
  %77 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %78 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %69, i64 noundef 24, ptr noundef %77) #84
  %79 = icmp eq ptr %78, null
  br i1 %79, label %88, label %ok182

80:                                               ; preds = %72
  %81 = getelementptr inbounds nuw i8, ptr %69, i64 368
  %82 = load i64, ptr %81, align 8, !noundef !39
  %83 = add i64 %82, 1
  store i64 %83, ptr %81, align 8
  %84 = urem i64 %83, %74
  %85 = icmp eq i64 %84, 0
  br i1 %85, label %86, label %76

86:                                               ; preds = %80
  %87 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %69, ptr noundef %87) #84
  br label %76

88:                                               ; preds = %76
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok182:                                            ; preds = %76
  %89 = ptrtoint ptr %78 to i64
  store i64 142, ptr %78, align 1
  %v189 = getelementptr i8, ptr %78, i64 8
  store i32 0, ptr %v189, align 1
  %v194 = getelementptr i8, ptr %78, i64 16
  store i64 0, ptr %v194, align 1
  store i64 %89, ptr %v3, align 8
  store i64 %89, ptr %v61, align 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v62, align 8
  store i64 %89, ptr %v63, align 8
  store i64 6, ptr %1, align 8
  %90 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %91 = icmp eq ptr %90, null
  br i1 %91, label %92, label %93

92:                                               ; preds = %ok182
  call fastcc void @native_trap() #114
  unreachable

93:                                               ; preds = %ok182
  %94 = getelementptr inbounds nuw i8, ptr %90, i64 376
  %95 = load i64, ptr %94, align 8, !noundef !39
  %96 = icmp eq i64 %95, 0
  br i1 %96, label %97, label %101

97:                                               ; preds = %107, %101, %93
  %98 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %99 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %90, i64 noundef 16, ptr noundef %98) #84
  %100 = icmp eq ptr %99, null
  br i1 %100, label %109, label %ok203

101:                                              ; preds = %93
  %102 = getelementptr inbounds nuw i8, ptr %90, i64 368
  %103 = load i64, ptr %102, align 8, !noundef !39
  %104 = add i64 %103, 1
  store i64 %104, ptr %102, align 8
  %105 = urem i64 %104, %95
  %106 = icmp eq i64 %105, 0
  br i1 %106, label %107, label %97

107:                                              ; preds = %101
  %108 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %90, ptr noundef %108) #84
  br label %97

109:                                              ; preds = %97
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok203:                                            ; preds = %97
  %110 = ptrtoint ptr %99 to i64
  store i64 126, ptr %99, align 1
  %v210 = getelementptr i8, ptr %99, i64 8
  store i64 %89, ptr %v210, align 1
  store i64 %110, ptr %v61, align 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v62, align 8
  store i64 %89, ptr %v63, align 8
  store i64 6, ptr %1, align 8
  %111 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %112 = icmp eq ptr %111, null
  br i1 %112, label %113, label %114

113:                                              ; preds = %ok203
  call fastcc void @native_trap() #114
  unreachable

114:                                              ; preds = %ok203
  %115 = getelementptr inbounds nuw i8, ptr %111, i64 376
  %116 = load i64, ptr %115, align 8, !noundef !39
  %117 = icmp eq i64 %116, 0
  br i1 %117, label %118, label %122

118:                                              ; preds = %128, %122, %114
  %119 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %120 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %111, i64 noundef 24, ptr noundef %119) #84
  %121 = icmp eq ptr %120, null
  br i1 %121, label %130, label %ok218

122:                                              ; preds = %114
  %123 = getelementptr inbounds nuw i8, ptr %111, i64 368
  %124 = load i64, ptr %123, align 8, !noundef !39
  %125 = add i64 %124, 1
  store i64 %125, ptr %123, align 8
  %126 = urem i64 %125, %116
  %127 = icmp eq i64 %126, 0
  br i1 %127, label %128, label %118

128:                                              ; preds = %122
  %129 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %111, ptr noundef %129) #84
  br label %118

130:                                              ; preds = %118
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok218:                                            ; preds = %118
  %131 = ptrtoint ptr %120 to i64
  store i64 166, ptr %120, align 1
  %v225 = getelementptr i8, ptr %120, i64 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v225, align 1
  %v230 = getelementptr i8, ptr %120, i64 16
  store i64 %110, ptr %v230, align 1
  store i64 %131, ptr %v194, align 1
  %v236 = load i64, ptr %v3, align 8
  %v237.not = icmp eq i64 %v236, 0
  br i1 %v237.not, label %trap238, label %ok239

trap238:                                          ; preds = %ok218
  call fastcc void @native_trap()
  unreachable

ok239:                                            ; preds = %ok218
  %v240 = inttoptr i64 %v236 to ptr
  %v241 = getelementptr i8, ptr %v240, i64 8
  store i32 1, ptr %v241, align 1
  %v242 = load i64, ptr %v3, align 8
  %v243.not = icmp eq i64 %v242, 0
  br i1 %v243.not, label %trap244, label %ok245

trap244:                                          ; preds = %ok239
  call fastcc void @native_trap()
  unreachable

ok245:                                            ; preds = %ok239
  %v246 = inttoptr i64 %v242 to ptr
  %v247 = getelementptr i8, ptr %v246, i64 8
  %v248 = load i32, ptr %v247, align 1
  %v249 = icmp eq i32 %v248, 0
  br i1 %v249, label %then253, label %ok261

then253:                                          ; preds = %ok245
  call fastcc void @native_trap()
  unreachable

ok261:                                            ; preds = %ok245
  %v263 = getelementptr i8, ptr %v246, i64 16
  %v264 = load i64, ptr %v263, align 1
  %v265.not = icmp eq i64 %v264, 0
  br i1 %v265.not, label %trap266, label %ok267

trap266:                                          ; preds = %ok261
  call fastcc void @native_trap()
  unreachable

ok267:                                            ; preds = %ok261
  store i64 %v264, ptr %v4, align 8
  %v271 = inttoptr i64 %v264 to ptr
  %v281 = getelementptr i8, ptr %v271, i64 8
  %v282 = load i64, ptr %v281, align 1
  %v283.not = icmp eq i64 %v282, 0
  br i1 %v283.not, label %trap284, label %ok285

trap284:                                          ; preds = %ok267
  call fastcc void @native_trap()
  unreachable

ok285:                                            ; preds = %ok267
  %v272 = getelementptr i8, ptr %v271, i64 16
  %v273 = load i64, ptr %v272, align 1
  %v275 = add i64 %arg1, 1
  %v154 = shl i64 %v153, 1
  %v257 = add i64 %v154, -2
  %v286 = inttoptr i64 %v282 to ptr
  %v287 = getelementptr i8, ptr %v286, i64 8
  %v288 = load ptr, ptr %v287, align 1
  store i64 %v273, ptr %v61, align 8
  store i64 4, ptr %1, align 8
  %v291 = call tailcc i64 %v288(i64 %v273, i64 %v275, i64 1)
  %v292 = add i64 %v291, -1
  %132 = icmp eq i64 %v292, 0
  br i1 %132, label %133, label %134, !prof !2126

133:                                              ; preds = %134, %ok285
  call fastcc void @native_trap() #114
  unreachable

134:                                              ; preds = %ok285
  %135 = icmp eq i64 %v257, -9223372036854775808
  %136 = icmp eq i64 %v291, 0
  %137 = and i1 %135, %136
  br i1 %137, label %133, label %native_i64_div_s.exit, !prof !68276

native_i64_div_s.exit:                            ; preds = %134
  %138 = load i64, ptr %0, align 8, !noundef !39
  %139 = icmp eq i64 %138, 0
  br i1 %139, label %native_roots_leave.exit, label %140

140:                                              ; preds = %native_i64_div_s.exit
  %141 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %141, ptr @native_roots.0, align 8
  %142 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %143 = add i64 %142, -1
  store i64 %143, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %140, %native_i64_div_s.exit
  %144 = sdiv i64 %v257, %v292
  ret i64 %144
}
