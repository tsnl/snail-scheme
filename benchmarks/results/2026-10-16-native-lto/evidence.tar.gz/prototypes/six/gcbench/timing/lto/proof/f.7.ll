define internal tailcc noundef i32 @f.7(i64 %arg0, i64 %arg1) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [7 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 7, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v3, i8 0, i64 24, i1 false)
  store i64 4, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %entry
  call fastcc void @native_trap() #114
  unreachable

10:                                               ; preds = %entry
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = phi ptr [ %.pre, %24 ], [ %roots, %18 ], [ %roots, %10 ]
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 16, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %25, label %ok12

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %14

25:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok12:                                             ; preds = %14
  %26 = ptrtoint ptr %16 to i64
  store i64 170, ptr %16, align 1
  %v19 = getelementptr i8, ptr %16, i64 8
  store i64 0, ptr %v19, align 1
  %v20 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 %26, ptr %v20, align 8
  store i64 5, ptr %1, align 8
  %27 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %28 = icmp eq ptr %27, null
  br i1 %28, label %29, label %30

29:                                               ; preds = %ok12
  call fastcc void @native_trap() #114
  unreachable

30:                                               ; preds = %ok12
  %31 = getelementptr inbounds nuw i8, ptr %27, i64 376
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %34, label %38

34:                                               ; preds = %44, %38, %30
  %35 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %36 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %27, i64 noundef 24, ptr noundef %35) #84
  %37 = icmp eq ptr %36, null
  br i1 %37, label %46, label %ok25

38:                                               ; preds = %30
  %39 = getelementptr inbounds nuw i8, ptr %27, i64 368
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = add i64 %40, 1
  store i64 %41, ptr %39, align 8
  %42 = urem i64 %41, %32
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %44, label %34

44:                                               ; preds = %38
  %45 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %27, ptr noundef %45) #84
  br label %34

46:                                               ; preds = %34
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok25:                                             ; preds = %34
  %47 = ptrtoint ptr %36 to i64
  store i64 138, ptr %36, align 1
  %v32 = getelementptr i8, ptr %36, i64 8
  store i32 1, ptr %v32, align 1
  %v37 = getelementptr i8, ptr %36, i64 16
  store i64 %26, ptr %v37, align 1
  store i64 %47, ptr %v4, align 8
  %v38.b = load i1, ptr @g.15, align 1
  br i1 %v38.b, label %block41, label %then43

then43:                                           ; preds = %ok25
  call fastcc void @native_trap()
  unreachable

block41:                                          ; preds = %ok25
  store i64 %47, ptr %v20, align 8
  store i64 5, ptr %1, align 8
  %48 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %block41
  call fastcc void @native_trap() #114
  unreachable

51:                                               ; preds = %block41
  %52 = getelementptr inbounds nuw i8, ptr %48, i64 376
  %53 = load i64, ptr %52, align 8, !noundef !39
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %55, label %59

55:                                               ; preds = %65, %59, %51
  %56 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %57 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %48, i64 noundef 24, ptr noundef %56) #84
  %58 = icmp eq ptr %57, null
  br i1 %58, label %67, label %ok52

59:                                               ; preds = %51
  %60 = getelementptr inbounds nuw i8, ptr %48, i64 368
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = add i64 %61, 1
  store i64 %62, ptr %60, align 8
  %63 = urem i64 %62, %53
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %65, label %55

65:                                               ; preds = %59
  %66 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %48, ptr noundef %66) #84
  br label %55

67:                                               ; preds = %55
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok52:                                             ; preds = %55
  %68 = ptrtoint ptr %57 to i64
  store i64 130, ptr %57, align 1
  %v59 = getelementptr i8, ptr %57, i64 8
  store i64 %arg1, ptr %v59, align 1
  %v64 = getelementptr i8, ptr %57, i64 16
  store i64 %47, ptr %v64, align 1
  store i64 %68, ptr %v20, align 8
  store i64 5, ptr %1, align 8
  %69 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %70 = icmp eq ptr %69, null
  br i1 %70, label %71, label %72

71:                                               ; preds = %ok52
  call fastcc void @native_trap() #114
  unreachable

72:                                               ; preds = %ok52
  %73 = getelementptr inbounds nuw i8, ptr %69, i64 376
  %74 = load i64, ptr %73, align 8, !noundef !39
  %75 = icmp eq i64 %74, 0
  br i1 %75, label %76, label %80

76:                                               ; preds = %86, %80, %72
  %77 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %78 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %69, i64 noundef 16, ptr noundef %77) #84
  %79 = icmp eq ptr %78, null
  br i1 %79, label %88, label %ok70

80:                                               ; preds = %72
  %81 = getelementptr inbounds nuw i8, ptr %69, i64 368
  %82 = load i64, ptr %81, align 8, !noundef !39
  %83 = add i64 %82, 1
  store i64 %83, ptr %81, align 8
  %84 = urem i64 %83, %74
  %85 = icmp eq i64 %84, 0
  br i1 %85, label %86, label %76

86:                                               ; preds = %80
  %87 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %69, ptr noundef %87) #84
  br label %76

88:                                               ; preds = %76
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok70:                                             ; preds = %76
  %89 = ptrtoint ptr %78 to i64
  store i64 170, ptr %78, align 1
  %v77 = getelementptr i8, ptr %78, i64 8
  store i64 %68, ptr %v77, align 1
  store i64 %89, ptr %v20, align 8
  store i64 5, ptr %1, align 8
  %90 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %91 = icmp eq ptr %90, null
  br i1 %91, label %92, label %93

92:                                               ; preds = %ok70
  call fastcc void @native_trap() #114
  unreachable

93:                                               ; preds = %ok70
  %94 = getelementptr inbounds nuw i8, ptr %90, i64 376
  %95 = load i64, ptr %94, align 8, !noundef !39
  %96 = icmp eq i64 %95, 0
  br i1 %96, label %97, label %101

97:                                               ; preds = %107, %101, %93
  %98 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %99 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %90, i64 noundef 24, ptr noundef %98) #84
  %100 = icmp eq ptr %99, null
  br i1 %100, label %109, label %ok83

101:                                              ; preds = %93
  %102 = getelementptr inbounds nuw i8, ptr %90, i64 368
  %103 = load i64, ptr %102, align 8, !noundef !39
  %104 = add i64 %103, 1
  store i64 %104, ptr %102, align 8
  %105 = urem i64 %104, %95
  %106 = icmp eq i64 %105, 0
  br i1 %106, label %107, label %97

107:                                              ; preds = %101
  %108 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %90, ptr noundef %108) #84
  br label %97

109:                                              ; preds = %97
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok83:                                             ; preds = %97
  %110 = ptrtoint ptr %99 to i64
  store i64 138, ptr %99, align 1
  %v90 = getelementptr i8, ptr %99, i64 8
  store i32 1, ptr %v90, align 1
  %v95 = getelementptr i8, ptr %99, i64 16
  store i64 %89, ptr %v95, align 1
  store i64 %110, ptr %v4, align 8
  %v96 = load i64, ptr @g.14, align 8
  %v97.not = icmp eq i64 %v96, 0
  br i1 %v97.not, label %trap98, label %ok99

trap98:                                           ; preds = %ok83
  call fastcc void @native_trap()
  unreachable

ok99:                                             ; preds = %ok83
  store i64 4, ptr %1, align 8
  %111 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %112 = icmp eq ptr %111, null
  br i1 %112, label %113, label %114

113:                                              ; preds = %ok99
  call fastcc void @native_trap() #114
  unreachable

114:                                              ; preds = %ok99
  %115 = getelementptr inbounds nuw i8, ptr %111, i64 376
  %116 = load i64, ptr %115, align 8, !noundef !39
  %117 = icmp eq i64 %116, 0
  br i1 %117, label %118, label %122

118:                                              ; preds = %128, %122, %114
  %119 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %120 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %111, i64 noundef 24, ptr noundef %119) #84
  %121 = icmp eq ptr %120, null
  br i1 %121, label %130, label %ok107

122:                                              ; preds = %114
  %123 = getelementptr inbounds nuw i8, ptr %111, i64 368
  %124 = load i64, ptr %123, align 8, !noundef !39
  %125 = add i64 %124, 1
  store i64 %125, ptr %123, align 8
  %126 = urem i64 %125, %116
  %127 = icmp eq i64 %126, 0
  br i1 %127, label %128, label %118

128:                                              ; preds = %122
  %129 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %111, ptr noundef %129) #84
  br label %118

130:                                              ; preds = %118
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok107:                                            ; preds = %118
  %131 = ptrtoint ptr %120 to i64
  store i64 142, ptr %120, align 1
  %v114 = getelementptr i8, ptr %120, i64 8
  store i32 0, ptr %v114, align 1
  %v119 = getelementptr i8, ptr %120, i64 16
  store i64 0, ptr %v119, align 1
  store i64 %131, ptr %v3, align 8
  store i64 %131, ptr %v20, align 8
  %v122 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v122, align 8
  %v123 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  store i64 %131, ptr %v123, align 8
  store i64 7, ptr %1, align 8
  %132 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %133 = icmp eq ptr %132, null
  br i1 %133, label %134, label %135

134:                                              ; preds = %ok107
  call fastcc void @native_trap() #114
  unreachable

135:                                              ; preds = %ok107
  %136 = getelementptr inbounds nuw i8, ptr %132, i64 376
  %137 = load i64, ptr %136, align 8, !noundef !39
  %138 = icmp eq i64 %137, 0
  br i1 %138, label %139, label %143

139:                                              ; preds = %149, %143, %135
  %140 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %141 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %132, i64 noundef 16, ptr noundef %140) #84
  %142 = icmp eq ptr %141, null
  br i1 %142, label %151, label %ok128

143:                                              ; preds = %135
  %144 = getelementptr inbounds nuw i8, ptr %132, i64 368
  %145 = load i64, ptr %144, align 8, !noundef !39
  %146 = add i64 %145, 1
  store i64 %146, ptr %144, align 8
  %147 = urem i64 %146, %137
  %148 = icmp eq i64 %147, 0
  br i1 %148, label %149, label %139

149:                                              ; preds = %143
  %150 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %132, ptr noundef %150) #84
  br label %139

151:                                              ; preds = %139
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok128:                                            ; preds = %139
  %152 = ptrtoint ptr %141 to i64
  store i64 126, ptr %141, align 1
  %v135 = getelementptr i8, ptr %141, i64 8
  store i64 %131, ptr %v135, align 1
  store i64 %152, ptr %v20, align 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v122, align 8
  store i64 %131, ptr %v123, align 8
  store i64 7, ptr %1, align 8
  %153 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %154 = icmp eq ptr %153, null
  br i1 %154, label %155, label %156

155:                                              ; preds = %ok128
  call fastcc void @native_trap() #114
  unreachable

156:                                              ; preds = %ok128
  %157 = getelementptr inbounds nuw i8, ptr %153, i64 376
  %158 = load i64, ptr %157, align 8, !noundef !39
  %159 = icmp eq i64 %158, 0
  br i1 %159, label %160, label %164

160:                                              ; preds = %170, %164, %156
  %161 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %162 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %153, i64 noundef 24, ptr noundef %161) #84
  %163 = icmp eq ptr %162, null
  br i1 %163, label %172, label %ok143

164:                                              ; preds = %156
  %165 = getelementptr inbounds nuw i8, ptr %153, i64 368
  %166 = load i64, ptr %165, align 8, !noundef !39
  %167 = add i64 %166, 1
  store i64 %167, ptr %165, align 8
  %168 = urem i64 %167, %158
  %169 = icmp eq i64 %168, 0
  br i1 %169, label %170, label %160

170:                                              ; preds = %164
  %171 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %153, ptr noundef %171) #84
  br label %160

172:                                              ; preds = %160
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok143:                                            ; preds = %160
  %173 = ptrtoint ptr %162 to i64
  store i64 166, ptr %162, align 1
  %v150 = getelementptr i8, ptr %162, i64 8
  store i64 ptrtoint (ptr @ref.21 to i64), ptr %v150, align 1
  %v155 = getelementptr i8, ptr %162, i64 16
  store i64 %152, ptr %v155, align 1
  store i64 %173, ptr %v119, align 1
  %v161 = load i64, ptr %v3, align 8
  %v162.not = icmp eq i64 %v161, 0
  br i1 %v162.not, label %trap163, label %ok164

trap163:                                          ; preds = %ok143
  call fastcc void @native_trap()
  unreachable

ok164:                                            ; preds = %ok143
  %v165 = inttoptr i64 %v161 to ptr
  %v166 = getelementptr i8, ptr %v165, i64 8
  store i32 1, ptr %v166, align 1
  %v167 = load i64, ptr %v3, align 8
  %v168.not = icmp eq i64 %v167, 0
  br i1 %v168.not, label %trap169, label %ok170

trap169:                                          ; preds = %ok164
  call fastcc void @native_trap()
  unreachable

ok170:                                            ; preds = %ok164
  %v171 = inttoptr i64 %v167 to ptr
  %v172 = getelementptr i8, ptr %v171, i64 8
  %v173 = load i32, ptr %v172, align 1
  %v174 = icmp eq i32 %v173, 0
  br i1 %v174, label %then178, label %ok186

then178:                                          ; preds = %ok170
  call fastcc void @native_trap()
  unreachable

ok186:                                            ; preds = %ok170
  %v188 = getelementptr i8, ptr %v171, i64 16
  %v189 = load i64, ptr %v188, align 1
  %v190.not = icmp eq i64 %v189, 0
  br i1 %v190.not, label %trap191, label %ok192

trap191:                                          ; preds = %ok186
  call fastcc void @native_trap()
  unreachable

ok192:                                            ; preds = %ok186
  store i64 %v189, ptr %v5, align 8
  %v196 = inttoptr i64 %v189 to ptr
  %v206 = getelementptr i8, ptr %v196, i64 8
  %v207 = load i64, ptr %v206, align 1
  %v208.not = icmp eq i64 %v207, 0
  br i1 %v208.not, label %trap209, label %ok210

trap209:                                          ; preds = %ok192
  call fastcc void @native_trap()
  unreachable

ok210:                                            ; preds = %ok192
  %v200 = add i64 %arg1, -1
  %v197 = getelementptr i8, ptr %v196, i64 16
  %v198 = load i64, ptr %v197, align 1
  %v211 = inttoptr i64 %v207 to ptr
  %v212 = getelementptr i8, ptr %v211, i64 8
  %v213 = load ptr, ptr %v212, align 1
  store i64 %v198, ptr %v20, align 8
  store i64 5, ptr %1, align 8
  %v216 = call tailcc i64 %v213(i64 %v198, i64 %v200, i64 1)
  %v220 = load i64, ptr %v4, align 8
  store i64 %v220, ptr %v20, align 8
  store i64 5, ptr %1, align 8
  %174 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %175 = icmp eq ptr %174, null
  br i1 %175, label %176, label %177

176:                                              ; preds = %ok210
  call fastcc void @native_trap() #114
  unreachable

177:                                              ; preds = %ok210
  %178 = getelementptr inbounds nuw i8, ptr %174, i64 376
  %179 = load i64, ptr %178, align 8, !noundef !39
  %180 = icmp eq i64 %179, 0
  br i1 %180, label %181, label %185

181:                                              ; preds = %191, %185, %177
  %182 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %183 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %174, i64 noundef 40, ptr noundef %182) #84
  %184 = icmp eq ptr %183, null
  br i1 %184, label %193, label %ok226

185:                                              ; preds = %177
  %186 = getelementptr inbounds nuw i8, ptr %174, i64 368
  %187 = load i64, ptr %186, align 8, !noundef !39
  %188 = add i64 %187, 1
  store i64 %188, ptr %186, align 8
  %189 = urem i64 %188, %179
  %190 = icmp eq i64 %189, 0
  br i1 %190, label %191, label %181

191:                                              ; preds = %185
  %192 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %174, ptr noundef %192) #84
  br label %181

193:                                              ; preds = %181
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok226:                                            ; preds = %181
  %v217 = shl i64 %v216, 2
  %v219 = add i64 %v217, -4
  %v182 = add i64 %arg1, -2
  store i64 118, ptr %183, align 1
  %v233 = getelementptr i8, ptr %183, i64 8
  store i64 %arg1, ptr %v233, align 1
  %v238 = getelementptr i8, ptr %183, i64 16
  store i64 %v182, ptr %v238, align 1
  %v243 = getelementptr i8, ptr %183, i64 24
  store i64 %v219, ptr %v243, align 1
  %v248 = getelementptr i8, ptr %183, i64 32
  store i64 %v220, ptr %v248, align 1
  %194 = load i64, ptr %0, align 8, !noundef !39
  %195 = icmp eq i64 %194, 0
  br i1 %195, label %native_roots_leave.exit, label %196

196:                                              ; preds = %ok226
  %197 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %197, ptr @native_roots.0, align 8
  %198 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %199 = add i64 %198, -1
  store i64 %199, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %196, %ok226
  %200 = ptrtoint ptr %183 to i64
  tail call tailcc void @f.8(i64 %200)
  ret i32 0
}
