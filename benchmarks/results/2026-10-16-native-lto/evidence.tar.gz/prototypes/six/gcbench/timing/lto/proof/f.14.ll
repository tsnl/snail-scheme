define internal tailcc i32 @f.14(i64 range(i64 1, 0) %arg0, i64 %arg1) unnamed_addr #104 personality ptr @rust_eh_personality {
native_roots_leave.exit1:
  %roots = alloca { ptr, i64, i64, [8 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 8, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %v12 = inttoptr i64 %arg0 to ptr
  %v13 = getelementptr i8, ptr %v12, i64 32
  %v14 = load i64, ptr %v13, align 1
  store i64 3, ptr %1, align 8
  call void @benchmark_opaque_print_construction(i64 %arg1, i64 %v14)
  store i64 3, ptr %1, align 8
  call void @benchmark_opaque_print_text(i64 0)
  %v17.b = load i1, ptr @g.23, align 1
  br i1 %v17.b, label %block20, label %then22

then22:                                           ; preds = %native_roots_leave.exit1
  call fastcc void @native_trap()
  unreachable

block20:                                          ; preds = %native_roots_leave.exit1
  %v24 = load i64, ptr @g.22, align 8
  %v25.not = icmp eq i64 %v24, 0
  br i1 %v25.not, label %trap26, label %native_roots_leave.exit3

trap26:                                           ; preds = %block20
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit3:                         ; preds = %block20
  store i64 3, ptr %1, align 8
  call void @benchmark_opaque_print_text(i64 4)
  store i64 3, ptr %1, align 8
  call void @benchmark_opaque_print_text(i64 0)
  store i64 3, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %native_roots_leave.exit3
  call fastcc void @native_trap() #114
  unreachable

10:                                               ; preds = %native_roots_leave.exit3
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 24, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %26, label %ok34

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  %25 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef %25) #84
  br label %14

26:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok34:                                             ; preds = %14
  %27 = ptrtoint ptr %16 to i64
  store i64 114, ptr %16, align 1
  %v41 = getelementptr i8, ptr %16, i64 8
  store i32 0, ptr %v41, align 1
  %v46 = getelementptr i8, ptr %16, i64 16
  store i64 0, ptr %v46, align 1
  store i64 %27, ptr %v3, align 8
  %v47 = load i64, ptr %v1, align 8
  %v48.not = icmp eq i64 %v47, 0
  br i1 %v48.not, label %trap49, label %ok50

trap49:                                           ; preds = %ok34
  call fastcc void @native_trap()
  unreachable

ok50:                                             ; preds = %ok34
  %v51 = inttoptr i64 %v47 to ptr
  %v52 = getelementptr i8, ptr %v51, i64 8
  %v53 = load i64, ptr %v52, align 1
  %v59 = getelementptr i8, ptr %v51, i64 24
  %28 = load <2 x i64>, ptr %v59, align 1
  %29 = extractelement <2 x i64> %28, i64 0
  %v70 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 %27, ptr %v70, align 8
  %v71 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 %29, ptr %v71, align 8
  %v72 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %v53, ptr %v72, align 8
  %v73 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v73, align 8
  %v74 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  store i64 %27, ptr %v74, align 8
  store i64 8, ptr %1, align 8
  %30 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %31 = icmp eq ptr %30, null
  br i1 %31, label %32, label %33

32:                                               ; preds = %ok50
  call fastcc void @native_trap() #114
  unreachable

33:                                               ; preds = %ok50
  %34 = getelementptr inbounds nuw i8, ptr %30, i64 376
  %35 = load i64, ptr %34, align 8, !noundef !39
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %37, label %41

37:                                               ; preds = %47, %41, %33
  %38 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %39 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %30, i64 noundef 48, ptr noundef %38) #84
  %40 = icmp eq ptr %39, null
  br i1 %40, label %49, label %ok79

41:                                               ; preds = %33
  %42 = getelementptr inbounds nuw i8, ptr %30, i64 368
  %43 = load i64, ptr %42, align 8, !noundef !39
  %44 = add i64 %43, 1
  store i64 %44, ptr %42, align 8
  %45 = urem i64 %44, %35
  %46 = icmp eq i64 %45, 0
  br i1 %46, label %47, label %37

47:                                               ; preds = %41
  %48 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %30, ptr noundef %48) #84
  br label %37

49:                                               ; preds = %37
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok79:                                             ; preds = %37
  %50 = ptrtoint ptr %39 to i64
  store i64 26, ptr %39, align 1
  %v86 = getelementptr i8, ptr %39, i64 8
  store i64 %v53, ptr %v86, align 1
  %v91 = getelementptr i8, ptr %39, i64 16
  store <2 x i64> %28, ptr %v91, align 1
  %v101 = getelementptr i8, ptr %39, i64 32
  store i64 %arg1, ptr %v101, align 1
  %v106 = getelementptr i8, ptr %39, i64 40
  store i64 %27, ptr %v106, align 1
  store i64 %50, ptr %v70, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v71, align 8
  store i64 %27, ptr %v72, align 8
  store i64 6, ptr %1, align 8
  %51 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %52 = icmp eq ptr %51, null
  br i1 %52, label %53, label %54

53:                                               ; preds = %ok79
  call fastcc void @native_trap() #114
  unreachable

54:                                               ; preds = %ok79
  %55 = getelementptr inbounds nuw i8, ptr %51, i64 376
  %56 = load i64, ptr %55, align 8, !noundef !39
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %58, label %62

58:                                               ; preds = %68, %62, %54
  %59 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %60 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %51, i64 noundef 24, ptr noundef %59) #84
  %61 = icmp eq ptr %60, null
  br i1 %61, label %70, label %ok114

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw i8, ptr %51, i64 368
  %64 = load i64, ptr %63, align 8, !noundef !39
  %65 = add i64 %64, 1
  store i64 %65, ptr %63, align 8
  %66 = urem i64 %65, %56
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %68, label %58

68:                                               ; preds = %62
  %69 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %51, ptr noundef %69) #84
  br label %58

70:                                               ; preds = %58
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok114:                                            ; preds = %58
  %71 = ptrtoint ptr %60 to i64
  store i64 150, ptr %60, align 1
  %v121 = getelementptr i8, ptr %60, i64 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v121, align 1
  %v126 = getelementptr i8, ptr %60, i64 16
  store i64 %50, ptr %v126, align 1
  store i64 %71, ptr %v46, align 1
  %v132 = load i64, ptr %v3, align 8
  %v133.not = icmp eq i64 %v132, 0
  br i1 %v133.not, label %trap134, label %ok135

trap134:                                          ; preds = %ok114
  call fastcc void @native_trap()
  unreachable

ok135:                                            ; preds = %ok114
  %v136 = inttoptr i64 %v132 to ptr
  %v137 = getelementptr i8, ptr %v136, i64 8
  store i32 1, ptr %v137, align 1
  %v138 = load i64, ptr %v3, align 8
  %v139.not = icmp eq i64 %v138, 0
  br i1 %v139.not, label %trap140, label %ok141

trap140:                                          ; preds = %ok135
  call fastcc void @native_trap()
  unreachable

ok141:                                            ; preds = %ok135
  %v142 = inttoptr i64 %v138 to ptr
  %v143 = getelementptr i8, ptr %v142, i64 8
  %v144 = load i32, ptr %v143, align 1
  %v145 = icmp eq i32 %v144, 0
  br i1 %v145, label %then149, label %ok154

then149:                                          ; preds = %ok141
  call fastcc void @native_trap()
  unreachable

ok154:                                            ; preds = %ok141
  %v156 = getelementptr i8, ptr %v142, i64 16
  %v157 = load i64, ptr %v156, align 1
  %v158.not = icmp eq i64 %v157, 0
  br i1 %v158.not, label %trap159, label %ok160

trap159:                                          ; preds = %ok154
  call fastcc void @native_trap()
  unreachable

ok160:                                            ; preds = %ok154
  store i64 %v157, ptr %v4, align 8
  %v164 = inttoptr i64 %v157 to ptr
  %v172 = getelementptr i8, ptr %v164, i64 8
  %v173 = load i64, ptr %v172, align 1
  %v174.not = icmp eq i64 %v173, 0
  br i1 %v174.not, label %trap175, label %ok176

trap175:                                          ; preds = %ok160
  call fastcc void @native_trap()
  unreachable

ok176:                                            ; preds = %ok160
  %v165 = getelementptr i8, ptr %v164, i64 16
  %v166 = load i64, ptr %v165, align 1
  %v177 = inttoptr i64 %v173 to ptr
  %v178 = getelementptr i8, ptr %v177, i64 8
  %v179 = load ptr, ptr %v178, align 1
  store i64 %v166, ptr %v70, align 8
  store i64 4, ptr %1, align 8
  %v182 = call tailcc i32 %v179(i64 %v166, i64 0)
  %v183.b = load i1, ptr @g.23, align 1
  br i1 %v183.b, label %block186, label %then188

then188:                                          ; preds = %ok176
  call fastcc void @native_trap()
  unreachable

block186:                                         ; preds = %ok176
  %v190 = load i64, ptr @g.22, align 8
  %v191.not = icmp eq i64 %v190, 0
  br i1 %v191.not, label %trap192, label %native_roots_leave.exit7

trap192:                                          ; preds = %block186
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit7:                         ; preds = %block186
  store i64 3, ptr %1, align 8
  call void @benchmark_opaque_print_text(i64 5)
  store i64 3, ptr %1, align 8
  call void @benchmark_opaque_print_text(i64 0)
  store i64 3, ptr %1, align 8
  %72 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %73 = icmp eq ptr %72, null
  br i1 %73, label %74, label %75

74:                                               ; preds = %native_roots_leave.exit7
  call fastcc void @native_trap() #114
  unreachable

75:                                               ; preds = %native_roots_leave.exit7
  %76 = getelementptr inbounds nuw i8, ptr %72, i64 376
  %77 = load i64, ptr %76, align 8, !noundef !39
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %79, label %83

79:                                               ; preds = %89, %83, %75
  %80 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %81 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %72, i64 noundef 24, ptr noundef %80) #84
  %82 = icmp eq ptr %81, null
  br i1 %82, label %91, label %ok200

83:                                               ; preds = %75
  %84 = getelementptr inbounds nuw i8, ptr %72, i64 368
  %85 = load i64, ptr %84, align 8, !noundef !39
  %86 = add i64 %85, 1
  store i64 %86, ptr %84, align 8
  %87 = urem i64 %86, %77
  %88 = icmp eq i64 %87, 0
  br i1 %88, label %89, label %79

89:                                               ; preds = %83
  %90 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %72, ptr noundef %90) #84
  br label %79

91:                                               ; preds = %79
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok200:                                            ; preds = %79
  %92 = ptrtoint ptr %81 to i64
  store i64 114, ptr %81, align 1
  %v207 = getelementptr i8, ptr %81, i64 8
  store i32 0, ptr %v207, align 1
  %v212 = getelementptr i8, ptr %81, i64 16
  store i64 0, ptr %v212, align 1
  store i64 %92, ptr %v3, align 8
  %v213 = load i64, ptr %v1, align 8
  %v214.not = icmp eq i64 %v213, 0
  br i1 %v214.not, label %trap215, label %ok216

trap215:                                          ; preds = %ok200
  call fastcc void @native_trap()
  unreachable

ok216:                                            ; preds = %ok200
  %v217 = inttoptr i64 %v213 to ptr
  %v218 = getelementptr i8, ptr %v217, i64 16
  %v219 = load i64, ptr %v218, align 1
  %v225 = getelementptr i8, ptr %v217, i64 32
  %v226 = load i64, ptr %v225, align 1
  store i64 %92, ptr %v70, align 8
  store i64 %v219, ptr %v71, align 8
  store i64 ptrtoint (ptr @ref.15 to i64), ptr %v72, align 8
  store i64 %92, ptr %v73, align 8
  store i64 7, ptr %1, align 8
  %93 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %94 = icmp eq ptr %93, null
  br i1 %94, label %95, label %96

95:                                               ; preds = %ok216
  call fastcc void @native_trap() #114
  unreachable

96:                                               ; preds = %ok216
  %97 = getelementptr inbounds nuw i8, ptr %93, i64 376
  %98 = load i64, ptr %97, align 8, !noundef !39
  %99 = icmp eq i64 %98, 0
  br i1 %99, label %100, label %104

100:                                              ; preds = %110, %104, %96
  %101 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %102 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %93, i64 noundef 40, ptr noundef %101) #84
  %103 = icmp eq ptr %102, null
  br i1 %103, label %112, label %ok237

104:                                              ; preds = %96
  %105 = getelementptr inbounds nuw i8, ptr %93, i64 368
  %106 = load i64, ptr %105, align 8, !noundef !39
  %107 = add i64 %106, 1
  store i64 %107, ptr %105, align 8
  %108 = urem i64 %107, %98
  %109 = icmp eq i64 %108, 0
  br i1 %109, label %110, label %100

110:                                              ; preds = %104
  %111 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %93, ptr noundef %111) #84
  br label %100

112:                                              ; preds = %100
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok237:                                            ; preds = %100
  %113 = ptrtoint ptr %102 to i64
  store i64 22, ptr %102, align 1
  %v244 = getelementptr i8, ptr %102, i64 8
  store i64 %v219, ptr %v244, align 1
  %v249 = getelementptr i8, ptr %102, i64 16
  store i64 %v226, ptr %v249, align 1
  %v254 = getelementptr i8, ptr %102, i64 24
  store i64 %arg1, ptr %v254, align 1
  %v259 = getelementptr i8, ptr %102, i64 32
  store i64 %92, ptr %v259, align 1
  store i64 %113, ptr %v70, align 8
  store i64 ptrtoint (ptr @ref.15 to i64), ptr %v71, align 8
  store i64 %92, ptr %v72, align 8
  store i64 6, ptr %1, align 8
  %114 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hb96eca4d421b2416E.0, align 8, !noundef !39
  %115 = icmp eq ptr %114, null
  br i1 %115, label %116, label %117

116:                                              ; preds = %ok237
  call fastcc void @native_trap() #114
  unreachable

117:                                              ; preds = %ok237
  %118 = getelementptr inbounds nuw i8, ptr %114, i64 376
  %119 = load i64, ptr %118, align 8, !noundef !39
  %120 = icmp eq i64 %119, 0
  br i1 %120, label %121, label %125

121:                                              ; preds = %131, %125, %117
  %122 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %123 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h6ef7dcd0ea0e9f6fE(ptr noalias noundef align 8 dereferenceable(344) %114, i64 noundef 24, ptr noundef %122) #84
  %124 = icmp eq ptr %123, null
  br i1 %124, label %133, label %ok267

125:                                              ; preds = %117
  %126 = getelementptr inbounds nuw i8, ptr %114, i64 368
  %127 = load i64, ptr %126, align 8, !noundef !39
  %128 = add i64 %127, 1
  store i64 %128, ptr %126, align 8
  %129 = urem i64 %128, %119
  %130 = icmp eq i64 %129, 0
  br i1 %130, label %131, label %121

131:                                              ; preds = %125
  %132 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h653baa87461b81b2E(ptr noalias noundef align 8 dereferenceable(344) %114, ptr noundef %132) #84
  br label %121

133:                                              ; preds = %121
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17hc3e08396466a40feE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.8cb776dec74e80df50c0f86ffa931e11.425, i64 noundef 47) #114
  unreachable

ok267:                                            ; preds = %121
  %134 = ptrtoint ptr %123 to i64
  store i64 150, ptr %123, align 1
  %v274 = getelementptr i8, ptr %123, i64 8
  store i64 ptrtoint (ptr @ref.15 to i64), ptr %v274, align 1
  %v279 = getelementptr i8, ptr %123, i64 16
  store i64 %113, ptr %v279, align 1
  store i64 %134, ptr %v212, align 1
  %v285 = load i64, ptr %v3, align 8
  %v286.not = icmp eq i64 %v285, 0
  br i1 %v286.not, label %trap287, label %ok288

trap287:                                          ; preds = %ok267
  call fastcc void @native_trap()
  unreachable

ok288:                                            ; preds = %ok267
  %v289 = inttoptr i64 %v285 to ptr
  %v290 = getelementptr i8, ptr %v289, i64 8
  store i32 1, ptr %v290, align 1
  %v291 = load i64, ptr %v3, align 8
  %v292.not = icmp eq i64 %v291, 0
  br i1 %v292.not, label %trap293, label %ok294

trap293:                                          ; preds = %ok288
  call fastcc void @native_trap()
  unreachable

ok294:                                            ; preds = %ok288
  %v295 = inttoptr i64 %v291 to ptr
  %v296 = getelementptr i8, ptr %v295, i64 8
  %v297 = load i32, ptr %v296, align 1
  %v298 = icmp eq i32 %v297, 0
  br i1 %v298, label %then302, label %ok307

then302:                                          ; preds = %ok294
  call fastcc void @native_trap()
  unreachable

ok307:                                            ; preds = %ok294
  %v309 = getelementptr i8, ptr %v295, i64 16
  %v310 = load i64, ptr %v309, align 1
  %v311.not = icmp eq i64 %v310, 0
  br i1 %v311.not, label %trap312, label %ok313

trap312:                                          ; preds = %ok307
  call fastcc void @native_trap()
  unreachable

ok313:                                            ; preds = %ok307
  store i64 %v310, ptr %v4, align 8
  %v317 = inttoptr i64 %v310 to ptr
  %v325 = getelementptr i8, ptr %v317, i64 8
  %v326 = load i64, ptr %v325, align 1
  %v327.not = icmp eq i64 %v326, 0
  br i1 %v327.not, label %trap328, label %ok329

trap328:                                          ; preds = %ok313
  call fastcc void @native_trap()
  unreachable

ok329:                                            ; preds = %ok313
  %v318 = getelementptr i8, ptr %v317, i64 16
  %v319 = load i64, ptr %v318, align 1
  %v330 = inttoptr i64 %v326 to ptr
  %v331 = getelementptr i8, ptr %v330, i64 8
  %v332 = load ptr, ptr %v331, align 1
  %135 = load i64, ptr %0, align 8, !noundef !39
  %136 = icmp eq i64 %135, 0
  br i1 %136, label %native_roots_leave.exit11, label %137

137:                                              ; preds = %ok329
  %138 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %138, ptr @native_roots.0, align 8
  %139 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %140 = add i64 %139, -1
  store i64 %140, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit11

native_roots_leave.exit11:                        ; preds = %137, %ok329
  %v333 = tail call tailcc i32 %v332(i64 %v319, i64 0)
  ret i32 %v333
}
