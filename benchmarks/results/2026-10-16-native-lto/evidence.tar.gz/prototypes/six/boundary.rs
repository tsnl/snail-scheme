// Opaque benchmark imports, compiled once as machine code without std.
#![no_std]
unsafe extern "C" { #[link_name = "input_i64"] fn provider_input_i64(index: i32) -> i64; }
#[unsafe(export_name = "benchmark_opaque_input_i64")]
pub extern "C" fn boundary_input_i64(index: i32) -> i64 { unsafe { provider_input_i64(index) } }
unsafe extern "C" { #[link_name = "input_f64"] fn provider_input_f64(index: i32) -> f64; }
#[unsafe(export_name = "benchmark_opaque_input_f64")]
pub extern "C" fn boundary_input_f64(index: i32) -> f64 { unsafe { provider_input_f64(index) } }
unsafe extern "C" { #[link_name = "vector_length"] fn provider_vector_length(index: i32) -> i64; }
#[unsafe(export_name = "benchmark_opaque_vector_length")]
pub extern "C" fn boundary_vector_length(index: i32) -> i64 { unsafe { provider_vector_length(index) } }
unsafe extern "C" { #[link_name = "vector_i64"] fn provider_vector_i64(index: i32, element: i64) -> i64; }
#[unsafe(export_name = "benchmark_opaque_vector_i64")]
pub extern "C" fn boundary_vector_i64(index: i32, element: i64) -> i64 { unsafe { provider_vector_i64(index, element) } }
unsafe extern "C" { #[link_name = "vector_f64"] fn provider_vector_f64(index: i32, element: i64) -> f64; }
#[unsafe(export_name = "benchmark_opaque_vector_f64")]
pub extern "C" fn boundary_vector_f64(index: i32, element: i64) -> f64 { unsafe { provider_vector_f64(index, element) } }
unsafe extern "C" { #[link_name = "expected_length"] fn provider_expected_length() -> i64; }
#[unsafe(export_name = "benchmark_opaque_expected_length")]
pub extern "C" fn boundary_expected_length() -> i64 { unsafe { provider_expected_length() } }
unsafe extern "C" { #[link_name = "expected_i64"] fn provider_expected_i64(index: i64) -> i64; }
#[unsafe(export_name = "benchmark_opaque_expected_i64")]
pub extern "C" fn boundary_expected_i64(index: i64) -> i64 { unsafe { provider_expected_i64(index) } }
unsafe extern "C" { #[link_name = "expected_f64"] fn provider_expected_f64(index: i64) -> f64; }
#[unsafe(export_name = "benchmark_opaque_expected_f64")]
pub extern "C" fn boundary_expected_f64(index: i64) -> f64 { unsafe { provider_expected_f64(index) } }
unsafe extern "C" { #[link_name = "tolerance"] fn provider_tolerance() -> f64; }
#[unsafe(export_name = "benchmark_opaque_tolerance")]
pub extern "C" fn boundary_tolerance() -> f64 { unsafe { provider_tolerance() } }
unsafe extern "C" { #[link_name = "count"] fn provider_count() -> i64; }
#[unsafe(export_name = "benchmark_opaque_count")]
pub extern "C" fn boundary_count() -> i64 { unsafe { provider_count() } }
unsafe extern "C" { #[link_name = "hide_i64"] fn provider_hide_i64(value: i64) -> i64; }
#[unsafe(export_name = "benchmark_opaque_hide_i64")]
pub extern "C" fn boundary_hide_i64(value: i64) -> i64 { unsafe { provider_hide_i64(value) } }
unsafe extern "C" { #[link_name = "hide_f64"] fn provider_hide_f64(value: f64) -> f64; }
#[unsafe(export_name = "benchmark_opaque_hide_f64")]
pub extern "C" fn boundary_hide_f64(value: f64) -> f64 { unsafe { provider_hide_f64(value) } }
unsafe extern "C" { #[link_name = "barrier"] fn provider_barrier() -> i32; }
#[unsafe(export_name = "benchmark_opaque_barrier")]
pub extern "C" fn boundary_barrier() -> i32 { unsafe { provider_barrier() } }
unsafe extern "C" { #[link_name = "write_character"] fn provider_write_character(value: u32); }
#[unsafe(export_name = "benchmark_opaque_write_character")]
pub extern "C" fn boundary_write_character(value: u32) { unsafe { provider_write_character(value) } }
unsafe extern "C" { #[link_name = "write_char"] fn provider_write_char(value: u32); }
#[unsafe(export_name = "benchmark_opaque_write_char")]
pub extern "C" fn boundary_write_char(value: u32) { unsafe { provider_write_char(value) } }
unsafe extern "C" { #[link_name = "print_text"] fn provider_print_text(index: i64); }
#[unsafe(export_name = "benchmark_opaque_print_text")]
pub extern "C" fn boundary_print_text(index: i64) { unsafe { provider_print_text(index) } }
unsafe extern "C" { #[link_name = "print_size"] fn provider_print_size(index: i64, value: i64); }
#[unsafe(export_name = "benchmark_opaque_print_size")]
pub extern "C" fn boundary_print_size(index: i64, value: i64) { unsafe { provider_print_size(index, value) } }
unsafe extern "C" { #[link_name = "print_construction"] fn provider_print_construction(iterations: i64, depth: i64); }
#[unsafe(export_name = "benchmark_opaque_print_construction")]
pub extern "C" fn boundary_print_construction(iterations: i64, depth: i64) { unsafe { provider_print_construction(iterations, depth) } }
