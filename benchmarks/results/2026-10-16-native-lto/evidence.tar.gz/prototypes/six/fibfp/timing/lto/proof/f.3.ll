define internal tailcc double @f.3(i64 %arg0, i64 %arg1, double %arg2) #104 personality ptr @rust_eh_personality {
native_roots_leave.exit:
  %roots = alloca { ptr, i64, i64, [1 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 1, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h0a06a12dde745025E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  store i64 1, ptr %1, align 8
  %v2.i = call double @benchmark_opaque_hide_f64(double %arg2)
  %7 = load i64, ptr %0, align 8, !noundef !39
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %native_roots_leave.exit1, label %9

9:                                                ; preds = %native_roots_leave.exit
  %10 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %10, ptr @native_roots.0, align 8
  %11 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8, !noundef !39
  %12 = add i64 %11, -1
  store i64 %12, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0a37305618b4ad24E.0, align 8
  br label %native_roots_leave.exit1

native_roots_leave.exit1:                         ; preds = %9, %native_roots_leave.exit
  ret double %v2.i
}
