define internal tailcc double @f.4(double %arg0) unnamed_addr #105 personality ptr @rust_eh_personality {
entry:
  %v6 = fcmp olt double %arg0, 2.000000e+00
  br i1 %v6, label %native_roots_leave.exit, label %else10

else10:                                           ; preds = %entry
  %v14.b = load i1, ptr @g.4, align 1
  br i1 %v14.b, label %block17, label %then19

then19:                                           ; preds = %else10
  tail call fastcc void @native_trap()
  unreachable

block17:                                          ; preds = %else10
  %v21 = load i64, ptr @g.3, align 8
  %v22.not = icmp eq i64 %v21, 0
  br i1 %v22.not, label %trap23, label %ok24

trap23:                                           ; preds = %block17
  tail call fastcc void @native_trap()
  unreachable

ok24:                                             ; preds = %block17
  %v26 = fadd double %arg0, -1.000000e+00
  %v28 = tail call tailcc double @f.4(double %v26)
  %v31.b = load i1, ptr @g.4, align 1
  br i1 %v31.b, label %block34, label %then36

then36:                                           ; preds = %ok24
  tail call fastcc void @native_trap()
  unreachable

block34:                                          ; preds = %ok24
  %v38 = load i64, ptr @g.3, align 8
  %v39.not = icmp eq i64 %v38, 0
  br i1 %v39.not, label %trap40, label %ok41

trap40:                                           ; preds = %block34
  tail call fastcc void @native_trap()
  unreachable

ok41:                                             ; preds = %block34
  %v43 = fadd double %arg0, -2.000000e+00
  %v45 = tail call tailcc double @f.4(double %v43)
  %v47 = fadd double %v28, %v45
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %ok41, %entry
  %slot8.0 = phi double [ %v47, %ok41 ], [ %arg0, %entry ]
  ret double %slot8.0
}
