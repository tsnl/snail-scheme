#![no_std]
unsafe extern "C" {
    fn hide_i64(value: i64) -> i64;
    fn input_i64(index: i32) -> i64;
}
#[unsafe(no_mangle)]
pub extern "C" fn benchmark_opaque_hide_i64(value: i64) -> i64 {
    unsafe { hide_i64(value) }
}
#[unsafe(no_mangle)]
pub extern "C" fn benchmark_opaque_input_i64(index: i32) -> i64 {
    unsafe { input_i64(index) }
}
