import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
const root='/tmp/snail-native-lto-20261016/probe/six';
const cases=process.argv.slice(2).length?process.argv.slice(2):['fib','fibfp','mbrot','array1','bv2string','gcbench'];
function blocks(body){
    const result=[];let current={label:'entry',lines:[],edges:[]};
    for(const line of body.split('\n')){
        const label=line.match(/^([A-Za-z0-9_.$-]+):/);
        if(label){if(current.lines.length)result.push(current);current={label:label[1],lines:[],edges:[]};}
        current.lines.push(line);current.edges.push(...[...line.matchAll(/label %([A-Za-z0-9_.$-]+)/g)].map(match=>match[1]));
    }
    if(current.lines.length)result.push(current);return result;
}
function components(graph){
    const nodes=new Map(graph.map(block=>[block.label,block]));const order=new Map();const low=new Map();const stack=[];const active=new Set();const result=[];let next=0;
    function visit(label){
        order.set(label,next);low.set(label,next++);stack.push(label);active.add(label);
        for(const successor of nodes.get(label).edges){if(!nodes.has(successor))continue;if(!order.has(successor)){visit(successor);low.set(label,Math.min(low.get(label),low.get(successor)));}else if(active.has(successor))low.set(label,Math.min(low.get(label),order.get(successor)));}
        if(low.get(label)===order.get(label)){const group=[];let member;do{member=stack.pop();active.delete(member);group.push(nodes.get(member));}while(member!==label);result.push(group);}
    }
    for(const label of nodes.keys())if(!order.has(label))visit(label);return result;
}
const summary=[];
for(const name of cases){
    const directory=root+'/'+name+'/timing/lto';const path=directory+'/post-lto.ll';if(!existsSync(path))continue;
    const ir=readFileSync(path,'utf8');const functions=[...ir.matchAll(/^define[^\n]*@(f\.\d+)\([^]*?^\}/gm)].map(match=>({name:match[1],body:match[0]}));
    const proofs=[];mkdirSync(directory+'/proof',{recursive:true});
    for(const fn of functions){
        const graph=blocks(fn.body);const loops=components(graph).filter(group=>group.length>1||(group.length===1&&group[0].edges.includes(group[0].label)));
        const groups=loops.map(group=>{const text=group.flatMap(block=>block.lines).join('\n');return {blocks:group.length,labels:group.map(block=>block.label),opaqueCalls:[...text.matchAll(/\bcall\b[^\n]*@benchmark_opaque_([A-Za-z0-9_]+)\(/g)].map(match=>match[1]),guestCalls:[...text.matchAll(/\bcall\b[^\n]*@(f\.\d+)\(/g)].map(match=>match[1]),indirectGuestCalls:(text.match(/\bcall tailcc[^\n]* %[A-Za-z0-9_.$-]+\(/g)||[]).length,allocationCalls:(text.match(/\bcall\b[^\n]*@(native_array_new|native_alloc|[^\s(]*Collector[^\s(]*allocate)[^\n]*/g)||[]).length,stores:(text.match(/^\s*store /gm)||[]).length,floatingOperations:(text.match(/\b(fadd|fsub|fmul|fdiv)\b/g)||[]).length};});
        const attributes=fn.body.split('\n')[0].match(/ #(\d+)/)?.[1];
        const attributeText=attributes?ir.match(new RegExp('^attributes #'+attributes+' = .*','m'))?.[0]:null;
        const calls=[...fn.body.matchAll(/\bcall\b[^\n]*@(f\.\d+)\(/g)].map(match=>match[1]);
        const proof={function:fn.name,header:fn.body.split('\n')[0],attributes:attributeText,blocks:graph.length,recursiveCalls:calls.filter(callee=>callee===fn.name).length,loops:groups};
        proofs.push(proof);writeFileSync(directory+'/proof/'+fn.name+'.ll',fn.body+'\n');
    }
    const hooks=[...ir.matchAll(/^(declare[^\n]*@benchmark_opaque_[^\n]*|\s*[^\n]*\bcall\b[^\n]*@benchmark_opaque_[^\n]*)$/gm)].map(match=>match[0]);
    const proof={name,ir:path,nativeRootHelperCalls:(ir.match(/\bcall\b[^\n]*@native_roots_(enter|leave)\(/g)||[]).length,numericHelperCalls:(ir.match(/\bcall\b[^\n]*@native_i64_(div|rem)_s\(/g)||[]).length,hooks,functions:proofs};
    writeFileSync(directory+'/proof.json',JSON.stringify(proof,null,2));
    const concise=proofs.map(fn=>({function:fn.function,recursiveCalls:fn.recursiveCalls,loops:fn.loops.map(loop=>({blocks:loop.blocks,hooks:loop.opaqueCalls,guestCalls:loop.guestCalls.length,indirectGuestCalls:loop.indirectGuestCalls,allocations:loop.allocationCalls,stores:loop.stores,floatingOperations:loop.floatingOperations})).filter(loop=>loop.hooks.length||loop.guestCalls||loop.allocations||loop.stores>2)})).filter(fn=>fn.recursiveCalls||fn.loops.length);
    summary.push({name,nativeRootHelperCalls:proof.nativeRootHelperCalls,numericHelperCalls:proof.numericHelperCalls,functions:concise});
}
writeFileSync(root+'/ir-proof-summary.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
