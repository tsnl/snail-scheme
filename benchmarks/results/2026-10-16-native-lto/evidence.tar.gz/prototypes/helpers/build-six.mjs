import {spawnSync} from 'node:child_process';
import {mkdirSync,writeFileSync,readFileSync,copyFileSync,readdirSync,symlinkSync,existsSync,realpathSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root='/tmp/snail-native-lto-20261016';
const probe=root+'/probe';
const output=probe+'/six';
const freeze='/tmp/sfir-native-parity-baseline-20261016';
const runtime=root+'/wasm-native';
const cases=process.argv.slice(2).length?process.argv.slice(2):['fib','fibfp','mbrot','array1','bv2string','gcbench'];
const target='x86_64-unknown-linux-gnu';
const sourceEnvironment=JSON.parse(readFileSync(freeze+'/timing/artifacts/fib/commands/sfir-native-shared-libraries/record.json')).environment;
const env={};
for(const [key,value]of Object.entries(sourceEnvironment)){if(value===null)delete env[key];else env[key]=value;}
mkdirSync(output+'/cargo-home',{recursive:true});
copyFileSync(freeze+'/toolchain/cargo-home/config.toml',output+'/cargo-home/config.toml');
env.CARGO_HOME=output+'/cargo-home';env.RUSTC_WRAPPER=runtime+'/scripts/rustc-native';
const rust=freeze+'/toolchain/rust';
const libc=env.SNAIL_NATIVE_LIBC;const gcc=env.SNAIL_NATIVE_GCC;
mkdirSync(output+'/system-libraries',{recursive:true});
if(!existsSync(output+'/system-libraries/libgcc_s.so'))symlinkSync(gcc+'/libgcc_s.so.1',output+'/system-libraries/libgcc_s.so');
const flags=['-C','linker='+rust+'/lib/rustlib/'+target+'/bin/rust-lld','-C','linker-flavor=ld.lld','-C','linker-plugin-lto','-C','lto=fat','-C','embed-bitcode=yes','-L','native='+output+'/system-libraries','-L','native='+libc,...[libc+'/Scrt1.o',libc+'/crti.o',libc+'/crtn.o','--dynamic-linker='+libc+'/ld-linux-x86-64.so.2','-rpath='+libc,'-rpath='+gcc,'--save-temps'].flatMap(value=>['-C','link-arg='+value])];
env.CARGO_ENCODED_RUSTFLAGS=flags.join('\x1f');
const sha=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
function run(command,directory,label,overrides={}){
    mkdirSync(directory,{recursive:true});
    const childEnvironment={...env,...overrides};const start=performance.now();
    const result=spawnSync(command[0],command.slice(1),{cwd:directory,env:childEnvironment,encoding:'utf8',maxBuffer:64*1024*1024,timeout:1800000});
    const record={command,environment:childEnvironment,status:result.status,signal:result.signal,error:result.error?.message,seconds:(performance.now()-start)/1000};
    writeFileSync(directory+'/'+label+'.stdout',result.stdout??'');writeFileSync(directory+'/'+label+'.stderr',result.stderr??'');
    writeFileSync(directory+'/'+label+'.json',JSON.stringify(record,null,2));
    if(result.status!==0)throw Error(label+' failed; see '+directory+'/'+label+'.stderr');
    return result;
}
function boundarySource(provider){
    const pattern=/#\[unsafe\(export_name = "([^"]+)"\)\]\s*pub extern "C" fn (\w+)\(([^)]*)\)(?:\s*->\s*(\w+))?\s*\{/g;
    const exports=[...readFileSync(provider,'utf8').matchAll(pattern)];
    if(exports.length!==(readFileSync(provider,'utf8').match(/export_name = /g)||[]).length)throw Error('Unexpected benchmark provider declarations: '+exports.length);
    let source='// Opaque benchmark imports, compiled once as machine code without std.\n#![no_std]\n';
    for(const [,symbol,name,parameters,result]of exports){
        const signature='('+parameters+')'+(result?' -> '+result:'');
        const argumentsText=parameters.split(',').filter(text=>text.trim()).map(text=>text.split(':')[0].trim()).join(', ');
        source+='unsafe extern "C" { #[link_name = '+JSON.stringify(symbol)+'] fn provider_'+name+signature+'; }\n';
        source+='#[unsafe(export_name = '+JSON.stringify('benchmark_opaque_'+symbol)+')]\npub extern "C" fn boundary_'+name+signature+' { unsafe { provider_'+name+'('+argumentsText+') } }\n';
    }
    return {source,symbols:exports.map(match=>match[1])};
}
const boundary=boundarySource(freeze+'/timing/artifacts/fib/scalar-provider.rs');
writeFileSync(output+'/boundary.rs',boundary.source);
run([env.RUSTC,'--crate-name','benchmark_boundary','--crate-type','lib','--edition','2024','--target',target,'--emit=obj','-C','opt-level=3','-C','panic=abort','-C','codegen-units=1','-C','lto=off','-C','embed-bitcode=no',output+'/boundary.rs','-o',output+'/boundary.o'],output,'build-boundary');
run(['llvm-objdump','-dr','--no-show-raw-insn',output+'/boundary.o'],output,'boundary-assembly');
function preparePhase(name,phase){
    const source=freeze+'/timing/artifacts/'+name;const directory=output+'/'+name+'/'+phase;
    mkdirSync(directory+'/provider',{recursive:true});
    copyFileSync(source+'/scalar-provider.rs',directory+'/scalar-provider.rs');
    let config=readFileSync(source+'/case-config.rs','utf8');
    if(phase==='diagnostic')config=config.replace('OBSERVE_BARRIERS: bool = false','OBSERVE_BARRIERS: bool = true');
    writeFileSync(directory+'/case-config.rs',config);
    copyFileSync(phase==='timing'?source+'/scalar-timing-entry.rs':freeze+'/validation/'+name+'/scalar-entry.rs',directory+'/entry.rs');
    const providerName='opaque_provider_'+name+'_'+phase;
    writeFileSync(directory+'/provider/Cargo.toml',`[package]\nname=${JSON.stringify(providerName)}\nversion="0.0.0"\nedition="2024"\n[lib]\npath=${JSON.stringify(directory+'/scalar-provider.rs')}\n`);
    return {directory,providerName};
}
function buildArm(name,phase,arm,prepared){
    const {directory,providerName}=prepared;const packageDirectory=directory+'/'+arm;
    mkdirSync(packageDirectory,{recursive:true});copyFileSync(directory+'/case-config.rs',packageDirectory+'/case-config.rs');
    const source=readFileSync(directory+'/entry.rs','utf8')+'\nextern crate snail_runtime as _;\nextern crate '+providerName+' as _;\n';
    writeFileSync(packageDirectory+'/main.rs',source);
    const packageName='opaque_'+name+'_'+phase+'_'+arm.replaceAll('-','_');
    writeFileSync(packageDirectory+'/Cargo.toml',`[package]\nname=${JSON.stringify(packageName)}\nversion="0.0.0"\nedition="2024"\n[[bin]]\nname=${JSON.stringify(packageName)}\npath="main.rs"\n[dependencies]\nsnail-runtime={path=${JSON.stringify(runtime)},features=["native-runtime"]}\n${providerName}={path="../provider"}\n[profile.release]\npanic="abort"\nlto=true\ncodegen-units=1\n`);
    const object=output+'/'+name+'/native/module.'+(arm==='lto'?'bc':'o');
    writeFileSync(packageDirectory+'/build.rs',`fn main() { println!("cargo:rustc-link-arg={}",${JSON.stringify(object)}); println!("cargo:rustc-link-arg={}",${JSON.stringify(output+'/boundary.o')}); }\n`);
    run([env.CARGO,'build','--offline','--release','--target',target,'--manifest-path',packageDirectory+'/Cargo.toml','--target-dir',output+'/target','-v'],packageDirectory,'build');
    const deps=output+'/target/'+target+'/release/deps';
    copyFileSync(output+'/target/'+target+'/release/'+packageName,packageDirectory+'/program');
    if(phase==='timing'&&arm==='lto'){
        for(const [suffix,filename]of [['.0.0.preopt.bc','pre-lto.ll'],['.0.4.opt.bc','post-lto.ll']]){
            const bitcode=readdirSync(deps).find(file=>file.startsWith(packageName+'-')&&file.endsWith(suffix));
            if(!bitcode)throw Error('Missing saved link bitcode for '+packageName);
            run(['llvm-dis',deps+'/'+bitcode,'-o',packageDirectory+'/'+filename],packageDirectory,'disassemble-'+filename);
        }
        run(['llvm-objdump','-d','--no-show-raw-insn',packageDirectory+'/program'],packageDirectory,'assembly');
    }
    console.log(name+' '+phase+' '+arm+' built');
    return {arm,program:packageDirectory+'/program',sha256:sha(packageDirectory+'/program')};
}
for(const name of cases){
    const source=freeze+'/timing/artifacts/'+name;const directory=output+'/'+name;
    mkdirSync(directory,{recursive:true});
    const phase=preparePhase(name,'timing');
    run([env.CHIBI,'-I',runtime+'/scheme',probe+'/lower-opaque.scm',runtime,source+'/program.wasm.raw.wasm',phase.directory+'/scalar-provider.rs',directory+'/native'],directory,'lower');
    if(sha(directory+'/native/optimized.wasm')!==sha(source+'/program.wasm'))throw Error(name+' canonical optimized Wasm changed');
    const sourceNative=readdirSync(source).find(file=>file.startsWith('program.native.native-'));
    const before=readFileSync(source+'/'+sourceNative+'/module.ll','utf8');
    let mapped=before;for(const symbol of boundary.symbols)mapped=mapped.replaceAll('@"'+symbol+'"','@"benchmark_opaque_'+symbol+'"');
    if(mapped!==readFileSync(directory+'/native/module.ll','utf8'))throw Error(name+' guest LLVM changed beyond import symbols');
    const arms=['matched-native','lto'].map(arm=>buildArm(name,'timing',arm,phase));
    const diagnostic=preparePhase(name,'diagnostic');
    const diagnosticArms=['matched-native','lto'].map(arm=>buildArm(name,'diagnostic',arm,diagnostic));
    const evidence={name,freeze:source,wasm:sha(source+'/program.wasm'),rawWasm:sha(source+'/program.wasm.raw.wasm'),nativeWasm:sha(directory+'/native/optimized.wasm'),nativeOnlyImportMapping:true,boundary:sha(output+'/boundary.o'),source:['scalar-provider.rs','scalar-timing-entry.rs','case-config.rs'].map(file=>({file,frozen:sha(source+'/'+file),private:sha(phase.directory+'/'+(file==='scalar-timing-entry.rs'?'entry.rs':file))})),arms,diagnosticArms,note:'Built for later parent-owned clean measurements; no clean timing performed here.'};
    writeFileSync(directory+'/evidence.json',JSON.stringify(evidence,null,2));
}
writeFileSync(output+'/build-summary.json',JSON.stringify({cases,flags,target,boundarySymbols:boundary.symbols,boundary:sha(output+'/boundary.o'),runtime,productCommit:'cf411e29',toolchain:rust},null,2));
