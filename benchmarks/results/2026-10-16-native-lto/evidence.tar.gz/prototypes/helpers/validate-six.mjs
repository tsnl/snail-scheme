import {spawnSync} from 'node:child_process';
import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';
const root='/tmp/snail-native-lto-20261016/probe/six';
const freeze='/tmp/sfir-native-parity-baseline-20261016';
const initial=JSON.parse(readFileSync(freeze+'/timing/artifacts/fib/commands/sfir-native-shared-libraries/record.json')).environment;
const env={};for(const [key,value]of Object.entries(initial))if(value!==null)env[key]=value;
const requested=process.argv.slice(2).filter(value=>!value.startsWith('--'));
const cases=requested.length?requested:['fib','fibfp','mbrot','array1','bv2string','gcbench'];
const phases=process.argv.includes('--timing')?['timing']:process.argv.includes('--diagnostic')?['diagnostic']:['timing','diagnostic'];
const results=[];
for(const name of cases)for(const phase of phases)for(const arm of ['matched-native','lto']){
    const directory=root+'/'+name+'/'+phase+'/'+arm+'/correctness';mkdirSync(directory,{recursive:true});
    const program=root+'/'+name+'/'+phase+'/'+arm+'/program';
    const childEnvironment={...env,SNAIL_PROCESS_RECORD:directory+'/process.json'};
    const command=[freeze+'/toolchain/snail-native-supervisor','--command','1800000','--',program];
    const result=spawnSync(command[0],command.slice(1),{cwd:directory,env:childEnvironment,encoding:'utf8',maxBuffer:16*1024*1024,timeout:1810000});
    writeFileSync(directory+'/stdout',result.stdout??'');writeFileSync(directory+'/stderr',result.stderr??'');
    const data=(result.stdout??'').split('\n').filter(line=>line.startsWith('{"result":')).map(line=>JSON.parse(line)).at(-1);
    const config=readFileSync(root+'/'+name+'/'+phase+'/case-config.rs','utf8');
    const expectedBarriers=Number(config.match(/EXPECTED_BARRIERS: i64 = (\d+)/)[1]);
    const record={name,phase,arm,command,environment:childEnvironment,status:result.status,signal:result.signal,error:result.error?.message,data,expectedBarriers,note:'One correctness execution, not a clean timing sample.'};
    writeFileSync(directory+'/result.json',JSON.stringify(record,null,2));results.push(record);
    if(result.status!==0||!data||(phase==='diagnostic'&&data.barriers!==expectedBarriers))throw Error(name+' '+phase+' '+arm+' predicate failed; see '+directory);
    console.log(name+' '+phase+' '+arm+' passed'+(phase==='diagnostic'?' barriers='+data.barriers:''));
}
writeFileSync(root+'/correctness-summary.json',JSON.stringify(results.map(({name,phase,arm,status,data,expectedBarriers})=>({name,phase,arm,status,data,expectedBarriers})),null,2));
