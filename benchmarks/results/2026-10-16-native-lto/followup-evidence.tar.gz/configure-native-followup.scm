(import (scheme base) (scheme file) (scheme write) (srfi 1)
        (wasm-native process) (sfir support))

(define (arm name route case . command)
  (append `((case . ,case) (name . ,name) (source_route . ,route))
          (if (null? command) '() `((command . ,(list->vector command))))))

(define provider
  (read-json "/tmp/snail-native-lto-black-box-20261016/timing-programs.json"))
(define programs (json-array (field provider 'programs)))
(for-each
 (lambda (program)
   (unless (equal? (file-sha256 (field program 'program)) (field program 'sha256))
     (error "reviewed provider binary changed" (field program 'case)))) programs)

(define arms
  (append
   (append-map
    (lambda (program)
      (let ((case (field program 'case)))
        (list (arm "baseline-native" "sfir-native" case)
              (arm "v8" "sfir-wasm" case)
              (arm "product-lto" "sfir-native" case (field program 'program))))) programs)
   (map
    (lambda (row)
      (arm (car row) "sfir-native" "array1"
           (string-append "/tmp/snail-native-lto-array-20261016/probe/" (cdr row) "/program")))
    '(("array-control" . "control") ("roots-boundary" . "noinline-roots")
      ("lto-zero-fill" . "zero-fill")))
   (map
    (lambda (row)
      (arm (car row) "sfir-native" "gcbench"
           (string-append "/tmp/snail-native-allocator-20261016/probe/gcbench-dead-blocks-20261016/"
                          (cdr row) "/program")))
    '(("gc-control" . "control") ("dead-blocks" . "skip-dead-blocks")))
   (append-map
    (lambda (case)
      (map (lambda (name)
             (arm (string-append "phase-" name) "sfir-native" case
                  (string-append "/tmp/snail-native-lto-array-20261016/probe/phase-order/"
                                 case "/" name "/program")))
           '("o3" "raw-as-layout"))) '("array1" "fib"))))

(write-json
 "build/native-parity-followup.json"
 `((freeze . "/tmp/sfir-native-parity-baseline-20261016") (cpu . 2)
   (quiet_window . "All task-owned build, test, and profiling workers finished before timing; agents explicitly held. The top-level backend test coordinator is suspended after its current worker exits, and resumes only after measurement. Host snapshots retain exact process states before and after. Ambient desktop processes remain; no exhaustive machine-wide quiet assertion. No other session contacted.")
   (arms . ,(list->vector arms))))
(display (length arms)) (display " fixed arms\n")
