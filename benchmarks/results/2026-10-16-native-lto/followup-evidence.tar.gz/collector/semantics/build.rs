fn main(){println!("cargo:rustc-link-arg={}","/tmp/snail-native-allocator-20261016/probe/gcbench-dead-blocks-20261016/semantics/module.o");}
