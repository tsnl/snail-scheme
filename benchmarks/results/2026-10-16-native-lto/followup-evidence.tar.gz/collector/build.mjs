import {readFileSync,writeFileSync,cpSync,mkdirSync,copyFileSync,chmodSync,symlinkSync,existsSync} from 'node:fs';
import {spawnSync,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='/tmp/snail-native-allocator-20261016/probe/gcbench-dead-blocks-20261016';
const repo='/tmp/snail-native-allocator-20261016';
const source='/tmp/snail-native-lto-20261016/probe/six/gcbench/timing/lto';
const build=JSON.parse(readFileSync(source+'/build.json'));
const runtime=root+'/runtime';mkdirSync(runtime,{recursive:true});
for(const name of ['src','scheme','scripts'])cpSync(repo+'/wasm-native/'+name,runtime+'/'+name,{recursive:true});
for(const name of ['Cargo.toml','Cargo.lock','src/native.rs','src/native_gc.rs'])copyFileSync(repo+'/probe/lto-final-target/runtime/'+name,runtime+'/'+name);
mkdirSync(root+'/cargo-home',{recursive:true});copyFileSync('/tmp/snail-native-lto-20261016/probe/six/cargo-home/config.toml',root+'/cargo-home/config.toml');
mkdirSync(root+'/system-libraries',{recursive:true});if(!existsSync(root+'/system-libraries/libgcc_s.so'))symlinkSync(build.environment.SNAIL_NATIVE_GCC+'/libgcc_s.so.1',root+'/system-libraries/libgcc_s.so');
mkdirSync(root+'/provider',{recursive:true});
for(const name of ['case-config.rs','scalar-provider.rs'])copyFileSync(source+'/../'+name,root+'/'+name);
copyFileSync('/tmp/snail-native-lto-20261016/probe/six/gcbench/native/module.bc',root+'/module.bc');
copyFileSync('/tmp/snail-native-lto-20261016/probe/six/boundary.o',root+'/boundary.o');
writeFileSync(root+'/provider/Cargo.toml','[package]\nname="opaque_provider_gcbench_timing"\nversion="0.0.0"\nedition="2024"\n[lib]\npath='+JSON.stringify(root+'/scalar-provider.rs')+'\n');
const env={...process.env,...build.environment,CARGO_HOME:root+'/cargo-home',RUSTC_WRAPPER:runtime+'/scripts/rustc-native'};
env.CARGO_ENCODED_RUSTFLAGS=env.CARGO_ENCODED_RUSTFLAGS.replaceAll('/tmp/snail-native-lto-20261016/probe/six/system-libraries',root+'/system-libraries');
const packageDir=root+'/package';mkdirSync(packageDir,{recursive:true});copyFileSync(source+'/main.rs',packageDir+'/main.rs');copyFileSync(source+'/case-config.rs',packageDir+'/case-config.rs');
writeFileSync(packageDir+'/Cargo.toml','[package]\nname="opaque_gcbench_timing_lto"\nversion="0.0.0"\nedition="2024"\n[[bin]]\nname="opaque_gcbench_timing_lto"\npath="main.rs"\n[dependencies]\nsnail-runtime={path='+JSON.stringify(runtime)+',features=["native-runtime"]}\nopaque_provider_gcbench_timing={path="../provider"}\n[profile.release]\npanic="abort"\nlto=true\ncodegen-units=1\n');
writeFileSync(packageDir+'/build.rs','fn main(){println!("cargo:rustc-link-arg={}",'+JSON.stringify(root+'/module.bc')+');println!("cargo:rustc-link-arg={}",'+JSON.stringify(root+'/boundary.o')+');}\n');
const sha=buffer=>createHash('sha256').update(buffer).digest('hex');
const args=['build','--offline','--release','--target','x86_64-unknown-linux-gnu','--manifest-path',packageDir+'/Cargo.toml','--target-dir',root+'/target','-v'];
const rows=[];
for(const arm of ['control','skip-dead-blocks']){
 if(arm==='skip-dead-blocks'){
 const file=runtime+'/src/native_gc.rs';const before=readFileSync(file,'utf8');
 const old='            unsafe { self.sweep_starts(region, index) };\n            let block = &mut self.regions[region].blocks[index];\n            block.live_lines = block.lines.iter().filter(|&&line| line != 0).count();\n            if block.live_lines == 0 {\n                block.span = 0;\n            }';
 const after='            let live_lines = self.regions[region].blocks[index]\n                .lines.iter().filter(|&&line| line != 0).count();\n            if live_lines == 0 {\n                // Finalizers already ran. Exact membership rejects all dead\n                // starts; allocation clears storage before its next use.\n                self.regions[region].blocks[index].starts.fill(0);\n            } else {\n                unsafe { self.sweep_starts(region, index) };\n            }\n            let block = &mut self.regions[region].blocks[index];\n            block.live_lines = live_lines;\n            if live_lines == 0 {\n                block.span = 0;\n            }';
 if(!before.includes(old))throw Error('sweep body differs');writeFileSync(root+'/control-native_gc.rs',before);writeFileSync(file,before.replace(old,after));
 const rustfmt=spawnSync('rustfmt',[file],{encoding:'utf8'});if(rustfmt.status!==0)throw Error(rustfmt.stderr);
 }
 const output=root+'/'+arm;mkdirSync(output,{recursive:true});
 writeFileSync(output+'/command.json',JSON.stringify({command:[build.command[0],...args],environment:env},null,2)+'\n');
 const result=spawnSync(build.command[0],args,{cwd:packageDir,env,encoding:'utf8'});
 writeFileSync(output+'/build.stdout',result.stdout??'');writeFileSync(output+'/build.stderr',result.stderr??'');
 console.log(arm,'build',result.status,result.error?.message??'');if(result.status!==0)process.exit(result.status??1);
 copyFileSync(root+'/target/x86_64-unknown-linux-gnu/release/opaque_gcbench_timing_lto',output+'/program');chmodSync(output+'/program',0o755);
 rows.push({arm,program:output+'/program',binary:sha(readFileSync(output+'/program')),runtimeNative:sha(readFileSync(runtime+'/src/native.rs')),runtimeGc:sha(readFileSync(runtime+'/src/native_gc.rs')),zeroFillGuard:false,finalExactFlags:false,cleanTiming:'not-measured'});
 copyFileSync(runtime+'/src/native_gc.rs',output+'/native_gc.rs');
}
writeFileSync(root+'/arms.json',JSON.stringify(rows,null,2)+'\n');
