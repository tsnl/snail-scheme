(import (scheme base) (scheme cxr) (scheme process-context) (srfi 1)
        (wasm-native process) (sfir support))

(define input (cadr (command-line)))
(define output (caddr (command-line)))
(define measurement (read-json input))
(define rows (json-array (field measurement 'rows)))
(define attempts (json-array (field measurement 'attempts)))
(unless (and (equal? (field measurement 'status) "complete")
             (= 162 (length attempts)) (= 27 (length rows))
             (every (lambda (attempt) (equal? (field attempt 'status) "passed")) attempts)
             (every (lambda (row) (and (field row 'complete) (= 5 (length (json-array (field row 'seconds)))))) rows))
  (error "follow-up schedule is not complete and passing"))

(define comparisons
  '((product_over_baseline "product-lto" "baseline-native")
    (product_over_v8 "product-lto" "v8")
    (dead_blocks_over_control "dead-blocks" "gc-control")
    (raw_over_preoptimized "phase-raw-as-layout" "phase-o3")
    (roots_boundary_over_control "roots-boundary" "array-control")
    (zero_fill_over_control "lto-zero-fill" "array-control")))

(define (summarize case)
  (let* ((selected (filter (lambda (row) (equal? case (field row 'case))) rows))
         (medians (map (lambda (row) (cons (string->symbol (field row 'route)) (field row 'median))) selected)))
    `((case . ,case) (medians . ,medians)
      (ratios . ,(filter-map
                  (lambda (comparison)
                    (let ((left (assq (string->symbol (cadr comparison)) medians))
                          (right (assq (string->symbol (caddr comparison)) medians)))
                      (and left right (cons (car comparison) (/ (cdr left) (cdr right)))))) comparisons))
      (arms . ,(list->vector selected)))))

(write-json
 output
 `((status . "complete") (attempt_count . ,(length attempts))
   (baseline_revision . "313cec8752b1fcd3b7a2577f3fc65b96ea1b9dd3")
   (product_revision . "90edf1b1e93af6ace69eb907dd65d91021758d5c")
   (provider_revision . "835cd98b3e24d75a132d75a5e801ed9edd7c6183")
   (measurement_sha256 . ,(file-sha256 input))
   (cases . ,(list->vector (map summarize '("fib" "fibfp" "mbrot" "array1" "bv2string" "gcbench"))))))
