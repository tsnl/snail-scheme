#!/bin/sh
set -u
array_root=/tmp/snail-native-lto-array-20261016
array_name=$1
array_binary=$2
mkdir -p "$array_root/probe/$array_name"
export SNAIL_PROCESS_RECORD="$array_root/probe/$array_name/process.json"
/nix/store/apffmxq24i2xf89m4llsz4yc2sc1bv94-perf-linux-7.2.3/bin/perf stat -x, --no-big-num -e 'cpu_core/cycles/u,cpu_core/event=3,umask=4/u,cpu_core/event=3,umask=0xa1/u,cpu_core/event=0xd1,umask=1/u,cpu_core/event=0xd1,umask=0/u,cpu_core/event=0xd1,umask=8/u' -o "$array_root/probe/$array_name/stat.csv" -- taskset -c 2 /tmp/sfir-native-parity-baseline-20261016/toolchain/snail-native-supervisor --command 120000 -- "$array_binary" > "$array_root/probe/$array_name/stdout" 2> "$array_root/probe/$array_name/stderr"
array_result=$?
printf '%s\n' "$array_result" > "$array_root/probe/$array_name/exit"
exit "$array_result"
