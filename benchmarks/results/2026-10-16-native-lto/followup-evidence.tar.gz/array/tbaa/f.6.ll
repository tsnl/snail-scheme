define internal tailcc i64 @f.6(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  %v919 = icmp slt i64 %arg1, 0
  br i1 %v919, label %then14, label %else13.preheader.split

else13.preheader.split:                           ; preds = %entry
  %v41.first_iter = icmp samesign ugt i64 %arg1, 4294967295
  %0 = icmp ne i64 %arg0, 0
  %1 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %1, 0
  %or.cond = and i1 %0, %.not.i
  br i1 %or.cond, label %2, label %else13.preheader

2:                                                ; preds = %else13.preheader.split
  %3 = inttoptr i64 %arg0 to ptr
  %4 = load i64, ptr %3, align 8, !noundef !39
  %5 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %6 = icmp eq ptr %5, null
  br i1 %6, label %19, label %7

7:                                                ; preds = %2
  switch i64 %4, label %8 [
    i64 6, label %.loopexit19
    i64 0, label %.loopexit19
  ]

8:                                                ; preds = %7
  %9 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %10 = load i64, ptr %9, align 8, !noundef !39
  %11 = lshr i64 %4, 2
  %12 = add nsw i64 %11, -1
  %13 = icmp ult i64 %12, %10
  br i1 %13, label %14, label %.loopexit18

14:                                               ; preds = %8
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %16 = load ptr, ptr %15, align 8, !nonnull !39, !noundef !39
  %17 = getelementptr inbounds nuw i64, ptr %16, i64 %12
  %18 = load i64, ptr %17, align 8, !noundef !39
  switch i64 %18, label %.preheader17 [
    i64 6, label %.loopexit19
    i64 0, label %.loopexit19
  ]

19:                                               ; preds = %2
  tail call fastcc void @native_trap() #113
  unreachable

.loopexit19:                                      ; preds = %25, %25, %14, %14, %7, %7
  %.in = phi i64 [ %4, %7 ], [ %18, %14 ], [ %18, %14 ], [ %4, %7 ], [ %27, %25 ], [ %27, %25 ]
  %20 = icmp eq i64 %.in, 6
  br label %else13.preheader

else13.preheader:                                 ; preds = %.loopexit19, %else13.preheader.split
  %phi.call.shrunk.ph = phi i1 [ false, %else13.preheader.split ], [ %20, %.loopexit19 ]
  br label %else13

.preheader17:                                     ; preds = %25, %14
  %21 = phi i64 [ %27, %25 ], [ %18, %14 ]
  %22 = lshr i64 %21, 2
  %23 = add nsw i64 %22, -1
  %24 = icmp ult i64 %23, %10
  br i1 %24, label %25, label %.loopexit18

.loopexit18:                                      ; preds = %.preheader17, %8
  tail call fastcc void @native_trap() #113
  unreachable

25:                                               ; preds = %.preheader17
  %26 = getelementptr inbounds nuw i64, ptr %16, i64 %23
  %27 = load i64, ptr %26, align 8, !noundef !39
  switch i64 %27, label %.preheader17 [
    i64 6, label %.loopexit19
    i64 0, label %.loopexit19
  ]

then14:                                           ; preds = %ok136, %entry
  %arg0.tr.lcssa = phi i64 [ %arg0, %entry ], [ %v139, %ok136 ]
  %28 = icmp ne i64 %arg0.tr.lcssa, 0
  %29 = and i64 %arg0.tr.lcssa, 1
  %.not.i3 = icmp eq i64 %29, 0
  %or.cond30 = and i1 %28, %.not.i3
  br i1 %or.cond30, label %30, label %trap19

30:                                               ; preds = %then14
  %31 = inttoptr i64 %arg0.tr.lcssa to ptr
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %34 = icmp eq ptr %33, null
  br i1 %34, label %47, label %35

35:                                               ; preds = %30
  switch i64 %32, label %36 [
    i64 6, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

36:                                               ; preds = %35
  %37 = getelementptr inbounds nuw i8, ptr %33, i64 360
  %38 = load i64, ptr %37, align 8, !noundef !39
  %39 = lshr i64 %32, 2
  %40 = add nsw i64 %39, -1
  %41 = icmp ult i64 %40, %38
  br i1 %41, label %42, label %.loopexit

42:                                               ; preds = %36
  %43 = getelementptr inbounds nuw i8, ptr %33, i64 352
  %44 = load ptr, ptr %43, align 8, !nonnull !39, !noundef !39
  %45 = getelementptr inbounds nuw i64, ptr %44, i64 %40
  %46 = load i64, ptr %45, align 8, !noundef !39
  switch i64 %46, label %.preheader [
    i64 6, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

47:                                               ; preds = %30
  tail call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %52, %42
  %48 = phi i64 [ %54, %52 ], [ %46, %42 ]
  %49 = lshr i64 %48, 2
  %50 = add nsw i64 %49, -1
  %51 = icmp ult i64 %50, %38
  br i1 %51, label %52, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %36
  tail call fastcc void @native_trap() #113
  unreachable

52:                                               ; preds = %.preheader
  %53 = getelementptr inbounds nuw i64, ptr %44, i64 %50
  %54 = load i64, ptr %53, align 8, !noundef !39
  switch i64 %54, label %.preheader [
    i64 6, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

native_ref_test.exit4:                            ; preds = %52, %52, %42, %42, %35, %35
  %.in44 = phi i64 [ %32, %35 ], [ %46, %42 ], [ %46, %42 ], [ %32, %35 ], [ %54, %52 ], [ %54, %52 ]
  %55 = icmp eq i64 %.in44, 6
  br i1 %55, label %ok23, label %trap19

trap19:                                           ; preds = %native_ref_test.exit4, %then14
  tail call fastcc void @native_trap()
  unreachable

ok23:                                             ; preds = %native_ref_test.exit4
  %v25 = getelementptr i8, ptr %31, i64 16
  %v26 = load i64, ptr %v25, align 1, !tbaa !75599
  ret i64 %v26

else13:                                           ; preds = %else13.backedge, %else13.preheader
  %phi.call.shrunk = phi i1 [ %phi.call.shrunk.ph, %else13.preheader ], [ %phi.call.shrunk.be, %else13.backedge ]
  %arg1.tr21 = phi i64 [ %arg1, %else13.preheader ], [ %v141, %else13.backedge ]
  %arg0.tr20 = phi i64 [ %arg0, %else13.preheader ], [ %v139, %else13.backedge ]
  br i1 %phi.call.shrunk, label %ok31, label %trap30

trap30:                                           ; preds = %else13
  tail call fastcc void @native_trap()
  unreachable

ok31:                                             ; preds = %else13
  %v32.not = icmp eq i64 %arg0.tr20, 0
  br i1 %v32.not, label %trap33, label %ok34

trap33:                                           ; preds = %ok31
  tail call fastcc void @native_trap()
  unreachable

ok34:                                             ; preds = %ok31
  %v35 = inttoptr i64 %arg0.tr20 to ptr
  %v36 = getelementptr i8, ptr %v35, i64 16
  %v37 = load i64, ptr %v36, align 1, !tbaa !75599
  br i1 %v41.first_iter, label %then45, label %ok50

then45:                                           ; preds = %ok34
  tail call fastcc void @native_trap()
  unreachable

ok50:                                             ; preds = %ok34
  %v52 = getelementptr i8, ptr %v35, i64 8
  %v53 = load i64, ptr %v52, align 1, !tbaa !75599
  %v56.not = icmp eq i64 %v53, 0
  br i1 %v56.not, label %trap57, label %ok58

trap57:                                           ; preds = %ok50
  tail call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %ok50
  %v59 = and i64 %v53, 1
  %v60 = icmp eq i64 %v59, 0
  br i1 %v60, label %ok62, label %trap61

trap61:                                           ; preds = %ok58
  tail call fastcc void @native_trap()
  unreachable

ok62:                                             ; preds = %ok58
  %v63 = inttoptr i64 %v53 to ptr
  %v64 = getelementptr i8, ptr %v63, i64 8
  %v65 = load i64, ptr %v64, align 1
  %v67 = icmp ult i64 %arg1.tr21, %v65
  br i1 %v67, label %ok69, label %trap68

trap68:                                           ; preds = %ok62
  tail call fastcc void @native_trap()
  unreachable

ok69:                                             ; preds = %ok62
  %v71 = getelementptr i8, ptr %v63, i64 16
  %v72 = getelementptr i64, ptr %v71, i64 %arg1.tr21
  %v73 = load i64, ptr %v72, align 1, !tbaa !86540
  %v85.not = icmp eq i64 %v37, 0
  br i1 %v85.not, label %trap86, label %ok87

trap86:                                           ; preds = %ok69
  tail call fastcc void @native_trap()
  unreachable

ok87:                                             ; preds = %ok69
  %v88 = and i64 %v37, 1
  %v89 = icmp eq i64 %v88, 0
  br i1 %v89, label %ok91, label %trap90

trap90:                                           ; preds = %ok87
  tail call fastcc void @native_trap()
  unreachable

ok91:                                             ; preds = %ok87
  %v92 = inttoptr i64 %v37 to ptr
  %v93 = getelementptr i8, ptr %v92, i64 8
  %v94 = load i64, ptr %v93, align 1
  %v96 = icmp ult i64 %arg1.tr21, %v94
  br i1 %v96, label %ok98, label %trap97

trap97:                                           ; preds = %ok91
  tail call fastcc void @native_trap()
  unreachable

ok98:                                             ; preds = %ok91
  %v100 = getelementptr i8, ptr %v92, i64 16
  %v101 = getelementptr i64, ptr %v100, i64 %arg1.tr21
  store i64 %v73, ptr %v101, align 1, !tbaa !86540
  %v107 = getelementptr i8, ptr %v35, i64 24
  %v108 = load i64, ptr %v107, align 1, !tbaa !75599
  %v109.not = icmp eq i64 %v108, 0
  br i1 %v109.not, label %trap110, label %ok111

trap110:                                          ; preds = %ok98
  tail call fastcc void @native_trap()
  unreachable

ok111:                                            ; preds = %ok98
  %v112 = inttoptr i64 %v108 to ptr
  %v113 = getelementptr i8, ptr %v112, i64 8
  %v114 = load i32, ptr %v113, align 1, !tbaa !75599
  %v115 = icmp eq i32 %v114, 0
  br i1 %v115, label %then119, label %ok130

then119:                                          ; preds = %ok111
  tail call fastcc void @native_trap()
  unreachable

ok130:                                            ; preds = %ok111
  %v132 = getelementptr i8, ptr %v112, i64 16
  %v133 = load i64, ptr %v132, align 1, !tbaa !75599
  %v134.not = icmp eq i64 %v133, 0
  br i1 %v134.not, label %trap135, label %ok136

trap135:                                          ; preds = %ok130
  tail call fastcc void @native_trap()
  unreachable

ok136:                                            ; preds = %ok130
  %v137 = inttoptr i64 %v133 to ptr
  %v138 = getelementptr i8, ptr %v137, i64 16
  %v139 = load i64, ptr %v138, align 1, !tbaa !75599
  %v9 = icmp eq i64 %arg1.tr21, 0
  br i1 %v9, label %then14, label %ok136.split

ok136.split:                                      ; preds = %ok136
  %v141 = add nsw i64 %arg1.tr21, -1
  %56 = icmp ne i64 %v139, 0
  %57 = and i64 %v139, 1
  %.not.i6 = icmp eq i64 %57, 0
  %or.cond31 = and i1 %56, %.not.i6
  br i1 %or.cond31, label %58, label %else13.backedge

else13.backedge:                                  ; preds = %.loopexit15, %ok136.split
  %phi.call.shrunk.be = phi i1 [ false, %ok136.split ], [ %76, %.loopexit15 ]
  br label %else13

58:                                               ; preds = %ok136.split
  %59 = inttoptr i64 %v139 to ptr
  %60 = load i64, ptr %59, align 8, !noundef !39
  %61 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %62 = icmp eq ptr %61, null
  br i1 %62, label %75, label %63

63:                                               ; preds = %58
  switch i64 %60, label %64 [
    i64 6, label %.loopexit15
    i64 0, label %.loopexit15
  ]

64:                                               ; preds = %63
  %65 = getelementptr inbounds nuw i8, ptr %61, i64 360
  %66 = load i64, ptr %65, align 8, !noundef !39
  %67 = lshr i64 %60, 2
  %68 = add nsw i64 %67, -1
  %69 = icmp ult i64 %68, %66
  br i1 %69, label %70, label %.loopexit14

70:                                               ; preds = %64
  %71 = getelementptr inbounds nuw i8, ptr %61, i64 352
  %72 = load ptr, ptr %71, align 8, !nonnull !39, !noundef !39
  %73 = getelementptr inbounds nuw i64, ptr %72, i64 %68
  %74 = load i64, ptr %73, align 8, !noundef !39
  switch i64 %74, label %.preheader13 [
    i64 6, label %.loopexit15
    i64 0, label %.loopexit15
  ]

75:                                               ; preds = %58
  tail call fastcc void @native_trap() #113
  unreachable

.loopexit15:                                      ; preds = %81, %81, %70, %70, %63, %63
  %.in43 = phi i64 [ %60, %63 ], [ %74, %70 ], [ %74, %70 ], [ %60, %63 ], [ %83, %81 ], [ %83, %81 ]
  %76 = icmp eq i64 %.in43, 6
  br label %else13.backedge

.preheader13:                                     ; preds = %81, %70
  %77 = phi i64 [ %83, %81 ], [ %74, %70 ]
  %78 = lshr i64 %77, 2
  %79 = add nsw i64 %78, -1
  %80 = icmp ult i64 %79, %66
  br i1 %80, label %81, label %.loopexit14

.loopexit14:                                      ; preds = %.preheader13, %64
  tail call fastcc void @native_trap() #113
  unreachable

81:                                               ; preds = %.preheader13
  %82 = getelementptr inbounds nuw i64, ptr %72, i64 %79
  %83 = load i64, ptr %82, align 8, !noundef !39
  switch i64 %83, label %.preheader13 [
    i64 6, label %.loopexit15
    i64 0, label %.loopexit15
  ]
}
