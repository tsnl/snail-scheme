define internal tailcc i64 @f.8(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  %0 = icmp ne i64 %arg0, 0
  %1 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %1, 0
  %or.cond = and i1 %0, %.not.i
  br i1 %or.cond, label %2, label %trap9

2:                                                ; preds = %entry
  %3 = inttoptr i64 %arg0 to ptr
  %4 = load i64, ptr %3, align 8, !noundef !39
  %5 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %6 = icmp eq ptr %5, null
  br i1 %6, label %19, label %7

7:                                                ; preds = %2
  switch i64 %4, label %8 [
    i64 14, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

8:                                                ; preds = %7
  %9 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %10 = load i64, ptr %9, align 8, !noundef !39
  %11 = lshr i64 %4, 2
  %12 = add nsw i64 %11, -1
  %13 = icmp ult i64 %12, %10
  br i1 %13, label %14, label %.loopexit10

14:                                               ; preds = %8
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %16 = load ptr, ptr %15, align 8, !nonnull !39, !noundef !39
  %17 = getelementptr inbounds nuw i64, ptr %16, i64 %12
  %18 = load i64, ptr %17, align 8, !noundef !39
  switch i64 %18, label %.preheader9 [
    i64 14, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

19:                                               ; preds = %2
  tail call fastcc void @native_trap() #113
  unreachable

.preheader9:                                      ; preds = %24, %14
  %20 = phi i64 [ %26, %24 ], [ %18, %14 ]
  %21 = lshr i64 %20, 2
  %22 = add nsw i64 %21, -1
  %23 = icmp ult i64 %22, %10
  br i1 %23, label %24, label %.loopexit10

.loopexit10:                                      ; preds = %.preheader9, %8
  tail call fastcc void @native_trap() #113
  unreachable

24:                                               ; preds = %.preheader9
  %25 = getelementptr inbounds nuw i64, ptr %16, i64 %22
  %26 = load i64, ptr %25, align 8, !noundef !39
  switch i64 %26, label %.preheader9 [
    i64 14, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %24, %24, %14, %14, %7, %7
  %.in = phi i64 [ %4, %7 ], [ %18, %14 ], [ %18, %14 ], [ %4, %7 ], [ %26, %24 ], [ %26, %24 ]
  %27 = icmp eq i64 %.in, 14
  br i1 %27, label %ok13, label %trap9

trap9:                                            ; preds = %native_ref_test.exit3, %ok112, %native_ref_test.exit, %entry
  tail call fastcc void @native_trap()
  unreachable

ok13:                                             ; preds = %native_ref_test.exit3, %native_ref_test.exit
  %arg1.tr17 = phi i64 [ %v117, %native_ref_test.exit3 ], [ %arg1, %native_ref_test.exit ]
  %arg0.tr16 = phi i64 [ %v115, %native_ref_test.exit3 ], [ %arg0, %native_ref_test.exit ]
  %v14 = inttoptr i64 %arg0.tr16 to ptr
  %v15 = getelementptr i8, ptr %v14, i64 8
  %v16 = load i64, ptr %v15, align 1, !tbaa !75599
  %v18.not = icmp sgt i64 %v16, %arg1.tr17
  br i1 %v18.not, label %else22, label %ok28

ok28:                                             ; preds = %ok13
  %v14.lcssa = phi ptr [ %v14, %ok13 ]
  %v30 = getelementptr i8, ptr %v14.lcssa, i64 16
  %v31 = load i64, ptr %v30, align 1, !tbaa !75599
  %v32.not = icmp eq i64 %v31, 0
  br i1 %v32.not, label %trap33, label %ok34

trap33:                                           ; preds = %ok28
  tail call fastcc void @native_trap()
  unreachable

ok34:                                             ; preds = %ok28
  %v35 = inttoptr i64 %v31 to ptr
  %v36 = getelementptr i8, ptr %v35, i64 8
  %v37 = load i64, ptr %v36, align 1, !tbaa !75599
  ret i64 %v37

else22:                                           ; preds = %ok13
  %v39 = icmp ugt i64 %arg1.tr17, 4294967295
  br i1 %v39, label %then43, label %ok48

then43:                                           ; preds = %else22
  tail call fastcc void @native_trap()
  unreachable

ok48:                                             ; preds = %else22
  %v50 = getelementptr i8, ptr %v14, i64 16
  %v51 = load i64, ptr %v50, align 1, !tbaa !75599
  %v52.not = icmp eq i64 %v51, 0
  br i1 %v52.not, label %trap53, label %ok54

trap53:                                           ; preds = %ok48
  tail call fastcc void @native_trap()
  unreachable

ok54:                                             ; preds = %ok48
  %v55 = inttoptr i64 %v51 to ptr
  %v56 = getelementptr i8, ptr %v55, i64 8
  %v57 = load i64, ptr %v56, align 1, !tbaa !75599
  %v61.not = icmp eq i64 %v57, 0
  br i1 %v61.not, label %trap62, label %ok63

trap62:                                           ; preds = %ok54
  tail call fastcc void @native_trap()
  unreachable

ok63:                                             ; preds = %ok54
  %v64 = and i64 %v57, 1
  %v65 = icmp eq i64 %v64, 0
  br i1 %v65, label %ok67, label %trap66

trap66:                                           ; preds = %ok63
  tail call fastcc void @native_trap()
  unreachable

ok67:                                             ; preds = %ok63
  %v68 = inttoptr i64 %v57 to ptr
  %v69 = getelementptr i8, ptr %v68, i64 8
  %v70 = load i64, ptr %v69, align 1
  %v72 = icmp ult i64 %arg1.tr17, %v70
  br i1 %v72, label %ok74, label %trap73

trap73:                                           ; preds = %ok67
  tail call fastcc void @native_trap()
  unreachable

ok74:                                             ; preds = %ok67
  %v76 = getelementptr i8, ptr %v68, i64 16
  %v77 = getelementptr i64, ptr %v76, i64 %arg1.tr17
  store i64 %arg1.tr17, ptr %v77, align 1, !tbaa !86540
  %v83 = getelementptr i8, ptr %v14, i64 24
  %v84 = load i64, ptr %v83, align 1, !tbaa !75599
  %v85.not = icmp eq i64 %v84, 0
  br i1 %v85.not, label %trap86, label %ok87

trap86:                                           ; preds = %ok74
  tail call fastcc void @native_trap()
  unreachable

ok87:                                             ; preds = %ok74
  %v88 = inttoptr i64 %v84 to ptr
  %v89 = getelementptr i8, ptr %v88, i64 8
  %v90 = load i32, ptr %v89, align 1, !tbaa !75599
  %v91 = icmp eq i32 %v90, 0
  br i1 %v91, label %then95, label %ok106

then95:                                           ; preds = %ok87
  tail call fastcc void @native_trap()
  unreachable

ok106:                                            ; preds = %ok87
  %v108 = getelementptr i8, ptr %v88, i64 16
  %v109 = load i64, ptr %v108, align 1, !tbaa !75599
  %v110.not = icmp eq i64 %v109, 0
  br i1 %v110.not, label %trap111, label %ok112

trap111:                                          ; preds = %ok106
  tail call fastcc void @native_trap()
  unreachable

ok112:                                            ; preds = %ok106
  %v113 = inttoptr i64 %v109 to ptr
  %v114 = getelementptr i8, ptr %v113, i64 16
  %v115 = load i64, ptr %v114, align 1, !tbaa !75599
  %v117 = add nuw nsw i64 %arg1.tr17, 1
  %28 = icmp ne i64 %v115, 0
  %29 = and i64 %v115, 1
  %.not.i2 = icmp eq i64 %29, 0
  %or.cond39 = and i1 %28, %.not.i2
  br i1 %or.cond39, label %30, label %trap9

30:                                               ; preds = %ok112
  %31 = inttoptr i64 %v115 to ptr
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %34 = icmp eq ptr %33, null
  br i1 %34, label %47, label %35

35:                                               ; preds = %30
  switch i64 %32, label %36 [
    i64 14, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

36:                                               ; preds = %35
  %37 = getelementptr inbounds nuw i8, ptr %33, i64 360
  %38 = load i64, ptr %37, align 8, !noundef !39
  %39 = lshr i64 %32, 2
  %40 = add nsw i64 %39, -1
  %41 = icmp ult i64 %40, %38
  br i1 %41, label %42, label %.loopexit

42:                                               ; preds = %36
  %43 = getelementptr inbounds nuw i8, ptr %33, i64 352
  %44 = load ptr, ptr %43, align 8, !nonnull !39, !noundef !39
  %45 = getelementptr inbounds nuw i64, ptr %44, i64 %40
  %46 = load i64, ptr %45, align 8, !noundef !39
  switch i64 %46, label %.preheader [
    i64 14, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

47:                                               ; preds = %30
  tail call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %52, %42
  %48 = phi i64 [ %54, %52 ], [ %46, %42 ]
  %49 = lshr i64 %48, 2
  %50 = add nsw i64 %49, -1
  %51 = icmp ult i64 %50, %38
  br i1 %51, label %52, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %36
  tail call fastcc void @native_trap() #113
  unreachable

52:                                               ; preds = %.preheader
  %53 = getelementptr inbounds nuw i64, ptr %44, i64 %50
  %54 = load i64, ptr %53, align 8, !noundef !39
  switch i64 %54, label %.preheader [
    i64 14, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

native_ref_test.exit3:                            ; preds = %52, %52, %42, %42, %35, %35
  %.in47 = phi i64 [ %32, %35 ], [ %46, %42 ], [ %46, %42 ], [ %32, %35 ], [ %54, %52 ], [ %54, %52 ]
  %55 = icmp eq i64 %.in47, 14
  br i1 %55, label %ok13, label %trap9
}
