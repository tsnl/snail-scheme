define internal tailcc i64 @f.3(i64 %arg0) unnamed_addr #105 personality ptr @rust_eh_personality {
entry:
  %v6 = icmp slt i64 %arg0, 2
  br i1 %v6, label %native_roots_leave.exit, label %else10

else10:                                           ; preds = %entry
  %v14.b = load i1, ptr @g.4, align 1
  br i1 %v14.b, label %block17, label %then19

then19:                                           ; preds = %else10
  tail call fastcc void @native_trap()
  unreachable

block17:                                          ; preds = %else10
  %v21 = load i64, ptr @g.3, align 8
  %v22.not = icmp eq i64 %v21, 0
  br i1 %v22.not, label %trap23, label %ok24

trap23:                                           ; preds = %block17
  tail call fastcc void @native_trap()
  unreachable

ok24:                                             ; preds = %block17
  %v26 = add nsw i64 %arg0, -1
  %v28 = tail call tailcc i64 @f.3(i64 %v26)
  %v29.b = load i1, ptr @g.4, align 1
  br i1 %v29.b, label %block32, label %then34

then34:                                           ; preds = %ok24
  tail call fastcc void @native_trap()
  unreachable

block32:                                          ; preds = %ok24
  %v36 = load i64, ptr @g.3, align 8
  %v37.not = icmp eq i64 %v36, 0
  br i1 %v37.not, label %trap38, label %ok39

trap38:                                           ; preds = %block32
  tail call fastcc void @native_trap()
  unreachable

ok39:                                             ; preds = %block32
  %v41 = add nsw i64 %arg0, -2
  %v43 = tail call tailcc i64 @f.3(i64 %v41)
  %v45 = add i64 %v43, %v28
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %ok39, %entry
  %slot8.0 = phi i64 [ %v45, %ok39 ], [ %arg0, %entry ]
  ret i64 %slot8.0
}
