# Prelink phase-order ablation

Four prepared executables are frozen at:

```
/tmp/snail-native-lto-array-20261016/probe/phase-order/{array1,fib}/{o3,raw-as-layout}/program
```

All passed their unchanged complete final predicate: array1 `1000000`, fib
`102334155`. Supervisor records confirm exit 0, no timeout, and all descendants
gone. These were preparation/correctness executions, not a clean timing
campaign. Raw stdout retains diagnostic seconds. Heavy jobs are stopped.

`freeze.json` records executable/input/provider/runtime/config/flag hashes and
all process statuses. The fixed six-case arms and source freezes are unchanged.
No tracked product changes are present; this worktree is still at `cf411e29`.

## Exact treatment

Both arms start with the exact unoptimized LLVM text already retained under
`/tmp/snail-native-lto-20261016/probe/six/<case>/native/module.ll`. They therefore
share the same Binaryen-optimized Wasm and native import mapping. Each pair
uses the same unchanged runtime, provider, config, native entry, and opaque
18-hook machine-code boundary. Cargo flags are identical, including the
explicit target, Rust fat/plugin LTO, and save-temps options.

Control:

```
opt '-passes=default<O3>' module.ll -o module.bc
```

Treatment:

```
llvm-as module.ll -o module.bc
```

The treatment's `module.ll` adds only the x86_64 target datalayout inferred by
the control. All original body text is preserved as `module.raw.ll`. The first
direct-assembly attempt lacked that declaration and failed in rust-lld with
`input module has no datalayout`; its complete failed build remains under
`array1/raw-as/` without being reclassified as success.

The requested API simplification check succeeded for both cases:

```
opt -passes=verify module.raw.ll -o verify-only.bc
```

After excluding only ModuleID/source_filename, the disassembled verify-only
IR exactly matches the direct-assembly treatment. Thus a later product change
can use existing `opt` with verification only instead of introducing llvm-as
or hardcoding a datalayout. No extra executable/timing variant was created for
this equivalence check.

## Retained work and generated code

`fib-retained-work.json` records the uninstrumented IR and assembly evidence.
Both fib arms retain 1024 static recursive-worker call sites inside the outer
work SCC and in the final outer machine-code body. The recursive worker has
two recursive calls, decrements by one and two, and adds the results. Worker
IR is identical between arms; its attributes include nounwind, without purity
or willreturn assumptions. The opaque hide hook remains in the work SCC.

The array1 raw treatment changes branch layout: it shares a single reference
test loop body instead of the O3 control's peeled/duplicated test structure.
Both still eliminate root helpers and retain the same loop-carried
environment→recursive-cell→closure→environment load chain. No performance
claim follows from this observation.

Per-arm `pre-lto.{bc,ll}`, `post-lto.{bc,ll}`, `assembly.txt`, and proof files
were copied immediately after each link. `ir-proof-summary.json` contains all
four proof summaries. The array1 hot functions and fib outer/recursive workers
also have separate assembly extracts.

## Build records

Cargo reported 3.45s / 3.42s / 4.02s / 4.15s for array1 O3/raw and fib O3/raw,
respectively. These are cached preparation builds, not clean build-cost
measurements. Every successful build used the native supervisor, not the old
Node spawnSync classification. The first O3 build succeeded before an overly
broad save-temps copy glob failed; `array1/o3/snapshot-attempt1.error` preserves
that separate capture error. Capture was repaired using the exact Rust
extra-filename from the retained compiler command.

Reproduction helpers are `../phase-order-build.sh`,
`../phase-order-validate.sh`, `build-env.sh`, and `prove.mjs`. Existing frozen
arms should remain immutable; copy this preparation before rerunning helpers.
