define internal tailcc i64 @f.4(i64 %arg0, i64 %arg1, i64 %arg2) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [9 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v80 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v81 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v86 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v103 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v262 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  br label %tailrecurse

tailrecurse:                                      ; preds = %native_roots_leave.exit, %entry
  %v17 = phi i64 [ %arg0, %entry ], [ %v420, %native_roots_leave.exit ]
  %arg1.tr = phi i64 [ %arg1, %entry ], [ %v422, %native_roots_leave.exit ]
  %arg2.tr = phi i64 [ %arg2, %entry ], [ %v374, %native_roots_leave.exit ]
  store i64 9, ptr %0, align 8
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hc5c801a01363b8a6E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hc5c801a01363b8a6E.0, align 8
  store i64 %v17, ptr %v1, align 8
  %v10 = icmp sgt i64 %arg1.tr, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  br i1 %v10, label %then15, label %return8

then15:                                           ; preds = %tailrecurse
  %7 = icmp ne i64 %v17, 0
  %8 = and i64 %v17, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap20

9:                                                ; preds = %then15
  %10 = inttoptr i64 %v17 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit25

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader24 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #113
  unreachable

.preheader24:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit25

.loopexit25:                                      ; preds = %.preheader24, %15
  call fastcc void @native_trap() #113
  unreachable

31:                                               ; preds = %.preheader24
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader24 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in, 30
  br i1 %34, label %ok24, label %trap20

trap20:                                           ; preds = %native_ref_test.exit, %then15
  call fastcc void @native_trap()
  unreachable

ok24:                                             ; preds = %native_ref_test.exit
  %v26 = getelementptr i8, ptr %10, i64 8
  %v27 = load i64, ptr %v26, align 1
  %v28.b = load i1, ptr @g.8, align 1
  br i1 %v28.b, label %block31, label %then33

then33:                                           ; preds = %ok24
  call fastcc void @native_trap()
  unreachable

block31:                                          ; preds = %ok24
  %v35 = load i64, ptr @g.7, align 8
  %v36.not = icmp eq i64 %v35, 0
  br i1 %v36.not, label %trap37, label %ok38

trap37:                                           ; preds = %block31
  call fastcc void @native_trap()
  unreachable

ok38:                                             ; preds = %block31
  %v39.b = load i1, ptr @g.4, align 1
  br i1 %v39.b, label %block42, label %then44

then44:                                           ; preds = %ok38
  call fastcc void @native_trap()
  unreachable

block42:                                          ; preds = %ok38
  %v46 = load i64, ptr @g.3, align 8
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %block42
  call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %block42
  %v54 = icmp ugt i64 %v27, 4294967295
  br i1 %v54, label %then58, label %block56

then58:                                           ; preds = %ok49
  call fastcc void @native_trap()
  unreachable

block56:                                          ; preds = %ok49
  store i64 4, ptr %1, align 8
  %35 = getelementptr inbounds nuw i8, ptr %12, i64 376
  %36 = load i64, ptr %35, align 8, !noundef !39
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %38, label %42

38:                                               ; preds = %48, %42, %block56
  %39 = phi ptr [ %.pre, %48 ], [ %roots, %42 ], [ %roots, %block56 ]
  %40 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %12, i64 noundef 24, ptr noundef %39) #84
  %41 = icmp eq ptr %40, null
  br i1 %41, label %49, label %ok74

42:                                               ; preds = %block56
  %43 = getelementptr inbounds nuw i8, ptr %12, i64 368
  %44 = load i64, ptr %43, align 8, !noundef !39
  %45 = add i64 %44, 1
  store i64 %45, ptr %43, align 8
  %46 = urem i64 %45, %36
  %47 = icmp eq i64 %46, 0
  br i1 %47, label %48, label %38

48:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %12, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %38

49:                                               ; preds = %38
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok74:                                             ; preds = %38
  %50 = ptrtoint ptr %40 to i64
  store i64 26, ptr %40, align 1
  %v71 = getelementptr i8, ptr %40, i64 8
  store i32 0, ptr %v71, align 1
  %v76 = getelementptr i8, ptr %40, i64 16
  store i64 0, ptr %v76, align 1
  store i64 %50, ptr %v4, align 8
  %v79 = trunc nuw i64 %v27 to i32
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v80, align 8
  store i64 %50, ptr %v81, align 8
  store i64 6, ptr %1, align 8
  %v83 = call fastcc i64 @native_array_new(i32 %v79)
  store i64 %v83, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v81, align 8
  store i64 %50, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %51 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %52 = icmp eq ptr %51, null
  br i1 %52, label %53, label %54

53:                                               ; preds = %ok74
  call fastcc void @native_trap() #113
  unreachable

54:                                               ; preds = %ok74
  %55 = getelementptr inbounds nuw i8, ptr %51, i64 376
  %56 = load i64, ptr %55, align 8, !noundef !39
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %58, label %62

58:                                               ; preds = %68, %62, %54
  %59 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %60 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %51, i64 noundef 16, ptr noundef %59) #84
  %61 = icmp eq ptr %60, null
  br i1 %61, label %70, label %ok96

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw i8, ptr %51, i64 368
  %64 = load i64, ptr %63, align 8, !noundef !39
  %65 = add i64 %64, 1
  store i64 %65, ptr %63, align 8
  %66 = urem i64 %65, %56
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %68, label %58

68:                                               ; preds = %62
  %69 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %51, ptr noundef %69) #84
  br label %58

70:                                               ; preds = %58
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok96:                                             ; preds = %58
  %71 = ptrtoint ptr %60 to i64
  store i64 18, ptr %60, align 1
  %v98 = getelementptr i8, ptr %60, i64 8
  store i64 %v83, ptr %v98, align 1
  %v99 = load i64, ptr %v4, align 8
  store i64 %v99, ptr %v80, align 8
  store i64 %71, ptr %v81, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v86, align 8
  store i64 %50, ptr %v103, align 8
  store i64 8, ptr %1, align 8
  %72 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %73 = icmp eq ptr %72, null
  br i1 %73, label %74, label %75

74:                                               ; preds = %ok96
  call fastcc void @native_trap() #113
  unreachable

75:                                               ; preds = %ok96
  %76 = getelementptr inbounds nuw i8, ptr %72, i64 376
  %77 = load i64, ptr %76, align 8, !noundef !39
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %79, label %83

79:                                               ; preds = %89, %83, %75
  %80 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %81 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %72, i64 noundef 32, ptr noundef %80) #84
  %82 = icmp eq ptr %81, null
  br i1 %82, label %91, label %ok123

83:                                               ; preds = %75
  %84 = getelementptr inbounds nuw i8, ptr %72, i64 368
  %85 = load i64, ptr %84, align 8, !noundef !39
  %86 = add i64 %85, 1
  store i64 %86, ptr %84, align 8
  %87 = urem i64 %86, %77
  %88 = icmp eq i64 %87, 0
  br i1 %88, label %89, label %79

89:                                               ; preds = %83
  %90 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %72, ptr noundef %90) #84
  br label %79

91:                                               ; preds = %79
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok123:                                            ; preds = %79
  %92 = ptrtoint ptr %81 to i64
  store i64 14, ptr %81, align 1
  %v115 = getelementptr i8, ptr %81, i64 8
  store i64 %v27, ptr %v115, align 1
  %v120 = getelementptr i8, ptr %81, i64 16
  store i64 %71, ptr %v120, align 1
  %v125 = getelementptr i8, ptr %81, i64 24
  store i64 %v99, ptr %v125, align 1
  store i64 %92, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v81, align 8
  store i64 %50, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %93 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %94 = icmp eq ptr %93, null
  br i1 %94, label %95, label %96

95:                                               ; preds = %ok123
  call fastcc void @native_trap() #113
  unreachable

96:                                               ; preds = %ok123
  %97 = getelementptr inbounds nuw i8, ptr %93, i64 376
  %98 = load i64, ptr %97, align 8, !noundef !39
  %99 = icmp eq i64 %98, 0
  br i1 %99, label %100, label %104

100:                                              ; preds = %110, %104, %96
  %101 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %102 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %93, i64 noundef 24, ptr noundef %101) #84
  %103 = icmp eq ptr %102, null
  br i1 %103, label %112, label %ok148

104:                                              ; preds = %96
  %105 = getelementptr inbounds nuw i8, ptr %93, i64 368
  %106 = load i64, ptr %105, align 8, !noundef !39
  %107 = add i64 %106, 1
  store i64 %107, ptr %105, align 8
  %108 = urem i64 %107, %98
  %109 = icmp eq i64 %108, 0
  br i1 %109, label %110, label %100

110:                                              ; preds = %104
  %111 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %93, ptr noundef %111) #84
  br label %100

112:                                              ; preds = %100
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok148:                                            ; preds = %100
  %113 = ptrtoint ptr %102 to i64
  store i64 54, ptr %102, align 1
  %v140 = getelementptr i8, ptr %102, i64 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v140, align 1
  %v145 = getelementptr i8, ptr %102, i64 16
  store i64 %92, ptr %v145, align 1
  store i64 %113, ptr %v76, align 1
  %v151 = load i64, ptr %v4, align 8
  %v152.not = icmp eq i64 %v151, 0
  br i1 %v152.not, label %trap153, label %ok154

trap153:                                          ; preds = %ok148
  call fastcc void @native_trap()
  unreachable

ok154:                                            ; preds = %ok148
  %v155 = inttoptr i64 %v151 to ptr
  %v156 = getelementptr i8, ptr %v155, i64 8
  store i32 1, ptr %v156, align 1
  %v157 = load i64, ptr %v4, align 8
  %v158.not = icmp eq i64 %v157, 0
  br i1 %v158.not, label %trap159, label %ok160

trap159:                                          ; preds = %ok154
  call fastcc void @native_trap()
  unreachable

ok160:                                            ; preds = %ok154
  %v161 = inttoptr i64 %v157 to ptr
  %v162 = getelementptr i8, ptr %v161, i64 8
  %v163 = load i32, ptr %v162, align 1
  %v164 = icmp eq i32 %v163, 0
  br i1 %v164, label %then168, label %ok173

then168:                                          ; preds = %ok160
  call fastcc void @native_trap()
  unreachable

ok173:                                            ; preds = %ok160
  %v175 = getelementptr i8, ptr %v161, i64 16
  %v176 = load i64, ptr %v175, align 1
  %v177.not = icmp eq i64 %v176, 0
  br i1 %v177.not, label %trap178, label %ok182

trap178:                                          ; preds = %ok173
  call fastcc void @native_trap()
  unreachable

ok182:                                            ; preds = %ok173
  store i64 %v176, ptr %v5, align 8
  %v183 = inttoptr i64 %v176 to ptr
  %v191 = getelementptr i8, ptr %v183, i64 8
  %v192 = load i64, ptr %v191, align 1
  %v193.not = icmp eq i64 %v192, 0
  br i1 %v193.not, label %trap194, label %ok195

trap194:                                          ; preds = %ok182
  call fastcc void @native_trap()
  unreachable

ok195:                                            ; preds = %ok182
  %v184 = getelementptr i8, ptr %v183, i64 16
  %v185 = load i64, ptr %v184, align 1
  %v196 = inttoptr i64 %v192 to ptr
  %v197 = getelementptr i8, ptr %v196, i64 8
  %v198 = load ptr, ptr %v197, align 1
  store i64 %v185, ptr %v80, align 8
  store i64 5, ptr %1, align 8
  %v201 = call tailcc i64 %v198(i64 %v185, i64 0)
  store i64 %v201, ptr %v6, align 8
  %v202.b = load i1, ptr @g.6, align 1
  br i1 %v202.b, label %block205, label %then207

then207:                                          ; preds = %ok195
  call fastcc void @native_trap()
  unreachable

block205:                                         ; preds = %ok195
  %v209 = load i64, ptr @g.5, align 8
  %v210.not = icmp eq i64 %v209, 0
  br i1 %v210.not, label %trap211, label %ok212

trap211:                                          ; preds = %block205
  call fastcc void @native_trap()
  unreachable

ok212:                                            ; preds = %block205
  %v214.not = icmp eq i64 %v201, 0
  br i1 %v214.not, label %trap215, label %ok216

trap215:                                          ; preds = %ok212
  call fastcc void @native_trap()
  unreachable

ok216:                                            ; preds = %ok212
  %v217 = and i64 %v201, 1
  %v218 = icmp eq i64 %v217, 0
  br i1 %v218, label %block228, label %trap219

trap219:                                          ; preds = %ok216
  call fastcc void @native_trap()
  unreachable

block228:                                         ; preds = %ok216
  %v221 = inttoptr i64 %v201 to ptr
  %v222 = getelementptr i8, ptr %v221, i64 8
  %v223 = load i64, ptr %v222, align 1
  %v225 = and i64 %v223, 4294967295
  store i64 4, ptr %1, align 8
  %114 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %115 = icmp eq ptr %114, null
  br i1 %115, label %116, label %117

116:                                              ; preds = %block228
  call fastcc void @native_trap() #113
  unreachable

117:                                              ; preds = %block228
  %118 = getelementptr inbounds nuw i8, ptr %114, i64 376
  %119 = load i64, ptr %118, align 8, !noundef !39
  %120 = icmp eq i64 %119, 0
  br i1 %120, label %121, label %125

121:                                              ; preds = %131, %125, %117
  %122 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %123 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %114, i64 noundef 24, ptr noundef %122) #84
  %124 = icmp eq ptr %123, null
  br i1 %124, label %133, label %ok246

125:                                              ; preds = %117
  %126 = getelementptr inbounds nuw i8, ptr %114, i64 368
  %127 = load i64, ptr %126, align 8, !noundef !39
  %128 = add i64 %127, 1
  store i64 %128, ptr %126, align 8
  %129 = urem i64 %128, %119
  %130 = icmp eq i64 %129, 0
  br i1 %130, label %131, label %121

131:                                              ; preds = %125
  %132 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %114, ptr noundef %132) #84
  br label %121

133:                                              ; preds = %121
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok246:                                            ; preds = %121
  %134 = ptrtoint ptr %123 to i64
  store i64 26, ptr %123, align 1
  %v243 = getelementptr i8, ptr %123, i64 8
  store i32 0, ptr %v243, align 1
  %v248 = getelementptr i8, ptr %123, i64 16
  store i64 0, ptr %v248, align 1
  store i64 %134, ptr %v4, align 8
  %v249 = load i64, ptr %v6, align 8
  %v251 = trunc i64 %v223 to i32
  store i64 %v249, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v81, align 8
  store i64 %134, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %v256 = call fastcc i64 @native_array_new(i32 %v251)
  %v257 = load i64, ptr %v4, align 8
  store i64 %v257, ptr %v80, align 8
  store i64 %v256, ptr %v81, align 8
  store i64 %v249, ptr %v86, align 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v103, align 8
  store i64 %134, ptr %v262, align 8
  store i64 9, ptr %1, align 8
  %135 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %136 = icmp eq ptr %135, null
  br i1 %136, label %137, label %138

137:                                              ; preds = %ok246
  call fastcc void @native_trap() #113
  unreachable

138:                                              ; preds = %ok246
  %139 = getelementptr inbounds nuw i8, ptr %135, i64 376
  %140 = load i64, ptr %139, align 8, !noundef !39
  %141 = icmp eq i64 %140, 0
  br i1 %141, label %142, label %146

142:                                              ; preds = %152, %146, %138
  %143 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %144 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %135, i64 noundef 32, ptr noundef %143) #84
  %145 = icmp eq ptr %144, null
  br i1 %145, label %154, label %ok282

146:                                              ; preds = %138
  %147 = getelementptr inbounds nuw i8, ptr %135, i64 368
  %148 = load i64, ptr %147, align 8, !noundef !39
  %149 = add i64 %148, 1
  store i64 %149, ptr %147, align 8
  %150 = urem i64 %149, %140
  %151 = icmp eq i64 %150, 0
  br i1 %151, label %152, label %142

152:                                              ; preds = %146
  %153 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %135, ptr noundef %153) #84
  br label %142

154:                                              ; preds = %142
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok282:                                            ; preds = %142
  %155 = ptrtoint ptr %144 to i64
  store i64 6, ptr %144, align 1
  %v274 = getelementptr i8, ptr %144, i64 8
  store i64 %v249, ptr %v274, align 1
  %v279 = getelementptr i8, ptr %144, i64 16
  store i64 %v256, ptr %v279, align 1
  %v284 = getelementptr i8, ptr %144, i64 24
  store i64 %v257, ptr %v284, align 1
  store i64 %155, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v81, align 8
  store i64 %134, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %156 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %157 = icmp eq ptr %156, null
  br i1 %157, label %158, label %159

158:                                              ; preds = %ok282
  call fastcc void @native_trap() #113
  unreachable

159:                                              ; preds = %ok282
  %160 = getelementptr inbounds nuw i8, ptr %156, i64 376
  %161 = load i64, ptr %160, align 8, !noundef !39
  %162 = icmp eq i64 %161, 0
  br i1 %162, label %163, label %167

163:                                              ; preds = %173, %167, %159
  %164 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %165 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %156, i64 noundef 24, ptr noundef %164) #84
  %166 = icmp eq ptr %165, null
  br i1 %166, label %175, label %ok307

167:                                              ; preds = %159
  %168 = getelementptr inbounds nuw i8, ptr %156, i64 368
  %169 = load i64, ptr %168, align 8, !noundef !39
  %170 = add i64 %169, 1
  store i64 %170, ptr %168, align 8
  %171 = urem i64 %170, %161
  %172 = icmp eq i64 %171, 0
  br i1 %172, label %173, label %163

173:                                              ; preds = %167
  %174 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %156, ptr noundef %174) #84
  br label %163

175:                                              ; preds = %163
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok307:                                            ; preds = %163
  %176 = ptrtoint ptr %165 to i64
  store i64 54, ptr %165, align 1
  %v299 = getelementptr i8, ptr %165, i64 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v299, align 1
  %v304 = getelementptr i8, ptr %165, i64 16
  store i64 %155, ptr %v304, align 1
  store i64 %176, ptr %v248, align 1
  %v310 = load i64, ptr %v4, align 8
  %v311.not = icmp eq i64 %v310, 0
  br i1 %v311.not, label %trap312, label %ok313

trap312:                                          ; preds = %ok307
  call fastcc void @native_trap()
  unreachable

ok313:                                            ; preds = %ok307
  %v314 = inttoptr i64 %v310 to ptr
  %v315 = getelementptr i8, ptr %v314, i64 8
  store i32 1, ptr %v315, align 1
  %v316 = load i64, ptr %v4, align 8
  %v317.not = icmp eq i64 %v316, 0
  br i1 %v317.not, label %trap318, label %ok319

trap318:                                          ; preds = %ok313
  call fastcc void @native_trap()
  unreachable

ok319:                                            ; preds = %ok313
  %v320 = inttoptr i64 %v316 to ptr
  %v321 = getelementptr i8, ptr %v320, i64 8
  %v322 = load i32, ptr %v321, align 1
  %v323 = icmp eq i32 %v322, 0
  br i1 %v323, label %then327, label %ok332

then327:                                          ; preds = %ok319
  call fastcc void @native_trap()
  unreachable

ok332:                                            ; preds = %ok319
  %v334 = getelementptr i8, ptr %v320, i64 16
  %v335 = load i64, ptr %v334, align 1
  %v336.not = icmp eq i64 %v335, 0
  br i1 %v336.not, label %trap337, label %ok341

trap337:                                          ; preds = %ok332
  call fastcc void @native_trap()
  unreachable

ok341:                                            ; preds = %ok332
  store i64 %v335, ptr %v5, align 8
  %v342 = inttoptr i64 %v335 to ptr
  %v352 = getelementptr i8, ptr %v342, i64 8
  %v353 = load i64, ptr %v352, align 1
  %v354.not = icmp eq i64 %v353, 0
  br i1 %v354.not, label %trap355, label %ok356

trap355:                                          ; preds = %ok341
  call fastcc void @native_trap()
  unreachable

ok356:                                            ; preds = %ok341
  %v346 = add nsw i64 %v225, -1
  %v343 = getelementptr i8, ptr %v342, i64 16
  %v344 = load i64, ptr %v343, align 1
  %v357 = inttoptr i64 %v353 to ptr
  %v358 = getelementptr i8, ptr %v357, i64 8
  %v359 = load ptr, ptr %v358, align 1
  store i64 %v344, ptr %v80, align 8
  store i64 5, ptr %1, align 8
  %v362 = call tailcc i64 %v359(i64 %v344, i64 %v346)
  %v363.not = icmp eq i64 %v362, 0
  br i1 %v363.not, label %trap364, label %ok365

trap364:                                          ; preds = %ok356
  call fastcc void @native_trap()
  unreachable

ok365:                                            ; preds = %ok356
  %v366 = and i64 %v362, 1
  %v367 = icmp eq i64 %v366, 0
  br i1 %v367, label %ok369, label %trap368

trap368:                                          ; preds = %ok365
  call fastcc void @native_trap()
  unreachable

ok369:                                            ; preds = %ok365
  %v370 = inttoptr i64 %v362 to ptr
  %v371 = getelementptr i8, ptr %v370, i64 8
  %v372 = load i64, ptr %v371, align 1
  %v375 = load i64, ptr %v1, align 8
  %177 = icmp ne i64 %v375, 0
  %178 = and i64 %v375, 1
  %.not.i14 = icmp eq i64 %178, 0
  %or.cond273 = and i1 %177, %.not.i14
  br i1 %or.cond273, label %179, label %trap378

179:                                              ; preds = %ok369
  %180 = inttoptr i64 %v375 to ptr
  %181 = load i64, ptr %180, align 8, !noundef !39
  %182 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %183 = icmp eq ptr %182, null
  br i1 %183, label %198, label %184

184:                                              ; preds = %179
  %185 = icmp eq i64 %181, 30
  switch i64 %181, label %186 [
    i64 30, label %native_ref_test.exit15
    i64 0, label %native_ref_test.exit15
  ]

186:                                              ; preds = %184
  %187 = getelementptr inbounds nuw i8, ptr %182, i64 360
  %188 = load i64, ptr %187, align 8, !noundef !39
  %189 = lshr i64 %181, 2
  %190 = add nsw i64 %189, -1
  %191 = icmp ult i64 %190, %188
  br i1 %191, label %192, label %.loopexit23

192:                                              ; preds = %186
  %193 = getelementptr inbounds nuw i8, ptr %182, i64 352
  %194 = load ptr, ptr %193, align 8, !nonnull !39, !noundef !39
  %195 = getelementptr inbounds nuw i64, ptr %194, i64 %190
  %196 = load i64, ptr %195, align 8, !noundef !39
  %197 = icmp eq i64 %196, 30
  switch i64 %196, label %.preheader22 [
    i64 30, label %native_ref_test.exit15
    i64 0, label %native_ref_test.exit15
  ]

198:                                              ; preds = %179
  call fastcc void @native_trap() #113
  unreachable

.preheader22:                                     ; preds = %203, %192
  %199 = phi i64 [ %205, %203 ], [ %196, %192 ]
  %200 = lshr i64 %199, 2
  %201 = add nsw i64 %200, -1
  %202 = icmp ult i64 %201, %188
  br i1 %202, label %203, label %.loopexit23

.loopexit23:                                      ; preds = %.preheader22, %186
  call fastcc void @native_trap() #113
  unreachable

203:                                              ; preds = %.preheader22
  %204 = getelementptr inbounds nuw i64, ptr %194, i64 %201
  %205 = load i64, ptr %204, align 8, !noundef !39
  switch i64 %205, label %.preheader22 [
    i64 30, label %native_ref_test.exit15.loopexit
    i64 0, label %native_ref_test.exit15.loopexit
  ]

native_ref_test.exit15.loopexit:                  ; preds = %203, %203
  %.lcssa455 = phi i64 [ %205, %203 ], [ %205, %203 ]
  %206 = icmp eq i64 %.lcssa455, 30
  br i1 %206, label %ok382, label %trap378

native_ref_test.exit15:                           ; preds = %192, %192, %184, %184
  %207 = phi i1 [ %185, %184 ], [ %197, %192 ], [ %197, %192 ], [ %185, %184 ]
  br i1 %207, label %ok382, label %trap378

trap378:                                          ; preds = %native_ref_test.exit15, %native_ref_test.exit15.loopexit, %ok369
  call fastcc void @native_trap()
  unreachable

ok382:                                            ; preds = %native_ref_test.exit15, %native_ref_test.exit15.loopexit
  %v384 = getelementptr i8, ptr %180, i64 16
  %v385 = load i64, ptr %v384, align 1
  %v386.not = icmp eq i64 %v385, 0
  br i1 %v386.not, label %trap387, label %ok388

trap387:                                          ; preds = %ok382
  call fastcc void @native_trap()
  unreachable

ok388:                                            ; preds = %ok382
  %v389 = inttoptr i64 %v385 to ptr
  %v390 = getelementptr i8, ptr %v389, i64 8
  %v391 = load i32, ptr %v390, align 1
  %v392 = icmp eq i32 %v391, 0
  br i1 %v392, label %then396, label %block394

then396:                                          ; preds = %ok388
  call fastcc void @native_trap()
  unreachable

block394:                                         ; preds = %ok388
  switch i64 %181, label %208 [
    i64 30, label %native_ref_test.exit17
    i64 0, label %native_ref_test.exit17
  ]

208:                                              ; preds = %block394
  %209 = getelementptr inbounds nuw i8, ptr %182, i64 360
  %210 = load i64, ptr %209, align 8, !noundef !39
  %211 = lshr i64 %181, 2
  %212 = add nsw i64 %211, -1
  %213 = icmp ult i64 %212, %210
  br i1 %213, label %214, label %.loopexit

214:                                              ; preds = %208
  %215 = getelementptr inbounds nuw i8, ptr %182, i64 352
  %216 = load ptr, ptr %215, align 8, !nonnull !39, !noundef !39
  %217 = getelementptr inbounds nuw i64, ptr %216, i64 %212
  %218 = load i64, ptr %217, align 8, !noundef !39
  %219 = icmp eq i64 %218, 30
  switch i64 %218, label %.preheader [
    i64 30, label %native_ref_test.exit17
    i64 0, label %native_ref_test.exit17
  ]

.preheader:                                       ; preds = %224, %214
  %220 = phi i64 [ %226, %224 ], [ %218, %214 ]
  %221 = lshr i64 %220, 2
  %222 = add nsw i64 %221, -1
  %223 = icmp ult i64 %222, %210
  br i1 %223, label %224, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %208
  call fastcc void @native_trap() #113
  unreachable

224:                                              ; preds = %.preheader
  %225 = getelementptr inbounds nuw i64, ptr %216, i64 %222
  %226 = load i64, ptr %225, align 8, !noundef !39
  switch i64 %226, label %.preheader [
    i64 30, label %native_ref_test.exit17.loopexit
    i64 0, label %native_ref_test.exit17.loopexit
  ]

native_ref_test.exit17.loopexit:                  ; preds = %224, %224
  %.lcssa456 = phi i64 [ %226, %224 ], [ %226, %224 ]
  %227 = icmp eq i64 %.lcssa456, 30
  br i1 %227, label %ok411, label %trap401

native_ref_test.exit17:                           ; preds = %214, %214, %block394, %block394
  %228 = phi i1 [ %185, %block394 ], [ %219, %214 ], [ %219, %214 ], [ %185, %block394 ]
  br i1 %228, label %ok411, label %trap401

trap401:                                          ; preds = %native_ref_test.exit17, %native_ref_test.exit17.loopexit
  call fastcc void @native_trap()
  unreachable

ok411:                                            ; preds = %native_ref_test.exit17, %native_ref_test.exit17.loopexit
  %v413 = getelementptr i8, ptr %v389, i64 16
  %v414 = load i64, ptr %v413, align 1
  %v415.not = icmp eq i64 %v414, 0
  br i1 %v415.not, label %trap416, label %ok417

trap416:                                          ; preds = %ok411
  call fastcc void @native_trap()
  unreachable

ok417:                                            ; preds = %ok411
  %v418 = inttoptr i64 %v414 to ptr
  %v419 = getelementptr i8, ptr %v418, i64 16
  %v420 = load i64, ptr %v419, align 1
  %229 = load i64, ptr %0, align 8, !noundef !39
  %230 = icmp eq i64 %229, 0
  br i1 %230, label %native_roots_leave.exit, label %231

231:                                              ; preds = %ok417
  %232 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %232, ptr @native_roots.0, align 8
  %233 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8, !noundef !39
  %234 = add i64 %233, -1
  store i64 %234, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %231, %ok417
  %v422 = add nsw i64 %arg1.tr, -1
  %v374 = and i64 %v372, 4294967295
  br label %tailrecurse

return8:                                          ; preds = %tailrecurse
  %arg2.tr.lcssa = phi i64 [ %arg2.tr, %tailrecurse ]
  %.lcssa358 = phi ptr [ %2, %tailrecurse ]
  %.lcssa309 = phi i64 [ %3, %tailrecurse ]
  store ptr %.lcssa358, ptr @native_roots.0, align 8
  store i64 %.lcssa309, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8
  ret i64 %arg2.tr.lcssa
}
