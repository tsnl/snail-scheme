define internal tailcc i64 @f.2(i64 %arg0, i64 %arg1, i64 %arg2) #104 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [6 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v123 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v124 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v125 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  br label %tailrecurse

tailrecurse:                                      ; preds = %native_roots_leave.exit, %entry
  %arg0.tr = phi i64 [ %arg0, %entry ], [ %v265, %native_roots_leave.exit ]
  %arg1.tr = phi i64 [ %arg1, %entry ], [ %v267, %native_roots_leave.exit ]
  %arg2.tr = phi i64 [ %arg2, %entry ], [ %v219, %native_roots_leave.exit ]
  store i64 6, ptr %0, align 8
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hc5c801a01363b8a6E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hc5c801a01363b8a6E.0, align 8
  store i64 %arg0.tr, ptr %v1, align 8
  %7 = icmp ne i64 %arg0.tr, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v4, i8 0, i64 16, i1 false)
  %8 = and i64 %arg0.tr, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap12

9:                                                ; preds = %tailrecurse
  %10 = inttoptr i64 %arg0.tr to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 34, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit21

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader20 [
    i64 34, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #113
  unreachable

.preheader20:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit21

.loopexit21:                                      ; preds = %.preheader20, %15
  call fastcc void @native_trap() #113
  unreachable

31:                                               ; preds = %.preheader20
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader20 [
    i64 34, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in, 34
  br i1 %34, label %ok16, label %trap12

trap12:                                           ; preds = %native_ref_test.exit, %tailrecurse
  call fastcc void @native_trap()
  unreachable

ok16:                                             ; preds = %native_ref_test.exit
  %v18 = getelementptr i8, ptr %10, i64 8
  %v19 = load i64, ptr %v18, align 1
  %v21 = icmp sgt i64 %v19, %arg1.tr
  br i1 %v21, label %then26, label %return8

then26:                                           ; preds = %ok16
  %v28.b = load i1, ptr @g.12, align 1
  br i1 %v28.b, label %block38, label %then33

then33:                                           ; preds = %then26
  call fastcc void @native_trap()
  unreachable

block38:                                          ; preds = %then26
  %v42.b = load i1, ptr @g.2, align 1
  br i1 %v42.b, label %block45, label %then47

then47:                                           ; preds = %block38
  call fastcc void @native_trap()
  unreachable

block45:                                          ; preds = %block38
  %v49 = load i64, ptr @g.1, align 8
  %v50.not = icmp eq i64 %v49, 0
  br i1 %v50.not, label %trap51, label %f.0.exit

trap51:                                           ; preds = %block45
  call fastcc void @native_trap()
  unreachable

f.0.exit:                                         ; preds = %block45
  %v56 = load i64, ptr @g.11, align 8
  store i64 3, ptr %1, align 8
  %v2.i = call i64 @benchmark_opaque_hide_i64(i64 %v56)
  %v59.b = load i1, ptr @g.12, align 1
  br i1 %v59.b, label %block62, label %then64

then64:                                           ; preds = %f.0.exit
  call fastcc void @native_trap()
  unreachable

block62:                                          ; preds = %f.0.exit
  %v66.b = load i1, ptr @g.14, align 1
  br i1 %v66.b, label %block69, label %then71

then71:                                           ; preds = %block62
  call fastcc void @native_trap()
  unreachable

block69:                                          ; preds = %block62
  %v73.b = load i1, ptr @g.2, align 1
  br i1 %v73.b, label %block76, label %then78

then78:                                           ; preds = %block69
  call fastcc void @native_trap()
  unreachable

block76:                                          ; preds = %block69
  %v80 = load i64, ptr @g.1, align 8
  %v81.not = icmp eq i64 %v80, 0
  br i1 %v81.not, label %trap82, label %f.0.exit7

trap82:                                           ; preds = %block76
  call fastcc void @native_trap()
  unreachable

f.0.exit7:                                        ; preds = %block76
  %v87 = load i64, ptr @g.13, align 8
  store i64 3, ptr %1, align 8
  %v2.i6 = call i64 @benchmark_opaque_hide_i64(i64 %v87)
  %v90.b = load i1, ptr @g.10, align 1
  br i1 %v90.b, label %block93, label %then95

then95:                                           ; preds = %f.0.exit7
  call fastcc void @native_trap()
  unreachable

block93:                                          ; preds = %f.0.exit7
  %v97 = load i64, ptr @g.9, align 8
  %v98.not = icmp eq i64 %v97, 0
  br i1 %v98.not, label %trap99, label %ok100

trap99:                                           ; preds = %block93
  call fastcc void @native_trap()
  unreachable

ok100:                                            ; preds = %block93
  store i64 3, ptr %1, align 8
  %35 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %36 = icmp eq ptr %35, null
  br i1 %36, label %37, label %38

37:                                               ; preds = %ok100
  call fastcc void @native_trap() #113
  unreachable

38:                                               ; preds = %ok100
  %39 = getelementptr inbounds nuw i8, ptr %35, i64 376
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = icmp eq i64 %40, 0
  br i1 %41, label %42, label %46

42:                                               ; preds = %52, %46, %38
  %43 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %44 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %35, i64 noundef 24, ptr noundef %43) #84
  %45 = icmp eq ptr %44, null
  br i1 %45, label %54, label %ok118

46:                                               ; preds = %38
  %47 = getelementptr inbounds nuw i8, ptr %35, i64 368
  %48 = load i64, ptr %47, align 8, !noundef !39
  %49 = add i64 %48, 1
  store i64 %49, ptr %47, align 8
  %50 = urem i64 %49, %40
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %52, label %42

52:                                               ; preds = %46
  %53 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %35, ptr noundef %53) #84
  br label %42

54:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok118:                                            ; preds = %42
  %55 = ptrtoint ptr %44 to i64
  store i64 38, ptr %44, align 1
  %v115 = getelementptr i8, ptr %44, i64 8
  store i32 0, ptr %v115, align 1
  %v120 = getelementptr i8, ptr %44, i64 16
  store i64 0, ptr %v120, align 1
  store i64 %55, ptr %v4, align 8
  store i64 %55, ptr %v123, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v124, align 8
  store i64 %55, ptr %v125, align 8
  store i64 6, ptr %1, align 8
  %56 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %57 = icmp eq ptr %56, null
  br i1 %57, label %58, label %59

58:                                               ; preds = %ok118
  call fastcc void @native_trap() #113
  unreachable

59:                                               ; preds = %ok118
  %60 = getelementptr inbounds nuw i8, ptr %56, i64 376
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = icmp eq i64 %61, 0
  br i1 %62, label %63, label %67

63:                                               ; preds = %73, %67, %59
  %64 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %65 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %56, i64 noundef 24, ptr noundef %64) #84
  %66 = icmp eq ptr %65, null
  br i1 %66, label %75, label %ok140

67:                                               ; preds = %59
  %68 = getelementptr inbounds nuw i8, ptr %56, i64 368
  %69 = load i64, ptr %68, align 8, !noundef !39
  %70 = add i64 %69, 1
  store i64 %70, ptr %68, align 8
  %71 = urem i64 %70, %61
  %72 = icmp eq i64 %71, 0
  br i1 %72, label %73, label %63

73:                                               ; preds = %67
  %74 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %56, ptr noundef %74) #84
  br label %63

75:                                               ; preds = %63
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok140:                                            ; preds = %63
  %76 = ptrtoint ptr %65 to i64
  store i64 30, ptr %65, align 1
  %v137 = getelementptr i8, ptr %65, i64 8
  store i64 %v2.i6, ptr %v137, align 1
  %v142 = getelementptr i8, ptr %65, i64 16
  store i64 %55, ptr %v142, align 1
  store i64 %76, ptr %v123, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v124, align 8
  store i64 %55, ptr %v125, align 8
  store i64 6, ptr %1, align 8
  %77 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %78 = icmp eq ptr %77, null
  br i1 %78, label %79, label %80

79:                                               ; preds = %ok140
  call fastcc void @native_trap() #113
  unreachable

80:                                               ; preds = %ok140
  %81 = getelementptr inbounds nuw i8, ptr %77, i64 376
  %82 = load i64, ptr %81, align 8, !noundef !39
  %83 = icmp eq i64 %82, 0
  br i1 %83, label %84, label %88

84:                                               ; preds = %94, %88, %80
  %85 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %86 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h864c9c54aba0e745E(ptr noalias noundef align 8 dereferenceable(344) %77, i64 noundef 24, ptr noundef %85) #84
  %87 = icmp eq ptr %86, null
  br i1 %87, label %96, label %ok165

88:                                               ; preds = %80
  %89 = getelementptr inbounds nuw i8, ptr %77, i64 368
  %90 = load i64, ptr %89, align 8, !noundef !39
  %91 = add i64 %90, 1
  store i64 %91, ptr %89, align 8
  %92 = urem i64 %91, %82
  %93 = icmp eq i64 %92, 0
  br i1 %93, label %94, label %84

94:                                               ; preds = %88
  %95 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17hcddb6a459f045c95E(ptr noalias noundef align 8 dereferenceable(344) %77, ptr noundef %95) #84
  br label %84

96:                                               ; preds = %84
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h26aac3f113e81833E(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.33cea93b1b6ca3bfc08d9009ea6da8a6.425, i64 noundef 47) #113
  unreachable

ok165:                                            ; preds = %84
  %97 = ptrtoint ptr %86 to i64
  store i64 58, ptr %86, align 1
  %v157 = getelementptr i8, ptr %86, i64 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v157, align 1
  %v162 = getelementptr i8, ptr %86, i64 16
  store i64 %76, ptr %v162, align 1
  store i64 %97, ptr %v120, align 1
  %v168 = load i64, ptr %v4, align 8
  %v169.not = icmp eq i64 %v168, 0
  br i1 %v169.not, label %trap170, label %ok171

trap170:                                          ; preds = %ok165
  call fastcc void @native_trap()
  unreachable

ok171:                                            ; preds = %ok165
  %v172 = inttoptr i64 %v168 to ptr
  %v173 = getelementptr i8, ptr %v172, i64 8
  store i32 1, ptr %v173, align 1
  %v174 = load i64, ptr %v4, align 8
  %v175.not = icmp eq i64 %v174, 0
  br i1 %v175.not, label %trap176, label %ok177

trap176:                                          ; preds = %ok171
  call fastcc void @native_trap()
  unreachable

ok177:                                            ; preds = %ok171
  %v178 = inttoptr i64 %v174 to ptr
  %v179 = getelementptr i8, ptr %v178, i64 8
  %v180 = load i32, ptr %v179, align 1
  %v181 = icmp eq i32 %v180, 0
  br i1 %v181, label %then185, label %ok190

then185:                                          ; preds = %ok177
  call fastcc void @native_trap()
  unreachable

ok190:                                            ; preds = %ok177
  %v192 = getelementptr i8, ptr %v178, i64 16
  %v193 = load i64, ptr %v192, align 1
  %v194.not = icmp eq i64 %v193, 0
  br i1 %v194.not, label %trap195, label %ok199

trap195:                                          ; preds = %ok190
  call fastcc void @native_trap()
  unreachable

ok199:                                            ; preds = %ok190
  store i64 %v193, ptr %v5, align 8
  %v200 = inttoptr i64 %v193 to ptr
  %v209 = getelementptr i8, ptr %v200, i64 8
  %v210 = load i64, ptr %v209, align 1
  %v211.not = icmp eq i64 %v210, 0
  br i1 %v211.not, label %trap212, label %ok213

trap212:                                          ; preds = %ok199
  call fastcc void @native_trap()
  unreachable

ok213:                                            ; preds = %ok199
  %v201 = getelementptr i8, ptr %v200, i64 16
  %v202 = load i64, ptr %v201, align 1
  %v214 = inttoptr i64 %v210 to ptr
  %v215 = getelementptr i8, ptr %v214, i64 8
  %v216 = load ptr, ptr %v215, align 1
  store i64 %v202, ptr %v123, align 8
  store i64 4, ptr %1, align 8
  %v219 = call tailcc i64 %v216(i64 %v202, i64 %v2.i, i64 0)
  %v220 = load i64, ptr %v1, align 8
  %98 = icmp ne i64 %v220, 0
  %99 = and i64 %v220, 1
  %.not.i10 = icmp eq i64 %99, 0
  %or.cond205 = and i1 %98, %.not.i10
  br i1 %or.cond205, label %100, label %trap223

100:                                              ; preds = %ok213
  %101 = inttoptr i64 %v220 to ptr
  %102 = load i64, ptr %101, align 8, !noundef !39
  %103 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %104 = icmp eq ptr %103, null
  br i1 %104, label %119, label %105

105:                                              ; preds = %100
  %106 = icmp eq i64 %102, 34
  switch i64 %102, label %107 [
    i64 34, label %native_ref_test.exit11
    i64 0, label %native_ref_test.exit11
  ]

107:                                              ; preds = %105
  %108 = getelementptr inbounds nuw i8, ptr %103, i64 360
  %109 = load i64, ptr %108, align 8, !noundef !39
  %110 = lshr i64 %102, 2
  %111 = add nsw i64 %110, -1
  %112 = icmp ult i64 %111, %109
  br i1 %112, label %113, label %.loopexit19

113:                                              ; preds = %107
  %114 = getelementptr inbounds nuw i8, ptr %103, i64 352
  %115 = load ptr, ptr %114, align 8, !nonnull !39, !noundef !39
  %116 = getelementptr inbounds nuw i64, ptr %115, i64 %111
  %117 = load i64, ptr %116, align 8, !noundef !39
  %118 = icmp eq i64 %117, 34
  switch i64 %117, label %.preheader18 [
    i64 34, label %native_ref_test.exit11
    i64 0, label %native_ref_test.exit11
  ]

119:                                              ; preds = %100
  call fastcc void @native_trap() #113
  unreachable

.preheader18:                                     ; preds = %124, %113
  %120 = phi i64 [ %126, %124 ], [ %117, %113 ]
  %121 = lshr i64 %120, 2
  %122 = add nsw i64 %121, -1
  %123 = icmp ult i64 %122, %109
  br i1 %123, label %124, label %.loopexit19

.loopexit19:                                      ; preds = %.preheader18, %107
  call fastcc void @native_trap() #113
  unreachable

124:                                              ; preds = %.preheader18
  %125 = getelementptr inbounds nuw i64, ptr %115, i64 %122
  %126 = load i64, ptr %125, align 8, !noundef !39
  switch i64 %126, label %.preheader18 [
    i64 34, label %native_ref_test.exit11.loopexit
    i64 0, label %native_ref_test.exit11.loopexit
  ]

native_ref_test.exit11.loopexit:                  ; preds = %124, %124
  %.lcssa334 = phi i64 [ %126, %124 ], [ %126, %124 ]
  %127 = icmp eq i64 %.lcssa334, 34
  br i1 %127, label %ok227, label %trap223

native_ref_test.exit11:                           ; preds = %113, %113, %105, %105
  %128 = phi i1 [ %106, %105 ], [ %118, %113 ], [ %118, %113 ], [ %106, %105 ]
  br i1 %128, label %ok227, label %trap223

trap223:                                          ; preds = %native_ref_test.exit11, %native_ref_test.exit11.loopexit, %ok213
  call fastcc void @native_trap()
  unreachable

ok227:                                            ; preds = %native_ref_test.exit11, %native_ref_test.exit11.loopexit
  %v229 = getelementptr i8, ptr %101, i64 16
  %v230 = load i64, ptr %v229, align 1
  %v231.not = icmp eq i64 %v230, 0
  br i1 %v231.not, label %trap232, label %ok233

trap232:                                          ; preds = %ok227
  call fastcc void @native_trap()
  unreachable

ok233:                                            ; preds = %ok227
  %v234 = inttoptr i64 %v230 to ptr
  %v235 = getelementptr i8, ptr %v234, i64 8
  %v236 = load i32, ptr %v235, align 1
  %v237 = icmp eq i32 %v236, 0
  br i1 %v237, label %then241, label %block239

then241:                                          ; preds = %ok233
  call fastcc void @native_trap()
  unreachable

block239:                                         ; preds = %ok233
  switch i64 %102, label %129 [
    i64 34, label %native_ref_test.exit13
    i64 0, label %native_ref_test.exit13
  ]

129:                                              ; preds = %block239
  %130 = getelementptr inbounds nuw i8, ptr %103, i64 360
  %131 = load i64, ptr %130, align 8, !noundef !39
  %132 = lshr i64 %102, 2
  %133 = add nsw i64 %132, -1
  %134 = icmp ult i64 %133, %131
  br i1 %134, label %135, label %.loopexit

135:                                              ; preds = %129
  %136 = getelementptr inbounds nuw i8, ptr %103, i64 352
  %137 = load ptr, ptr %136, align 8, !nonnull !39, !noundef !39
  %138 = getelementptr inbounds nuw i64, ptr %137, i64 %133
  %139 = load i64, ptr %138, align 8, !noundef !39
  %140 = icmp eq i64 %139, 34
  switch i64 %139, label %.preheader [
    i64 34, label %native_ref_test.exit13
    i64 0, label %native_ref_test.exit13
  ]

.preheader:                                       ; preds = %145, %135
  %141 = phi i64 [ %147, %145 ], [ %139, %135 ]
  %142 = lshr i64 %141, 2
  %143 = add nsw i64 %142, -1
  %144 = icmp ult i64 %143, %131
  br i1 %144, label %145, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %129
  call fastcc void @native_trap() #113
  unreachable

145:                                              ; preds = %.preheader
  %146 = getelementptr inbounds nuw i64, ptr %137, i64 %143
  %147 = load i64, ptr %146, align 8, !noundef !39
  switch i64 %147, label %.preheader [
    i64 34, label %native_ref_test.exit13.loopexit
    i64 0, label %native_ref_test.exit13.loopexit
  ]

native_ref_test.exit13.loopexit:                  ; preds = %145, %145
  %.lcssa335 = phi i64 [ %147, %145 ], [ %147, %145 ]
  %148 = icmp eq i64 %.lcssa335, 34
  br i1 %148, label %ok256, label %trap246

native_ref_test.exit13:                           ; preds = %135, %135, %block239, %block239
  %149 = phi i1 [ %106, %block239 ], [ %140, %135 ], [ %140, %135 ], [ %106, %block239 ]
  br i1 %149, label %ok256, label %trap246

trap246:                                          ; preds = %native_ref_test.exit13, %native_ref_test.exit13.loopexit
  call fastcc void @native_trap()
  unreachable

ok256:                                            ; preds = %native_ref_test.exit13, %native_ref_test.exit13.loopexit
  %v258 = getelementptr i8, ptr %v234, i64 16
  %v259 = load i64, ptr %v258, align 1
  %v260.not = icmp eq i64 %v259, 0
  br i1 %v260.not, label %trap261, label %ok262

trap261:                                          ; preds = %ok256
  call fastcc void @native_trap()
  unreachable

ok262:                                            ; preds = %ok256
  %v263 = inttoptr i64 %v259 to ptr
  %v264 = getelementptr i8, ptr %v263, i64 16
  %v265 = load i64, ptr %v264, align 1
  %150 = load i64, ptr %0, align 8, !noundef !39
  %151 = icmp eq i64 %150, 0
  br i1 %151, label %native_roots_leave.exit, label %152

152:                                              ; preds = %ok262
  %153 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %153, ptr @native_roots.0, align 8
  %154 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8, !noundef !39
  %155 = add i64 %154, -1
  store i64 %155, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %152, %ok262
  %v267 = add i64 %arg1.tr, 1
  br label %tailrecurse

return8:                                          ; preds = %ok16
  %arg2.tr.lcssa303 = phi i64 [ %arg2.tr, %ok16 ]
  %.lcssa269 = phi ptr [ %2, %ok16 ]
  %.lcssa234 = phi i64 [ %3, %ok16 ]
  store ptr %.lcssa269, ptr @native_roots.0, align 8
  store i64 %.lcssa234, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8
  ret i64 %arg2.tr.lcssa303
}
