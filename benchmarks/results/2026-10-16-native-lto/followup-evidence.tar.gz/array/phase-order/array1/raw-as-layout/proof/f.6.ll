define internal tailcc i64 @f.6(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  br label %tailrecurse

tailrecurse:                                      ; preds = %ok136, %entry
  %arg0.tr = phi i64 [ %arg0, %entry ], [ %v139, %ok136 ]
  %arg1.tr = phi i64 [ %arg1, %entry ], [ %v141, %ok136 ]
  %v15.not = icmp sgt i64 %arg1.tr, -1
  %0 = icmp ne i64 %arg0.tr, 0
  %1 = and i64 %arg0.tr, 1
  %.not.i6 = icmp eq i64 %1, 0
  %or.cond60 = and i1 %0, %.not.i6
  br i1 %v15.not, label %else13, label %then14

then14:                                           ; preds = %tailrecurse
  br i1 %or.cond60, label %2, label %trap19

2:                                                ; preds = %then14
  %3 = inttoptr i64 %arg0.tr to ptr
  %4 = load i64, ptr %3, align 8, !noundef !39
  %5 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %6 = icmp eq ptr %5, null
  br i1 %6, label %19, label %7

7:                                                ; preds = %2
  switch i64 %4, label %8 [
    i64 6, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

8:                                                ; preds = %7
  %9 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %10 = load i64, ptr %9, align 8, !noundef !39
  %11 = lshr i64 %4, 2
  %12 = add nsw i64 %11, -1
  %13 = icmp ult i64 %12, %10
  br i1 %13, label %14, label %.loopexit

14:                                               ; preds = %8
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %16 = load ptr, ptr %15, align 8, !nonnull !39, !noundef !39
  %17 = getelementptr inbounds nuw i64, ptr %16, i64 %12
  %18 = load i64, ptr %17, align 8, !noundef !39
  switch i64 %18, label %.preheader [
    i64 6, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

19:                                               ; preds = %2
  tail call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %24, %14
  %20 = phi i64 [ %26, %24 ], [ %18, %14 ]
  %21 = lshr i64 %20, 2
  %22 = add nsw i64 %21, -1
  %23 = icmp ult i64 %22, %10
  br i1 %23, label %24, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %8
  tail call fastcc void @native_trap() #113
  unreachable

24:                                               ; preds = %.preheader
  %25 = getelementptr inbounds nuw i64, ptr %16, i64 %22
  %26 = load i64, ptr %25, align 8, !noundef !39
  switch i64 %26, label %.preheader [
    i64 6, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %24, %24, %14, %14, %7, %7
  %.in = phi i64 [ %4, %7 ], [ %18, %14 ], [ %18, %14 ], [ %4, %7 ], [ %26, %24 ], [ %26, %24 ]
  %27 = icmp eq i64 %.in, 6
  br i1 %27, label %return7, label %trap19

trap19:                                           ; preds = %native_ref_test.exit, %then14
  tail call fastcc void @native_trap()
  unreachable

else13:                                           ; preds = %tailrecurse
  br i1 %or.cond60, label %28, label %trap30

28:                                               ; preds = %else13
  %29 = inttoptr i64 %arg0.tr to ptr
  %30 = load i64, ptr %29, align 8, !noundef !39
  %31 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %32 = icmp eq ptr %31, null
  br i1 %32, label %45, label %33

33:                                               ; preds = %28
  switch i64 %30, label %34 [
    i64 6, label %native_ref_test.exit7
    i64 0, label %native_ref_test.exit7
  ]

34:                                               ; preds = %33
  %35 = getelementptr inbounds nuw i8, ptr %31, i64 360
  %36 = load i64, ptr %35, align 8, !noundef !39
  %37 = lshr i64 %30, 2
  %38 = add nsw i64 %37, -1
  %39 = icmp ult i64 %38, %36
  br i1 %39, label %40, label %.loopexit17

40:                                               ; preds = %34
  %41 = getelementptr inbounds nuw i8, ptr %31, i64 352
  %42 = load ptr, ptr %41, align 8, !nonnull !39, !noundef !39
  %43 = getelementptr inbounds nuw i64, ptr %42, i64 %38
  %44 = load i64, ptr %43, align 8, !noundef !39
  switch i64 %44, label %.preheader16 [
    i64 6, label %native_ref_test.exit7
    i64 0, label %native_ref_test.exit7
  ]

45:                                               ; preds = %28
  tail call fastcc void @native_trap() #113
  unreachable

.preheader16:                                     ; preds = %50, %40
  %46 = phi i64 [ %52, %50 ], [ %44, %40 ]
  %47 = lshr i64 %46, 2
  %48 = add nsw i64 %47, -1
  %49 = icmp ult i64 %48, %36
  br i1 %49, label %50, label %.loopexit17

.loopexit17:                                      ; preds = %.preheader16, %34
  tail call fastcc void @native_trap() #113
  unreachable

50:                                               ; preds = %.preheader16
  %51 = getelementptr inbounds nuw i64, ptr %42, i64 %48
  %52 = load i64, ptr %51, align 8, !noundef !39
  switch i64 %52, label %.preheader16 [
    i64 6, label %native_ref_test.exit7
    i64 0, label %native_ref_test.exit7
  ]

native_ref_test.exit7:                            ; preds = %50, %50, %40, %40, %33, %33
  %.in68 = phi i64 [ %30, %33 ], [ %44, %40 ], [ %44, %40 ], [ %30, %33 ], [ %52, %50 ], [ %52, %50 ]
  %53 = icmp eq i64 %.in68, 6
  br i1 %53, label %ok34, label %trap30

trap30:                                           ; preds = %native_ref_test.exit7, %else13
  tail call fastcc void @native_trap()
  unreachable

ok34:                                             ; preds = %native_ref_test.exit7
  %v36 = getelementptr i8, ptr %29, i64 16
  %v37 = load i64, ptr %v36, align 1
  %v41 = icmp ugt i64 %arg1.tr, 4294967295
  br i1 %v41, label %then45, label %ok50

then45:                                           ; preds = %ok34
  tail call fastcc void @native_trap()
  unreachable

ok50:                                             ; preds = %ok34
  %v52 = getelementptr i8, ptr %29, i64 8
  %v53 = load i64, ptr %v52, align 1
  %v56.not = icmp eq i64 %v53, 0
  br i1 %v56.not, label %trap57, label %ok58

trap57:                                           ; preds = %ok50
  tail call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %ok50
  %v59 = and i64 %v53, 1
  %v60 = icmp eq i64 %v59, 0
  br i1 %v60, label %ok62, label %trap61

trap61:                                           ; preds = %ok58
  tail call fastcc void @native_trap()
  unreachable

ok62:                                             ; preds = %ok58
  %v63 = inttoptr i64 %v53 to ptr
  %v64 = getelementptr i8, ptr %v63, i64 8
  %v65 = load i64, ptr %v64, align 1
  %v67 = icmp ult i64 %arg1.tr, %v65
  br i1 %v67, label %block39, label %trap68

trap68:                                           ; preds = %ok62
  tail call fastcc void @native_trap()
  unreachable

block39:                                          ; preds = %ok62
  %v71 = getelementptr i8, ptr %v63, i64 16
  %v72 = getelementptr i64, ptr %v71, i64 %arg1.tr
  %v73 = load i64, ptr %v72, align 1
  %v85.not = icmp eq i64 %v37, 0
  br i1 %v85.not, label %trap86, label %ok87

trap86:                                           ; preds = %block39
  tail call fastcc void @native_trap()
  unreachable

ok87:                                             ; preds = %block39
  %v88 = and i64 %v37, 1
  %v89 = icmp eq i64 %v88, 0
  br i1 %v89, label %ok91, label %trap90

trap90:                                           ; preds = %ok87
  tail call fastcc void @native_trap()
  unreachable

ok91:                                             ; preds = %ok87
  %v92 = inttoptr i64 %v37 to ptr
  %v93 = getelementptr i8, ptr %v92, i64 8
  %v94 = load i64, ptr %v93, align 1
  %v96 = icmp ult i64 %arg1.tr, %v94
  br i1 %v96, label %ok98, label %trap97

trap97:                                           ; preds = %ok91
  tail call fastcc void @native_trap()
  unreachable

ok98:                                             ; preds = %ok91
  %v100 = getelementptr i8, ptr %v92, i64 16
  %v101 = getelementptr i64, ptr %v100, i64 %arg1.tr
  store i64 %v73, ptr %v101, align 1
  %v107 = getelementptr i8, ptr %29, i64 24
  %v108 = load i64, ptr %v107, align 1
  %v109.not = icmp eq i64 %v108, 0
  br i1 %v109.not, label %trap110, label %ok111

trap110:                                          ; preds = %ok98
  tail call fastcc void @native_trap()
  unreachable

ok111:                                            ; preds = %ok98
  %v112 = inttoptr i64 %v108 to ptr
  %v113 = getelementptr i8, ptr %v112, i64 8
  %v114 = load i32, ptr %v113, align 1
  %v115 = icmp eq i32 %v114, 0
  br i1 %v115, label %then119, label %ok130

then119:                                          ; preds = %ok111
  tail call fastcc void @native_trap()
  unreachable

ok130:                                            ; preds = %ok111
  %v132 = getelementptr i8, ptr %v112, i64 16
  %v133 = load i64, ptr %v132, align 1
  %v134.not = icmp eq i64 %v133, 0
  br i1 %v134.not, label %trap135, label %ok136

trap135:                                          ; preds = %ok130
  tail call fastcc void @native_trap()
  unreachable

ok136:                                            ; preds = %ok130
  %v137 = inttoptr i64 %v133 to ptr
  %v138 = getelementptr i8, ptr %v137, i64 16
  %v139 = load i64, ptr %v138, align 1
  %v141 = add nsw i64 %arg1.tr, -1
  br label %tailrecurse

return7:                                          ; preds = %native_ref_test.exit
  %v25 = getelementptr i8, ptr %3, i64 16
  %v26 = load i64, ptr %v25, align 1
  ret i64 %v26
}
