define internal tailcc i64 @f.8(i64 %arg0, i64 %arg1) #105 personality ptr @rust_eh_personality {
entry:
  br label %tailrecurse

tailrecurse:                                      ; preds = %ok112, %entry
  %arg0.tr = phi i64 [ %arg0, %entry ], [ %v115, %ok112 ]
  %arg1.tr = phi i64 [ %arg1, %entry ], [ %v117, %ok112 ]
  %0 = icmp ne i64 %arg0.tr, 0
  %1 = and i64 %arg0.tr, 1
  %.not.i = icmp eq i64 %1, 0
  %or.cond = and i1 %0, %.not.i
  br i1 %or.cond, label %2, label %trap9

2:                                                ; preds = %tailrecurse
  %3 = inttoptr i64 %arg0.tr to ptr
  %4 = load i64, ptr %3, align 8, !noundef !39
  %5 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17h3f37fc01500908e3E.0, align 8, !noundef !39
  %6 = icmp eq ptr %5, null
  br i1 %6, label %19, label %7

7:                                                ; preds = %2
  switch i64 %4, label %8 [
    i64 14, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

8:                                                ; preds = %7
  %9 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %10 = load i64, ptr %9, align 8, !noundef !39
  %11 = lshr i64 %4, 2
  %12 = add nsw i64 %11, -1
  %13 = icmp ult i64 %12, %10
  br i1 %13, label %14, label %.loopexit

14:                                               ; preds = %8
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %16 = load ptr, ptr %15, align 8, !nonnull !39, !noundef !39
  %17 = getelementptr inbounds nuw i64, ptr %16, i64 %12
  %18 = load i64, ptr %17, align 8, !noundef !39
  switch i64 %18, label %.preheader [
    i64 14, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

19:                                               ; preds = %2
  tail call fastcc void @native_trap() #113
  unreachable

.preheader:                                       ; preds = %24, %14
  %20 = phi i64 [ %26, %24 ], [ %18, %14 ]
  %21 = lshr i64 %20, 2
  %22 = add nsw i64 %21, -1
  %23 = icmp ult i64 %22, %10
  br i1 %23, label %24, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %8
  tail call fastcc void @native_trap() #113
  unreachable

24:                                               ; preds = %.preheader
  %25 = getelementptr inbounds nuw i64, ptr %16, i64 %22
  %26 = load i64, ptr %25, align 8, !noundef !39
  switch i64 %26, label %.preheader [
    i64 14, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %24, %24, %14, %14, %7, %7
  %.in = phi i64 [ %4, %7 ], [ %18, %14 ], [ %18, %14 ], [ %4, %7 ], [ %26, %24 ], [ %26, %24 ]
  %27 = icmp eq i64 %.in, 14
  br i1 %27, label %ok13, label %trap9

trap9:                                            ; preds = %native_ref_test.exit, %tailrecurse
  tail call fastcc void @native_trap()
  unreachable

ok13:                                             ; preds = %native_ref_test.exit
  %v15 = getelementptr i8, ptr %3, i64 8
  %v16 = load i64, ptr %v15, align 1
  %v18.not = icmp sgt i64 %v16, %arg1.tr
  br i1 %v18.not, label %else22, label %ok28

ok28:                                             ; preds = %ok13
  %.lcssa54 = phi ptr [ %3, %ok13 ]
  %v30 = getelementptr i8, ptr %.lcssa54, i64 16
  %v31 = load i64, ptr %v30, align 1
  %v32.not = icmp eq i64 %v31, 0
  br i1 %v32.not, label %trap33, label %return5

trap33:                                           ; preds = %ok28
  tail call fastcc void @native_trap()
  unreachable

else22:                                           ; preds = %ok13
  %v39 = icmp ugt i64 %arg1.tr, 4294967295
  br i1 %v39, label %then43, label %ok48

then43:                                           ; preds = %else22
  tail call fastcc void @native_trap()
  unreachable

ok48:                                             ; preds = %else22
  %v50 = getelementptr i8, ptr %3, i64 16
  %v51 = load i64, ptr %v50, align 1
  %v52.not = icmp eq i64 %v51, 0
  br i1 %v52.not, label %trap53, label %ok54

trap53:                                           ; preds = %ok48
  tail call fastcc void @native_trap()
  unreachable

ok54:                                             ; preds = %ok48
  %v55 = inttoptr i64 %v51 to ptr
  %v56 = getelementptr i8, ptr %v55, i64 8
  %v57 = load i64, ptr %v56, align 1
  %v61.not = icmp eq i64 %v57, 0
  br i1 %v61.not, label %trap62, label %ok63

trap62:                                           ; preds = %ok54
  tail call fastcc void @native_trap()
  unreachable

ok63:                                             ; preds = %ok54
  %v64 = and i64 %v57, 1
  %v65 = icmp eq i64 %v64, 0
  br i1 %v65, label %ok67, label %trap66

trap66:                                           ; preds = %ok63
  tail call fastcc void @native_trap()
  unreachable

ok67:                                             ; preds = %ok63
  %v68 = inttoptr i64 %v57 to ptr
  %v69 = getelementptr i8, ptr %v68, i64 8
  %v70 = load i64, ptr %v69, align 1
  %v72 = icmp ult i64 %arg1.tr, %v70
  br i1 %v72, label %ok74, label %trap73

trap73:                                           ; preds = %ok67
  tail call fastcc void @native_trap()
  unreachable

ok74:                                             ; preds = %ok67
  %v76 = getelementptr i8, ptr %v68, i64 16
  %v77 = getelementptr i64, ptr %v76, i64 %arg1.tr
  store i64 %arg1.tr, ptr %v77, align 1
  %v83 = getelementptr i8, ptr %3, i64 24
  %v84 = load i64, ptr %v83, align 1
  %v85.not = icmp eq i64 %v84, 0
  br i1 %v85.not, label %trap86, label %ok87

trap86:                                           ; preds = %ok74
  tail call fastcc void @native_trap()
  unreachable

ok87:                                             ; preds = %ok74
  %v88 = inttoptr i64 %v84 to ptr
  %v89 = getelementptr i8, ptr %v88, i64 8
  %v90 = load i32, ptr %v89, align 1
  %v91 = icmp eq i32 %v90, 0
  br i1 %v91, label %then95, label %ok106

then95:                                           ; preds = %ok87
  tail call fastcc void @native_trap()
  unreachable

ok106:                                            ; preds = %ok87
  %v108 = getelementptr i8, ptr %v88, i64 16
  %v109 = load i64, ptr %v108, align 1
  %v110.not = icmp eq i64 %v109, 0
  br i1 %v110.not, label %trap111, label %ok112

trap111:                                          ; preds = %ok106
  tail call fastcc void @native_trap()
  unreachable

ok112:                                            ; preds = %ok106
  %v113 = inttoptr i64 %v109 to ptr
  %v114 = getelementptr i8, ptr %v113, i64 16
  %v115 = load i64, ptr %v114, align 1
  %v117 = add nuw nsw i64 %arg1.tr, 1
  br label %tailrecurse

return5:                                          ; preds = %ok28
  %v35 = inttoptr i64 %v31 to ptr
  %v36 = getelementptr i8, ptr %v35, i64 8
  %v37 = load i64, ptr %v36, align 1
  ret i64 %v37
}
