define internal tailcc i64 @f.5(i64 %arg0, i64 %arg1, i64 %arg2) #104 personality ptr @rust_eh_personality {
return5:
  %roots = alloca { ptr, i64, i64, [1 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 1, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hc5c801a01363b8a6E.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17hc5c801a01363b8a6E.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  store i64 1, ptr %1, align 8
  %v2.i = call i64 @benchmark_opaque_hide_i64(i64 %arg2)
  %7 = load i64, ptr %0, align 8, !noundef !39
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %native_roots_leave.exit, label %9

9:                                                ; preds = %return5
  %10 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %10, ptr @native_roots.0, align 8
  %11 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8, !noundef !39
  %12 = add i64 %11, -1
  store i64 %12, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h976a275949e8fba8E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %9, %return5
  ret i64 %v2.i
}
