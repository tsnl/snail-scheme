# Array1 shared-LTO regression diagnostics

These are throwaway diagnostic controls, based on `cf411e29` in the isolated
worktree `/tmp/snail-native-lto-array-20261016`. No tracked product change is
currently present. The fixed six-case arms under
`/tmp/snail-native-lto-20261016/probe/six` and the frozen benchmark inputs are
unchanged. No clean timing has been taken here.

## Findings

The immutable matched-native and LTO profiles place the regression in the two
per-element loops: `f.8` initializes `x[i] = i`, and `f.6` copies `y[i] = x[i]`.
The original workload performs 500 repetitions over one million elements.
Matched-native spends 28.76% of core cycles in `f.8`, 23.82% in `f.6`, 17.38%
in `native_ref_test`, and 11.09% in root enter/leave. LTO puts 40.57% in `f.8`
and 42.73% in `f.6`. Allocation/memset has not grown enough to explain the
regression. The matched dwarf profile dropped 68/13517 samples; retain that
warning when interpreting its percentages.

All versions already turn the self tail call into a loop. LTO removes the root
helpers and promotes the saved environment root to SSA. Its loop uses the
carried environment directly after the array store, then follows:

```
environment + 24 -> recursive cell + 16 -> closure + 16 -> next environment
```

Matched-native reloads the saved environment from the stack root slot after
the vector store before following the same three heap loads. Keeping both
root helpers out of line restores that stack root publication/reload and
recovers part of the lost cycles. It does not yet explain the entire CPU-level
effect or establish a complete correction. The exact trap checks, nullable
flags and collecting semantics remain intact.

Type-based alias metadata distinguishing only struct fields and array
elements does not change either hot function's machine code. All structs
share one category, all arrays another; runtime, roots and headers remain
untagged, so inheritance and canonical aliases are preserved. The generated
IR differs from the original only in metadata. Both hot loops retain the
carried closure cycle, whose base address changes on each iteration. This
rejects simple struct/array alias metadata as the explanation/fix.

Preserving proven final target exactness changes nine reference tests, with
all 17 types proved final. It greatly shrinks the generic type-check code but
does not recover the array regression in these diagnostic runs. No conclusion
is drawn from the cold subtype slow paths receiving no samples.

Hardware counters also reject a simple increase in cache/branch misses:
LTO executes 43% fewer instructions but takes more core cycles. Branch misses
are negligible. A separate targeted run reports 0.44M retired L1 load misses
for LTO versus 14.46M for matched-native. The extra root stack operations are
observable in the load-block counters, but a claim about CPU dependency
prediction or memory renaming would require further evidence.

## Runnable controls

Each executable path is `<this directory>/<arm>/program`. Each passed the
unchanged complete result predicate (`1000000`) through the frozen native
supervisor, with exit 0, no timeout, and all descendants gone. These controls
have not yet been run under forced collection, and no additional scalar
root-boundary arm has been built.

| Arm | Change | Diagnostic core cycles, billions |
| --- | --- | ---: |
| Original matched-native | Immutable old machine guest | 18.593 |
| Original LTO | Immutable six-case LTO guest | 24.886 |
| `control` | Rebuilt LTO in this worktree | 23.012 |
| `final-exact` | Only proven final targets use exact ref tests | 24.604 |
| `noinline-ref-test` | Only `native_ref_test` gets `inline(never)` | 24.109 |
| `noinline-roots` | Only enter/leave get `inline(never)` | 20.591 |
| `zero-fill` | Exact `ed23cb3c` allocator zero-fill skip | 22.617 |
| `tbaa` | Semantic struct-field/array-element categories | 22.903 |

These are individual instrumented diagnostic runs with varying cache/frequency
state. In particular, the rebuilt control is lower than the earlier immutable
LTO run. The table does not replace a paired clean comparison. Raw stdout
retains the diagnostic seconds; none is claimed as a clean measurement.

## Evidence and reproduction

`summary.json` records source, guest, provider, boundary and executable hashes,
all successful supervisor records, counters, and precise limitations.
`code-comparison/proof.json` verifies that both TBAA hot functions match the
old LTO instructions after removing code addresses/comments. The corresponding
assembly extracts are beside that proof. Per-arm original/post-LTO IR and
assembly are retained where captured before the next link reused the Cargo
save-temps path. The `control` uses the same original guest bitcode and has its
executable/source snapshots; its overwritten post-LTO temp was not captured.

`build-env.sh` contains the exact explicit-target Cargo/rust-lld flags.
`build-arm.sh ARM GUEST_BC` snapshots the runtime source/build script and runs
Cargo through the frozen supervisor. It retains stdout/stderr, wrapper exit
code and the independent process record. All six builds succeeded. Unlike the
old Node spawnSync harness, this builder does not classify `status == 0` while
ignoring a spawn error. Old failing-attempt metadata is unchanged.

`stat-arm.sh ARM BINARY` collects basic hardware counters; `stat-memory.sh`
collects the targeted core load-block/cache counters. Both pin CPU 2 and use
the frozen supervisor. Hybrid atom startup values are not meaningful here;
analyze the `cpu_core` records. `summarize.mjs` derives `summary.json` from
existing files and makes no subprocess calls.

`final-exact/patch-proof.json` records type facts and each exactness change.
`tbaa/{emitter.patch,llvm.sld,patch-proof.json}` records the rejected alias
experiment. The raw optimized Wasm SHA-256 is identical to the original:
`232431e37c25c9ba1b5466568b77192127fc3e643bf1892ae707f6cb79c4af95`.

The first summary-generation attempt used the nonexistent name
`native-entry.rs` and failed with ENOENT before writing the summary. The fixed
script hashes the frozen `scalar-timing-entry.rs`. This was a record-generation
error; no build or process status was changed.
