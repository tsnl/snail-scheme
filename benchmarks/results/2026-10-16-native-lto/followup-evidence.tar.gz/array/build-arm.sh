#!/bin/sh
set -u
array_root=/tmp/snail-native-lto-array-20261016
array_probe=$array_root/probe
array_arm=$1
array_guest=$2
. "$array_probe/build-env.sh"
mkdir -p "$array_probe/$array_arm"
cp "$array_root/wasm-native/src/native.rs" "$array_probe/$array_arm/native.rs"
printf 'fn main() { println!("cargo:rustc-link-arg={}", "%s"); println!("cargo:rustc-link-arg={}", "/tmp/snail-native-lto-20261016/probe/six/boundary.o"); }\n' "$array_guest" > "$array_probe/build/build.rs"
cp "$array_probe/build/build.rs" "$array_probe/$array_arm/build.rs"
export SNAIL_PROCESS_RECORD="$array_probe/$array_arm/build-process.json"
"$SNAIL_NATIVE_SUPERVISOR" --command 1800000 -- "$CARGO" build --offline --release --target x86_64-unknown-linux-gnu --manifest-path "$array_probe/build/Cargo.toml" --target-dir "$array_probe/target" -v > "$array_probe/$array_arm/build.stdout" 2> "$array_probe/$array_arm/build.stderr"
array_result=$?
printf '%s\n' "$array_result" > "$array_probe/$array_arm/build.exit"
if test "$array_result" -ne 0; then cat "$array_probe/$array_arm/build.stderr"; exit "$array_result"; fi
cp "$array_probe/target/x86_64-unknown-linux-gnu/release/opaque_array1_timing_lto" "$array_probe/$array_arm/program"
cp "$array_probe/build/Cargo.toml" "$array_probe/$array_arm/Cargo.toml"
cp "$array_probe/build/main.rs" "$array_probe/$array_arm/main.rs"
