#!/bin/sh
set -eu
phase_root=/tmp/snail-native-lto-array-20261016
phase_probe=$phase_root/probe/phase-order
phase_original=/tmp/snail-native-lto-20261016/probe/six
phase_source=/tmp/sfir-native-parity-baseline-20261016/timing/artifacts
. "$phase_root/probe/build-env.sh"
mkdir -p "$phase_probe"
cp "$phase_root/probe/build-env.sh" "$phase_probe/build-env.sh"
cp "$phase_root/wasm-native/src/native.rs" "$phase_probe/native.rs"
for phase_case in array1 fib; do
    phase_directory=$phase_probe/$phase_case
    phase_package=opaque_${phase_case}_timing_lto
    mkdir -p "$phase_directory/build" "$phase_directory/provider"
    cp "$phase_original/$phase_case/timing/lto/main.rs" "$phase_directory/build/main.rs"
    cp "$phase_source/$phase_case/case-config.rs" "$phase_directory/build/case-config.rs"
    cp "$phase_source/$phase_case/scalar-provider.rs" "$phase_directory/provider/scalar-provider.rs"
    cp "$phase_source/$phase_case/case-config.rs" "$phase_directory/provider/case-config.rs"
    sed "s|/tmp/snail-native-lto-20261016/wasm-native|$phase_root/wasm-native|" "$phase_original/$phase_case/timing/lto/Cargo.toml" > "$phase_directory/build/Cargo.toml"
    printf '[package]\nname="opaque_provider_%s_timing"\nversion="0.0.0"\nedition="2024"\n[lib]\npath="scalar-provider.rs"\n' "$phase_case" > "$phase_directory/provider/Cargo.toml"
    for phase_arm in o3 raw-as-layout; do
        phase_output=$phase_directory/$phase_arm
        mkdir -p "$phase_output"
        if test -f "$phase_output/program" && test -f "$phase_output/post-lto.ll"; then
            printf 'Reuse completed %s %s\n' "$phase_case" "$phase_arm"
            continue
        fi
        cp "$phase_original/$phase_case/native/module.ll" "$phase_output/module.ll"
        export SNAIL_PROCESS_RECORD="$phase_output/bitcode-process.json"
        if test "$phase_arm" = o3; then
            "$SNAIL_NATIVE_SUPERVISOR" --command 60000 -- "$LLVM_OPT" '-passes=default<O3>' "$phase_output/module.ll" -o "$phase_output/module.bc" > "$phase_output/bitcode.stdout" 2> "$phase_output/bitcode.stderr"
        else
            cp "$phase_output/module.ll" "$phase_output/module.raw.ll"
            cat "$phase_probe/target-datalayout.ll" "$phase_output/module.raw.ll" > "$phase_output/module.ll"
            "$SNAIL_NATIVE_SUPERVISOR" --command 60000 -- /nix/store/dlhnzkygd34z7mavq8c6pnag4kjafbjn-system-path/bin/llvm-as "$phase_output/module.ll" -o "$phase_output/module.bc" > "$phase_output/bitcode.stdout" 2> "$phase_output/bitcode.stderr"
        fi
        printf 'fn main() { println!("cargo:rustc-link-arg={}", "%s"); println!("cargo:rustc-link-arg={}", "%s/boundary.o"); }\n' "$phase_output/module.bc" "$phase_original" > "$phase_directory/build/build.rs"
        cp "$phase_directory/build/build.rs" "$phase_output/build.rs"
        if ! test -f "$phase_output/build.exit"; then
            export SNAIL_PROCESS_RECORD="$phase_output/build-process.json"
            set +e
            "$SNAIL_NATIVE_SUPERVISOR" --command 60000 -- "$CARGO" build --offline --release --target x86_64-unknown-linux-gnu --manifest-path "$phase_directory/build/Cargo.toml" --target-dir "$phase_root/probe/target" -v > "$phase_output/build.stdout" 2> "$phase_output/build.stderr"
            phase_result=$?
            set -e
            printf '%s\n' "$phase_result" > "$phase_output/build.exit"
            if test "$phase_result" -ne 0; then
                printf 'Stopped after failed/lengthy build: %s %s\n' "$phase_case" "$phase_arm"
                tail -n 8 "$phase_output/build.stderr"
                exit "$phase_result"
            fi
        fi
        phase_suffix=$(sed -n "/--crate-name $phase_package /s/.*-C extra-filename=\([^ ]*\).*/\1/p" "$phase_output/build.stderr")
        test -n "$phase_suffix"
        cp "$phase_root/probe/target/x86_64-unknown-linux-gnu/release/$phase_package" "$phase_output/program"
        cp "$phase_root/probe/target/x86_64-unknown-linux-gnu/release/deps/$phase_package$phase_suffix.0.0.preopt.bc" "$phase_output/pre-lto.bc"
        cp "$phase_root/probe/target/x86_64-unknown-linux-gnu/release/deps/$phase_package$phase_suffix.0.4.opt.bc" "$phase_output/post-lto.bc"
        llvm-dis "$phase_output/pre-lto.bc" -o "$phase_output/pre-lto.ll"
        llvm-dis "$phase_output/post-lto.bc" -o "$phase_output/post-lto.ll"
        llvm-objdump -d --no-show-raw-insn "$phase_output/program" > "$phase_output/assembly.txt"
        printf 'Built %s %s: ' "$phase_case" "$phase_arm"
        tail -n 1 "$phase_output/build.stderr"
    done
done
