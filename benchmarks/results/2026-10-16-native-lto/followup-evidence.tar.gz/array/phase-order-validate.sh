#!/bin/sh
set -eu
phase_root=/tmp/snail-native-lto-array-20261016
. "$phase_root/probe/build-env.sh"
for phase_case in array1 fib; do
    for phase_arm in o3 raw-as-layout; do
        phase_output=$phase_root/probe/phase-order/$phase_case/$phase_arm
        export SNAIL_PROCESS_RECORD="$phase_output/correctness-process.json"
        "$ENV" -u SNAIL_NATIVE_GC_INTERVAL -u SNAIL_GC_STATS -u SNAIL_GC_HEAP_BYTES -u SNAIL_GC_INITIAL_BYTES -u SNAIL_GC_MIN_BYTES "$TASKSET" -c 2 "$SNAIL_NATIVE_SUPERVISOR" --command 60000 -- "$phase_output/program" > "$phase_output/correctness.stdout" 2> "$phase_output/correctness.stderr"
        printf 'Predicate passed: %s %s\n' "$phase_case" "$phase_arm"
    done
done
