import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const root = "/tmp/snail-native-lto-array-20261016/probe";
const original = "/tmp/snail-native-lto-20261016/probe/six/array1";
const frozen = "/tmp/sfir-native-parity-baseline-20261016/timing/artifacts/array1";
const digest = file => crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
const json = file => JSON.parse(fs.readFileSync(file, "utf8"));
const counters = file => Object.fromEntries(fs.readFileSync(file, "utf8").split("\n")
  .filter(line => line.includes("cpu_core/"))
  .map(line => { const fields = line.split(","); return [fields[2], Number(fields[0])]; }));
const variants = ["control", "final-exact", "noinline-ref-test", "noinline-roots", "zero-fill", "tbaa"];
const arms = Object.fromEntries(variants.map(name => {
  const dir = path.join(root, name);
  const output = json(path.join(dir, "stat.stdout"));
  const build = json(path.join(dir, "build-process.json"));
  const run = json(path.join(dir, "stat-process.json"));
  const hashes = Object.fromEntries(["program", "native.rs", "build.rs", "main.rs", "Cargo.toml", "module.ll", "module.bc", "post-lto.bc", "post-lto.ll"]
    .filter(file => fs.existsSync(path.join(dir, file)))
    .map(file => [file, digest(path.join(dir, file))]));
  const completePredicatePassed = output.result === "1000000" && run.exit_code === 0 && run.descendants_gone && !run.timed_out;
  return [name, { program: path.join(dir, "program"), hashes, build, run, completePredicatePassed, diagnosticCounters: counters(path.join(dir, "stat.csv")) }];
}));
const summary = {
  classification: "Instrumented hardware diagnostics only. No clean timing claim. Raw run stdout retains diagnostic seconds.",
  baseCommit: "cf411e29",
  immutableSource: { frozen, original, guestLlSha256: digest(path.join(original, "native/module.ll")), guestBcSha256: digest(path.join(original, "native/module.bc")), wasmSha256: digest(path.join(frozen, "program.wasm")), providerSha256: digest(path.join(frozen, "scalar-provider.rs")), entrySha256: digest(path.join(frozen, "scalar-timing-entry.rs")), boundarySha256: digest("/tmp/snail-native-lto-20261016/probe/six/boundary.o") },
  originalDiagnostics: { matchedNative: counters(path.join(root, "matched-stat/stat.csv")), lto: counters(path.join(root, "lto-stat/stat.csv")) },
  hardwareMemoryDiagnostics: Object.fromEntries(["matched-memory", "lto-memory", "noinline-roots-memory"].map(name => [name, { raw: path.join(root, name, "stat.csv"), run: json(path.join(root, name, "process.json")) }])),
  arms,
  finalExact: json(path.join(root, "final-exact/patch-proof.json")),
  tbaa: json(path.join(root, "tbaa/patch-proof.json")),
  constraints: ["All fixed six-case timing and diagnostic arms unchanged", "No source workload or provider changes", "No new unsafe alias annotations outside semantic struct/array TBAA experiment", "No forced-collection validation of these throwaway controls yet", "No additional scalar root-boundary arm built", "No new product commit or tracked diff"]
};
fs.writeFileSync(path.join(root, "summary.json"), JSON.stringify(summary, null, 2) + "\n");
console.log(JSON.stringify({ arms: variants, allPassed: variants.every(name => arms[name].completePredicatePassed), summary: path.join(root, "summary.json") }));
