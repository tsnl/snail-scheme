define internal tailcc range(i64 0, 2) i64 @f.7(i64 %arg0, i64 %arg1, i64 %arg2) #102 personality ptr @rust_eh_personality {
entry:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %roots = alloca { ptr, i64, i64, [26 x i64] }, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v7 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v8 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v9 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v10 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v11 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  %v12 = getelementptr inbounds nuw i8, ptr %roots, i64 96
  %v13 = getelementptr inbounds nuw i8, ptr %roots, i64 104
  %v14 = getelementptr inbounds nuw i8, ptr %roots, i64 112
  %v15 = getelementptr inbounds nuw i8, ptr %roots, i64 120
  %v16 = getelementptr inbounds nuw i8, ptr %roots, i64 128
  %v17 = getelementptr inbounds nuw i8, ptr %roots, i64 136
  %v18 = getelementptr inbounds nuw i8, ptr %roots, i64 144
  %v19 = getelementptr inbounds nuw i8, ptr %roots, i64 152
  %v20 = getelementptr inbounds nuw i8, ptr %roots, i64 160
  %v21 = getelementptr inbounds nuw i8, ptr %roots, i64 168
  %v22 = getelementptr inbounds nuw i8, ptr %roots, i64 176
  %v23 = getelementptr inbounds nuw i8, ptr %roots, i64 184
  %v67 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %v111 = getelementptr inbounds nuw i8, ptr %roots, i64 192
  %v130 = getelementptr inbounds nuw i8, ptr %roots, i64 200
  %v150 = getelementptr inbounds nuw i8, ptr %roots, i64 208
  %v171 = getelementptr inbounds nuw i8, ptr %roots, i64 216
  %v193 = getelementptr inbounds nuw i8, ptr %roots, i64 224
  %2 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 26, ptr %2, align 8
  store i64 0, ptr %v67, align 8
  %3 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %3, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %4 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %5 = add i64 %4, 1
  store i64 %5, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %6 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %7 = call noundef i64 @llvm.umax.i64(i64 %5, i64 %6)
  store i64 %7, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %arg0, ptr %v1, align 8
  %v31.not1197 = icmp eq i64 %arg0, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(160) %v4, i8 0, i64 160, i1 false)
  br i1 %v31.not1197, label %trap32, label %ok33

trap32:                                           ; preds = %ok1903, %entry
  call fastcc void @native_trap()
  unreachable

ok33:                                             ; preds = %ok1903, %entry
  %8 = phi i64 [ %678, %ok1903 ], [ %4, %entry ]
  %9 = phi ptr [ %679, %ok1903 ], [ %3, %entry ]
  %arg2.tr1200 = phi i64 [ %slot1111.0, %ok1903 ], [ %arg2, %entry ]
  %arg1.tr1199 = phi i64 [ %v1908, %ok1903 ], [ %arg1, %entry ]
  %arg0.tr1198 = phi i64 [ %v1906, %ok1903 ], [ %arg0, %entry ]
  %v34 = inttoptr i64 %arg0.tr1198 to ptr
  %v35 = getelementptr i8, ptr %v34, i64 8
  %v36 = load i64, ptr %v35, align 1
  %v38 = icmp sgt i64 %v36, %arg1.tr1199
  br i1 %v38, label %then43, label %else42

then43:                                           ; preds = %ok33
  %v45.b = load i1, ptr @g.28, align 1
  br i1 %v45.b, label %block48, label %then50

then50:                                           ; preds = %then43
  call fastcc void @native_trap()
  unreachable

block48:                                          ; preds = %then43
  %v52.b = load i1, ptr @g.20, align 1
  br i1 %v52.b, label %block55, label %then57

then57:                                           ; preds = %block48
  call fastcc void @native_trap()
  unreachable

block55:                                          ; preds = %block48
  %v59 = load i64, ptr @g.19, align 8
  %v60.not = icmp eq i64 %v59, 0
  br i1 %v60.not, label %trap61, label %ok62

trap61:                                           ; preds = %block55
  call fastcc void @native_trap()
  unreachable

ok62:                                             ; preds = %block55
  %v66 = load i64, ptr @g.27, align 8
  store i64 21, ptr %v67, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %1)
  store i64 %v66, ptr %1, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %1) #84, !srcloc !75600
  %10 = load i64, ptr %1, align 8, !noundef !39
  call void @llvm.lifetime.end.p0(ptr nonnull %1)
  %v69 = load i64, ptr %v1, align 8
  %v70.not = icmp eq i64 %v69, 0
  br i1 %v70.not, label %trap71, label %ok72

trap71:                                           ; preds = %ok62
  call fastcc void @native_trap()
  unreachable

ok72:                                             ; preds = %ok62
  %v76.b = load i1, ptr @g.30, align 1
  br i1 %v76.b, label %block79, label %then81

then81:                                           ; preds = %ok72
  call fastcc void @native_trap()
  unreachable

block79:                                          ; preds = %ok72
  %v83.b = load i1, ptr @g.20, align 1
  br i1 %v83.b, label %block86, label %then88

then88:                                           ; preds = %block79
  call fastcc void @native_trap()
  unreachable

block86:                                          ; preds = %block79
  %v90 = load i64, ptr @g.19, align 8
  %v91.not = icmp eq i64 %v90, 0
  br i1 %v91.not, label %trap92, label %ok93

trap92:                                           ; preds = %block86
  call fastcc void @native_trap()
  unreachable

ok93:                                             ; preds = %block86
  %v97 = load i64, ptr @g.29, align 8
  store i64 21, ptr %v67, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %0)
  store i64 %v97, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %0) #84, !srcloc !75600
  %11 = load i64, ptr %0, align 8, !noundef !39
  call void @llvm.lifetime.end.p0(ptr nonnull %0)
  %v100.b = load i1, ptr @g.26, align 1
  br i1 %v100.b, label %block103, label %then105

then105:                                          ; preds = %ok93
  call fastcc void @native_trap()
  unreachable

block103:                                         ; preds = %ok93
  %v107 = load i64, ptr @g.25, align 8
  %v108.not = icmp eq i64 %v107, 0
  br i1 %v108.not, label %trap109, label %ok110

trap109:                                          ; preds = %block103
  call fastcc void @native_trap()
  unreachable

ok110:                                            ; preds = %block103
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %14, label %15

14:                                               ; preds = %ok110
  call fastcc void @native_trap() #111
  unreachable

15:                                               ; preds = %ok110
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 376
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = icmp eq i64 %17, 0
  br i1 %18, label %19, label %23

19:                                               ; preds = %29, %23, %15
  %20 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %21 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %12, i64 noundef 24, ptr noundef %20) #84
  %22 = icmp eq ptr %21, null
  br i1 %22, label %31, label %ok116

23:                                               ; preds = %15
  %24 = getelementptr inbounds nuw i8, ptr %12, i64 368
  %25 = load i64, ptr %24, align 8, !noundef !39
  %26 = add i64 %25, 1
  store i64 %26, ptr %24, align 8
  %27 = urem i64 %26, %17
  %28 = icmp eq i64 %27, 0
  br i1 %28, label %29, label %19

29:                                               ; preds = %23
  %30 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %12, ptr noundef %30) #84
  br label %19

31:                                               ; preds = %19
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok116:                                            ; preds = %19
  %32 = ptrtoint ptr %21 to i64
  store i64 86, ptr %21, align 1
  %v123 = getelementptr i8, ptr %21, i64 8
  store i32 0, ptr %v123, align 1
  %v128 = getelementptr i8, ptr %21, i64 16
  store i64 0, ptr %v128, align 1
  store i64 %32, ptr %v12, align 8
  store i64 %32, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %33 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %34 = icmp eq ptr %33, null
  br i1 %34, label %35, label %36

35:                                               ; preds = %ok116
  call fastcc void @native_trap() #111
  unreachable

36:                                               ; preds = %ok116
  %37 = getelementptr inbounds nuw i8, ptr %33, i64 376
  %38 = load i64, ptr %37, align 8, !noundef !39
  %39 = icmp eq i64 %38, 0
  br i1 %39, label %40, label %44

40:                                               ; preds = %50, %44, %36
  %41 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %42 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %33, i64 noundef 24, ptr noundef %41) #84
  %43 = icmp eq ptr %42, null
  br i1 %43, label %52, label %ok135

44:                                               ; preds = %36
  %45 = getelementptr inbounds nuw i8, ptr %33, i64 368
  %46 = load i64, ptr %45, align 8, !noundef !39
  %47 = add i64 %46, 1
  store i64 %47, ptr %45, align 8
  %48 = urem i64 %47, %38
  %49 = icmp eq i64 %48, 0
  br i1 %49, label %50, label %40

50:                                               ; preds = %44
  %51 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %33, ptr noundef %51) #84
  br label %40

52:                                               ; preds = %40
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok135:                                            ; preds = %40
  %53 = ptrtoint ptr %42 to i64
  store i64 82, ptr %42, align 1
  %v142 = getelementptr i8, ptr %42, i64 8
  store i32 0, ptr %v142, align 1
  %v147 = getelementptr i8, ptr %42, i64 16
  store i64 0, ptr %v147, align 1
  store i64 %53, ptr %v15, align 8
  store i64 %53, ptr %v111, align 8
  store i64 %32, ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %54 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %55 = icmp eq ptr %54, null
  br i1 %55, label %56, label %57

56:                                               ; preds = %ok135
  call fastcc void @native_trap() #111
  unreachable

57:                                               ; preds = %ok135
  %58 = getelementptr inbounds nuw i8, ptr %54, i64 376
  %59 = load i64, ptr %58, align 8, !noundef !39
  %60 = icmp eq i64 %59, 0
  br i1 %60, label %61, label %65

61:                                               ; preds = %71, %65, %57
  %62 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %63 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %54, i64 noundef 24, ptr noundef %62) #84
  %64 = icmp eq ptr %63, null
  br i1 %64, label %73, label %ok155

65:                                               ; preds = %57
  %66 = getelementptr inbounds nuw i8, ptr %54, i64 368
  %67 = load i64, ptr %66, align 8, !noundef !39
  %68 = add i64 %67, 1
  store i64 %68, ptr %66, align 8
  %69 = urem i64 %68, %59
  %70 = icmp eq i64 %69, 0
  br i1 %70, label %71, label %61

71:                                               ; preds = %65
  %72 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %54, ptr noundef %72) #84
  br label %61

73:                                               ; preds = %61
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok155:                                            ; preds = %61
  %74 = ptrtoint ptr %63 to i64
  store i64 86, ptr %63, align 1
  %v162 = getelementptr i8, ptr %63, i64 8
  store i32 0, ptr %v162, align 1
  %v167 = getelementptr i8, ptr %63, i64 16
  store i64 0, ptr %v167, align 1
  store i64 %74, ptr %v13, align 8
  store i64 %74, ptr %v111, align 8
  store i64 %53, ptr %v130, align 8
  store i64 %32, ptr %v150, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v171, align 8
  store i64 25, ptr %v67, align 8
  %75 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %76 = icmp eq ptr %75, null
  br i1 %76, label %77, label %78

77:                                               ; preds = %ok155
  call fastcc void @native_trap() #111
  unreachable

78:                                               ; preds = %ok155
  %79 = getelementptr inbounds nuw i8, ptr %75, i64 376
  %80 = load i64, ptr %79, align 8, !noundef !39
  %81 = icmp eq i64 %80, 0
  br i1 %81, label %82, label %86

82:                                               ; preds = %92, %86, %78
  %83 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %84 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %75, i64 noundef 24, ptr noundef %83) #84
  %85 = icmp eq ptr %84, null
  br i1 %85, label %94, label %ok176

86:                                               ; preds = %78
  %87 = getelementptr inbounds nuw i8, ptr %75, i64 368
  %88 = load i64, ptr %87, align 8, !noundef !39
  %89 = add i64 %88, 1
  store i64 %89, ptr %87, align 8
  %90 = urem i64 %89, %80
  %91 = icmp eq i64 %90, 0
  br i1 %91, label %92, label %82

92:                                               ; preds = %86
  %93 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %75, ptr noundef %93) #84
  br label %82

94:                                               ; preds = %82
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok176:                                            ; preds = %82
  %95 = ptrtoint ptr %84 to i64
  store i64 86, ptr %84, align 1
  %v183 = getelementptr i8, ptr %84, i64 8
  store i32 0, ptr %v183, align 1
  %v188 = getelementptr i8, ptr %84, i64 16
  store i64 0, ptr %v188, align 1
  store i64 %95, ptr %v14, align 8
  store i64 %95, ptr %v111, align 8
  store i64 %74, ptr %v130, align 8
  store i64 %53, ptr %v150, align 8
  store i64 %32, ptr %v171, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v193, align 8
  store i64 26, ptr %v67, align 8
  %96 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %97 = icmp eq ptr %96, null
  br i1 %97, label %98, label %99

98:                                               ; preds = %ok176
  call fastcc void @native_trap() #111
  unreachable

99:                                               ; preds = %ok176
  %100 = getelementptr inbounds nuw i8, ptr %96, i64 376
  %101 = load i64, ptr %100, align 8, !noundef !39
  %102 = icmp eq i64 %101, 0
  br i1 %102, label %103, label %107

103:                                              ; preds = %113, %107, %99
  %104 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %105 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %96, i64 noundef 40, ptr noundef %104) #84
  %106 = icmp eq ptr %105, null
  br i1 %106, label %115, label %ok198

107:                                              ; preds = %99
  %108 = getelementptr inbounds nuw i8, ptr %96, i64 368
  %109 = load i64, ptr %108, align 8, !noundef !39
  %110 = add i64 %109, 1
  store i64 %110, ptr %108, align 8
  %111 = urem i64 %110, %101
  %112 = icmp eq i64 %111, 0
  br i1 %112, label %113, label %103

113:                                              ; preds = %107
  %114 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %96, ptr noundef %114) #84
  br label %103

115:                                              ; preds = %103
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok198:                                            ; preds = %103
  %116 = ptrtoint ptr %105 to i64
  store i64 62, ptr %105, align 1
  %v205 = getelementptr i8, ptr %105, i64 8
  store i64 %32, ptr %v205, align 1
  %v210 = getelementptr i8, ptr %105, i64 16
  store i64 %53, ptr %v210, align 1
  %v215 = getelementptr i8, ptr %105, i64 24
  store i64 %74, ptr %v215, align 1
  %v220 = getelementptr i8, ptr %105, i64 32
  store i64 %95, ptr %v220, align 1
  store i64 %116, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %117 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %118 = icmp eq ptr %117, null
  br i1 %118, label %119, label %120

119:                                              ; preds = %ok198
  call fastcc void @native_trap() #111
  unreachable

120:                                              ; preds = %ok198
  %121 = getelementptr inbounds nuw i8, ptr %117, i64 376
  %122 = load i64, ptr %121, align 8, !noundef !39
  %123 = icmp eq i64 %122, 0
  br i1 %123, label %124, label %128

124:                                              ; preds = %134, %128, %120
  %125 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %126 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %117, i64 noundef 24, ptr noundef %125) #84
  %127 = icmp eq ptr %126, null
  br i1 %127, label %136, label %ok227

128:                                              ; preds = %120
  %129 = getelementptr inbounds nuw i8, ptr %117, i64 368
  %130 = load i64, ptr %129, align 8, !noundef !39
  %131 = add i64 %130, 1
  store i64 %131, ptr %129, align 8
  %132 = urem i64 %131, %122
  %133 = icmp eq i64 %132, 0
  br i1 %133, label %134, label %124

134:                                              ; preds = %128
  %135 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %117, ptr noundef %135) #84
  br label %124

136:                                              ; preds = %124
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok227:                                            ; preds = %124
  %137 = ptrtoint ptr %126 to i64
  store i64 146, ptr %126, align 1
  %v234 = getelementptr i8, ptr %126, i64 8
  store i64 ptrtoint (ptr @ref.16 to i64), ptr %v234, align 1
  %v239 = getelementptr i8, ptr %126, i64 16
  store i64 %116, ptr %v239, align 1
  store i64 %137, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %138 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %139 = icmp eq ptr %138, null
  br i1 %139, label %140, label %141

140:                                              ; preds = %ok227
  call fastcc void @native_trap() #111
  unreachable

141:                                              ; preds = %ok227
  %142 = getelementptr inbounds nuw i8, ptr %138, i64 376
  %143 = load i64, ptr %142, align 8, !noundef !39
  %144 = icmp eq i64 %143, 0
  br i1 %144, label %145, label %149

145:                                              ; preds = %155, %149, %141
  %146 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %147 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %138, i64 noundef 16, ptr noundef %146) #84
  %148 = icmp eq ptr %147, null
  br i1 %148, label %157, label %ok245

149:                                              ; preds = %141
  %150 = getelementptr inbounds nuw i8, ptr %138, i64 368
  %151 = load i64, ptr %150, align 8, !noundef !39
  %152 = add i64 %151, 1
  store i64 %152, ptr %150, align 8
  %153 = urem i64 %152, %143
  %154 = icmp eq i64 %153, 0
  br i1 %154, label %155, label %145

155:                                              ; preds = %149
  %156 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %138, ptr noundef %156) #84
  br label %145

157:                                              ; preds = %145
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok245:                                            ; preds = %145
  %158 = ptrtoint ptr %147 to i64
  store i64 78, ptr %147, align 1
  %v252 = getelementptr i8, ptr %147, i64 8
  store i64 %137, ptr %v252, align 1
  store i64 %158, ptr %v16, align 8
  %v253 = load i64, ptr %v12, align 8
  %v254.not = icmp eq i64 %v253, 0
  br i1 %v254.not, label %trap255, label %ok256

trap255:                                          ; preds = %ok245
  call fastcc void @native_trap()
  unreachable

ok256:                                            ; preds = %ok245
  %v257 = inttoptr i64 %v253 to ptr
  %v258 = getelementptr i8, ptr %v257, i64 16
  store i64 701, ptr %v258, align 1
  %v259 = load i64, ptr %v12, align 8
  %v260.not = icmp eq i64 %v259, 0
  br i1 %v260.not, label %trap261, label %ok262

trap261:                                          ; preds = %ok256
  call fastcc void @native_trap()
  unreachable

ok262:                                            ; preds = %ok256
  %v263 = inttoptr i64 %v259 to ptr
  %v264 = getelementptr i8, ptr %v263, i64 8
  store i32 1, ptr %v264, align 1
  %v265 = load i64, ptr %v15, align 8
  store i64 %v265, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %159 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %160 = icmp eq ptr %159, null
  br i1 %160, label %161, label %162

161:                                              ; preds = %ok262
  call fastcc void @native_trap() #111
  unreachable

162:                                              ; preds = %ok262
  %163 = getelementptr inbounds nuw i8, ptr %159, i64 376
  %164 = load i64, ptr %163, align 8, !noundef !39
  %165 = icmp eq i64 %164, 0
  br i1 %165, label %166, label %170

166:                                              ; preds = %176, %170, %162
  %167 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %168 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %159, i64 noundef 16, ptr noundef %167) #84
  %169 = icmp eq ptr %168, null
  br i1 %169, label %178, label %ok271

170:                                              ; preds = %162
  %171 = getelementptr inbounds nuw i8, ptr %159, i64 368
  %172 = load i64, ptr %171, align 8, !noundef !39
  %173 = add i64 %172, 1
  store i64 %173, ptr %171, align 8
  %174 = urem i64 %173, %164
  %175 = icmp eq i64 %174, 0
  br i1 %175, label %176, label %166

176:                                              ; preds = %170
  %177 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %159, ptr noundef %177) #84
  br label %166

178:                                              ; preds = %166
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok271:                                            ; preds = %166
  store i64 58, ptr %168, align 1
  %v278 = getelementptr i8, ptr %168, i64 8
  store i64 1, ptr %v278, align 1
  %v279.not = icmp eq i64 %v265, 0
  br i1 %v279.not, label %trap280, label %ok281

trap280:                                          ; preds = %ok271
  call fastcc void @native_trap()
  unreachable

ok281:                                            ; preds = %ok271
  %179 = ptrtoint ptr %168 to i64
  %v282 = inttoptr i64 %v265 to ptr
  %v283 = getelementptr i8, ptr %v282, i64 16
  store i64 %179, ptr %v283, align 1
  %v284 = load i64, ptr %v15, align 8
  %v285.not = icmp eq i64 %v284, 0
  br i1 %v285.not, label %trap286, label %ok287

trap286:                                          ; preds = %ok281
  call fastcc void @native_trap()
  unreachable

ok287:                                            ; preds = %ok281
  %v288 = inttoptr i64 %v284 to ptr
  %v289 = getelementptr i8, ptr %v288, i64 8
  store i32 1, ptr %v289, align 1
  %v290 = load i64, ptr %v13, align 8
  %v291.not = icmp eq i64 %v290, 0
  br i1 %v291.not, label %trap292, label %ok293

trap292:                                          ; preds = %ok287
  call fastcc void @native_trap()
  unreachable

ok293:                                            ; preds = %ok287
  %v294 = inttoptr i64 %v290 to ptr
  %v295 = getelementptr i8, ptr %v294, i64 16
  store i64 743483, ptr %v295, align 1
  %v296 = load i64, ptr %v13, align 8
  %v297.not = icmp eq i64 %v296, 0
  br i1 %v297.not, label %trap298, label %ok299

trap298:                                          ; preds = %ok293
  call fastcc void @native_trap()
  unreachable

ok299:                                            ; preds = %ok293
  %v300 = inttoptr i64 %v296 to ptr
  %v301 = getelementptr i8, ptr %v300, i64 8
  store i32 1, ptr %v301, align 1
  %v302 = load i64, ptr %v14, align 8
  %v303.not = icmp eq i64 %v302, 0
  br i1 %v303.not, label %trap304, label %ok305

trap304:                                          ; preds = %ok299
  call fastcc void @native_trap()
  unreachable

ok305:                                            ; preds = %ok299
  %v306 = inttoptr i64 %v302 to ptr
  %v307 = getelementptr i8, ptr %v306, i64 16
  store i64 524287, ptr %v307, align 1
  %v308 = load i64, ptr %v14, align 8
  %v309.not = icmp eq i64 %v308, 0
  br i1 %v309.not, label %trap310, label %ok311

trap310:                                          ; preds = %ok305
  call fastcc void @native_trap()
  unreachable

ok311:                                            ; preds = %ok305
  %v312 = inttoptr i64 %v308 to ptr
  %v313 = getelementptr i8, ptr %v312, i64 8
  store i32 1, ptr %v313, align 1
  store i64 21, ptr %v67, align 8
  %180 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %181 = icmp eq ptr %180, null
  br i1 %181, label %182, label %183

182:                                              ; preds = %ok311
  call fastcc void @native_trap() #111
  unreachable

183:                                              ; preds = %ok311
  %184 = getelementptr inbounds nuw i8, ptr %180, i64 376
  %185 = load i64, ptr %184, align 8, !noundef !39
  %186 = icmp eq i64 %185, 0
  br i1 %186, label %187, label %191

187:                                              ; preds = %197, %191, %183
  %188 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %189 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %180, i64 noundef 24, ptr noundef %188) #84
  %190 = icmp eq ptr %189, null
  br i1 %190, label %199, label %ok318

191:                                              ; preds = %183
  %192 = getelementptr inbounds nuw i8, ptr %180, i64 368
  %193 = load i64, ptr %192, align 8, !noundef !39
  %194 = add i64 %193, 1
  store i64 %194, ptr %192, align 8
  %195 = urem i64 %194, %185
  %196 = icmp eq i64 %195, 0
  br i1 %196, label %197, label %187

197:                                              ; preds = %191
  %198 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %180, ptr noundef %198) #84
  br label %187

199:                                              ; preds = %187
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok318:                                            ; preds = %187
  %200 = ptrtoint ptr %189 to i64
  store i64 90, ptr %189, align 1
  %v325 = getelementptr i8, ptr %189, i64 8
  store i32 0, ptr %v325, align 1
  %v330 = getelementptr i8, ptr %189, i64 16
  store i64 0, ptr %v330, align 1
  store i64 %200, ptr %v11, align 8
  %v331 = load i64, ptr %v16, align 8
  store i64 %200, ptr %v111, align 8
  store i64 %v331, ptr %v130, align 8
  store i64 %200, ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %201 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %202 = icmp eq ptr %201, null
  br i1 %202, label %203, label %204

203:                                              ; preds = %ok318
  call fastcc void @native_trap() #111
  unreachable

204:                                              ; preds = %ok318
  %205 = getelementptr inbounds nuw i8, ptr %201, i64 376
  %206 = load i64, ptr %205, align 8, !noundef !39
  %207 = icmp eq i64 %206, 0
  br i1 %207, label %208, label %212

208:                                              ; preds = %218, %212, %204
  %209 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %210 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %201, i64 noundef 24, ptr noundef %209) #84
  %211 = icmp eq ptr %210, null
  br i1 %211, label %220, label %ok340

212:                                              ; preds = %204
  %213 = getelementptr inbounds nuw i8, ptr %201, i64 368
  %214 = load i64, ptr %213, align 8, !noundef !39
  %215 = add i64 %214, 1
  store i64 %215, ptr %213, align 8
  %216 = urem i64 %215, %206
  %217 = icmp eq i64 %216, 0
  br i1 %217, label %218, label %208

218:                                              ; preds = %212
  %219 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %201, ptr noundef %219) #84
  br label %208

220:                                              ; preds = %208
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok340:                                            ; preds = %208
  %221 = ptrtoint ptr %210 to i64
  store i64 54, ptr %210, align 1
  %v347 = getelementptr i8, ptr %210, i64 8
  store i64 %v331, ptr %v347, align 1
  %v352 = getelementptr i8, ptr %210, i64 16
  store i64 %200, ptr %v352, align 1
  store i64 %221, ptr %v111, align 8
  store i64 %200, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %222 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %223 = icmp eq ptr %222, null
  br i1 %223, label %224, label %225

224:                                              ; preds = %ok340
  call fastcc void @native_trap() #111
  unreachable

225:                                              ; preds = %ok340
  %226 = getelementptr inbounds nuw i8, ptr %222, i64 376
  %227 = load i64, ptr %226, align 8, !noundef !39
  %228 = icmp eq i64 %227, 0
  br i1 %228, label %229, label %233

229:                                              ; preds = %239, %233, %225
  %230 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %231 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %222, i64 noundef 16, ptr noundef %230) #84
  %232 = icmp eq ptr %231, null
  br i1 %232, label %241, label %ok359

233:                                              ; preds = %225
  %234 = getelementptr inbounds nuw i8, ptr %222, i64 368
  %235 = load i64, ptr %234, align 8, !noundef !39
  %236 = add i64 %235, 1
  store i64 %236, ptr %234, align 8
  %237 = urem i64 %236, %227
  %238 = icmp eq i64 %237, 0
  br i1 %238, label %239, label %229

239:                                              ; preds = %233
  %240 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %222, ptr noundef %240) #84
  br label %229

241:                                              ; preds = %229
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok359:                                            ; preds = %229
  %242 = ptrtoint ptr %231 to i64
  store i64 50, ptr %231, align 1
  %v366 = getelementptr i8, ptr %231, i64 8
  store i64 %221, ptr %v366, align 1
  store i64 %242, ptr %v330, align 1
  %v372 = load i64, ptr %v11, align 8
  %v373.not = icmp eq i64 %v372, 0
  br i1 %v373.not, label %trap374, label %ok375

trap374:                                          ; preds = %ok359
  call fastcc void @native_trap()
  unreachable

ok375:                                            ; preds = %ok359
  %v376 = inttoptr i64 %v372 to ptr
  %v377 = getelementptr i8, ptr %v376, i64 8
  store i32 1, ptr %v377, align 1
  %v378 = load i64, ptr %v16, align 8
  %v379 = load i64, ptr %v11, align 8
  store i64 %v379, ptr %v111, align 8
  store i64 %v378, ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.14 to i64), ptr %v150, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v171, align 8
  store i64 25, ptr %v67, align 8
  %243 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %244 = icmp eq ptr %243, null
  br i1 %244, label %245, label %246

245:                                              ; preds = %ok375
  call fastcc void @native_trap() #111
  unreachable

246:                                              ; preds = %ok375
  %247 = getelementptr inbounds nuw i8, ptr %243, i64 376
  %248 = load i64, ptr %247, align 8, !noundef !39
  %249 = icmp eq i64 %248, 0
  br i1 %249, label %250, label %254

250:                                              ; preds = %260, %254, %246
  %251 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %252 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %243, i64 noundef 24, ptr noundef %251) #84
  %253 = icmp eq ptr %252, null
  br i1 %253, label %262, label %ok388

254:                                              ; preds = %246
  %255 = getelementptr inbounds nuw i8, ptr %243, i64 368
  %256 = load i64, ptr %255, align 8, !noundef !39
  %257 = add i64 %256, 1
  store i64 %257, ptr %255, align 8
  %258 = urem i64 %257, %248
  %259 = icmp eq i64 %258, 0
  br i1 %259, label %260, label %250

260:                                              ; preds = %254
  %261 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %243, ptr noundef %261) #84
  br label %250

262:                                              ; preds = %250
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok388:                                            ; preds = %250
  %263 = ptrtoint ptr %252 to i64
  store i64 46, ptr %252, align 1
  %v395 = getelementptr i8, ptr %252, i64 8
  store i64 %v378, ptr %v395, align 1
  %v400 = getelementptr i8, ptr %252, i64 16
  store i64 %v379, ptr %v400, align 1
  store i64 %263, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.14 to i64), ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %264 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %265 = icmp eq ptr %264, null
  br i1 %265, label %266, label %267

266:                                              ; preds = %ok388
  call fastcc void @native_trap() #111
  unreachable

267:                                              ; preds = %ok388
  %268 = getelementptr inbounds nuw i8, ptr %264, i64 376
  %269 = load i64, ptr %268, align 8, !noundef !39
  %270 = icmp eq i64 %269, 0
  br i1 %270, label %271, label %275

271:                                              ; preds = %281, %275, %267
  %272 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %273 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %264, i64 noundef 24, ptr noundef %272) #84
  %274 = icmp eq ptr %273, null
  br i1 %274, label %283, label %ok408

275:                                              ; preds = %267
  %276 = getelementptr inbounds nuw i8, ptr %264, i64 368
  %277 = load i64, ptr %276, align 8, !noundef !39
  %278 = add i64 %277, 1
  store i64 %278, ptr %276, align 8
  %279 = urem i64 %278, %269
  %280 = icmp eq i64 %279, 0
  br i1 %280, label %281, label %271

281:                                              ; preds = %275
  %282 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %264, ptr noundef %282) #84
  br label %271

283:                                              ; preds = %271
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok408:                                            ; preds = %271
  %284 = ptrtoint ptr %273 to i64
  store i64 146, ptr %273, align 1
  %v415 = getelementptr i8, ptr %273, i64 8
  store i64 ptrtoint (ptr @ref.14 to i64), ptr %v415, align 1
  %v420 = getelementptr i8, ptr %273, i64 16
  store i64 %263, ptr %v420, align 1
  store i64 %284, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %285 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %286 = icmp eq ptr %285, null
  br i1 %286, label %287, label %288

287:                                              ; preds = %ok408
  call fastcc void @native_trap() #111
  unreachable

288:                                              ; preds = %ok408
  %289 = getelementptr inbounds nuw i8, ptr %285, i64 376
  %290 = load i64, ptr %289, align 8, !noundef !39
  %291 = icmp eq i64 %290, 0
  br i1 %291, label %292, label %296

292:                                              ; preds = %302, %296, %288
  %293 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %294 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %285, i64 noundef 16, ptr noundef %293) #84
  %295 = icmp eq ptr %294, null
  br i1 %295, label %304, label %ok427

296:                                              ; preds = %288
  %297 = getelementptr inbounds nuw i8, ptr %285, i64 368
  %298 = load i64, ptr %297, align 8, !noundef !39
  %299 = add i64 %298, 1
  store i64 %299, ptr %297, align 8
  %300 = urem i64 %299, %290
  %301 = icmp eq i64 %300, 0
  br i1 %301, label %302, label %292

302:                                              ; preds = %296
  %303 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %285, ptr noundef %303) #84
  br label %292

304:                                              ; preds = %292
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok427:                                            ; preds = %292
  %305 = ptrtoint ptr %294 to i64
  store i64 78, ptr %294, align 1
  %v434 = getelementptr i8, ptr %294, i64 8
  store i64 %284, ptr %v434, align 1
  store i64 %305, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %306 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %307 = icmp eq ptr %306, null
  br i1 %307, label %308, label %309

308:                                              ; preds = %ok427
  call fastcc void @native_trap() #111
  unreachable

309:                                              ; preds = %ok427
  %310 = getelementptr inbounds nuw i8, ptr %306, i64 376
  %311 = load i64, ptr %310, align 8, !noundef !39
  %312 = icmp eq i64 %311, 0
  br i1 %312, label %313, label %317

313:                                              ; preds = %323, %317, %309
  %314 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %315 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %306, i64 noundef 16, ptr noundef %314) #84
  %316 = icmp eq ptr %315, null
  br i1 %316, label %325, label %ok441

317:                                              ; preds = %309
  %318 = getelementptr inbounds nuw i8, ptr %306, i64 368
  %319 = load i64, ptr %318, align 8, !noundef !39
  %320 = add i64 %319, 1
  store i64 %320, ptr %318, align 8
  %321 = urem i64 %320, %311
  %322 = icmp eq i64 %321, 0
  br i1 %322, label %323, label %313

323:                                              ; preds = %317
  %324 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %306, ptr noundef %324) #84
  br label %313

325:                                              ; preds = %313
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok441:                                            ; preds = %313
  %326 = ptrtoint ptr %315 to i64
  store i64 74, ptr %315, align 1
  %v448 = getelementptr i8, ptr %315, i64 8
  store i64 %305, ptr %v448, align 1
  store i64 %326, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %327 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %328 = icmp eq ptr %327, null
  br i1 %328, label %329, label %330

329:                                              ; preds = %ok441
  call fastcc void @native_trap() #111
  unreachable

330:                                              ; preds = %ok441
  %331 = getelementptr inbounds nuw i8, ptr %327, i64 376
  %332 = load i64, ptr %331, align 8, !noundef !39
  %333 = icmp eq i64 %332, 0
  br i1 %333, label %334, label %338

334:                                              ; preds = %344, %338, %330
  %335 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %336 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %327, i64 noundef 24, ptr noundef %335) #84
  %337 = icmp eq ptr %336, null
  br i1 %337, label %346, label %ok455

338:                                              ; preds = %330
  %339 = getelementptr inbounds nuw i8, ptr %327, i64 368
  %340 = load i64, ptr %339, align 8, !noundef !39
  %341 = add i64 %340, 1
  store i64 %341, ptr %339, align 8
  %342 = urem i64 %341, %332
  %343 = icmp eq i64 %342, 0
  br i1 %343, label %344, label %334

344:                                              ; preds = %338
  %345 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %327, ptr noundef %345) #84
  br label %334

346:                                              ; preds = %334
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok455:                                            ; preds = %334
  %347 = ptrtoint ptr %336 to i64
  store i64 194, ptr %336, align 1
  %v462 = getelementptr i8, ptr %336, i64 8
  store i64 ptrtoint (ptr @ref.12 to i64), ptr %v462, align 1
  %v467 = getelementptr i8, ptr %336, i64 16
  store i64 %326, ptr %v467, align 1
  store i64 %347, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %348 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %349 = icmp eq ptr %348, null
  br i1 %349, label %350, label %351

350:                                              ; preds = %ok455
  call fastcc void @native_trap() #111
  unreachable

351:                                              ; preds = %ok455
  %352 = getelementptr inbounds nuw i8, ptr %348, i64 376
  %353 = load i64, ptr %352, align 8, !noundef !39
  %354 = icmp eq i64 %353, 0
  br i1 %354, label %355, label %359

355:                                              ; preds = %365, %359, %351
  %356 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %357 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %348, i64 noundef 24, ptr noundef %356) #84
  %358 = icmp eq ptr %357, null
  br i1 %358, label %367, label %ok473

359:                                              ; preds = %351
  %360 = getelementptr inbounds nuw i8, ptr %348, i64 368
  %361 = load i64, ptr %360, align 8, !noundef !39
  %362 = add i64 %361, 1
  store i64 %362, ptr %360, align 8
  %363 = urem i64 %362, %353
  %364 = icmp eq i64 %363, 0
  br i1 %364, label %365, label %355

365:                                              ; preds = %359
  %366 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %348, ptr noundef %366) #84
  br label %355

367:                                              ; preds = %355
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok473:                                            ; preds = %355
  %368 = ptrtoint ptr %357 to i64
  store i64 102, ptr %357, align 1
  %v480 = getelementptr i8, ptr %357, i64 8
  store i32 1, ptr %v480, align 1
  %v485 = getelementptr i8, ptr %357, i64 16
  store i64 %347, ptr %v485, align 1
  store i64 %368, ptr %v7, align 8
  %v491 = load i32, ptr %v480, align 1
  %v492 = icmp eq i32 %v491, 0
  br i1 %v492, label %then496, label %ok501

then496:                                          ; preds = %ok473
  call fastcc void @native_trap()
  unreachable

ok501:                                            ; preds = %ok473
  %v504 = load i64, ptr %v485, align 1
  %v505.not = icmp eq i64 %v504, 0
  br i1 %v505.not, label %trap506, label %ok507

trap506:                                          ; preds = %ok501
  call fastcc void @native_trap()
  unreachable

ok507:                                            ; preds = %ok501
  %v508 = inttoptr i64 %v504 to ptr
  %v509 = getelementptr i8, ptr %v508, i64 16
  %v510 = load i64, ptr %v509, align 1
  %369 = icmp ne i64 %v510, 0
  %370 = and i64 %v510, 1
  %.not.i = icmp eq i64 %370, 0
  %or.cond = and i1 %369, %.not.i
  br i1 %or.cond, label %371, label %trap513

371:                                              ; preds = %ok507
  %372 = inttoptr i64 %v510 to ptr
  %373 = load i64, ptr %372, align 8, !noundef !39
  %374 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %375 = icmp eq ptr %374, null
  br i1 %375, label %388, label %376

376:                                              ; preds = %371
  switch i64 %373, label %377 [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

377:                                              ; preds = %376
  %378 = getelementptr inbounds nuw i8, ptr %374, i64 360
  %379 = load i64, ptr %378, align 8, !noundef !39
  %380 = lshr i64 %373, 2
  %381 = add nsw i64 %380, -1
  %382 = icmp ult i64 %381, %379
  br i1 %382, label %383, label %.loopexit

383:                                              ; preds = %377
  %384 = getelementptr inbounds nuw i8, ptr %374, i64 352
  %385 = load ptr, ptr %384, align 8, !nonnull !39, !noundef !39
  %386 = getelementptr inbounds nuw i64, ptr %385, i64 %381
  %387 = load i64, ptr %386, align 8, !noundef !39
  switch i64 %387, label %.preheader [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

388:                                              ; preds = %371
  call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %393, %383
  %389 = phi i64 [ %395, %393 ], [ %387, %383 ]
  %390 = lshr i64 %389, 2
  %391 = add nsw i64 %390, -1
  %392 = icmp ult i64 %391, %379
  br i1 %392, label %393, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %377
  call fastcc void @native_trap() #111
  unreachable

393:                                              ; preds = %.preheader
  %394 = getelementptr inbounds nuw i64, ptr %385, i64 %391
  %395 = load i64, ptr %394, align 8, !noundef !39
  switch i64 %395, label %.preheader [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %393, %393, %383, %383, %376, %376
  %.in1254 = phi i64 [ %373, %376 ], [ %387, %383 ], [ %387, %383 ], [ %373, %376 ], [ %395, %393 ], [ %395, %393 ]
  %396 = icmp eq i64 %.in1254, 74
  br i1 %396, label %ok514, label %trap513

trap513:                                          ; preds = %native_ref_test.exit, %ok507
  call fastcc void @native_trap()
  unreachable

ok514:                                            ; preds = %native_ref_test.exit
  store i64 %v510, ptr %v19, align 8
  %v519 = getelementptr i8, ptr %372, i64 8
  %v520 = load i64, ptr %v519, align 1
  %v521.not = icmp eq i64 %v520, 0
  br i1 %v521.not, label %trap522, label %ok523

trap522:                                          ; preds = %ok514
  call fastcc void @native_trap()
  unreachable

ok523:                                            ; preds = %ok514
  %v524 = inttoptr i64 %v520 to ptr
  %v525 = getelementptr i8, ptr %v524, i64 8
  %v526 = load i64, ptr %v525, align 1
  store i64 %v526, ptr %v20, align 8
  %v527.not = icmp eq i64 %v526, 0
  br i1 %v527.not, label %trap528, label %ok529

trap528:                                          ; preds = %ok523
  call fastcc void @native_trap()
  unreachable

ok529:                                            ; preds = %ok523
  %v530 = inttoptr i64 %v526 to ptr
  %v538 = getelementptr i8, ptr %v530, i64 8
  %v539 = load i64, ptr %v538, align 1
  %v540.not = icmp eq i64 %v539, 0
  br i1 %v540.not, label %trap541, label %ok542

trap541:                                          ; preds = %ok529
  call fastcc void @native_trap()
  unreachable

ok542:                                            ; preds = %ok529
  %v531 = getelementptr i8, ptr %v530, i64 16
  %v532 = load i64, ptr %v531, align 1
  %v543 = inttoptr i64 %v539 to ptr
  %v544 = getelementptr i8, ptr %v543, i64 8
  %v545 = load ptr, ptr %v544, align 1
  store i64 %v532, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v548 = call tailcc i64 %v545(i64 %v532, i64 10)
  %v549.b = load i1, ptr @g.4, align 1
  br i1 %v549.b, label %block552, label %then554

then554:                                          ; preds = %ok542
  call fastcc void @native_trap()
  unreachable

block552:                                         ; preds = %ok542
  %v556 = load i64, ptr @g.3, align 8
  %v557.not = icmp eq i64 %v556, 0
  br i1 %v557.not, label %trap558, label %ok559

trap558:                                          ; preds = %block552
  call fastcc void @native_trap()
  unreachable

ok559:                                            ; preds = %block552
  %v564 = icmp ugt i64 %v548, 4294967295
  br i1 %v564, label %then568, label %block566

then568:                                          ; preds = %ok559
  call fastcc void @native_trap()
  unreachable

block566:                                         ; preds = %ok559
  store i64 21, ptr %v67, align 8
  %397 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %398 = icmp eq ptr %397, null
  br i1 %398, label %399, label %400

399:                                              ; preds = %block566
  call fastcc void @native_trap() #111
  unreachable

400:                                              ; preds = %block566
  %401 = getelementptr inbounds nuw i8, ptr %397, i64 376
  %402 = load i64, ptr %401, align 8, !noundef !39
  %403 = icmp eq i64 %402, 0
  br i1 %403, label %404, label %408

404:                                              ; preds = %414, %408, %400
  %405 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %406 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %397, i64 noundef 24, ptr noundef %405) #84
  %407 = icmp eq ptr %406, null
  br i1 %407, label %416, label %ok574

408:                                              ; preds = %400
  %409 = getelementptr inbounds nuw i8, ptr %397, i64 368
  %410 = load i64, ptr %409, align 8, !noundef !39
  %411 = add i64 %410, 1
  store i64 %411, ptr %409, align 8
  %412 = urem i64 %411, %402
  %413 = icmp eq i64 %412, 0
  br i1 %413, label %414, label %404

414:                                              ; preds = %408
  %415 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %397, ptr noundef %415) #84
  br label %404

416:                                              ; preds = %404
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok574:                                            ; preds = %404
  %417 = ptrtoint ptr %406 to i64
  store i64 102, ptr %406, align 1
  %v581 = getelementptr i8, ptr %406, i64 8
  store i32 0, ptr %v581, align 1
  %v586 = getelementptr i8, ptr %406, i64 16
  store i64 0, ptr %v586, align 1
  store i64 %417, ptr %v6, align 8
  %v587 = load i64, ptr %v19, align 8
  %v588.not = icmp eq i64 %v587, 0
  br i1 %v588.not, label %trap589, label %ok590

trap589:                                          ; preds = %ok574
  call fastcc void @native_trap()
  unreachable

ok590:                                            ; preds = %ok574
  %v591 = inttoptr i64 %v587 to ptr
  %v592 = getelementptr i8, ptr %v591, i64 8
  %v593 = load i64, ptr %v592, align 1
  %v596 = trunc nuw i64 %v548 to i32
  store i64 %v593, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v130, align 8
  store i64 %417, ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %v602 = call fastcc i64 @native_array_new(i32 %v596)
  store i64 %v602, ptr %v111, align 8
  store i64 %v593, ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v150, align 8
  store i64 %417, ptr %v171, align 8
  store i64 25, ptr %v67, align 8
  %418 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %419 = icmp eq ptr %418, null
  br i1 %419, label %420, label %421

420:                                              ; preds = %ok590
  call fastcc void @native_trap() #111
  unreachable

421:                                              ; preds = %ok590
  %422 = getelementptr inbounds nuw i8, ptr %418, i64 376
  %423 = load i64, ptr %422, align 8, !noundef !39
  %424 = icmp eq i64 %423, 0
  br i1 %424, label %425, label %429

425:                                              ; preds = %435, %429, %421
  %426 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %427 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %418, i64 noundef 16, ptr noundef %426) #84
  %428 = icmp eq ptr %427, null
  br i1 %428, label %437, label %ok611

429:                                              ; preds = %421
  %430 = getelementptr inbounds nuw i8, ptr %418, i64 368
  %431 = load i64, ptr %430, align 8, !noundef !39
  %432 = add i64 %431, 1
  store i64 %432, ptr %430, align 8
  %433 = urem i64 %432, %423
  %434 = icmp eq i64 %433, 0
  br i1 %434, label %435, label %425

435:                                              ; preds = %429
  %436 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %418, ptr noundef %436) #84
  br label %425

437:                                              ; preds = %425
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok611:                                            ; preds = %425
  %438 = ptrtoint ptr %427 to i64
  store i64 130, ptr %427, align 1
  %v618 = getelementptr i8, ptr %427, i64 8
  store i64 %v602, ptr %v618, align 1
  %v619 = load i64, ptr %v6, align 8
  store i64 %v619, ptr %v111, align 8
  store i64 %438, ptr %v130, align 8
  store i64 %v593, ptr %v150, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v171, align 8
  store i64 %417, ptr %v193, align 8
  store i64 26, ptr %v67, align 8
  %439 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %440 = icmp eq ptr %439, null
  br i1 %440, label %441, label %442

441:                                              ; preds = %ok611
  call fastcc void @native_trap() #111
  unreachable

442:                                              ; preds = %ok611
  %443 = getelementptr inbounds nuw i8, ptr %439, i64 376
  %444 = load i64, ptr %443, align 8, !noundef !39
  %445 = icmp eq i64 %444, 0
  br i1 %445, label %446, label %450

446:                                              ; preds = %456, %450, %442
  %447 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %448 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %439, i64 noundef 40, ptr noundef %447) #84
  %449 = icmp eq ptr %448, null
  br i1 %449, label %458, label %ok629

450:                                              ; preds = %442
  %451 = getelementptr inbounds nuw i8, ptr %439, i64 368
  %452 = load i64, ptr %451, align 8, !noundef !39
  %453 = add i64 %452, 1
  store i64 %453, ptr %451, align 8
  %454 = urem i64 %453, %444
  %455 = icmp eq i64 %454, 0
  br i1 %455, label %456, label %446

456:                                              ; preds = %450
  %457 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %439, ptr noundef %457) #84
  br label %446

458:                                              ; preds = %446
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok629:                                            ; preds = %446
  %459 = ptrtoint ptr %448 to i64
  store i64 42, ptr %448, align 1
  %v636 = getelementptr i8, ptr %448, i64 8
  store i64 %v593, ptr %v636, align 1
  %v641 = getelementptr i8, ptr %448, i64 16
  store i64 %v548, ptr %v641, align 1
  %v646 = getelementptr i8, ptr %448, i64 24
  store i64 %438, ptr %v646, align 1
  %v651 = getelementptr i8, ptr %448, i64 32
  store i64 %v619, ptr %v651, align 1
  store i64 %459, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v130, align 8
  store i64 %417, ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %460 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %461 = icmp eq ptr %460, null
  br i1 %461, label %462, label %463

462:                                              ; preds = %ok629
  call fastcc void @native_trap() #111
  unreachable

463:                                              ; preds = %ok629
  %464 = getelementptr inbounds nuw i8, ptr %460, i64 376
  %465 = load i64, ptr %464, align 8, !noundef !39
  %466 = icmp eq i64 %465, 0
  br i1 %466, label %467, label %471

467:                                              ; preds = %477, %471, %463
  %468 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %469 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %460, i64 noundef 24, ptr noundef %468) #84
  %470 = icmp eq ptr %469, null
  br i1 %470, label %479, label %ok659

471:                                              ; preds = %463
  %472 = getelementptr inbounds nuw i8, ptr %460, i64 368
  %473 = load i64, ptr %472, align 8, !noundef !39
  %474 = add i64 %473, 1
  store i64 %474, ptr %472, align 8
  %475 = urem i64 %474, %465
  %476 = icmp eq i64 %475, 0
  br i1 %476, label %477, label %467

477:                                              ; preds = %471
  %478 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %460, ptr noundef %478) #84
  br label %467

479:                                              ; preds = %467
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok659:                                            ; preds = %467
  %480 = ptrtoint ptr %469 to i64
  store i64 194, ptr %469, align 1
  %v666 = getelementptr i8, ptr %469, i64 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v666, align 1
  %v671 = getelementptr i8, ptr %469, i64 16
  store i64 %459, ptr %v671, align 1
  store i64 %480, ptr %v586, align 1
  %v677 = load i64, ptr %v6, align 8
  %v678.not = icmp eq i64 %v677, 0
  br i1 %v678.not, label %trap679, label %ok680

trap679:                                          ; preds = %ok659
  call fastcc void @native_trap()
  unreachable

ok680:                                            ; preds = %ok659
  %v681 = inttoptr i64 %v677 to ptr
  %v682 = getelementptr i8, ptr %v681, i64 8
  store i32 1, ptr %v682, align 1
  %v683 = load i64, ptr %v6, align 8
  %v684.not = icmp eq i64 %v683, 0
  br i1 %v684.not, label %trap685, label %ok686

trap685:                                          ; preds = %ok680
  call fastcc void @native_trap()
  unreachable

ok686:                                            ; preds = %ok680
  %v687 = inttoptr i64 %v683 to ptr
  %v688 = getelementptr i8, ptr %v687, i64 8
  %v689 = load i32, ptr %v688, align 1
  %v690 = icmp eq i32 %v689, 0
  br i1 %v690, label %then694, label %ok699

then694:                                          ; preds = %ok686
  call fastcc void @native_trap()
  unreachable

ok699:                                            ; preds = %ok686
  %v701 = getelementptr i8, ptr %v687, i64 16
  %v702 = load i64, ptr %v701, align 1
  %v703.not = icmp eq i64 %v702, 0
  br i1 %v703.not, label %trap704, label %ok705

trap704:                                          ; preds = %ok699
  call fastcc void @native_trap()
  unreachable

ok705:                                            ; preds = %ok699
  store i64 %v702, ptr %v21, align 8
  %v709 = inttoptr i64 %v702 to ptr
  %v717 = getelementptr i8, ptr %v709, i64 8
  %v718 = load i64, ptr %v717, align 1
  %v719.not = icmp eq i64 %v718, 0
  br i1 %v719.not, label %trap720, label %ok721

trap720:                                          ; preds = %ok705
  call fastcc void @native_trap()
  unreachable

ok721:                                            ; preds = %ok705
  %v710 = getelementptr i8, ptr %v709, i64 16
  %v711 = load i64, ptr %v710, align 1
  %v722 = inttoptr i64 %v718 to ptr
  %v723 = getelementptr i8, ptr %v722, i64 8
  %v724 = load ptr, ptr %v723, align 1
  store i64 %v711, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v727 = call tailcc i64 %v724(i64 %v711, i64 0)
  store i64 %v727, ptr %v17, align 8
  %v728.b = load i1, ptr @g.6, align 1
  br i1 %v728.b, label %block731, label %then733

then733:                                          ; preds = %ok721
  call fastcc void @native_trap()
  unreachable

block731:                                         ; preds = %ok721
  %v735 = load i64, ptr @g.5, align 8
  %v736.not = icmp eq i64 %v735, 0
  br i1 %v736.not, label %trap737, label %ok738

trap737:                                          ; preds = %block731
  call fastcc void @native_trap()
  unreachable

ok738:                                            ; preds = %block731
  %v739.b = load i1, ptr @g.8, align 1
  br i1 %v739.b, label %block742, label %then744

then744:                                          ; preds = %ok738
  call fastcc void @native_trap()
  unreachable

block742:                                         ; preds = %ok738
  %v746 = load i64, ptr @g.7, align 8
  %v747.not = icmp eq i64 %v746, 0
  br i1 %v747.not, label %trap748, label %ok749

trap748:                                          ; preds = %block742
  call fastcc void @native_trap()
  unreachable

ok749:                                            ; preds = %block742
  %v752.not = icmp eq i64 %v727, 0
  br i1 %v752.not, label %trap753, label %ok754

trap753:                                          ; preds = %ok749
  call fastcc void @native_trap()
  unreachable

ok754:                                            ; preds = %ok749
  %v755 = inttoptr i64 %v727 to ptr
  %v756 = getelementptr i8, ptr %v755, i64 8
  %v757 = load i64, ptr %v756, align 1
  %v758.not = icmp eq i64 %v757, 0
  br i1 %v758.not, label %trap759, label %ok760

trap759:                                          ; preds = %ok754
  call fastcc void @native_trap()
  unreachable

ok760:                                            ; preds = %ok754
  %v761 = and i64 %v757, 1
  %v762 = icmp eq i64 %v761, 0
  br i1 %v762, label %ok764, label %trap763

trap763:                                          ; preds = %ok760
  call fastcc void @native_trap()
  unreachable

ok764:                                            ; preds = %ok760
  %v765 = inttoptr i64 %v757 to ptr
  %v766 = getelementptr i8, ptr %v765, i64 8
  %v767 = load i64, ptr %v766, align 1
  %v769 = and i64 %v767, 4294967295
  store i64 %v727, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v772 = call tailcc i64 @f.5(i64 %v727, i64 %v769)
  store i64 %v772, ptr %v8, align 8
  store i64 %v772, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %481 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %482 = icmp eq ptr %481, null
  br i1 %482, label %483, label %484

483:                                              ; preds = %ok764
  call fastcc void @native_trap() #111
  unreachable

484:                                              ; preds = %ok764
  %485 = getelementptr inbounds nuw i8, ptr %481, i64 376
  %486 = load i64, ptr %485, align 8, !noundef !39
  %487 = icmp eq i64 %486, 0
  br i1 %487, label %488, label %492

488:                                              ; preds = %498, %492, %484
  %489 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %490 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %481, i64 noundef 16, ptr noundef %489) #84
  %491 = icmp eq ptr %490, null
  br i1 %491, label %500, label %ok778

492:                                              ; preds = %484
  %493 = getelementptr inbounds nuw i8, ptr %481, i64 368
  %494 = load i64, ptr %493, align 8, !noundef !39
  %495 = add i64 %494, 1
  store i64 %495, ptr %493, align 8
  %496 = urem i64 %495, %486
  %497 = icmp eq i64 %496, 0
  br i1 %497, label %498, label %488

498:                                              ; preds = %492
  %499 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %481, ptr noundef %499) #84
  br label %488

500:                                              ; preds = %488
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok778:                                            ; preds = %488
  %501 = ptrtoint ptr %490 to i64
  store i64 34, ptr %490, align 1
  %v785 = getelementptr i8, ptr %490, i64 8
  store i64 %v772, ptr %v785, align 1
  %v788 = load i64, ptr %v8, align 8
  %v789.not = icmp eq i64 %v788, 0
  br i1 %v789.not, label %trap790, label %block799

trap790:                                          ; preds = %ok778
  call fastcc void @native_trap()
  unreachable

block799:                                         ; preds = %ok778
  %v792 = inttoptr i64 %v788 to ptr
  %v793 = getelementptr i8, ptr %v792, i64 8
  %v794 = load i32, ptr %v793, align 1
  store i64 %501, ptr %v111, align 8
  store i64 %v788, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %v807 = call tailcc i32 @f.4(i64 %v788, i32 0)
  %v808 = load i64, ptr %v8, align 8
  store i64 %501, ptr %v111, align 8
  store i64 %v808, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %v814 = call tailcc i32 @f.4(i64 %v808, i32 %v794)
  %v816 = sub i32 %v814, %v807
  store i64 %501, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v820 = call fastcc i64 @native_array_new(i32 %v816)
  store i64 %v820, ptr %v22, align 8
  %v821 = load i64, ptr %v8, align 8
  %v822.not = icmp eq i64 %v821, 0
  br i1 %v822.not, label %trap823, label %ok824

trap823:                                          ; preds = %block799
  call fastcc void @native_trap()
  unreachable

ok824:                                            ; preds = %block799
  %v825 = inttoptr i64 %v821 to ptr
  %v826 = getelementptr i8, ptr %v825, i64 24
  %v827 = load i64, ptr %v826, align 1
  %502 = and i64 %v820, 1
  %503 = icmp eq i64 %502, 0
  br i1 %503, label %505, label %504

504:                                              ; preds = %ok824
  call fastcc void @native_trap() #111
  unreachable

505:                                              ; preds = %ok824
  %506 = inttoptr i64 %v820 to ptr
  %507 = icmp ne i64 %v827, 0
  %508 = and i64 %v827, 1
  %509 = icmp eq i64 %508, 0
  %510 = and i1 %507, %509
  br i1 %510, label %512, label %511

511:                                              ; preds = %505
  call fastcc void @native_trap() #111
  unreachable

512:                                              ; preds = %505
  %513 = inttoptr i64 %v827 to ptr
  %514 = zext i32 %v816 to i64
  %515 = getelementptr inbounds nuw i8, ptr %506, i64 8
  %516 = load i64, ptr %515, align 8, !noundef !39
  %517 = icmp ult i64 %516, %514
  br i1 %517, label %524, label %518

518:                                              ; preds = %512
  %519 = zext i32 %v807 to i64
  %520 = add nuw nsw i64 %514, %519
  %521 = getelementptr inbounds nuw i8, ptr %513, i64 8
  %522 = load i64, ptr %521, align 8, !noundef !39
  %523 = icmp ugt i64 %520, %522
  br i1 %523, label %524, label %native_array_copy.exit

524:                                              ; preds = %518, %512
  call fastcc void @native_trap() #111
  unreachable

native_array_copy.exit:                           ; preds = %518
  %525 = getelementptr inbounds nuw i8, ptr %513, i64 16
  %526 = getelementptr inbounds nuw i8, ptr %525, i64 %519
  %527 = getelementptr inbounds nuw i8, ptr %506, i64 16
  call void @llvm.memmove.p0.p0.i64(ptr nonnull align 1 %527, ptr nonnull align 1 %526, i64 %514, i1 false)
  %v830 = load i64, ptr %v22, align 8
  store i64 %v830, ptr %v111, align 8
  store i64 %501, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %528 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %529 = icmp eq ptr %528, null
  br i1 %529, label %530, label %531

530:                                              ; preds = %native_array_copy.exit
  call fastcc void @native_trap() #111
  unreachable

531:                                              ; preds = %native_array_copy.exit
  %532 = getelementptr inbounds nuw i8, ptr %528, i64 376
  %533 = load i64, ptr %532, align 8, !noundef !39
  %534 = icmp eq i64 %533, 0
  br i1 %534, label %535, label %539

535:                                              ; preds = %545, %539, %531
  %536 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %537 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %528, i64 noundef 16, ptr noundef %536) #84
  %538 = icmp eq ptr %537, null
  br i1 %538, label %547, label %ok837

539:                                              ; preds = %531
  %540 = getelementptr inbounds nuw i8, ptr %528, i64 368
  %541 = load i64, ptr %540, align 8, !noundef !39
  %542 = add i64 %541, 1
  store i64 %542, ptr %540, align 8
  %543 = urem i64 %542, %533
  %544 = icmp eq i64 %543, 0
  br i1 %544, label %545, label %535

545:                                              ; preds = %539
  %546 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %528, ptr noundef %546) #84
  br label %535

547:                                              ; preds = %535
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok837:                                            ; preds = %535
  %548 = ptrtoint ptr %537 to i64
  store i64 130, ptr %537, align 1
  %v844 = getelementptr i8, ptr %537, i64 8
  store i64 %v830, ptr %v844, align 1
  store i64 %548, ptr %v18, align 8
  %v851 = load i64, ptr %v844, align 1
  %v852.not = icmp eq i64 %v851, 0
  br i1 %v852.not, label %trap853, label %ok854

trap853:                                          ; preds = %ok837
  call fastcc void @native_trap()
  unreachable

ok854:                                            ; preds = %ok837
  %v855 = and i64 %v851, 1
  %v856 = icmp eq i64 %v855, 0
  br i1 %v856, label %ok858, label %trap857

trap857:                                          ; preds = %ok854
  call fastcc void @native_trap()
  unreachable

ok858:                                            ; preds = %ok854
  %v859 = inttoptr i64 %v851 to ptr
  %v860 = getelementptr i8, ptr %v859, i64 8
  %v861 = load i64, ptr %v860, align 1
  %v863 = and i64 %v861, 4294967295
  store i64 %501, ptr %v111, align 8
  store i64 %548, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %v867 = call tailcc i64 @f.5(i64 %548, i64 %v863)
  store i64 %501, ptr %v111, align 8
  store i64 %v867, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  call tailcc void @f.11(i64 %501, i64 %v867)
  store i64 21, ptr %v67, align 8
  %549 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %550 = icmp eq ptr %549, null
  br i1 %550, label %551, label %552

551:                                              ; preds = %ok858
  call fastcc void @native_trap() #111
  unreachable

552:                                              ; preds = %ok858
  %553 = getelementptr inbounds nuw i8, ptr %549, i64 376
  %554 = load i64, ptr %553, align 8, !noundef !39
  %555 = icmp eq i64 %554, 0
  br i1 %555, label %556, label %560

556:                                              ; preds = %566, %560, %552
  %557 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %558 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %549, i64 noundef 24, ptr noundef %557) #84
  %559 = icmp eq ptr %558, null
  br i1 %559, label %568, label %ok876

560:                                              ; preds = %552
  %561 = getelementptr inbounds nuw i8, ptr %549, i64 368
  %562 = load i64, ptr %561, align 8, !noundef !39
  %563 = add i64 %562, 1
  store i64 %563, ptr %561, align 8
  %564 = urem i64 %563, %554
  %565 = icmp eq i64 %564, 0
  br i1 %565, label %566, label %556

566:                                              ; preds = %560
  %567 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %549, ptr noundef %567) #84
  br label %556

568:                                              ; preds = %556
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok876:                                            ; preds = %556
  %569 = ptrtoint ptr %558 to i64
  store i64 98, ptr %558, align 1
  %v883 = getelementptr i8, ptr %558, i64 8
  store i32 0, ptr %v883, align 1
  %v888 = getelementptr i8, ptr %558, i64 16
  store i64 0, ptr %v888, align 1
  store i64 %569, ptr %v9, align 8
  %v891 = load i64, ptr %v7, align 8
  store i64 %569, ptr %v111, align 8
  store i64 %v891, ptr %v130, align 8
  store i64 ptrtoint (ptr @ref.10 to i64), ptr %v150, align 8
  store i64 %569, ptr %v171, align 8
  store i64 25, ptr %v67, align 8
  %570 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %571 = icmp eq ptr %570, null
  br i1 %571, label %572, label %573

572:                                              ; preds = %ok876
  call fastcc void @native_trap() #111
  unreachable

573:                                              ; preds = %ok876
  %574 = getelementptr inbounds nuw i8, ptr %570, i64 376
  %575 = load i64, ptr %574, align 8, !noundef !39
  %576 = icmp eq i64 %575, 0
  br i1 %576, label %577, label %581

577:                                              ; preds = %587, %581, %573
  %578 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %579 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %570, i64 noundef 40, ptr noundef %578) #84
  %580 = icmp eq ptr %579, null
  br i1 %580, label %589, label %ok901

581:                                              ; preds = %573
  %582 = getelementptr inbounds nuw i8, ptr %570, i64 368
  %583 = load i64, ptr %582, align 8, !noundef !39
  %584 = add i64 %583, 1
  store i64 %584, ptr %582, align 8
  %585 = urem i64 %584, %575
  %586 = icmp eq i64 %585, 0
  br i1 %586, label %587, label %577

587:                                              ; preds = %581
  %588 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %570, ptr noundef %588) #84
  br label %577

589:                                              ; preds = %577
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok901:                                            ; preds = %577
  %590 = ptrtoint ptr %579 to i64
  store i64 30, ptr %579, align 1
  %v908 = getelementptr i8, ptr %579, i64 8
  store i64 %10, ptr %v908, align 1
  %v913 = getelementptr i8, ptr %579, i64 16
  store i64 %11, ptr %v913, align 1
  %v918 = getelementptr i8, ptr %579, i64 24
  store i64 %v891, ptr %v918, align 1
  %v923 = getelementptr i8, ptr %579, i64 32
  store i64 %569, ptr %v923, align 1
  store i64 %590, ptr %v111, align 8
  store i64 ptrtoint (ptr @ref.10 to i64), ptr %v130, align 8
  store i64 %569, ptr %v150, align 8
  store i64 24, ptr %v67, align 8
  %591 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %592 = icmp eq ptr %591, null
  br i1 %592, label %593, label %594

593:                                              ; preds = %ok901
  call fastcc void @native_trap() #111
  unreachable

594:                                              ; preds = %ok901
  %595 = getelementptr inbounds nuw i8, ptr %591, i64 376
  %596 = load i64, ptr %595, align 8, !noundef !39
  %597 = icmp eq i64 %596, 0
  br i1 %597, label %598, label %602

598:                                              ; preds = %608, %602, %594
  %599 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %600 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %591, i64 noundef 24, ptr noundef %599) #84
  %601 = icmp eq ptr %600, null
  br i1 %601, label %610, label %ok931

602:                                              ; preds = %594
  %603 = getelementptr inbounds nuw i8, ptr %591, i64 368
  %604 = load i64, ptr %603, align 8, !noundef !39
  %605 = add i64 %604, 1
  store i64 %605, ptr %603, align 8
  %606 = urem i64 %605, %596
  %607 = icmp eq i64 %606, 0
  br i1 %607, label %608, label %598

608:                                              ; preds = %602
  %609 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %591, ptr noundef %609) #84
  br label %598

610:                                              ; preds = %598
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok931:                                            ; preds = %598
  %611 = ptrtoint ptr %600 to i64
  store i64 66, ptr %600, align 1
  %v938 = getelementptr i8, ptr %600, i64 8
  store i64 ptrtoint (ptr @ref.10 to i64), ptr %v938, align 1
  %v943 = getelementptr i8, ptr %600, i64 16
  store i64 %590, ptr %v943, align 1
  store i64 %611, ptr %v888, align 1
  %v949 = load i64, ptr %v9, align 8
  %v950.not = icmp eq i64 %v949, 0
  br i1 %v950.not, label %trap951, label %ok952

trap951:                                          ; preds = %ok931
  call fastcc void @native_trap()
  unreachable

ok952:                                            ; preds = %ok931
  %v953 = inttoptr i64 %v949 to ptr
  %v954 = getelementptr i8, ptr %v953, i64 8
  store i32 1, ptr %v954, align 1
  %v955 = load i64, ptr %v9, align 8
  %v956.not = icmp eq i64 %v955, 0
  br i1 %v956.not, label %trap957, label %ok958

trap957:                                          ; preds = %ok952
  call fastcc void @native_trap()
  unreachable

ok958:                                            ; preds = %ok952
  %v959 = inttoptr i64 %v955 to ptr
  %v960 = getelementptr i8, ptr %v959, i64 8
  %v961 = load i32, ptr %v960, align 1
  %v962 = icmp eq i32 %v961, 0
  br i1 %v962, label %then966, label %ok971

then966:                                          ; preds = %ok958
  call fastcc void @native_trap()
  unreachable

ok971:                                            ; preds = %ok958
  %v973 = getelementptr i8, ptr %v959, i64 16
  %v974 = load i64, ptr %v973, align 1
  %v975.not = icmp eq i64 %v974, 0
  br i1 %v975.not, label %trap976, label %ok977

trap976:                                          ; preds = %ok971
  call fastcc void @native_trap()
  unreachable

ok977:                                            ; preds = %ok971
  store i64 %v974, ptr %v23, align 8
  %v981 = inttoptr i64 %v974 to ptr
  %v989 = getelementptr i8, ptr %v981, i64 8
  %v990 = load i64, ptr %v989, align 1
  %v991.not = icmp eq i64 %v990, 0
  br i1 %v991.not, label %trap992, label %ok993

trap992:                                          ; preds = %ok977
  call fastcc void @native_trap()
  unreachable

ok993:                                            ; preds = %ok977
  %v982 = getelementptr i8, ptr %v981, i64 16
  %v983 = load i64, ptr %v982, align 1
  %v994 = inttoptr i64 %v990 to ptr
  %v995 = getelementptr i8, ptr %v994, i64 8
  %v996 = load ptr, ptr %v995, align 1
  store i64 %v983, ptr %v111, align 8
  store i64 22, ptr %v67, align 8
  %v999 = call tailcc i32 %v996(i64 %v983, i64 0)
  %v1000.b = load i1, ptr @g.22, align 1
  br i1 %v1000.b, label %block1003, label %then1005

then1005:                                         ; preds = %ok993
  call fastcc void @native_trap()
  unreachable

block1003:                                        ; preds = %ok993
  %v1007 = load i64, ptr @g.21, align 8
  %v1008.not = icmp eq i64 %v1007, 0
  br i1 %v1008.not, label %trap1009, label %ok1010

trap1009:                                         ; preds = %block1003
  call fastcc void @native_trap()
  unreachable

ok1010:                                           ; preds = %block1003
  %v1011 = inttoptr i64 %v1007 to ptr
  %v1012 = getelementptr i8, ptr %v1011, i64 8
  %v1013 = load i64, ptr %v1012, align 1
  store i64 %v1013, ptr %v4, align 8
  %v1014.b = load i1, ptr @g.10, align 1
  br i1 %v1014.b, label %block1017, label %then1019

then1019:                                         ; preds = %ok1010
  call fastcc void @native_trap()
  unreachable

block1017:                                        ; preds = %ok1010
  %v1021 = load i64, ptr @g.9, align 8
  %v1022.not = icmp eq i64 %v1021, 0
  br i1 %v1022.not, label %trap1023, label %ok1024

trap1023:                                         ; preds = %block1017
  call fastcc void @native_trap()
  unreachable

ok1024:                                           ; preds = %block1017
  store i64 21, ptr %v67, align 8
  %612 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %613 = icmp eq ptr %612, null
  br i1 %613, label %614, label %615

614:                                              ; preds = %ok1024
  call fastcc void @native_trap() #111
  unreachable

615:                                              ; preds = %ok1024
  %616 = getelementptr inbounds nuw i8, ptr %612, i64 376
  %617 = load i64, ptr %616, align 8, !noundef !39
  %618 = icmp eq i64 %617, 0
  br i1 %618, label %619, label %623

619:                                              ; preds = %629, %623, %615
  %620 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %621 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %612, i64 noundef 24, ptr noundef %620) #84
  %622 = icmp eq ptr %621, null
  br i1 %622, label %631, label %ok1029

623:                                              ; preds = %615
  %624 = getelementptr inbounds nuw i8, ptr %612, i64 368
  %625 = load i64, ptr %624, align 8, !noundef !39
  %626 = add i64 %625, 1
  store i64 %626, ptr %624, align 8
  %627 = urem i64 %626, %617
  %628 = icmp eq i64 %627, 0
  br i1 %628, label %629, label %619

629:                                              ; preds = %623
  %630 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %612, ptr noundef %630) #84
  br label %619

631:                                              ; preds = %619
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok1029:                                           ; preds = %619
  %632 = ptrtoint ptr %621 to i64
  store i64 94, ptr %621, align 1
  %v1036 = getelementptr i8, ptr %621, i64 8
  store i32 0, ptr %v1036, align 1
  %v1041 = getelementptr i8, ptr %621, i64 16
  store i64 0, ptr %v1041, align 1
  store i64 %632, ptr %v10, align 8
  store i64 %632, ptr %v111, align 8
  store i64 %632, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %633 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %634 = icmp eq ptr %633, null
  br i1 %634, label %635, label %636

635:                                              ; preds = %ok1029
  call fastcc void @native_trap() #111
  unreachable

636:                                              ; preds = %ok1029
  %637 = getelementptr inbounds nuw i8, ptr %633, i64 376
  %638 = load i64, ptr %637, align 8, !noundef !39
  %639 = icmp eq i64 %638, 0
  br i1 %639, label %640, label %644

640:                                              ; preds = %650, %644, %636
  %641 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %642 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %633, i64 noundef 16, ptr noundef %641) #84
  %643 = icmp eq ptr %642, null
  br i1 %643, label %652, label %ok1049

644:                                              ; preds = %636
  %645 = getelementptr inbounds nuw i8, ptr %633, i64 368
  %646 = load i64, ptr %645, align 8, !noundef !39
  %647 = add i64 %646, 1
  store i64 %647, ptr %645, align 8
  %648 = urem i64 %647, %638
  %649 = icmp eq i64 %648, 0
  br i1 %649, label %650, label %640

650:                                              ; preds = %644
  %651 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %633, ptr noundef %651) #84
  br label %640

652:                                              ; preds = %640
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok1049:                                           ; preds = %640
  %653 = ptrtoint ptr %642 to i64
  store i64 106, ptr %642, align 1
  %v1056 = getelementptr i8, ptr %642, i64 8
  store i64 %632, ptr %v1056, align 1
  store i64 %653, ptr %v111, align 8
  store i64 %632, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %654 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %655 = icmp eq ptr %654, null
  br i1 %655, label %656, label %657

656:                                              ; preds = %ok1049
  call fastcc void @native_trap() #111
  unreachable

657:                                              ; preds = %ok1049
  %658 = getelementptr inbounds nuw i8, ptr %654, i64 376
  %659 = load i64, ptr %658, align 8, !noundef !39
  %660 = icmp eq i64 %659, 0
  br i1 %660, label %661, label %665

661:                                              ; preds = %671, %665, %657
  %662 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %663 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %654, i64 noundef 16, ptr noundef %662) #84
  %664 = icmp eq ptr %663, null
  br i1 %664, label %673, label %ok1063

665:                                              ; preds = %657
  %666 = getelementptr inbounds nuw i8, ptr %654, i64 368
  %667 = load i64, ptr %666, align 8, !noundef !39
  %668 = add i64 %667, 1
  store i64 %668, ptr %666, align 8
  %669 = urem i64 %668, %659
  %670 = icmp eq i64 %669, 0
  br i1 %670, label %671, label %661

671:                                              ; preds = %665
  %672 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %654, ptr noundef %672) #84
  br label %661

673:                                              ; preds = %661
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok1063:                                           ; preds = %661
  %674 = ptrtoint ptr %663 to i64
  store i64 22, ptr %663, align 1
  %v1070 = getelementptr i8, ptr %663, i64 8
  store i64 %653, ptr %v1070, align 1
  store i64 %674, ptr %v1041, align 1
  %v1076 = load i64, ptr %v10, align 8
  %v1077.not = icmp eq i64 %v1076, 0
  br i1 %v1077.not, label %trap1078, label %ok1079

trap1078:                                         ; preds = %ok1063
  call fastcc void @native_trap()
  unreachable

ok1079:                                           ; preds = %ok1063
  %v1080 = inttoptr i64 %v1076 to ptr
  %v1081 = getelementptr i8, ptr %v1080, i64 8
  store i32 1, ptr %v1081, align 1
  %v1082 = load i64, ptr %v10, align 8
  %v1083.not = icmp eq i64 %v1082, 0
  br i1 %v1083.not, label %trap1084, label %ok1085

trap1084:                                         ; preds = %ok1079
  call fastcc void @native_trap()
  unreachable

ok1085:                                           ; preds = %ok1079
  %v1086 = inttoptr i64 %v1082 to ptr
  %v1087 = getelementptr i8, ptr %v1086, i64 8
  %v1088 = load i32, ptr %v1087, align 1
  %v1089 = icmp eq i32 %v1088, 0
  br i1 %v1089, label %then1093, label %ok1098

then1093:                                         ; preds = %ok1085
  call fastcc void @native_trap()
  unreachable

ok1098:                                           ; preds = %ok1085
  %v1100 = getelementptr i8, ptr %v1086, i64 16
  %v1101 = load i64, ptr %v1100, align 1
  %v1102.not = icmp eq i64 %v1101, 0
  br i1 %v1102.not, label %trap1103, label %ok1104

trap1103:                                         ; preds = %ok1098
  call fastcc void @native_trap()
  unreachable

ok1104:                                           ; preds = %ok1098
  %v1105 = inttoptr i64 %v1101 to ptr
  %v1106 = getelementptr i8, ptr %v1105, i64 8
  %v1107 = load i64, ptr %v1106, align 1
  store i64 %v1107, ptr %v5, align 8
  %v1108 = load i64, ptr %v4, align 8
  %v1109 = icmp eq i64 %v1108, 0
  br i1 %v1109, label %block1112, label %ok1119

ok1119:                                           ; preds = %ok1104
  %v1120 = inttoptr i64 %v1108 to ptr
  %v1121 = getelementptr i8, ptr %v1120, i64 8
  %v1122 = load i64, ptr %v1121, align 1
  store i64 %v1122, ptr %v4, align 8
  %v1124.not = icmp eq i64 %v1107, 0
  br i1 %v1124.not, label %trap1125, label %ok1126

trap1125:                                         ; preds = %ok1119
  call fastcc void @native_trap()
  unreachable

ok1126:                                           ; preds = %ok1119
  %v1127 = inttoptr i64 %v1107 to ptr
  %v1128 = getelementptr i8, ptr %v1127, i64 8
  %v1129 = load i64, ptr %v1128, align 1
  %v1130.not = icmp eq i64 %v1129, 0
  br i1 %v1130.not, label %trap1131, label %ok1132

trap1131:                                         ; preds = %ok1126
  call fastcc void @native_trap()
  unreachable

ok1132:                                           ; preds = %ok1126
  %v1133 = inttoptr i64 %v1129 to ptr
  %v1134 = getelementptr i8, ptr %v1133, i64 8
  %v1135 = load i32, ptr %v1134, align 1
  %v1136 = icmp eq i32 %v1135, 0
  br i1 %v1136, label %then1140, label %ok1151

then1140:                                         ; preds = %ok1132
  call fastcc void @native_trap()
  unreachable

ok1151:                                           ; preds = %ok1132
  %v1153 = getelementptr i8, ptr %v1133, i64 16
  %v1154 = load i64, ptr %v1153, align 1
  %v1155.not = icmp eq i64 %v1154, 0
  br i1 %v1155.not, label %trap1156, label %ok1157

trap1156:                                         ; preds = %ok1151
  call fastcc void @native_trap()
  unreachable

ok1157:                                           ; preds = %ok1151
  %v1158 = inttoptr i64 %v1154 to ptr
  %v1159 = getelementptr i8, ptr %v1158, i64 8
  %v1160 = load i64, ptr %v1159, align 1
  store i64 %v1160, ptr %v5, align 8
  %v1162 = icmp eq i64 %v1122, 0
  br i1 %v1162, label %block1112, label %ok1172

ok1172:                                           ; preds = %ok1157
  %v1173 = inttoptr i64 %v1122 to ptr
  %v1174 = getelementptr i8, ptr %v1173, i64 8
  %v1175 = load i64, ptr %v1174, align 1
  store i64 %v1175, ptr %v4, align 8
  %v1177.not = icmp eq i64 %v1160, 0
  br i1 %v1177.not, label %trap1178, label %ok1179

trap1178:                                         ; preds = %ok1172
  call fastcc void @native_trap()
  unreachable

ok1179:                                           ; preds = %ok1172
  %v1180 = inttoptr i64 %v1160 to ptr
  %v1181 = getelementptr i8, ptr %v1180, i64 8
  %v1182 = load i64, ptr %v1181, align 1
  %v1183.not = icmp eq i64 %v1182, 0
  br i1 %v1183.not, label %trap1184, label %ok1185

trap1184:                                         ; preds = %ok1179
  call fastcc void @native_trap()
  unreachable

ok1185:                                           ; preds = %ok1179
  %v1186 = inttoptr i64 %v1182 to ptr
  %v1187 = getelementptr i8, ptr %v1186, i64 8
  %v1188 = load i32, ptr %v1187, align 1
  %v1189 = icmp eq i32 %v1188, 0
  br i1 %v1189, label %then1193, label %ok1204

then1193:                                         ; preds = %ok1185
  call fastcc void @native_trap()
  unreachable

ok1204:                                           ; preds = %ok1185
  %v1206 = getelementptr i8, ptr %v1186, i64 16
  %v1207 = load i64, ptr %v1206, align 1
  %v1208.not = icmp eq i64 %v1207, 0
  br i1 %v1208.not, label %trap1209, label %ok1210

trap1209:                                         ; preds = %ok1204
  call fastcc void @native_trap()
  unreachable

ok1210:                                           ; preds = %ok1204
  %v1211 = inttoptr i64 %v1207 to ptr
  %v1212 = getelementptr i8, ptr %v1211, i64 8
  %v1213 = load i64, ptr %v1212, align 1
  store i64 %v1213, ptr %v5, align 8
  %v1215 = icmp eq i64 %v1175, 0
  br i1 %v1215, label %block1112, label %ok1225

ok1225:                                           ; preds = %ok1210
  %v1226 = inttoptr i64 %v1175 to ptr
  %v1227 = getelementptr i8, ptr %v1226, i64 8
  %v1228 = load i64, ptr %v1227, align 1
  store i64 %v1228, ptr %v4, align 8
  %v1230.not = icmp eq i64 %v1213, 0
  br i1 %v1230.not, label %trap1231, label %ok1232

trap1231:                                         ; preds = %ok1225
  call fastcc void @native_trap()
  unreachable

ok1232:                                           ; preds = %ok1225
  %v1233 = inttoptr i64 %v1213 to ptr
  %v1234 = getelementptr i8, ptr %v1233, i64 8
  %v1235 = load i64, ptr %v1234, align 1
  %v1236.not = icmp eq i64 %v1235, 0
  br i1 %v1236.not, label %trap1237, label %ok1238

trap1237:                                         ; preds = %ok1232
  call fastcc void @native_trap()
  unreachable

ok1238:                                           ; preds = %ok1232
  %v1239 = inttoptr i64 %v1235 to ptr
  %v1240 = getelementptr i8, ptr %v1239, i64 8
  %v1241 = load i32, ptr %v1240, align 1
  %v1242 = icmp eq i32 %v1241, 0
  br i1 %v1242, label %then1246, label %ok1257

then1246:                                         ; preds = %ok1238
  call fastcc void @native_trap()
  unreachable

ok1257:                                           ; preds = %ok1238
  %v1259 = getelementptr i8, ptr %v1239, i64 16
  %v1260 = load i64, ptr %v1259, align 1
  %v1261.not = icmp eq i64 %v1260, 0
  br i1 %v1261.not, label %trap1262, label %ok1263

trap1262:                                         ; preds = %ok1257
  call fastcc void @native_trap()
  unreachable

ok1263:                                           ; preds = %ok1257
  %v1264 = inttoptr i64 %v1260 to ptr
  %v1265 = getelementptr i8, ptr %v1264, i64 8
  %v1266 = load i64, ptr %v1265, align 1
  store i64 %v1266, ptr %v5, align 8
  %v1268 = icmp eq i64 %v1228, 0
  br i1 %v1268, label %block1112, label %ok1278

ok1278:                                           ; preds = %ok1263
  %v1279 = inttoptr i64 %v1228 to ptr
  %v1280 = getelementptr i8, ptr %v1279, i64 8
  %v1281 = load i64, ptr %v1280, align 1
  store i64 %v1281, ptr %v4, align 8
  %v1283.not = icmp eq i64 %v1266, 0
  br i1 %v1283.not, label %trap1284, label %ok1285

trap1284:                                         ; preds = %ok1278
  call fastcc void @native_trap()
  unreachable

ok1285:                                           ; preds = %ok1278
  %v1286 = inttoptr i64 %v1266 to ptr
  %v1287 = getelementptr i8, ptr %v1286, i64 8
  %v1288 = load i64, ptr %v1287, align 1
  %v1289.not = icmp eq i64 %v1288, 0
  br i1 %v1289.not, label %trap1290, label %ok1291

trap1290:                                         ; preds = %ok1285
  call fastcc void @native_trap()
  unreachable

ok1291:                                           ; preds = %ok1285
  %v1292 = inttoptr i64 %v1288 to ptr
  %v1293 = getelementptr i8, ptr %v1292, i64 8
  %v1294 = load i32, ptr %v1293, align 1
  %v1295 = icmp eq i32 %v1294, 0
  br i1 %v1295, label %then1299, label %ok1310

then1299:                                         ; preds = %ok1291
  call fastcc void @native_trap()
  unreachable

ok1310:                                           ; preds = %ok1291
  %v1312 = getelementptr i8, ptr %v1292, i64 16
  %v1313 = load i64, ptr %v1312, align 1
  %v1314.not = icmp eq i64 %v1313, 0
  br i1 %v1314.not, label %trap1315, label %ok1316

trap1315:                                         ; preds = %ok1310
  call fastcc void @native_trap()
  unreachable

ok1316:                                           ; preds = %ok1310
  %v1317 = inttoptr i64 %v1313 to ptr
  %v1318 = getelementptr i8, ptr %v1317, i64 8
  %v1319 = load i64, ptr %v1318, align 1
  store i64 %v1319, ptr %v5, align 8
  %v1321 = icmp eq i64 %v1281, 0
  br i1 %v1321, label %block1112, label %ok1331

ok1331:                                           ; preds = %ok1316
  %v1332 = inttoptr i64 %v1281 to ptr
  %v1333 = getelementptr i8, ptr %v1332, i64 8
  %v1334 = load i64, ptr %v1333, align 1
  store i64 %v1334, ptr %v4, align 8
  %v1336.not = icmp eq i64 %v1319, 0
  br i1 %v1336.not, label %trap1337, label %ok1338

trap1337:                                         ; preds = %ok1331
  call fastcc void @native_trap()
  unreachable

ok1338:                                           ; preds = %ok1331
  %v1339 = inttoptr i64 %v1319 to ptr
  %v1340 = getelementptr i8, ptr %v1339, i64 8
  %v1341 = load i64, ptr %v1340, align 1
  %v1342.not = icmp eq i64 %v1341, 0
  br i1 %v1342.not, label %trap1343, label %ok1344

trap1343:                                         ; preds = %ok1338
  call fastcc void @native_trap()
  unreachable

ok1344:                                           ; preds = %ok1338
  %v1345 = inttoptr i64 %v1341 to ptr
  %v1346 = getelementptr i8, ptr %v1345, i64 8
  %v1347 = load i32, ptr %v1346, align 1
  %v1348 = icmp eq i32 %v1347, 0
  br i1 %v1348, label %then1352, label %ok1363

then1352:                                         ; preds = %ok1344
  call fastcc void @native_trap()
  unreachable

ok1363:                                           ; preds = %ok1344
  %v1365 = getelementptr i8, ptr %v1345, i64 16
  %v1366 = load i64, ptr %v1365, align 1
  %v1367.not = icmp eq i64 %v1366, 0
  br i1 %v1367.not, label %trap1368, label %ok1369

trap1368:                                         ; preds = %ok1363
  call fastcc void @native_trap()
  unreachable

ok1369:                                           ; preds = %ok1363
  %v1370 = inttoptr i64 %v1366 to ptr
  %v1371 = getelementptr i8, ptr %v1370, i64 8
  %v1372 = load i64, ptr %v1371, align 1
  store i64 %v1372, ptr %v5, align 8
  %v1374 = icmp eq i64 %v1334, 0
  br i1 %v1374, label %block1112, label %ok1384

ok1384:                                           ; preds = %ok1369
  %v1385 = inttoptr i64 %v1334 to ptr
  %v1386 = getelementptr i8, ptr %v1385, i64 8
  %v1387 = load i64, ptr %v1386, align 1
  store i64 %v1387, ptr %v4, align 8
  %v1389.not = icmp eq i64 %v1372, 0
  br i1 %v1389.not, label %trap1390, label %ok1391

trap1390:                                         ; preds = %ok1384
  call fastcc void @native_trap()
  unreachable

ok1391:                                           ; preds = %ok1384
  %v1392 = inttoptr i64 %v1372 to ptr
  %v1393 = getelementptr i8, ptr %v1392, i64 8
  %v1394 = load i64, ptr %v1393, align 1
  %v1395.not = icmp eq i64 %v1394, 0
  br i1 %v1395.not, label %trap1396, label %ok1397

trap1396:                                         ; preds = %ok1391
  call fastcc void @native_trap()
  unreachable

ok1397:                                           ; preds = %ok1391
  %v1398 = inttoptr i64 %v1394 to ptr
  %v1399 = getelementptr i8, ptr %v1398, i64 8
  %v1400 = load i32, ptr %v1399, align 1
  %v1401 = icmp eq i32 %v1400, 0
  br i1 %v1401, label %then1405, label %ok1416

then1405:                                         ; preds = %ok1397
  call fastcc void @native_trap()
  unreachable

ok1416:                                           ; preds = %ok1397
  %v1418 = getelementptr i8, ptr %v1398, i64 16
  %v1419 = load i64, ptr %v1418, align 1
  %v1420.not = icmp eq i64 %v1419, 0
  br i1 %v1420.not, label %trap1421, label %ok1422

trap1421:                                         ; preds = %ok1416
  call fastcc void @native_trap()
  unreachable

ok1422:                                           ; preds = %ok1416
  %v1423 = inttoptr i64 %v1419 to ptr
  %v1424 = getelementptr i8, ptr %v1423, i64 8
  %v1425 = load i64, ptr %v1424, align 1
  store i64 %v1425, ptr %v5, align 8
  %v1427 = icmp eq i64 %v1387, 0
  br i1 %v1427, label %block1112, label %ok1437

ok1437:                                           ; preds = %ok1422
  %v1438 = inttoptr i64 %v1387 to ptr
  %v1439 = getelementptr i8, ptr %v1438, i64 8
  %v1440 = load i64, ptr %v1439, align 1
  store i64 %v1440, ptr %v4, align 8
  %v1442.not = icmp eq i64 %v1425, 0
  br i1 %v1442.not, label %trap1443, label %ok1444

trap1443:                                         ; preds = %ok1437
  call fastcc void @native_trap()
  unreachable

ok1444:                                           ; preds = %ok1437
  %v1445 = inttoptr i64 %v1425 to ptr
  %v1446 = getelementptr i8, ptr %v1445, i64 8
  %v1447 = load i64, ptr %v1446, align 1
  %v1448.not = icmp eq i64 %v1447, 0
  br i1 %v1448.not, label %trap1449, label %ok1450

trap1449:                                         ; preds = %ok1444
  call fastcc void @native_trap()
  unreachable

ok1450:                                           ; preds = %ok1444
  %v1451 = inttoptr i64 %v1447 to ptr
  %v1452 = getelementptr i8, ptr %v1451, i64 8
  %v1453 = load i32, ptr %v1452, align 1
  %v1454 = icmp eq i32 %v1453, 0
  br i1 %v1454, label %then1458, label %ok1469

then1458:                                         ; preds = %ok1450
  call fastcc void @native_trap()
  unreachable

ok1469:                                           ; preds = %ok1450
  %v1471 = getelementptr i8, ptr %v1451, i64 16
  %v1472 = load i64, ptr %v1471, align 1
  %v1473.not = icmp eq i64 %v1472, 0
  br i1 %v1473.not, label %trap1474, label %ok1475

trap1474:                                         ; preds = %ok1469
  call fastcc void @native_trap()
  unreachable

ok1475:                                           ; preds = %ok1469
  %v1476 = inttoptr i64 %v1472 to ptr
  %v1477 = getelementptr i8, ptr %v1476, i64 8
  %v1478 = load i64, ptr %v1477, align 1
  store i64 %v1478, ptr %v5, align 8
  %v1480 = icmp eq i64 %v1440, 0
  br i1 %v1480, label %block1112, label %ok1490

ok1490:                                           ; preds = %ok1475
  %v1491 = inttoptr i64 %v1440 to ptr
  %v1492 = getelementptr i8, ptr %v1491, i64 8
  %v1493 = load i64, ptr %v1492, align 1
  store i64 %v1493, ptr %v4, align 8
  %v1495.not = icmp eq i64 %v1478, 0
  br i1 %v1495.not, label %trap1496, label %ok1497

trap1496:                                         ; preds = %ok1490
  call fastcc void @native_trap()
  unreachable

ok1497:                                           ; preds = %ok1490
  %v1498 = inttoptr i64 %v1478 to ptr
  %v1499 = getelementptr i8, ptr %v1498, i64 8
  %v1500 = load i64, ptr %v1499, align 1
  %v1501.not = icmp eq i64 %v1500, 0
  br i1 %v1501.not, label %trap1502, label %ok1503

trap1502:                                         ; preds = %ok1497
  call fastcc void @native_trap()
  unreachable

ok1503:                                           ; preds = %ok1497
  %v1504 = inttoptr i64 %v1500 to ptr
  %v1505 = getelementptr i8, ptr %v1504, i64 8
  %v1506 = load i32, ptr %v1505, align 1
  %v1507 = icmp eq i32 %v1506, 0
  br i1 %v1507, label %then1511, label %ok1522

then1511:                                         ; preds = %ok1503
  call fastcc void @native_trap()
  unreachable

ok1522:                                           ; preds = %ok1503
  %v1524 = getelementptr i8, ptr %v1504, i64 16
  %v1525 = load i64, ptr %v1524, align 1
  %v1526.not = icmp eq i64 %v1525, 0
  br i1 %v1526.not, label %trap1527, label %ok1528

trap1527:                                         ; preds = %ok1522
  call fastcc void @native_trap()
  unreachable

ok1528:                                           ; preds = %ok1522
  %v1529 = inttoptr i64 %v1525 to ptr
  %v1530 = getelementptr i8, ptr %v1529, i64 8
  %v1531 = load i64, ptr %v1530, align 1
  store i64 %v1531, ptr %v5, align 8
  %v1533 = icmp eq i64 %v1493, 0
  br i1 %v1533, label %block1112, label %ok1543

ok1543:                                           ; preds = %ok1528
  %v1544 = inttoptr i64 %v1493 to ptr
  %v1545 = getelementptr i8, ptr %v1544, i64 8
  %v1546 = load i64, ptr %v1545, align 1
  store i64 %v1546, ptr %v4, align 8
  %v1548.not = icmp eq i64 %v1531, 0
  br i1 %v1548.not, label %trap1549, label %ok1550

trap1549:                                         ; preds = %ok1543
  call fastcc void @native_trap()
  unreachable

ok1550:                                           ; preds = %ok1543
  %v1551 = inttoptr i64 %v1531 to ptr
  %v1552 = getelementptr i8, ptr %v1551, i64 8
  %v1553 = load i64, ptr %v1552, align 1
  %v1554.not = icmp eq i64 %v1553, 0
  br i1 %v1554.not, label %trap1555, label %ok1556

trap1555:                                         ; preds = %ok1550
  call fastcc void @native_trap()
  unreachable

ok1556:                                           ; preds = %ok1550
  %v1557 = inttoptr i64 %v1553 to ptr
  %v1558 = getelementptr i8, ptr %v1557, i64 8
  %v1559 = load i32, ptr %v1558, align 1
  %v1560 = icmp eq i32 %v1559, 0
  br i1 %v1560, label %then1564, label %ok1575

then1564:                                         ; preds = %ok1556
  call fastcc void @native_trap()
  unreachable

ok1575:                                           ; preds = %ok1556
  %v1577 = getelementptr i8, ptr %v1557, i64 16
  %v1578 = load i64, ptr %v1577, align 1
  %v1579.not = icmp eq i64 %v1578, 0
  br i1 %v1579.not, label %trap1580, label %ok1581

trap1580:                                         ; preds = %ok1575
  call fastcc void @native_trap()
  unreachable

ok1581:                                           ; preds = %ok1575
  %v1582 = inttoptr i64 %v1578 to ptr
  %v1583 = getelementptr i8, ptr %v1582, i64 8
  %v1584 = load i64, ptr %v1583, align 1
  store i64 %v1584, ptr %v5, align 8
  %v1586 = icmp eq i64 %v1546, 0
  br i1 %v1586, label %block1112, label %ok1596

ok1596:                                           ; preds = %ok1581
  %v1597 = inttoptr i64 %v1546 to ptr
  %v1598 = getelementptr i8, ptr %v1597, i64 8
  %v1599 = load i64, ptr %v1598, align 1
  store i64 %v1599, ptr %v4, align 8
  %v1601.not = icmp eq i64 %v1584, 0
  br i1 %v1601.not, label %trap1602, label %ok1603

trap1602:                                         ; preds = %ok1596
  call fastcc void @native_trap()
  unreachable

ok1603:                                           ; preds = %ok1596
  %v1604 = inttoptr i64 %v1584 to ptr
  %v1605 = getelementptr i8, ptr %v1604, i64 8
  %v1606 = load i64, ptr %v1605, align 1
  %v1607.not = icmp eq i64 %v1606, 0
  br i1 %v1607.not, label %trap1608, label %ok1609

trap1608:                                         ; preds = %ok1603
  call fastcc void @native_trap()
  unreachable

ok1609:                                           ; preds = %ok1603
  %v1610 = inttoptr i64 %v1606 to ptr
  %v1611 = getelementptr i8, ptr %v1610, i64 8
  %v1612 = load i32, ptr %v1611, align 1
  %v1613 = icmp eq i32 %v1612, 0
  br i1 %v1613, label %then1617, label %ok1628

then1617:                                         ; preds = %ok1609
  call fastcc void @native_trap()
  unreachable

ok1628:                                           ; preds = %ok1609
  %v1630 = getelementptr i8, ptr %v1610, i64 16
  %v1631 = load i64, ptr %v1630, align 1
  %v1632.not = icmp eq i64 %v1631, 0
  br i1 %v1632.not, label %trap1633, label %ok1634

trap1633:                                         ; preds = %ok1628
  call fastcc void @native_trap()
  unreachable

ok1634:                                           ; preds = %ok1628
  %v1635 = inttoptr i64 %v1631 to ptr
  %v1636 = getelementptr i8, ptr %v1635, i64 8
  %v1637 = load i64, ptr %v1636, align 1
  store i64 %v1637, ptr %v5, align 8
  %v1639 = icmp eq i64 %v1599, 0
  br i1 %v1639, label %block1112, label %ok1649

ok1649:                                           ; preds = %ok1634
  %v1650 = inttoptr i64 %v1599 to ptr
  %v1651 = getelementptr i8, ptr %v1650, i64 8
  %v1652 = load i64, ptr %v1651, align 1
  store i64 %v1652, ptr %v4, align 8
  %v1654.not = icmp eq i64 %v1637, 0
  br i1 %v1654.not, label %trap1655, label %ok1656

trap1655:                                         ; preds = %ok1649
  call fastcc void @native_trap()
  unreachable

ok1656:                                           ; preds = %ok1649
  %v1657 = inttoptr i64 %v1637 to ptr
  %v1658 = getelementptr i8, ptr %v1657, i64 8
  %v1659 = load i64, ptr %v1658, align 1
  %v1660.not = icmp eq i64 %v1659, 0
  br i1 %v1660.not, label %trap1661, label %ok1662

trap1661:                                         ; preds = %ok1656
  call fastcc void @native_trap()
  unreachable

ok1662:                                           ; preds = %ok1656
  %v1663 = inttoptr i64 %v1659 to ptr
  %v1664 = getelementptr i8, ptr %v1663, i64 8
  %v1665 = load i32, ptr %v1664, align 1
  %v1666 = icmp eq i32 %v1665, 0
  br i1 %v1666, label %then1670, label %ok1681

then1670:                                         ; preds = %ok1662
  call fastcc void @native_trap()
  unreachable

ok1681:                                           ; preds = %ok1662
  %v1683 = getelementptr i8, ptr %v1663, i64 16
  %v1684 = load i64, ptr %v1683, align 1
  %v1685.not = icmp eq i64 %v1684, 0
  br i1 %v1685.not, label %trap1686, label %ok1687

trap1686:                                         ; preds = %ok1681
  call fastcc void @native_trap()
  unreachable

ok1687:                                           ; preds = %ok1681
  %v1688 = inttoptr i64 %v1684 to ptr
  %v1689 = getelementptr i8, ptr %v1688, i64 8
  %v1690 = load i64, ptr %v1689, align 1
  store i64 %v1690, ptr %v5, align 8
  %v1692 = icmp eq i64 %v1652, 0
  br i1 %v1692, label %block1112, label %ok1702

ok1702:                                           ; preds = %ok1687
  %v1703 = inttoptr i64 %v1652 to ptr
  %v1704 = getelementptr i8, ptr %v1703, i64 8
  %v1705 = load i64, ptr %v1704, align 1
  store i64 %v1705, ptr %v4, align 8
  %v1707.not = icmp eq i64 %v1690, 0
  br i1 %v1707.not, label %trap1708, label %ok1709

trap1708:                                         ; preds = %ok1702
  call fastcc void @native_trap()
  unreachable

ok1709:                                           ; preds = %ok1702
  %v1710 = inttoptr i64 %v1690 to ptr
  %v1711 = getelementptr i8, ptr %v1710, i64 8
  %v1712 = load i64, ptr %v1711, align 1
  %v1713.not = icmp eq i64 %v1712, 0
  br i1 %v1713.not, label %trap1714, label %ok1715

trap1714:                                         ; preds = %ok1709
  call fastcc void @native_trap()
  unreachable

ok1715:                                           ; preds = %ok1709
  %v1716 = inttoptr i64 %v1712 to ptr
  %v1717 = getelementptr i8, ptr %v1716, i64 8
  %v1718 = load i32, ptr %v1717, align 1
  %v1719 = icmp eq i32 %v1718, 0
  br i1 %v1719, label %then1723, label %ok1734

then1723:                                         ; preds = %ok1715
  call fastcc void @native_trap()
  unreachable

ok1734:                                           ; preds = %ok1715
  %v1736 = getelementptr i8, ptr %v1716, i64 16
  %v1737 = load i64, ptr %v1736, align 1
  %v1738.not = icmp eq i64 %v1737, 0
  br i1 %v1738.not, label %trap1739, label %ok1740

trap1739:                                         ; preds = %ok1734
  call fastcc void @native_trap()
  unreachable

ok1740:                                           ; preds = %ok1734
  %v1741 = inttoptr i64 %v1737 to ptr
  %v1742 = getelementptr i8, ptr %v1741, i64 8
  %v1743 = load i64, ptr %v1742, align 1
  store i64 %v1743, ptr %v5, align 8
  %v1745 = icmp eq i64 %v1705, 0
  br i1 %v1745, label %block1112, label %ok1755

ok1755:                                           ; preds = %ok1740
  %v1756 = inttoptr i64 %v1705 to ptr
  %v1757 = getelementptr i8, ptr %v1756, i64 8
  %v1758 = load i64, ptr %v1757, align 1
  store i64 %v1758, ptr %v4, align 8
  %v1760.not = icmp eq i64 %v1743, 0
  br i1 %v1760.not, label %trap1761, label %ok1762

trap1761:                                         ; preds = %ok1755
  call fastcc void @native_trap()
  unreachable

ok1762:                                           ; preds = %ok1755
  %v1763 = inttoptr i64 %v1743 to ptr
  %v1764 = getelementptr i8, ptr %v1763, i64 8
  %v1765 = load i64, ptr %v1764, align 1
  %v1766.not = icmp eq i64 %v1765, 0
  br i1 %v1766.not, label %trap1767, label %ok1768

trap1767:                                         ; preds = %ok1762
  call fastcc void @native_trap()
  unreachable

ok1768:                                           ; preds = %ok1762
  %v1769 = inttoptr i64 %v1765 to ptr
  %v1770 = getelementptr i8, ptr %v1769, i64 8
  %v1771 = load i32, ptr %v1770, align 1
  %v1772 = icmp eq i32 %v1771, 0
  br i1 %v1772, label %then1776, label %ok1787

then1776:                                         ; preds = %ok1768
  call fastcc void @native_trap()
  unreachable

ok1787:                                           ; preds = %ok1768
  %v1789 = getelementptr i8, ptr %v1769, i64 16
  %v1790 = load i64, ptr %v1789, align 1
  %v1791.not = icmp eq i64 %v1790, 0
  br i1 %v1791.not, label %trap1792, label %ok1793

trap1792:                                         ; preds = %ok1787
  call fastcc void @native_trap()
  unreachable

ok1793:                                           ; preds = %ok1787
  %v1794 = inttoptr i64 %v1790 to ptr
  %v1795 = getelementptr i8, ptr %v1794, i64 8
  %v1796 = load i64, ptr %v1795, align 1
  store i64 %v1796, ptr %v5, align 8
  %v1798 = icmp eq i64 %v1758, 0
  br i1 %v1798, label %block1112, label %ok1808

ok1808:                                           ; preds = %ok1793
  %v1809 = inttoptr i64 %v1758 to ptr
  %v1810 = getelementptr i8, ptr %v1809, i64 8
  %v1811 = load i64, ptr %v1810, align 1
  store i64 %v1811, ptr %v4, align 8
  %v1813.not = icmp eq i64 %v1796, 0
  br i1 %v1813.not, label %trap1814, label %ok1815

trap1814:                                         ; preds = %ok1808
  call fastcc void @native_trap()
  unreachable

ok1815:                                           ; preds = %ok1808
  %v1816 = inttoptr i64 %v1796 to ptr
  %v1817 = getelementptr i8, ptr %v1816, i64 8
  %v1818 = load i64, ptr %v1817, align 1
  %v1819.not = icmp eq i64 %v1818, 0
  br i1 %v1819.not, label %trap1820, label %ok1821

trap1820:                                         ; preds = %ok1815
  call fastcc void @native_trap()
  unreachable

ok1821:                                           ; preds = %ok1815
  %v1822 = inttoptr i64 %v1818 to ptr
  %v1823 = getelementptr i8, ptr %v1822, i64 8
  %v1824 = load i32, ptr %v1823, align 1
  %v1825 = icmp eq i32 %v1824, 0
  br i1 %v1825, label %then1829, label %ok1840

then1829:                                         ; preds = %ok1821
  call fastcc void @native_trap()
  unreachable

ok1840:                                           ; preds = %ok1821
  %v1842 = getelementptr i8, ptr %v1822, i64 16
  %v1843 = load i64, ptr %v1842, align 1
  %v1844.not = icmp eq i64 %v1843, 0
  br i1 %v1844.not, label %trap1845, label %ok1846

trap1845:                                         ; preds = %ok1840
  call fastcc void @native_trap()
  unreachable

ok1846:                                           ; preds = %ok1840
  %v1847 = inttoptr i64 %v1843 to ptr
  %v1848 = getelementptr i8, ptr %v1847, i64 8
  %v1849 = load i64, ptr %v1848, align 1
  store i64 %v1849, ptr %v111, align 8
  store i64 %v1811, ptr %v130, align 8
  store i64 23, ptr %v67, align 8
  %v76.i = icmp eq i64 %v1811, 0
  br i1 %v76.i, label %block1112, label %ok18.i

ok18.i:                                           ; preds = %ok56.i, %ok1846
  %arg2.tr9.i = phi i64 [ %v62.i, %ok56.i ], [ 14, %ok1846 ]
  %arg1.tr8.i = phi i64 [ %v21.i, %ok56.i ], [ %v1811, %ok1846 ]
  %arg0.tr7.i = phi i64 [ %v59.i, %ok56.i ], [ %v1849, %ok1846 ]
  %v19.i = inttoptr i64 %arg1.tr8.i to ptr
  %v20.i = getelementptr i8, ptr %v19.i, i64 8
  %v21.i = load i64, ptr %v20.i, align 1
  %v23.not.i = icmp eq i64 %arg0.tr7.i, 0
  br i1 %v23.not.i, label %trap24.i, label %ok25.i

trap24.i:                                         ; preds = %ok18.i
  call fastcc void @native_trap()
  unreachable

ok25.i:                                           ; preds = %ok18.i
  %v26.i = inttoptr i64 %arg0.tr7.i to ptr
  %v27.i = getelementptr i8, ptr %v26.i, i64 8
  %v28.i = load i64, ptr %v27.i, align 1
  %v29.not.i = icmp eq i64 %v28.i, 0
  br i1 %v29.not.i, label %trap30.i, label %ok31.i

trap30.i:                                         ; preds = %ok25.i
  call fastcc void @native_trap()
  unreachable

ok31.i:                                           ; preds = %ok25.i
  %v32.i = inttoptr i64 %v28.i to ptr
  %v33.i = getelementptr i8, ptr %v32.i, i64 8
  %v34.i = load i32, ptr %v33.i, align 1
  %v35.i = icmp eq i32 %v34.i, 0
  br i1 %v35.i, label %then39.i, label %ok50.i

then39.i:                                         ; preds = %ok31.i
  call fastcc void @native_trap()
  unreachable

ok50.i:                                           ; preds = %ok31.i
  %v52.i = getelementptr i8, ptr %v32.i, i64 16
  %v53.i = load i64, ptr %v52.i, align 1
  %v54.not.i = icmp eq i64 %v53.i, 0
  br i1 %v54.not.i, label %trap55.i, label %ok56.i

trap55.i:                                         ; preds = %ok50.i
  call fastcc void @native_trap()
  unreachable

ok56.i:                                           ; preds = %ok50.i
  %v57.i = inttoptr i64 %v53.i to ptr
  %v58.i = getelementptr i8, ptr %v57.i, i64 8
  %v59.i = load i64, ptr %v58.i, align 1
  %v62.i = add i64 %arg2.tr9.i, 1
  %v7.i = icmp eq i64 %v21.i, 0
  br i1 %v7.i, label %block1112, label %ok18.i

block1112:                                        ; preds = %ok56.i, %ok1846, %ok1793, %ok1740, %ok1687, %ok1634, %ok1581, %ok1528, %ok1475, %ok1422, %ok1369, %ok1316, %ok1263, %ok1210, %ok1157, %ok1104
  %slot1111.0 = phi i64 [ 0, %ok1104 ], [ 1, %ok1157 ], [ 2, %ok1210 ], [ 3, %ok1263 ], [ 4, %ok1316 ], [ 5, %ok1369 ], [ 6, %ok1422 ], [ 7, %ok1475 ], [ 8, %ok1528 ], [ 9, %ok1581 ], [ 10, %ok1634 ], [ 11, %ok1687 ], [ 12, %ok1740 ], [ 13, %ok1793 ], [ 14, %ok1846 ], [ %v62.i, %ok56.i ]
  %v1869 = load i64, ptr %v1, align 8
  %v1870.not = icmp eq i64 %v1869, 0
  br i1 %v1870.not, label %trap1871, label %ok1872

trap1871:                                         ; preds = %block1112
  call fastcc void @native_trap()
  unreachable

ok1872:                                           ; preds = %block1112
  %v1873 = inttoptr i64 %v1869 to ptr
  %v1874 = getelementptr i8, ptr %v1873, i64 16
  %v1875 = load i64, ptr %v1874, align 1
  %v1876.not = icmp eq i64 %v1875, 0
  br i1 %v1876.not, label %trap1877, label %ok1878

trap1877:                                         ; preds = %ok1872
  call fastcc void @native_trap()
  unreachable

ok1878:                                           ; preds = %ok1872
  %v1879 = inttoptr i64 %v1875 to ptr
  %v1880 = getelementptr i8, ptr %v1879, i64 8
  %v1881 = load i32, ptr %v1880, align 1
  %v1882 = icmp eq i32 %v1881, 0
  br i1 %v1882, label %then1886, label %ok1897

then1886:                                         ; preds = %ok1878
  call fastcc void @native_trap()
  unreachable

ok1897:                                           ; preds = %ok1878
  %v1899 = getelementptr i8, ptr %v1879, i64 16
  %v1900 = load i64, ptr %v1899, align 1
  %v1901.not = icmp eq i64 %v1900, 0
  br i1 %v1901.not, label %trap1902, label %ok1903

trap1902:                                         ; preds = %ok1897
  call fastcc void @native_trap()
  unreachable

ok1903:                                           ; preds = %ok1897
  %v1904 = inttoptr i64 %v1900 to ptr
  %v1905 = getelementptr i8, ptr %v1904, i64 16
  %v1906 = load i64, ptr %v1905, align 1
  %v1908 = add nsw i64 %arg1.tr1199, 1
  %675 = load i64, ptr %2, align 8, !noundef !39
  %676 = icmp ne i64 %675, 0
  %.pre412 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %677 = sext i1 %676 to i64
  %678 = add i64 %.pre412, %677
  %roots.val = load ptr, ptr %roots, align 8
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %679 = select i1 %676, ptr %roots.val, ptr %native_roots.0.val
  store i64 26, ptr %2, align 8
  store i64 0, ptr %v67, align 8
  store ptr %679, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %680 = add i64 %678, 1
  store i64 %680, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %681 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %682 = call noundef i64 @llvm.umax.i64(i64 %680, i64 %681)
  store i64 %682, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v1906, ptr %v1, align 8
  %v31.not = icmp eq i64 %v1906, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(160) %v4, i8 0, i64 160, i1 false)
  br i1 %v31.not, label %trap32, label %ok33

else42:                                           ; preds = %ok33
  %.lcssa1815 = phi i64 [ %8, %ok33 ]
  %.lcssa1628 = phi ptr [ %9, %ok33 ]
  %arg2.tr1200.lcssa = phi i64 [ %arg2.tr1200, %ok33 ]
  %arg1.tr1199.lcssa = phi i64 [ %arg1.tr1199, %ok33 ]
  %v1912 = icmp sgt i64 %arg1.tr1199.lcssa, 0
  br i1 %v1912, label %then1917, label %block1915

then1917:                                         ; preds = %else42
  %v1919.b = load i1, ptr @g.32, align 1
  br i1 %v1919.b, label %block1922, label %then1924

then1924:                                         ; preds = %then1917
  call fastcc void @native_trap()
  unreachable

block1922:                                        ; preds = %then1917
  %v1926 = load i64, ptr @g.31, align 8
  %v1928 = icmp eq i64 %v1926, %arg2.tr1200.lcssa
  %683 = zext i1 %v1928 to i64
  br label %block1915

block1915:                                        ; preds = %block1922, %else42
  %slot1914.0 = phi i64 [ %683, %block1922 ], [ 0, %else42 ]
  store ptr %.lcssa1628, ptr @native_roots.0, align 8
  store i64 %.lcssa1815, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  ret i64 %slot1914.0
}

define internal tailcc noundef range(i64 1, 0) i64 @f.5(i64 range(i64 1, 0) %arg0, i64 range(i64 0, 4294967296) %arg1) unnamed_addr #103 personality ptr @rust_eh_personality {
ok16:
  %roots = alloca { ptr, i64, i64, [4 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 4, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v8 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v9 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v8, i8 0, i64 16, i1 false)
  %v17 = inttoptr i64 %arg0 to ptr
  %v18 = getelementptr i8, ptr %v17, i64 8
  %v19 = load i64, ptr %v18, align 1
  store i64 %v19, ptr %v8, align 8
  %v20.not = icmp eq i64 %v19, 0
  br i1 %v20.not, label %trap21, label %ok22

trap21:                                           ; preds = %ok16
  call fastcc void @native_trap()
  unreachable

ok22:                                             ; preds = %ok16
  %v23 = and i64 %v19, 1
  %v24 = icmp eq i64 %v23, 0
  br i1 %v24, label %ok26, label %trap25

trap25:                                           ; preds = %ok22
  call fastcc void @native_trap()
  unreachable

ok26:                                             ; preds = %ok22
  %v27 = inttoptr i64 %v19 to ptr
  %v28 = getelementptr i8, ptr %v27, i64 8
  %v29 = load i64, ptr %v28, align 1
  %v31 = and i64 %v29, 4294967295
  %v32 = icmp samesign ugt i64 %arg1, %v31
  br i1 %v32, label %then36, label %block34

then36:                                           ; preds = %ok26
  call fastcc void @native_trap()
  unreachable

block34:                                          ; preds = %ok26
  %v39 = trunc nuw i64 %arg1 to i32
  %v44.not36 = icmp eq i64 %arg1, 0
  br i1 %v44.not36, label %block213, label %then48.lr.ph

then48.lr.ph:                                     ; preds = %block34
  %v161 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  br label %then48

then48:                                           ; preds = %block73, %then48.lr.ph
  %slot7.038 = phi i32 [ 0, %then48.lr.ph ], [ %v209, %block73 ]
  %slot4.037 = phi i32 [ 0, %then48.lr.ph ], [ %v207, %block73 ]
  %v50 = load i64, ptr %v8, align 8
  %v52.not = icmp eq i64 %v50, 0
  br i1 %v52.not, label %trap53, label %ok54

trap53:                                           ; preds = %then48
  call fastcc void @native_trap()
  unreachable

ok54:                                             ; preds = %then48
  %v55 = and i64 %v50, 1
  %v56 = icmp eq i64 %v55, 0
  br i1 %v56, label %ok58, label %trap57

trap57:                                           ; preds = %ok54
  call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %ok54
  %v59 = inttoptr i64 %v50 to ptr
  %v60 = getelementptr i8, ptr %v59, i64 8
  %v61 = load i64, ptr %v60, align 1
  %v62 = zext i32 %slot4.037 to i64
  %v63 = icmp ugt i64 %v61, %v62
  br i1 %v63, label %ok65, label %trap64

trap64:                                           ; preds = %ok58
  call fastcc void @native_trap()
  unreachable

ok65:                                             ; preds = %ok58
  %v67 = getelementptr i8, ptr %v59, i64 16
  %v68 = getelementptr i8, ptr %v67, i64 %v62
  %v69 = load i8, ptr %v68, align 1
  %v71 = icmp slt i8 %v69, 0
  br i1 %v71, label %then75, label %block73

then75:                                           ; preds = %ok65
  %7 = add nsw i8 %v69, 11
  %v8325 = icmp ult i8 %7, -51
  br i1 %v8325, label %then86, label %else93

then86:                                           ; preds = %then75
  call fastcc void @native_trap()
  unreachable

else93:                                           ; preds = %then75
  %v97 = icmp samesign ult i8 %v69, -32
  %v105 = icmp samesign ult i8 %v69, -16
  %v108 = select i1 %v105, i32 3, i32 4
  %slot99.0 = select i1 %v97, i32 2, i32 %v108
  %v113 = sub i32 %v39, %slot4.037
  %v114 = icmp ugt i32 %slot99.0, %v113
  br i1 %v114, label %then118, label %ok132.preheader

ok132.preheader:                                  ; preds = %else93
  %wide.trip.count = zext nneg i32 %slot99.0 to i64
  br label %ok132

then118:                                          ; preds = %else93
  call fastcc void @native_trap()
  unreachable

ok132:                                            ; preds = %block148, %ok132.preheader
  %indvars.iv = phi i64 [ 1, %ok132.preheader ], [ %indvars.iv.next, %block148 ]
  %8 = trunc nuw nsw i64 %indvars.iv to i32
  %v125 = add i32 %slot4.037, %8
  %v136 = zext i32 %v125 to i64
  %v137 = icmp ugt i64 %v61, %v136
  br i1 %v137, label %ok139, label %trap138

trap138:                                          ; preds = %ok132
  call fastcc void @native_trap()
  unreachable

ok139:                                            ; preds = %ok132
  %v142 = getelementptr i8, ptr %v67, i64 %v136
  %v143 = load i8, ptr %v142, align 1
  %v146.not = icmp slt i8 %v143, -64
  br i1 %v146.not, label %block148, label %then150

then150:                                          ; preds = %ok139
  call fastcc void @native_trap()
  unreachable

block148:                                         ; preds = %ok139
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %block120, label %ok132

block120:                                         ; preds = %block148
  store i64 %v50, ptr %v161, align 8
  store i64 4, ptr %1, align 8
  %v163 = call tailcc i32 @f.3(i64 %v50, i32 %slot4.037)
  %v164 = icmp ult i32 %v163, 128
  br i1 %v164, label %then191, label %else168

else168:                                          ; preds = %block120
  %v172 = icmp ult i32 %v163, 2048
  %v180 = icmp ult i32 %v163, 65536
  %v183 = select i1 %v180, i32 3, i32 4
  %9 = icmp eq i32 %v183, %slot99.0
  %10 = select i1 %v172, i1 %v97, i1 %9
  br i1 %10, label %block189, label %then191

then191:                                          ; preds = %else168, %block120
  call fastcc void @native_trap()
  unreachable

block189:                                         ; preds = %else168
  %11 = and i32 %v163, -2048
  %v195 = icmp eq i32 %11, 55296
  %v198 = icmp ugt i32 %v163, 1114111
  %v20026 = or i1 %v198, %v195
  br i1 %v20026, label %then203, label %block73

then203:                                          ; preds = %block189
  call fastcc void @native_trap()
  unreachable

block73:                                          ; preds = %block189, %ok65
  %slot5.0 = phi i32 [ %slot99.0, %block189 ], [ 1, %ok65 ]
  %v207 = add i32 %slot5.0, %slot4.037
  %v209 = add i32 %slot7.038, 1
  %v44.not = icmp eq i32 %v207, %v39
  br i1 %v44.not, label %block40, label %then48

block40:                                          ; preds = %block73
  %v209.lcssa = phi i32 [ %v209, %block73 ]
  %v211 = icmp eq i64 %arg1, 4294967295
  br i1 %v211, label %then215, label %block213

then215:                                          ; preds = %block40
  call fastcc void @native_trap()
  unreachable

block213:                                         ; preds = %block40, %block34
  %slot7.0.lcssa42 = phi i32 [ %v209.lcssa, %block40 ], [ 0, %block34 ]
  store i64 3, ptr %1, align 8
  %v221 = call fastcc i64 @native_array_new(i32 %v39)
  store i64 %v221, ptr %v9, align 8
  %v222 = load i64, ptr %v8, align 8
  %12 = and i64 %v221, 1
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %15, label %14

14:                                               ; preds = %block213
  call fastcc void @native_trap() #111
  unreachable

15:                                               ; preds = %block213
  %16 = inttoptr i64 %v221 to ptr
  %17 = icmp ne i64 %v222, 0
  %18 = and i64 %v222, 1
  %19 = icmp eq i64 %18, 0
  %20 = and i1 %17, %19
  br i1 %20, label %22, label %21

21:                                               ; preds = %15
  call fastcc void @native_trap() #111
  unreachable

22:                                               ; preds = %15
  %23 = inttoptr i64 %v222 to ptr
  %24 = getelementptr inbounds nuw i8, ptr %16, i64 8
  %25 = load i64, ptr %24, align 8, !noundef !39
  %26 = icmp ult i64 %25, %arg1
  br i1 %26, label %31, label %27

27:                                               ; preds = %22
  %28 = getelementptr inbounds nuw i8, ptr %23, i64 8
  %29 = load i64, ptr %28, align 8, !noundef !39
  %30 = icmp ugt i64 %arg1, %29
  br i1 %30, label %31, label %native_array_copy.exit

31:                                               ; preds = %27, %22
  call fastcc void @native_trap() #111
  unreachable

native_array_copy.exit:                           ; preds = %27
  %32 = getelementptr inbounds nuw i8, ptr %23, i64 16
  %33 = getelementptr inbounds nuw i8, ptr %16, i64 16
  call void @llvm.memmove.p0.p0.i64(ptr nonnull align 1 %33, ptr nonnull align 1 %32, i64 %arg1, i1 false)
  %v226 = load i64, ptr %v9, align 8
  %v227 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 %v226, ptr %v227, align 8
  store i64 4, ptr %1, align 8
  %34 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %35 = icmp eq ptr %34, null
  br i1 %35, label %36, label %37

36:                                               ; preds = %native_array_copy.exit
  call fastcc void @native_trap() #111
  unreachable

37:                                               ; preds = %native_array_copy.exit
  %38 = getelementptr inbounds nuw i8, ptr %34, i64 376
  %39 = load i64, ptr %38, align 8, !noundef !39
  %40 = icmp eq i64 %39, 0
  br i1 %40, label %41, label %45

41:                                               ; preds = %51, %45, %37
  %42 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %43 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %34, i64 noundef 48, ptr noundef %42) #84
  %44 = icmp eq ptr %43, null
  br i1 %44, label %53, label %ok232

45:                                               ; preds = %37
  %46 = getelementptr inbounds nuw i8, ptr %34, i64 368
  %47 = load i64, ptr %46, align 8, !noundef !39
  %48 = add i64 %47, 1
  store i64 %48, ptr %46, align 8
  %49 = urem i64 %48, %39
  %50 = icmp eq i64 %49, 0
  br i1 %50, label %51, label %41

51:                                               ; preds = %45
  %52 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %34, ptr noundef %52) #84
  br label %41

53:                                               ; preds = %41
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok232:                                            ; preds = %41
  store i64 198, ptr %43, align 1
  %v239 = getelementptr i8, ptr %43, i64 8
  store i32 %slot7.0.lcssa42, ptr %v239, align 1
  %v244 = getelementptr i8, ptr %43, i64 16
  store i32 %v39, ptr %v244, align 1
  %v249 = getelementptr i8, ptr %43, i64 24
  store i64 %v226, ptr %v249, align 1
  %v254 = getelementptr i8, ptr %43, i64 32
  store i32 0, ptr %v254, align 1
  %v259 = getelementptr i8, ptr %43, i64 40
  store i32 0, ptr %v259, align 1
  %54 = load i64, ptr %0, align 8, !noundef !39
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %native_roots_leave.exit, label %56

56:                                               ; preds = %ok232
  %57 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %57, ptr @native_roots.0, align 8
  %58 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %59 = add i64 %58, -1
  store i64 %59, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %56, %ok232
  %60 = ptrtoint ptr %43 to i64
  ret i64 %60
}

define internal tailcc i32 @f.4(i64 %arg0, i32 %arg1) unnamed_addr #103 personality ptr @rust_eh_personality {
entry:
  %v10.not = icmp eq i64 %arg0, 0
  br i1 %v10.not, label %trap11, label %ok12

trap11:                                           ; preds = %entry
  tail call fastcc void @native_trap()
  unreachable

ok12:                                             ; preds = %entry
  %v13 = inttoptr i64 %arg0 to ptr
  %v14 = getelementptr i8, ptr %v13, i64 8
  %v15 = load i32, ptr %v14, align 1
  %v17 = icmp ult i32 %v15, %arg1
  br i1 %v17, label %then21, label %ok27

then21:                                           ; preds = %ok12
  tail call fastcc void @native_trap()
  unreachable

ok27:                                             ; preds = %ok12
  %v29 = getelementptr i8, ptr %v13, i64 16
  %v30 = load i32, ptr %v29, align 1
  %v31 = icmp eq i32 %v15, %v30
  br i1 %v31, label %native_roots_leave.exit, label %ok49

native_roots_leave.exit:                          ; preds = %ok208, %ok27
  %common.ret.op = phi i32 [ %slot4.3.lcssa, %ok208 ], [ %arg1, %ok27 ]
  ret i32 %common.ret.op

ok49:                                             ; preds = %ok27
  %v43 = getelementptr i8, ptr %v13, i64 40
  %v44 = load i32, ptr %v43, align 1
  %v51 = getelementptr i8, ptr %v13, i64 32
  %v52 = load i32, ptr %v51, align 1
  %v54 = sub i32 %v52, %arg1
  %v57 = sub i32 %arg1, %v52
  %v60 = icmp ult i32 %arg1, %v52
  %v63 = select i1 %v60, i32 %v54, i32 %v57
  %v64 = icmp ult i32 %arg1, %v63
  %spec.select = select i1 %v64, i32 0, i32 %v44
  %spec.select29 = select i1 %v64, i32 0, i32 %v52
  %v72 = sub i32 %v15, %arg1
  %v75 = sub i32 %spec.select29, %arg1
  %v78 = sub i32 %arg1, %spec.select29
  %v81 = icmp ult i32 %arg1, %spec.select29
  %v84 = select i1 %v81, i32 %v75, i32 %v78
  %v85 = icmp ult i32 %v72, %v84
  %spec.select30 = select i1 %v85, i32 %v30, i32 %spec.select
  %spec.select31 = select i1 %v85, i32 %v15, i32 %spec.select29
  %v104 = getelementptr i8, ptr %v13, i64 24
  %v105 = load i64, ptr %v104, align 1
  %v11044 = icmp ugt i32 %arg1, %spec.select31
  br i1 %v11044, label %then114.lr.ph, label %loop164.preheader

then114.lr.ph:                                    ; preds = %ok49
  %v118.not = icmp eq i64 %v105, 0
  %v125 = inttoptr i64 %v105 to ptr
  %v126 = getelementptr i8, ptr %v125, i64 8
  %v133 = getelementptr i8, ptr %v125, i64 16
  br i1 %v118.not, label %trap119, label %then114.lr.ph.split

then114.lr.ph.split:                              ; preds = %then114.lr.ph
  %v121 = and i64 %v105, 1
  %v122 = icmp eq i64 %v121, 0
  br i1 %v122, label %then114.lr.ph.split.split, label %trap123

then114.lr.ph.split.split:                        ; preds = %then114.lr.ph.split
  %v127 = load i64, ptr %v126, align 1
  br label %then114

loop164.preheader:                                ; preds = %ok49
  %v16748 = icmp ult i32 %arg1, %spec.select31
  br i1 %v16748, label %loop174.preheader.lr.ph, label %ok208

loop174.preheader.lr.ph:                          ; preds = %loop164.preheader
  %v178.not = icmp eq i64 %v105, 0
  %v185 = inttoptr i64 %v105 to ptr
  %v186 = getelementptr i8, ptr %v185, i64 8
  %v193 = getelementptr i8, ptr %v185, i64 16
  br i1 %v178.not, label %trap179, label %loop174.preheader.lr.ph.split

loop174.preheader.lr.ph.split:                    ; preds = %loop174.preheader.lr.ph
  %v181 = and i64 %v105, 1
  %v182 = icmp eq i64 %v181, 0
  br i1 %v182, label %loop174.preheader.lr.ph.split.split, label %trap183

loop174.preheader.lr.ph.split.split:              ; preds = %loop174.preheader.lr.ph.split
  %v187 = load i64, ptr %v186, align 1
  br label %loop174.preheader

then114:                                          ; preds = %ok131, %then114.lr.ph.split.split
  %slot3.246 = phi i32 [ %spec.select31, %then114.lr.ph.split.split ], [ %v162, %ok131 ]
  %slot4.245 = phi i32 [ %spec.select30, %then114.lr.ph.split.split ], [ %v160, %ok131 ]
  %v128 = zext i32 %slot4.245 to i64
  %v129 = icmp ugt i64 %v127, %v128
  br i1 %v129, label %ok131, label %trap130

trap119:                                          ; preds = %then114.lr.ph
  tail call fastcc void @native_trap()
  unreachable

trap123:                                          ; preds = %then114.lr.ph.split
  tail call fastcc void @native_trap()
  unreachable

trap130:                                          ; preds = %then114
  tail call fastcc void @native_trap()
  unreachable

ok131:                                            ; preds = %then114
  %v134 = getelementptr i8, ptr %v133, i64 %v128
  %v135 = load i8, ptr %v134, align 1
  %v137 = icmp sgt i8 %v135, -1
  %v145 = icmp ult i8 %v135, -32
  %v153 = icmp ult i8 %v135, -16
  %v156 = select i1 %v153, i32 3, i32 4
  %slot147.0 = select i1 %v145, i32 2, i32 %v156
  %slot139.0 = select i1 %v137, i32 1, i32 %slot147.0
  %v160 = add i32 %slot139.0, %slot4.245
  %v162 = add nuw i32 %slot3.246, 1
  %exitcond.not = icmp eq i32 %v162, %arg1
  br i1 %exitcond.not, label %ok208, label %then114

loop174.preheader:                                ; preds = %block173, %loop174.preheader.lr.ph.split.split
  %slot3.350 = phi i32 [ %spec.select31, %loop174.preheader.lr.ph.split.split ], [ %v203, %block173 ]
  %slot4.349 = phi i32 [ %spec.select30, %loop174.preheader.lr.ph.split.split ], [ %v177.lcssa5, %block173 ]
  br label %loop174

loop174:                                          ; preds = %ok191, %loop174.preheader
  %slot4.4 = phi i32 [ %v177, %ok191 ], [ %slot4.349, %loop174.preheader ]
  %v177 = add i32 %slot4.4, -1
  %v188 = zext i32 %v177 to i64
  %v189 = icmp ugt i64 %v187, %v188
  br i1 %v189, label %ok191, label %trap190

trap179:                                          ; preds = %loop174.preheader.lr.ph
  tail call fastcc void @native_trap()
  unreachable

trap183:                                          ; preds = %loop174.preheader.lr.ph.split
  tail call fastcc void @native_trap()
  unreachable

trap190:                                          ; preds = %loop174
  tail call fastcc void @native_trap()
  unreachable

ok191:                                            ; preds = %loop174
  %v194 = getelementptr i8, ptr %v193, i64 %v188
  %v195 = load i8, ptr %v194, align 1
  %v198 = icmp slt i8 %v195, -64
  br i1 %v198, label %loop174, label %block173

block173:                                         ; preds = %ok191
  %v177.lcssa5 = phi i32 [ %v177, %ok191 ]
  %v203 = add i32 %slot3.350, -1
  %v167 = icmp ult i32 %arg1, %v203
  br i1 %v167, label %loop174.preheader, label %ok208

ok208:                                            ; preds = %block173, %ok131, %loop164.preheader
  %slot4.3.lcssa = phi i32 [ %spec.select30, %loop164.preheader ], [ %v160, %ok131 ], [ %v177.lcssa5, %block173 ]
  store i32 %arg1, ptr %v51, align 1
  store i32 %slot4.3.lcssa, ptr %v43, align 1
  br label %native_roots_leave.exit
}

define internal tailcc void @f.11(i64 range(i64 1, 0) %arg0, i64 range(i64 1, 0) %arg1) unnamed_addr #102 personality ptr @rust_eh_personality {
ok20:
  %roots = alloca { ptr, i64, i64, [12 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 12, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v2 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  store i64 %arg1, ptr %v2, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v7 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %v3, i8 0, i64 48, i1 false)
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v21 = inttoptr i64 %arg0 to ptr
  %v22 = getelementptr i8, ptr %v21, i64 8
  %v23 = load i64, ptr %v22, align 1
  store i64 %v23, ptr %v5, align 8
  %v25 = icmp eq i64 %v23, %arg1
  br i1 %v25, label %block16, label %next28

next28:                                           ; preds = %ok20
  %v30.not = icmp eq i64 %v23, 0
  br i1 %v30.not, label %trap31, label %ok39

trap31:                                           ; preds = %next28
  call fastcc void @native_trap()
  unreachable

ok39:                                             ; preds = %next28
  %v33 = inttoptr i64 %v23 to ptr
  %v34 = getelementptr i8, ptr %v33, i64 16
  %v35 = load i32, ptr %v34, align 1
  %v40 = inttoptr i64 %arg1 to ptr
  %v41 = getelementptr i8, ptr %v40, i64 16
  %v42 = load i32, ptr %v41, align 1
  %v43.not = icmp eq i32 %v35, %v42
  br i1 %v43.not, label %ok57, label %block16

ok57:                                             ; preds = %ok39
  %v52 = getelementptr i8, ptr %v33, i64 24
  %v53 = load i64, ptr %v52, align 1
  store i64 %v53, ptr %v6, align 8
  %v59 = getelementptr i8, ptr %v40, i64 24
  %v60 = load i64, ptr %v59, align 1
  %v60.fr = freeze i64 %v60
  store i64 %v60.fr, ptr %v7, align 8
  %v65.not4 = icmp eq i32 %v35, 0
  br i1 %v65.not4, label %block16, label %then69.lr.ph

then69.lr.ph:                                     ; preds = %ok57
  %v73.not = icmp eq i64 %v53, 0
  %v80 = inttoptr i64 %v53 to ptr
  %v81 = getelementptr i8, ptr %v80, i64 8
  %v88 = getelementptr i8, ptr %v80, i64 16
  %v94.not = icmp eq i64 %v60.fr, 0
  %v97 = and i64 %v60.fr, 1
  %v98 = icmp eq i64 %v97, 0
  %v101 = inttoptr i64 %v60.fr to ptr
  %v102 = getelementptr i8, ptr %v101, i64 8
  %v109 = getelementptr i8, ptr %v101, i64 16
  br i1 %v73.not, label %trap74, label %then69.lr.ph.split

then69.lr.ph.split:                               ; preds = %then69.lr.ph
  %v76 = and i64 %v53, 1
  %v77 = icmp eq i64 %v76, 0
  br i1 %v77, label %then69.lr.ph.split.split, label %trap78

then69.lr.ph.split.split:                         ; preds = %then69.lr.ph.split
  %v82 = load i64, ptr %v81, align 1
  br i1 %v94.not, label %then69.us, label %then69.lr.ph.split.split.split

then69.us:                                        ; preds = %then69.lr.ph.split.split
  %v84.us.not = icmp eq i64 %v82, 0
  br i1 %v84.us.not, label %trap85, label %ok86.us

ok86.us:                                          ; preds = %then69.us
  call fastcc void @native_trap()
  unreachable

then69.lr.ph.split.split.split:                   ; preds = %then69.lr.ph.split.split
  br i1 %v98, label %then69.us7.preheader, label %then69

then69.us7.preheader:                             ; preds = %then69.lr.ph.split.split.split
  %7 = zext i32 %v35 to i64
  br label %then69.us7

then69.us7:                                       ; preds = %ok107.us, %then69.us7.preheader
  %indvars.iv = phi i64 [ 0, %then69.us7.preheader ], [ %indvars.iv.next, %ok107.us ]
  %exitcond.not = icmp eq i64 %indvars.iv, %v82
  br i1 %exitcond.not, label %trap85, label %ok86.us11

ok86.us11:                                        ; preds = %then69.us7
  %v103.us = load i64, ptr %v102, align 1
  %v105.us = icmp ugt i64 %v103.us, %indvars.iv
  br i1 %v105.us, label %ok107.us, label %trap106

ok107.us:                                         ; preds = %ok86.us11
  %v89.us12 = getelementptr i8, ptr %v88, i64 %indvars.iv
  %v90.us13 = load i8, ptr %v89.us12, align 1
  %v110.us = getelementptr i8, ptr %v109, i64 %indvars.iv
  %v111.us = load i8, ptr %v110.us, align 1
  %v113.not.us.not = icmp ne i8 %v90.us13, %v111.us
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %v65.not.us = icmp eq i64 %indvars.iv.next, %7
  %or.cond = select i1 %v113.not.us.not, i1 true, i1 %v65.not.us
  br i1 %or.cond, label %block16, label %then69.us7

then69:                                           ; preds = %then69.lr.ph.split.split.split
  %v84.not = icmp eq i64 %v82, 0
  br i1 %v84.not, label %trap85, label %ok86

trap74:                                           ; preds = %then69.lr.ph
  call fastcc void @native_trap()
  unreachable

trap78:                                           ; preds = %then69.lr.ph.split
  call fastcc void @native_trap()
  unreachable

trap85:                                           ; preds = %then69, %then69.us7, %then69.us
  call fastcc void @native_trap()
  unreachable

ok86:                                             ; preds = %then69
  call fastcc void @native_trap()
  unreachable

trap106:                                          ; preds = %ok86.us11
  call fastcc void @native_trap()
  unreachable

block16:                                          ; preds = %ok107.us, %ok57, %ok39, %ok20
  %v146 = phi i1 [ false, %ok20 ], [ true, %ok39 ], [ false, %ok57 ], [ %v113.not.us.not, %ok107.us ]
  %v122.b = load i1, ptr @g.24, align 1
  br i1 %v122.b, label %block125, label %then127

then127:                                          ; preds = %block16
  call fastcc void @native_trap()
  unreachable

block125:                                         ; preds = %block16
  %v129 = load i64, ptr @g.23, align 8
  %v130.not = icmp eq i64 %v129, 0
  br i1 %v130.not, label %trap131, label %ok132

trap131:                                          ; preds = %block125
  call fastcc void @native_trap()
  unreachable

ok132:                                            ; preds = %block125
  %v133.b = load i1, ptr @g.12, align 1
  br i1 %v133.b, label %block136, label %then138

then138:                                          ; preds = %ok132
  call fastcc void @native_trap()
  unreachable

block136:                                         ; preds = %ok132
  %v140 = load i64, ptr @g.11, align 8
  %v141.not = icmp eq i64 %v140, 0
  br i1 %v141.not, label %trap142, label %ok143

trap142:                                          ; preds = %block136
  call fastcc void @native_trap()
  unreachable

ok143:                                            ; preds = %block136
  br i1 %v146, label %then150, label %.critedge

then150:                                          ; preds = %ok143
  %v152.b = load i1, ptr @g.16, align 1
  br i1 %v152.b, label %block155, label %then157

then157:                                          ; preds = %then150
  call fastcc void @native_trap()
  unreachable

block155:                                         ; preds = %then150
  %v159 = load i64, ptr @g.15, align 8
  %v160.not = icmp eq i64 %v159, 0
  br i1 %v160.not, label %trap161, label %ok162

trap161:                                          ; preds = %block155
  call fastcc void @native_trap()
  unreachable

ok162:                                            ; preds = %block155
  store i64 8, ptr %1, align 8
  %8 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %9 = icmp eq ptr %8, null
  br i1 %9, label %10, label %11

10:                                               ; preds = %ok162
  call fastcc void @native_trap() #111
  unreachable

11:                                               ; preds = %ok162
  %12 = getelementptr inbounds nuw i8, ptr %8, i64 376
  %13 = load i64, ptr %12, align 8, !noundef !39
  %14 = icmp eq i64 %13, 0
  br i1 %14, label %15, label %19

15:                                               ; preds = %25, %19, %11
  %16 = phi ptr [ %.pre, %25 ], [ %roots, %19 ], [ %roots, %11 ]
  %17 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %8, i64 noundef 24, ptr noundef %16) #84
  %18 = icmp eq ptr %17, null
  br i1 %18, label %26, label %ok167

19:                                               ; preds = %11
  %20 = getelementptr inbounds nuw i8, ptr %8, i64 368
  %21 = load i64, ptr %20, align 8, !noundef !39
  %22 = add i64 %21, 1
  store i64 %22, ptr %20, align 8
  %23 = urem i64 %22, %13
  %24 = icmp eq i64 %23, 0
  br i1 %24, label %25, label %15

25:                                               ; preds = %19
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %8, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %15

26:                                               ; preds = %15
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok167:                                            ; preds = %15
  %27 = ptrtoint ptr %17 to i64
  store i64 98, ptr %17, align 1
  %v174 = getelementptr i8, ptr %17, i64 8
  store i32 0, ptr %v174, align 1
  %v179 = getelementptr i8, ptr %17, i64 16
  store i64 0, ptr %v179, align 1
  store i64 %27, ptr %v3, align 8
  %v182 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  store i64 %27, ptr %v182, align 8
  %v183 = getelementptr inbounds nuw i8, ptr %roots, i64 96
  store i64 ptrtoint (ptr @object.2.1 to i64), ptr %v183, align 8
  %v184 = getelementptr inbounds nuw i8, ptr %roots, i64 104
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v184, align 8
  %v185 = getelementptr inbounds nuw i8, ptr %roots, i64 112
  store i64 %27, ptr %v185, align 8
  store i64 12, ptr %1, align 8
  %28 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %29 = icmp eq ptr %28, null
  br i1 %29, label %30, label %31

30:                                               ; preds = %ok167
  call fastcc void @native_trap() #111
  unreachable

31:                                               ; preds = %ok167
  %32 = getelementptr inbounds nuw i8, ptr %28, i64 376
  %33 = load i64, ptr %32, align 8, !noundef !39
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %35, label %39

35:                                               ; preds = %45, %39, %31
  %36 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %37 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %28, i64 noundef 24, ptr noundef %36) #84
  %38 = icmp eq ptr %37, null
  br i1 %38, label %47, label %ok190

39:                                               ; preds = %31
  %40 = getelementptr inbounds nuw i8, ptr %28, i64 368
  %41 = load i64, ptr %40, align 8, !noundef !39
  %42 = add i64 %41, 1
  store i64 %42, ptr %40, align 8
  %43 = urem i64 %42, %33
  %44 = icmp eq i64 %43, 0
  br i1 %44, label %45, label %35

45:                                               ; preds = %39
  %46 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %28, ptr noundef %46) #84
  br label %35

47:                                               ; preds = %35
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok190:                                            ; preds = %35
  %48 = ptrtoint ptr %37 to i64
  store i64 10, ptr %37, align 1
  %v197 = getelementptr i8, ptr %37, i64 8
  store i64 ptrtoint (ptr @object.2.1 to i64), ptr %v197, align 1
  %v202 = getelementptr i8, ptr %37, i64 16
  store i64 %27, ptr %v202, align 1
  store i64 %48, ptr %v182, align 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v183, align 8
  store i64 %27, ptr %v184, align 8
  store i64 11, ptr %1, align 8
  %49 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %50 = icmp eq ptr %49, null
  br i1 %50, label %51, label %52

51:                                               ; preds = %ok190
  call fastcc void @native_trap() #111
  unreachable

52:                                               ; preds = %ok190
  %53 = getelementptr inbounds nuw i8, ptr %49, i64 376
  %54 = load i64, ptr %53, align 8, !noundef !39
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %56, label %60

56:                                               ; preds = %66, %60, %52
  %57 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %58 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %49, i64 noundef 24, ptr noundef %57) #84
  %59 = icmp eq ptr %58, null
  br i1 %59, label %68, label %ok210

60:                                               ; preds = %52
  %61 = getelementptr inbounds nuw i8, ptr %49, i64 368
  %62 = load i64, ptr %61, align 8, !noundef !39
  %63 = add i64 %62, 1
  store i64 %63, ptr %61, align 8
  %64 = urem i64 %63, %54
  %65 = icmp eq i64 %64, 0
  br i1 %65, label %66, label %56

66:                                               ; preds = %60
  %67 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %49, ptr noundef %67) #84
  br label %56

68:                                               ; preds = %56
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok210:                                            ; preds = %56
  %69 = ptrtoint ptr %58 to i64
  store i64 66, ptr %58, align 1
  %v217 = getelementptr i8, ptr %58, i64 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v217, align 1
  %v222 = getelementptr i8, ptr %58, i64 16
  store i64 %48, ptr %v222, align 1
  store i64 %69, ptr %v179, align 1
  %v228 = load i64, ptr %v3, align 8
  %v229.not = icmp eq i64 %v228, 0
  br i1 %v229.not, label %trap230, label %ok231

trap230:                                          ; preds = %ok210
  call fastcc void @native_trap()
  unreachable

ok231:                                            ; preds = %ok210
  %v232 = inttoptr i64 %v228 to ptr
  %v233 = getelementptr i8, ptr %v232, i64 8
  store i32 1, ptr %v233, align 1
  %v234 = load i64, ptr %v3, align 8
  %v235.not = icmp eq i64 %v234, 0
  br i1 %v235.not, label %trap236, label %ok237

trap236:                                          ; preds = %ok231
  call fastcc void @native_trap()
  unreachable

ok237:                                            ; preds = %ok231
  %v238 = inttoptr i64 %v234 to ptr
  %v239 = getelementptr i8, ptr %v238, i64 8
  %v240 = load i32, ptr %v239, align 1
  %v241 = icmp eq i32 %v240, 0
  br i1 %v241, label %then245, label %ok250

then245:                                          ; preds = %ok237
  call fastcc void @native_trap()
  unreachable

ok250:                                            ; preds = %ok237
  %v252 = getelementptr i8, ptr %v238, i64 16
  %v253 = load i64, ptr %v252, align 1
  %v254.not = icmp eq i64 %v253, 0
  br i1 %v254.not, label %trap255, label %ok256

trap255:                                          ; preds = %ok250
  call fastcc void @native_trap()
  unreachable

ok256:                                            ; preds = %ok250
  store i64 %v253, ptr %v4, align 8
  %v260 = inttoptr i64 %v253 to ptr
  %v268 = getelementptr i8, ptr %v260, i64 8
  %v269 = load i64, ptr %v268, align 1
  %v270.not = icmp eq i64 %v269, 0
  br i1 %v270.not, label %trap271, label %ok272

trap271:                                          ; preds = %ok256
  call fastcc void @native_trap()
  unreachable

ok272:                                            ; preds = %ok256
  %v261 = getelementptr i8, ptr %v260, i64 16
  %v262 = load i64, ptr %v261, align 1
  %v273 = inttoptr i64 %v269 to ptr
  %v274 = getelementptr i8, ptr %v273, i64 8
  %v275 = load ptr, ptr %v274, align 1
  store i64 %v262, ptr %v182, align 8
  store i64 9, ptr %1, align 8
  %v278 = call tailcc i32 %v275(i64 %v262, i64 0)
  %v279.b = load i1, ptr @g.16, align 1
  br i1 %v279.b, label %block282, label %then284

then284:                                          ; preds = %ok272
  call fastcc void @native_trap()
  unreachable

block282:                                         ; preds = %ok272
  %v286 = load i64, ptr @g.15, align 8
  %v287.not = icmp eq i64 %v286, 0
  br i1 %v287.not, label %trap288, label %ok289

trap288:                                          ; preds = %block282
  call fastcc void @native_trap()
  unreachable

ok289:                                            ; preds = %block282
  store i64 8, ptr %1, align 8
  %70 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %71 = icmp eq ptr %70, null
  br i1 %71, label %72, label %73

72:                                               ; preds = %ok289
  call fastcc void @native_trap() #111
  unreachable

73:                                               ; preds = %ok289
  %74 = getelementptr inbounds nuw i8, ptr %70, i64 376
  %75 = load i64, ptr %74, align 8, !noundef !39
  %76 = icmp eq i64 %75, 0
  br i1 %76, label %77, label %81

77:                                               ; preds = %87, %81, %73
  %78 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %79 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %70, i64 noundef 24, ptr noundef %78) #84
  %80 = icmp eq ptr %79, null
  br i1 %80, label %89, label %ok294

81:                                               ; preds = %73
  %82 = getelementptr inbounds nuw i8, ptr %70, i64 368
  %83 = load i64, ptr %82, align 8, !noundef !39
  %84 = add i64 %83, 1
  store i64 %84, ptr %82, align 8
  %85 = urem i64 %84, %75
  %86 = icmp eq i64 %85, 0
  br i1 %86, label %87, label %77

87:                                               ; preds = %81
  %88 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %70, ptr noundef %88) #84
  br label %77

89:                                               ; preds = %77
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok294:                                            ; preds = %77
  %90 = ptrtoint ptr %79 to i64
  store i64 98, ptr %79, align 1
  %v301 = getelementptr i8, ptr %79, i64 8
  store i32 0, ptr %v301, align 1
  %v306 = getelementptr i8, ptr %79, i64 16
  store i64 0, ptr %v306, align 1
  store i64 %90, ptr %v3, align 8
  store i64 %90, ptr %v182, align 8
  store i64 ptrtoint (ptr @object.1.1 to i64), ptr %v183, align 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v184, align 8
  store i64 %90, ptr %v185, align 8
  store i64 12, ptr %1, align 8
  %91 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %92 = icmp eq ptr %91, null
  br i1 %92, label %93, label %94

93:                                               ; preds = %ok294
  call fastcc void @native_trap() #111
  unreachable

94:                                               ; preds = %ok294
  %95 = getelementptr inbounds nuw i8, ptr %91, i64 376
  %96 = load i64, ptr %95, align 8, !noundef !39
  %97 = icmp eq i64 %96, 0
  br i1 %97, label %98, label %102

98:                                               ; preds = %108, %102, %94
  %99 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %100 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %91, i64 noundef 24, ptr noundef %99) #84
  %101 = icmp eq ptr %100, null
  br i1 %101, label %110, label %ok317

102:                                              ; preds = %94
  %103 = getelementptr inbounds nuw i8, ptr %91, i64 368
  %104 = load i64, ptr %103, align 8, !noundef !39
  %105 = add i64 %104, 1
  store i64 %105, ptr %103, align 8
  %106 = urem i64 %105, %96
  %107 = icmp eq i64 %106, 0
  br i1 %107, label %108, label %98

108:                                              ; preds = %102
  %109 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %91, ptr noundef %109) #84
  br label %98

110:                                              ; preds = %98
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok317:                                            ; preds = %98
  %111 = ptrtoint ptr %100 to i64
  store i64 10, ptr %100, align 1
  %v324 = getelementptr i8, ptr %100, i64 8
  store i64 ptrtoint (ptr @object.1.1 to i64), ptr %v324, align 1
  %v329 = getelementptr i8, ptr %100, i64 16
  store i64 %90, ptr %v329, align 1
  store i64 %111, ptr %v182, align 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v183, align 8
  store i64 %90, ptr %v184, align 8
  store i64 11, ptr %1, align 8
  %112 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %113 = icmp eq ptr %112, null
  br i1 %113, label %114, label %115

114:                                              ; preds = %ok317
  call fastcc void @native_trap() #111
  unreachable

115:                                              ; preds = %ok317
  %116 = getelementptr inbounds nuw i8, ptr %112, i64 376
  %117 = load i64, ptr %116, align 8, !noundef !39
  %118 = icmp eq i64 %117, 0
  br i1 %118, label %119, label %123

119:                                              ; preds = %129, %123, %115
  %120 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %121 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %112, i64 noundef 24, ptr noundef %120) #84
  %122 = icmp eq ptr %121, null
  br i1 %122, label %131, label %ok337

123:                                              ; preds = %115
  %124 = getelementptr inbounds nuw i8, ptr %112, i64 368
  %125 = load i64, ptr %124, align 8, !noundef !39
  %126 = add i64 %125, 1
  store i64 %126, ptr %124, align 8
  %127 = urem i64 %126, %117
  %128 = icmp eq i64 %127, 0
  br i1 %128, label %129, label %119

129:                                              ; preds = %123
  %130 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %112, ptr noundef %130) #84
  br label %119

131:                                              ; preds = %119
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok337:                                            ; preds = %119
  %132 = ptrtoint ptr %121 to i64
  store i64 66, ptr %121, align 1
  %v344 = getelementptr i8, ptr %121, i64 8
  store i64 ptrtoint (ptr @ref.17 to i64), ptr %v344, align 1
  %v349 = getelementptr i8, ptr %121, i64 16
  store i64 %111, ptr %v349, align 1
  store i64 %132, ptr %v306, align 1
  %v355 = load i64, ptr %v3, align 8
  %v356.not = icmp eq i64 %v355, 0
  br i1 %v356.not, label %trap357, label %ok358

trap357:                                          ; preds = %ok337
  call fastcc void @native_trap()
  unreachable

ok358:                                            ; preds = %ok337
  %v359 = inttoptr i64 %v355 to ptr
  %v360 = getelementptr i8, ptr %v359, i64 8
  store i32 1, ptr %v360, align 1
  %v361 = load i64, ptr %v3, align 8
  %v362.not = icmp eq i64 %v361, 0
  br i1 %v362.not, label %trap363, label %ok364

trap363:                                          ; preds = %ok358
  call fastcc void @native_trap()
  unreachable

ok364:                                            ; preds = %ok358
  %v365 = inttoptr i64 %v361 to ptr
  %v366 = getelementptr i8, ptr %v365, i64 8
  %v367 = load i32, ptr %v366, align 1
  %v368 = icmp eq i32 %v367, 0
  br i1 %v368, label %then372, label %ok377

then372:                                          ; preds = %ok364
  call fastcc void @native_trap()
  unreachable

ok377:                                            ; preds = %ok364
  %v379 = getelementptr i8, ptr %v365, i64 16
  %v380 = load i64, ptr %v379, align 1
  %v381.not = icmp eq i64 %v380, 0
  br i1 %v381.not, label %trap382, label %ok383

trap382:                                          ; preds = %ok377
  call fastcc void @native_trap()
  unreachable

ok383:                                            ; preds = %ok377
  store i64 %v380, ptr %v4, align 8
  %v387 = inttoptr i64 %v380 to ptr
  %v395 = getelementptr i8, ptr %v387, i64 8
  %v396 = load i64, ptr %v395, align 1
  %v397.not = icmp eq i64 %v396, 0
  br i1 %v397.not, label %trap398, label %ok399

trap398:                                          ; preds = %ok383
  call fastcc void @native_trap()
  unreachable

ok399:                                            ; preds = %ok383
  %v388 = getelementptr i8, ptr %v387, i64 16
  %v389 = load i64, ptr %v388, align 1
  %v400 = inttoptr i64 %v396 to ptr
  %v401 = getelementptr i8, ptr %v400, i64 8
  %v402 = load ptr, ptr %v401, align 1
  store i64 %v389, ptr %v182, align 8
  store i64 9, ptr %1, align 8
  %v405 = call tailcc i32 %v402(i64 %v389, i64 0)
  %v406.b = load i1, ptr @g.18, align 1
  br i1 %v406.b, label %block409, label %then411

then411:                                          ; preds = %ok399
  call fastcc void @native_trap()
  unreachable

block409:                                         ; preds = %ok399
  %v413 = load i64, ptr @g.17, align 8
  %v414.not = icmp eq i64 %v413, 0
  br i1 %v414.not, label %trap415, label %native_roots_leave.exit

trap415:                                          ; preds = %block409
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit:                          ; preds = %block409
  store i64 8, ptr %1, align 8
  call fastcc void @write_character(i32 10)
  %v418.b = load i1, ptr @g.22, align 1
  br i1 %v418.b, label %block421, label %then423

then423:                                          ; preds = %native_roots_leave.exit
  call fastcc void @native_trap()
  unreachable

block421:                                         ; preds = %native_roots_leave.exit
  %v425 = load i64, ptr @g.21, align 8
  %v426.not = icmp eq i64 %v425, 0
  br i1 %v426.not, label %trap427, label %ok441

trap427:                                          ; preds = %block421
  call fastcc void @native_trap()
  unreachable

ok441:                                            ; preds = %block421
  %v442 = inttoptr i64 %v425 to ptr
  %v443 = getelementptr i8, ptr %v442, i64 8
  %v444 = load i64, ptr %v443, align 1
  store i64 %v444, ptr %v182, align 8
  store i64 %v425, ptr %v183, align 8
  store i64 10, ptr %1, align 8
  %133 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %134 = icmp eq ptr %133, null
  br i1 %134, label %135, label %136

135:                                              ; preds = %ok441
  call fastcc void @native_trap() #111
  unreachable

136:                                              ; preds = %ok441
  %137 = getelementptr inbounds nuw i8, ptr %133, i64 376
  %138 = load i64, ptr %137, align 8, !noundef !39
  %139 = icmp eq i64 %138, 0
  br i1 %139, label %140, label %144

140:                                              ; preds = %150, %144, %136
  %141 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %142 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %133, i64 noundef 16, ptr noundef %141) #84
  %143 = icmp eq ptr %142, null
  br i1 %143, label %152, label %ok451

144:                                              ; preds = %136
  %145 = getelementptr inbounds nuw i8, ptr %133, i64 368
  %146 = load i64, ptr %145, align 8, !noundef !39
  %147 = add i64 %146, 1
  store i64 %147, ptr %145, align 8
  %148 = urem i64 %147, %138
  %149 = icmp eq i64 %148, 0
  br i1 %149, label %150, label %140

150:                                              ; preds = %144
  %151 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %133, ptr noundef %151) #84
  br label %140

152:                                              ; preds = %140
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok451:                                            ; preds = %140
  %153 = ptrtoint ptr %142 to i64
  store i64 110, ptr %142, align 1
  %v458 = getelementptr i8, ptr %142, i64 8
  store i64 %v444, ptr %v458, align 1
  store i64 %153, ptr %v443, align 1
  %.pre8 = load i64, ptr %0, align 8
  %154 = icmp eq i64 %.pre8, 0
  br i1 %154, label %native_roots_leave.exit7, label %.critedge

.critedge:                                        ; preds = %ok451, %ok143
  %155 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %155, ptr @native_roots.0, align 8
  %156 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %157 = add i64 %156, -1
  store i64 %157, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit7

native_roots_leave.exit7:                         ; preds = %.critedge, %ok451
  ret void
}

define internal tailcc noundef i32 @f.10(i64 %arg0, i64 %arg1) #102 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [15 x i64] }, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v7 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v8 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v9 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v10 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v11 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v12 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v13 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  %v14 = getelementptr inbounds nuw i8, ptr %roots, i64 96
  %v121 = getelementptr inbounds nuw i8, ptr %roots, i64 104
  %v122 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %v173 = getelementptr inbounds nuw i8, ptr %roots, i64 112
  %v174 = getelementptr inbounds nuw i8, ptr %roots, i64 120
  %v181 = getelementptr inbounds nuw i8, ptr %roots, i64 128
  %v199 = getelementptr inbounds nuw i8, ptr %roots, i64 136
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 15, ptr %0, align 8
  store i64 0, ptr %v122, align 8
  %1 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %1, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %2 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %3 = add i64 %2, 1
  store i64 %3, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %4 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %5 = call noundef i64 @llvm.umax.i64(i64 %3, i64 %4)
  store i64 %5, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %arg0, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(72) %v6, i8 0, i64 72, i1 false)
  %6 = icmp ne i64 %arg0, 0
  %7 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %7, 0
  %or.cond = and i1 %6, %.not.i
  br i1 %or.cond, label %8, label %trap20

8:                                                ; preds = %entry
  %9 = inttoptr i64 %arg0 to ptr
  %10 = load i64, ptr %9, align 8, !noundef !39
  %11 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %12 = icmp eq ptr %11, null
  br i1 %12, label %25, label %13

13:                                               ; preds = %8
  switch i64 %10, label %14 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

14:                                               ; preds = %13
  %15 = getelementptr inbounds nuw i8, ptr %11, i64 360
  %16 = load i64, ptr %15, align 8, !noundef !39
  %17 = lshr i64 %10, 2
  %18 = add nsw i64 %17, -1
  %19 = icmp ult i64 %18, %16
  br i1 %19, label %20, label %.loopexit25

20:                                               ; preds = %14
  %21 = getelementptr inbounds nuw i8, ptr %11, i64 352
  %22 = load ptr, ptr %21, align 8, !nonnull !39, !noundef !39
  %23 = getelementptr inbounds nuw i64, ptr %22, i64 %18
  %24 = load i64, ptr %23, align 8, !noundef !39
  switch i64 %24, label %.preheader24 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

25:                                               ; preds = %8
  call fastcc void @native_trap() #111
  unreachable

.preheader24:                                     ; preds = %30, %20
  %26 = phi i64 [ %32, %30 ], [ %24, %20 ]
  %27 = lshr i64 %26, 2
  %28 = add nsw i64 %27, -1
  %29 = icmp ult i64 %28, %16
  br i1 %29, label %30, label %.loopexit25

.loopexit25:                                      ; preds = %.preheader24, %14
  call fastcc void @native_trap() #111
  unreachable

30:                                               ; preds = %.preheader24
  %31 = getelementptr inbounds nuw i64, ptr %22, i64 %28
  %32 = load i64, ptr %31, align 8, !noundef !39
  switch i64 %32, label %.preheader24 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %30, %30, %20, %20, %13, %13
  %.in191 = phi i64 [ %10, %13 ], [ %24, %20 ], [ %24, %20 ], [ %10, %13 ], [ %32, %30 ], [ %32, %30 ]
  %33 = icmp eq i64 %.in191, 30
  br i1 %33, label %ok24, label %trap20

trap20:                                           ; preds = %native_ref_test.exit12, %ok481, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok24:                                             ; preds = %native_ref_test.exit12, %native_ref_test.exit
  %34 = phi i64 [ %239, %native_ref_test.exit12 ], [ %3, %native_ref_test.exit ]
  %35 = phi ptr [ %240, %native_ref_test.exit12 ], [ %1, %native_ref_test.exit ]
  %36 = phi ptr [ %248, %native_ref_test.exit12 ], [ %11, %native_ref_test.exit ]
  %37 = phi i64 [ %247, %native_ref_test.exit12 ], [ %10, %native_ref_test.exit ]
  %arg1.tr96 = phi i64 [ %v486, %native_ref_test.exit12 ], [ %arg1, %native_ref_test.exit ]
  %v36 = phi i64 [ %v484, %native_ref_test.exit12 ], [ %arg0, %native_ref_test.exit ]
  %v25 = inttoptr i64 %v36 to ptr
  %v26 = getelementptr i8, ptr %v25, i64 8
  %v27 = load i64, ptr %v26, align 1
  %v29 = icmp eq i64 %v27, %arg1.tr96
  br i1 %v29, label %then34, label %else33

then34:                                           ; preds = %ok24
  %.lcssa255 = phi i64 [ %34, %ok24 ]
  %.lcssa199 = phi ptr [ %35, %ok24 ]
  store ptr %.lcssa199, ptr @native_roots.0, align 8
  %38 = add i64 %.lcssa255, -1
  store i64 %38, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  ret i32 0

else33:                                           ; preds = %ok24
  %39 = and i64 %v36, 1
  %.not.i1 = icmp eq i64 %39, 0
  br i1 %.not.i1, label %40, label %trap39

40:                                               ; preds = %else33
  switch i64 %37, label %41 [
    i64 30, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

41:                                               ; preds = %40
  %42 = getelementptr inbounds nuw i8, ptr %36, i64 360
  %43 = load i64, ptr %42, align 8, !noundef !39
  %44 = lshr i64 %37, 2
  %45 = add nsw i64 %44, -1
  %46 = icmp ult i64 %45, %43
  br i1 %46, label %47, label %.loopexit20

47:                                               ; preds = %41
  %48 = getelementptr inbounds nuw i8, ptr %36, i64 352
  %49 = load ptr, ptr %48, align 8, !nonnull !39, !noundef !39
  %50 = getelementptr inbounds nuw i64, ptr %49, i64 %45
  %51 = load i64, ptr %50, align 8, !noundef !39
  switch i64 %51, label %.preheader19 [
    i64 30, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader19:                                     ; preds = %56, %47
  %52 = phi i64 [ %58, %56 ], [ %51, %47 ]
  %53 = lshr i64 %52, 2
  %54 = add nsw i64 %53, -1
  %55 = icmp ult i64 %54, %43
  br i1 %55, label %56, label %.loopexit20

.loopexit20:                                      ; preds = %.preheader19, %41
  call fastcc void @native_trap() #111
  unreachable

56:                                               ; preds = %.preheader19
  %57 = getelementptr inbounds nuw i64, ptr %49, i64 %54
  %58 = load i64, ptr %57, align 8, !noundef !39
  switch i64 %58, label %.preheader19 [
    i64 30, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

native_ref_test.exit2:                            ; preds = %56, %56, %47, %47, %40, %40
  %.in192 = phi i64 [ %37, %40 ], [ %51, %47 ], [ %51, %47 ], [ %37, %40 ], [ %58, %56 ], [ %58, %56 ]
  %59 = icmp eq i64 %.in192, 30
  br i1 %59, label %ok40, label %trap39

trap39:                                           ; preds = %native_ref_test.exit2, %else33
  call fastcc void @native_trap()
  unreachable

ok40:                                             ; preds = %native_ref_test.exit2
  store i64 %v36, ptr %v6, align 8
  %v45 = getelementptr i8, ptr %v25, i64 16
  %v46 = load i64, ptr %v45, align 1
  %v52 = getelementptr i8, ptr %v25, i64 24
  %v53 = load i64, ptr %v52, align 1
  %v54.not = icmp eq i64 %v53, 0
  br i1 %v54.not, label %trap55, label %ok56

trap55:                                           ; preds = %ok40
  call fastcc void @native_trap()
  unreachable

ok56:                                             ; preds = %ok40
  %v57 = inttoptr i64 %v53 to ptr
  %v58 = getelementptr i8, ptr %v57, i64 8
  %v59 = load i32, ptr %v58, align 1
  %v60 = icmp eq i32 %v59, 0
  br i1 %v60, label %then64, label %ok75

then64:                                           ; preds = %ok56
  call fastcc void @native_trap()
  unreachable

ok75:                                             ; preds = %ok56
  %v77 = getelementptr i8, ptr %v57, i64 16
  %v78 = load i64, ptr %v77, align 1
  %v79.not = icmp eq i64 %v78, 0
  br i1 %v79.not, label %trap80, label %ok81

trap80:                                           ; preds = %ok75
  call fastcc void @native_trap()
  unreachable

ok81:                                             ; preds = %ok75
  %v82 = inttoptr i64 %v78 to ptr
  %v83 = getelementptr i8, ptr %v82, i64 16
  %v84 = load i64, ptr %v83, align 1
  %60 = icmp ne i64 %v84, 0
  %61 = and i64 %v84, 1
  %.not.i3 = icmp eq i64 %61, 0
  %or.cond157 = and i1 %60, %.not.i3
  br i1 %or.cond157, label %62, label %trap87

62:                                               ; preds = %ok81
  %63 = inttoptr i64 %v84 to ptr
  %64 = load i64, ptr %63, align 8, !noundef !39
  switch i64 %64, label %65 [
    i64 74, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

65:                                               ; preds = %62
  %66 = getelementptr inbounds nuw i8, ptr %36, i64 360
  %67 = load i64, ptr %66, align 8, !noundef !39
  %68 = lshr i64 %64, 2
  %69 = add nsw i64 %68, -1
  %70 = icmp ult i64 %69, %67
  br i1 %70, label %71, label %.loopexit18

71:                                               ; preds = %65
  %72 = getelementptr inbounds nuw i8, ptr %36, i64 352
  %73 = load ptr, ptr %72, align 8, !nonnull !39, !noundef !39
  %74 = getelementptr inbounds nuw i64, ptr %73, i64 %69
  %75 = load i64, ptr %74, align 8, !noundef !39
  switch i64 %75, label %.preheader17 [
    i64 74, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

.preheader17:                                     ; preds = %80, %71
  %76 = phi i64 [ %82, %80 ], [ %75, %71 ]
  %77 = lshr i64 %76, 2
  %78 = add nsw i64 %77, -1
  %79 = icmp ult i64 %78, %67
  br i1 %79, label %80, label %.loopexit18

.loopexit18:                                      ; preds = %.preheader17, %65
  call fastcc void @native_trap() #111
  unreachable

80:                                               ; preds = %.preheader17
  %81 = getelementptr inbounds nuw i64, ptr %73, i64 %78
  %82 = load i64, ptr %81, align 8, !noundef !39
  switch i64 %82, label %.preheader17 [
    i64 74, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

native_ref_test.exit4:                            ; preds = %80, %80, %71, %71, %62, %62
  %.in193 = phi i64 [ %64, %62 ], [ %75, %71 ], [ %75, %71 ], [ %64, %62 ], [ %82, %80 ], [ %82, %80 ]
  %83 = icmp eq i64 %.in193, 74
  br i1 %83, label %ok88, label %trap87

trap87:                                           ; preds = %native_ref_test.exit4, %ok81
  call fastcc void @native_trap()
  unreachable

ok88:                                             ; preds = %native_ref_test.exit4
  store i64 %v84, ptr %v11, align 8
  %v93 = getelementptr i8, ptr %63, i64 8
  %v94 = load i64, ptr %v93, align 1
  %v95.not = icmp eq i64 %v94, 0
  br i1 %v95.not, label %trap96, label %ok97

trap96:                                           ; preds = %ok88
  call fastcc void @native_trap()
  unreachable

ok97:                                             ; preds = %ok88
  %v98 = inttoptr i64 %v94 to ptr
  %v99 = getelementptr i8, ptr %v98, i64 8
  %v100 = load i64, ptr %v99, align 1
  store i64 %v100, ptr %v12, align 8
  %v101.not = icmp eq i64 %v100, 0
  br i1 %v101.not, label %trap102, label %ok103

trap102:                                          ; preds = %ok97
  call fastcc void @native_trap()
  unreachable

ok103:                                            ; preds = %ok97
  %v104 = inttoptr i64 %v100 to ptr
  %v113 = getelementptr i8, ptr %v104, i64 8
  %v114 = load i64, ptr %v113, align 1
  %v115.not = icmp eq i64 %v114, 0
  br i1 %v115.not, label %trap116, label %ok117

trap116:                                          ; preds = %ok103
  call fastcc void @native_trap()
  unreachable

ok117:                                            ; preds = %ok103
  %v105 = getelementptr i8, ptr %v104, i64 16
  %v106 = load i64, ptr %v105, align 1
  %v118 = inttoptr i64 %v114 to ptr
  %v119 = getelementptr i8, ptr %v118, i64 8
  %v120 = load ptr, ptr %v119, align 1
  store i64 %v106, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %v123 = call tailcc i64 %v120(i64 %v106, i64 %v46)
  %v124.b = load i1, ptr @g.4, align 1
  br i1 %v124.b, label %block127, label %then129

then129:                                          ; preds = %ok117
  call fastcc void @native_trap()
  unreachable

block127:                                         ; preds = %ok117
  %v131 = load i64, ptr @g.3, align 8
  %v132.not = icmp eq i64 %v131, 0
  br i1 %v132.not, label %trap133, label %ok134

trap133:                                          ; preds = %block127
  call fastcc void @native_trap()
  unreachable

ok134:                                            ; preds = %block127
  %v139 = icmp ugt i64 %v123, 4294967295
  br i1 %v139, label %then143, label %block141

then143:                                          ; preds = %ok134
  call fastcc void @native_trap()
  unreachable

block141:                                         ; preds = %ok134
  store i64 10, ptr %v122, align 8
  %84 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %85 = icmp eq ptr %84, null
  br i1 %85, label %86, label %87

86:                                               ; preds = %block141
  call fastcc void @native_trap() #111
  unreachable

87:                                               ; preds = %block141
  %88 = getelementptr inbounds nuw i8, ptr %84, i64 376
  %89 = load i64, ptr %88, align 8, !noundef !39
  %90 = icmp eq i64 %89, 0
  br i1 %90, label %91, label %95

91:                                               ; preds = %101, %95, %87
  %92 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %93 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %84, i64 noundef 24, ptr noundef %92) #84
  %94 = icmp eq ptr %93, null
  br i1 %94, label %103, label %ok149

95:                                               ; preds = %87
  %96 = getelementptr inbounds nuw i8, ptr %84, i64 368
  %97 = load i64, ptr %96, align 8, !noundef !39
  %98 = add i64 %97, 1
  store i64 %98, ptr %96, align 8
  %99 = urem i64 %98, %89
  %100 = icmp eq i64 %99, 0
  br i1 %100, label %101, label %91

101:                                              ; preds = %95
  %102 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %84, ptr noundef %102) #84
  br label %91

103:                                              ; preds = %91
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok149:                                            ; preds = %91
  %104 = ptrtoint ptr %93 to i64
  store i64 102, ptr %93, align 1
  %v156 = getelementptr i8, ptr %93, i64 8
  store i32 0, ptr %v156, align 1
  %v161 = getelementptr i8, ptr %93, i64 16
  store i64 0, ptr %v161, align 1
  store i64 %104, ptr %v7, align 8
  %v162 = load i64, ptr %v11, align 8
  %v163.not = icmp eq i64 %v162, 0
  br i1 %v163.not, label %trap164, label %ok165

trap164:                                          ; preds = %ok149
  call fastcc void @native_trap()
  unreachable

ok165:                                            ; preds = %ok149
  %v166 = inttoptr i64 %v162 to ptr
  %v167 = getelementptr i8, ptr %v166, i64 8
  %v168 = load i64, ptr %v167, align 1
  %v171 = trunc nuw i64 %v123 to i32
  store i64 %v168, ptr %v121, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v173, align 8
  store i64 %104, ptr %v174, align 8
  store i64 13, ptr %v122, align 8
  %v177 = call fastcc i64 @native_array_new(i32 %v171)
  store i64 %v177, ptr %v121, align 8
  store i64 %v168, ptr %v173, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v174, align 8
  store i64 %104, ptr %v181, align 8
  store i64 14, ptr %v122, align 8
  %105 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %106 = icmp eq ptr %105, null
  br i1 %106, label %107, label %108

107:                                              ; preds = %ok165
  call fastcc void @native_trap() #111
  unreachable

108:                                              ; preds = %ok165
  %109 = getelementptr inbounds nuw i8, ptr %105, i64 376
  %110 = load i64, ptr %109, align 8, !noundef !39
  %111 = icmp eq i64 %110, 0
  br i1 %111, label %112, label %116

112:                                              ; preds = %122, %116, %108
  %113 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %114 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %105, i64 noundef 16, ptr noundef %113) #84
  %115 = icmp eq ptr %114, null
  br i1 %115, label %124, label %ok186

116:                                              ; preds = %108
  %117 = getelementptr inbounds nuw i8, ptr %105, i64 368
  %118 = load i64, ptr %117, align 8, !noundef !39
  %119 = add i64 %118, 1
  store i64 %119, ptr %117, align 8
  %120 = urem i64 %119, %110
  %121 = icmp eq i64 %120, 0
  br i1 %121, label %122, label %112

122:                                              ; preds = %116
  %123 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %105, ptr noundef %123) #84
  br label %112

124:                                              ; preds = %112
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok186:                                            ; preds = %112
  %125 = ptrtoint ptr %114 to i64
  store i64 130, ptr %114, align 1
  %v193 = getelementptr i8, ptr %114, i64 8
  store i64 %v177, ptr %v193, align 1
  %v194 = load i64, ptr %v7, align 8
  store i64 %v194, ptr %v121, align 8
  store i64 %125, ptr %v173, align 8
  store i64 %v168, ptr %v174, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v181, align 8
  store i64 %104, ptr %v199, align 8
  store i64 15, ptr %v122, align 8
  %126 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %127 = icmp eq ptr %126, null
  br i1 %127, label %128, label %129

128:                                              ; preds = %ok186
  call fastcc void @native_trap() #111
  unreachable

129:                                              ; preds = %ok186
  %130 = getelementptr inbounds nuw i8, ptr %126, i64 376
  %131 = load i64, ptr %130, align 8, !noundef !39
  %132 = icmp eq i64 %131, 0
  br i1 %132, label %133, label %137

133:                                              ; preds = %143, %137, %129
  %134 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %135 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %126, i64 noundef 40, ptr noundef %134) #84
  %136 = icmp eq ptr %135, null
  br i1 %136, label %145, label %ok204

137:                                              ; preds = %129
  %138 = getelementptr inbounds nuw i8, ptr %126, i64 368
  %139 = load i64, ptr %138, align 8, !noundef !39
  %140 = add i64 %139, 1
  store i64 %140, ptr %138, align 8
  %141 = urem i64 %140, %131
  %142 = icmp eq i64 %141, 0
  br i1 %142, label %143, label %133

143:                                              ; preds = %137
  %144 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %126, ptr noundef %144) #84
  br label %133

145:                                              ; preds = %133
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok204:                                            ; preds = %133
  %146 = ptrtoint ptr %135 to i64
  store i64 42, ptr %135, align 1
  %v211 = getelementptr i8, ptr %135, i64 8
  store i64 %v168, ptr %v211, align 1
  %v216 = getelementptr i8, ptr %135, i64 16
  store i64 %v123, ptr %v216, align 1
  %v221 = getelementptr i8, ptr %135, i64 24
  store i64 %125, ptr %v221, align 1
  %v226 = getelementptr i8, ptr %135, i64 32
  store i64 %v194, ptr %v226, align 1
  store i64 %146, ptr %v121, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v173, align 8
  store i64 %104, ptr %v174, align 8
  store i64 13, ptr %v122, align 8
  %147 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %148 = icmp eq ptr %147, null
  br i1 %148, label %149, label %150

149:                                              ; preds = %ok204
  call fastcc void @native_trap() #111
  unreachable

150:                                              ; preds = %ok204
  %151 = getelementptr inbounds nuw i8, ptr %147, i64 376
  %152 = load i64, ptr %151, align 8, !noundef !39
  %153 = icmp eq i64 %152, 0
  br i1 %153, label %154, label %158

154:                                              ; preds = %164, %158, %150
  %155 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %156 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %147, i64 noundef 24, ptr noundef %155) #84
  %157 = icmp eq ptr %156, null
  br i1 %157, label %166, label %ok234

158:                                              ; preds = %150
  %159 = getelementptr inbounds nuw i8, ptr %147, i64 368
  %160 = load i64, ptr %159, align 8, !noundef !39
  %161 = add i64 %160, 1
  store i64 %161, ptr %159, align 8
  %162 = urem i64 %161, %152
  %163 = icmp eq i64 %162, 0
  br i1 %163, label %164, label %154

164:                                              ; preds = %158
  %165 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %147, ptr noundef %165) #84
  br label %154

166:                                              ; preds = %154
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok234:                                            ; preds = %154
  %167 = ptrtoint ptr %156 to i64
  store i64 194, ptr %156, align 1
  %v241 = getelementptr i8, ptr %156, i64 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v241, align 1
  %v246 = getelementptr i8, ptr %156, i64 16
  store i64 %146, ptr %v246, align 1
  store i64 %167, ptr %v161, align 1
  %v252 = load i64, ptr %v7, align 8
  %v253.not = icmp eq i64 %v252, 0
  br i1 %v253.not, label %trap254, label %ok255

trap254:                                          ; preds = %ok234
  call fastcc void @native_trap()
  unreachable

ok255:                                            ; preds = %ok234
  %v256 = inttoptr i64 %v252 to ptr
  %v257 = getelementptr i8, ptr %v256, i64 8
  store i32 1, ptr %v257, align 1
  %v258 = load i64, ptr %v7, align 8
  %v259.not = icmp eq i64 %v258, 0
  br i1 %v259.not, label %trap260, label %ok261

trap260:                                          ; preds = %ok255
  call fastcc void @native_trap()
  unreachable

ok261:                                            ; preds = %ok255
  %v262 = inttoptr i64 %v258 to ptr
  %v263 = getelementptr i8, ptr %v262, i64 8
  %v264 = load i32, ptr %v263, align 1
  %v265 = icmp eq i32 %v264, 0
  br i1 %v265, label %then269, label %ok274

then269:                                          ; preds = %ok261
  call fastcc void @native_trap()
  unreachable

ok274:                                            ; preds = %ok261
  %v276 = getelementptr i8, ptr %v262, i64 16
  %v277 = load i64, ptr %v276, align 1
  %v278.not = icmp eq i64 %v277, 0
  br i1 %v278.not, label %trap279, label %ok280

trap279:                                          ; preds = %ok274
  call fastcc void @native_trap()
  unreachable

ok280:                                            ; preds = %ok274
  store i64 %v277, ptr %v13, align 8
  %v284 = inttoptr i64 %v277 to ptr
  %v292 = getelementptr i8, ptr %v284, i64 8
  %v293 = load i64, ptr %v292, align 1
  %v294.not = icmp eq i64 %v293, 0
  br i1 %v294.not, label %trap295, label %ok296

trap295:                                          ; preds = %ok280
  call fastcc void @native_trap()
  unreachable

ok296:                                            ; preds = %ok280
  %v285 = getelementptr i8, ptr %v284, i64 16
  %v286 = load i64, ptr %v285, align 1
  %v297 = inttoptr i64 %v293 to ptr
  %v298 = getelementptr i8, ptr %v297, i64 8
  %v299 = load ptr, ptr %v298, align 1
  store i64 %v286, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %v302 = call tailcc i64 %v299(i64 %v286, i64 0)
  store i64 %v302, ptr %v9, align 8
  %v303.b = load i1, ptr @g.6, align 1
  br i1 %v303.b, label %block306, label %then308

then308:                                          ; preds = %ok296
  call fastcc void @native_trap()
  unreachable

block306:                                         ; preds = %ok296
  %v310 = load i64, ptr @g.5, align 8
  %v311.not = icmp eq i64 %v310, 0
  br i1 %v311.not, label %trap312, label %ok313

trap312:                                          ; preds = %block306
  call fastcc void @native_trap()
  unreachable

ok313:                                            ; preds = %block306
  %v314.b = load i1, ptr @g.8, align 1
  br i1 %v314.b, label %block317, label %then319

then319:                                          ; preds = %ok313
  call fastcc void @native_trap()
  unreachable

block317:                                         ; preds = %ok313
  %v321 = load i64, ptr @g.7, align 8
  %v322.not = icmp eq i64 %v321, 0
  br i1 %v322.not, label %trap323, label %ok324

trap323:                                          ; preds = %block317
  call fastcc void @native_trap()
  unreachable

ok324:                                            ; preds = %block317
  %v327.not = icmp eq i64 %v302, 0
  br i1 %v327.not, label %trap328, label %ok329

trap328:                                          ; preds = %ok324
  call fastcc void @native_trap()
  unreachable

ok329:                                            ; preds = %ok324
  %v330 = inttoptr i64 %v302 to ptr
  %v331 = getelementptr i8, ptr %v330, i64 8
  %v332 = load i64, ptr %v331, align 1
  %v333.not = icmp eq i64 %v332, 0
  br i1 %v333.not, label %trap334, label %ok335

trap334:                                          ; preds = %ok329
  call fastcc void @native_trap()
  unreachable

ok335:                                            ; preds = %ok329
  %v336 = and i64 %v332, 1
  %v337 = icmp eq i64 %v336, 0
  br i1 %v337, label %ok339, label %trap338

trap338:                                          ; preds = %ok335
  call fastcc void @native_trap()
  unreachable

ok339:                                            ; preds = %ok335
  %v340 = inttoptr i64 %v332 to ptr
  %v341 = getelementptr i8, ptr %v340, i64 8
  %v342 = load i64, ptr %v341, align 1
  %v344 = and i64 %v342, 4294967295
  store i64 %v302, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %v347 = call tailcc i64 @f.5(i64 %v302, i64 %v344)
  store i64 %v347, ptr %v8, align 8
  store i64 %v347, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %168 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %169 = icmp eq ptr %168, null
  br i1 %169, label %170, label %171

170:                                              ; preds = %ok339
  call fastcc void @native_trap() #111
  unreachable

171:                                              ; preds = %ok339
  %172 = getelementptr inbounds nuw i8, ptr %168, i64 376
  %173 = load i64, ptr %172, align 8, !noundef !39
  %174 = icmp eq i64 %173, 0
  br i1 %174, label %175, label %179

175:                                              ; preds = %185, %179, %171
  %176 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %177 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %168, i64 noundef 16, ptr noundef %176) #84
  %178 = icmp eq ptr %177, null
  br i1 %178, label %187, label %ok353

179:                                              ; preds = %171
  %180 = getelementptr inbounds nuw i8, ptr %168, i64 368
  %181 = load i64, ptr %180, align 8, !noundef !39
  %182 = add i64 %181, 1
  store i64 %182, ptr %180, align 8
  %183 = urem i64 %182, %173
  %184 = icmp eq i64 %183, 0
  br i1 %184, label %185, label %175

185:                                              ; preds = %179
  %186 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %168, ptr noundef %186) #84
  br label %175

187:                                              ; preds = %175
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok353:                                            ; preds = %175
  %188 = ptrtoint ptr %177 to i64
  store i64 34, ptr %177, align 1
  %v360 = getelementptr i8, ptr %177, i64 8
  store i64 %v347, ptr %v360, align 1
  %v363 = load i64, ptr %v8, align 8
  %v364.not = icmp eq i64 %v363, 0
  br i1 %v364.not, label %trap365, label %block374

trap365:                                          ; preds = %ok353
  call fastcc void @native_trap()
  unreachable

block374:                                         ; preds = %ok353
  %v367 = inttoptr i64 %v363 to ptr
  %v368 = getelementptr i8, ptr %v367, i64 8
  %v369 = load i32, ptr %v368, align 1
  store i64 %188, ptr %v121, align 8
  store i64 %v363, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  %v382 = call tailcc i32 @f.4(i64 %v363, i32 0)
  %v383 = load i64, ptr %v8, align 8
  store i64 %188, ptr %v121, align 8
  store i64 %v383, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  %v389 = call tailcc i32 @f.4(i64 %v383, i32 %v369)
  %v391 = sub i32 %v389, %v382
  store i64 %188, ptr %v121, align 8
  store i64 11, ptr %v122, align 8
  %v395 = call fastcc i64 @native_array_new(i32 %v391)
  store i64 %v395, ptr %v14, align 8
  %v396 = load i64, ptr %v8, align 8
  %v397.not = icmp eq i64 %v396, 0
  br i1 %v397.not, label %trap398, label %ok399

trap398:                                          ; preds = %block374
  call fastcc void @native_trap()
  unreachable

ok399:                                            ; preds = %block374
  %v400 = inttoptr i64 %v396 to ptr
  %v401 = getelementptr i8, ptr %v400, i64 24
  %v402 = load i64, ptr %v401, align 1
  %189 = and i64 %v395, 1
  %190 = icmp eq i64 %189, 0
  br i1 %190, label %192, label %191

191:                                              ; preds = %ok399
  call fastcc void @native_trap() #111
  unreachable

192:                                              ; preds = %ok399
  %193 = inttoptr i64 %v395 to ptr
  %194 = icmp ne i64 %v402, 0
  %195 = and i64 %v402, 1
  %196 = icmp eq i64 %195, 0
  %197 = and i1 %194, %196
  br i1 %197, label %199, label %198

198:                                              ; preds = %192
  call fastcc void @native_trap() #111
  unreachable

199:                                              ; preds = %192
  %200 = inttoptr i64 %v402 to ptr
  %201 = zext i32 %v391 to i64
  %202 = getelementptr inbounds nuw i8, ptr %193, i64 8
  %203 = load i64, ptr %202, align 8, !noundef !39
  %204 = icmp ult i64 %203, %201
  br i1 %204, label %211, label %205

205:                                              ; preds = %199
  %206 = zext i32 %v382 to i64
  %207 = add nuw nsw i64 %201, %206
  %208 = getelementptr inbounds nuw i8, ptr %200, i64 8
  %209 = load i64, ptr %208, align 8, !noundef !39
  %210 = icmp ugt i64 %207, %209
  br i1 %210, label %211, label %native_array_copy.exit

211:                                              ; preds = %205, %199
  call fastcc void @native_trap() #111
  unreachable

native_array_copy.exit:                           ; preds = %205
  %212 = getelementptr inbounds nuw i8, ptr %200, i64 16
  %213 = getelementptr inbounds nuw i8, ptr %212, i64 %206
  %214 = getelementptr inbounds nuw i8, ptr %193, i64 16
  call void @llvm.memmove.p0.p0.i64(ptr nonnull align 1 %214, ptr nonnull align 1 %213, i64 %201, i1 false)
  %v405 = load i64, ptr %v14, align 8
  store i64 %v405, ptr %v121, align 8
  store i64 %188, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  %215 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %216 = icmp eq ptr %215, null
  br i1 %216, label %217, label %218

217:                                              ; preds = %native_array_copy.exit
  call fastcc void @native_trap() #111
  unreachable

218:                                              ; preds = %native_array_copy.exit
  %219 = getelementptr inbounds nuw i8, ptr %215, i64 376
  %220 = load i64, ptr %219, align 8, !noundef !39
  %221 = icmp eq i64 %220, 0
  br i1 %221, label %222, label %226

222:                                              ; preds = %232, %226, %218
  %223 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %224 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %215, i64 noundef 16, ptr noundef %223) #84
  %225 = icmp eq ptr %224, null
  br i1 %225, label %234, label %ok412

226:                                              ; preds = %218
  %227 = getelementptr inbounds nuw i8, ptr %215, i64 368
  %228 = load i64, ptr %227, align 8, !noundef !39
  %229 = add i64 %228, 1
  store i64 %229, ptr %227, align 8
  %230 = urem i64 %229, %220
  %231 = icmp eq i64 %230, 0
  br i1 %231, label %232, label %222

232:                                              ; preds = %226
  %233 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %215, ptr noundef %233) #84
  br label %222

234:                                              ; preds = %222
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok412:                                            ; preds = %222
  %235 = ptrtoint ptr %224 to i64
  store i64 130, ptr %224, align 1
  %v419 = getelementptr i8, ptr %224, i64 8
  store i64 %v405, ptr %v419, align 1
  store i64 %235, ptr %v10, align 8
  %v426 = load i64, ptr %v419, align 1
  %v427.not = icmp eq i64 %v426, 0
  br i1 %v427.not, label %trap428, label %ok429

trap428:                                          ; preds = %ok412
  call fastcc void @native_trap()
  unreachable

ok429:                                            ; preds = %ok412
  %v430 = and i64 %v426, 1
  %v431 = icmp eq i64 %v430, 0
  br i1 %v431, label %ok433, label %trap432

trap432:                                          ; preds = %ok429
  call fastcc void @native_trap()
  unreachable

ok433:                                            ; preds = %ok429
  %v434 = inttoptr i64 %v426 to ptr
  %v435 = getelementptr i8, ptr %v434, i64 8
  %v436 = load i64, ptr %v435, align 1
  %v438 = and i64 %v436, 4294967295
  store i64 %188, ptr %v121, align 8
  store i64 %235, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  %v442 = call tailcc i64 @f.5(i64 %235, i64 %v438)
  store i64 %188, ptr %v121, align 8
  store i64 %v442, ptr %v173, align 8
  store i64 12, ptr %v122, align 8
  call tailcc void @f.11(i64 %188, i64 %v442)
  %v447 = load i64, ptr %v6, align 8
  %v448.not = icmp eq i64 %v447, 0
  br i1 %v448.not, label %trap449, label %ok450

trap449:                                          ; preds = %ok433
  call fastcc void @native_trap()
  unreachable

ok450:                                            ; preds = %ok433
  %v451 = inttoptr i64 %v447 to ptr
  %v452 = getelementptr i8, ptr %v451, i64 32
  %v453 = load i64, ptr %v452, align 1
  %v454.not = icmp eq i64 %v453, 0
  br i1 %v454.not, label %trap455, label %ok456

trap455:                                          ; preds = %ok450
  call fastcc void @native_trap()
  unreachable

ok456:                                            ; preds = %ok450
  %v457 = inttoptr i64 %v453 to ptr
  %v458 = getelementptr i8, ptr %v457, i64 8
  %v459 = load i32, ptr %v458, align 1
  %v460 = icmp eq i32 %v459, 0
  br i1 %v460, label %then464, label %ok475

then464:                                          ; preds = %ok456
  call fastcc void @native_trap()
  unreachable

ok475:                                            ; preds = %ok456
  %v477 = getelementptr i8, ptr %v457, i64 16
  %v478 = load i64, ptr %v477, align 1
  %v479.not = icmp eq i64 %v478, 0
  br i1 %v479.not, label %trap480, label %ok481

trap480:                                          ; preds = %ok475
  call fastcc void @native_trap()
  unreachable

ok481:                                            ; preds = %ok475
  %v482 = inttoptr i64 %v478 to ptr
  %v483 = getelementptr i8, ptr %v482, i64 16
  %v484 = load i64, ptr %v483, align 1
  %v486 = add i64 %arg1.tr96, 1
  %236 = load i64, ptr %0, align 8, !noundef !39
  %237 = icmp eq i64 %236, 0
  %.pre29 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %238 = zext i1 %237 to i64
  %239 = add i64 %.pre29, %238
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %240 = select i1 %237, ptr %native_roots.0.val, ptr %roots.val
  store i64 15, ptr %0, align 8
  store i64 0, ptr %v122, align 8
  store ptr %240, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %239, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %241 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %242 = call noundef i64 @llvm.umax.i64(i64 %239, i64 %241)
  store i64 %242, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v484, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(72) %v6, i8 0, i64 72, i1 false)
  %243 = icmp ne i64 %v484, 0
  %244 = and i64 %v484, 1
  %.not.i11 = icmp eq i64 %244, 0
  %or.cond158 = and i1 %243, %.not.i11
  br i1 %or.cond158, label %245, label %trap20

245:                                              ; preds = %ok481
  %246 = inttoptr i64 %v484 to ptr
  %247 = load i64, ptr %246, align 8, !noundef !39
  %248 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %249 = icmp eq ptr %248, null
  br i1 %249, label %262, label %250

250:                                              ; preds = %245
  switch i64 %247, label %251 [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

251:                                              ; preds = %250
  %252 = getelementptr inbounds nuw i8, ptr %248, i64 360
  %253 = load i64, ptr %252, align 8, !noundef !39
  %254 = lshr i64 %247, 2
  %255 = add nsw i64 %254, -1
  %256 = icmp ult i64 %255, %253
  br i1 %256, label %257, label %.loopexit

257:                                              ; preds = %251
  %258 = getelementptr inbounds nuw i8, ptr %248, i64 352
  %259 = load ptr, ptr %258, align 8, !nonnull !39, !noundef !39
  %260 = getelementptr inbounds nuw i64, ptr %259, i64 %255
  %261 = load i64, ptr %260, align 8, !noundef !39
  switch i64 %261, label %.preheader [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

262:                                              ; preds = %245
  call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %267, %257
  %263 = phi i64 [ %269, %267 ], [ %261, %257 ]
  %264 = lshr i64 %263, 2
  %265 = add nsw i64 %264, -1
  %266 = icmp ult i64 %265, %253
  br i1 %266, label %267, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %251
  call fastcc void @native_trap() #111
  unreachable

267:                                              ; preds = %.preheader
  %268 = getelementptr inbounds nuw i64, ptr %259, i64 %265
  %269 = load i64, ptr %268, align 8, !noundef !39
  switch i64 %269, label %.preheader [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

native_ref_test.exit12:                           ; preds = %267, %267, %257, %257, %250, %250
  %.in = phi i64 [ %247, %250 ], [ %261, %257 ], [ %261, %257 ], [ %247, %250 ], [ %269, %267 ], [ %269, %267 ]
  %270 = icmp eq i64 %.in, 30
  br i1 %270, label %ok24, label %trap20
}

define internal tailcc noundef i32 @f.17(i64 %arg0, i64 %arg1) #103 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [5 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 5, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap11

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 10, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit15

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader14 [
    i64 10, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #111
  unreachable

.preheader14:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit15

.loopexit15:                                      ; preds = %.preheader14, %15
  call fastcc void @native_trap() #111
  unreachable

31:                                               ; preds = %.preheader14
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader14 [
    i64 10, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in70 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in70, 10
  br i1 %34, label %ok12.lr.ph, label %trap11

ok12.lr.ph:                                       ; preds = %native_ref_test.exit
  %v68 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v69 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  br label %ok15

trap11:                                           ; preds = %native_ref_test.exit6, %ok110, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok15:                                             ; preds = %native_ref_test.exit6, %ok12.lr.ph
  %35 = phi i64 [ %4, %ok12.lr.ph ], [ %64, %native_ref_test.exit6 ]
  %36 = phi ptr [ %2, %ok12.lr.ph ], [ %65, %native_ref_test.exit6 ]
  %37 = phi ptr [ %12, %ok12.lr.ph ], [ %73, %native_ref_test.exit6 ]
  %38 = phi i64 [ %11, %ok12.lr.ph ], [ %72, %native_ref_test.exit6 ]
  %arg1.tr30 = phi i64 [ %arg1, %ok12.lr.ph ], [ %v115, %native_ref_test.exit6 ]
  %v34 = phi i64 [ %arg0, %ok12.lr.ph ], [ %v113, %native_ref_test.exit6 ]
  %v16 = inttoptr i64 %v34 to ptr
  %v17 = getelementptr i8, ptr %v16, i64 8
  %v18 = load i64, ptr %v17, align 1
  %v19.not = icmp eq i64 %v18, 0
  br i1 %v19.not, label %trap20, label %ok21

trap20:                                           ; preds = %ok15
  call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %ok15
  %v22 = inttoptr i64 %v18 to ptr
  %v23 = getelementptr i8, ptr %v22, i64 8
  %v24 = load i32, ptr %v23, align 1
  %v25 = zext i32 %v24 to i64
  %v26 = icmp eq i64 %arg1.tr30, %v25
  br i1 %v26, label %then31, label %else30

then31:                                           ; preds = %ok21
  %.lcssa91 = phi i64 [ %35, %ok21 ]
  %.lcssa76 = phi ptr [ %36, %ok21 ]
  store ptr %.lcssa76, ptr @native_roots.0, align 8
  %39 = add i64 %.lcssa91, -1
  store i64 %39, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  ret i32 0

else30:                                           ; preds = %ok21
  %40 = and i64 %v34, 1
  %.not.i1 = icmp eq i64 %40, 0
  br i1 %.not.i1, label %41, label %trap37

41:                                               ; preds = %else30
  switch i64 %38, label %42 [
    i64 10, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

42:                                               ; preds = %41
  %43 = getelementptr inbounds nuw i8, ptr %37, i64 360
  %44 = load i64, ptr %43, align 8, !noundef !39
  %45 = lshr i64 %38, 2
  %46 = add nsw i64 %45, -1
  %47 = icmp ult i64 %46, %44
  br i1 %47, label %48, label %.loopexit11

48:                                               ; preds = %42
  %49 = getelementptr inbounds nuw i8, ptr %37, i64 352
  %50 = load ptr, ptr %49, align 8, !nonnull !39, !noundef !39
  %51 = getelementptr inbounds nuw i64, ptr %50, i64 %46
  %52 = load i64, ptr %51, align 8, !noundef !39
  switch i64 %52, label %.preheader10 [
    i64 10, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader10:                                     ; preds = %57, %48
  %53 = phi i64 [ %59, %57 ], [ %52, %48 ]
  %54 = lshr i64 %53, 2
  %55 = add nsw i64 %54, -1
  %56 = icmp ult i64 %55, %44
  br i1 %56, label %57, label %.loopexit11

.loopexit11:                                      ; preds = %.preheader10, %42
  call fastcc void @native_trap() #111
  unreachable

57:                                               ; preds = %.preheader10
  %58 = getelementptr inbounds nuw i64, ptr %50, i64 %55
  %59 = load i64, ptr %58, align 8, !noundef !39
  switch i64 %59, label %.preheader10 [
    i64 10, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

native_ref_test.exit2:                            ; preds = %57, %57, %48, %48, %41, %41
  %.in71 = phi i64 [ %38, %41 ], [ %52, %48 ], [ %52, %48 ], [ %38, %41 ], [ %59, %57 ], [ %59, %57 ]
  %60 = icmp eq i64 %.in71, 10
  br i1 %60, label %ok38, label %trap37

trap37:                                           ; preds = %native_ref_test.exit2, %else30
  call fastcc void @native_trap()
  unreachable

ok38:                                             ; preds = %native_ref_test.exit2
  store i64 %v34, ptr %v3, align 8
  %v44 = load i64, ptr %v17, align 1
  store i64 %v44, ptr %v4, align 8
  %v45.not = icmp eq i64 %v44, 0
  br i1 %v45.not, label %trap46, label %ok47

trap46:                                           ; preds = %ok38
  call fastcc void @native_trap()
  unreachable

ok47:                                             ; preds = %ok38
  %v48 = inttoptr i64 %v44 to ptr
  %v49 = getelementptr i8, ptr %v48, i64 8
  %v50 = load i32, ptr %v49, align 1
  %v51 = zext i32 %v50 to i64
  %v52.not = icmp ult i64 %arg1.tr30, %v51
  br i1 %v52.not, label %native_roots_leave.exit3, label %then56

then56:                                           ; preds = %ok47
  call fastcc void @native_trap()
  unreachable

native_roots_leave.exit3:                         ; preds = %ok47
  %v63 = getelementptr i8, ptr %v48, i64 24
  %v64 = load i64, ptr %v63, align 1
  %v67 = trunc nuw i64 %arg1.tr30 to i32
  store i64 %v64, ptr %v68, align 8
  store i64 %v44, ptr %v69, align 8
  store i64 5, ptr %1, align 8
  %v71 = call tailcc i32 @f.4(i64 %v44, i32 %v67)
  store i64 %v64, ptr %v68, align 8
  store i64 4, ptr %1, align 8
  %v74 = call tailcc i32 @f.3(i64 %v64, i32 %v71)
  store i64 3, ptr %1, align 8
  call fastcc void @write_character(i32 %v74)
  %v76 = load i64, ptr %v3, align 8
  %v77.not = icmp eq i64 %v76, 0
  br i1 %v77.not, label %trap78, label %ok79

trap78:                                           ; preds = %native_roots_leave.exit3
  call fastcc void @native_trap()
  unreachable

ok79:                                             ; preds = %native_roots_leave.exit3
  %v80 = inttoptr i64 %v76 to ptr
  %v81 = getelementptr i8, ptr %v80, i64 16
  %v82 = load i64, ptr %v81, align 1
  %v83.not = icmp eq i64 %v82, 0
  br i1 %v83.not, label %trap84, label %ok85

trap84:                                           ; preds = %ok79
  call fastcc void @native_trap()
  unreachable

ok85:                                             ; preds = %ok79
  %v86 = inttoptr i64 %v82 to ptr
  %v87 = getelementptr i8, ptr %v86, i64 8
  %v88 = load i32, ptr %v87, align 1
  %v89 = icmp eq i32 %v88, 0
  br i1 %v89, label %then93, label %ok104

then93:                                           ; preds = %ok85
  call fastcc void @native_trap()
  unreachable

ok104:                                            ; preds = %ok85
  %v106 = getelementptr i8, ptr %v86, i64 16
  %v107 = load i64, ptr %v106, align 1
  %v108.not = icmp eq i64 %v107, 0
  br i1 %v108.not, label %trap109, label %ok110

trap109:                                          ; preds = %ok104
  call fastcc void @native_trap()
  unreachable

ok110:                                            ; preds = %ok104
  %v111 = inttoptr i64 %v107 to ptr
  %v112 = getelementptr i8, ptr %v111, i64 16
  %v113 = load i64, ptr %v112, align 1
  %v115 = add nuw nsw i64 %arg1.tr30, 1
  %61 = load i64, ptr %0, align 8, !noundef !39
  %62 = icmp eq i64 %61, 0
  %.pre18 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %63 = zext i1 %62 to i64
  %64 = add i64 %.pre18, %63
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %65 = select i1 %62, ptr %native_roots.0.val, ptr %roots.val
  store i64 5, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %65, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %66 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %67 = call noundef i64 @llvm.umax.i64(i64 %64, i64 %66)
  store i64 %67, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v113, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %68 = icmp ne i64 %v113, 0
  %69 = and i64 %v113, 1
  %.not.i5 = icmp eq i64 %69, 0
  %or.cond59 = and i1 %68, %.not.i5
  br i1 %or.cond59, label %70, label %trap11

70:                                               ; preds = %ok110
  %71 = inttoptr i64 %v113 to ptr
  %72 = load i64, ptr %71, align 8, !noundef !39
  %73 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %74 = icmp eq ptr %73, null
  br i1 %74, label %87, label %75

75:                                               ; preds = %70
  switch i64 %72, label %76 [
    i64 10, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

76:                                               ; preds = %75
  %77 = getelementptr inbounds nuw i8, ptr %73, i64 360
  %78 = load i64, ptr %77, align 8, !noundef !39
  %79 = lshr i64 %72, 2
  %80 = add nsw i64 %79, -1
  %81 = icmp ult i64 %80, %78
  br i1 %81, label %82, label %.loopexit

82:                                               ; preds = %76
  %83 = getelementptr inbounds nuw i8, ptr %73, i64 352
  %84 = load ptr, ptr %83, align 8, !nonnull !39, !noundef !39
  %85 = getelementptr inbounds nuw i64, ptr %84, i64 %80
  %86 = load i64, ptr %85, align 8, !noundef !39
  switch i64 %86, label %.preheader [
    i64 10, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

87:                                               ; preds = %70
  call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %92, %82
  %88 = phi i64 [ %94, %92 ], [ %86, %82 ]
  %89 = lshr i64 %88, 2
  %90 = add nsw i64 %89, -1
  %91 = icmp ult i64 %90, %78
  br i1 %91, label %92, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %76
  call fastcc void @native_trap() #111
  unreachable

92:                                               ; preds = %.preheader
  %93 = getelementptr inbounds nuw i64, ptr %84, i64 %90
  %94 = load i64, ptr %93, align 8, !noundef !39
  switch i64 %94, label %.preheader [
    i64 10, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

native_ref_test.exit6:                            ; preds = %92, %92, %82, %82, %75, %75
  %.in = phi i64 [ %72, %75 ], [ %86, %82 ], [ %86, %82 ], [ %72, %75 ], [ %94, %92 ], [ %94, %92 ]
  %95 = icmp eq i64 %.in, 10
  br i1 %95, label %ok15, label %trap11
}

define internal tailcc i32 @f.3(i64 %arg0, i32 %arg1) unnamed_addr #103 personality ptr @rust_eh_personality {
entry:
  %v10.not = icmp eq i64 %arg0, 0
  br i1 %v10.not, label %trap11, label %ok12

trap11:                                           ; preds = %entry
  tail call fastcc void @native_trap()
  unreachable

ok12:                                             ; preds = %entry
  %v13 = and i64 %arg0, 1
  %v14 = icmp eq i64 %v13, 0
  br i1 %v14, label %ok16, label %trap15

trap15:                                           ; preds = %ok12
  tail call fastcc void @native_trap()
  unreachable

ok16:                                             ; preds = %ok12
  %v17 = inttoptr i64 %arg0 to ptr
  %v18 = getelementptr i8, ptr %v17, i64 8
  %v19 = load i64, ptr %v18, align 1
  %v20 = zext i32 %arg1 to i64
  %v21 = icmp ugt i64 %v19, %v20
  br i1 %v21, label %ok23, label %trap22

trap22:                                           ; preds = %ok16
  tail call fastcc void @native_trap()
  unreachable

ok23:                                             ; preds = %ok16
  %v25 = getelementptr i8, ptr %v17, i64 16
  %v26 = getelementptr i8, ptr %v25, i64 %v20
  %v27 = load i8, ptr %v26, align 1
  %v28 = zext i8 %v27 to i32
  %v29 = icmp sgt i8 %v27, -1
  br i1 %v29, label %native_roots_leave.exit, label %else42

native_roots_leave.exit:                          ; preds = %ok82, %ok23
  %common.ret.op = phi i32 [ %v28, %ok23 ], [ %v92, %ok82 ]
  ret i32 %common.ret.op

else42:                                           ; preds = %ok23
  %v46 = icmp samesign ult i8 %v27, -32
  %v54 = icmp samesign ult i8 %v27, -16
  %v57 = select i1 %v54, i32 3, i32 4
  %slot48.0 = select i1 %v46, i32 2, i32 %v57
  %v61 = lshr i32 127, %slot48.0
  %v62 = and i32 %v61, %v28
  %wide.trip.count = zext nneg i32 %slot48.0 to i64
  br label %ok75

ok75:                                             ; preds = %ok82, %else42
  %indvars.iv = phi i64 [ %indvars.iv.next, %ok82 ], [ 1, %else42 ]
  %slot3.0 = phi i32 [ %v92, %ok82 ], [ %v62, %else42 ]
  %0 = trunc nuw nsw i64 %indvars.iv to i32
  %v68 = add i32 %arg1, %0
  %v79 = zext i32 %v68 to i64
  %v80 = icmp ugt i64 %v19, %v79
  br i1 %v80, label %ok82, label %trap81

trap81:                                           ; preds = %ok75
  tail call fastcc void @native_trap()
  unreachable

ok82:                                             ; preds = %ok75
  %v85 = getelementptr i8, ptr %v25, i64 %v79
  %v86 = load i8, ptr %v85, align 1
  %1 = and i8 %v86, 63
  %v88 = zext nneg i8 %1 to i32
  %v91 = shl i32 %slot3.0, 6
  %v92 = or disjoint i32 %v91, %v88
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %native_roots_leave.exit, label %ok75
}

define internal tailcc i64 @f.13(i64 %arg0, i64 %arg1) #102 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [4 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 4, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap11

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 42, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit8

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader7 [
    i64 42, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #111
  unreachable

.preheader7:                                      ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit8

.loopexit8:                                       ; preds = %.preheader7, %15
  call fastcc void @native_trap() #111
  unreachable

31:                                               ; preds = %.preheader7
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader7 [
    i64 42, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in96 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in96, 42
  br i1 %34, label %ok12.lr.ph, label %trap11

ok12.lr.ph:                                       ; preds = %native_ref_test.exit
  %v66 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  br label %ok12

trap11:                                           ; preds = %native_ref_test.exit3, %ok152, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok12:                                             ; preds = %native_ref_test.exit3, %ok12.lr.ph
  %35 = phi i64 [ %4, %ok12.lr.ph ], [ %41, %native_ref_test.exit3 ]
  %36 = phi ptr [ %2, %ok12.lr.ph ], [ %42, %native_ref_test.exit3 ]
  %arg1.tr22 = phi i64 [ %arg1, %ok12.lr.ph ], [ %v157, %native_ref_test.exit3 ]
  %arg0.tr21 = phi i64 [ %arg0, %ok12.lr.ph ], [ %v155, %native_ref_test.exit3 ]
  store i64 %arg0.tr21, ptr %v3, align 8
  %v16 = inttoptr i64 %arg0.tr21 to ptr
  %v17 = getelementptr i8, ptr %v16, i64 16
  %v18 = load i64, ptr %v17, align 1
  %v20 = icmp eq i64 %v18, %arg1.tr22
  br i1 %v20, label %ok30, label %ok37

ok30:                                             ; preds = %ok12
  %.lcssa135 = phi i64 [ %35, %ok12 ]
  %.lcssa116 = phi ptr [ %36, %ok12 ]
  %v16.lcssa = phi ptr [ %v16, %ok12 ]
  %v32 = getelementptr i8, ptr %v16.lcssa, i64 24
  %v33 = load i64, ptr %v32, align 1
  store ptr %.lcssa116, ptr @native_roots.0, align 8
  %37 = add i64 %.lcssa135, -1
  store i64 %37, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  ret i64 %v33

ok37:                                             ; preds = %ok12
  %v39 = getelementptr i8, ptr %v16, i64 8
  %v40 = load i64, ptr %v39, align 1
  %v41.not = icmp eq i64 %v40, 0
  br i1 %v41.not, label %trap42, label %ok43

trap42:                                           ; preds = %ok37
  call fastcc void @native_trap()
  unreachable

ok43:                                             ; preds = %ok37
  %v44 = inttoptr i64 %v40 to ptr
  %v45 = getelementptr i8, ptr %v44, i64 8
  %v46 = load i64, ptr %v45, align 1
  store i64 %v46, ptr %v4, align 8
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %ok43
  call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %ok43
  %v50 = inttoptr i64 %v46 to ptr
  %v58 = getelementptr i8, ptr %v50, i64 8
  %v59 = load i64, ptr %v58, align 1
  %v60.not = icmp eq i64 %v59, 0
  br i1 %v60.not, label %trap61, label %ok62

trap61:                                           ; preds = %ok49
  call fastcc void @native_trap()
  unreachable

ok62:                                             ; preds = %ok49
  %v51 = getelementptr i8, ptr %v50, i64 16
  %v52 = load i64, ptr %v51, align 1
  %v63 = inttoptr i64 %v59 to ptr
  %v64 = getelementptr i8, ptr %v63, i64 8
  %v65 = load ptr, ptr %v64, align 1
  store i64 %v52, ptr %v66, align 8
  store i64 4, ptr %1, align 8
  %v68 = call tailcc i64 %v65(i64 %v52, i64 128)
  %v70 = icmp ugt i64 %arg1.tr22, 4294967295
  br i1 %v70, label %then74, label %block72

then74:                                           ; preds = %ok62
  call fastcc void @native_trap()
  unreachable

block72:                                          ; preds = %ok62
  %v77 = icmp ugt i64 %v68, 255
  br i1 %v77, label %then81, label %block79

then81:                                           ; preds = %block72
  call fastcc void @native_trap()
  unreachable

block79:                                          ; preds = %block72
  %v83 = load i64, ptr %v3, align 8
  %v84.not = icmp eq i64 %v83, 0
  br i1 %v84.not, label %trap85, label %ok86

trap85:                                           ; preds = %block79
  call fastcc void @native_trap()
  unreachable

ok86:                                             ; preds = %block79
  %v87 = inttoptr i64 %v83 to ptr
  %v88 = getelementptr i8, ptr %v87, i64 24
  %v89 = load i64, ptr %v88, align 1
  %v90.not = icmp eq i64 %v89, 0
  br i1 %v90.not, label %trap91, label %ok92

trap91:                                           ; preds = %ok86
  call fastcc void @native_trap()
  unreachable

ok92:                                             ; preds = %ok86
  %v93 = inttoptr i64 %v89 to ptr
  %v94 = getelementptr i8, ptr %v93, i64 8
  %v95 = load i64, ptr %v94, align 1
  %v100.not = icmp eq i64 %v95, 0
  br i1 %v100.not, label %trap101, label %ok102

trap101:                                          ; preds = %ok92
  call fastcc void @native_trap()
  unreachable

ok102:                                            ; preds = %ok92
  %v103 = and i64 %v95, 1
  %v104 = icmp eq i64 %v103, 0
  br i1 %v104, label %ok106, label %trap105

trap105:                                          ; preds = %ok102
  call fastcc void @native_trap()
  unreachable

ok106:                                            ; preds = %ok102
  %v107 = inttoptr i64 %v95 to ptr
  %v108 = getelementptr i8, ptr %v107, i64 8
  %v109 = load i64, ptr %v108, align 1
  %v111 = icmp ult i64 %arg1.tr22, %v109
  br i1 %v111, label %ok113, label %trap112

trap112:                                          ; preds = %ok106
  call fastcc void @native_trap()
  unreachable

ok113:                                            ; preds = %ok106
  %v115 = getelementptr i8, ptr %v107, i64 16
  %v116 = getelementptr i8, ptr %v115, i64 %arg1.tr22
  %v117 = trunc nuw i64 %v68 to i8
  store i8 %v117, ptr %v116, align 1
  %v118 = load i64, ptr %v3, align 8
  %v119.not = icmp eq i64 %v118, 0
  br i1 %v119.not, label %trap120, label %ok121

trap120:                                          ; preds = %ok113
  call fastcc void @native_trap()
  unreachable

ok121:                                            ; preds = %ok113
  %v122 = inttoptr i64 %v118 to ptr
  %v123 = getelementptr i8, ptr %v122, i64 32
  %v124 = load i64, ptr %v123, align 1
  %v125.not = icmp eq i64 %v124, 0
  br i1 %v125.not, label %trap126, label %ok127

trap126:                                          ; preds = %ok121
  call fastcc void @native_trap()
  unreachable

ok127:                                            ; preds = %ok121
  %v128 = inttoptr i64 %v124 to ptr
  %v129 = getelementptr i8, ptr %v128, i64 8
  %v130 = load i32, ptr %v129, align 1
  %v131 = icmp eq i32 %v130, 0
  br i1 %v131, label %then135, label %ok146

then135:                                          ; preds = %ok127
  call fastcc void @native_trap()
  unreachable

ok146:                                            ; preds = %ok127
  %v148 = getelementptr i8, ptr %v128, i64 16
  %v149 = load i64, ptr %v148, align 1
  %v150.not = icmp eq i64 %v149, 0
  br i1 %v150.not, label %trap151, label %ok152

trap151:                                          ; preds = %ok146
  call fastcc void @native_trap()
  unreachable

ok152:                                            ; preds = %ok146
  %v153 = inttoptr i64 %v149 to ptr
  %v154 = getelementptr i8, ptr %v153, i64 16
  %v155 = load i64, ptr %v154, align 1
  %v157 = add nuw nsw i64 %arg1.tr22, 1
  %38 = load i64, ptr %0, align 8, !noundef !39
  %39 = icmp eq i64 %38, 0
  %.pre28 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %40 = zext i1 %39 to i64
  %41 = add i64 %.pre28, %40
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %42 = select i1 %39, ptr %native_roots.0.val, ptr %roots.val
  store i64 4, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %42, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %41, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %43 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %44 = call noundef i64 @llvm.umax.i64(i64 %41, i64 %43)
  store i64 %44, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v155, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  %45 = icmp ne i64 %v155, 0
  %46 = and i64 %v155, 1
  %.not.i2 = icmp eq i64 %46, 0
  %or.cond88 = and i1 %45, %.not.i2
  br i1 %or.cond88, label %47, label %trap11

47:                                               ; preds = %ok152
  %48 = inttoptr i64 %v155 to ptr
  %49 = load i64, ptr %48, align 8, !noundef !39
  %50 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %51 = icmp eq ptr %50, null
  br i1 %51, label %64, label %52

52:                                               ; preds = %47
  switch i64 %49, label %53 [
    i64 42, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

53:                                               ; preds = %52
  %54 = getelementptr inbounds nuw i8, ptr %50, i64 360
  %55 = load i64, ptr %54, align 8, !noundef !39
  %56 = lshr i64 %49, 2
  %57 = add nsw i64 %56, -1
  %58 = icmp ult i64 %57, %55
  br i1 %58, label %59, label %.loopexit

59:                                               ; preds = %53
  %60 = getelementptr inbounds nuw i8, ptr %50, i64 352
  %61 = load ptr, ptr %60, align 8, !nonnull !39, !noundef !39
  %62 = getelementptr inbounds nuw i64, ptr %61, i64 %57
  %63 = load i64, ptr %62, align 8, !noundef !39
  switch i64 %63, label %.preheader [
    i64 42, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

64:                                               ; preds = %47
  call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %69, %59
  %65 = phi i64 [ %71, %69 ], [ %63, %59 ]
  %66 = lshr i64 %65, 2
  %67 = add nsw i64 %66, -1
  %68 = icmp ult i64 %67, %55
  br i1 %68, label %69, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %53
  call fastcc void @native_trap() #111
  unreachable

69:                                               ; preds = %.preheader
  %70 = getelementptr inbounds nuw i64, ptr %61, i64 %67
  %71 = load i64, ptr %70, align 8, !noundef !39
  switch i64 %71, label %.preheader [
    i64 42, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

native_ref_test.exit3:                            ; preds = %69, %69, %59, %59, %52, %52
  %.in = phi i64 [ %49, %52 ], [ %63, %59 ], [ %63, %59 ], [ %49, %52 ], [ %71, %69 ], [ %71, %69 ]
  %72 = icmp eq i64 %.in, 42
  br i1 %72, label %ok12, label %trap11
}

define internal tailcc i64 @f.12(i64 %arg0, i64 %arg1) #102 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [10 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 10, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %v3, i8 0, i64 32, i1 false)
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap12

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %15
  call fastcc void @native_trap() #111
  unreachable

31:                                               ; preds = %.preheader
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader [
    i64 74, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in, 74
  br i1 %34, label %ok13, label %trap12

trap12:                                           ; preds = %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok13:                                             ; preds = %native_ref_test.exit
  store i64 %arg0, ptr %v4, align 8
  %v18 = getelementptr i8, ptr %10, i64 8
  %v19 = load i64, ptr %v18, align 1
  %v20.not = icmp eq i64 %v19, 0
  br i1 %v20.not, label %trap21, label %ok22

trap21:                                           ; preds = %ok13
  call fastcc void @native_trap()
  unreachable

ok22:                                             ; preds = %ok13
  %v23 = inttoptr i64 %v19 to ptr
  %v24 = getelementptr i8, ptr %v23, i64 8
  %v25 = load i64, ptr %v24, align 1
  store i64 %v25, ptr %v5, align 8
  %v26.not = icmp eq i64 %v25, 0
  br i1 %v26.not, label %trap27, label %ok28

trap27:                                           ; preds = %ok22
  call fastcc void @native_trap()
  unreachable

ok28:                                             ; preds = %ok22
  %v29 = inttoptr i64 %v25 to ptr
  %v38 = getelementptr i8, ptr %v29, i64 8
  %v39 = load i64, ptr %v38, align 1
  %v40.not = icmp eq i64 %v39, 0
  br i1 %v40.not, label %trap41, label %ok42

trap41:                                           ; preds = %ok28
  call fastcc void @native_trap()
  unreachable

ok42:                                             ; preds = %ok28
  %v30 = getelementptr i8, ptr %v29, i64 16
  %v31 = load i64, ptr %v30, align 1
  %v43 = inttoptr i64 %v39 to ptr
  %v44 = getelementptr i8, ptr %v43, i64 8
  %v45 = load ptr, ptr %v44, align 1
  %v46 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %v31, ptr %v46, align 8
  store i64 6, ptr %1, align 8
  %v48 = call tailcc i64 %v45(i64 %v31, i64 %arg1)
  %v49.b = load i1, ptr @g.4, align 1
  br i1 %v49.b, label %block52, label %then54

then54:                                           ; preds = %ok42
  call fastcc void @native_trap()
  unreachable

block52:                                          ; preds = %ok42
  %v56 = load i64, ptr @g.3, align 8
  %v57.not = icmp eq i64 %v56, 0
  br i1 %v57.not, label %trap58, label %ok59

trap58:                                           ; preds = %block52
  call fastcc void @native_trap()
  unreachable

ok59:                                             ; preds = %block52
  %v64 = icmp ugt i64 %v48, 4294967295
  br i1 %v64, label %then68, label %block66

then68:                                           ; preds = %ok59
  call fastcc void @native_trap()
  unreachable

block66:                                          ; preds = %ok59
  store i64 5, ptr %1, align 8
  %35 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %36 = icmp eq ptr %35, null
  br i1 %36, label %37, label %38

37:                                               ; preds = %block66
  call fastcc void @native_trap() #111
  unreachable

38:                                               ; preds = %block66
  %39 = getelementptr inbounds nuw i8, ptr %35, i64 376
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = icmp eq i64 %40, 0
  br i1 %41, label %42, label %46

42:                                               ; preds = %52, %46, %38
  %43 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %44 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %35, i64 noundef 24, ptr noundef %43) #84
  %45 = icmp eq ptr %44, null
  br i1 %45, label %54, label %ok74

46:                                               ; preds = %38
  %47 = getelementptr inbounds nuw i8, ptr %35, i64 368
  %48 = load i64, ptr %47, align 8, !noundef !39
  %49 = add i64 %48, 1
  store i64 %49, ptr %47, align 8
  %50 = urem i64 %49, %40
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %52, label %42

52:                                               ; preds = %46
  %53 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %35, ptr noundef %53) #84
  br label %42

54:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok74:                                             ; preds = %42
  %55 = ptrtoint ptr %44 to i64
  store i64 102, ptr %44, align 1
  %v81 = getelementptr i8, ptr %44, i64 8
  store i32 0, ptr %v81, align 1
  %v86 = getelementptr i8, ptr %44, i64 16
  store i64 0, ptr %v86, align 1
  store i64 %55, ptr %v3, align 8
  %v87 = load i64, ptr %v4, align 8
  %v88.not = icmp eq i64 %v87, 0
  br i1 %v88.not, label %trap89, label %ok90

trap89:                                           ; preds = %ok74
  call fastcc void @native_trap()
  unreachable

ok90:                                             ; preds = %ok74
  %v91 = inttoptr i64 %v87 to ptr
  %v92 = getelementptr i8, ptr %v91, i64 8
  %v93 = load i64, ptr %v92, align 1
  %v96 = trunc nuw i64 %v48 to i32
  store i64 %v93, ptr %v46, align 8
  %v98 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v98, align 8
  %v99 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  store i64 %55, ptr %v99, align 8
  store i64 8, ptr %1, align 8
  %v102 = call fastcc i64 @native_array_new(i32 %v96)
  store i64 %v102, ptr %v46, align 8
  store i64 %v93, ptr %v98, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v99, align 8
  %v106 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  store i64 %55, ptr %v106, align 8
  store i64 9, ptr %1, align 8
  %56 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %57 = icmp eq ptr %56, null
  br i1 %57, label %58, label %59

58:                                               ; preds = %ok90
  call fastcc void @native_trap() #111
  unreachable

59:                                               ; preds = %ok90
  %60 = getelementptr inbounds nuw i8, ptr %56, i64 376
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = icmp eq i64 %61, 0
  br i1 %62, label %63, label %67

63:                                               ; preds = %73, %67, %59
  %64 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %65 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %56, i64 noundef 16, ptr noundef %64) #84
  %66 = icmp eq ptr %65, null
  br i1 %66, label %75, label %ok111

67:                                               ; preds = %59
  %68 = getelementptr inbounds nuw i8, ptr %56, i64 368
  %69 = load i64, ptr %68, align 8, !noundef !39
  %70 = add i64 %69, 1
  store i64 %70, ptr %68, align 8
  %71 = urem i64 %70, %61
  %72 = icmp eq i64 %71, 0
  br i1 %72, label %73, label %63

73:                                               ; preds = %67
  %74 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %56, ptr noundef %74) #84
  br label %63

75:                                               ; preds = %63
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok111:                                            ; preds = %63
  %76 = ptrtoint ptr %65 to i64
  store i64 130, ptr %65, align 1
  %v118 = getelementptr i8, ptr %65, i64 8
  store i64 %v102, ptr %v118, align 1
  %v119 = load i64, ptr %v3, align 8
  store i64 %v119, ptr %v46, align 8
  store i64 %76, ptr %v98, align 8
  store i64 %v93, ptr %v99, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v106, align 8
  %v124 = getelementptr inbounds nuw i8, ptr %roots, i64 96
  store i64 %55, ptr %v124, align 8
  store i64 10, ptr %1, align 8
  %77 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %78 = icmp eq ptr %77, null
  br i1 %78, label %79, label %80

79:                                               ; preds = %ok111
  call fastcc void @native_trap() #111
  unreachable

80:                                               ; preds = %ok111
  %81 = getelementptr inbounds nuw i8, ptr %77, i64 376
  %82 = load i64, ptr %81, align 8, !noundef !39
  %83 = icmp eq i64 %82, 0
  br i1 %83, label %84, label %88

84:                                               ; preds = %94, %88, %80
  %85 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %86 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %77, i64 noundef 40, ptr noundef %85) #84
  %87 = icmp eq ptr %86, null
  br i1 %87, label %96, label %ok129

88:                                               ; preds = %80
  %89 = getelementptr inbounds nuw i8, ptr %77, i64 368
  %90 = load i64, ptr %89, align 8, !noundef !39
  %91 = add i64 %90, 1
  store i64 %91, ptr %89, align 8
  %92 = urem i64 %91, %82
  %93 = icmp eq i64 %92, 0
  br i1 %93, label %94, label %84

94:                                               ; preds = %88
  %95 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %77, ptr noundef %95) #84
  br label %84

96:                                               ; preds = %84
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok129:                                            ; preds = %84
  %97 = ptrtoint ptr %86 to i64
  store i64 42, ptr %86, align 1
  %v136 = getelementptr i8, ptr %86, i64 8
  store i64 %v93, ptr %v136, align 1
  %v141 = getelementptr i8, ptr %86, i64 16
  store i64 %v48, ptr %v141, align 1
  %v146 = getelementptr i8, ptr %86, i64 24
  store i64 %76, ptr %v146, align 1
  %v151 = getelementptr i8, ptr %86, i64 32
  store i64 %v119, ptr %v151, align 1
  store i64 %97, ptr %v46, align 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v98, align 8
  store i64 %55, ptr %v99, align 8
  store i64 8, ptr %1, align 8
  %98 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %99 = icmp eq ptr %98, null
  br i1 %99, label %100, label %101

100:                                              ; preds = %ok129
  call fastcc void @native_trap() #111
  unreachable

101:                                              ; preds = %ok129
  %102 = getelementptr inbounds nuw i8, ptr %98, i64 376
  %103 = load i64, ptr %102, align 8, !noundef !39
  %104 = icmp eq i64 %103, 0
  br i1 %104, label %105, label %109

105:                                              ; preds = %115, %109, %101
  %106 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %107 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %98, i64 noundef 24, ptr noundef %106) #84
  %108 = icmp eq ptr %107, null
  br i1 %108, label %117, label %ok159

109:                                              ; preds = %101
  %110 = getelementptr inbounds nuw i8, ptr %98, i64 368
  %111 = load i64, ptr %110, align 8, !noundef !39
  %112 = add i64 %111, 1
  store i64 %112, ptr %110, align 8
  %113 = urem i64 %112, %103
  %114 = icmp eq i64 %113, 0
  br i1 %114, label %115, label %105

115:                                              ; preds = %109
  %116 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %98, ptr noundef %116) #84
  br label %105

117:                                              ; preds = %105
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok159:                                            ; preds = %105
  %118 = ptrtoint ptr %107 to i64
  store i64 194, ptr %107, align 1
  %v166 = getelementptr i8, ptr %107, i64 8
  store i64 ptrtoint (ptr @ref.13 to i64), ptr %v166, align 1
  %v171 = getelementptr i8, ptr %107, i64 16
  store i64 %97, ptr %v171, align 1
  store i64 %118, ptr %v86, align 1
  %v177 = load i64, ptr %v3, align 8
  %v178.not = icmp eq i64 %v177, 0
  br i1 %v178.not, label %trap179, label %ok180

trap179:                                          ; preds = %ok159
  call fastcc void @native_trap()
  unreachable

ok180:                                            ; preds = %ok159
  %v181 = inttoptr i64 %v177 to ptr
  %v182 = getelementptr i8, ptr %v181, i64 8
  store i32 1, ptr %v182, align 1
  %v183 = load i64, ptr %v3, align 8
  %v184.not = icmp eq i64 %v183, 0
  br i1 %v184.not, label %trap185, label %ok186

trap185:                                          ; preds = %ok180
  call fastcc void @native_trap()
  unreachable

ok186:                                            ; preds = %ok180
  %v187 = inttoptr i64 %v183 to ptr
  %v188 = getelementptr i8, ptr %v187, i64 8
  %v189 = load i32, ptr %v188, align 1
  %v190 = icmp eq i32 %v189, 0
  br i1 %v190, label %then194, label %ok199

then194:                                          ; preds = %ok186
  call fastcc void @native_trap()
  unreachable

ok199:                                            ; preds = %ok186
  %v201 = getelementptr i8, ptr %v187, i64 16
  %v202 = load i64, ptr %v201, align 1
  %v203.not = icmp eq i64 %v202, 0
  br i1 %v203.not, label %trap204, label %ok205

trap204:                                          ; preds = %ok199
  call fastcc void @native_trap()
  unreachable

ok205:                                            ; preds = %ok199
  store i64 %v202, ptr %v6, align 8
  %v209 = inttoptr i64 %v202 to ptr
  %v217 = getelementptr i8, ptr %v209, i64 8
  %v218 = load i64, ptr %v217, align 1
  %v219.not = icmp eq i64 %v218, 0
  br i1 %v219.not, label %trap220, label %ok221

trap220:                                          ; preds = %ok205
  call fastcc void @native_trap()
  unreachable

ok221:                                            ; preds = %ok205
  %v210 = getelementptr i8, ptr %v209, i64 16
  %v211 = load i64, ptr %v210, align 1
  %v222 = inttoptr i64 %v218 to ptr
  %v223 = getelementptr i8, ptr %v222, i64 8
  %v224 = load ptr, ptr %v223, align 1
  %119 = load i64, ptr %0, align 8, !noundef !39
  %120 = icmp eq i64 %119, 0
  br i1 %120, label %native_roots_leave.exit, label %121

121:                                              ; preds = %ok221
  %122 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %122, ptr @native_roots.0, align 8
  %123 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %124 = add i64 %123, -1
  store i64 %124, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %121, %ok221
  %v225 = tail call tailcc i64 %v224(i64 %v211, i64 0)
  ret i64 %v225
}

define internal tailcc noundef i64 @f.14(i64 %arg0, i64 %arg1) #103 personality ptr @rust_eh_personality {
entry:
  %roots.i = alloca { ptr, i64, i64, [2 x i64] }, align 8
  %roots = alloca { ptr, i64, i64, [3 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 3, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  store i64 0, ptr %v3, align 8
  %v8 = icmp slt i64 %arg1, 16384
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %native_ref_test.exit.thread

9:                                                ; preds = %entry
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 46, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader [
    i64 46, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %15
  call fastcc void @native_trap() #111
  unreachable

31:                                               ; preds = %.preheader
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader [
    i64 46, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in49 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp ne i64 %.in49, 46
  br i1 %v8, label %then12, label %else11

native_ref_test.exit.thread:                      ; preds = %entry
  br i1 %v8, label %trap17, label %trap42

then12:                                           ; preds = %native_ref_test.exit
  br i1 %34, label %trap17, label %ok18

trap17:                                           ; preds = %then12, %native_ref_test.exit.thread
  call fastcc void @native_trap()
  unreachable

ok18:                                             ; preds = %then12
  br i1 %7, label %ok21, label %trap20

trap20:                                           ; preds = %ok18
  call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %ok18
  %v22 = inttoptr i64 %arg0 to ptr
  %v23 = getelementptr i8, ptr %v22, i64 8
  %v24 = load i64, ptr %v23, align 1
  %v25.not = icmp eq i64 %v24, 0
  br i1 %v25.not, label %trap26, label %ok27

trap26:                                           ; preds = %ok21
  call fastcc void @native_trap()
  unreachable

ok27:                                             ; preds = %ok21
  %v28 = inttoptr i64 %v24 to ptr
  %v29 = getelementptr i8, ptr %v28, i64 8
  %v30 = load i64, ptr %v29, align 1
  %v31.not = icmp eq i64 %v30, 0
  br i1 %v31.not, label %trap32, label %ok33

trap32:                                           ; preds = %ok27
  call fastcc void @native_trap()
  unreachable

common.ret:                                       ; preds = %native_i64_rem_s.exit, %ok33
  %common.ret.op = phi i64 [ %v38, %ok33 ], [ %53, %native_i64_rem_s.exit ]
  ret i64 %common.ret.op

ok33:                                             ; preds = %ok27
  %v34 = inttoptr i64 %v30 to ptr
  %v35 = getelementptr i8, ptr %v34, i64 16
  %v36 = load i64, ptr %v35, align 1
  store ptr %2, ptr @native_roots.0, align 8
  store i64 %3, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %v38 = tail call tailcc i64 @f.16(i64 %v36, i64 %arg1)
  br label %common.ret

else11:                                           ; preds = %native_ref_test.exit
  br i1 %34, label %trap42, label %ok43

trap42:                                           ; preds = %else11, %native_ref_test.exit.thread
  call fastcc void @native_trap()
  unreachable

ok43:                                             ; preds = %else11
  store i64 %arg0, ptr %v3, align 8
  br i1 %7, label %ok46, label %trap45

trap45:                                           ; preds = %ok43
  call fastcc void @native_trap()
  unreachable

ok46:                                             ; preds = %ok43
  %v47 = inttoptr i64 %arg0 to ptr
  %v48 = getelementptr i8, ptr %v47, i64 8
  %v49 = load i64, ptr %v48, align 1
  %v50.not = icmp eq i64 %v49, 0
  br i1 %v50.not, label %trap51, label %ok52

trap51:                                           ; preds = %ok46
  call fastcc void @native_trap()
  unreachable

ok52:                                             ; preds = %ok46
  %v53 = inttoptr i64 %v49 to ptr
  %v54 = getelementptr i8, ptr %v53, i64 8
  %v55 = load i64, ptr %v54, align 1
  %v56.not = icmp eq i64 %v55, 0
  br i1 %v56.not, label %trap57, label %ok58

trap57:                                           ; preds = %ok52
  call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %ok52
  %v59 = inttoptr i64 %v55 to ptr
  %v60 = getelementptr i8, ptr %v59, i64 16
  %v61 = load i64, ptr %v60, align 1
  %v62 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  store i64 %v61, ptr %v62, align 8
  store i64 3, ptr %1, align 8
  %v64 = call tailcc i64 @f.16(i64 %v61, i64 16384)
  %v65 = load i64, ptr %v3, align 8
  %v66.not = icmp eq i64 %v65, 0
  br i1 %v66.not, label %trap67, label %ok68

trap67:                                           ; preds = %ok58
  call fastcc void @native_trap()
  unreachable

ok68:                                             ; preds = %ok58
  %v69 = inttoptr i64 %v65 to ptr
  %v70 = getelementptr i8, ptr %v69, i64 16
  %v71 = load i64, ptr %v70, align 1
  %v72.not = icmp eq i64 %v71, 0
  br i1 %v72.not, label %trap73, label %ok74

trap73:                                           ; preds = %ok68
  call fastcc void @native_trap()
  unreachable

ok74:                                             ; preds = %ok68
  %v75 = inttoptr i64 %v71 to ptr
  %v76 = getelementptr i8, ptr %v75, i64 8
  %v77 = load i32, ptr %v76, align 1
  %v78 = icmp eq i32 %v77, 0
  br i1 %v78, label %then82, label %ok93

then82:                                           ; preds = %ok74
  call fastcc void @native_trap()
  unreachable

ok93:                                             ; preds = %ok74
  %v95 = getelementptr i8, ptr %v75, i64 16
  %v96 = load i64, ptr %v95, align 1
  %v97.not = icmp eq i64 %v96, 0
  br i1 %v97.not, label %trap98, label %ok99

trap98:                                           ; preds = %ok93
  call fastcc void @native_trap()
  unreachable

ok99:                                             ; preds = %ok93
  %v100 = inttoptr i64 %v96 to ptr
  %v101 = getelementptr i8, ptr %v100, i64 8
  %v102 = load i64, ptr %v101, align 1
  %35 = load i64, ptr %0, align 8, !noundef !39
  %36 = icmp eq i64 %35, 0
  %.pre14 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %37 = zext i1 %36 to i64
  %38 = add i64 %.pre14, %37
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %39 = select i1 %36, ptr %native_roots.0.val, ptr %roots.val
  call void @llvm.lifetime.start.p0(ptr nonnull %roots.i)
  %40 = getelementptr inbounds nuw i8, ptr %roots.i, i64 8
  store i64 2, ptr %40, align 8
  %41 = getelementptr inbounds nuw i8, ptr %roots.i, i64 16
  store i64 0, ptr %41, align 8
  store ptr %39, ptr %roots.i, align 8
  store ptr %roots.i, ptr @native_roots.0, align 8
  store i64 %38, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %42 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %43 = call noundef i64 @llvm.umax.i64(i64 %38, i64 %42)
  store i64 %43, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1.i = getelementptr inbounds nuw i8, ptr %roots.i, i64 24
  store i64 %v102, ptr %v1.i, align 8
  %v8.b13.i = load i1, ptr @g.14, align 1
  br i1 %v8.b13.i, label %block11.lr.ph.i, label %then13.i

block11.lr.ph.i:                                  ; preds = %ok99
  %v49.i = getelementptr inbounds nuw i8, ptr %roots.i, i64 32
  br label %block11.i

then13.i:                                         ; preds = %ok86.i, %ok99
  call fastcc void @native_trap()
  unreachable

block11.i:                                        ; preds = %ok86.i, %block11.lr.ph.i
  %44 = phi i64 [ %38, %block11.lr.ph.i ], [ %49, %ok86.i ]
  %45 = phi ptr [ %39, %block11.lr.ph.i ], [ %50, %ok86.i ]
  %arg2.tr16.i = phi i64 [ %v64, %block11.lr.ph.i ], [ %v96.i, %ok86.i ]
  %arg1.tr15.i.in = phi i64 [ %arg1, %block11.lr.ph.i ], [ %arg1.tr15.i, %ok86.i ]
  %arg0.tr14.i = phi i64 [ %v102, %block11.lr.ph.i ], [ %v89.i, %ok86.i ]
  %arg1.tr15.i = lshr i64 %arg1.tr15.i.in, 14
  %v15.i = load i64, ptr @g.13, align 8
  %v16.not.i = icmp eq i64 %v15.i, 0
  br i1 %v16.not.i, label %trap17.i, label %ok18.i

trap17.i:                                         ; preds = %block11.i
  call fastcc void @native_trap()
  unreachable

ok18.i:                                           ; preds = %block11.i
  %v20.i = icmp eq i64 %arg1.tr15.i, 0
  br i1 %v20.i, label %native_i64_rem_s.exit, label %else24.i

else24.i:                                         ; preds = %ok18.i
  %v31.not.i = icmp eq i64 %arg0.tr14.i, 0
  br i1 %v31.not.i, label %trap32.i, label %ok33.i

trap32.i:                                         ; preds = %else24.i
  call fastcc void @native_trap()
  unreachable

ok33.i:                                           ; preds = %else24.i
  %v34.i = inttoptr i64 %arg0.tr14.i to ptr
  %v35.i = getelementptr i8, ptr %v34.i, i64 8
  %v36.i = load i64, ptr %v35.i, align 1
  %v37.not.i = icmp eq i64 %v36.i, 0
  br i1 %v37.not.i, label %trap38.i, label %ok39.i

trap38.i:                                         ; preds = %ok33.i
  call fastcc void @native_trap()
  unreachable

ok39.i:                                           ; preds = %ok33.i
  %v40.i = inttoptr i64 %v36.i to ptr
  %v41.i = getelementptr i8, ptr %v40.i, i64 8
  %v42.i = load i64, ptr %v41.i, align 1
  %v43.not.i = icmp eq i64 %v42.i, 0
  br i1 %v43.not.i, label %trap44.i, label %ok45.i

trap44.i:                                         ; preds = %ok39.i
  call fastcc void @native_trap()
  unreachable

ok45.i:                                           ; preds = %ok39.i
  %v46.i = inttoptr i64 %v42.i to ptr
  %v47.i = getelementptr i8, ptr %v46.i, i64 16
  %v48.i = load i64, ptr %v47.i, align 1
  store i64 %v48.i, ptr %v49.i, align 8
  store i64 2, ptr %41, align 8
  %v51.i = call tailcc i64 @f.16(i64 %v48.i, i64 16384)
  %v52.i = load i64, ptr %v1.i, align 8
  %v53.not.i = icmp eq i64 %v52.i, 0
  br i1 %v53.not.i, label %trap54.i, label %ok55.i

trap54.i:                                         ; preds = %ok45.i
  call fastcc void @native_trap()
  unreachable

ok55.i:                                           ; preds = %ok45.i
  %v56.i = inttoptr i64 %v52.i to ptr
  %v57.i = getelementptr i8, ptr %v56.i, i64 16
  %v58.i = load i64, ptr %v57.i, align 1
  %v59.not.i = icmp eq i64 %v58.i, 0
  br i1 %v59.not.i, label %trap60.i, label %ok61.i

trap60.i:                                         ; preds = %ok55.i
  call fastcc void @native_trap()
  unreachable

ok61.i:                                           ; preds = %ok55.i
  %v62.i = inttoptr i64 %v58.i to ptr
  %v63.i = getelementptr i8, ptr %v62.i, i64 8
  %v64.i = load i32, ptr %v63.i, align 1
  %v65.i = icmp eq i32 %v64.i, 0
  br i1 %v65.i, label %then69.i, label %ok80.i

then69.i:                                         ; preds = %ok61.i
  call fastcc void @native_trap()
  unreachable

ok80.i:                                           ; preds = %ok61.i
  %v82.i = getelementptr i8, ptr %v62.i, i64 16
  %v83.i = load i64, ptr %v82.i, align 1
  %v84.not.i = icmp eq i64 %v83.i, 0
  br i1 %v84.not.i, label %trap85.i, label %ok86.i

trap85.i:                                         ; preds = %ok80.i
  call fastcc void @native_trap()
  unreachable

ok86.i:                                           ; preds = %ok80.i
  %v87.i = inttoptr i64 %v83.i to ptr
  %v88.i = getelementptr i8, ptr %v87.i, i64 8
  %v89.i = load i64, ptr %v88.i, align 1
  %v95.i = shl i64 %arg2.tr16.i, 14
  %v96.i = add i64 %v51.i, %v95.i
  %46 = load i64, ptr %40, align 8, !noundef !39
  %47 = icmp eq i64 %46, 0
  %.pre16 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %48 = zext i1 %47 to i64
  %49 = add i64 %.pre16, %48
  %native_roots.0.val50 = load ptr, ptr @native_roots.0, align 8
  %roots.i.val = load ptr, ptr %roots.i, align 8
  %50 = select i1 %47, ptr %native_roots.0.val50, ptr %roots.i.val
  store i64 2, ptr %40, align 8
  store i64 0, ptr %41, align 8
  store ptr %50, ptr %roots.i, align 8
  store ptr %roots.i, ptr @native_roots.0, align 8
  store i64 %49, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %51 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %52 = call noundef i64 @llvm.umax.i64(i64 %49, i64 %51)
  store i64 %52, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v89.i, ptr %v1.i, align 8
  %v8.b.i = load i1, ptr @g.14, align 1
  br i1 %v8.b.i, label %block11.i, label %then13.i

native_i64_rem_s.exit:                            ; preds = %ok18.i
  %.lcssa70 = phi i64 [ %44, %ok18.i ]
  %.lcssa60 = phi ptr [ %45, %ok18.i ]
  %arg2.tr16.i.lcssa51 = phi i64 [ %arg2.tr16.i, %ok18.i ]
  %53 = srem i64 %arg2.tr16.i.lcssa51, %arg1
  store ptr %.lcssa60, ptr @native_roots.0, align 8
  %54 = add i64 %.lcssa70, -1
  store i64 %54, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %roots.i)
  br label %common.ret
}

define internal tailcc noundef range(i64 -1152921504606846976, 1152921504606846976) i64 @f.16(i64 %arg0, i64 %arg1) #103 personality ptr @rust_eh_personality {
entry:
  %0 = icmp ne i64 %arg0, 0
  %1 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %1, 0
  %or.cond = and i1 %0, %.not.i
  br i1 %or.cond, label %2, label %trap11

2:                                                ; preds = %entry
  %3 = inttoptr i64 %arg0 to ptr
  %4 = load i64, ptr %3, align 8, !noundef !39
  %5 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %6 = icmp eq ptr %5, null
  br i1 %6, label %21, label %7

7:                                                ; preds = %2
  %8 = icmp eq i64 %4, 62
  switch i64 %4, label %9 [
    i64 62, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

9:                                                ; preds = %7
  %10 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = lshr i64 %4, 2
  %13 = add nsw i64 %12, -1
  %14 = icmp ult i64 %13, %11
  br i1 %14, label %15, label %.loopexit7

15:                                               ; preds = %9
  %16 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %17 = load ptr, ptr %16, align 8, !nonnull !39, !noundef !39
  %18 = getelementptr inbounds nuw i64, ptr %17, i64 %13
  %19 = load i64, ptr %18, align 8, !noundef !39
  %20 = icmp eq i64 %19, 62
  switch i64 %19, label %.preheader6 [
    i64 62, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

21:                                               ; preds = %2
  tail call fastcc void @native_trap() #111
  unreachable

.preheader6:                                      ; preds = %26, %15
  %22 = phi i64 [ %28, %26 ], [ %19, %15 ]
  %23 = lshr i64 %22, 2
  %24 = add nsw i64 %23, -1
  %25 = icmp ult i64 %24, %11
  br i1 %25, label %26, label %.loopexit7

.loopexit7:                                       ; preds = %.preheader6, %9
  tail call fastcc void @native_trap() #111
  unreachable

26:                                               ; preds = %.preheader6
  %27 = getelementptr inbounds nuw i64, ptr %17, i64 %24
  %28 = load i64, ptr %27, align 8, !noundef !39
  switch i64 %28, label %.preheader6 [
    i64 62, label %native_ref_test.exit.loopexit
    i64 0, label %native_ref_test.exit.loopexit
  ]

native_ref_test.exit.loopexit:                    ; preds = %26, %26
  %.lcssa17 = phi i64 [ %28, %26 ], [ %28, %26 ]
  %29 = icmp eq i64 %.lcssa17, 62
  br i1 %29, label %ok15, label %trap11

native_ref_test.exit:                             ; preds = %15, %15, %7, %7
  %30 = phi i1 [ %8, %7 ], [ %20, %15 ], [ %20, %15 ], [ %8, %7 ]
  br i1 %30, label %ok15, label %trap11

trap11:                                           ; preds = %native_ref_test.exit, %native_ref_test.exit.loopexit, %entry
  tail call fastcc void @native_trap()
  unreachable

ok15:                                             ; preds = %native_ref_test.exit, %native_ref_test.exit.loopexit
  %v17 = getelementptr i8, ptr %3, i64 16
  %v18 = load i64, ptr %v17, align 1
  %v19.not = icmp eq i64 %v18, 0
  br i1 %v19.not, label %trap20, label %ok21

trap20:                                           ; preds = %ok15
  tail call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %ok15
  %v22 = inttoptr i64 %v18 to ptr
  %v23 = getelementptr i8, ptr %v22, i64 8
  %v24 = load i32, ptr %v23, align 1
  %v25 = icmp eq i32 %v24, 0
  br i1 %v25, label %then29, label %block27

then29:                                           ; preds = %ok21
  tail call fastcc void @native_trap()
  unreachable

block27:                                          ; preds = %ok21
  switch i64 %4, label %31 [
    i64 62, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

31:                                               ; preds = %block27
  %32 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %33 = load i64, ptr %32, align 8, !noundef !39
  %34 = lshr i64 %4, 2
  %35 = add nsw i64 %34, -1
  %36 = icmp ult i64 %35, %33
  br i1 %36, label %37, label %.loopexit

37:                                               ; preds = %31
  %38 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %39 = load ptr, ptr %38, align 8, !nonnull !39, !noundef !39
  %40 = getelementptr inbounds nuw i64, ptr %39, i64 %35
  %41 = load i64, ptr %40, align 8, !noundef !39
  %42 = icmp eq i64 %41, 62
  switch i64 %41, label %.preheader [
    i64 62, label %native_ref_test.exit2
    i64 0, label %native_ref_test.exit2
  ]

.preheader:                                       ; preds = %47, %37
  %43 = phi i64 [ %49, %47 ], [ %41, %37 ]
  %44 = lshr i64 %43, 2
  %45 = add nsw i64 %44, -1
  %46 = icmp ult i64 %45, %33
  br i1 %46, label %47, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %31
  tail call fastcc void @native_trap() #111
  unreachable

47:                                               ; preds = %.preheader
  %48 = getelementptr inbounds nuw i64, ptr %39, i64 %45
  %49 = load i64, ptr %48, align 8, !noundef !39
  switch i64 %49, label %.preheader [
    i64 62, label %native_ref_test.exit2.loopexit
    i64 0, label %native_ref_test.exit2.loopexit
  ]

native_ref_test.exit2.loopexit:                   ; preds = %47, %47
  %.lcssa18 = phi i64 [ %49, %47 ], [ %49, %47 ]
  %50 = icmp eq i64 %.lcssa18, 62
  br i1 %50, label %ok44, label %trap34

native_ref_test.exit2:                            ; preds = %37, %37, %block27, %block27
  %51 = phi i1 [ %8, %block27 ], [ %42, %37 ], [ %42, %37 ], [ %8, %block27 ]
  br i1 %51, label %ok44, label %trap34

trap34:                                           ; preds = %native_ref_test.exit2, %native_ref_test.exit2.loopexit
  tail call fastcc void @native_trap()
  unreachable

ok44:                                             ; preds = %native_ref_test.exit2, %native_ref_test.exit2.loopexit
  %v46 = getelementptr i8, ptr %v22, i64 16
  %v47 = load i64, ptr %v46, align 1
  %v48.not = icmp eq i64 %v47, 0
  br i1 %v48.not, label %trap49, label %ok56

trap49:                                           ; preds = %ok44
  tail call fastcc void @native_trap()
  unreachable

ok56:                                             ; preds = %ok44
  %v58 = getelementptr i8, ptr %3, i64 8
  %v59 = load i64, ptr %v58, align 1
  %v60.not = icmp eq i64 %v59, 0
  br i1 %v60.not, label %trap61, label %ok62

trap61:                                           ; preds = %ok56
  tail call fastcc void @native_trap()
  unreachable

ok62:                                             ; preds = %ok56
  %v63 = inttoptr i64 %v59 to ptr
  %v64 = getelementptr i8, ptr %v63, i64 8
  %v65 = load i32, ptr %v64, align 1
  %v66 = icmp eq i32 %v65, 0
  br i1 %v66, label %then70, label %ok106

then70:                                           ; preds = %ok62
  tail call fastcc void @native_trap()
  unreachable

ok106:                                            ; preds = %ok62
  %v107 = inttoptr i64 %v47 to ptr
  %v108 = getelementptr i8, ptr %v107, i64 8
  %v109 = load i64, ptr %v108, align 1
  %v117 = getelementptr i8, ptr %3, i64 24
  %v118 = load i64, ptr %v117, align 1
  %v119.not = icmp eq i64 %v118, 0
  br i1 %v119.not, label %trap120, label %ok121

trap120:                                          ; preds = %ok106
  tail call fastcc void @native_trap()
  unreachable

ok121:                                            ; preds = %ok106
  %v122 = inttoptr i64 %v118 to ptr
  %v123 = getelementptr i8, ptr %v122, i64 8
  %v124 = load i32, ptr %v123, align 1
  %v125 = icmp eq i32 %v124, 0
  br i1 %v125, label %then129, label %ok134

then129:                                          ; preds = %ok121
  tail call fastcc void @native_trap()
  unreachable

ok134:                                            ; preds = %ok121
  %v136 = getelementptr i8, ptr %3, i64 32
  %v137 = load i64, ptr %v136, align 1
  %v138.not = icmp eq i64 %v137, 0
  br i1 %v138.not, label %trap139, label %ok140

trap139:                                          ; preds = %ok134
  tail call fastcc void @native_trap()
  unreachable

ok140:                                            ; preds = %ok134
  %v141 = inttoptr i64 %v137 to ptr
  %v142 = getelementptr i8, ptr %v141, i64 8
  %v143 = load i32, ptr %v142, align 1
  %v144 = icmp eq i32 %v143, 0
  br i1 %v144, label %then148, label %ok159

then148:                                          ; preds = %ok140
  tail call fastcc void @native_trap()
  unreachable

ok159:                                            ; preds = %ok140
  %v190 = getelementptr i8, ptr %v141, i64 16
  %v191 = load i64, ptr %v190, align 1
  switch i64 %v191, label %53 [
    i64 -1, label %52
    i64 -2, label %native_i64_rem_s.exit
  ], !prof !86525

52:                                               ; preds = %ok159
  tail call fastcc void @native_trap() #111
  unreachable

53:                                               ; preds = %ok159
  %v192 = add i64 %v191, 1
  %v161 = getelementptr i8, ptr %v63, i64 16
  %v162 = load i64, ptr %v161, align 1
  %v164 = mul i64 %v162, %v109
  %v176 = getelementptr i8, ptr %v122, i64 16
  %v177 = load i64, ptr %v176, align 1
  %v178 = add i64 %v164, %v177
  %54 = srem i64 %v178, %v192
  br label %native_i64_rem_s.exit

native_i64_rem_s.exit:                            ; preds = %53, %ok159
  %55 = phi i64 [ %54, %53 ], [ 0, %ok159 ]
  store i64 %55, ptr %v108, align 1
  %v206 = load i64, ptr %v17, align 1
  %v207.not = icmp eq i64 %v206, 0
  br i1 %v207.not, label %trap208, label %ok209

trap208:                                          ; preds = %native_i64_rem_s.exit
  tail call fastcc void @native_trap()
  unreachable

ok209:                                            ; preds = %native_i64_rem_s.exit
  %v210 = inttoptr i64 %v206 to ptr
  %v211 = getelementptr i8, ptr %v210, i64 8
  %v212 = load i32, ptr %v211, align 1
  %v213 = icmp eq i32 %v212, 0
  br i1 %v213, label %then217, label %ok228

then217:                                          ; preds = %ok209
  tail call fastcc void @native_trap()
  unreachable

ok228:                                            ; preds = %ok209
  %v230 = getelementptr i8, ptr %v210, i64 16
  %v231 = load i64, ptr %v230, align 1
  %v232.not = icmp eq i64 %v231, 0
  br i1 %v232.not, label %trap233, label %ok234

trap233:                                          ; preds = %ok228
  tail call fastcc void @native_trap()
  unreachable

ok234:                                            ; preds = %ok228
  switch i64 %arg1, label %57 [
    i64 0, label %56
    i64 -1, label %native_roots_leave.exit
  ], !prof !86525

56:                                               ; preds = %ok234
  tail call fastcc void @native_trap() #111
  unreachable

57:                                               ; preds = %ok234
  %v235 = inttoptr i64 %v231 to ptr
  %v236 = getelementptr i8, ptr %v235, i64 8
  %v237 = load i64, ptr %v236, align 1
  %58 = sdiv i64 %v237, 8
  %59 = srem i64 %58, %arg1
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %57, %ok234
  %60 = phi i64 [ %59, %57 ], [ 0, %ok234 ]
  ret i64 %60
}

define internal tailcc i64 @f.6(i64 %arg0, i64 %arg1) #102 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [6 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 6, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  store i64 3, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %entry
  call fastcc void @native_trap() #111
  unreachable

10:                                               ; preds = %entry
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = phi ptr [ %.pre, %24 ], [ %roots, %18 ], [ %roots, %10 ]
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 24, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %25, label %ok11

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %14

25:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok11:                                             ; preds = %14
  %26 = ptrtoint ptr %16 to i64
  store i64 122, ptr %16, align 1
  %v18 = getelementptr i8, ptr %16, i64 8
  store i32 0, ptr %v18, align 1
  %v23 = getelementptr i8, ptr %16, i64 16
  store i64 0, ptr %v23, align 1
  store i64 %26, ptr %v3, align 8
  %v26 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 %26, ptr %v26, align 8
  %v27 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v27, align 8
  %v28 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %26, ptr %v28, align 8
  store i64 6, ptr %1, align 8
  %27 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %28 = icmp eq ptr %27, null
  br i1 %28, label %29, label %30

29:                                               ; preds = %ok11
  call fastcc void @native_trap() #111
  unreachable

30:                                               ; preds = %ok11
  %31 = getelementptr inbounds nuw i8, ptr %27, i64 376
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %34, label %38

34:                                               ; preds = %44, %38, %30
  %35 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %36 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %27, i64 noundef 24, ptr noundef %35) #84
  %37 = icmp eq ptr %36, null
  br i1 %37, label %46, label %ok33

38:                                               ; preds = %30
  %39 = getelementptr inbounds nuw i8, ptr %27, i64 368
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = add i64 %40, 1
  store i64 %41, ptr %39, align 8
  %42 = urem i64 %41, %32
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %44, label %34

44:                                               ; preds = %38
  %45 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %27, ptr noundef %45) #84
  br label %34

46:                                               ; preds = %34
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok33:                                             ; preds = %34
  %47 = ptrtoint ptr %36 to i64
  store i64 118, ptr %36, align 1
  %v40 = getelementptr i8, ptr %36, i64 8
  store i64 %arg1, ptr %v40, align 1
  %v45 = getelementptr i8, ptr %36, i64 16
  store i64 %26, ptr %v45, align 1
  store i64 %47, ptr %v26, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v27, align 8
  store i64 %26, ptr %v28, align 8
  store i64 6, ptr %1, align 8
  %48 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %ok33
  call fastcc void @native_trap() #111
  unreachable

51:                                               ; preds = %ok33
  %52 = getelementptr inbounds nuw i8, ptr %48, i64 376
  %53 = load i64, ptr %52, align 8, !noundef !39
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %55, label %59

55:                                               ; preds = %65, %59, %51
  %56 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %57 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %48, i64 noundef 24, ptr noundef %56) #84
  %58 = icmp eq ptr %57, null
  br i1 %58, label %67, label %ok53

59:                                               ; preds = %51
  %60 = getelementptr inbounds nuw i8, ptr %48, i64 368
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = add i64 %61, 1
  store i64 %62, ptr %60, align 8
  %63 = urem i64 %62, %53
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %65, label %55

65:                                               ; preds = %59
  %66 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %48, ptr noundef %66) #84
  br label %55

67:                                               ; preds = %55
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok53:                                             ; preds = %55
  %68 = ptrtoint ptr %57 to i64
  store i64 162, ptr %57, align 1
  %v60 = getelementptr i8, ptr %57, i64 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v60, align 1
  %v65 = getelementptr i8, ptr %57, i64 16
  store i64 %47, ptr %v65, align 1
  store i64 %68, ptr %v23, align 1
  %v71 = load i64, ptr %v3, align 8
  %v72.not = icmp eq i64 %v71, 0
  br i1 %v72.not, label %trap73, label %ok74

trap73:                                           ; preds = %ok53
  call fastcc void @native_trap()
  unreachable

ok74:                                             ; preds = %ok53
  %v75 = inttoptr i64 %v71 to ptr
  %v76 = getelementptr i8, ptr %v75, i64 8
  store i32 1, ptr %v76, align 1
  %v77 = load i64, ptr %v3, align 8
  %v78.not = icmp eq i64 %v77, 0
  br i1 %v78.not, label %trap79, label %ok80

trap79:                                           ; preds = %ok74
  call fastcc void @native_trap()
  unreachable

ok80:                                             ; preds = %ok74
  %v81 = inttoptr i64 %v77 to ptr
  %v82 = getelementptr i8, ptr %v81, i64 8
  %v83 = load i32, ptr %v82, align 1
  %v84 = icmp eq i32 %v83, 0
  br i1 %v84, label %then88, label %ok93

then88:                                           ; preds = %ok80
  call fastcc void @native_trap()
  unreachable

ok93:                                             ; preds = %ok80
  %v95 = getelementptr i8, ptr %v81, i64 16
  %v96 = load i64, ptr %v95, align 1
  %v97.not = icmp eq i64 %v96, 0
  br i1 %v97.not, label %trap98, label %ok99

trap98:                                           ; preds = %ok93
  call fastcc void @native_trap()
  unreachable

ok99:                                             ; preds = %ok93
  store i64 %v96, ptr %v4, align 8
  %v103 = inttoptr i64 %v96 to ptr
  %v111 = getelementptr i8, ptr %v103, i64 8
  %v112 = load i64, ptr %v111, align 1
  %v113.not = icmp eq i64 %v112, 0
  br i1 %v113.not, label %trap114, label %ok115

trap114:                                          ; preds = %ok99
  call fastcc void @native_trap()
  unreachable

ok115:                                            ; preds = %ok99
  %v104 = getelementptr i8, ptr %v103, i64 16
  %v105 = load i64, ptr %v104, align 1
  %v116 = inttoptr i64 %v112 to ptr
  %v117 = getelementptr i8, ptr %v116, i64 8
  %v118 = load ptr, ptr %v117, align 1
  %69 = load i64, ptr %0, align 8, !noundef !39
  %70 = icmp eq i64 %69, 0
  br i1 %70, label %native_roots_leave.exit, label %71

71:                                               ; preds = %ok115
  %72 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %72, ptr @native_roots.0, align 8
  %73 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %74 = add i64 %73, -1
  store i64 %74, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %71, %ok115
  %v119 = tail call tailcc i64 %v118(i64 %v105, i64 0, i64 0)
  ret i64 %v119
}

define internal tailcc noundef i64 @f.9(i64 %arg0, i64 %arg1, i64 %arg2) #103 personality ptr @rust_eh_personality {
entry:
  %0 = alloca [8 x i8], align 8
  %roots = alloca { ptr, i64, i64, [1 x i64] }, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 1, ptr %1, align 8
  %2 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %3 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %3, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %4 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %5 = add i64 %4, 1
  store i64 %5, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %6 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %7 = call noundef i64 @llvm.umax.i64(i64 %5, i64 %6)
  store i64 %7, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  store i64 1, ptr %2, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %0)
  store i64 %arg2, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %0) #84, !srcloc !75600
  %8 = load i64, ptr %0, align 8, !noundef !39
  call void @llvm.lifetime.end.p0(ptr nonnull %0)
  %9 = load i64, ptr %1, align 8, !noundef !39
  %10 = icmp eq i64 %9, 0
  br i1 %10, label %native_roots_leave.exit1, label %11

11:                                               ; preds = %entry
  %12 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %12, ptr @native_roots.0, align 8
  %13 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %14 = add i64 %13, -1
  store i64 %14, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit1

native_roots_leave.exit1:                         ; preds = %11, %entry
  ret i64 %8
}

define internal tailcc noundef range(i64 1, 0) i64 @f.18(i64 %arg0, i64 %arg1) #103 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [2 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 2, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v6 = icmp ugt i64 %arg1, 4294967295
  br i1 %v6, label %then10, label %block8

then10:                                           ; preds = %entry
  call fastcc void @native_trap()
  unreachable

block8:                                           ; preds = %entry
  %v13 = trunc nuw i64 %arg1 to i32
  store i64 1, ptr %1, align 8
  %v16 = call fastcc i64 @native_array_new(i32 %v13)
  %v17 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  store i64 %v16, ptr %v17, align 8
  store i64 2, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %block8
  call fastcc void @native_trap() #111
  unreachable

10:                                               ; preds = %block8
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 16, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %26, label %ok22

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  %25 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef %25) #84
  br label %14

26:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok22:                                             ; preds = %14
  store i64 130, ptr %16, align 1
  %v29 = getelementptr i8, ptr %16, i64 8
  store i64 %v16, ptr %v29, align 1
  %27 = load i64, ptr %0, align 8, !noundef !39
  %28 = icmp eq i64 %27, 0
  br i1 %28, label %native_roots_leave.exit, label %29

29:                                               ; preds = %ok22
  %30 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %30, ptr @native_roots.0, align 8
  %31 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %32 = add i64 %31, -1
  store i64 %32, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %29, %ok22
  %33 = ptrtoint ptr %16 to i64
  ret i64 %33
}
