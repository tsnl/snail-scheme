(module
 (rec
  (type $call70 (func (param (ref $environment320) i64 i64 i64) (result i64)))
  (type $environment358 (struct (field (ref $type14)) (field (ref $type62))))
  (type $2 (func (param (ref $environment215) (ref $type14))))
  (type $call53 (func (param (ref $environment160) (ref null $type22) i64) (result i64)))
  (type $type53 (struct (field (ref $environment160))))
  (type $call61 (func (param (ref struct) i64) (result i32)))
  (type $environment194 (struct (field i64) (field i64) (field (ref $type56)) (field (ref $type62))))
  (type $environment215 (struct (field (ref $type14))))
  (type $call25 (func (param structref i64) (result (ref $type15))))
  (type $environment296 (struct (field (ref $type55)) (field i64) (field (ref $type15)) (field (ref $type56))))
  (type $environment315 (struct (field (ref $type55)) (field (ref $type69))))
  (type $type70 (struct (field (ref $environment320))))
  (type $environment320 (struct (field (ref $type55)) (field (ref $type69))))
  (type $type68 (struct (field (mut i64))))
  (type $environment333 (struct (field (ref $type66)) (field (ref $type67)) (field (ref $type66)) (field (ref $type66))))
  (type $type61 (struct (field (ref $call61)) (field (ref struct))))
  (type $type57 (struct))
  (type $environment277 (struct (field (ref $type55))))
  (type $type55 (struct (field (ref $type44))))
  (type $type67 (struct (field (mut i32)) (field (mut (ref null $type68)))))
  (type $type66 (struct (field (mut i32)) (field (mut i64))))
  (type $type69 (struct (field (mut i32)) (field (mut (ref null $type70)))))
  (type $type54 (struct (field (mut i32)) (field (mut (ref null $type53)))))
  (type $type62 (struct (field (mut i32)) (field (mut (ref null $type61)))))
  (type $type56 (struct (field (mut i32)) (field (mut (ref null $type25)))))
  (type $environment160 (struct (field (ref $type54))))
  (type $type22 (struct (field (ref null $type22))))
  (type $call46 (func (param (ref null $environment142) i64 i64) (result i64)))
  (type $environment142 (struct (field i64) (field (ref $type51))))
  (type $type51 (struct (field (mut i32)) (field (mut (ref null $type46)))))
  (type $call44 (func (param structref i64) (result i64)))
  (type $type15 (struct (field (ref $type16))))
  (type $32 (func (param (ref $type15) i64) (result (ref $type14))))
  (type $33 (func (param (ref $type14) i32) (result i32)))
  (type $34 (func (param (ref $type16) i32) (result i32)))
  (type $type44 (struct (field (ref $call44)) (field structref)))
  (type $type49 (struct))
  (type $type48 (struct))
  (type $type47 (struct (field (mut (ref null $type22)))))
  (type $type46 (struct (field (ref $call46)) (field (ref null $environment142))))
  (type $type10 (struct))
  (type $type45 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type23 (struct))
  (type $type41 (struct))
  (type $type39 (struct))
  (type $type25 (struct (field (ref $call25)) (field structref)))
  (type $type14 (struct (field i32) (field i32) (field (ref $type16)) (field (mut i32)) (field (mut i32))))
  (type $type16 (array (mut i8)))
 )
 (type $50 (func (param i64) (result i64)))
 (type $51 (func (param i32)))
 (type $52 (func (param i32) (result i64)))
 (type $53 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "write_character" (func $foreign1 (param i32)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (struct.new $type14
  (i32.const 31)
  (i32.const 31)
  (array.new_fixed $type16 31
   (i32.const 114)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 112)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 118)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $string1 (ref $type14) (struct.new $type14
  (i32.const 30)
  (i32.const 30)
  (array.new_fixed $type16 30
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 32)
   (i32.const 70)
   (i32.const 65)
   (i32.const 73)
   (i32.const 76)
   (i32.const 69)
   (i32.const 68)
   (i32.const 32)
   (i32.const 84)
   (i32.const 69)
   (i32.const 83)
   (i32.const 84)
   (i32.const 32)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 42)
   (i32.const 32)
  )
  (i32.const 0)
  (i32.const 0)
 ))
 (global $global108 (mut (ref null $type25)) (ref.null none))
 (global $ready108 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type39)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global120 (mut (ref null $type41)) (ref.null none))
 (global $ready120 (mut i32) (i32.const 0))
 (global $global150 (mut (ref null $type23)) (ref.null none))
 (global $ready150 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type42)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global328 (mut (ref null $type43)) (ref.null none))
 (global $ready328 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type45)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global125 (mut (ref null $type10)) (ref.null none))
 (global $ready125 (mut i32) (i32.const 0))
 (global $global149 (mut (ref null $type46)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type47)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type48)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global128 (mut (ref null $type49)) (ref.null none))
 (global $ready128 (mut i32) (i32.const 0))
 (global $global129 (mut i64) (i64.const 0))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global130 (mut i64) (i64.const 0))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global131 (mut i64) (i64.const 0))
 (global $ready131 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type44)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $utf8-read (type $34) (param $0 (ref $type16)) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (if
   (i32.lt_u
    (local.tee $2
     (array.get_u $type16
      (local.get $0)
      (local.get $1)
     )
    )
    (i32.const 128)
   )
   (then
    (return
     (local.get $2)
    )
   )
  )
  (local.set $2
   (i32.and
    (local.get $2)
    (i32.shr_u
     (i32.const 127)
     (local.tee $4
      (if (result i32)
       (i32.lt_u
        (local.get $2)
        (i32.const 128)
       )
       (then
        (i32.const 1)
       )
       (else
        (if (result i32)
         (i32.lt_u
          (local.get $2)
          (i32.const 224)
         )
         (then
          (i32.const 2)
         )
         (else
          (select
           (i32.const 3)
           (i32.const 4)
           (i32.lt_u
            (local.get $2)
            (i32.const 240)
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.set $3
   (i32.const 1)
  )
  (loop $label
   (local.set $2
    (i32.or
     (i32.and
      (array.get_u $type16
       (local.get $0)
       (i32.add
        (local.get $1)
        (local.get $3)
       )
      )
      (i32.const 63)
     )
     (i32.shl
      (local.get $2)
      (i32.const 6)
     )
    )
   )
   (br_if $label
    (i32.lt_u
     (local.tee $3
      (i32.add
       (local.get $3)
       (i32.const 1)
      )
     )
     (local.get $4)
    )
   )
  )
  (local.get $2)
 )
 (func $string-boundary (type $33) (param $0 (ref $type14)) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref $type16))
  (if
   (i32.lt_u
    (local.tee $4
     (struct.get $type14 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $4)
    (struct.get $type14 1
     (local.get $0)
    )
   )
   (then
    (return
     (local.get $1)
    )
   )
  )
  (local.set $3
   (struct.get $type14 4
    (local.get $0)
   )
  )
  (if
   (i32.lt_u
    (local.get $1)
    (select
     (i32.sub
      (local.tee $2
       (struct.get $type14 3
        (local.get $0)
       )
      )
      (local.get $1)
     )
     (i32.sub
      (local.get $1)
      (local.get $2)
     )
     (i32.lt_u
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (local.set $3
     (i32.const 0)
    )
    (local.set $2
     (i32.const 0)
    )
   )
  )
  (if
   (i32.lt_u
    (i32.sub
     (local.get $4)
     (local.get $1)
    )
    (select
     (i32.sub
      (local.get $2)
      (local.get $1)
     )
     (i32.sub
      (local.get $1)
      (local.get $2)
     )
     (i32.lt_u
      (local.get $1)
      (local.get $2)
     )
    )
   )
   (then
    (local.set $3
     (struct.get $type14 1
      (local.get $0)
     )
    )
    (local.set $2
     (local.get $4)
    )
   )
  )
  (local.set $5
   (struct.get $type14 2
    (local.get $0)
   )
  )
  (loop $label
   (if
    (i32.gt_u
     (local.get $1)
     (local.get $2)
    )
    (then
     (local.set $3
      (i32.add
       (if (result i32)
        (i32.lt_u
         (local.tee $4
          (array.get_u $type16
           (local.get $5)
           (local.get $3)
          )
         )
         (i32.const 128)
        )
        (then
         (i32.const 1)
        )
        (else
         (if (result i32)
          (i32.lt_u
           (local.get $4)
           (i32.const 224)
          )
          (then
           (i32.const 2)
          )
          (else
           (select
            (i32.const 3)
            (i32.const 4)
            (i32.lt_u
             (local.get $4)
             (i32.const 240)
            )
           )
          )
         )
        )
       )
       (local.get $3)
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (loop $label2
   (if
    (i32.lt_u
     (local.get $1)
     (local.get $2)
    )
    (then
     (loop $label1
      (br_if $label1
       (i32.eq
        (i32.and
         (array.get_u $type16
          (local.get $5)
          (local.tee $3
           (i32.sub
            (local.get $3)
            (i32.const 1)
           )
          )
         )
         (i32.const 192)
        )
        (i32.const 128)
       )
      )
     )
     (local.set $2
      (i32.sub
       (local.get $2)
       (i32.const 1)
      )
     )
     (br $label2)
    )
   )
  )
  (struct.set $type14 3
   (local.get $0)
   (local.get $1)
  )
  (struct.set $type14 4
   (local.get $0)
   (local.get $3)
  )
  (local.get $3)
 )
 (func $utf8->string (type $32) (param $0 (ref $type15)) (param $1 i64) (result (ref $type14))
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 (ref $type16))
  (local $8 (ref $type16))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (array.len
      (local.tee $7
       (struct.get $type15 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (i32.wrap_i64
    (local.get $1)
   )
  )
  (loop $label1
   (if
    (i32.ne
     (local.get $3)
     (local.get $5)
    )
    (then
     (local.set $4
      (i32.const 1)
     )
     (if
      (i32.ge_u
       (local.tee $2
        (array.get_u $type16
         (local.get $7)
         (local.get $3)
        )
       )
       (i32.const 128)
      )
      (then
       (if
        (i32.or
         (i32.lt_u
          (local.get $2)
          (i32.const 194)
         )
         (i32.gt_u
          (local.get $2)
          (i32.const 244)
         )
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.gt_u
         (local.tee $4
          (if (result i32)
           (i32.lt_u
            (local.get $2)
            (i32.const 128)
           )
           (then
            (i32.const 1)
           )
           (else
            (if (result i32)
             (i32.lt_u
              (local.get $2)
              (i32.const 224)
             )
             (then
              (i32.const 2)
             )
             (else
              (select
               (i32.const 3)
               (i32.const 4)
               (i32.lt_u
                (local.get $2)
                (i32.const 240)
               )
              )
             )
            )
           )
          )
         )
         (i32.sub
          (local.get $5)
          (local.get $3)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $2
        (i32.const 1)
       )
       (loop $label
        (if
         (i32.gt_u
          (i32.sub
           (array.get_u $type16
            (local.get $7)
            (i32.add
             (local.get $2)
             (local.get $3)
            )
           )
           (i32.const 128)
          )
          (i32.const 63)
         )
         (then
          (unreachable)
         )
        )
        (br_if $label
         (i32.lt_u
          (local.tee $2
           (i32.add
            (local.get $2)
            (i32.const 1)
           )
          )
          (local.get $4)
         )
        )
       )
       (if
        (i32.ne
         (if (result i32)
          (i32.lt_u
           (local.tee $2
            (call $utf8-read
             (local.get $7)
             (local.get $3)
            )
           )
           (i32.const 128)
          )
          (then
           (i32.const 1)
          )
          (else
           (if (result i32)
            (i32.lt_u
             (local.get $2)
             (i32.const 2048)
            )
            (then
             (i32.const 2)
            )
            (else
             (select
              (i32.const 3)
              (i32.const 4)
              (i32.lt_u
               (local.get $2)
               (i32.const 65536)
              )
             )
            )
           )
          )
         )
         (local.get $4)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.or
         (i32.le_u
          (i32.sub
           (local.get $2)
           (i32.const 55296)
          )
          (i32.const 2047)
         )
         (i32.gt_u
          (local.get $2)
          (i32.const 1114111)
         )
        )
        (then
         (unreachable)
        )
       )
      )
     )
     (local.set $3
      (i32.add
       (local.get $3)
       (local.get $4)
      )
     )
     (local.set $6
      (i32.add
       (local.get $6)
       (i32.const 1)
      )
     )
     (br $label1)
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $type16 $type16
   (local.tee $8
    (array.new_default $type16
     (local.tee $3
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
   )
   (i32.const 0)
   (local.get $7)
   (i32.const 0)
   (local.get $3)
  )
  (struct.new $type14
   (local.get $6)
   (local.get $3)
   (local.get $8)
   (i32.const 0)
   (i32.const 0)
  )
 )
 (func $function133 (type $call44) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $type51))
  (local $3 (ref $type46))
  (struct.set $type51 1
   (local.tee $2
    (struct.new_default $type51)
   )
   (struct.new $type46
    (ref.func $function142)
    (struct.new $environment142
     (local.get $1)
     (local.get $2)
    )
   )
  )
  (struct.set $type51 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call46
   (struct.get $type46 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type51 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type46 0
    (local.get $3)
   )
  )
 )
 (func $function142 (type $call46) (param $0 (ref null $environment142)) (param $1 i64) (param $2 i64) (result i64)
  (local $3 (ref null $type22))
  (local $4 (ref $environment160))
  (local $5 (ref $type56))
  (local $6 (ref $type56))
  (local $7 (ref $type14))
  (local $8 (ref $type62))
  (local $9 (ref $type54))
  (local $10 (ref $type69))
  (local $11 (ref $type66))
  (local $12 (ref $type66))
  (local $13 (ref $type66))
  (local $14 (ref $type67))
  (local $15 (ref $type55))
  (local $16 (ref $type15))
  (local $17 (ref $type15))
  (local $18 (ref $environment277))
  (local $19 (ref $type44))
  (local $20 (ref $type25))
  (local $21 (ref $type16))
  (local $22 (ref $type61))
  (local $23 i32)
  (local $24 i32)
  (local $25 i64)
  (local $26 i64)
  (if (result i64)
   (i64.gt_s
    (struct.get $environment142 0
     (local.get $0)
    )
    (local.get $1)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready129)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready149)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type46 1
      (global.get $global149)
     )
    )
    (local.set $25
     (call $foreign0
      (global.get $global129)
     )
    )
    (drop
     (struct.get $environment142 0
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready149)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type46 1
      (global.get $global149)
     )
    )
    (local.set $26
     (call $foreign0
      (global.get $global130)
     )
    )
    (if
     (i32.eqz
      (global.get $ready128)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global128)
     )
    )
    (local.set $15
     (struct.new $type55
      (struct.new $type44
       (ref.func $function333)
       (struct.new $environment333
        (local.tee $11
         (struct.new_default $type66)
        )
        (local.tee $14
         (struct.new_default $type67)
        )
        (local.tee $12
         (struct.new_default $type66)
        )
        (local.tee $13
         (struct.new_default $type66)
        )
       )
      )
     )
    )
    (struct.set $type66 1
     (local.get $11)
     (i64.const 701)
    )
    (struct.set $type66 0
     (local.get $11)
     (i32.const 1)
    )
    (struct.set $type67 1
     (local.get $14)
     (struct.new $type68
      (i64.const 1)
     )
    )
    (struct.set $type67 0
     (local.get $14)
     (i32.const 1)
    )
    (struct.set $type66 1
     (local.get $12)
     (i64.const 743483)
    )
    (struct.set $type66 0
     (local.get $12)
     (i32.const 1)
    )
    (struct.set $type66 1
     (local.get $13)
     (i64.const 524287)
    )
    (struct.set $type66 0
     (local.get $13)
     (i32.const 1)
    )
    (struct.set $type69 1
     (local.tee $10
      (struct.new_default $type69)
     )
     (struct.new $type70
      (struct.new $environment320
       (local.get $15)
       (local.get $10)
      )
     )
    )
    (struct.set $type69 0
     (local.get $10)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (local.tee $6
        (struct.new $type56
         (i32.const 1)
         (struct.new $type25
          (ref.func $function277)
          (struct.new $environment277
           (struct.new $type55
            (struct.new $type44
             (ref.func $function315)
             (struct.new $environment315
              (local.get $15)
              (local.get $10)
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call_ref $call44
      (struct.get $type44 1
       (local.tee $19
        (struct.get $type55 0
         (struct.get $environment277 0
          (local.tee $18
           (ref.cast (ref $environment277)
            (struct.get $type25 1
             (struct.get $type56 1
              (local.get $6)
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 10)
      (struct.get $type44 0
       (local.get $19)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready108)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type25 1
      (global.get $global108)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type56 1
     (local.tee $5
      (struct.new_default $type56)
     )
     (struct.new $type25
      (ref.func $function296)
      (struct.new $environment296
       (struct.get $environment277 0
        (local.get $18)
       )
       (local.get $2)
       (struct.new $type15
        (array.new_default $type16
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (local.get $5)
      )
     )
    )
    (struct.set $type56 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $16
     (call_ref $call25
      (struct.get $type25 1
       (local.tee $20
        (ref.as_non_null
         (struct.get $type56 1
          (local.get $5)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type25 0
       (local.get $20)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (if
     (i32.eqz
      (global.get $ready120)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (call $function215
     (struct.new $environment215
      (local.tee $7
       (call $utf8->string
        (local.get $16)
        (i64.extend_i32_u
         (array.len
          (struct.get $type15 0
           (local.get $16)
          )
         )
        )
       )
      )
     )
     (block (result (ref $type14))
      (if
       (i64.lt_u
        (local.tee $2
         (i64.extend_i32_u
          (struct.get $type14 0
           (local.get $7)
          )
         )
        )
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $23
       (call $string-boundary
        (local.get $7)
        (i32.const 0)
       )
      )
      (array.copy $type16 $type16
       (local.tee $21
        (array.new_default $type16
         (local.tee $24
          (i32.sub
           (call $string-boundary
            (local.get $7)
            (i32.wrap_i64
             (local.get $2)
            )
           )
           (local.get $23)
          )
         )
        )
       )
       (i32.const 0)
       (struct.get $type14 2
        (local.get $7)
       )
       (local.get $23)
       (local.get $24)
      )
      (call $utf8->string
       (local.tee $17
        (struct.new $type15
         (local.get $21)
        )
       )
       (i64.extend_i32_u
        (array.len
         (struct.get $type15 0
          (local.get $17)
         )
        )
       )
      )
     )
    )
    (struct.set $type62 1
     (local.tee $8
      (struct.new_default $type62)
     )
     (struct.new $type61
      (ref.func $function194)
      (struct.new $environment194
       (local.get $25)
       (local.get $26)
       (local.get $6)
       (local.get $8)
      )
     )
    )
    (struct.set $type62 0
     (local.get $8)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (local.get $8)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call61
      (struct.get $type61 1
       (local.tee $22
        (ref.as_non_null
         (struct.get $type62 1
          (local.get $8)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type61 0
       (local.get $22)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready126)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type47 0
      (global.get $global126)
     )
    )
    (if
     (i32.eqz
      (global.get $ready150)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global150)
     )
    )
    (struct.set $type54 1
     (local.tee $9
      (struct.new_default $type54)
     )
     (struct.new $type53
      (struct.new $environment160
       (local.get $9)
      )
     )
    )
    (struct.set $type54 0
     (local.get $9)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type54 0
       (local.get $9)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (struct.get $type53 0
      (struct.get $type54 1
       (local.get $9)
      )
     )
    )
    (local.set $2
     (if (result i64)
      (ref.is_null
       (local.get $3)
      )
      (then
       (i64.const 0)
      )
      (else
       (local.set $3
        (struct.get $type22 0
         (local.get $3)
        )
       )
       (if
        (i32.eqz
         (struct.get $type54 0
          (struct.get $environment160 0
           (local.get $4)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type53 0
         (struct.get $type54 1
          (struct.get $environment160 0
           (local.get $4)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $3)
        )
        (then
         (i64.const 1)
        )
        (else
         (local.set $3
          (struct.get $type22 0
           (local.get $3)
          )
         )
         (if
          (i32.eqz
           (struct.get $type54 0
            (struct.get $environment160 0
             (local.get $4)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $4
          (struct.get $type53 0
           (struct.get $type54 1
            (struct.get $environment160 0
             (local.get $4)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (i64.const 2)
          )
          (else
           (local.set $3
            (struct.get $type22 0
             (local.get $3)
            )
           )
           (if
            (i32.eqz
             (struct.get $type54 0
              (struct.get $environment160 0
               (local.get $4)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $4
            (struct.get $type53 0
             (struct.get $type54 1
              (struct.get $environment160 0
               (local.get $4)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $3)
            )
            (then
             (i64.const 3)
            )
            (else
             (local.set $3
              (struct.get $type22 0
               (local.get $3)
              )
             )
             (if
              (i32.eqz
               (struct.get $type54 0
                (struct.get $environment160 0
                 (local.get $4)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $4
              (struct.get $type53 0
               (struct.get $type54 1
                (struct.get $environment160 0
                 (local.get $4)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $3)
              )
              (then
               (i64.const 4)
              )
              (else
               (local.set $3
                (struct.get $type22 0
                 (local.get $3)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type54 0
                  (struct.get $environment160 0
                   (local.get $4)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $4
                (struct.get $type53 0
                 (struct.get $type54 1
                  (struct.get $environment160 0
                   (local.get $4)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (i64.const 5)
                )
                (else
                 (local.set $3
                  (struct.get $type22 0
                   (local.get $3)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type54 0
                    (struct.get $environment160 0
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $4
                  (struct.get $type53 0
                   (struct.get $type54 1
                    (struct.get $environment160 0
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $3)
                  )
                  (then
                   (i64.const 6)
                  )
                  (else
                   (local.set $3
                    (struct.get $type22 0
                     (local.get $3)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type54 0
                      (struct.get $environment160 0
                       (local.get $4)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $4
                    (struct.get $type53 0
                     (struct.get $type54 1
                      (struct.get $environment160 0
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (i64.const 7)
                    )
                    (else
                     (local.set $3
                      (struct.get $type22 0
                       (local.get $3)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type54 0
                        (struct.get $environment160 0
                         (local.get $4)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $4
                      (struct.get $type53 0
                       (struct.get $type54 1
                        (struct.get $environment160 0
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (if (result i64)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (i64.const 8)
                      )
                      (else
                       (local.set $3
                        (struct.get $type22 0
                         (local.get $3)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type54 0
                          (struct.get $environment160 0
                           (local.get $4)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $4
                        (struct.get $type53 0
                         (struct.get $type54 1
                          (struct.get $environment160 0
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (if (result i64)
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (i64.const 9)
                        )
                        (else
                         (local.set $3
                          (struct.get $type22 0
                           (local.get $3)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type54 0
                            (struct.get $environment160 0
                             (local.get $4)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $4
                          (struct.get $type53 0
                           (struct.get $type54 1
                            (struct.get $environment160 0
                             (local.get $4)
                            )
                           )
                          )
                         )
                         (if (result i64)
                          (ref.is_null
                           (local.get $3)
                          )
                          (then
                           (i64.const 10)
                          )
                          (else
                           (local.set $3
                            (struct.get $type22 0
                             (local.get $3)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type54 0
                              (struct.get $environment160 0
                               (local.get $4)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $4
                            (struct.get $type53 0
                             (struct.get $type54 1
                              (struct.get $environment160 0
                               (local.get $4)
                              )
                             )
                            )
                           )
                           (if (result i64)
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (i64.const 11)
                            )
                            (else
                             (local.set $3
                              (struct.get $type22 0
                               (local.get $3)
                              )
                             )
                             (if
                              (i32.eqz
                               (struct.get $type54 0
                                (struct.get $environment160 0
                                 (local.get $4)
                                )
                               )
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (local.set $4
                              (struct.get $type53 0
                               (struct.get $type54 1
                                (struct.get $environment160 0
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (if (result i64)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (i64.const 12)
                              )
                              (else
                               (local.set $3
                                (struct.get $type22 0
                                 (local.get $3)
                                )
                               )
                               (if
                                (i32.eqz
                                 (struct.get $type54 0
                                  (struct.get $environment160 0
                                   (local.get $4)
                                  )
                                 )
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (local.set $4
                                (struct.get $type53 0
                                 (struct.get $type54 1
                                  (struct.get $environment160 0
                                   (local.get $4)
                                  )
                                 )
                                )
                               )
                               (if (result i64)
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (i64.const 13)
                                )
                                (else
                                 (local.set $3
                                  (struct.get $type22 0
                                   (local.get $3)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (struct.get $type54 0
                                    (struct.get $environment160 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (call $function160
                                  (struct.get $type53 0
                                   (struct.get $type54 1
                                    (struct.get $environment160 0
                                     (local.get $4)
                                    )
                                   )
                                  )
                                  (local.get $3)
                                  (i64.const 14)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type51 0
       (struct.get $environment142 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function142
     (struct.get $type46 1
      (struct.get $type51 1
       (struct.get $environment142 1
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (i64.gt_s
        (local.get $1)
        (i64.const 0)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready131)
         )
         (then
          (unreachable)
         )
        )
        (i64.eq
         (global.get $global131)
         (local.get $2)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function160 (type $call53) (param $0 (ref $environment160)) (param $1 (ref null $type22)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type22 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type54 0
       (struct.get $environment160 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function160
     (struct.get $type53 0
      (struct.get $type54 1
       (struct.get $environment160 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function166 (type $call46) (param $0 (ref null $environment142)) (param $1 i64) (param $2 i64) (result i64)
  (call $foreign0
   (local.get $2)
  )
 )
 (func $function194 (type $call61) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref $environment194))
  (local $6 (ref $type56))
  (local $7 (ref $type14))
  (local $8 (ref $type15))
  (local $9 (ref $type15))
  (local $10 (ref $environment277))
  (local $11 (ref $type44))
  (local $12 (ref $type25))
  (local $13 (ref $type16))
  (if (result i32)
   (i64.eq
    (struct.get $environment194 0
     (ref.cast (ref $environment194)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $2
     (struct.get $environment194 1
      (local.tee $5
       (ref.cast (ref $environment194)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment194 2
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call_ref $call44
      (struct.get $type44 1
       (local.tee $11
        (struct.get $type55 0
         (struct.get $environment277 0
          (local.tee $10
           (ref.cast (ref $environment277)
            (struct.get $type25 1
             (struct.get $type56 1
              (struct.get $environment194 2
               (local.get $5)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (local.get $2)
      (struct.get $type44 0
       (local.get $11)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready108)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type25 1
      (global.get $global108)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type56 1
     (local.tee $6
      (struct.new_default $type56)
     )
     (struct.new $type25
      (ref.func $function296)
      (struct.new $environment296
       (struct.get $environment277 0
        (local.get $10)
       )
       (local.get $2)
       (struct.new $type15
        (array.new_default $type16
         (i32.wrap_i64
          (local.get $2)
         )
        )
       )
       (local.get $6)
      )
     )
    )
    (struct.set $type56 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $8
     (call_ref $call25
      (struct.get $type25 1
       (local.tee $12
        (ref.as_non_null
         (struct.get $type56 1
          (local.get $6)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type25 0
       (local.get $12)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready118)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global118)
     )
    )
    (if
     (i32.eqz
      (global.get $ready120)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global120)
     )
    )
    (call $function215
     (struct.new $environment215
      (local.tee $7
       (call $utf8->string
        (local.get $8)
        (i64.extend_i32_u
         (array.len
          (struct.get $type15 0
           (local.get $8)
          )
         )
        )
       )
      )
     )
     (block (result (ref $type14))
      (if
       (i64.lt_u
        (local.tee $2
         (i64.extend_i32_u
          (struct.get $type14 0
           (local.get $7)
          )
         )
        )
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $string-boundary
        (local.get $7)
        (i32.const 0)
       )
      )
      (array.copy $type16 $type16
       (local.tee $13
        (array.new_default $type16
         (local.tee $4
          (i32.sub
           (call $string-boundary
            (local.get $7)
            (i32.wrap_i64
             (local.get $2)
            )
           )
           (local.get $3)
          )
         )
        )
       )
       (i32.const 0)
       (struct.get $type14 2
        (local.get $7)
       )
       (local.get $3)
       (local.get $4)
      )
      (call $utf8->string
       (local.tee $9
        (struct.new $type15
         (local.get $13)
        )
       )
       (i64.extend_i32_u
        (array.len
         (struct.get $type15 0
          (local.get $9)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (struct.get $environment194 3
        (local.get $5)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function194
     (struct.get $type61 1
      (struct.get $type62 1
       (struct.get $environment194 3
        (local.get $5)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function215 (type $2) (param $0 (ref $environment215)) (param $1 (ref $type14))
  (local $2 (ref $type62))
  (local $3 (ref $type61))
  (local $4 (ref $type14))
  (local $5 (ref $type16))
  (local $6 (ref $type16))
  (local $7 (ref $type47))
  (local $8 i32)
  (local $9 i32)
  (local $scratch i32)
  (if
   (i32.eqz
    (block (result i32)
     (local.set $scratch
      (block $block (result i32)
       (drop
        (br_if $block
         (i32.const 1)
         (ref.eq
          (local.tee $4
           (struct.get $environment215 0
            (local.get $0)
           )
          )
          (local.get $1)
         )
        )
       )
       (drop
        (br_if $block
         (i32.const 0)
         (i32.ne
          (local.tee $9
           (struct.get $type14 1
            (local.get $4)
           )
          )
          (struct.get $type14 1
           (local.get $1)
          )
         )
        )
       )
       (local.set $5
        (struct.get $type14 2
         (local.get $4)
        )
       )
       (local.set $6
        (struct.get $type14 2
         (local.get $1)
        )
       )
       (loop $label
        (if
         (i32.ne
          (local.get $8)
          (local.get $9)
         )
         (then
          (if
           (i32.ne
            (array.get_u $type16
             (local.get $5)
             (local.get $8)
            )
            (array.get_u $type16
             (local.get $6)
             (local.get $8)
            )
           )
           (then
            (br $block
             (i32.const 0)
            )
           )
           (else
            (local.set $8
             (i32.add
              (local.get $8)
              (i32.const 1)
             )
            )
            (br $label)
           )
          )
          (unreachable)
         )
        )
       )
       (i32.const 1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready127)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global127)
      )
     )
     (if
      (i32.eqz
       (global.get $ready121)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global121)
      )
     )
     (local.get $scratch)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (struct.set $type62 1
     (local.tee $2
      (struct.new_default $type62)
     )
     (struct.new $type61
      (ref.func $function358)
      (struct.new $environment358
       (global.get $string1)
       (local.get $2)
      )
     )
    )
    (struct.set $type62 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call61
      (struct.get $type61 1
       (local.tee $3
        (ref.as_non_null
         (struct.get $type62 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type61 0
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (struct.set $type62 1
     (local.tee $2
      (struct.new_default $type62)
     )
     (struct.new $type61
      (ref.func $function358)
      (struct.new $environment358
       (global.get $string0)
       (local.get $2)
      )
     )
    )
    (struct.set $type62 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call61
      (struct.get $type61 1
       (local.tee $3
        (ref.as_non_null
         (struct.get $type62 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 0)
      (struct.get $type61 0
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready125)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global125)
     )
    )
    (call $foreign1
     (i32.const 10)
    )
    (if
     (i32.eqz
      (global.get $ready126)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type47 0
     (ref.as_non_null
      (global.get $global126)
     )
     (block (result (ref (exact $type22)))
      (if
       (i32.eqz
        (global.get $ready126)
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type22
       (struct.get $type47 0
        (global.get $global126)
       )
      )
     )
    )
   )
  )
 )
 (func $function277 (type $call25) (param $0 structref) (param $1 i64) (result (ref $type15))
  (local $2 (ref $type56))
  (local $3 (ref $environment277))
  (local $4 (ref $type44))
  (local $5 (ref $type25))
  (local.set $1
   (call_ref $call44
    (struct.get $type44 1
     (local.tee $4
      (struct.get $type55 0
       (struct.get $environment277 0
        (local.tee $3
         (ref.cast (ref $environment277)
          (local.get $0)
         )
        )
       )
      )
     )
    )
    (local.get $1)
    (struct.get $type44 0
     (local.get $4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready108)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type25 1
    (global.get $global108)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type56 1
   (local.tee $2
    (struct.new_default $type56)
   )
   (struct.new $type25
    (ref.func $function296)
    (struct.new $environment296
     (struct.get $environment277 0
      (local.get $3)
     )
     (local.get $1)
     (struct.new $type15
      (array.new_default $type16
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type56 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type56 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call25
   (struct.get $type25 1
    (local.tee $5
     (ref.as_non_null
      (struct.get $type56 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type25 0
    (local.get $5)
   )
  )
 )
 (func $function296 (type $call25) (param $0 structref) (param $1 i64) (result (ref $type15))
  (local $2 (ref $environment296))
  (local $3 (ref $type44))
  (local $4 i64)
  (if (result (ref $type15))
   (i64.eq
    (struct.get $environment296 1
     (local.tee $2
      (ref.cast (ref $environment296)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (struct.get $environment296 2
     (local.get $2)
    )
   )
   (else
    (local.set $4
     (call_ref $call44
      (struct.get $type44 1
       (local.tee $3
        (struct.get $type55 0
         (struct.get $environment296 0
          (local.get $2)
         )
        )
       )
      )
      (i64.const 128)
      (struct.get $type44 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type16
     (struct.get $type15 0
      (struct.get $environment296 2
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (struct.get $type56 0
       (struct.get $environment296 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function296
     (struct.get $type25 1
      (struct.get $type56 1
       (struct.get $environment296 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function315 (type $call44) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment315))
  (local $3 i64)
  (if
   (i64.lt_s
    (local.get $1)
    (i64.const 16384)
   )
   (then
    (return_call $function333
     (struct.get $type44 1
      (struct.get $type55 0
       (struct.get $environment315 0
        (ref.cast (ref $environment315)
         (local.get $0)
        )
       )
      )
     )
     (local.get $1)
    )
   )
   (else
    (local.set $3
     (call $function333
      (struct.get $type44 1
       (struct.get $type55 0
        (struct.get $environment315 0
         (local.tee $2
          (ref.cast (ref $environment315)
           (local.get $0)
          )
         )
        )
       )
      )
      (i64.const 16384)
     )
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment315 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function320
     (struct.get $type70 0
      (struct.get $type69 1
       (struct.get $environment315 1
        (local.get $2)
       )
      )
     )
     (i64.div_s
      (local.get $1)
      (i64.const 16384)
     )
     (local.get $3)
     (local.get $1)
    )
   )
  )
  (unreachable)
 )
 (func $function320 (type $call70) (param $0 (ref $environment320)) (param $1 i64) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i64)
  (if
   (i32.eqz
    (global.get $ready328)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global328)
   )
  )
  (if (result i64)
   (i64.eqz
    (local.get $1)
   )
   (then
    (i64.rem_s
     (local.get $2)
     (local.get $3)
    )
   )
   (else
    (local.set $4
     (call $function333
      (struct.get $type44 1
       (struct.get $type55 0
        (struct.get $environment320 0
         (local.get $0)
        )
       )
      )
      (i64.const 16384)
     )
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment320 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function320
     (struct.get $type70 0
      (struct.get $type69 1
       (struct.get $environment320 1
        (local.get $0)
       )
      )
     )
     (i64.div_s
      (local.get $1)
      (i64.const 16384)
     )
     (i64.add
      (local.get $4)
      (i64.shl
       (local.get $2)
       (i64.const 14)
      )
     )
     (local.get $3)
    )
   )
  )
 )
 (func $function333 (type $call44) (param $0 structref) (param $1 i64) (result i64)
  (local $2 (ref $environment333))
  (local $3 (ref $type68))
  (local $4 i64)
  (if
   (i32.eqz
    (struct.get $type67 0
     (struct.get $environment333 1
      (ref.cast (ref $environment333)
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type68 0
   (ref.as_non_null
    (struct.get $type67 1
     (struct.get $environment333 1
      (local.tee $2
       (ref.cast (ref $environment333)
        (local.get $0)
       )
      )
     )
    )
   )
   (block (result i64)
    (if
     (i32.eqz
      (struct.get $type66 0
       (struct.get $environment333 0
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (struct.get $type67 0
       (struct.get $environment333 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (i64.rem_s
     (i64.add
      (i64.mul
       (struct.get $type68 0
        (struct.get $type67 1
         (struct.get $environment333 1
          (local.get $2)
         )
        )
       )
       (block (result i64)
        (if
         (i32.eqz
          (struct.get $type66 0
           (struct.get $environment333 2
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (struct.get $type66 0
           (struct.get $environment333 3
            (local.get $2)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (struct.get $type66 1
         (struct.get $environment333 0
          (local.get $2)
         )
        )
       )
      )
      (struct.get $type66 1
       (struct.get $environment333 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (struct.get $type66 1
       (struct.get $environment333 3
        (local.get $2)
       )
      )
      (i64.const 1)
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type67 0
     (struct.get $environment333 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (i64.rem_s
   (i64.div_s
    (struct.get $type68 0
     (struct.get $type67 1
      (struct.get $environment333 1
       (local.get $2)
      )
     )
    )
    (i64.const 8)
   )
   (local.get $1)
  )
 )
 (func $function358 (type $call61) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment358))
  (local $3 (ref $type14))
  (if (result i32)
   (i64.eq
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type14 0
      (struct.get $environment358 0
       (ref.cast (ref $environment358)
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $1)
      (i64.extend_i32_u
       (struct.get $type14 0
        (local.tee $3
         (struct.get $environment358 0
          (local.tee $2
           (ref.cast (ref $environment358)
            (local.get $0)
           )
          )
         )
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (call $utf8-read
      (struct.get $type14 2
       (local.get $3)
      )
      (call $string-boundary
       (local.get $3)
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type62 0
       (struct.get $environment358 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function358
     (struct.get $type61 1
      (struct.get $type62 1
       (struct.get $environment358 1
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function522 (type $call25) (param $0 structref) (param $1 i64) (result (ref $type15))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.new $type15
   (array.new_default $type16
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type51))
  (local $2 (ref $type46))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type44 1
    (global.get $global132)
   )
  )
  (struct.set $type51 1
   (local.tee $1
    (struct.new_default $type51)
   )
   (struct.new $type46
    (ref.func $function142)
    (struct.new $environment142
     (local.get $0)
     (local.get $1)
    )
   )
  )
  (struct.set $type51 0
   (local.get $1)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type51 0
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call46
   (struct.get $type46 1
    (local.tee $2
     (ref.as_non_null
      (struct.get $type51 1
       (local.get $1)
      )
     )
    )
   )
   (i64.const 0)
   (i64.const 0)
   (struct.get $type46 0
    (local.get $2)
   )
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global108
   (struct.new $type25
    (ref.func $function522)
    (ref.null none)
   )
  )
  (global.set $ready108
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type39)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global120
   (struct.new_default $type41)
  )
  (global.set $ready120
   (i32.const 1)
  )
  (global.set $global150
   (struct.new_default $type23)
  )
  (global.set $ready150
   (i32.const 1)
  )
  (global.set $global121
   (struct.new_default $type42)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $global328
   (struct.new_default $type43)
  )
  (global.set $ready328
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type45)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global125
   (struct.new_default $type10)
  )
  (global.set $ready125
   (i32.const 1)
  )
  (global.set $global149
   (struct.new $type46
    (ref.func $function166)
    (ref.null none)
   )
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global126
   (struct.new_default $type47)
  )
  (global.set $ready126
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type48)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global128
   (struct.new_default $type49)
  )
  (global.set $ready128
   (i32.const 1)
  )
  (global.set $global129
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global130
   (call $foreign2
    (i32.const 1)
   )
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global131
   (call $foreign2
    (i32.const 2)
   )
  )
  (global.set $ready131
   (i32.const 1)
  )
  (global.set $global132
   (struct.new $type44
    (ref.func $function133)
    (ref.null none)
   )
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

