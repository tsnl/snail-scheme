define internal tailcc i64 @f.2(i64 %arg0, i64 %arg1, i64 %arg2) #102 personality ptr @rust_eh_personality {
entry:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %roots = alloca { ptr, i64, i64, [6 x i64] }, align 8
  %2 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 6, ptr %2, align 8
  %3 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %3, align 8
  %4 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %4, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %6 = add i64 %5, 1
  store i64 %6, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %7 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %8 = call noundef i64 @llvm.umax.i64(i64 %6, i64 %7)
  store i64 %8, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v4, i8 0, i64 16, i1 false)
  %9 = icmp ne i64 %arg0, 0
  %10 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %10, 0
  %or.cond = and i1 %9, %.not.i
  br i1 %or.cond, label %11, label %trap12

11:                                               ; preds = %entry
  %12 = inttoptr i64 %arg0 to ptr
  %13 = load i64, ptr %12, align 8, !noundef !39
  %14 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %15 = icmp eq ptr %14, null
  br i1 %15, label %28, label %16

16:                                               ; preds = %11
  switch i64 %13, label %17 [
    i64 34, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

17:                                               ; preds = %16
  %18 = getelementptr inbounds nuw i8, ptr %14, i64 360
  %19 = load i64, ptr %18, align 8, !noundef !39
  %20 = lshr i64 %13, 2
  %21 = add nsw i64 %20, -1
  %22 = icmp ult i64 %21, %19
  br i1 %22, label %23, label %.loopexit24

23:                                               ; preds = %17
  %24 = getelementptr inbounds nuw i8, ptr %14, i64 352
  %25 = load ptr, ptr %24, align 8, !nonnull !39, !noundef !39
  %26 = getelementptr inbounds nuw i64, ptr %25, i64 %21
  %27 = load i64, ptr %26, align 8, !noundef !39
  switch i64 %27, label %.preheader23 [
    i64 34, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

28:                                               ; preds = %11
  call fastcc void @native_trap() #111
  unreachable

.preheader23:                                     ; preds = %33, %23
  %29 = phi i64 [ %35, %33 ], [ %27, %23 ]
  %30 = lshr i64 %29, 2
  %31 = add nsw i64 %30, -1
  %32 = icmp ult i64 %31, %19
  br i1 %32, label %33, label %.loopexit24

.loopexit24:                                      ; preds = %.preheader23, %17
  call fastcc void @native_trap() #111
  unreachable

33:                                               ; preds = %.preheader23
  %34 = getelementptr inbounds nuw i64, ptr %25, i64 %31
  %35 = load i64, ptr %34, align 8, !noundef !39
  switch i64 %35, label %.preheader23 [
    i64 34, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %33, %33, %23, %23, %16, %16
  %.in220 = phi i64 [ %13, %16 ], [ %27, %23 ], [ %27, %23 ], [ %13, %16 ], [ %35, %33 ], [ %35, %33 ]
  %36 = icmp eq i64 %.in220, 34
  br i1 %36, label %ok13.lr.ph, label %trap12

ok13.lr.ph:                                       ; preds = %native_ref_test.exit
  %v123 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v124 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v125 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  br label %ok16

trap12:                                           ; preds = %native_ref_test.exit10, %ok262, %native_ref_test.exit, %entry
  call fastcc void @native_trap()
  unreachable

ok16:                                             ; preds = %native_ref_test.exit10, %ok13.lr.ph
  %37 = phi i64 [ %5, %ok13.lr.ph ], [ %159, %native_ref_test.exit10 ]
  %38 = phi ptr [ %4, %ok13.lr.ph ], [ %160, %native_ref_test.exit10 ]
  %arg2.tr38 = phi i64 [ %arg2, %ok13.lr.ph ], [ %v219, %native_ref_test.exit10 ]
  %arg1.tr37 = phi i64 [ %arg1, %ok13.lr.ph ], [ %v267, %native_ref_test.exit10 ]
  %arg0.tr36 = phi i64 [ %arg0, %ok13.lr.ph ], [ %v265, %native_ref_test.exit10 ]
  %v17 = inttoptr i64 %arg0.tr36 to ptr
  %v18 = getelementptr i8, ptr %v17, i64 8
  %v19 = load i64, ptr %v18, align 1
  %v21 = icmp sgt i64 %v19, %arg1.tr37
  br i1 %v21, label %then26, label %else25

then26:                                           ; preds = %ok16
  %v28.b = load i1, ptr @g.12, align 1
  br i1 %v28.b, label %block38, label %then33

then33:                                           ; preds = %then26
  call fastcc void @native_trap()
  unreachable

block38:                                          ; preds = %then26
  %v42.b = load i1, ptr @g.2, align 1
  br i1 %v42.b, label %block45, label %then47

then47:                                           ; preds = %block38
  call fastcc void @native_trap()
  unreachable

block45:                                          ; preds = %block38
  %v49 = load i64, ptr @g.1, align 8
  %v50.not = icmp eq i64 %v49, 0
  br i1 %v50.not, label %trap51, label %ok52

trap51:                                           ; preds = %block45
  call fastcc void @native_trap()
  unreachable

ok52:                                             ; preds = %block45
  %v56 = load i64, ptr @g.11, align 8
  store i64 3, ptr %3, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %1)
  store i64 %v56, ptr %1, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %1) #84, !srcloc !75600
  %39 = load i64, ptr %1, align 8, !noundef !39
  call void @llvm.lifetime.end.p0(ptr nonnull %1)
  %v59.b = load i1, ptr @g.12, align 1
  br i1 %v59.b, label %block62, label %then64

then64:                                           ; preds = %ok52
  call fastcc void @native_trap()
  unreachable

block62:                                          ; preds = %ok52
  %v66.b = load i1, ptr @g.14, align 1
  br i1 %v66.b, label %block69, label %then71

then71:                                           ; preds = %block62
  call fastcc void @native_trap()
  unreachable

block69:                                          ; preds = %block62
  %v73.b = load i1, ptr @g.2, align 1
  br i1 %v73.b, label %block76, label %then78

then78:                                           ; preds = %block69
  call fastcc void @native_trap()
  unreachable

block76:                                          ; preds = %block69
  %v80 = load i64, ptr @g.1, align 8
  %v81.not = icmp eq i64 %v80, 0
  br i1 %v81.not, label %trap82, label %ok83

trap82:                                           ; preds = %block76
  call fastcc void @native_trap()
  unreachable

ok83:                                             ; preds = %block76
  %v87 = load i64, ptr @g.13, align 8
  store i64 3, ptr %3, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %0)
  store i64 %v87, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %0) #84, !srcloc !75600
  %40 = load i64, ptr %0, align 8, !noundef !39
  call void @llvm.lifetime.end.p0(ptr nonnull %0)
  %v90.b = load i1, ptr @g.10, align 1
  br i1 %v90.b, label %block93, label %then95

then95:                                           ; preds = %ok83
  call fastcc void @native_trap()
  unreachable

block93:                                          ; preds = %ok83
  %v97 = load i64, ptr @g.9, align 8
  %v98.not = icmp eq i64 %v97, 0
  br i1 %v98.not, label %trap99, label %ok100

trap99:                                           ; preds = %block93
  call fastcc void @native_trap()
  unreachable

ok100:                                            ; preds = %block93
  store i64 3, ptr %3, align 8
  %41 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %42 = icmp eq ptr %41, null
  br i1 %42, label %43, label %44

43:                                               ; preds = %ok100
  call fastcc void @native_trap() #111
  unreachable

44:                                               ; preds = %ok100
  %45 = getelementptr inbounds nuw i8, ptr %41, i64 376
  %46 = load i64, ptr %45, align 8, !noundef !39
  %47 = icmp eq i64 %46, 0
  br i1 %47, label %48, label %52

48:                                               ; preds = %58, %52, %44
  %49 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %50 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %41, i64 noundef 24, ptr noundef %49) #84
  %51 = icmp eq ptr %50, null
  br i1 %51, label %60, label %ok108

52:                                               ; preds = %44
  %53 = getelementptr inbounds nuw i8, ptr %41, i64 368
  %54 = load i64, ptr %53, align 8, !noundef !39
  %55 = add i64 %54, 1
  store i64 %55, ptr %53, align 8
  %56 = urem i64 %55, %46
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %58, label %48

58:                                               ; preds = %52
  %59 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %41, ptr noundef %59) #84
  br label %48

60:                                               ; preds = %48
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok108:                                            ; preds = %48
  %61 = ptrtoint ptr %50 to i64
  store i64 38, ptr %50, align 1
  %v115 = getelementptr i8, ptr %50, i64 8
  store i32 0, ptr %v115, align 1
  %v120 = getelementptr i8, ptr %50, i64 16
  store i64 0, ptr %v120, align 1
  store i64 %61, ptr %v4, align 8
  store i64 %61, ptr %v123, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v124, align 8
  store i64 %61, ptr %v125, align 8
  store i64 6, ptr %3, align 8
  %62 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %63 = icmp eq ptr %62, null
  br i1 %63, label %64, label %65

64:                                               ; preds = %ok108
  call fastcc void @native_trap() #111
  unreachable

65:                                               ; preds = %ok108
  %66 = getelementptr inbounds nuw i8, ptr %62, i64 376
  %67 = load i64, ptr %66, align 8, !noundef !39
  %68 = icmp eq i64 %67, 0
  br i1 %68, label %69, label %73

69:                                               ; preds = %79, %73, %65
  %70 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %71 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %62, i64 noundef 24, ptr noundef %70) #84
  %72 = icmp eq ptr %71, null
  br i1 %72, label %81, label %ok130

73:                                               ; preds = %65
  %74 = getelementptr inbounds nuw i8, ptr %62, i64 368
  %75 = load i64, ptr %74, align 8, !noundef !39
  %76 = add i64 %75, 1
  store i64 %76, ptr %74, align 8
  %77 = urem i64 %76, %67
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %79, label %69

79:                                               ; preds = %73
  %80 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %62, ptr noundef %80) #84
  br label %69

81:                                               ; preds = %69
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok130:                                            ; preds = %69
  %82 = ptrtoint ptr %71 to i64
  store i64 30, ptr %71, align 1
  %v137 = getelementptr i8, ptr %71, i64 8
  store i64 %40, ptr %v137, align 1
  %v142 = getelementptr i8, ptr %71, i64 16
  store i64 %61, ptr %v142, align 1
  store i64 %82, ptr %v123, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v124, align 8
  store i64 %61, ptr %v125, align 8
  store i64 6, ptr %3, align 8
  %83 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %84 = icmp eq ptr %83, null
  br i1 %84, label %85, label %86

85:                                               ; preds = %ok130
  call fastcc void @native_trap() #111
  unreachable

86:                                               ; preds = %ok130
  %87 = getelementptr inbounds nuw i8, ptr %83, i64 376
  %88 = load i64, ptr %87, align 8, !noundef !39
  %89 = icmp eq i64 %88, 0
  br i1 %89, label %90, label %94

90:                                               ; preds = %100, %94, %86
  %91 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %92 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %83, i64 noundef 24, ptr noundef %91) #84
  %93 = icmp eq ptr %92, null
  br i1 %93, label %102, label %ok150

94:                                               ; preds = %86
  %95 = getelementptr inbounds nuw i8, ptr %83, i64 368
  %96 = load i64, ptr %95, align 8, !noundef !39
  %97 = add i64 %96, 1
  store i64 %97, ptr %95, align 8
  %98 = urem i64 %97, %88
  %99 = icmp eq i64 %98, 0
  br i1 %99, label %100, label %90

100:                                              ; preds = %94
  %101 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %83, ptr noundef %101) #84
  br label %90

102:                                              ; preds = %90
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok150:                                            ; preds = %90
  %103 = ptrtoint ptr %92 to i64
  store i64 58, ptr %92, align 1
  %v157 = getelementptr i8, ptr %92, i64 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v157, align 1
  %v162 = getelementptr i8, ptr %92, i64 16
  store i64 %82, ptr %v162, align 1
  store i64 %103, ptr %v120, align 1
  %v168 = load i64, ptr %v4, align 8
  %v169.not = icmp eq i64 %v168, 0
  br i1 %v169.not, label %trap170, label %ok171

trap170:                                          ; preds = %ok150
  call fastcc void @native_trap()
  unreachable

ok171:                                            ; preds = %ok150
  %v172 = inttoptr i64 %v168 to ptr
  %v173 = getelementptr i8, ptr %v172, i64 8
  store i32 1, ptr %v173, align 1
  %v174 = load i64, ptr %v4, align 8
  %v175.not = icmp eq i64 %v174, 0
  br i1 %v175.not, label %trap176, label %ok177

trap176:                                          ; preds = %ok171
  call fastcc void @native_trap()
  unreachable

ok177:                                            ; preds = %ok171
  %v178 = inttoptr i64 %v174 to ptr
  %v179 = getelementptr i8, ptr %v178, i64 8
  %v180 = load i32, ptr %v179, align 1
  %v181 = icmp eq i32 %v180, 0
  br i1 %v181, label %then185, label %ok190

then185:                                          ; preds = %ok177
  call fastcc void @native_trap()
  unreachable

ok190:                                            ; preds = %ok177
  %v192 = getelementptr i8, ptr %v178, i64 16
  %v193 = load i64, ptr %v192, align 1
  %v194.not = icmp eq i64 %v193, 0
  br i1 %v194.not, label %trap195, label %ok196

trap195:                                          ; preds = %ok190
  call fastcc void @native_trap()
  unreachable

ok196:                                            ; preds = %ok190
  store i64 %v193, ptr %v5, align 8
  %v200 = inttoptr i64 %v193 to ptr
  %v209 = getelementptr i8, ptr %v200, i64 8
  %v210 = load i64, ptr %v209, align 1
  %v211.not = icmp eq i64 %v210, 0
  br i1 %v211.not, label %trap212, label %ok213

trap212:                                          ; preds = %ok196
  call fastcc void @native_trap()
  unreachable

ok213:                                            ; preds = %ok196
  %v201 = getelementptr i8, ptr %v200, i64 16
  %v202 = load i64, ptr %v201, align 1
  %v214 = inttoptr i64 %v210 to ptr
  %v215 = getelementptr i8, ptr %v214, i64 8
  %v216 = load ptr, ptr %v215, align 1
  store i64 %v202, ptr %v123, align 8
  store i64 4, ptr %3, align 8
  %v219 = call tailcc i64 %v216(i64 %v202, i64 %39, i64 0)
  %v220 = load i64, ptr %v1, align 8
  %104 = icmp ne i64 %v220, 0
  %105 = and i64 %v220, 1
  %.not.i4 = icmp eq i64 %105, 0
  %or.cond196 = and i1 %104, %.not.i4
  br i1 %or.cond196, label %106, label %trap223

106:                                              ; preds = %ok213
  %107 = inttoptr i64 %v220 to ptr
  %108 = load i64, ptr %107, align 8, !noundef !39
  %109 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %110 = icmp eq ptr %109, null
  br i1 %110, label %125, label %111

111:                                              ; preds = %106
  %112 = icmp eq i64 %108, 34
  switch i64 %108, label %113 [
    i64 34, label %native_ref_test.exit5
    i64 0, label %native_ref_test.exit5
  ]

113:                                              ; preds = %111
  %114 = getelementptr inbounds nuw i8, ptr %109, i64 360
  %115 = load i64, ptr %114, align 8, !noundef !39
  %116 = lshr i64 %108, 2
  %117 = add nsw i64 %116, -1
  %118 = icmp ult i64 %117, %115
  br i1 %118, label %119, label %.loopexit19

119:                                              ; preds = %113
  %120 = getelementptr inbounds nuw i8, ptr %109, i64 352
  %121 = load ptr, ptr %120, align 8, !nonnull !39, !noundef !39
  %122 = getelementptr inbounds nuw i64, ptr %121, i64 %117
  %123 = load i64, ptr %122, align 8, !noundef !39
  %124 = icmp eq i64 %123, 34
  switch i64 %123, label %.preheader18 [
    i64 34, label %native_ref_test.exit5
    i64 0, label %native_ref_test.exit5
  ]

125:                                              ; preds = %106
  call fastcc void @native_trap() #111
  unreachable

.preheader18:                                     ; preds = %130, %119
  %126 = phi i64 [ %132, %130 ], [ %123, %119 ]
  %127 = lshr i64 %126, 2
  %128 = add nsw i64 %127, -1
  %129 = icmp ult i64 %128, %115
  br i1 %129, label %130, label %.loopexit19

.loopexit19:                                      ; preds = %.preheader18, %113
  call fastcc void @native_trap() #111
  unreachable

130:                                              ; preds = %.preheader18
  %131 = getelementptr inbounds nuw i64, ptr %121, i64 %128
  %132 = load i64, ptr %131, align 8, !noundef !39
  switch i64 %132, label %.preheader18 [
    i64 34, label %native_ref_test.exit5.loopexit
    i64 0, label %native_ref_test.exit5.loopexit
  ]

native_ref_test.exit5.loopexit:                   ; preds = %130, %130
  %.lcssa328 = phi i64 [ %132, %130 ], [ %132, %130 ]
  %133 = icmp eq i64 %.lcssa328, 34
  br i1 %133, label %ok227, label %trap223

native_ref_test.exit5:                            ; preds = %119, %119, %111, %111
  %134 = phi i1 [ %112, %111 ], [ %124, %119 ], [ %124, %119 ], [ %112, %111 ]
  br i1 %134, label %ok227, label %trap223

trap223:                                          ; preds = %native_ref_test.exit5, %native_ref_test.exit5.loopexit, %ok213
  call fastcc void @native_trap()
  unreachable

ok227:                                            ; preds = %native_ref_test.exit5, %native_ref_test.exit5.loopexit
  %v229 = getelementptr i8, ptr %107, i64 16
  %v230 = load i64, ptr %v229, align 1
  %v231.not = icmp eq i64 %v230, 0
  br i1 %v231.not, label %trap232, label %ok233

trap232:                                          ; preds = %ok227
  call fastcc void @native_trap()
  unreachable

ok233:                                            ; preds = %ok227
  %v234 = inttoptr i64 %v230 to ptr
  %v235 = getelementptr i8, ptr %v234, i64 8
  %v236 = load i32, ptr %v235, align 1
  %v237 = icmp eq i32 %v236, 0
  br i1 %v237, label %then241, label %block239

then241:                                          ; preds = %ok233
  call fastcc void @native_trap()
  unreachable

block239:                                         ; preds = %ok233
  switch i64 %108, label %135 [
    i64 34, label %native_ref_test.exit7
    i64 0, label %native_ref_test.exit7
  ]

135:                                              ; preds = %block239
  %136 = getelementptr inbounds nuw i8, ptr %109, i64 360
  %137 = load i64, ptr %136, align 8, !noundef !39
  %138 = lshr i64 %108, 2
  %139 = add nsw i64 %138, -1
  %140 = icmp ult i64 %139, %137
  br i1 %140, label %141, label %.loopexit17

141:                                              ; preds = %135
  %142 = getelementptr inbounds nuw i8, ptr %109, i64 352
  %143 = load ptr, ptr %142, align 8, !nonnull !39, !noundef !39
  %144 = getelementptr inbounds nuw i64, ptr %143, i64 %139
  %145 = load i64, ptr %144, align 8, !noundef !39
  %146 = icmp eq i64 %145, 34
  switch i64 %145, label %.preheader16 [
    i64 34, label %native_ref_test.exit7
    i64 0, label %native_ref_test.exit7
  ]

.preheader16:                                     ; preds = %151, %141
  %147 = phi i64 [ %153, %151 ], [ %145, %141 ]
  %148 = lshr i64 %147, 2
  %149 = add nsw i64 %148, -1
  %150 = icmp ult i64 %149, %137
  br i1 %150, label %151, label %.loopexit17

.loopexit17:                                      ; preds = %.preheader16, %135
  call fastcc void @native_trap() #111
  unreachable

151:                                              ; preds = %.preheader16
  %152 = getelementptr inbounds nuw i64, ptr %143, i64 %149
  %153 = load i64, ptr %152, align 8, !noundef !39
  switch i64 %153, label %.preheader16 [
    i64 34, label %native_ref_test.exit7.loopexit
    i64 0, label %native_ref_test.exit7.loopexit
  ]

native_ref_test.exit7.loopexit:                   ; preds = %151, %151
  %.lcssa = phi i64 [ %153, %151 ], [ %153, %151 ]
  %154 = icmp eq i64 %.lcssa, 34
  br i1 %154, label %ok256, label %trap246

native_ref_test.exit7:                            ; preds = %141, %141, %block239, %block239
  %155 = phi i1 [ %112, %block239 ], [ %146, %141 ], [ %146, %141 ], [ %112, %block239 ]
  br i1 %155, label %ok256, label %trap246

trap246:                                          ; preds = %native_ref_test.exit7, %native_ref_test.exit7.loopexit
  call fastcc void @native_trap()
  unreachable

ok256:                                            ; preds = %native_ref_test.exit7, %native_ref_test.exit7.loopexit
  %v258 = getelementptr i8, ptr %v234, i64 16
  %v259 = load i64, ptr %v258, align 1
  %v260.not = icmp eq i64 %v259, 0
  br i1 %v260.not, label %trap261, label %ok262

trap261:                                          ; preds = %ok256
  call fastcc void @native_trap()
  unreachable

ok262:                                            ; preds = %ok256
  %v263 = inttoptr i64 %v259 to ptr
  %v264 = getelementptr i8, ptr %v263, i64 16
  %v265 = load i64, ptr %v264, align 1
  %v267 = add nsw i64 %arg1.tr37, 1
  %156 = load i64, ptr %2, align 8, !noundef !39
  %157 = icmp ne i64 %156, 0
  %.pre67 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %158 = sext i1 %157 to i64
  %159 = add i64 %.pre67, %158
  %roots.val = load ptr, ptr %roots, align 8
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %160 = select i1 %157, ptr %roots.val, ptr %native_roots.0.val
  store i64 6, ptr %2, align 8
  store i64 0, ptr %3, align 8
  store ptr %160, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %161 = add i64 %159, 1
  store i64 %161, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %162 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %163 = call noundef i64 @llvm.umax.i64(i64 %161, i64 %162)
  store i64 %163, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v265, ptr %v1, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v4, i8 0, i64 16, i1 false)
  %164 = icmp ne i64 %v265, 0
  %165 = and i64 %v265, 1
  %.not.i9 = icmp eq i64 %165, 0
  %or.cond197 = and i1 %164, %.not.i9
  br i1 %or.cond197, label %166, label %trap12

166:                                              ; preds = %ok262
  %167 = inttoptr i64 %v265 to ptr
  %168 = load i64, ptr %167, align 8, !noundef !39
  switch i64 %168, label %169 [
    i64 34, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

169:                                              ; preds = %166
  %170 = getelementptr inbounds nuw i8, ptr %109, i64 360
  %171 = load i64, ptr %170, align 8, !noundef !39
  %172 = lshr i64 %168, 2
  %173 = add nsw i64 %172, -1
  %174 = icmp ult i64 %173, %171
  br i1 %174, label %175, label %.loopexit

175:                                              ; preds = %169
  %176 = getelementptr inbounds nuw i8, ptr %109, i64 352
  %177 = load ptr, ptr %176, align 8, !nonnull !39, !noundef !39
  %178 = getelementptr inbounds nuw i64, ptr %177, i64 %173
  %179 = load i64, ptr %178, align 8, !noundef !39
  switch i64 %179, label %.preheader [
    i64 34, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

.preheader:                                       ; preds = %184, %175
  %180 = phi i64 [ %186, %184 ], [ %179, %175 ]
  %181 = lshr i64 %180, 2
  %182 = add nsw i64 %181, -1
  %183 = icmp ult i64 %182, %171
  br i1 %183, label %184, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %169
  call fastcc void @native_trap() #111
  unreachable

184:                                              ; preds = %.preheader
  %185 = getelementptr inbounds nuw i64, ptr %177, i64 %182
  %186 = load i64, ptr %185, align 8, !noundef !39
  switch i64 %186, label %.preheader [
    i64 34, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

native_ref_test.exit10:                           ; preds = %184, %184, %175, %175, %166, %166
  %.in = phi i64 [ %168, %166 ], [ %179, %175 ], [ %179, %175 ], [ %168, %166 ], [ %186, %184 ], [ %186, %184 ]
  %187 = icmp eq i64 %.in, 34
  br i1 %187, label %ok16, label %trap12

else25:                                           ; preds = %ok16
  %.lcssa293 = phi i64 [ %37, %ok16 ]
  %.lcssa259 = phi ptr [ %38, %ok16 ]
  %arg2.tr38.lcssa = phi i64 [ %arg2.tr38, %ok16 ]
  store ptr %.lcssa259, ptr @native_roots.0, align 8
  store i64 %.lcssa293, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  ret i64 %arg2.tr38.lcssa
}

define internal tailcc i64 @f.4(i64 %arg0, i64 %arg1, i64 %arg2) #102 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [9 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 9, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v1046 = icmp sgt i64 %arg1, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  br i1 %v1046, label %then15.lr.ph.split, label %else14

then15.lr.ph.split:                               ; preds = %entry
  %v80 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v81 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v86 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v103 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v262 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %then15.preheader

9:                                                ; preds = %then15.lr.ph.split
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 30, label %.loopexit28
    i64 0, label %.loopexit28
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit27

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader26 [
    i64 30, label %.loopexit28
    i64 0, label %.loopexit28
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #111
  unreachable

.loopexit28:                                      ; preds = %32, %32, %21, %21, %14, %14
  %.in117 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %34, %32 ], [ %34, %32 ]
  %27 = icmp eq i64 %.in117, 30
  br label %then15.preheader

then15.preheader:                                 ; preds = %.loopexit28, %then15.lr.ph.split
  %phi.call.shrunk.ph = phi i1 [ false, %then15.lr.ph.split ], [ %27, %.loopexit28 ]
  br label %then15

.preheader26:                                     ; preds = %32, %21
  %28 = phi i64 [ %34, %32 ], [ %25, %21 ]
  %29 = lshr i64 %28, 2
  %30 = add nsw i64 %29, -1
  %31 = icmp ult i64 %30, %17
  br i1 %31, label %32, label %.loopexit27

.loopexit27:                                      ; preds = %.preheader26, %15
  call fastcc void @native_trap() #111
  unreachable

32:                                               ; preds = %.preheader26
  %33 = getelementptr inbounds nuw i64, ptr %23, i64 %30
  %34 = load i64, ptr %33, align 8, !noundef !39
  switch i64 %34, label %.preheader26 [
    i64 30, label %.loopexit28
    i64 0, label %.loopexit28
  ]

then15:                                           ; preds = %then15.backedge, %then15.preheader
  %phi.call.shrunk = phi i1 [ %phi.call.shrunk.ph, %then15.preheader ], [ %phi.call.shrunk.be, %then15.backedge ]
  %arg1.tr48 = phi i64 [ %arg1, %then15.preheader ], [ %v422, %then15.backedge ]
  %arg0.tr47 = phi i64 [ %arg0, %then15.preheader ], [ %v420, %then15.backedge ]
  br i1 %phi.call.shrunk, label %ok21, label %trap20

trap20:                                           ; preds = %then15
  call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %then15
  %v22.not = icmp eq i64 %arg0.tr47, 0
  br i1 %v22.not, label %trap23, label %ok24

trap23:                                           ; preds = %ok21
  call fastcc void @native_trap()
  unreachable

ok24:                                             ; preds = %ok21
  %v25 = inttoptr i64 %arg0.tr47 to ptr
  %v26 = getelementptr i8, ptr %v25, i64 8
  %v27 = load i64, ptr %v26, align 1
  %v28.b = load i1, ptr @g.8, align 1
  br i1 %v28.b, label %block31, label %then33

then33:                                           ; preds = %ok24
  call fastcc void @native_trap()
  unreachable

block31:                                          ; preds = %ok24
  %v35 = load i64, ptr @g.7, align 8
  %v36.not = icmp eq i64 %v35, 0
  br i1 %v36.not, label %trap37, label %ok38

trap37:                                           ; preds = %block31
  call fastcc void @native_trap()
  unreachable

ok38:                                             ; preds = %block31
  %v39.b = load i1, ptr @g.4, align 1
  br i1 %v39.b, label %block42, label %then44

then44:                                           ; preds = %ok38
  call fastcc void @native_trap()
  unreachable

block42:                                          ; preds = %ok38
  %v46 = load i64, ptr @g.3, align 8
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %block42
  call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %block42
  %v54 = icmp ugt i64 %v27, 4294967295
  br i1 %v54, label %then58, label %block56

then58:                                           ; preds = %ok49
  call fastcc void @native_trap()
  unreachable

block56:                                          ; preds = %ok49
  store i64 4, ptr %1, align 8
  %35 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %36 = icmp eq ptr %35, null
  br i1 %36, label %37, label %38

37:                                               ; preds = %block56
  call fastcc void @native_trap() #111
  unreachable

38:                                               ; preds = %block56
  %39 = getelementptr inbounds nuw i8, ptr %35, i64 376
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = icmp eq i64 %40, 0
  br i1 %41, label %42, label %46

42:                                               ; preds = %52, %46, %38
  %43 = phi ptr [ %.pre, %52 ], [ %roots, %46 ], [ %roots, %38 ]
  %44 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %35, i64 noundef 24, ptr noundef %43) #84
  %45 = icmp eq ptr %44, null
  br i1 %45, label %53, label %ok64

46:                                               ; preds = %38
  %47 = getelementptr inbounds nuw i8, ptr %35, i64 368
  %48 = load i64, ptr %47, align 8, !noundef !39
  %49 = add i64 %48, 1
  store i64 %49, ptr %47, align 8
  %50 = urem i64 %49, %40
  %51 = icmp eq i64 %50, 0
  br i1 %51, label %52, label %42

52:                                               ; preds = %46
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %35, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %42

53:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok64:                                             ; preds = %42
  %54 = ptrtoint ptr %44 to i64
  store i64 26, ptr %44, align 1
  %v71 = getelementptr i8, ptr %44, i64 8
  store i32 0, ptr %v71, align 1
  %v76 = getelementptr i8, ptr %44, i64 16
  store i64 0, ptr %v76, align 1
  store i64 %54, ptr %v4, align 8
  %v79 = trunc nuw i64 %v27 to i32
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v80, align 8
  store i64 %54, ptr %v81, align 8
  store i64 6, ptr %1, align 8
  %v83 = call fastcc i64 @native_array_new(i32 %v79)
  store i64 %v83, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v81, align 8
  store i64 %54, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %55 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %56 = icmp eq ptr %55, null
  br i1 %56, label %57, label %58

57:                                               ; preds = %ok64
  call fastcc void @native_trap() #111
  unreachable

58:                                               ; preds = %ok64
  %59 = getelementptr inbounds nuw i8, ptr %55, i64 376
  %60 = load i64, ptr %59, align 8, !noundef !39
  %61 = icmp eq i64 %60, 0
  br i1 %61, label %62, label %66

62:                                               ; preds = %72, %66, %58
  %63 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %64 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %55, i64 noundef 16, ptr noundef %63) #84
  %65 = icmp eq ptr %64, null
  br i1 %65, label %74, label %ok91

66:                                               ; preds = %58
  %67 = getelementptr inbounds nuw i8, ptr %55, i64 368
  %68 = load i64, ptr %67, align 8, !noundef !39
  %69 = add i64 %68, 1
  store i64 %69, ptr %67, align 8
  %70 = urem i64 %69, %60
  %71 = icmp eq i64 %70, 0
  br i1 %71, label %72, label %62

72:                                               ; preds = %66
  %73 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %55, ptr noundef %73) #84
  br label %62

74:                                               ; preds = %62
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok91:                                             ; preds = %62
  %75 = ptrtoint ptr %64 to i64
  store i64 18, ptr %64, align 1
  %v98 = getelementptr i8, ptr %64, i64 8
  store i64 %v83, ptr %v98, align 1
  %v99 = load i64, ptr %v4, align 8
  store i64 %v99, ptr %v80, align 8
  store i64 %75, ptr %v81, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v86, align 8
  store i64 %54, ptr %v103, align 8
  store i64 8, ptr %1, align 8
  %76 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %77 = icmp eq ptr %76, null
  br i1 %77, label %78, label %79

78:                                               ; preds = %ok91
  call fastcc void @native_trap() #111
  unreachable

79:                                               ; preds = %ok91
  %80 = getelementptr inbounds nuw i8, ptr %76, i64 376
  %81 = load i64, ptr %80, align 8, !noundef !39
  %82 = icmp eq i64 %81, 0
  br i1 %82, label %83, label %87

83:                                               ; preds = %93, %87, %79
  %84 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %85 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %76, i64 noundef 32, ptr noundef %84) #84
  %86 = icmp eq ptr %85, null
  br i1 %86, label %95, label %ok108

87:                                               ; preds = %79
  %88 = getelementptr inbounds nuw i8, ptr %76, i64 368
  %89 = load i64, ptr %88, align 8, !noundef !39
  %90 = add i64 %89, 1
  store i64 %90, ptr %88, align 8
  %91 = urem i64 %90, %81
  %92 = icmp eq i64 %91, 0
  br i1 %92, label %93, label %83

93:                                               ; preds = %87
  %94 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %76, ptr noundef %94) #84
  br label %83

95:                                               ; preds = %83
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok108:                                            ; preds = %83
  %96 = ptrtoint ptr %85 to i64
  store i64 14, ptr %85, align 1
  %v115 = getelementptr i8, ptr %85, i64 8
  store i64 %v27, ptr %v115, align 1
  %v120 = getelementptr i8, ptr %85, i64 16
  store i64 %75, ptr %v120, align 1
  %v125 = getelementptr i8, ptr %85, i64 24
  store i64 %v99, ptr %v125, align 1
  store i64 %96, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v81, align 8
  store i64 %54, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %97 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %98 = icmp eq ptr %97, null
  br i1 %98, label %99, label %100

99:                                               ; preds = %ok108
  call fastcc void @native_trap() #111
  unreachable

100:                                              ; preds = %ok108
  %101 = getelementptr inbounds nuw i8, ptr %97, i64 376
  %102 = load i64, ptr %101, align 8, !noundef !39
  %103 = icmp eq i64 %102, 0
  br i1 %103, label %104, label %108

104:                                              ; preds = %114, %108, %100
  %105 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %106 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %97, i64 noundef 24, ptr noundef %105) #84
  %107 = icmp eq ptr %106, null
  br i1 %107, label %116, label %ok133

108:                                              ; preds = %100
  %109 = getelementptr inbounds nuw i8, ptr %97, i64 368
  %110 = load i64, ptr %109, align 8, !noundef !39
  %111 = add i64 %110, 1
  store i64 %111, ptr %109, align 8
  %112 = urem i64 %111, %102
  %113 = icmp eq i64 %112, 0
  br i1 %113, label %114, label %104

114:                                              ; preds = %108
  %115 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %97, ptr noundef %115) #84
  br label %104

116:                                              ; preds = %104
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok133:                                            ; preds = %104
  %117 = ptrtoint ptr %106 to i64
  store i64 54, ptr %106, align 1
  %v140 = getelementptr i8, ptr %106, i64 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v140, align 1
  %v145 = getelementptr i8, ptr %106, i64 16
  store i64 %96, ptr %v145, align 1
  store i64 %117, ptr %v76, align 1
  %v151 = load i64, ptr %v4, align 8
  %v152.not = icmp eq i64 %v151, 0
  br i1 %v152.not, label %trap153, label %ok154

trap153:                                          ; preds = %ok133
  call fastcc void @native_trap()
  unreachable

ok154:                                            ; preds = %ok133
  %v155 = inttoptr i64 %v151 to ptr
  %v156 = getelementptr i8, ptr %v155, i64 8
  store i32 1, ptr %v156, align 1
  %v157 = load i64, ptr %v4, align 8
  %v158.not = icmp eq i64 %v157, 0
  br i1 %v158.not, label %trap159, label %ok160

trap159:                                          ; preds = %ok154
  call fastcc void @native_trap()
  unreachable

ok160:                                            ; preds = %ok154
  %v161 = inttoptr i64 %v157 to ptr
  %v162 = getelementptr i8, ptr %v161, i64 8
  %v163 = load i32, ptr %v162, align 1
  %v164 = icmp eq i32 %v163, 0
  br i1 %v164, label %then168, label %ok173

then168:                                          ; preds = %ok160
  call fastcc void @native_trap()
  unreachable

ok173:                                            ; preds = %ok160
  %v175 = getelementptr i8, ptr %v161, i64 16
  %v176 = load i64, ptr %v175, align 1
  %v177.not = icmp eq i64 %v176, 0
  br i1 %v177.not, label %trap178, label %ok179

trap178:                                          ; preds = %ok173
  call fastcc void @native_trap()
  unreachable

ok179:                                            ; preds = %ok173
  store i64 %v176, ptr %v5, align 8
  %v183 = inttoptr i64 %v176 to ptr
  %v191 = getelementptr i8, ptr %v183, i64 8
  %v192 = load i64, ptr %v191, align 1
  %v193.not = icmp eq i64 %v192, 0
  br i1 %v193.not, label %trap194, label %ok195

trap194:                                          ; preds = %ok179
  call fastcc void @native_trap()
  unreachable

ok195:                                            ; preds = %ok179
  %v184 = getelementptr i8, ptr %v183, i64 16
  %v185 = load i64, ptr %v184, align 1
  %v196 = inttoptr i64 %v192 to ptr
  %v197 = getelementptr i8, ptr %v196, i64 8
  %v198 = load ptr, ptr %v197, align 1
  store i64 %v185, ptr %v80, align 8
  store i64 5, ptr %1, align 8
  %v201 = call tailcc i64 %v198(i64 %v185, i64 0)
  store i64 %v201, ptr %v6, align 8
  %v202.b = load i1, ptr @g.6, align 1
  br i1 %v202.b, label %block205, label %then207

then207:                                          ; preds = %ok195
  call fastcc void @native_trap()
  unreachable

block205:                                         ; preds = %ok195
  %v209 = load i64, ptr @g.5, align 8
  %v210.not = icmp eq i64 %v209, 0
  br i1 %v210.not, label %trap211, label %ok212

trap211:                                          ; preds = %block205
  call fastcc void @native_trap()
  unreachable

ok212:                                            ; preds = %block205
  %v214.not = icmp eq i64 %v201, 0
  br i1 %v214.not, label %trap215, label %ok216

trap215:                                          ; preds = %ok212
  call fastcc void @native_trap()
  unreachable

ok216:                                            ; preds = %ok212
  %v217 = and i64 %v201, 1
  %v218 = icmp eq i64 %v217, 0
  br i1 %v218, label %ok220, label %trap219

trap219:                                          ; preds = %ok216
  call fastcc void @native_trap()
  unreachable

ok220:                                            ; preds = %ok216
  %v221 = inttoptr i64 %v201 to ptr
  %v222 = getelementptr i8, ptr %v221, i64 8
  %v223 = load i64, ptr %v222, align 1
  %v225 = and i64 %v223, 4294967295
  store i64 4, ptr %1, align 8
  %118 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %119 = icmp eq ptr %118, null
  br i1 %119, label %120, label %121

120:                                              ; preds = %ok220
  call fastcc void @native_trap() #111
  unreachable

121:                                              ; preds = %ok220
  %122 = getelementptr inbounds nuw i8, ptr %118, i64 376
  %123 = load i64, ptr %122, align 8, !noundef !39
  %124 = icmp eq i64 %123, 0
  br i1 %124, label %125, label %129

125:                                              ; preds = %135, %129, %121
  %126 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %127 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %118, i64 noundef 24, ptr noundef %126) #84
  %128 = icmp eq ptr %127, null
  br i1 %128, label %137, label %ok236

129:                                              ; preds = %121
  %130 = getelementptr inbounds nuw i8, ptr %118, i64 368
  %131 = load i64, ptr %130, align 8, !noundef !39
  %132 = add i64 %131, 1
  store i64 %132, ptr %130, align 8
  %133 = urem i64 %132, %123
  %134 = icmp eq i64 %133, 0
  br i1 %134, label %135, label %125

135:                                              ; preds = %129
  %136 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %118, ptr noundef %136) #84
  br label %125

137:                                              ; preds = %125
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok236:                                            ; preds = %125
  %138 = ptrtoint ptr %127 to i64
  %v224 = trunc i64 %v223 to i32
  store i64 26, ptr %127, align 1
  %v243 = getelementptr i8, ptr %127, i64 8
  store i32 0, ptr %v243, align 1
  %v248 = getelementptr i8, ptr %127, i64 16
  store i64 0, ptr %v248, align 1
  store i64 %138, ptr %v4, align 8
  %v249 = load i64, ptr %v6, align 8
  store i64 %v249, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v81, align 8
  store i64 %138, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %v256 = call fastcc i64 @native_array_new(i32 %v224)
  %v257 = load i64, ptr %v4, align 8
  store i64 %v257, ptr %v80, align 8
  store i64 %v256, ptr %v81, align 8
  store i64 %v249, ptr %v86, align 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v103, align 8
  store i64 %138, ptr %v262, align 8
  store i64 9, ptr %1, align 8
  %139 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %140 = icmp eq ptr %139, null
  br i1 %140, label %141, label %142

141:                                              ; preds = %ok236
  call fastcc void @native_trap() #111
  unreachable

142:                                              ; preds = %ok236
  %143 = getelementptr inbounds nuw i8, ptr %139, i64 376
  %144 = load i64, ptr %143, align 8, !noundef !39
  %145 = icmp eq i64 %144, 0
  br i1 %145, label %146, label %150

146:                                              ; preds = %156, %150, %142
  %147 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %148 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %139, i64 noundef 32, ptr noundef %147) #84
  %149 = icmp eq ptr %148, null
  br i1 %149, label %158, label %ok267

150:                                              ; preds = %142
  %151 = getelementptr inbounds nuw i8, ptr %139, i64 368
  %152 = load i64, ptr %151, align 8, !noundef !39
  %153 = add i64 %152, 1
  store i64 %153, ptr %151, align 8
  %154 = urem i64 %153, %144
  %155 = icmp eq i64 %154, 0
  br i1 %155, label %156, label %146

156:                                              ; preds = %150
  %157 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %139, ptr noundef %157) #84
  br label %146

158:                                              ; preds = %146
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok267:                                            ; preds = %146
  %159 = ptrtoint ptr %148 to i64
  store i64 6, ptr %148, align 1
  %v274 = getelementptr i8, ptr %148, i64 8
  store i64 %v249, ptr %v274, align 1
  %v279 = getelementptr i8, ptr %148, i64 16
  store i64 %v256, ptr %v279, align 1
  %v284 = getelementptr i8, ptr %148, i64 24
  store i64 %v257, ptr %v284, align 1
  store i64 %159, ptr %v80, align 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v81, align 8
  store i64 %138, ptr %v86, align 8
  store i64 7, ptr %1, align 8
  %160 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %161 = icmp eq ptr %160, null
  br i1 %161, label %162, label %163

162:                                              ; preds = %ok267
  call fastcc void @native_trap() #111
  unreachable

163:                                              ; preds = %ok267
  %164 = getelementptr inbounds nuw i8, ptr %160, i64 376
  %165 = load i64, ptr %164, align 8, !noundef !39
  %166 = icmp eq i64 %165, 0
  br i1 %166, label %167, label %171

167:                                              ; preds = %177, %171, %163
  %168 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %169 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %160, i64 noundef 24, ptr noundef %168) #84
  %170 = icmp eq ptr %169, null
  br i1 %170, label %179, label %ok292

171:                                              ; preds = %163
  %172 = getelementptr inbounds nuw i8, ptr %160, i64 368
  %173 = load i64, ptr %172, align 8, !noundef !39
  %174 = add i64 %173, 1
  store i64 %174, ptr %172, align 8
  %175 = urem i64 %174, %165
  %176 = icmp eq i64 %175, 0
  br i1 %176, label %177, label %167

177:                                              ; preds = %171
  %178 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %160, ptr noundef %178) #84
  br label %167

179:                                              ; preds = %167
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok292:                                            ; preds = %167
  %180 = ptrtoint ptr %169 to i64
  store i64 54, ptr %169, align 1
  %v299 = getelementptr i8, ptr %169, i64 8
  store i64 ptrtoint (ptr @ref.6 to i64), ptr %v299, align 1
  %v304 = getelementptr i8, ptr %169, i64 16
  store i64 %159, ptr %v304, align 1
  store i64 %180, ptr %v248, align 1
  %v310 = load i64, ptr %v4, align 8
  %v311.not = icmp eq i64 %v310, 0
  br i1 %v311.not, label %trap312, label %ok313

trap312:                                          ; preds = %ok292
  call fastcc void @native_trap()
  unreachable

ok313:                                            ; preds = %ok292
  %v314 = inttoptr i64 %v310 to ptr
  %v315 = getelementptr i8, ptr %v314, i64 8
  store i32 1, ptr %v315, align 1
  %v316 = load i64, ptr %v4, align 8
  %v317.not = icmp eq i64 %v316, 0
  br i1 %v317.not, label %trap318, label %ok319

trap318:                                          ; preds = %ok313
  call fastcc void @native_trap()
  unreachable

ok319:                                            ; preds = %ok313
  %v320 = inttoptr i64 %v316 to ptr
  %v321 = getelementptr i8, ptr %v320, i64 8
  %v322 = load i32, ptr %v321, align 1
  %v323 = icmp eq i32 %v322, 0
  br i1 %v323, label %then327, label %ok332

then327:                                          ; preds = %ok319
  call fastcc void @native_trap()
  unreachable

ok332:                                            ; preds = %ok319
  %v334 = getelementptr i8, ptr %v320, i64 16
  %v335 = load i64, ptr %v334, align 1
  %v336.not = icmp eq i64 %v335, 0
  br i1 %v336.not, label %trap337, label %ok338

trap337:                                          ; preds = %ok332
  call fastcc void @native_trap()
  unreachable

ok338:                                            ; preds = %ok332
  store i64 %v335, ptr %v5, align 8
  %v342 = inttoptr i64 %v335 to ptr
  %v352 = getelementptr i8, ptr %v342, i64 8
  %v353 = load i64, ptr %v352, align 1
  %v354.not = icmp eq i64 %v353, 0
  br i1 %v354.not, label %trap355, label %ok356

trap355:                                          ; preds = %ok338
  call fastcc void @native_trap()
  unreachable

ok356:                                            ; preds = %ok338
  %v346 = add nsw i64 %v225, -1
  %v343 = getelementptr i8, ptr %v342, i64 16
  %v344 = load i64, ptr %v343, align 1
  %v357 = inttoptr i64 %v353 to ptr
  %v358 = getelementptr i8, ptr %v357, i64 8
  %v359 = load ptr, ptr %v358, align 1
  store i64 %v344, ptr %v80, align 8
  store i64 5, ptr %1, align 8
  %v362 = call tailcc i64 %v359(i64 %v344, i64 %v346)
  %v363.not = icmp eq i64 %v362, 0
  br i1 %v363.not, label %trap364, label %ok365

trap364:                                          ; preds = %ok356
  call fastcc void @native_trap()
  unreachable

ok365:                                            ; preds = %ok356
  %v366 = and i64 %v362, 1
  %v367 = icmp eq i64 %v366, 0
  br i1 %v367, label %ok369, label %trap368

trap368:                                          ; preds = %ok365
  call fastcc void @native_trap()
  unreachable

ok369:                                            ; preds = %ok365
  %v370 = inttoptr i64 %v362 to ptr
  %v371 = getelementptr i8, ptr %v370, i64 8
  %v372 = load i64, ptr %v371, align 1
  %v375 = load i64, ptr %v1, align 8
  %181 = icmp ne i64 %v375, 0
  %182 = and i64 %v375, 1
  %.not.i9 = icmp eq i64 %182, 0
  %or.cond81 = and i1 %181, %.not.i9
  br i1 %or.cond81, label %183, label %trap378

183:                                              ; preds = %ok369
  %184 = inttoptr i64 %v375 to ptr
  %185 = load i64, ptr %184, align 8, !noundef !39
  %186 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %187 = icmp eq ptr %186, null
  br i1 %187, label %202, label %188

188:                                              ; preds = %183
  %189 = icmp eq i64 %185, 30
  switch i64 %185, label %190 [
    i64 30, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

190:                                              ; preds = %188
  %191 = getelementptr inbounds nuw i8, ptr %186, i64 360
  %192 = load i64, ptr %191, align 8, !noundef !39
  %193 = lshr i64 %185, 2
  %194 = add nsw i64 %193, -1
  %195 = icmp ult i64 %194, %192
  br i1 %195, label %196, label %.loopexit22

196:                                              ; preds = %190
  %197 = getelementptr inbounds nuw i8, ptr %186, i64 352
  %198 = load ptr, ptr %197, align 8, !nonnull !39, !noundef !39
  %199 = getelementptr inbounds nuw i64, ptr %198, i64 %194
  %200 = load i64, ptr %199, align 8, !noundef !39
  %201 = icmp eq i64 %200, 30
  switch i64 %200, label %.preheader21 [
    i64 30, label %native_ref_test.exit10
    i64 0, label %native_ref_test.exit10
  ]

202:                                              ; preds = %183
  call fastcc void @native_trap() #111
  unreachable

.preheader21:                                     ; preds = %207, %196
  %203 = phi i64 [ %209, %207 ], [ %200, %196 ]
  %204 = lshr i64 %203, 2
  %205 = add nsw i64 %204, -1
  %206 = icmp ult i64 %205, %192
  br i1 %206, label %207, label %.loopexit22

.loopexit22:                                      ; preds = %.preheader21, %190
  call fastcc void @native_trap() #111
  unreachable

207:                                              ; preds = %.preheader21
  %208 = getelementptr inbounds nuw i64, ptr %198, i64 %205
  %209 = load i64, ptr %208, align 8, !noundef !39
  switch i64 %209, label %.preheader21 [
    i64 30, label %native_ref_test.exit10.loopexit
    i64 0, label %native_ref_test.exit10.loopexit
  ]

native_ref_test.exit10.loopexit:                  ; preds = %207, %207
  %.lcssa142 = phi i64 [ %209, %207 ], [ %209, %207 ]
  %210 = icmp eq i64 %.lcssa142, 30
  br i1 %210, label %ok382, label %trap378

native_ref_test.exit10:                           ; preds = %196, %196, %188, %188
  %211 = phi i1 [ %189, %188 ], [ %201, %196 ], [ %201, %196 ], [ %189, %188 ]
  br i1 %211, label %ok382, label %trap378

trap378:                                          ; preds = %native_ref_test.exit10, %native_ref_test.exit10.loopexit, %ok369
  call fastcc void @native_trap()
  unreachable

ok382:                                            ; preds = %native_ref_test.exit10, %native_ref_test.exit10.loopexit
  %v384 = getelementptr i8, ptr %184, i64 16
  %v385 = load i64, ptr %v384, align 1
  %v386.not = icmp eq i64 %v385, 0
  br i1 %v386.not, label %trap387, label %ok388

trap387:                                          ; preds = %ok382
  call fastcc void @native_trap()
  unreachable

ok388:                                            ; preds = %ok382
  %v389 = inttoptr i64 %v385 to ptr
  %v390 = getelementptr i8, ptr %v389, i64 8
  %v391 = load i32, ptr %v390, align 1
  %v392 = icmp eq i32 %v391, 0
  br i1 %v392, label %then396, label %block394

then396:                                          ; preds = %ok388
  call fastcc void @native_trap()
  unreachable

block394:                                         ; preds = %ok388
  switch i64 %185, label %212 [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

212:                                              ; preds = %block394
  %213 = getelementptr inbounds nuw i8, ptr %186, i64 360
  %214 = load i64, ptr %213, align 8, !noundef !39
  %215 = lshr i64 %185, 2
  %216 = add nsw i64 %215, -1
  %217 = icmp ult i64 %216, %214
  br i1 %217, label %218, label %.loopexit20

218:                                              ; preds = %212
  %219 = getelementptr inbounds nuw i8, ptr %186, i64 352
  %220 = load ptr, ptr %219, align 8, !nonnull !39, !noundef !39
  %221 = getelementptr inbounds nuw i64, ptr %220, i64 %216
  %222 = load i64, ptr %221, align 8, !noundef !39
  %223 = icmp eq i64 %222, 30
  switch i64 %222, label %.preheader19 [
    i64 30, label %native_ref_test.exit12
    i64 0, label %native_ref_test.exit12
  ]

.preheader19:                                     ; preds = %228, %218
  %224 = phi i64 [ %230, %228 ], [ %222, %218 ]
  %225 = lshr i64 %224, 2
  %226 = add nsw i64 %225, -1
  %227 = icmp ult i64 %226, %214
  br i1 %227, label %228, label %.loopexit20

.loopexit20:                                      ; preds = %.preheader19, %212
  call fastcc void @native_trap() #111
  unreachable

228:                                              ; preds = %.preheader19
  %229 = getelementptr inbounds nuw i64, ptr %220, i64 %226
  %230 = load i64, ptr %229, align 8, !noundef !39
  switch i64 %230, label %.preheader19 [
    i64 30, label %native_ref_test.exit12.loopexit
    i64 0, label %native_ref_test.exit12.loopexit
  ]

native_ref_test.exit12.loopexit:                  ; preds = %228, %228
  %.lcssa = phi i64 [ %230, %228 ], [ %230, %228 ]
  %231 = icmp eq i64 %.lcssa, 30
  br i1 %231, label %ok411, label %trap401

native_ref_test.exit12:                           ; preds = %218, %218, %block394, %block394
  %232 = phi i1 [ %189, %block394 ], [ %223, %218 ], [ %223, %218 ], [ %189, %block394 ]
  br i1 %232, label %ok411, label %trap401

trap401:                                          ; preds = %native_ref_test.exit12, %native_ref_test.exit12.loopexit
  call fastcc void @native_trap()
  unreachable

ok411:                                            ; preds = %native_ref_test.exit12, %native_ref_test.exit12.loopexit
  %v413 = getelementptr i8, ptr %v389, i64 16
  %v414 = load i64, ptr %v413, align 1
  %v415.not = icmp eq i64 %v414, 0
  br i1 %v415.not, label %trap416, label %ok417

trap416:                                          ; preds = %ok411
  call fastcc void @native_trap()
  unreachable

ok417:                                            ; preds = %ok411
  %v418 = inttoptr i64 %v414 to ptr
  %v419 = getelementptr i8, ptr %v418, i64 16
  %v420 = load i64, ptr %v419, align 1
  %233 = load i64, ptr %0, align 8, !noundef !39
  %234 = icmp eq i64 %233, 0
  %.pre50 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %235 = zext i1 %234 to i64
  %236 = add i64 %.pre50, %235
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %237 = select i1 %234, ptr %native_roots.0.val, ptr %roots.val
  store i64 9, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %237, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %236, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %238 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %239 = call noundef i64 @llvm.umax.i64(i64 %236, i64 %238)
  store i64 %239, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v420, ptr %v1, align 8
  %v10 = icmp sgt i64 %arg1.tr48, 1
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  br i1 %v10, label %ok417.split, label %tailrecurse.else14_crit_edge

ok417.split:                                      ; preds = %ok417
  %v422 = add nsw i64 %arg1.tr48, -1
  %240 = icmp ne i64 %v420, 0
  %241 = and i64 %v420, 1
  %.not.i13 = icmp eq i64 %241, 0
  %or.cond82 = and i1 %240, %.not.i13
  br i1 %or.cond82, label %242, label %then15.backedge

then15.backedge:                                  ; preds = %.loopexit18, %ok417.split
  %phi.call.shrunk.be = phi i1 [ false, %ok417.split ], [ %256, %.loopexit18 ]
  br label %then15

242:                                              ; preds = %ok417.split
  %243 = inttoptr i64 %v420 to ptr
  %244 = load i64, ptr %243, align 8, !noundef !39
  switch i64 %244, label %245 [
    i64 30, label %.loopexit18
    i64 0, label %.loopexit18
  ]

245:                                              ; preds = %242
  %246 = getelementptr inbounds nuw i8, ptr %186, i64 360
  %247 = load i64, ptr %246, align 8, !noundef !39
  %248 = lshr i64 %244, 2
  %249 = add nsw i64 %248, -1
  %250 = icmp ult i64 %249, %247
  br i1 %250, label %251, label %.loopexit

251:                                              ; preds = %245
  %252 = getelementptr inbounds nuw i8, ptr %186, i64 352
  %253 = load ptr, ptr %252, align 8, !nonnull !39, !noundef !39
  %254 = getelementptr inbounds nuw i64, ptr %253, i64 %249
  %255 = load i64, ptr %254, align 8, !noundef !39
  switch i64 %255, label %.preheader [
    i64 30, label %.loopexit18
    i64 0, label %.loopexit18
  ]

.loopexit18:                                      ; preds = %261, %261, %251, %251, %242, %242
  %.in = phi i64 [ %244, %242 ], [ %255, %251 ], [ %255, %251 ], [ %244, %242 ], [ %263, %261 ], [ %263, %261 ]
  %256 = icmp eq i64 %.in, 30
  br label %then15.backedge

.preheader:                                       ; preds = %261, %251
  %257 = phi i64 [ %263, %261 ], [ %255, %251 ]
  %258 = lshr i64 %257, 2
  %259 = add nsw i64 %258, -1
  %260 = icmp ult i64 %259, %247
  br i1 %260, label %261, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %245
  call fastcc void @native_trap() #111
  unreachable

261:                                              ; preds = %.preheader
  %262 = getelementptr inbounds nuw i64, ptr %253, i64 %259
  %263 = load i64, ptr %262, align 8, !noundef !39
  switch i64 %263, label %.preheader [
    i64 30, label %.loopexit18
    i64 0, label %.loopexit18
  ]

tailrecurse.else14_crit_edge:                     ; preds = %ok417
  %.lcssa138 = phi i64 [ %236, %ok417 ]
  %.lcssa135 = phi ptr [ %237, %ok417 ]
  %v372.lcssa132 = phi i64 [ %v372, %ok417 ]
  %v374.le = and i64 %v372.lcssa132, 4294967295
  %264 = add i64 %.lcssa138, -1
  br label %else14

else14:                                           ; preds = %tailrecurse.else14_crit_edge, %entry
  %265 = phi i64 [ %264, %tailrecurse.else14_crit_edge ], [ %3, %entry ]
  %266 = phi ptr [ %.lcssa135, %tailrecurse.else14_crit_edge ], [ %2, %entry ]
  %arg2.tr.lcssa = phi i64 [ %v374.le, %tailrecurse.else14_crit_edge ], [ %arg2, %entry ]
  store ptr %266, ptr @native_roots.0, align 8
  store i64 %265, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  ret i64 %arg2.tr.lcssa
}

define internal tailcc i64 @f.6(i64 %arg0, i64 %arg1) #103 personality ptr @rust_eh_personality {
entry:
  %v919 = icmp slt i64 %arg1, 0
  br i1 %v919, label %then14, label %else13.preheader.split

else13.preheader.split:                           ; preds = %entry
  %v41.first_iter = icmp samesign ugt i64 %arg1, 4294967295
  %0 = icmp ne i64 %arg0, 0
  %1 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %1, 0
  %or.cond = and i1 %0, %.not.i
  br i1 %or.cond, label %2, label %else13.preheader

2:                                                ; preds = %else13.preheader.split
  %3 = inttoptr i64 %arg0 to ptr
  %4 = load i64, ptr %3, align 8, !noundef !39
  %5 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %6 = icmp eq ptr %5, null
  br i1 %6, label %19, label %7

7:                                                ; preds = %2
  switch i64 %4, label %8 [
    i64 6, label %.loopexit19
    i64 0, label %.loopexit19
  ]

8:                                                ; preds = %7
  %9 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %10 = load i64, ptr %9, align 8, !noundef !39
  %11 = lshr i64 %4, 2
  %12 = add nsw i64 %11, -1
  %13 = icmp ult i64 %12, %10
  br i1 %13, label %14, label %.loopexit18

14:                                               ; preds = %8
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %16 = load ptr, ptr %15, align 8, !nonnull !39, !noundef !39
  %17 = getelementptr inbounds nuw i64, ptr %16, i64 %12
  %18 = load i64, ptr %17, align 8, !noundef !39
  switch i64 %18, label %.preheader17 [
    i64 6, label %.loopexit19
    i64 0, label %.loopexit19
  ]

19:                                               ; preds = %2
  tail call fastcc void @native_trap() #111
  unreachable

.loopexit19:                                      ; preds = %25, %25, %14, %14, %7, %7
  %.in = phi i64 [ %4, %7 ], [ %18, %14 ], [ %18, %14 ], [ %4, %7 ], [ %27, %25 ], [ %27, %25 ]
  %20 = icmp eq i64 %.in, 6
  br label %else13.preheader

else13.preheader:                                 ; preds = %.loopexit19, %else13.preheader.split
  %phi.call.shrunk.ph = phi i1 [ false, %else13.preheader.split ], [ %20, %.loopexit19 ]
  br label %else13

.preheader17:                                     ; preds = %25, %14
  %21 = phi i64 [ %27, %25 ], [ %18, %14 ]
  %22 = lshr i64 %21, 2
  %23 = add nsw i64 %22, -1
  %24 = icmp ult i64 %23, %10
  br i1 %24, label %25, label %.loopexit18

.loopexit18:                                      ; preds = %.preheader17, %8
  tail call fastcc void @native_trap() #111
  unreachable

25:                                               ; preds = %.preheader17
  %26 = getelementptr inbounds nuw i64, ptr %16, i64 %23
  %27 = load i64, ptr %26, align 8, !noundef !39
  switch i64 %27, label %.preheader17 [
    i64 6, label %.loopexit19
    i64 0, label %.loopexit19
  ]

then14:                                           ; preds = %ok136, %entry
  %arg0.tr.lcssa = phi i64 [ %arg0, %entry ], [ %v139, %ok136 ]
  %28 = icmp ne i64 %arg0.tr.lcssa, 0
  %29 = and i64 %arg0.tr.lcssa, 1
  %.not.i3 = icmp eq i64 %29, 0
  %or.cond30 = and i1 %28, %.not.i3
  br i1 %or.cond30, label %30, label %trap19

30:                                               ; preds = %then14
  %31 = inttoptr i64 %arg0.tr.lcssa to ptr
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %34 = icmp eq ptr %33, null
  br i1 %34, label %47, label %35

35:                                               ; preds = %30
  switch i64 %32, label %36 [
    i64 6, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

36:                                               ; preds = %35
  %37 = getelementptr inbounds nuw i8, ptr %33, i64 360
  %38 = load i64, ptr %37, align 8, !noundef !39
  %39 = lshr i64 %32, 2
  %40 = add nsw i64 %39, -1
  %41 = icmp ult i64 %40, %38
  br i1 %41, label %42, label %.loopexit

42:                                               ; preds = %36
  %43 = getelementptr inbounds nuw i8, ptr %33, i64 352
  %44 = load ptr, ptr %43, align 8, !nonnull !39, !noundef !39
  %45 = getelementptr inbounds nuw i64, ptr %44, i64 %40
  %46 = load i64, ptr %45, align 8, !noundef !39
  switch i64 %46, label %.preheader [
    i64 6, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

47:                                               ; preds = %30
  tail call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %52, %42
  %48 = phi i64 [ %54, %52 ], [ %46, %42 ]
  %49 = lshr i64 %48, 2
  %50 = add nsw i64 %49, -1
  %51 = icmp ult i64 %50, %38
  br i1 %51, label %52, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %36
  tail call fastcc void @native_trap() #111
  unreachable

52:                                               ; preds = %.preheader
  %53 = getelementptr inbounds nuw i64, ptr %44, i64 %50
  %54 = load i64, ptr %53, align 8, !noundef !39
  switch i64 %54, label %.preheader [
    i64 6, label %native_ref_test.exit4
    i64 0, label %native_ref_test.exit4
  ]

native_ref_test.exit4:                            ; preds = %52, %52, %42, %42, %35, %35
  %.in44 = phi i64 [ %32, %35 ], [ %46, %42 ], [ %46, %42 ], [ %32, %35 ], [ %54, %52 ], [ %54, %52 ]
  %55 = icmp eq i64 %.in44, 6
  br i1 %55, label %ok23, label %trap19

trap19:                                           ; preds = %native_ref_test.exit4, %then14
  tail call fastcc void @native_trap()
  unreachable

ok23:                                             ; preds = %native_ref_test.exit4
  %v25 = getelementptr i8, ptr %31, i64 16
  %v26 = load i64, ptr %v25, align 1
  ret i64 %v26

else13:                                           ; preds = %else13.backedge, %else13.preheader
  %phi.call.shrunk = phi i1 [ %phi.call.shrunk.ph, %else13.preheader ], [ %phi.call.shrunk.be, %else13.backedge ]
  %arg1.tr21 = phi i64 [ %arg1, %else13.preheader ], [ %v141, %else13.backedge ]
  %arg0.tr20 = phi i64 [ %arg0, %else13.preheader ], [ %v139, %else13.backedge ]
  br i1 %phi.call.shrunk, label %ok31, label %trap30

trap30:                                           ; preds = %else13
  tail call fastcc void @native_trap()
  unreachable

ok31:                                             ; preds = %else13
  %v32.not = icmp eq i64 %arg0.tr20, 0
  br i1 %v32.not, label %trap33, label %ok34

trap33:                                           ; preds = %ok31
  tail call fastcc void @native_trap()
  unreachable

ok34:                                             ; preds = %ok31
  %v35 = inttoptr i64 %arg0.tr20 to ptr
  %v36 = getelementptr i8, ptr %v35, i64 16
  %v37 = load i64, ptr %v36, align 1
  br i1 %v41.first_iter, label %then45, label %ok50

then45:                                           ; preds = %ok34
  tail call fastcc void @native_trap()
  unreachable

ok50:                                             ; preds = %ok34
  %v52 = getelementptr i8, ptr %v35, i64 8
  %v53 = load i64, ptr %v52, align 1
  %v56.not = icmp eq i64 %v53, 0
  br i1 %v56.not, label %trap57, label %ok58

trap57:                                           ; preds = %ok50
  tail call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %ok50
  %v59 = and i64 %v53, 1
  %v60 = icmp eq i64 %v59, 0
  br i1 %v60, label %ok62, label %trap61

trap61:                                           ; preds = %ok58
  tail call fastcc void @native_trap()
  unreachable

ok62:                                             ; preds = %ok58
  %v63 = inttoptr i64 %v53 to ptr
  %v64 = getelementptr i8, ptr %v63, i64 8
  %v65 = load i64, ptr %v64, align 1
  %v67 = icmp ult i64 %arg1.tr21, %v65
  br i1 %v67, label %ok69, label %trap68

trap68:                                           ; preds = %ok62
  tail call fastcc void @native_trap()
  unreachable

ok69:                                             ; preds = %ok62
  %v71 = getelementptr i8, ptr %v63, i64 16
  %v72 = getelementptr i64, ptr %v71, i64 %arg1.tr21
  %v73 = load i64, ptr %v72, align 1
  %v85.not = icmp eq i64 %v37, 0
  br i1 %v85.not, label %trap86, label %ok87

trap86:                                           ; preds = %ok69
  tail call fastcc void @native_trap()
  unreachable

ok87:                                             ; preds = %ok69
  %v88 = and i64 %v37, 1
  %v89 = icmp eq i64 %v88, 0
  br i1 %v89, label %ok91, label %trap90

trap90:                                           ; preds = %ok87
  tail call fastcc void @native_trap()
  unreachable

ok91:                                             ; preds = %ok87
  %v92 = inttoptr i64 %v37 to ptr
  %v93 = getelementptr i8, ptr %v92, i64 8
  %v94 = load i64, ptr %v93, align 1
  %v96 = icmp ult i64 %arg1.tr21, %v94
  br i1 %v96, label %ok98, label %trap97

trap97:                                           ; preds = %ok91
  tail call fastcc void @native_trap()
  unreachable

ok98:                                             ; preds = %ok91
  %v100 = getelementptr i8, ptr %v92, i64 16
  %v101 = getelementptr i64, ptr %v100, i64 %arg1.tr21
  store i64 %v73, ptr %v101, align 1
  %v107 = getelementptr i8, ptr %v35, i64 24
  %v108 = load i64, ptr %v107, align 1
  %v109.not = icmp eq i64 %v108, 0
  br i1 %v109.not, label %trap110, label %ok111

trap110:                                          ; preds = %ok98
  tail call fastcc void @native_trap()
  unreachable

ok111:                                            ; preds = %ok98
  %v112 = inttoptr i64 %v108 to ptr
  %v113 = getelementptr i8, ptr %v112, i64 8
  %v114 = load i32, ptr %v113, align 1
  %v115 = icmp eq i32 %v114, 0
  br i1 %v115, label %then119, label %ok130

then119:                                          ; preds = %ok111
  tail call fastcc void @native_trap()
  unreachable

ok130:                                            ; preds = %ok111
  %v132 = getelementptr i8, ptr %v112, i64 16
  %v133 = load i64, ptr %v132, align 1
  %v134.not = icmp eq i64 %v133, 0
  br i1 %v134.not, label %trap135, label %ok136

trap135:                                          ; preds = %ok130
  tail call fastcc void @native_trap()
  unreachable

ok136:                                            ; preds = %ok130
  %v137 = inttoptr i64 %v133 to ptr
  %v138 = getelementptr i8, ptr %v137, i64 16
  %v139 = load i64, ptr %v138, align 1
  %v9 = icmp eq i64 %arg1.tr21, 0
  br i1 %v9, label %then14, label %ok136.split

ok136.split:                                      ; preds = %ok136
  %v141 = add nsw i64 %arg1.tr21, -1
  %56 = icmp ne i64 %v139, 0
  %57 = and i64 %v139, 1
  %.not.i6 = icmp eq i64 %57, 0
  %or.cond31 = and i1 %56, %.not.i6
  br i1 %or.cond31, label %58, label %else13.backedge

else13.backedge:                                  ; preds = %.loopexit15, %ok136.split
  %phi.call.shrunk.be = phi i1 [ false, %ok136.split ], [ %76, %.loopexit15 ]
  br label %else13

58:                                               ; preds = %ok136.split
  %59 = inttoptr i64 %v139 to ptr
  %60 = load i64, ptr %59, align 8, !noundef !39
  %61 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %62 = icmp eq ptr %61, null
  br i1 %62, label %75, label %63

63:                                               ; preds = %58
  switch i64 %60, label %64 [
    i64 6, label %.loopexit15
    i64 0, label %.loopexit15
  ]

64:                                               ; preds = %63
  %65 = getelementptr inbounds nuw i8, ptr %61, i64 360
  %66 = load i64, ptr %65, align 8, !noundef !39
  %67 = lshr i64 %60, 2
  %68 = add nsw i64 %67, -1
  %69 = icmp ult i64 %68, %66
  br i1 %69, label %70, label %.loopexit14

70:                                               ; preds = %64
  %71 = getelementptr inbounds nuw i8, ptr %61, i64 352
  %72 = load ptr, ptr %71, align 8, !nonnull !39, !noundef !39
  %73 = getelementptr inbounds nuw i64, ptr %72, i64 %68
  %74 = load i64, ptr %73, align 8, !noundef !39
  switch i64 %74, label %.preheader13 [
    i64 6, label %.loopexit15
    i64 0, label %.loopexit15
  ]

75:                                               ; preds = %58
  tail call fastcc void @native_trap() #111
  unreachable

.loopexit15:                                      ; preds = %81, %81, %70, %70, %63, %63
  %.in43 = phi i64 [ %60, %63 ], [ %74, %70 ], [ %74, %70 ], [ %60, %63 ], [ %83, %81 ], [ %83, %81 ]
  %76 = icmp eq i64 %.in43, 6
  br label %else13.backedge

.preheader13:                                     ; preds = %81, %70
  %77 = phi i64 [ %83, %81 ], [ %74, %70 ]
  %78 = lshr i64 %77, 2
  %79 = add nsw i64 %78, -1
  %80 = icmp ult i64 %79, %66
  br i1 %80, label %81, label %.loopexit14

.loopexit14:                                      ; preds = %.preheader13, %64
  tail call fastcc void @native_trap() #111
  unreachable

81:                                               ; preds = %.preheader13
  %82 = getelementptr inbounds nuw i64, ptr %72, i64 %79
  %83 = load i64, ptr %82, align 8, !noundef !39
  switch i64 %83, label %.preheader13 [
    i64 6, label %.loopexit15
    i64 0, label %.loopexit15
  ]
}

define internal tailcc i64 @f.8(i64 %arg0, i64 %arg1) #103 personality ptr @rust_eh_personality {
entry:
  %0 = icmp ne i64 %arg0, 0
  %1 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %1, 0
  %or.cond = and i1 %0, %.not.i
  br i1 %or.cond, label %2, label %trap9

2:                                                ; preds = %entry
  %3 = inttoptr i64 %arg0 to ptr
  %4 = load i64, ptr %3, align 8, !noundef !39
  %5 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %6 = icmp eq ptr %5, null
  br i1 %6, label %19, label %7

7:                                                ; preds = %2
  switch i64 %4, label %8 [
    i64 14, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

8:                                                ; preds = %7
  %9 = getelementptr inbounds nuw i8, ptr %5, i64 360
  %10 = load i64, ptr %9, align 8, !noundef !39
  %11 = lshr i64 %4, 2
  %12 = add nsw i64 %11, -1
  %13 = icmp ult i64 %12, %10
  br i1 %13, label %14, label %.loopexit10

14:                                               ; preds = %8
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %16 = load ptr, ptr %15, align 8, !nonnull !39, !noundef !39
  %17 = getelementptr inbounds nuw i64, ptr %16, i64 %12
  %18 = load i64, ptr %17, align 8, !noundef !39
  switch i64 %18, label %.preheader9 [
    i64 14, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

19:                                               ; preds = %2
  tail call fastcc void @native_trap() #111
  unreachable

.preheader9:                                      ; preds = %24, %14
  %20 = phi i64 [ %26, %24 ], [ %18, %14 ]
  %21 = lshr i64 %20, 2
  %22 = add nsw i64 %21, -1
  %23 = icmp ult i64 %22, %10
  br i1 %23, label %24, label %.loopexit10

.loopexit10:                                      ; preds = %.preheader9, %8
  tail call fastcc void @native_trap() #111
  unreachable

24:                                               ; preds = %.preheader9
  %25 = getelementptr inbounds nuw i64, ptr %16, i64 %22
  %26 = load i64, ptr %25, align 8, !noundef !39
  switch i64 %26, label %.preheader9 [
    i64 14, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %24, %24, %14, %14, %7, %7
  %.in = phi i64 [ %4, %7 ], [ %18, %14 ], [ %18, %14 ], [ %4, %7 ], [ %26, %24 ], [ %26, %24 ]
  %27 = icmp eq i64 %.in, 14
  br i1 %27, label %ok13, label %trap9

trap9:                                            ; preds = %native_ref_test.exit3, %ok112, %native_ref_test.exit, %entry
  tail call fastcc void @native_trap()
  unreachable

ok13:                                             ; preds = %native_ref_test.exit3, %native_ref_test.exit
  %arg1.tr17 = phi i64 [ %v117, %native_ref_test.exit3 ], [ %arg1, %native_ref_test.exit ]
  %arg0.tr16 = phi i64 [ %v115, %native_ref_test.exit3 ], [ %arg0, %native_ref_test.exit ]
  %v14 = inttoptr i64 %arg0.tr16 to ptr
  %v15 = getelementptr i8, ptr %v14, i64 8
  %v16 = load i64, ptr %v15, align 1
  %v18.not = icmp sgt i64 %v16, %arg1.tr17
  br i1 %v18.not, label %else22, label %ok28

ok28:                                             ; preds = %ok13
  %v14.lcssa = phi ptr [ %v14, %ok13 ]
  %v30 = getelementptr i8, ptr %v14.lcssa, i64 16
  %v31 = load i64, ptr %v30, align 1
  %v32.not = icmp eq i64 %v31, 0
  br i1 %v32.not, label %trap33, label %ok34

trap33:                                           ; preds = %ok28
  tail call fastcc void @native_trap()
  unreachable

ok34:                                             ; preds = %ok28
  %v35 = inttoptr i64 %v31 to ptr
  %v36 = getelementptr i8, ptr %v35, i64 8
  %v37 = load i64, ptr %v36, align 1
  ret i64 %v37

else22:                                           ; preds = %ok13
  %v39 = icmp ugt i64 %arg1.tr17, 4294967295
  br i1 %v39, label %then43, label %ok48

then43:                                           ; preds = %else22
  tail call fastcc void @native_trap()
  unreachable

ok48:                                             ; preds = %else22
  %v50 = getelementptr i8, ptr %v14, i64 16
  %v51 = load i64, ptr %v50, align 1
  %v52.not = icmp eq i64 %v51, 0
  br i1 %v52.not, label %trap53, label %ok54

trap53:                                           ; preds = %ok48
  tail call fastcc void @native_trap()
  unreachable

ok54:                                             ; preds = %ok48
  %v55 = inttoptr i64 %v51 to ptr
  %v56 = getelementptr i8, ptr %v55, i64 8
  %v57 = load i64, ptr %v56, align 1
  %v61.not = icmp eq i64 %v57, 0
  br i1 %v61.not, label %trap62, label %ok63

trap62:                                           ; preds = %ok54
  tail call fastcc void @native_trap()
  unreachable

ok63:                                             ; preds = %ok54
  %v64 = and i64 %v57, 1
  %v65 = icmp eq i64 %v64, 0
  br i1 %v65, label %ok67, label %trap66

trap66:                                           ; preds = %ok63
  tail call fastcc void @native_trap()
  unreachable

ok67:                                             ; preds = %ok63
  %v68 = inttoptr i64 %v57 to ptr
  %v69 = getelementptr i8, ptr %v68, i64 8
  %v70 = load i64, ptr %v69, align 1
  %v72 = icmp ult i64 %arg1.tr17, %v70
  br i1 %v72, label %ok74, label %trap73

trap73:                                           ; preds = %ok67
  tail call fastcc void @native_trap()
  unreachable

ok74:                                             ; preds = %ok67
  %v76 = getelementptr i8, ptr %v68, i64 16
  %v77 = getelementptr i64, ptr %v76, i64 %arg1.tr17
  store i64 %arg1.tr17, ptr %v77, align 1
  %v83 = getelementptr i8, ptr %v14, i64 24
  %v84 = load i64, ptr %v83, align 1
  %v85.not = icmp eq i64 %v84, 0
  br i1 %v85.not, label %trap86, label %ok87

trap86:                                           ; preds = %ok74
  tail call fastcc void @native_trap()
  unreachable

ok87:                                             ; preds = %ok74
  %v88 = inttoptr i64 %v84 to ptr
  %v89 = getelementptr i8, ptr %v88, i64 8
  %v90 = load i32, ptr %v89, align 1
  %v91 = icmp eq i32 %v90, 0
  br i1 %v91, label %then95, label %ok106

then95:                                           ; preds = %ok87
  tail call fastcc void @native_trap()
  unreachable

ok106:                                            ; preds = %ok87
  %v108 = getelementptr i8, ptr %v88, i64 16
  %v109 = load i64, ptr %v108, align 1
  %v110.not = icmp eq i64 %v109, 0
  br i1 %v110.not, label %trap111, label %ok112

trap111:                                          ; preds = %ok106
  tail call fastcc void @native_trap()
  unreachable

ok112:                                            ; preds = %ok106
  %v113 = inttoptr i64 %v109 to ptr
  %v114 = getelementptr i8, ptr %v113, i64 16
  %v115 = load i64, ptr %v114, align 1
  %v117 = add nuw nsw i64 %arg1.tr17, 1
  %28 = icmp ne i64 %v115, 0
  %29 = and i64 %v115, 1
  %.not.i2 = icmp eq i64 %29, 0
  %or.cond39 = and i1 %28, %.not.i2
  br i1 %or.cond39, label %30, label %trap9

30:                                               ; preds = %ok112
  %31 = inttoptr i64 %v115 to ptr
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %34 = icmp eq ptr %33, null
  br i1 %34, label %47, label %35

35:                                               ; preds = %30
  switch i64 %32, label %36 [
    i64 14, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

36:                                               ; preds = %35
  %37 = getelementptr inbounds nuw i8, ptr %33, i64 360
  %38 = load i64, ptr %37, align 8, !noundef !39
  %39 = lshr i64 %32, 2
  %40 = add nsw i64 %39, -1
  %41 = icmp ult i64 %40, %38
  br i1 %41, label %42, label %.loopexit

42:                                               ; preds = %36
  %43 = getelementptr inbounds nuw i8, ptr %33, i64 352
  %44 = load ptr, ptr %43, align 8, !nonnull !39, !noundef !39
  %45 = getelementptr inbounds nuw i64, ptr %44, i64 %40
  %46 = load i64, ptr %45, align 8, !noundef !39
  switch i64 %46, label %.preheader [
    i64 14, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

47:                                               ; preds = %30
  tail call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %52, %42
  %48 = phi i64 [ %54, %52 ], [ %46, %42 ]
  %49 = lshr i64 %48, 2
  %50 = add nsw i64 %49, -1
  %51 = icmp ult i64 %50, %38
  br i1 %51, label %52, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %36
  tail call fastcc void @native_trap() #111
  unreachable

52:                                               ; preds = %.preheader
  %53 = getelementptr inbounds nuw i64, ptr %44, i64 %50
  %54 = load i64, ptr %53, align 8, !noundef !39
  switch i64 %54, label %.preheader [
    i64 14, label %native_ref_test.exit3
    i64 0, label %native_ref_test.exit3
  ]

native_ref_test.exit3:                            ; preds = %52, %52, %42, %42, %35, %35
  %.in47 = phi i64 [ %32, %35 ], [ %46, %42 ], [ %46, %42 ], [ %32, %35 ], [ %54, %52 ], [ %54, %52 ]
  %55 = icmp eq i64 %.in47, 14
  br i1 %55, label %ok13, label %trap9
}

define internal tailcc i64 @f.3(i64 %arg0, i64 %arg1, i64 %arg2) #102 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [6 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 6, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v4, i8 0, i64 16, i1 false)
  store i64 3, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %entry
  call fastcc void @native_trap() #111
  unreachable

10:                                               ; preds = %entry
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = phi ptr [ %.pre, %24 ], [ %roots, %18 ], [ %roots, %10 ]
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 24, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %25, label %ok12

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %14

25:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok12:                                             ; preds = %14
  %26 = ptrtoint ptr %16 to i64
  store i64 38, ptr %16, align 1
  %v19 = getelementptr i8, ptr %16, i64 8
  store i32 0, ptr %v19, align 1
  %v24 = getelementptr i8, ptr %16, i64 16
  store i64 0, ptr %v24, align 1
  store i64 %26, ptr %v4, align 8
  %v27 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 %26, ptr %v27, align 8
  %v28 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v28, align 8
  %v29 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %26, ptr %v29, align 8
  store i64 6, ptr %1, align 8
  %27 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %28 = icmp eq ptr %27, null
  br i1 %28, label %29, label %30

29:                                               ; preds = %ok12
  call fastcc void @native_trap() #111
  unreachable

30:                                               ; preds = %ok12
  %31 = getelementptr inbounds nuw i8, ptr %27, i64 376
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %34, label %38

34:                                               ; preds = %44, %38, %30
  %35 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %36 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %27, i64 noundef 24, ptr noundef %35) #84
  %37 = icmp eq ptr %36, null
  br i1 %37, label %46, label %ok34

38:                                               ; preds = %30
  %39 = getelementptr inbounds nuw i8, ptr %27, i64 368
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = add i64 %40, 1
  store i64 %41, ptr %39, align 8
  %42 = urem i64 %41, %32
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %44, label %34

44:                                               ; preds = %38
  %45 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %27, ptr noundef %45) #84
  br label %34

46:                                               ; preds = %34
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok34:                                             ; preds = %34
  %47 = ptrtoint ptr %36 to i64
  store i64 30, ptr %36, align 1
  %v41 = getelementptr i8, ptr %36, i64 8
  store i64 %arg2, ptr %v41, align 1
  %v46 = getelementptr i8, ptr %36, i64 16
  store i64 %26, ptr %v46, align 1
  store i64 %47, ptr %v27, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v28, align 8
  store i64 %26, ptr %v29, align 8
  store i64 6, ptr %1, align 8
  %48 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %ok34
  call fastcc void @native_trap() #111
  unreachable

51:                                               ; preds = %ok34
  %52 = getelementptr inbounds nuw i8, ptr %48, i64 376
  %53 = load i64, ptr %52, align 8, !noundef !39
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %55, label %59

55:                                               ; preds = %65, %59, %51
  %56 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %57 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %48, i64 noundef 24, ptr noundef %56) #84
  %58 = icmp eq ptr %57, null
  br i1 %58, label %67, label %ok54

59:                                               ; preds = %51
  %60 = getelementptr inbounds nuw i8, ptr %48, i64 368
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = add i64 %61, 1
  store i64 %62, ptr %60, align 8
  %63 = urem i64 %62, %53
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %65, label %55

65:                                               ; preds = %59
  %66 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %48, ptr noundef %66) #84
  br label %55

67:                                               ; preds = %55
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok54:                                             ; preds = %55
  %68 = ptrtoint ptr %57 to i64
  store i64 58, ptr %57, align 1
  %v61 = getelementptr i8, ptr %57, i64 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v61, align 1
  %v66 = getelementptr i8, ptr %57, i64 16
  store i64 %47, ptr %v66, align 1
  store i64 %68, ptr %v24, align 1
  %v72 = load i64, ptr %v4, align 8
  %v73.not = icmp eq i64 %v72, 0
  br i1 %v73.not, label %trap74, label %ok75

trap74:                                           ; preds = %ok54
  call fastcc void @native_trap()
  unreachable

ok75:                                             ; preds = %ok54
  %v76 = inttoptr i64 %v72 to ptr
  %v77 = getelementptr i8, ptr %v76, i64 8
  store i32 1, ptr %v77, align 1
  %v78 = load i64, ptr %v4, align 8
  %v79.not = icmp eq i64 %v78, 0
  br i1 %v79.not, label %trap80, label %ok81

trap80:                                           ; preds = %ok75
  call fastcc void @native_trap()
  unreachable

ok81:                                             ; preds = %ok75
  %v82 = inttoptr i64 %v78 to ptr
  %v83 = getelementptr i8, ptr %v82, i64 8
  %v84 = load i32, ptr %v83, align 1
  %v85 = icmp eq i32 %v84, 0
  br i1 %v85, label %then89, label %ok94

then89:                                           ; preds = %ok81
  call fastcc void @native_trap()
  unreachable

ok94:                                             ; preds = %ok81
  %v96 = getelementptr i8, ptr %v82, i64 16
  %v97 = load i64, ptr %v96, align 1
  %v98.not = icmp eq i64 %v97, 0
  br i1 %v98.not, label %trap99, label %ok100

trap99:                                           ; preds = %ok94
  call fastcc void @native_trap()
  unreachable

ok100:                                            ; preds = %ok94
  store i64 %v97, ptr %v5, align 8
  %v104 = inttoptr i64 %v97 to ptr
  %v113 = getelementptr i8, ptr %v104, i64 8
  %v114 = load i64, ptr %v113, align 1
  %v115.not = icmp eq i64 %v114, 0
  br i1 %v115.not, label %trap116, label %ok117

trap116:                                          ; preds = %ok100
  call fastcc void @native_trap()
  unreachable

ok117:                                            ; preds = %ok100
  %v105 = getelementptr i8, ptr %v104, i64 16
  %v106 = load i64, ptr %v105, align 1
  %v118 = inttoptr i64 %v114 to ptr
  %v119 = getelementptr i8, ptr %v118, i64 8
  %v120 = load ptr, ptr %v119, align 1
  %69 = load i64, ptr %0, align 8, !noundef !39
  %70 = icmp eq i64 %69, 0
  br i1 %70, label %native_roots_leave.exit, label %71

71:                                               ; preds = %ok117
  %72 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %72, ptr @native_roots.0, align 8
  %73 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %74 = add i64 %73, -1
  store i64 %74, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %71, %ok117
  %v121 = tail call tailcc i64 %v120(i64 %v106, i64 %arg1, i64 0)
  ret i64 %v121
}

define internal tailcc i64 @f.7(i64 %arg0, i64 %arg1) #102 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [7 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 7, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v8 = icmp ugt i64 %arg1, 4294967295
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  br i1 %v8, label %then12, label %block10

then12:                                           ; preds = %entry
  call fastcc void @native_trap()
  unreachable

block10:                                          ; preds = %entry
  store i64 3, ptr %1, align 8
  %7 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %10

9:                                                ; preds = %block10
  call fastcc void @native_trap() #111
  unreachable

10:                                               ; preds = %block10
  %11 = getelementptr inbounds nuw i8, ptr %7, i64 376
  %12 = load i64, ptr %11, align 8, !noundef !39
  %13 = icmp eq i64 %12, 0
  br i1 %13, label %14, label %18

14:                                               ; preds = %24, %18, %10
  %15 = phi ptr [ %.pre, %24 ], [ %roots, %18 ], [ %roots, %10 ]
  %16 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %7, i64 noundef 24, ptr noundef %15) #84
  %17 = icmp eq ptr %16, null
  br i1 %17, label %25, label %ok18

18:                                               ; preds = %10
  %19 = getelementptr inbounds nuw i8, ptr %7, i64 368
  %20 = load i64, ptr %19, align 8, !noundef !39
  %21 = add i64 %20, 1
  store i64 %21, ptr %19, align 8
  %22 = urem i64 %21, %12
  %23 = icmp eq i64 %22, 0
  br i1 %23, label %24, label %14

24:                                               ; preds = %18
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %7, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %14

25:                                               ; preds = %14
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok18:                                             ; preds = %14
  %26 = ptrtoint ptr %16 to i64
  store i64 26, ptr %16, align 1
  %v25 = getelementptr i8, ptr %16, i64 8
  store i32 0, ptr %v25, align 1
  %v30 = getelementptr i8, ptr %16, i64 16
  store i64 0, ptr %v30, align 1
  store i64 %26, ptr %v3, align 8
  %v33 = trunc nuw i64 %arg1 to i32
  %v34 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v34, align 8
  %v35 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 %26, ptr %v35, align 8
  store i64 5, ptr %1, align 8
  %v37 = call fastcc i64 @native_array_new(i32 %v33)
  store i64 %v37, ptr %v34, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v35, align 8
  %v40 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %26, ptr %v40, align 8
  store i64 6, ptr %1, align 8
  %27 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %28 = icmp eq ptr %27, null
  br i1 %28, label %29, label %30

29:                                               ; preds = %ok18
  call fastcc void @native_trap() #111
  unreachable

30:                                               ; preds = %ok18
  %31 = getelementptr inbounds nuw i8, ptr %27, i64 376
  %32 = load i64, ptr %31, align 8, !noundef !39
  %33 = icmp eq i64 %32, 0
  br i1 %33, label %34, label %38

34:                                               ; preds = %44, %38, %30
  %35 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %36 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %27, i64 noundef 16, ptr noundef %35) #84
  %37 = icmp eq ptr %36, null
  br i1 %37, label %46, label %ok45

38:                                               ; preds = %30
  %39 = getelementptr inbounds nuw i8, ptr %27, i64 368
  %40 = load i64, ptr %39, align 8, !noundef !39
  %41 = add i64 %40, 1
  store i64 %41, ptr %39, align 8
  %42 = urem i64 %41, %32
  %43 = icmp eq i64 %42, 0
  br i1 %43, label %44, label %34

44:                                               ; preds = %38
  %45 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %27, ptr noundef %45) #84
  br label %34

46:                                               ; preds = %34
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok45:                                             ; preds = %34
  %47 = ptrtoint ptr %36 to i64
  store i64 18, ptr %36, align 1
  %v52 = getelementptr i8, ptr %36, i64 8
  store i64 %v37, ptr %v52, align 1
  %v53 = load i64, ptr %v3, align 8
  store i64 %v53, ptr %v34, align 8
  store i64 %47, ptr %v35, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v40, align 8
  %v57 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  store i64 %26, ptr %v57, align 8
  store i64 7, ptr %1, align 8
  %48 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %49 = icmp eq ptr %48, null
  br i1 %49, label %50, label %51

50:                                               ; preds = %ok45
  call fastcc void @native_trap() #111
  unreachable

51:                                               ; preds = %ok45
  %52 = getelementptr inbounds nuw i8, ptr %48, i64 376
  %53 = load i64, ptr %52, align 8, !noundef !39
  %54 = icmp eq i64 %53, 0
  br i1 %54, label %55, label %59

55:                                               ; preds = %65, %59, %51
  %56 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %57 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %48, i64 noundef 32, ptr noundef %56) #84
  %58 = icmp eq ptr %57, null
  br i1 %58, label %67, label %ok62

59:                                               ; preds = %51
  %60 = getelementptr inbounds nuw i8, ptr %48, i64 368
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = add i64 %61, 1
  store i64 %62, ptr %60, align 8
  %63 = urem i64 %62, %53
  %64 = icmp eq i64 %63, 0
  br i1 %64, label %65, label %55

65:                                               ; preds = %59
  %66 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %48, ptr noundef %66) #84
  br label %55

67:                                               ; preds = %55
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok62:                                             ; preds = %55
  %68 = ptrtoint ptr %57 to i64
  store i64 14, ptr %57, align 1
  %v69 = getelementptr i8, ptr %57, i64 8
  store i64 %arg1, ptr %v69, align 1
  %v74 = getelementptr i8, ptr %57, i64 16
  store i64 %47, ptr %v74, align 1
  %v79 = getelementptr i8, ptr %57, i64 24
  store i64 %v53, ptr %v79, align 1
  store i64 %68, ptr %v34, align 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v35, align 8
  store i64 %26, ptr %v40, align 8
  store i64 6, ptr %1, align 8
  %69 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %70 = icmp eq ptr %69, null
  br i1 %70, label %71, label %72

71:                                               ; preds = %ok62
  call fastcc void @native_trap() #111
  unreachable

72:                                               ; preds = %ok62
  %73 = getelementptr inbounds nuw i8, ptr %69, i64 376
  %74 = load i64, ptr %73, align 8, !noundef !39
  %75 = icmp eq i64 %74, 0
  br i1 %75, label %76, label %80

76:                                               ; preds = %86, %80, %72
  %77 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %78 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %69, i64 noundef 24, ptr noundef %77) #84
  %79 = icmp eq ptr %78, null
  br i1 %79, label %88, label %ok87

80:                                               ; preds = %72
  %81 = getelementptr inbounds nuw i8, ptr %69, i64 368
  %82 = load i64, ptr %81, align 8, !noundef !39
  %83 = add i64 %82, 1
  store i64 %83, ptr %81, align 8
  %84 = urem i64 %83, %74
  %85 = icmp eq i64 %84, 0
  br i1 %85, label %86, label %76

86:                                               ; preds = %80
  %87 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %69, ptr noundef %87) #84
  br label %76

88:                                               ; preds = %76
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok87:                                             ; preds = %76
  %89 = ptrtoint ptr %78 to i64
  store i64 54, ptr %78, align 1
  %v94 = getelementptr i8, ptr %78, i64 8
  store i64 ptrtoint (ptr @ref.8 to i64), ptr %v94, align 1
  %v99 = getelementptr i8, ptr %78, i64 16
  store i64 %68, ptr %v99, align 1
  store i64 %89, ptr %v30, align 1
  %v105 = load i64, ptr %v3, align 8
  %v106.not = icmp eq i64 %v105, 0
  br i1 %v106.not, label %trap107, label %ok108

trap107:                                          ; preds = %ok87
  call fastcc void @native_trap()
  unreachable

ok108:                                            ; preds = %ok87
  %v109 = inttoptr i64 %v105 to ptr
  %v110 = getelementptr i8, ptr %v109, i64 8
  store i32 1, ptr %v110, align 1
  %v111 = load i64, ptr %v3, align 8
  %v112.not = icmp eq i64 %v111, 0
  br i1 %v112.not, label %trap113, label %ok114

trap113:                                          ; preds = %ok108
  call fastcc void @native_trap()
  unreachable

ok114:                                            ; preds = %ok108
  %v115 = inttoptr i64 %v111 to ptr
  %v116 = getelementptr i8, ptr %v115, i64 8
  %v117 = load i32, ptr %v116, align 1
  %v118 = icmp eq i32 %v117, 0
  br i1 %v118, label %then122, label %ok127

then122:                                          ; preds = %ok114
  call fastcc void @native_trap()
  unreachable

ok127:                                            ; preds = %ok114
  %v129 = getelementptr i8, ptr %v115, i64 16
  %v130 = load i64, ptr %v129, align 1
  %v131.not = icmp eq i64 %v130, 0
  br i1 %v131.not, label %trap132, label %ok133

trap132:                                          ; preds = %ok127
  call fastcc void @native_trap()
  unreachable

ok133:                                            ; preds = %ok127
  store i64 %v130, ptr %v4, align 8
  %v137 = inttoptr i64 %v130 to ptr
  %v145 = getelementptr i8, ptr %v137, i64 8
  %v146 = load i64, ptr %v145, align 1
  %v147.not = icmp eq i64 %v146, 0
  br i1 %v147.not, label %trap148, label %ok149

trap148:                                          ; preds = %ok133
  call fastcc void @native_trap()
  unreachable

ok149:                                            ; preds = %ok133
  %v138 = getelementptr i8, ptr %v137, i64 16
  %v139 = load i64, ptr %v138, align 1
  %v150 = inttoptr i64 %v146 to ptr
  %v151 = getelementptr i8, ptr %v150, i64 8
  %v152 = load ptr, ptr %v151, align 1
  %90 = load i64, ptr %0, align 8, !noundef !39
  %91 = icmp eq i64 %90, 0
  br i1 %91, label %native_roots_leave.exit, label %92

92:                                               ; preds = %ok149
  %93 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %93, ptr @native_roots.0, align 8
  %94 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %95 = add i64 %94, -1
  store i64 %95, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %92, %ok149
  %v153 = tail call tailcc i64 %v152(i64 %v139, i64 0)
  ret i64 %v153
}

define internal tailcc noundef i64 @f.5(i64 %arg0, i64 %arg1, i64 %arg2) #103 personality ptr @rust_eh_personality {
entry:
  %0 = alloca [8 x i8], align 8
  %roots = alloca { ptr, i64, i64, [1 x i64] }, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 1, ptr %1, align 8
  %2 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %3 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %3, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %4 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %5 = add i64 %4, 1
  store i64 %5, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %6 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %7 = call noundef i64 @llvm.umax.i64(i64 %5, i64 %6)
  store i64 %7, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  store i64 1, ptr %2, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %0)
  store i64 %arg2, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %0) #84, !srcloc !75600
  %8 = load i64, ptr %0, align 8, !noundef !39
  call void @llvm.lifetime.end.p0(ptr nonnull %0)
  %9 = load i64, ptr %1, align 8, !noundef !39
  %10 = icmp eq i64 %9, 0
  br i1 %10, label %native_roots_leave.exit1, label %11

11:                                               ; preds = %entry
  %12 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %12, ptr @native_roots.0, align 8
  %13 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %14 = add i64 %13, -1
  store i64 %14, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit1

native_roots_leave.exit1:                         ; preds = %11, %entry
  ret i64 %8
}
