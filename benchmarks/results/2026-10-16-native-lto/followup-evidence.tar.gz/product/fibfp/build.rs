fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/snail-native-lto-black-box-20261016/fibfp/module.bc");
}
