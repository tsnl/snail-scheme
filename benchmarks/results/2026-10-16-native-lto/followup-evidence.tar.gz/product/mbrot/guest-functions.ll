define internal tailcc i64 @f.2(i64 %arg0, i64 %arg1, i64 %arg2) #102 personality ptr @rust_eh_personality {
entry:
  %0 = alloca [8 x i8], align 8
  %roots = alloca { ptr, i64, i64, [8 x i64] }, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 8, ptr %1, align 8
  %2 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %2, align 8
  %3 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %3, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %4 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %5 = add i64 %4, 1
  store i64 %5, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %6 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %7 = call noundef i64 @llvm.umax.i64(i64 %5, i64 %6)
  store i64 %7, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v6 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v10.not44 = icmp eq i64 %arg0, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  br i1 %v10.not44, label %trap11, label %ok12.lr.ph

ok12.lr.ph:                                       ; preds = %entry
  %v84 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v85 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v92 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v99 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  %v13153 = inttoptr i64 %arg0 to ptr
  %v14154 = getelementptr i8, ptr %v13153, i64 8
  %v15155 = load i64, ptr %v14154, align 1
  %v17156 = icmp sgt i64 %v15155, %arg1
  br i1 %v17156, label %then22, label %else21

trap11:                                           ; preds = %ok406, %entry
  call fastcc void @native_trap()
  unreachable

ok12:                                             ; preds = %ok406
  %v411 = add nsw i64 %arg1.tr46157, 1
  %v13 = inttoptr i64 %v409 to ptr
  %v14 = getelementptr i8, ptr %v13, i64 8
  %v15 = load i64, ptr %v14, align 1
  %v17 = icmp sgt i64 %v15, %v411
  br i1 %v17, label %then22, label %else21.loopexit

then22:                                           ; preds = %ok12, %ok12.lr.ph
  %arg1.tr46157 = phi i64 [ %v411, %ok12 ], [ %arg1, %ok12.lr.ph ]
  %v24.b = load i1, ptr @g.10, align 1
  br i1 %v24.b, label %block27, label %then29

then29:                                           ; preds = %then22
  call fastcc void @native_trap()
  unreachable

block27:                                          ; preds = %then22
  %v31.b = load i1, ptr @g.2, align 1
  br i1 %v31.b, label %block34, label %then36

then36:                                           ; preds = %block27
  call fastcc void @native_trap()
  unreachable

block34:                                          ; preds = %block27
  %v38 = load i64, ptr @g.1, align 8
  %v39.not = icmp eq i64 %v38, 0
  br i1 %v39.not, label %trap40, label %ok41

trap40:                                           ; preds = %block34
  call fastcc void @native_trap()
  unreachable

ok41:                                             ; preds = %block34
  %v45 = load i64, ptr @g.9, align 8
  store i64 4, ptr %2, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %0)
  store i64 %v45, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %0) #84, !srcloc !75600
  %8 = load i64, ptr %0, align 8, !noundef !39
  call void @llvm.lifetime.end.p0(ptr nonnull %0)
  %v48.b = load i1, ptr @g.8, align 1
  br i1 %v48.b, label %block51, label %then53

then53:                                           ; preds = %ok41
  call fastcc void @native_trap()
  unreachable

block51:                                          ; preds = %ok41
  %v55 = load i64, ptr @g.7, align 8
  %v56.not = icmp eq i64 %v55, 0
  br i1 %v56.not, label %trap57, label %ok58

trap57:                                           ; preds = %block51
  call fastcc void @native_trap()
  unreachable

ok58:                                             ; preds = %block51
  %v60 = icmp ugt i64 %8, 4294967295
  br i1 %v60, label %then64, label %block62

then64:                                           ; preds = %ok58
  call fastcc void @native_trap()
  unreachable

block62:                                          ; preds = %ok58
  store i64 4, ptr %2, align 8
  %9 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %10 = icmp eq ptr %9, null
  br i1 %10, label %11, label %12

11:                                               ; preds = %block62
  call fastcc void @native_trap() #111
  unreachable

12:                                               ; preds = %block62
  %13 = getelementptr inbounds nuw i8, ptr %9, i64 376
  %14 = load i64, ptr %13, align 8, !noundef !39
  %15 = icmp eq i64 %14, 0
  br i1 %15, label %16, label %20

16:                                               ; preds = %26, %20, %12
  %17 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %18 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %9, i64 noundef 24, ptr noundef %17) #84
  %19 = icmp eq ptr %18, null
  br i1 %19, label %28, label %ok70

20:                                               ; preds = %12
  %21 = getelementptr inbounds nuw i8, ptr %9, i64 368
  %22 = load i64, ptr %21, align 8, !noundef !39
  %23 = add i64 %22, 1
  store i64 %23, ptr %21, align 8
  %24 = urem i64 %23, %14
  %25 = icmp eq i64 %24, 0
  br i1 %25, label %26, label %16

26:                                               ; preds = %20
  %27 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %9, ptr noundef %27) #84
  br label %16

28:                                               ; preds = %16
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok70:                                             ; preds = %16
  %29 = ptrtoint ptr %18 to i64
  store i64 58, ptr %18, align 1
  %v77 = getelementptr i8, ptr %18, i64 8
  store i32 0, ptr %v77, align 1
  %v82 = getelementptr i8, ptr %18, i64 16
  store i64 0, ptr %v82, align 1
  store i64 %29, ptr %v4, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v84, align 8
  store i64 %29, ptr %v85, align 8
  store i64 6, ptr %2, align 8
  %30 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %31 = icmp eq ptr %30, null
  br i1 %31, label %32, label %33

32:                                               ; preds = %ok70
  call fastcc void @native_trap() #111
  unreachable

33:                                               ; preds = %ok70
  %34 = getelementptr inbounds nuw i8, ptr %30, i64 376
  %35 = load i64, ptr %34, align 8, !noundef !39
  %36 = icmp eq i64 %35, 0
  br i1 %36, label %37, label %41

37:                                               ; preds = %47, %41, %33
  %38 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %39 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %30, i64 noundef 16, ptr noundef %38) #84
  %40 = icmp eq ptr %39, null
  br i1 %40, label %49, label %50

41:                                               ; preds = %33
  %42 = getelementptr inbounds nuw i8, ptr %30, i64 368
  %43 = load i64, ptr %42, align 8, !noundef !39
  %44 = add i64 %43, 1
  store i64 %44, ptr %42, align 8
  %45 = urem i64 %44, %35
  %46 = icmp eq i64 %45, 0
  br i1 %46, label %47, label %37

47:                                               ; preds = %41
  %48 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %30, ptr noundef %48) #84
  br label %37

49:                                               ; preds = %37
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

50:                                               ; preds = %37
  %51 = ptrtoint ptr %39 to i64
  %52 = and i64 %51, 1
  %53 = icmp eq i64 %52, 0
  br i1 %53, label %native_array_new.exit, label %54

54:                                               ; preds = %50
  call fastcc void @native_trap() #111
  unreachable

native_array_new.exit:                            ; preds = %50
  store i64 43, ptr %39, align 8
  %55 = getelementptr inbounds nuw i8, ptr %39, i64 8
  store i64 0, ptr %55, align 8
  %v89 = trunc nuw i64 %8 to i32
  store i64 %51, ptr %v84, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v85, align 8
  store i64 %29, ptr %v92, align 8
  store i64 7, ptr %2, align 8
  %v94 = call fastcc i64 @native_array_new(i64 51, i32 %v89, i64 %51)
  store i64 %v94, ptr %v6, align 8
  %v95 = load i64, ptr %v4, align 8
  store i64 %v95, ptr %v84, align 8
  store i64 %v94, ptr %v85, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v92, align 8
  store i64 %29, ptr %v99, align 8
  store i64 8, ptr %2, align 8
  %56 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %57 = icmp eq ptr %56, null
  br i1 %57, label %58, label %59

58:                                               ; preds = %native_array_new.exit
  call fastcc void @native_trap() #111
  unreachable

59:                                               ; preds = %native_array_new.exit
  %60 = getelementptr inbounds nuw i8, ptr %56, i64 376
  %61 = load i64, ptr %60, align 8, !noundef !39
  %62 = icmp eq i64 %61, 0
  br i1 %62, label %63, label %67

63:                                               ; preds = %73, %67, %59
  %64 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %65 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %56, i64 noundef 32, ptr noundef %64) #84
  %66 = icmp eq ptr %65, null
  br i1 %66, label %75, label %ok104

67:                                               ; preds = %59
  %68 = getelementptr inbounds nuw i8, ptr %56, i64 368
  %69 = load i64, ptr %68, align 8, !noundef !39
  %70 = add i64 %69, 1
  store i64 %70, ptr %68, align 8
  %71 = urem i64 %70, %61
  %72 = icmp eq i64 %71, 0
  br i1 %72, label %73, label %63

73:                                               ; preds = %67
  %74 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %56, ptr noundef %74) #84
  br label %63

75:                                               ; preds = %63
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok104:                                            ; preds = %63
  %76 = ptrtoint ptr %65 to i64
  store i64 38, ptr %65, align 1
  %v111 = getelementptr i8, ptr %65, i64 8
  store i64 %8, ptr %v111, align 1
  %v116 = getelementptr i8, ptr %65, i64 16
  store i64 %v94, ptr %v116, align 1
  %v121 = getelementptr i8, ptr %65, i64 24
  store i64 %v95, ptr %v121, align 1
  store i64 %76, ptr %v84, align 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v85, align 8
  store i64 %29, ptr %v92, align 8
  store i64 7, ptr %2, align 8
  %77 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %78 = icmp eq ptr %77, null
  br i1 %78, label %79, label %80

79:                                               ; preds = %ok104
  call fastcc void @native_trap() #111
  unreachable

80:                                               ; preds = %ok104
  %81 = getelementptr inbounds nuw i8, ptr %77, i64 376
  %82 = load i64, ptr %81, align 8, !noundef !39
  %83 = icmp eq i64 %82, 0
  br i1 %83, label %84, label %88

84:                                               ; preds = %94, %88, %80
  %85 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %86 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %77, i64 noundef 24, ptr noundef %85) #84
  %87 = icmp eq ptr %86, null
  br i1 %87, label %96, label %ok129

88:                                               ; preds = %80
  %89 = getelementptr inbounds nuw i8, ptr %77, i64 368
  %90 = load i64, ptr %89, align 8, !noundef !39
  %91 = add i64 %90, 1
  store i64 %91, ptr %89, align 8
  %92 = urem i64 %91, %82
  %93 = icmp eq i64 %92, 0
  br i1 %93, label %94, label %84

94:                                               ; preds = %88
  %95 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %77, ptr noundef %95) #84
  br label %84

96:                                               ; preds = %84
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok129:                                            ; preds = %84
  %97 = ptrtoint ptr %86 to i64
  store i64 54, ptr %86, align 1
  %v136 = getelementptr i8, ptr %86, i64 8
  store i64 ptrtoint (ptr @ref.7 to i64), ptr %v136, align 1
  %v141 = getelementptr i8, ptr %86, i64 16
  store i64 %76, ptr %v141, align 1
  store i64 %97, ptr %v82, align 1
  %v147 = load i64, ptr %v4, align 8
  %v148.not = icmp eq i64 %v147, 0
  br i1 %v148.not, label %trap149, label %ok150

trap149:                                          ; preds = %ok129
  call fastcc void @native_trap()
  unreachable

ok150:                                            ; preds = %ok129
  %v151 = inttoptr i64 %v147 to ptr
  %v152 = getelementptr i8, ptr %v151, i64 8
  store i32 1, ptr %v152, align 1
  %v153 = load i64, ptr %v4, align 8
  %v154.not = icmp eq i64 %v153, 0
  br i1 %v154.not, label %trap155, label %ok156

trap155:                                          ; preds = %ok150
  call fastcc void @native_trap()
  unreachable

ok156:                                            ; preds = %ok150
  %v157 = inttoptr i64 %v153 to ptr
  %v158 = getelementptr i8, ptr %v157, i64 8
  %v159 = load i32, ptr %v158, align 1
  %v160 = icmp eq i32 %v159, 0
  br i1 %v160, label %then164, label %ok169

then164:                                          ; preds = %ok156
  call fastcc void @native_trap()
  unreachable

ok169:                                            ; preds = %ok156
  %v171 = getelementptr i8, ptr %v157, i64 16
  %v172 = load i64, ptr %v171, align 1
  %v173.not = icmp eq i64 %v172, 0
  br i1 %v173.not, label %trap174, label %ok175

trap174:                                          ; preds = %ok169
  call fastcc void @native_trap()
  unreachable

ok175:                                            ; preds = %ok169
  store i64 %v172, ptr %v5, align 8
  %v179 = inttoptr i64 %v172 to ptr
  %v183 = add nsw i64 %8, -1
  %v189 = getelementptr i8, ptr %v179, i64 8
  %v190 = load i64, ptr %v189, align 1
  %v191.not = icmp eq i64 %v190, 0
  br i1 %v191.not, label %trap192, label %ok193

trap192:                                          ; preds = %ok175
  call fastcc void @native_trap()
  unreachable

ok193:                                            ; preds = %ok175
  %v180 = getelementptr i8, ptr %v179, i64 16
  %v181 = load i64, ptr %v180, align 1
  %v194 = inttoptr i64 %v190 to ptr
  %v195 = getelementptr i8, ptr %v194, i64 8
  %v196 = load ptr, ptr %v195, align 1
  store i64 %v181, ptr %v84, align 8
  store i64 5, ptr %2, align 8
  %v199 = call tailcc i32 %v196(i64 %v181, i64 %v183)
  %v200.b = load i1, ptr @g.6, align 1
  br i1 %v200.b, label %block203, label %then205

then205:                                          ; preds = %ok193
  call fastcc void @native_trap()
  unreachable

block203:                                         ; preds = %ok193
  %v207 = load i64, ptr @g.5, align 8
  %v208.not = icmp eq i64 %v207, 0
  br i1 %v208.not, label %trap209, label %ok210

trap209:                                          ; preds = %block203
  call fastcc void @native_trap()
  unreachable

ok210:                                            ; preds = %block203
  store i64 4, ptr %2, align 8
  %98 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %99 = icmp eq ptr %98, null
  br i1 %99, label %100, label %101

100:                                              ; preds = %ok210
  call fastcc void @native_trap() #111
  unreachable

101:                                              ; preds = %ok210
  %102 = getelementptr inbounds nuw i8, ptr %98, i64 376
  %103 = load i64, ptr %102, align 8, !noundef !39
  %104 = icmp eq i64 %103, 0
  br i1 %104, label %105, label %109

105:                                              ; preds = %115, %109, %101
  %106 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %107 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %98, i64 noundef 24, ptr noundef %106) #84
  %108 = icmp eq ptr %107, null
  br i1 %108, label %117, label %ok215

109:                                              ; preds = %101
  %110 = getelementptr inbounds nuw i8, ptr %98, i64 368
  %111 = load i64, ptr %110, align 8, !noundef !39
  %112 = add i64 %111, 1
  store i64 %112, ptr %110, align 8
  %113 = urem i64 %112, %103
  %114 = icmp eq i64 %113, 0
  br i1 %114, label %115, label %105

115:                                              ; preds = %109
  %116 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %98, ptr noundef %116) #84
  br label %105

117:                                              ; preds = %105
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok215:                                            ; preds = %105
  %118 = ptrtoint ptr %107 to i64
  store i64 58, ptr %107, align 1
  %v222 = getelementptr i8, ptr %107, i64 8
  store i32 0, ptr %v222, align 1
  %v227 = getelementptr i8, ptr %107, i64 16
  store i64 0, ptr %v227, align 1
  store i64 %118, ptr %v4, align 8
  %v228 = load i64, ptr %v6, align 8
  store i64 %118, ptr %v84, align 8
  store i64 %v228, ptr %v85, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v92, align 8
  store i64 %118, ptr %v99, align 8
  store i64 8, ptr %2, align 8
  %119 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %120 = icmp eq ptr %119, null
  br i1 %120, label %121, label %122

121:                                              ; preds = %ok215
  call fastcc void @native_trap() #111
  unreachable

122:                                              ; preds = %ok215
  %123 = getelementptr inbounds nuw i8, ptr %119, i64 376
  %124 = load i64, ptr %123, align 8, !noundef !39
  %125 = icmp eq i64 %124, 0
  br i1 %125, label %126, label %130

126:                                              ; preds = %136, %130, %122
  %127 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %128 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %119, i64 noundef 32, ptr noundef %127) #84
  %129 = icmp eq ptr %128, null
  br i1 %129, label %138, label %ok239

130:                                              ; preds = %122
  %131 = getelementptr inbounds nuw i8, ptr %119, i64 368
  %132 = load i64, ptr %131, align 8, !noundef !39
  %133 = add i64 %132, 1
  store i64 %133, ptr %131, align 8
  %134 = urem i64 %133, %124
  %135 = icmp eq i64 %134, 0
  br i1 %135, label %136, label %126

136:                                              ; preds = %130
  %137 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %119, ptr noundef %137) #84
  br label %126

138:                                              ; preds = %126
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok239:                                            ; preds = %126
  %139 = ptrtoint ptr %128 to i64
  store i64 30, ptr %128, align 1
  %v246 = getelementptr i8, ptr %128, i64 8
  store i64 %v228, ptr %v246, align 1
  %v251 = getelementptr i8, ptr %128, i64 16
  store i64 %8, ptr %v251, align 1
  %v256 = getelementptr i8, ptr %128, i64 24
  store i64 %118, ptr %v256, align 1
  store i64 %139, ptr %v84, align 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v85, align 8
  store i64 %118, ptr %v92, align 8
  store i64 7, ptr %2, align 8
  %140 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %141 = icmp eq ptr %140, null
  br i1 %141, label %142, label %143

142:                                              ; preds = %ok239
  call fastcc void @native_trap() #111
  unreachable

143:                                              ; preds = %ok239
  %144 = getelementptr inbounds nuw i8, ptr %140, i64 376
  %145 = load i64, ptr %144, align 8, !noundef !39
  %146 = icmp eq i64 %145, 0
  br i1 %146, label %147, label %151

147:                                              ; preds = %157, %151, %143
  %148 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %149 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %140, i64 noundef 24, ptr noundef %148) #84
  %150 = icmp eq ptr %149, null
  br i1 %150, label %159, label %ok264

151:                                              ; preds = %143
  %152 = getelementptr inbounds nuw i8, ptr %140, i64 368
  %153 = load i64, ptr %152, align 8, !noundef !39
  %154 = add i64 %153, 1
  store i64 %154, ptr %152, align 8
  %155 = urem i64 %154, %145
  %156 = icmp eq i64 %155, 0
  br i1 %156, label %157, label %147

157:                                              ; preds = %151
  %158 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %140, ptr noundef %158) #84
  br label %147

159:                                              ; preds = %147
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok264:                                            ; preds = %147
  %160 = ptrtoint ptr %149 to i64
  store i64 54, ptr %149, align 1
  %v271 = getelementptr i8, ptr %149, i64 8
  store i64 ptrtoint (ptr @ref.4 to i64), ptr %v271, align 1
  %v276 = getelementptr i8, ptr %149, i64 16
  store i64 %139, ptr %v276, align 1
  store i64 %160, ptr %v227, align 1
  %v282 = load i64, ptr %v4, align 8
  %v283.not = icmp eq i64 %v282, 0
  br i1 %v283.not, label %trap284, label %ok285

trap284:                                          ; preds = %ok264
  call fastcc void @native_trap()
  unreachable

ok285:                                            ; preds = %ok264
  %v286 = inttoptr i64 %v282 to ptr
  %v287 = getelementptr i8, ptr %v286, i64 8
  store i32 1, ptr %v287, align 1
  %v288 = load i64, ptr %v4, align 8
  %v289.not = icmp eq i64 %v288, 0
  br i1 %v289.not, label %trap290, label %ok291

trap290:                                          ; preds = %ok285
  call fastcc void @native_trap()
  unreachable

ok291:                                            ; preds = %ok285
  %v292 = inttoptr i64 %v288 to ptr
  %v293 = getelementptr i8, ptr %v292, i64 8
  %v294 = load i32, ptr %v293, align 1
  %v295 = icmp eq i32 %v294, 0
  br i1 %v295, label %then299, label %ok304

then299:                                          ; preds = %ok291
  call fastcc void @native_trap()
  unreachable

ok304:                                            ; preds = %ok291
  %v306 = getelementptr i8, ptr %v292, i64 16
  %v307 = load i64, ptr %v306, align 1
  %v308.not = icmp eq i64 %v307, 0
  br i1 %v308.not, label %trap309, label %ok310

trap309:                                          ; preds = %ok304
  call fastcc void @native_trap()
  unreachable

ok310:                                            ; preds = %ok304
  store i64 %v307, ptr %v5, align 8
  %v314 = inttoptr i64 %v307 to ptr
  %v324 = getelementptr i8, ptr %v314, i64 8
  %v325 = load i64, ptr %v324, align 1
  %v326.not = icmp eq i64 %v325, 0
  br i1 %v326.not, label %trap327, label %ok328

trap327:                                          ; preds = %ok310
  call fastcc void @native_trap()
  unreachable

ok328:                                            ; preds = %ok310
  %v315 = getelementptr i8, ptr %v314, i64 16
  %v316 = load i64, ptr %v315, align 1
  %v329 = inttoptr i64 %v325 to ptr
  %v330 = getelementptr i8, ptr %v329, i64 8
  %v331 = load ptr, ptr %v330, align 1
  store i64 %v316, ptr %v84, align 8
  store i64 5, ptr %2, align 8
  %v334 = call tailcc i32 %v331(i64 %v316, i64 %v183)
  %v335 = load i64, ptr %v6, align 8
  %v336.not = icmp eq i64 %v335, 0
  br i1 %v336.not, label %trap337, label %ok338

trap337:                                          ; preds = %ok328
  call fastcc void @native_trap()
  unreachable

ok338:                                            ; preds = %ok328
  %v339 = and i64 %v335, 1
  %v340 = icmp eq i64 %v339, 0
  br i1 %v340, label %ok342, label %trap341

trap341:                                          ; preds = %ok338
  call fastcc void @native_trap()
  unreachable

ok342:                                            ; preds = %ok338
  %v343 = inttoptr i64 %v335 to ptr
  %v344 = getelementptr i8, ptr %v343, i64 8
  %v345 = load i64, ptr %v344, align 1
  %v347.not = icmp eq i64 %v345, 0
  br i1 %v347.not, label %trap348, label %ok349

trap348:                                          ; preds = %ok342
  call fastcc void @native_trap()
  unreachable

ok349:                                            ; preds = %ok342
  %v351 = getelementptr i8, ptr %v343, i64 16
  %v353 = load i64, ptr %v351, align 1
  %v354.not = icmp eq i64 %v353, 0
  br i1 %v354.not, label %trap355, label %ok356

trap355:                                          ; preds = %ok349
  call fastcc void @native_trap()
  unreachable

ok356:                                            ; preds = %ok349
  %v357 = and i64 %v353, 1
  %v358 = icmp eq i64 %v357, 0
  br i1 %v358, label %ok360, label %trap359

trap359:                                          ; preds = %ok356
  call fastcc void @native_trap()
  unreachable

ok360:                                            ; preds = %ok356
  %v361 = inttoptr i64 %v353 to ptr
  %v362 = getelementptr i8, ptr %v361, i64 8
  %v363 = load i64, ptr %v362, align 1
  %v365.not = icmp eq i64 %v363, 0
  br i1 %v365.not, label %trap366, label %ok367

trap366:                                          ; preds = %ok360
  call fastcc void @native_trap()
  unreachable

ok367:                                            ; preds = %ok360
  %v369 = getelementptr i8, ptr %v361, i64 16
  %v371 = load i64, ptr %v369, align 1
  %v372 = load i64, ptr %v1, align 8
  %v373.not = icmp eq i64 %v372, 0
  br i1 %v373.not, label %trap374, label %ok375

trap374:                                          ; preds = %ok367
  call fastcc void @native_trap()
  unreachable

ok375:                                            ; preds = %ok367
  %v376 = inttoptr i64 %v372 to ptr
  %v377 = getelementptr i8, ptr %v376, i64 16
  %v378 = load i64, ptr %v377, align 1
  %v379.not = icmp eq i64 %v378, 0
  br i1 %v379.not, label %trap380, label %ok381

trap380:                                          ; preds = %ok375
  call fastcc void @native_trap()
  unreachable

ok381:                                            ; preds = %ok375
  %v382 = inttoptr i64 %v378 to ptr
  %v383 = getelementptr i8, ptr %v382, i64 8
  %v384 = load i32, ptr %v383, align 1
  %v385 = icmp eq i32 %v384, 0
  br i1 %v385, label %then389, label %ok400

then389:                                          ; preds = %ok381
  call fastcc void @native_trap()
  unreachable

ok400:                                            ; preds = %ok381
  %v402 = getelementptr i8, ptr %v382, i64 16
  %v403 = load i64, ptr %v402, align 1
  %v404.not = icmp eq i64 %v403, 0
  br i1 %v404.not, label %trap405, label %ok406

trap405:                                          ; preds = %ok400
  call fastcc void @native_trap()
  unreachable

ok406:                                            ; preds = %ok400
  %v407 = inttoptr i64 %v403 to ptr
  %v408 = getelementptr i8, ptr %v407, i64 16
  %v409 = load i64, ptr %v408, align 1
  %161 = load i64, ptr %1, align 8, !noundef !39
  %162 = icmp eq i64 %161, 0
  %.pre13 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %163 = zext i1 %162 to i64
  %164 = add i64 %.pre13, %163
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %165 = select i1 %162, ptr %native_roots.0.val, ptr %roots.val
  store i64 8, ptr %1, align 8
  store i64 0, ptr %2, align 8
  store ptr %165, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %164, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %166 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %167 = call noundef i64 @llvm.umax.i64(i64 %164, i64 %166)
  store i64 %167, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v409, ptr %v1, align 8
  %v10.not = icmp eq i64 %v409, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v4, i8 0, i64 24, i1 false)
  br i1 %v10.not, label %trap11, label %ok12

else21.loopexit:                                  ; preds = %ok12
  %.lcssa50 = phi i64 [ %164, %ok12 ]
  %.lcssa48 = phi ptr [ %165, %ok12 ]
  %v371.lcssa47 = phi i64 [ %v371, %ok12 ]
  %168 = add i64 %.lcssa50, -1
  br label %else21

else21:                                           ; preds = %else21.loopexit, %ok12.lr.ph
  %169 = phi i64 [ %4, %ok12.lr.ph ], [ %168, %else21.loopexit ]
  %170 = phi ptr [ %3, %ok12.lr.ph ], [ %.lcssa48, %else21.loopexit ]
  %arg2.tr47.lcssa = phi i64 [ %arg2, %ok12.lr.ph ], [ %v371.lcssa47, %else21.loopexit ]
  store ptr %170, ptr @native_roots.0, align 8
  store i64 %169, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  ret i64 %arg2.tr47.lcssa
}

define internal tailcc i32 @f.4(i64 %arg0, i64 %arg1) #102 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [9 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 9, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v5 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v10 = icmp sgt i64 %arg1, -1
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v3, i8 0, i64 24, i1 false)
  br i1 %v10, label %then15, label %else14

then15:                                           ; preds = %entry
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap20

9:                                                ; preds = %then15
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %15
  call fastcc void @native_trap() #111
  unreachable

31:                                               ; preds = %.preheader
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader [
    i64 30, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in, 30
  br i1 %34, label %ok21, label %trap20

trap20:                                           ; preds = %native_ref_test.exit, %then15
  call fastcc void @native_trap()
  unreachable

ok21:                                             ; preds = %native_ref_test.exit
  store i64 %arg0, ptr %v4, align 8
  %v26 = getelementptr i8, ptr %10, i64 16
  %v27 = load i64, ptr %v26, align 1
  %v28 = add i64 %v27, -1
  store i64 4, ptr %1, align 8
  %35 = getelementptr inbounds nuw i8, ptr %12, i64 376
  %36 = load i64, ptr %35, align 8, !noundef !39
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %38, label %42

38:                                               ; preds = %48, %42, %ok21
  %39 = phi ptr [ %.pre, %48 ], [ %roots, %42 ], [ %roots, %ok21 ]
  %40 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %12, i64 noundef 24, ptr noundef %39) #84
  %41 = icmp eq ptr %40, null
  br i1 %41, label %49, label %ok33

42:                                               ; preds = %ok21
  %43 = getelementptr inbounds nuw i8, ptr %12, i64 368
  %44 = load i64, ptr %43, align 8, !noundef !39
  %45 = add i64 %44, 1
  store i64 %45, ptr %43, align 8
  %46 = urem i64 %45, %36
  %47 = icmp eq i64 %46, 0
  br i1 %47, label %48, label %38

48:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %12, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %38

49:                                               ; preds = %38
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok33:                                             ; preds = %38
  %50 = ptrtoint ptr %40 to i64
  store i64 58, ptr %40, align 1
  %v40 = getelementptr i8, ptr %40, i64 8
  store i32 0, ptr %v40, align 1
  %v45 = getelementptr i8, ptr %40, i64 16
  store i64 0, ptr %v45, align 1
  store i64 %50, ptr %v3, align 8
  %v46 = load i64, ptr %v4, align 8
  %v47.not = icmp eq i64 %v46, 0
  br i1 %v47.not, label %trap48, label %ok49

trap48:                                           ; preds = %ok33
  call fastcc void @native_trap()
  unreachable

ok49:                                             ; preds = %ok33
  %v50 = inttoptr i64 %v46 to ptr
  %v51 = getelementptr i8, ptr %v50, i64 8
  %v52 = load i64, ptr %v51, align 1
  %v58 = getelementptr i8, ptr %v50, i64 24
  %v59 = load i64, ptr %v58, align 1
  %v62 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  store i64 %50, ptr %v62, align 8
  %v63 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  store i64 %v59, ptr %v63, align 8
  %v64 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  store i64 %v52, ptr %v64, align 8
  %v65 = getelementptr inbounds nuw i8, ptr %roots, i64 80
  store i64 ptrtoint (ptr @ref.5 to i64), ptr %v65, align 8
  %v66 = getelementptr inbounds nuw i8, ptr %roots, i64 88
  store i64 %50, ptr %v66, align 8
  store i64 9, ptr %1, align 8
  %51 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %52 = icmp eq ptr %51, null
  br i1 %52, label %53, label %54

53:                                               ; preds = %ok49
  call fastcc void @native_trap() #111
  unreachable

54:                                               ; preds = %ok49
  %55 = getelementptr inbounds nuw i8, ptr %51, i64 376
  %56 = load i64, ptr %55, align 8, !noundef !39
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %58, label %62

58:                                               ; preds = %68, %62, %54
  %59 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %60 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %51, i64 noundef 40, ptr noundef %59) #84
  %61 = icmp eq ptr %60, null
  br i1 %61, label %70, label %ok71

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw i8, ptr %51, i64 368
  %64 = load i64, ptr %63, align 8, !noundef !39
  %65 = add i64 %64, 1
  store i64 %65, ptr %63, align 8
  %66 = urem i64 %65, %56
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %68, label %58

68:                                               ; preds = %62
  %69 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %51, ptr noundef %69) #84
  br label %58

70:                                               ; preds = %58
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok71:                                             ; preds = %58
  %71 = ptrtoint ptr %60 to i64
  store i64 22, ptr %60, align 1
  %v78 = getelementptr i8, ptr %60, i64 8
  store i64 %v52, ptr %v78, align 1
  %v83 = getelementptr i8, ptr %60, i64 16
  store i64 %v59, ptr %v83, align 1
  %v88 = getelementptr i8, ptr %60, i64 24
  store i64 %arg1, ptr %v88, align 1
  %v93 = getelementptr i8, ptr %60, i64 32
  store i64 %50, ptr %v93, align 1
  store i64 %71, ptr %v62, align 8
  store i64 ptrtoint (ptr @ref.5 to i64), ptr %v63, align 8
  store i64 %50, ptr %v64, align 8
  store i64 7, ptr %1, align 8
  %72 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %73 = icmp eq ptr %72, null
  br i1 %73, label %74, label %75

74:                                               ; preds = %ok71
  call fastcc void @native_trap() #111
  unreachable

75:                                               ; preds = %ok71
  %76 = getelementptr inbounds nuw i8, ptr %72, i64 376
  %77 = load i64, ptr %76, align 8, !noundef !39
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %79, label %83

79:                                               ; preds = %89, %83, %75
  %80 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %81 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %72, i64 noundef 24, ptr noundef %80) #84
  %82 = icmp eq ptr %81, null
  br i1 %82, label %91, label %ok101

83:                                               ; preds = %75
  %84 = getelementptr inbounds nuw i8, ptr %72, i64 368
  %85 = load i64, ptr %84, align 8, !noundef !39
  %86 = add i64 %85, 1
  store i64 %86, ptr %84, align 8
  %87 = urem i64 %86, %77
  %88 = icmp eq i64 %87, 0
  br i1 %88, label %89, label %79

89:                                               ; preds = %83
  %90 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %72, ptr noundef %90) #84
  br label %79

91:                                               ; preds = %79
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok101:                                            ; preds = %79
  %92 = ptrtoint ptr %81 to i64
  store i64 54, ptr %81, align 1
  %v108 = getelementptr i8, ptr %81, i64 8
  store i64 ptrtoint (ptr @ref.5 to i64), ptr %v108, align 1
  %v113 = getelementptr i8, ptr %81, i64 16
  store i64 %71, ptr %v113, align 1
  store i64 %92, ptr %v45, align 1
  %v119 = load i64, ptr %v3, align 8
  %v120.not = icmp eq i64 %v119, 0
  br i1 %v120.not, label %trap121, label %ok122

trap121:                                          ; preds = %ok101
  call fastcc void @native_trap()
  unreachable

ok122:                                            ; preds = %ok101
  %v123 = inttoptr i64 %v119 to ptr
  %v124 = getelementptr i8, ptr %v123, i64 8
  store i32 1, ptr %v124, align 1
  %v125 = load i64, ptr %v3, align 8
  %v126.not = icmp eq i64 %v125, 0
  br i1 %v126.not, label %trap127, label %ok128

trap127:                                          ; preds = %ok122
  call fastcc void @native_trap()
  unreachable

ok128:                                            ; preds = %ok122
  %v129 = inttoptr i64 %v125 to ptr
  %v130 = getelementptr i8, ptr %v129, i64 8
  %v131 = load i32, ptr %v130, align 1
  %v132 = icmp eq i32 %v131, 0
  br i1 %v132, label %then136, label %ok141

then136:                                          ; preds = %ok128
  call fastcc void @native_trap()
  unreachable

ok141:                                            ; preds = %ok128
  %v143 = getelementptr i8, ptr %v129, i64 16
  %v144 = load i64, ptr %v143, align 1
  %v145.not = icmp eq i64 %v144, 0
  br i1 %v145.not, label %trap146, label %ok147

trap146:                                          ; preds = %ok141
  call fastcc void @native_trap()
  unreachable

ok147:                                            ; preds = %ok141
  store i64 %v144, ptr %v5, align 8
  %v151 = inttoptr i64 %v144 to ptr
  %v160 = getelementptr i8, ptr %v151, i64 8
  %v161 = load i64, ptr %v160, align 1
  %v162.not = icmp eq i64 %v161, 0
  br i1 %v162.not, label %trap163, label %ok164

trap163:                                          ; preds = %ok147
  call fastcc void @native_trap()
  unreachable

common.ret:                                       ; preds = %else14, %native_roots_leave.exit
  %common.ret.op = phi i32 [ %v168, %native_roots_leave.exit ], [ 0, %else14 ]
  ret i32 %common.ret.op

ok164:                                            ; preds = %ok147
  %v152 = getelementptr i8, ptr %v151, i64 16
  %v153 = load i64, ptr %v152, align 1
  %v165 = inttoptr i64 %v161 to ptr
  %v166 = getelementptr i8, ptr %v165, i64 8
  %v167 = load ptr, ptr %v166, align 1
  %93 = load i64, ptr %0, align 8, !noundef !39
  %94 = icmp eq i64 %93, 0
  br i1 %94, label %native_roots_leave.exit, label %95

95:                                               ; preds = %ok164
  %96 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %96, ptr @native_roots.0, align 8
  %97 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %98 = add i64 %97, -1
  store i64 %98, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit

native_roots_leave.exit:                          ; preds = %95, %ok164
  %v168 = tail call tailcc i32 %v167(i64 %v153, i64 %v28)
  br label %common.ret

else14:                                           ; preds = %entry
  store ptr %2, ptr @native_roots.0, align 8
  store i64 %3, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %common.ret
}

define internal tailcc i32 @f.5(i64 %arg0, i64 %arg1) #102 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [7 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 7, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v4 = getelementptr inbounds nuw i8, ptr %roots, i64 40
  %v1363 = icmp sgt i64 %arg1, -1
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v3, i8 0, i64 24, i1 false)
  br i1 %v1363, label %then17.lr.ph, label %else16

then17.lr.ph:                                     ; preds = %entry
  %v70 = getelementptr inbounds nuw i8, ptr %roots, i64 56
  %v104 = getelementptr inbounds nuw i8, ptr %roots, i64 64
  %v105 = getelementptr inbounds nuw i8, ptr %roots, i64 72
  %v20.first_iter = icmp samesign ugt i64 %arg1, 4294967295
  br label %then17

then17:                                           ; preds = %ok248, %then17.lr.ph
  %arg1.tr65 = phi i64 [ %arg1, %then17.lr.ph ], [ %v253, %ok248 ]
  %arg0.tr64 = phi i64 [ %arg0, %then17.lr.ph ], [ %v251, %ok248 ]
  br i1 %v20.first_iter, label %then24, label %block22

then24:                                           ; preds = %then17
  call fastcc void @native_trap()
  unreachable

block22:                                          ; preds = %then17
  %7 = icmp ne i64 %arg0.tr64, 0
  %8 = and i64 %arg0.tr64, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %trap29

9:                                                ; preds = %block22
  %10 = inttoptr i64 %arg0.tr64 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 22, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit13

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader12 [
    i64 22, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #111
  unreachable

.preheader12:                                     ; preds = %31, %21
  %27 = phi i64 [ %33, %31 ], [ %25, %21 ]
  %28 = lshr i64 %27, 2
  %29 = add nsw i64 %28, -1
  %30 = icmp ult i64 %29, %17
  br i1 %30, label %31, label %.loopexit13

.loopexit13:                                      ; preds = %.preheader12, %15
  call fastcc void @native_trap() #111
  unreachable

31:                                               ; preds = %.preheader12
  %32 = getelementptr inbounds nuw i64, ptr %23, i64 %29
  %33 = load i64, ptr %32, align 8, !noundef !39
  switch i64 %33, label %.preheader12 [
    i64 22, label %native_ref_test.exit
    i64 0, label %native_ref_test.exit
  ]

native_ref_test.exit:                             ; preds = %31, %31, %21, %21, %14, %14
  %.in37 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %33, %31 ], [ %33, %31 ]
  %34 = icmp eq i64 %.in37, 22
  br i1 %34, label %ok30, label %trap29

trap29:                                           ; preds = %native_ref_test.exit, %block22
  call fastcc void @native_trap()
  unreachable

ok30:                                             ; preds = %native_ref_test.exit
  store i64 %arg0.tr64, ptr %v3, align 8
  %v35 = getelementptr i8, ptr %10, i64 8
  %v36 = load i64, ptr %v35, align 1
  %v39.not = icmp eq i64 %v36, 0
  br i1 %v39.not, label %trap40, label %ok41

trap40:                                           ; preds = %ok30
  call fastcc void @native_trap()
  unreachable

ok41:                                             ; preds = %ok30
  %v42 = and i64 %v36, 1
  %v43 = icmp eq i64 %v42, 0
  br i1 %v43, label %ok45, label %trap44

trap44:                                           ; preds = %ok41
  call fastcc void @native_trap()
  unreachable

ok45:                                             ; preds = %ok41
  %v46 = inttoptr i64 %v36 to ptr
  %v47 = getelementptr i8, ptr %v46, i64 8
  %v48 = load i64, ptr %v47, align 1
  %v50 = icmp ult i64 %arg1.tr65, %v48
  br i1 %v50, label %ok52, label %trap51

trap51:                                           ; preds = %ok45
  call fastcc void @native_trap()
  unreachable

ok52:                                             ; preds = %ok45
  %v54 = getelementptr i8, ptr %v46, i64 16
  %v55 = getelementptr i64, ptr %v54, i64 %arg1.tr65
  %v56 = load i64, ptr %v55, align 1
  %v59.b = load i1, ptr @g.4, align 1
  br i1 %v59.b, label %block62, label %then64

then64:                                           ; preds = %ok52
  call fastcc void @native_trap()
  unreachable

block62:                                          ; preds = %ok52
  %v66 = load i64, ptr @g.3, align 8
  %v67.not = icmp eq i64 %v66, 0
  br i1 %v67.not, label %trap68, label %ok69

trap68:                                           ; preds = %block62
  call fastcc void @native_trap()
  unreachable

ok69:                                             ; preds = %block62
  store i64 %v56, ptr %v70, align 8
  store i64 5, ptr %1, align 8
  %35 = getelementptr inbounds nuw i8, ptr %12, i64 376
  %36 = load i64, ptr %35, align 8, !noundef !39
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %38, label %42

38:                                               ; preds = %48, %42, %ok69
  %39 = phi ptr [ %.pre, %48 ], [ %roots, %42 ], [ %roots, %ok69 ]
  %40 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %12, i64 noundef 24, ptr noundef %39) #84
  %41 = icmp eq ptr %40, null
  br i1 %41, label %49, label %ok75

42:                                               ; preds = %ok69
  %43 = getelementptr inbounds nuw i8, ptr %12, i64 368
  %44 = load i64, ptr %43, align 8, !noundef !39
  %45 = add i64 %44, 1
  store i64 %45, ptr %43, align 8
  %46 = urem i64 %45, %36
  %47 = icmp eq i64 %46, 0
  br i1 %47, label %48, label %38

48:                                               ; preds = %42
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %12, ptr noundef nonnull %roots) #84
  %.pre = load ptr, ptr @native_roots.0, align 8
  br label %38

49:                                               ; preds = %38
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok75:                                             ; preds = %38
  %50 = ptrtoint ptr %40 to i64
  store i64 18, ptr %40, align 1
  %v82 = getelementptr i8, ptr %40, i64 8
  store i32 0, ptr %v82, align 1
  %v87 = getelementptr i8, ptr %40, i64 16
  store i64 0, ptr %v87, align 1
  store i64 %50, ptr %v4, align 8
  %v89 = uitofp nneg i64 %arg1.tr65 to double
  %v90 = fmul double %v89, 5.000000e-03
  %v91 = fadd double %v90, -1.000000e+00
  %v92 = load i64, ptr %v3, align 8
  %v93.not = icmp eq i64 %v92, 0
  br i1 %v93.not, label %trap94, label %ok95

trap94:                                           ; preds = %ok75
  call fastcc void @native_trap()
  unreachable

ok95:                                             ; preds = %ok75
  %v96 = inttoptr i64 %v92 to ptr
  %v97 = getelementptr i8, ptr %v96, i64 24
  %v98 = load i64, ptr %v97, align 1
  %v99 = sitofp i64 %v98 to double
  %v100 = fmul double %v99, 5.000000e-03
  %v101 = fadd double %v100, -5.000000e-01
  store i64 %50, ptr %v70, align 8
  store i64 %50, ptr %v104, align 8
  store i64 %v56, ptr %v105, align 8
  store i64 7, ptr %1, align 8
  %51 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %52 = icmp eq ptr %51, null
  br i1 %52, label %53, label %54

53:                                               ; preds = %ok95
  call fastcc void @native_trap() #111
  unreachable

54:                                               ; preds = %ok95
  %55 = getelementptr inbounds nuw i8, ptr %51, i64 376
  %56 = load i64, ptr %55, align 8, !noundef !39
  %57 = icmp eq i64 %56, 0
  br i1 %57, label %58, label %62

58:                                               ; preds = %68, %62, %54
  %59 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %60 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %51, i64 noundef 32, ptr noundef %59) #84
  %61 = icmp eq ptr %60, null
  br i1 %61, label %70, label %ok110

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw i8, ptr %51, i64 368
  %64 = load i64, ptr %63, align 8, !noundef !39
  %65 = add i64 %64, 1
  store i64 %65, ptr %63, align 8
  %66 = urem i64 %65, %56
  %67 = icmp eq i64 %66, 0
  br i1 %67, label %68, label %58

68:                                               ; preds = %62
  %69 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %51, ptr noundef %69) #84
  br label %58

70:                                               ; preds = %58
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok110:                                            ; preds = %58
  %71 = ptrtoint ptr %60 to i64
  store i64 14, ptr %60, align 1
  %v117 = getelementptr i8, ptr %60, i64 8
  store double %v91, ptr %v117, align 1
  %v122 = getelementptr i8, ptr %60, i64 16
  store double %v101, ptr %v122, align 1
  %v127 = getelementptr i8, ptr %60, i64 24
  store i64 %50, ptr %v127, align 1
  store i64 %71, ptr %v70, align 8
  store i64 %50, ptr %v104, align 8
  store i64 %v56, ptr %v105, align 8
  store i64 7, ptr %1, align 8
  %72 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %73 = icmp eq ptr %72, null
  br i1 %73, label %74, label %75

74:                                               ; preds = %ok110
  call fastcc void @native_trap() #111
  unreachable

75:                                               ; preds = %ok110
  %76 = getelementptr inbounds nuw i8, ptr %72, i64 376
  %77 = load i64, ptr %76, align 8, !noundef !39
  %78 = icmp eq i64 %77, 0
  br i1 %78, label %79, label %83

79:                                               ; preds = %89, %83, %75
  %80 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  %81 = call fastcc noundef ptr @_ZN13snail_runtime9native_gc9Collector8allocate17h19e11b15959cdfbaE(ptr noalias noundef align 8 dereferenceable(344) %72, i64 noundef 16, ptr noundef %80) #84
  %82 = icmp eq ptr %81, null
  br i1 %82, label %91, label %ok135

83:                                               ; preds = %75
  %84 = getelementptr inbounds nuw i8, ptr %72, i64 368
  %85 = load i64, ptr %84, align 8, !noundef !39
  %86 = add i64 %85, 1
  store i64 %86, ptr %84, align 8
  %87 = urem i64 %86, %77
  %88 = icmp eq i64 %87, 0
  br i1 %88, label %89, label %79

89:                                               ; preds = %83
  %90 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  call fastcc void @_ZN13snail_runtime9native_gc9Collector7collect17h7d5cb56e75403e6aE(ptr noalias noundef align 8 dereferenceable(344) %72, ptr noundef %90) #84
  br label %79

91:                                               ; preds = %79
  call fastcc void @_ZN13snail_runtime6native10fail_bytes17h05f7ad1c538719baE(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @anon.fd425da7dd6de8cb87f45b8d1d3e5fbe.425, i64 noundef 47) #111
  unreachable

ok135:                                            ; preds = %79
  %92 = ptrtoint ptr %81 to i64
  store i64 10, ptr %81, align 1
  %v142 = getelementptr i8, ptr %81, i64 8
  store i64 %71, ptr %v142, align 1
  store i64 %92, ptr %v87, align 1
  %v148 = load i64, ptr %v4, align 8
  %v149.not = icmp eq i64 %v148, 0
  br i1 %v149.not, label %trap150, label %ok151

trap150:                                          ; preds = %ok135
  call fastcc void @native_trap()
  unreachable

ok151:                                            ; preds = %ok135
  %v152 = inttoptr i64 %v148 to ptr
  %v153 = getelementptr i8, ptr %v152, i64 8
  store i32 1, ptr %v153, align 1
  %v154 = load i64, ptr %v4, align 8
  %v155.not = icmp eq i64 %v154, 0
  br i1 %v155.not, label %trap156, label %ok157

trap156:                                          ; preds = %ok151
  call fastcc void @native_trap()
  unreachable

ok157:                                            ; preds = %ok151
  %v158 = inttoptr i64 %v154 to ptr
  %v159 = getelementptr i8, ptr %v158, i64 8
  %v160 = load i32, ptr %v159, align 1
  %v161 = icmp eq i32 %v160, 0
  br i1 %v161, label %then165, label %ok170

then165:                                          ; preds = %ok157
  call fastcc void @native_trap()
  unreachable

ok170:                                            ; preds = %ok157
  %v172 = getelementptr i8, ptr %v158, i64 16
  %v173 = load i64, ptr %v172, align 1
  %v174.not = icmp eq i64 %v173, 0
  br i1 %v174.not, label %trap175, label %ok176

trap175:                                          ; preds = %ok170
  call fastcc void @native_trap()
  unreachable

ok176:                                            ; preds = %ok170
  %v177 = inttoptr i64 %v173 to ptr
  %v178 = getelementptr i8, ptr %v177, i64 8
  %v179 = load i64, ptr %v178, align 1
  store i64 %v56, ptr %v70, align 8
  store i64 %v179, ptr %v104, align 8
  store i64 6, ptr %1, align 8
  %93 = insertelement <2 x double> poison, double %v91, i64 0
  %94 = insertelement <2 x double> %93, double %v101, i64 1
  br label %else15.i

else15.i:                                         ; preds = %ok84.i, %ok176
  %arg3.tr12.i = phi i64 [ %v90.i, %ok84.i ], [ 0, %ok176 ]
  %arg0.tr9.i = phi i64 [ %v65.i, %ok84.i ], [ %v179, %ok176 ]
  %95 = phi <2 x double> [ %102, %ok84.i ], [ %94, %ok176 ]
  %96 = fmul <2 x double> %95, %95
  %97 = extractelement <2 x double> %96, i64 0
  %98 = extractelement <2 x double> %96, i64 1
  %v25.i = fadd double %98, %97
  %v26.i = fcmp ogt double %v25.i, 1.600000e+01
  br i1 %v26.i, label %native_roots_leave.exit3, label %else30.i

else30.i:                                         ; preds = %else15.i
  %v35.not.i = icmp eq i64 %arg0.tr9.i, 0
  br i1 %v35.not.i, label %trap36.i, label %ok37.i

trap36.i:                                         ; preds = %else30.i
  call fastcc void @native_trap()
  unreachable

ok37.i:                                           ; preds = %else30.i
  %v38.i = inttoptr i64 %arg0.tr9.i to ptr
  %v39.i = getelementptr i8, ptr %v38.i, i64 24
  %v40.i = load i64, ptr %v39.i, align 1
  %v41.not.i = icmp eq i64 %v40.i, 0
  br i1 %v41.not.i, label %trap42.i, label %ok43.i

trap42.i:                                         ; preds = %ok37.i
  call fastcc void @native_trap()
  unreachable

ok43.i:                                           ; preds = %ok37.i
  %v44.i = inttoptr i64 %v40.i to ptr
  %v45.i = getelementptr i8, ptr %v44.i, i64 8
  %v46.i = load i32, ptr %v45.i, align 1
  %v47.i = icmp eq i32 %v46.i, 0
  br i1 %v47.i, label %then51.i, label %ok56.i

then51.i:                                         ; preds = %ok43.i
  call fastcc void @native_trap()
  unreachable

ok56.i:                                           ; preds = %ok43.i
  %v58.i = getelementptr i8, ptr %v44.i, i64 16
  %v59.i = load i64, ptr %v58.i, align 1
  %v60.not.i = icmp eq i64 %v59.i, 0
  br i1 %v60.not.i, label %trap61.i, label %ok84.i

trap61.i:                                         ; preds = %ok56.i
  call fastcc void @native_trap()
  unreachable

ok84.i:                                           ; preds = %ok56.i
  %v63.i = inttoptr i64 %v59.i to ptr
  %v64.i = getelementptr i8, ptr %v63.i, i64 8
  %v65.i = load i64, ptr %v64.i, align 1
  %shift = shufflevector <2 x double> %95, <2 x double> poison, <2 x i32> <i32 1, i32 poison>
  %foldExtExtBinop = fmul <2 x double> %shift, %95
  %v79.i = extractelement <2 x double> %foldExtExtBinop, i64 0
  %v80.i = fmul double %v79.i, 2.000000e+00
  %v68.i = fsub double %97, %98
  %v74.i = getelementptr i8, ptr %v38.i, i64 8
  %99 = load <2 x double>, ptr %v74.i, align 1
  %100 = insertelement <2 x double> poison, double %v68.i, i64 0
  %101 = insertelement <2 x double> %100, double %v80.i, i64 1
  %102 = fadd <2 x double> %101, %99
  %v90.i = add nuw nsw i64 %arg3.tr12.i, 1
  %v11.i = icmp eq i64 %v90.i, 64
  br i1 %v11.i, label %native_roots_leave.exit3, label %else15.i

native_roots_leave.exit3:                         ; preds = %ok84.i, %else15.i
  %arg3.tr.lcssa.i = phi i64 [ 64, %ok84.i ], [ %arg3.tr12.i, %else15.i ]
  %v187 = icmp ugt i64 %v98, 4294967295
  br i1 %v187, label %then191, label %block189

then191:                                          ; preds = %native_roots_leave.exit3
  call fastcc void @native_trap()
  unreachable

block189:                                         ; preds = %native_roots_leave.exit3
  %v197.not = icmp eq i64 %v56, 0
  br i1 %v197.not, label %trap198, label %ok199

trap198:                                          ; preds = %block189
  call fastcc void @native_trap()
  unreachable

ok199:                                            ; preds = %block189
  %v200 = and i64 %v56, 1
  %v201 = icmp eq i64 %v200, 0
  br i1 %v201, label %ok203, label %trap202

trap202:                                          ; preds = %ok199
  call fastcc void @native_trap()
  unreachable

ok203:                                            ; preds = %ok199
  %v204 = inttoptr i64 %v56 to ptr
  %v205 = getelementptr i8, ptr %v204, i64 8
  %v206 = load i64, ptr %v205, align 1
  %v208 = icmp ult i64 %v98, %v206
  br i1 %v208, label %ok210, label %trap209

trap209:                                          ; preds = %ok203
  call fastcc void @native_trap()
  unreachable

ok210:                                            ; preds = %ok203
  %v212 = getelementptr i8, ptr %v204, i64 16
  %v213 = getelementptr i64, ptr %v212, i64 %v98
  store i64 %arg3.tr.lcssa.i, ptr %v213, align 1
  %v214 = load i64, ptr %v3, align 8
  %v215.not = icmp eq i64 %v214, 0
  br i1 %v215.not, label %trap216, label %ok217

trap216:                                          ; preds = %ok210
  call fastcc void @native_trap()
  unreachable

ok217:                                            ; preds = %ok210
  %v218 = inttoptr i64 %v214 to ptr
  %v219 = getelementptr i8, ptr %v218, i64 32
  %v220 = load i64, ptr %v219, align 1
  %v221.not = icmp eq i64 %v220, 0
  br i1 %v221.not, label %trap222, label %ok223

trap222:                                          ; preds = %ok217
  call fastcc void @native_trap()
  unreachable

ok223:                                            ; preds = %ok217
  %v224 = inttoptr i64 %v220 to ptr
  %v225 = getelementptr i8, ptr %v224, i64 8
  %v226 = load i32, ptr %v225, align 1
  %v227 = icmp eq i32 %v226, 0
  br i1 %v227, label %then231, label %ok242

then231:                                          ; preds = %ok223
  call fastcc void @native_trap()
  unreachable

ok242:                                            ; preds = %ok223
  %v244 = getelementptr i8, ptr %v224, i64 16
  %v245 = load i64, ptr %v244, align 1
  %v246.not = icmp eq i64 %v245, 0
  br i1 %v246.not, label %trap247, label %ok248

trap247:                                          ; preds = %ok242
  call fastcc void @native_trap()
  unreachable

ok248:                                            ; preds = %ok242
  %v249 = inttoptr i64 %v245 to ptr
  %v250 = getelementptr i8, ptr %v249, i64 16
  %v251 = load i64, ptr %v250, align 1
  %v253 = add nsw i64 %arg1.tr65, -1
  %103 = load i64, ptr %0, align 8, !noundef !39
  %104 = icmp eq i64 %103, 0
  %.pre17 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %105 = zext i1 %104 to i64
  %106 = add i64 %.pre17, %105
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %107 = select i1 %104, ptr %native_roots.0.val, ptr %roots.val
  store i64 7, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %107, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %106, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %108 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %109 = call noundef i64 @llvm.umax.i64(i64 %106, i64 %108)
  store i64 %109, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v251, ptr %v1, align 8
  %v13.not = icmp eq i64 %arg1.tr65, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v3, i8 0, i64 24, i1 false)
  br i1 %v13.not, label %else16.loopexit, label %then17

else16.loopexit:                                  ; preds = %ok248
  %v251.lcssa = phi i64 [ %v251, %ok248 ]
  %.lcssa41 = phi i64 [ %106, %ok248 ]
  %.lcssa40 = phi ptr [ %107, %ok248 ]
  %110 = add i64 %.lcssa41, -1
  br label %else16

else16:                                           ; preds = %else16.loopexit, %entry
  %111 = phi i64 [ %3, %entry ], [ %110, %else16.loopexit ]
  %112 = phi ptr [ %2, %entry ], [ %.lcssa40, %else16.loopexit ]
  %arg0.tr.lcssa = phi i64 [ %arg0, %entry ], [ %v251.lcssa, %else16.loopexit ]
  %113 = icmp ne i64 %arg0.tr.lcssa, 0
  %114 = and i64 %arg0.tr.lcssa, 1
  %.not.i5 = icmp eq i64 %114, 0
  %or.cond21 = and i1 %113, %.not.i5
  br i1 %or.cond21, label %115, label %trap258

115:                                              ; preds = %else16
  %116 = inttoptr i64 %arg0.tr.lcssa to ptr
  %117 = load i64, ptr %116, align 8, !noundef !39
  %118 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %119 = icmp eq ptr %118, null
  br i1 %119, label %132, label %120

120:                                              ; preds = %115
  switch i64 %117, label %121 [
    i64 22, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

121:                                              ; preds = %120
  %122 = getelementptr inbounds nuw i8, ptr %118, i64 360
  %123 = load i64, ptr %122, align 8, !noundef !39
  %124 = lshr i64 %117, 2
  %125 = add nsw i64 %124, -1
  %126 = icmp ult i64 %125, %123
  br i1 %126, label %127, label %.loopexit

127:                                              ; preds = %121
  %128 = getelementptr inbounds nuw i8, ptr %118, i64 352
  %129 = load ptr, ptr %128, align 8, !nonnull !39, !noundef !39
  %130 = getelementptr inbounds nuw i64, ptr %129, i64 %125
  %131 = load i64, ptr %130, align 8, !noundef !39
  switch i64 %131, label %.preheader [
    i64 22, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

132:                                              ; preds = %115
  call fastcc void @native_trap() #111
  unreachable

.preheader:                                       ; preds = %137, %127
  %133 = phi i64 [ %139, %137 ], [ %131, %127 ]
  %134 = lshr i64 %133, 2
  %135 = add nsw i64 %134, -1
  %136 = icmp ult i64 %135, %123
  br i1 %136, label %137, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %121
  call fastcc void @native_trap() #111
  unreachable

137:                                              ; preds = %.preheader
  %138 = getelementptr inbounds nuw i64, ptr %129, i64 %135
  %139 = load i64, ptr %138, align 8, !noundef !39
  switch i64 %139, label %.preheader [
    i64 22, label %native_ref_test.exit6
    i64 0, label %native_ref_test.exit6
  ]

native_ref_test.exit6:                            ; preds = %137, %137, %127, %127, %120, %120
  %.in = phi i64 [ %117, %120 ], [ %131, %127 ], [ %131, %127 ], [ %117, %120 ], [ %139, %137 ], [ %139, %137 ]
  %140 = icmp eq i64 %.in, 22
  br i1 %140, label %ok259, label %trap258

trap258:                                          ; preds = %native_ref_test.exit6, %else16
  call fastcc void @native_trap()
  unreachable

ok259:                                            ; preds = %native_ref_test.exit6
  store i64 %arg0.tr.lcssa, ptr %v3, align 8
  %v264 = getelementptr i8, ptr %116, i64 24
  %v265 = load i64, ptr %v264, align 1
  %v271 = getelementptr i8, ptr %116, i64 16
  %v272 = load i64, ptr %v271, align 1
  %v273.not = icmp eq i64 %v272, 0
  br i1 %v273.not, label %trap274, label %ok275

trap274:                                          ; preds = %ok259
  call fastcc void @native_trap()
  unreachable

ok275:                                            ; preds = %ok259
  %v276 = inttoptr i64 %v272 to ptr
  %v277 = getelementptr i8, ptr %v276, i64 8
  %v278 = load i32, ptr %v277, align 1
  %v279 = icmp eq i32 %v278, 0
  br i1 %v279, label %then283, label %ok294

then283:                                          ; preds = %ok275
  call fastcc void @native_trap()
  unreachable

ok294:                                            ; preds = %ok275
  %v296 = getelementptr i8, ptr %v276, i64 16
  %v297 = load i64, ptr %v296, align 1
  %v298.not = icmp eq i64 %v297, 0
  br i1 %v298.not, label %trap299, label %ok300

trap299:                                          ; preds = %ok294
  call fastcc void @native_trap()
  unreachable

ok300:                                            ; preds = %ok294
  %v301 = inttoptr i64 %v297 to ptr
  %v302 = getelementptr i8, ptr %v301, i64 16
  %v303 = load i64, ptr %v302, align 1
  store ptr %112, ptr @native_roots.0, align 8
  store i64 %111, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %v305 = add i64 %v265, -1
  %v306 = tail call tailcc i32 @f.4(i64 %v303, i64 %v305)
  ret i32 %v306
}

define internal tailcc noundef i32 @f.7(i64 %arg0, i64 %arg1) #103 personality ptr @rust_eh_personality {
entry:
  %roots = alloca { ptr, i64, i64, [4 x i64] }, align 8
  %0 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 4, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  store i64 0, ptr %1, align 8
  %2 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %2, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %3 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %4 = add i64 %3, 1
  store i64 %4, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %5 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %6 = call noundef i64 @llvm.umax.i64(i64 %4, i64 %5)
  store i64 %6, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  %v3 = getelementptr inbounds nuw i8, ptr %roots, i64 32
  %v927 = icmp sgt i64 %arg1, -1
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  br i1 %v927, label %then14.lr.ph.split, label %else13

then14.lr.ph.split:                               ; preds = %entry
  %v54 = getelementptr inbounds nuw i8, ptr %roots, i64 48
  %v43.first_iter = icmp samesign ugt i64 %arg1, 4294967295
  %7 = icmp ne i64 %arg0, 0
  %8 = and i64 %arg0, 1
  %.not.i = icmp eq i64 %8, 0
  %or.cond = and i1 %7, %.not.i
  br i1 %or.cond, label %9, label %then14.preheader

9:                                                ; preds = %then14.lr.ph.split
  %10 = inttoptr i64 %arg0 to ptr
  %11 = load i64, ptr %10, align 8, !noundef !39
  %12 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %13 = icmp eq ptr %12, null
  br i1 %13, label %26, label %14

14:                                               ; preds = %9
  switch i64 %11, label %15 [
    i64 38, label %.loopexit10
    i64 0, label %.loopexit10
  ]

15:                                               ; preds = %14
  %16 = getelementptr inbounds nuw i8, ptr %12, i64 360
  %17 = load i64, ptr %16, align 8, !noundef !39
  %18 = lshr i64 %11, 2
  %19 = add nsw i64 %18, -1
  %20 = icmp ult i64 %19, %17
  br i1 %20, label %21, label %.loopexit9

21:                                               ; preds = %15
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 352
  %23 = load ptr, ptr %22, align 8, !nonnull !39, !noundef !39
  %24 = getelementptr inbounds nuw i64, ptr %23, i64 %19
  %25 = load i64, ptr %24, align 8, !noundef !39
  switch i64 %25, label %.preheader8 [
    i64 38, label %.loopexit10
    i64 0, label %.loopexit10
  ]

26:                                               ; preds = %9
  call fastcc void @native_trap() #111
  unreachable

.loopexit10:                                      ; preds = %32, %32, %21, %21, %14, %14
  %.in30 = phi i64 [ %11, %14 ], [ %25, %21 ], [ %25, %21 ], [ %11, %14 ], [ %34, %32 ], [ %34, %32 ]
  %27 = icmp eq i64 %.in30, 38
  br label %then14.preheader

then14.preheader:                                 ; preds = %.loopexit10, %then14.lr.ph.split
  %phi.call.shrunk.ph = phi i1 [ false, %then14.lr.ph.split ], [ %27, %.loopexit10 ]
  br label %then14

.preheader8:                                      ; preds = %32, %21
  %28 = phi i64 [ %34, %32 ], [ %25, %21 ]
  %29 = lshr i64 %28, 2
  %30 = add nsw i64 %29, -1
  %31 = icmp ult i64 %30, %17
  br i1 %31, label %32, label %.loopexit9

.loopexit9:                                       ; preds = %.preheader8, %15
  call fastcc void @native_trap() #111
  unreachable

32:                                               ; preds = %.preheader8
  %33 = getelementptr inbounds nuw i64, ptr %23, i64 %30
  %34 = load i64, ptr %33, align 8, !noundef !39
  switch i64 %34, label %.preheader8 [
    i64 38, label %.loopexit10
    i64 0, label %.loopexit10
  ]

then14:                                           ; preds = %then14.backedge, %then14.preheader
  %phi.call.shrunk = phi i1 [ %phi.call.shrunk.ph, %then14.preheader ], [ %phi.call.shrunk.be, %then14.backedge ]
  %arg1.tr29 = phi i64 [ %arg1, %then14.preheader ], [ %v113, %then14.backedge ]
  %arg0.tr28 = phi i64 [ %arg0, %then14.preheader ], [ %v111, %then14.backedge ]
  br i1 %phi.call.shrunk, label %ok20, label %trap19

trap19:                                           ; preds = %then14
  call fastcc void @native_trap()
  unreachable

ok20:                                             ; preds = %then14
  store i64 %arg0.tr28, ptr %v3, align 8
  %v21.not = icmp eq i64 %arg0.tr28, 0
  br i1 %v21.not, label %trap22, label %ok23

trap22:                                           ; preds = %ok20
  call fastcc void @native_trap()
  unreachable

ok23:                                             ; preds = %ok20
  %v24 = inttoptr i64 %arg0.tr28 to ptr
  %v25 = getelementptr i8, ptr %v24, i64 16
  %v26 = load i64, ptr %v25, align 1
  %v34 = getelementptr i8, ptr %v24, i64 8
  %v35 = load i64, ptr %v34, align 1
  %v36 = icmp ugt i64 %v35, 4294967295
  br i1 %v36, label %then40, label %block38

then40:                                           ; preds = %ok23
  call fastcc void @native_trap()
  unreachable

block38:                                          ; preds = %ok23
  br i1 %v43.first_iter, label %then47, label %block45

then47:                                           ; preds = %block38
  call fastcc void @native_trap()
  unreachable

block45:                                          ; preds = %block38
  %v53 = trunc nuw i64 %v35 to i32
  store i64 %v26, ptr %v54, align 8
  store i64 4, ptr %1, align 8
  %v56 = call fastcc i64 @native_array_new(i64 43, i32 %v53, i64 0)
  %v57.not = icmp eq i64 %v26, 0
  br i1 %v57.not, label %trap58, label %ok59

trap58:                                           ; preds = %block45
  call fastcc void @native_trap()
  unreachable

ok59:                                             ; preds = %block45
  %v60 = and i64 %v26, 1
  %v61 = icmp eq i64 %v60, 0
  br i1 %v61, label %ok63, label %trap62

trap62:                                           ; preds = %ok59
  call fastcc void @native_trap()
  unreachable

ok63:                                             ; preds = %ok59
  %v64 = inttoptr i64 %v26 to ptr
  %v65 = getelementptr i8, ptr %v64, i64 8
  %v66 = load i64, ptr %v65, align 1
  %v68 = icmp ult i64 %arg1.tr29, %v66
  br i1 %v68, label %ok70, label %trap69

trap69:                                           ; preds = %ok63
  call fastcc void @native_trap()
  unreachable

ok70:                                             ; preds = %ok63
  %v72 = getelementptr i8, ptr %v64, i64 16
  %v73 = getelementptr i64, ptr %v72, i64 %arg1.tr29
  store i64 %v56, ptr %v73, align 1
  %v74 = load i64, ptr %v3, align 8
  %v75.not = icmp eq i64 %v74, 0
  br i1 %v75.not, label %trap76, label %ok77

trap76:                                           ; preds = %ok70
  call fastcc void @native_trap()
  unreachable

ok77:                                             ; preds = %ok70
  %v78 = inttoptr i64 %v74 to ptr
  %v79 = getelementptr i8, ptr %v78, i64 24
  %v80 = load i64, ptr %v79, align 1
  %v81.not = icmp eq i64 %v80, 0
  br i1 %v81.not, label %trap82, label %ok83

trap82:                                           ; preds = %ok77
  call fastcc void @native_trap()
  unreachable

ok83:                                             ; preds = %ok77
  %v84 = inttoptr i64 %v80 to ptr
  %v85 = getelementptr i8, ptr %v84, i64 8
  %v86 = load i32, ptr %v85, align 1
  %v87 = icmp eq i32 %v86, 0
  br i1 %v87, label %then91, label %ok102

then91:                                           ; preds = %ok83
  call fastcc void @native_trap()
  unreachable

ok102:                                            ; preds = %ok83
  %v104 = getelementptr i8, ptr %v84, i64 16
  %v105 = load i64, ptr %v104, align 1
  %v106.not = icmp eq i64 %v105, 0
  br i1 %v106.not, label %trap107, label %ok108

trap107:                                          ; preds = %ok102
  call fastcc void @native_trap()
  unreachable

ok108:                                            ; preds = %ok102
  %v109 = inttoptr i64 %v105 to ptr
  %v110 = getelementptr i8, ptr %v109, i64 16
  %v111 = load i64, ptr %v110, align 1
  %35 = load i64, ptr %0, align 8, !noundef !39
  %36 = icmp eq i64 %35, 0
  %.pre12 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %37 = zext i1 %36 to i64
  %38 = add i64 %.pre12, %37
  %native_roots.0.val = load ptr, ptr @native_roots.0, align 8
  %roots.val = load ptr, ptr %roots, align 8
  %39 = select i1 %36, ptr %native_roots.0.val, ptr %roots.val
  store i64 4, ptr %0, align 8
  store i64 0, ptr %1, align 8
  store ptr %39, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  store i64 %38, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %40 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %41 = call noundef i64 @llvm.umax.i64(i64 %38, i64 %40)
  store i64 %41, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  store i64 %v111, ptr %v1, align 8
  %v9.not = icmp eq i64 %arg1.tr29, 0
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %v3, i8 0, i64 16, i1 false)
  br i1 %v9.not, label %else13.loopexit, label %ok108.split

ok108.split:                                      ; preds = %ok108
  %v113 = add nsw i64 %arg1.tr29, -1
  %42 = icmp ne i64 %v111, 0
  %43 = and i64 %v111, 1
  %.not.i3 = icmp eq i64 %43, 0
  %or.cond22 = and i1 %42, %.not.i3
  br i1 %or.cond22, label %44, label %then14.backedge

then14.backedge:                                  ; preds = %.loopexit6, %ok108.split
  %phi.call.shrunk.be = phi i1 [ false, %ok108.split ], [ %62, %.loopexit6 ]
  br label %then14

44:                                               ; preds = %ok108.split
  %45 = inttoptr i64 %v111 to ptr
  %46 = load i64, ptr %45, align 8, !noundef !39
  %47 = load ptr, ptr @_ZN13snail_runtime6native7RUNTIME17hbd54e637c3aa8a5bE.0, align 8, !noundef !39
  %48 = icmp eq ptr %47, null
  br i1 %48, label %61, label %49

49:                                               ; preds = %44
  switch i64 %46, label %50 [
    i64 38, label %.loopexit6
    i64 0, label %.loopexit6
  ]

50:                                               ; preds = %49
  %51 = getelementptr inbounds nuw i8, ptr %47, i64 360
  %52 = load i64, ptr %51, align 8, !noundef !39
  %53 = lshr i64 %46, 2
  %54 = add nsw i64 %53, -1
  %55 = icmp ult i64 %54, %52
  br i1 %55, label %56, label %.loopexit

56:                                               ; preds = %50
  %57 = getelementptr inbounds nuw i8, ptr %47, i64 352
  %58 = load ptr, ptr %57, align 8, !nonnull !39, !noundef !39
  %59 = getelementptr inbounds nuw i64, ptr %58, i64 %54
  %60 = load i64, ptr %59, align 8, !noundef !39
  switch i64 %60, label %.preheader [
    i64 38, label %.loopexit6
    i64 0, label %.loopexit6
  ]

61:                                               ; preds = %44
  call fastcc void @native_trap() #111
  unreachable

.loopexit6:                                       ; preds = %67, %67, %56, %56, %49, %49
  %.in = phi i64 [ %46, %49 ], [ %60, %56 ], [ %60, %56 ], [ %46, %49 ], [ %69, %67 ], [ %69, %67 ]
  %62 = icmp eq i64 %.in, 38
  br label %then14.backedge

.preheader:                                       ; preds = %67, %56
  %63 = phi i64 [ %69, %67 ], [ %60, %56 ]
  %64 = lshr i64 %63, 2
  %65 = add nsw i64 %64, -1
  %66 = icmp ult i64 %65, %52
  br i1 %66, label %67, label %.loopexit

.loopexit:                                        ; preds = %.preheader, %50
  call fastcc void @native_trap() #111
  unreachable

67:                                               ; preds = %.preheader
  %68 = getelementptr inbounds nuw i64, ptr %58, i64 %65
  %69 = load i64, ptr %68, align 8, !noundef !39
  switch i64 %69, label %.preheader [
    i64 38, label %.loopexit6
    i64 0, label %.loopexit6
  ]

else13.loopexit:                                  ; preds = %ok108
  %.lcssa36 = phi i64 [ %38, %ok108 ]
  %.lcssa32 = phi ptr [ %39, %ok108 ]
  %70 = add i64 %.lcssa36, -1
  br label %else13

else13:                                           ; preds = %else13.loopexit, %entry
  %71 = phi i64 [ %70, %else13.loopexit ], [ %3, %entry ]
  %72 = phi ptr [ %.lcssa32, %else13.loopexit ], [ %2, %entry ]
  store ptr %72, ptr @native_roots.0, align 8
  store i64 %71, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  ret i32 0
}

define internal tailcc noundef i64 @f.3(i64 %arg0, i64 %arg1, i64 %arg2) #103 personality ptr @rust_eh_personality {
entry:
  %0 = alloca [8 x i8], align 8
  %roots = alloca { ptr, i64, i64, [1 x i64] }, align 8
  %1 = getelementptr inbounds nuw i8, ptr %roots, i64 8
  store i64 1, ptr %1, align 8
  %2 = getelementptr inbounds nuw i8, ptr %roots, i64 16
  %3 = load ptr, ptr @native_roots.0, align 8, !noundef !39
  store ptr %3, ptr %roots, align 8
  store ptr %roots, ptr @native_roots.0, align 8
  %4 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %5 = add i64 %4, 1
  store i64 %5, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  %6 = load i64, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8, !noundef !39
  %7 = call noundef i64 @llvm.umax.i64(i64 %5, i64 %6)
  store i64 %7, ptr @_ZN13snail_runtime6native15PEAK_ROOT_DEPTH17h3816cd4d0a5f276dE.0, align 8
  %v1 = getelementptr inbounds nuw i8, ptr %roots, i64 24
  store i64 %arg0, ptr %v1, align 8
  store i64 1, ptr %2, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %0)
  store i64 %arg2, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %0) #84, !srcloc !75600
  %8 = load i64, ptr %0, align 8, !noundef !39
  call void @llvm.lifetime.end.p0(ptr nonnull %0)
  %9 = load i64, ptr %1, align 8, !noundef !39
  %10 = icmp eq i64 %9, 0
  br i1 %10, label %native_roots_leave.exit1, label %11

11:                                               ; preds = %entry
  %12 = load ptr, ptr %roots, align 8, !noundef !39
  store ptr %12, ptr @native_roots.0, align 8
  %13 = load i64, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8, !noundef !39
  %14 = add i64 %13, -1
  store i64 %14, ptr @_ZN13snail_runtime6native10ROOT_DEPTH17h0f7e07766b9d6108E.0, align 8
  br label %native_roots_leave.exit1

native_roots_leave.exit1:                         ; preds = %11, %entry
  ret i64 %8
}
