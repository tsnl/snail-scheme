(func $function118 (type $call98) (param $0 (ref $type13)) (param $1 (ref $type13)) (result (ref $type13))
  (local $2 (ref $type13))
  (local $3 (ref $type31))
  (drop
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global353)
   )
  )
  (if (result (ref $type13))
   (i64.eqz
    (call $function107
     (local.get $1)
    )
   )
   (then
    (struct.new $type15
     (i32.const 1)
     (i32.const 0)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global373)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $1)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.tee $2
        (struct.get $type32 0
         (struct.get $type31 1
          (ref.cast (ref $type31)
           (local.get $1)
          )
         )
        )
       )
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type31))
     (call $function112
      (local.get $0)
      (struct.get $type32 0
       (struct.get $type31 1
        (local.tee $3
         (ref.cast (ref $type31)
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global345)
       )
      )
      (if
       (i32.ne
        (struct.get $type13 0
         (local.get $1)
        )
        (i32.const 6)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type32 0
        (struct.get $type31 2
         (ref.cast (ref $type31)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready398)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global398)
       )
      )
      (return_call $function118
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
