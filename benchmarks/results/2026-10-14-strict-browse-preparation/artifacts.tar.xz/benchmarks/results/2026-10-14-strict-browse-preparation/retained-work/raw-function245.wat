(func $function245 (param $capture881 (ref $type13)) (param $capture882 i32) (param $initialized882 i32) (param $argument883 (ref $type13)) (result i32)
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local3 (ref null $type13))
  (local $local4 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local7 (ref null $type13))
  (local $local9 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local2 (ref null $type99))
  (local $local5 (ref null $type99))
  (local $local8 (ref null $type99))
  (local $local10 (ref null $type207))
  (local $local12 (ref null $type102))
  (local.set $local11
   (ref.as_non_null
    (local.get $argument883)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (if (result i32)
   (call $function109
    (struct.get $type102 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (ref.as_non_null
     (local.get $local11)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local4
     (ref.as_non_null
      (local.get $capture881)
     )
    )
    (local.set $local5
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (local.set $local3
     (call $function103
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local5)
       )
      )
      (ref.as_non_null
       (local.get $local4)
      )
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $argument883)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (local.set $local6
     (call $function103
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local9
     (global.get $empty14)
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global858)
     )
    )
    (drop
     (call $function239
      (struct.get $type207 1
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
      (ref.as_non_null
       (local.get $local6)
      )
      (ref.as_non_null
       (local.get $local9)
      )
     )
    )
    (local.set $local1
     (ref.as_non_null
      (local.get $argument883)
     )
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (local.set $local0
     (call $function104
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $initialized882)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture882)
    )
    (return_call $function245
     (ref.as_non_null
      (local.get $capture881)
     )
     (local.get $capture882)
     (local.get $initialized882)
     (ref.as_non_null
      (local.get $local0)
     )
    )
   )
  )
 )
