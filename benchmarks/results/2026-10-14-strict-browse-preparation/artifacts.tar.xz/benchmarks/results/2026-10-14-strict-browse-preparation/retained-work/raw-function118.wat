(func $function118 (type $call98) (param $environment eqref) (param $argument399 (ref $type13)) (param $argument400 (ref $type13)) (result (ref $type13))
  (local $local0 i32)
  (local $local14 i32)
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type13))
  (local $local4 (ref null $type13))
  (local $local5 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local9 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local15 (ref null $type13))
  (local $local3 (ref null $type99))
  (local $local7 (ref null $type99))
  (local $local12 (ref null $type99))
  (local $local8 (ref null $type98))
  (local $local13 (ref null $type103))
  (local $local16 (ref null $type102))
  (local.set $local15
   (ref.as_non_null
    (local.get $argument400)
   )
  )
  (local.set $local16
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (if (result (ref $type13))
   (call $function109
    (struct.get $type102 1
     (ref.as_non_null
      (local.get $local16)
     )
    )
    (ref.as_non_null
     (local.get $local15)
    )
   )
   (then
    (local.set $local14
     (i32.const 0)
    )
    (struct.new $type15
     (i32.const 1)
     (local.get $local14)
    )
   )
   (else
    (local.set $local2
     (ref.as_non_null
      (local.get $argument400)
     )
    )
    (local.set $local3
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (local.set $local1
     (call $function103
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local0
     (i32.const 1)
    )
    (local.set $local9
     (ref.as_non_null
      (local.get $argument399)
     )
    )
    (if
     (i32.eqz
      (local.get $local0)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local11
     (ref.as_non_null
      (local.get $local1)
     )
    )
    (local.set $local12
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (local.set $local10
     (call $function103
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local12)
       )
      )
      (ref.as_non_null
       (local.get $local11)
      )
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global373)
     )
    )
    (if (result (ref $type13))
     (call $function112
      (struct.get $type103 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (ref.as_non_null
       (local.get $local9)
      )
      (ref.as_non_null
       (local.get $local10)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $local0)
       )
       (then
        (unreachable)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
     (else
      (local.set $local4
       (ref.as_non_null
        (local.get $argument399)
       )
      )
      (local.set $local6
       (ref.as_non_null
        (local.get $argument400)
       )
      )
      (local.set $local7
       (ref.as_non_null
        (global.get $global345)
       )
      )
      (local.set $local5
       (call $function104
        (struct.get $type99 1
         (ref.as_non_null
          (local.get $local7)
         )
        )
        (ref.as_non_null
         (local.get $local6)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready398)
       )
       (then
        (unreachable)
       )
      )
      (local.set $local8
       (ref.as_non_null
        (global.get $global398)
       )
      )
      (return_call $function118
       (struct.get $type98 1
        (ref.as_non_null
         (local.get $local8)
        )
       )
       (ref.as_non_null
        (local.get $local4)
       )
       (ref.as_non_null
        (local.get $local5)
       )
      )
     )
    )
   )
  )
 )
