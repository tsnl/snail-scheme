(func $function225 (type $call98) (param $environment eqref) (param $argument817 (ref $type13)) (param $argument818 (ref $type13)) (result (ref $type13))
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local3 (ref null $type99))
  (local $local7 (ref null $type102))
  (local $local4 i32)
  (local $local5 i32)
  (local.set $local6
   (ref.as_non_null
    (local.get $argument817)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (if (result (ref $type13))
   (call $function109
    (struct.get $type102 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
   )
   (then
    (ref.as_non_null
     (local.get $argument818)
    )
   )
   (else
    (local.set $local0
     (ref.as_non_null
      (local.get $argument817)
     )
    )
    (local.set $local2
     (ref.as_non_null
      (local.get $argument817)
     )
    )
    (local.set $local3
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (local.set $local1
     (call $function104
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local3)
       )
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local5
     (i32.const 0)
    )
    (local.set $local4
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local5)
    )
    (return_call $function226
     (ref.as_non_null
      (local.get $argument817)
     )
     (ref.as_non_null
      (local.get $argument818)
     )
     (local.get $local5)
     (local.get $local4)
     (ref.as_non_null
      (local.get $local0)
     )
     (ref.as_non_null
      (local.get $local1)
     )
    )
   )
  )
 )
