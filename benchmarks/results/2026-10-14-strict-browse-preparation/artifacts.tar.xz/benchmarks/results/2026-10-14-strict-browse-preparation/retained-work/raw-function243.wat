(func $function243 (param $capture877 (ref $type13)) (param $capture878 i32) (param $initialized878 i32) (param $argument879 (ref $type13)) (result i32)
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local3 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local2 (ref null $type99))
  (local $local7 (ref null $type102))
  (local $local4 i32)
  (local $local5 i32)
  (local.set $local6
   (ref.as_non_null
    (local.get $argument879)
   )
  )
  (local.set $local7
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (if (result i32)
   (call $function109
    (struct.get $type102 1
     (ref.as_non_null
      (local.get $local7)
     )
    )
    (ref.as_non_null
     (local.get $local6)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local3
     (ref.as_non_null
      (local.get $capture877)
     )
    )
    (local.set $local5
     (i32.const 0)
    )
    (local.set $local4
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local4)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local5)
    )
    (drop
     (call $function244
      (ref.as_non_null
       (local.get $argument879)
      )
      (local.get $local5)
      (local.get $local4)
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (local.set $local1
     (ref.as_non_null
      (local.get $argument879)
     )
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (local.set $local0
     (call $function104
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $initialized878)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture878)
    )
    (return_call $function243
     (ref.as_non_null
      (local.get $capture877)
     )
     (local.get $capture878)
     (local.get $initialized878)
     (ref.as_non_null
      (local.get $local0)
     )
    )
   )
  )
 )
