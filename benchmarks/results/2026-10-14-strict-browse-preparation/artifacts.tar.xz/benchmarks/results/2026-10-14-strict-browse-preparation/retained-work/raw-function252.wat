(func $function252 (param $capture909 i64) (param $capture910 i32) (param $initialized910 i32) (param $argument911 i64) (param $argument912 (ref $type13)) (result i64)
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local7 (ref null $type13))
  (local $local9 (ref null $type13))
  (local $local2 (ref null $type103))
  (local $local10 (ref null $type208))
  (local $local11 (ref null $type99))
  (local $local3 i64)
  (local $local4 i64)
  (local $local5 i64)
  (local $local8 i64)
  (local $local12 i64)
  (local $local13 i64)
  (local.set $local12
   (local.get $argument911)
  )
  (local.set $local13
   (local.get $capture909)
  )
  (if (result i64)
   (i64.lt_s
    (local.get $local12)
    (local.get $local13)
   )
   (then
    (local.set $local4
     (local.get $argument911)
    )
    (local.set $local5
     (i64.const 1)
    )
    (local.set $local3
     (i64.add
      (local.get $local4)
      (local.get $local5)
     )
    )
    (local.set $local8
     (local.get $capture909)
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global902)
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global905)
     )
    )
    (local.set $local7
     (call $function250
      (struct.get $type208 1
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (local.get $local8)
      (ref.as_non_null
       (local.get $local9)
      )
     )
    )
    (local.set $local11
     (ref.as_non_null
      (global.get $global873)
     )
    )
    (local.set $local6
     (call $function241
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local11)
       )
      )
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $initialized910)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture910)
    )
    (return_call $function252
     (local.get $capture909)
     (local.get $capture910)
     (local.get $initialized910)
     (local.get $local3)
     (ref.as_non_null
      (local.get $local6)
     )
    )
   )
   (else
    (local.set $local0
     (ref.as_non_null
      (local.get $argument912)
     )
    )
    (local.set $local1
     (ref.as_non_null
      (global.get $global903)
     )
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global406)
     )
    )
    (if (result i64)
     (call $function120
      (struct.get $type103 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (ref.as_non_null
       (local.get $local0)
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (i64.const 0)
     )
    )
   )
  )
 )
