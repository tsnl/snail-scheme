   65fd0: 55                           	pushq	%rbp
   65fd1: 41 57                        	pushq	%r15
   65fd3: 41 56                        	pushq	%r14
   65fd5: 41 55                        	pushq	%r13
   65fd7: 41 54                        	pushq	%r12
   65fd9: 53                           	pushq	%rbx
   65fda: 48 81 ec a8 00 00 00         	subq	$0xa8, %rsp
   65fe1: 4c 8d 7c 24 48               	leaq	0x48(%rsp), %r15
   65fe6: 4c 8d 64 24 18               	leaq	0x18(%rsp), %r12
   65feb: bd fe ff ff ff               	movl	$0xfffffffe, %ebp       # imm = 0xFFFFFFFE
   65ff0: eb 21                        	jmp	0x66013 <f.102+0x43>
   65ff2: 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00    	nopw	%cs:(%rax,%rax)
   66000: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
   66005: 48 89 05 cc 8c 06 00         	movq	%rax, 0x68ccc(%rip)     # 0xcecd8 <native_roots>
   6600c: 48 ff 0d f5 8b 06 00         	decq	0x68bf5(%rip)           # 0xcec08 <root_depth>
   66013: 48 c7 44 24 20 0f 00 00 00   	movq	$0xf, 0x20(%rsp)
   6601c: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
   66025: 48 8b 05 ac 8c 06 00         	movq	0x68cac(%rip), %rax     # 0xcecd8 <native_roots>
   6602c: 48 89 44 24 18               	movq	%rax, 0x18(%rsp)
   66031: 4c 89 25 a0 8c 06 00         	movq	%r12, 0x68ca0(%rip)     # 0xcecd8 <native_roots>
   66038: 48 8b 05 c9 8b 06 00         	movq	0x68bc9(%rip), %rax     # 0xcec08 <root_depth>
   6603f: 48 ff c0                     	incq	%rax
   66042: 48 89 05 bf 8b 06 00         	movq	%rax, 0x68bbf(%rip)     # 0xcec08 <root_depth>
   66049: 48 3b 05 c0 8b 06 00         	cmpq	0x68bc0(%rip), %rax     # 0xcec10 <peak_root_depth>
   66050: 76 07                        	jbe	0x66059 <f.102+0x89>
   66052: 48 89 05 b7 8b 06 00         	movq	%rax, 0x68bb7(%rip)     # 0xcec10 <peak_root_depth>
   66059: 48 89 7c 24 30               	movq	%rdi, 0x30(%rsp)
   6605e: 48 89 74 24 38               	movq	%rsi, 0x38(%rsp)
   66063: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
   66068: 0f 57 c0                     	xorps	%xmm0, %xmm0
   6606b: 41 0f 11 47 20               	movups	%xmm0, 0x20(%r15)
   66070: 41 0f 11 47 10               	movups	%xmm0, 0x10(%r15)
   66075: 41 0f 11 07                  	movups	%xmm0, (%r15)
   66079: 49 c7 47 30 00 00 00 00      	movq	$0x0, 0x30(%r15)
   66081: 48 83 3d c7 85 06 00 00      	cmpq	$0x0, 0x685c7(%rip)     # 0xce650 <g.5>
   66089: 0f 84 57 24 00 00            	je	0x684e6 <f.102+0x2516>
   6608f: 48 83 3d b1 85 06 00 00      	cmpq	$0x0, 0x685b1(%rip)     # 0xce648 <g.4>
   66097: 0f 84 49 24 00 00            	je	0x684e6 <f.102+0x2516>
   6609d: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   660a5: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   660ae: e8 dd ee ff ff               	callq	0x64f90 <f.45>
   660b3: 48 83 ec 08                  	subq	$0x8, %rsp
   660b7: 48 8b 0d 92 85 06 00         	movq	0x68592(%rip), %rcx     # 0xce650 <g.5>
   660be: 48 85 c0                     	testq	%rax, %rax
   660c1: 0f 84 df 1a 00 00            	je	0x67ba6 <f.102+0x1bd6>
   660c7: 48 85 c9                     	testq	%rcx, %rcx
   660ca: 0f 84 16 24 00 00            	je	0x684e6 <f.102+0x2516>
   660d0: 48 83 3d 70 85 06 00 00      	cmpq	$0x0, 0x68570(%rip)     # 0xce648 <g.4>
   660d8: 0f 84 08 24 00 00            	je	0x684e6 <f.102+0x2516>
   660de: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
   660e3: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   660eb: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   660f4: e8 97 ee ff ff               	callq	0x64f90 <f.45>
   660f9: 48 83 ec 08                  	subq	$0x8, %rsp
   660fd: 48 85 c0                     	testq	%rax, %rax
   66100: 0f 84 fa 1a 00 00            	je	0x67c00 <f.102+0x1c30>
   66106: 48 83 3d 5a 85 06 00 00      	cmpq	$0x0, 0x6855a(%rip)     # 0xce668 <g.9>
   6610e: 0f 84 d2 23 00 00            	je	0x684e6 <f.102+0x2516>
   66114: 48 83 3d 5c 86 06 00 00      	cmpq	$0x0, 0x6865c(%rip)     # 0xce778 <g.46>
   6611c: 0f 84 c4 23 00 00            	je	0x684e6 <f.102+0x2516>
   66122: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
   66127: 48 85 c9                     	testq	%rcx, %rcx
   6612a: 0f 84 b6 23 00 00            	je	0x684e6 <f.102+0x2516>
   66130: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   66134: 0f 85 ac 23 00 00            	jne	0x684e6 <f.102+0x2516>
   6613a: f6 c1 01                     	testb	$0x1, %cl
   6613d: 0f 85 a3 23 00 00            	jne	0x684e6 <f.102+0x2516>
   66143: 48 8b 01                     	movq	(%rcx), %rax
   66146: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   6614c: 0f 85 b1 1f 00 00            	jne	0x68103 <f.102+0x2133>
   66152: 48 8b 41 10                  	movq	0x10(%rcx), %rax
   66156: 48 85 c0                     	testq	%rax, %rax
   66159: 0f 84 87 23 00 00            	je	0x684e6 <f.102+0x2516>
   6615f: 48 8b 35 0a 8a 06 00         	movq	0x68a0a(%rip), %rsi     # 0xceb70 <g.182>
   66166: 48 85 f6                     	testq	%rsi, %rsi
   66169: 0f 84 77 23 00 00            	je	0x684e6 <f.102+0x2516>
   6616f: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   66173: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   6617b: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   66183: 48 c7 44 24 28 0c 00 00 00   	movq	$0xc, 0x28(%rsp)
   6618c: e8 5f 23 00 00               	callq	0x684f0 <f.47>
   66191: 48 83 ec 08                  	subq	$0x8, %rsp
   66195: 85 c0                        	testl	%eax, %eax
   66197: 0f 85 c9 00 00 00            	jne	0x66266 <f.102+0x296>
   6619d: 48 83 3d c3 84 06 00 00      	cmpq	$0x0, 0x684c3(%rip)     # 0xce668 <g.9>
   661a5: 0f 84 3b 23 00 00            	je	0x684e6 <f.102+0x2516>
   661ab: 48 83 3d c5 85 06 00 00      	cmpq	$0x0, 0x685c5(%rip)     # 0xce778 <g.46>
   661b3: 0f 84 2d 23 00 00            	je	0x684e6 <f.102+0x2516>
   661b9: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
   661be: 48 85 c9                     	testq	%rcx, %rcx
   661c1: 0f 84 1f 23 00 00            	je	0x684e6 <f.102+0x2516>
   661c7: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   661cb: 0f 85 15 23 00 00            	jne	0x684e6 <f.102+0x2516>
   661d1: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
   661d6: 48 85 c0                     	testq	%rax, %rax
   661d9: 0f 84 07 23 00 00            	je	0x684e6 <f.102+0x2516>
   661df: 83 78 08 06                  	cmpl	$0x6, 0x8(%rax)
   661e3: 0f 85 fd 22 00 00            	jne	0x684e6 <f.102+0x2516>
   661e9: f6 c1 01                     	testb	$0x1, %cl
   661ec: 0f 85 f4 22 00 00            	jne	0x684e6 <f.102+0x2516>
   661f2: 48 8b 11                     	movq	(%rcx), %rdx
   661f5: 48 81 fa 5a 01 00 00         	cmpq	$0x15a, %rdx            # imm = 0x15A
   661fc: 0f 85 02 20 00 00            	jne	0x68204 <f.102+0x2234>
   66202: 48 8b 51 10                  	movq	0x10(%rcx), %rdx
   66206: 48 85 d2                     	testq	%rdx, %rdx
   66209: 0f 84 d7 22 00 00            	je	0x684e6 <f.102+0x2516>
   6620f: a8 01                        	testb	$0x1, %al
   66211: 0f 85 cf 22 00 00            	jne	0x684e6 <f.102+0x2516>
   66217: 48 8b 08                     	movq	(%rax), %rcx
   6621a: 48 81 f9 5a 01 00 00         	cmpq	$0x15a, %rcx            # imm = 0x15A
   66221: 0f 85 9d 1f 00 00            	jne	0x681c4 <f.102+0x21f4>
   66227: 48 8b 40 10                  	movq	0x10(%rax), %rax
   6622b: 48 85 c0                     	testq	%rax, %rax
   6622e: 0f 84 b2 22 00 00            	je	0x684e6 <f.102+0x2516>
   66234: 48 8b 7a 08                  	movq	0x8(%rdx), %rdi
   66238: 48 8b 70 08                  	movq	0x8(%rax), %rsi
   6623c: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   66244: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   6624c: 48 c7 44 24 28 0c 00 00 00   	movq	$0xc, 0x28(%rsp)
   66255: e8 96 22 00 00               	callq	0x684f0 <f.47>
   6625a: 48 83 ec 08                  	subq	$0x8, %rsp
   6625e: 85 c0                        	testl	%eax, %eax
   66260: 0f 84 d5 00 00 00            	je	0x6633b <f.102+0x36b>
   66266: 48 83 3d ca 83 06 00 00      	cmpq	$0x0, 0x683ca(%rip)     # 0xce638 <g.1>
   6626e: 0f 84 72 22 00 00            	je	0x684e6 <f.102+0x2516>
   66274: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
   66279: 48 85 c9                     	testq	%rcx, %rcx
   6627c: 0f 84 64 22 00 00            	je	0x684e6 <f.102+0x2516>
   66282: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   66286: 0f 85 5a 22 00 00            	jne	0x684e6 <f.102+0x2516>
   6628c: f6 c1 01                     	testb	$0x1, %cl
   6628f: 0f 85 51 22 00 00            	jne	0x684e6 <f.102+0x2516>
   66295: 48 8b 01                     	movq	(%rcx), %rax
   66298: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   6629e: 0f 85 a0 1e 00 00            	jne	0x68144 <f.102+0x2174>
   662a4: 48 8b 41 18                  	movq	0x18(%rcx), %rax
   662a8: 48 85 c0                     	testq	%rax, %rax
   662ab: 0f 84 35 22 00 00            	je	0x684e6 <f.102+0x2516>
   662b1: 48 8b 40 08                  	movq	0x8(%rax), %rax
   662b5: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
   662ba: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
   662bf: 48 85 c9                     	testq	%rcx, %rcx
   662c2: 0f 84 1e 22 00 00            	je	0x684e6 <f.102+0x2516>
   662c8: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   662cc: 0f 85 14 22 00 00            	jne	0x684e6 <f.102+0x2516>
   662d2: f6 c1 01                     	testb	$0x1, %cl
   662d5: 0f 85 0b 22 00 00            	jne	0x684e6 <f.102+0x2516>
   662db: 48 8b 01                     	movq	(%rcx), %rax
   662de: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   662e4: 0f 85 9a 1e 00 00            	jne	0x68184 <f.102+0x21b4>
   662ea: 48 8b 41 18                  	movq	0x18(%rcx), %rax
   662ee: 48 85 c0                     	testq	%rax, %rax
   662f1: 0f 84 ef 21 00 00            	je	0x684e6 <f.102+0x2516>
   662f7: 48 8b 40 08                  	movq	0x8(%rax), %rax
   662fb: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
   66300: 80 3d 61 84 06 00 00         	cmpb	$0x0, 0x68461(%rip)     # 0xce768 <g.44>
   66307: 0f 84 d9 21 00 00            	je	0x684e6 <f.102+0x2516>
   6630d: 48 83 3d 23 84 06 00 00      	cmpq	$0x0, 0x68423(%rip)     # 0xce738 <g.38>
   66315: 0f 84 cb 21 00 00            	je	0x684e6 <f.102+0x2516>
   6631b: 48 8b 7c 24 30               	movq	0x30(%rsp), %rdi
   66320: 48 8b 74 24 38               	movq	0x38(%rsp), %rsi
   66325: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
   6632a: 48 83 7c 24 20 00            	cmpq	$0x0, 0x20(%rsp)
   66330: 0f 85 ca fc ff ff            	jne	0x66000 <f.102+0x30>
   66336: e9 d8 fc ff ff               	jmp	0x66013 <f.102+0x43>
   6633b: 48 83 3d 25 83 06 00 00      	cmpq	$0x0, 0x68325(%rip)     # 0xce668 <g.9>
   66343: 0f 84 9d 21 00 00            	je	0x684e6 <f.102+0x2516>
   66349: 48 83 3d 27 84 06 00 00      	cmpq	$0x0, 0x68427(%rip)     # 0xce778 <g.46>
   66351: 0f 84 8f 21 00 00            	je	0x684e6 <f.102+0x2516>
   66357: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
   6635c: 48 85 c9                     	testq	%rcx, %rcx
   6635f: 0f 84 81 21 00 00            	je	0x684e6 <f.102+0x2516>
   66365: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   66369: 0f 85 77 21 00 00            	jne	0x684e6 <f.102+0x2516>
   6636f: f6 c1 01                     	testb	$0x1, %cl
   66372: 0f 85 6e 21 00 00            	jne	0x684e6 <f.102+0x2516>
   66378: 48 8b 01                     	movq	(%rcx), %rax
   6637b: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   66381: 0f 85 bd 1e 00 00            	jne	0x68244 <f.102+0x2274>
   66387: 48 89 4c 24 48               	movq	%rcx, 0x48(%rsp)
   6638c: 48 8b 41 10                  	movq	0x10(%rcx), %rax
   66390: 48 85 c0                     	testq	%rax, %rax
   66393: 0f 84 4d 21 00 00            	je	0x684e6 <f.102+0x2516>
   66399: 48 8b 35 d8 87 06 00         	movq	0x687d8(%rip), %rsi     # 0xceb78 <g.183>
   663a0: 48 85 f6                     	testq	%rsi, %rsi
   663a3: 0f 84 3d 21 00 00            	je	0x684e6 <f.102+0x2516>
   663a9: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   663ad: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   663b5: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   663bd: 48 c7 44 24 28 0c 00 00 00   	movq	$0xc, 0x28(%rsp)
   663c6: e8 25 21 00 00               	callq	0x684f0 <f.47>
   663cb: 48 83 ec 08                  	subq	$0x8, %rsp
   663cf: 85 c0                        	testl	%eax, %eax
   663d1: 0f 84 b6 01 00 00            	je	0x6658d <f.102+0x5bd>
   663d7: 48 83 3d 59 82 06 00 00      	cmpq	$0x0, 0x68259(%rip)     # 0xce638 <g.1>
   663df: 0f 84 01 21 00 00            	je	0x684e6 <f.102+0x2516>
   663e5: 80 3d 7c 83 06 00 00         	cmpb	$0x0, 0x6837c(%rip)     # 0xce768 <g.44>
   663ec: 0f 84 f4 20 00 00            	je	0x684e6 <f.102+0x2516>
   663f2: 48 83 3d 3e 83 06 00 00      	cmpq	$0x0, 0x6833e(%rip)     # 0xce738 <g.38>
   663fa: 0f 84 e6 20 00 00            	je	0x684e6 <f.102+0x2516>
   66400: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   66405: 48 85 c0                     	testq	%rax, %rax
   66408: 0f 84 d8 20 00 00            	je	0x684e6 <f.102+0x2516>
   6640e: 48 8b 40 18                  	movq	0x18(%rax), %rax
   66412: 48 85 c0                     	testq	%rax, %rax
   66415: 0f 84 cb 20 00 00            	je	0x684e6 <f.102+0x2516>
   6641b: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   6641f: 48 8b 74 24 38               	movq	0x38(%rsp), %rsi
   66424: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
   66429: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   66431: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   66439: 48 89 94 24 90 00 00 00      	movq	%rdx, 0x90(%rsp)
   66441: 48 c7 44 24 28 0d 00 00 00   	movq	$0xd, 0x28(%rsp)
   6644a: e8 81 fb ff ff               	callq	0x65fd0 <f.102>
   6644f: 48 83 ec 08                  	subq	$0x8, %rsp
   66453: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
   66458: 48 83 3d 28 83 06 00 00      	cmpq	$0x0, 0x68328(%rip)     # 0xce788 <g.48>
   66460: 0f 84 80 20 00 00            	je	0x684e6 <f.102+0x2516>
   66466: 83 78 08 00                  	cmpl	$0x0, 0x8(%rax)
   6646a: 0f 85 b1 17 00 00            	jne	0x67c21 <f.102+0x1c51>
   66470: 48 83 3d c0 81 06 00 00      	cmpq	$0x0, 0x681c0(%rip)     # 0xce638 <g.1>
   66478: 0f 84 68 20 00 00            	je	0x684e6 <f.102+0x2516>
   6647e: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
   66483: 48 85 c9                     	testq	%rcx, %rcx
   66486: 0f 84 5a 20 00 00            	je	0x684e6 <f.102+0x2516>
   6648c: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   66490: 0f 85 50 20 00 00            	jne	0x684e6 <f.102+0x2516>
   66496: f6 c1 01                     	testb	$0x1, %cl
   66499: 0f 85 47 20 00 00            	jne	0x684e6 <f.102+0x2516>
   6649f: 48 8b 01                     	movq	(%rcx), %rax
   664a2: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   664a8: 0f 85 d6 1d 00 00            	jne	0x68284 <f.102+0x22b4>
   664ae: 48 8b 41 18                  	movq	0x18(%rcx), %rax
   664b2: 48 85 c0                     	testq	%rax, %rax
   664b5: 0f 84 2b 20 00 00            	je	0x684e6 <f.102+0x2516>
   664bb: 48 8b 70 08                  	movq	0x8(%rax), %rsi
   664bf: 48 89 74 24 68               	movq	%rsi, 0x68(%rsp)
   664c4: 80 3d 9d 82 06 00 00         	cmpb	$0x0, 0x6829d(%rip)     # 0xce768 <g.44>
   664cb: 0f 84 15 20 00 00            	je	0x684e6 <f.102+0x2516>
   664d1: 48 83 3d 5f 82 06 00 00      	cmpq	$0x0, 0x6825f(%rip)     # 0xce738 <g.38>
   664d9: 0f 84 07 20 00 00            	je	0x684e6 <f.102+0x2516>
   664df: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   664e4: 48 85 c0                     	testq	%rax, %rax
   664e7: 0f 84 f9 1f 00 00            	je	0x684e6 <f.102+0x2516>
   664ed: 48 8b 40 18                  	movq	0x18(%rax), %rax
   664f1: 48 85 c0                     	testq	%rax, %rax
   664f4: 0f 84 ec 1f 00 00            	je	0x684e6 <f.102+0x2516>
   664fa: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   664fe: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
   66503: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   6650b: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   66513: 48 89 94 24 90 00 00 00      	movq	%rdx, 0x90(%rsp)
   6651b: 48 c7 44 24 28 0d 00 00 00   	movq	$0xd, 0x28(%rsp)
   66524: e8 a7 fa ff ff               	callq	0x65fd0 <f.102>
   66529: 48 83 ec 08                  	subq	$0x8, %rsp
   6652d: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
   66532: 48 83 3d 4e 82 06 00 00      	cmpq	$0x0, 0x6824e(%rip)     # 0xce788 <g.48>
   6653a: 0f 84 a6 1f 00 00            	je	0x684e6 <f.102+0x2516>
   66540: 83 78 08 00                  	cmpl	$0x0, 0x8(%rax)
   66544: 0f 85 d7 16 00 00            	jne	0x67c21 <f.102+0x1c51>
   6654a: 48 83 3d e6 80 06 00 00      	cmpq	$0x0, 0x680e6(%rip)     # 0xce638 <g.1>
   66552: 0f 84 8e 1f 00 00            	je	0x684e6 <f.102+0x2516>
   66558: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
   6655d: 48 85 c9                     	testq	%rcx, %rcx
   66560: 0f 84 80 1f 00 00            	je	0x684e6 <f.102+0x2516>
   66566: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   6656a: 0f 85 76 1f 00 00            	jne	0x684e6 <f.102+0x2516>
   66570: f6 c1 01                     	testb	$0x1, %cl
   66573: 0f 85 6d 1f 00 00            	jne	0x684e6 <f.102+0x2516>
   66579: 48 8b 01                     	movq	(%rcx), %rax
   6657c: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   66582: 0f 84 62 fd ff ff            	je	0x662ea <f.102+0x31a>
   66588: e9 37 1d 00 00               	jmp	0x682c4 <f.102+0x22f4>
   6658d: 48 83 3d d3 80 06 00 00      	cmpq	$0x0, 0x680d3(%rip)     # 0xce668 <g.9>
   66595: 0f 84 4b 1f 00 00            	je	0x684e6 <f.102+0x2516>
   6659b: 48 83 3d 45 82 06 00 00      	cmpq	$0x0, 0x68245(%rip)     # 0xce7e8 <g.61>
   665a3: 0f 84 3d 1f 00 00            	je	0x684e6 <f.102+0x2516>
   665a9: 48 83 3d 97 80 06 00 00      	cmpq	$0x0, 0x68097(%rip)     # 0xce648 <g.4>
   665b1: 0f 84 2f 1f 00 00            	je	0x684e6 <f.102+0x2516>
   665b7: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   665bc: 48 85 c0                     	testq	%rax, %rax
   665bf: 0f 84 21 1f 00 00            	je	0x684e6 <f.102+0x2516>
   665c5: 48 8b 40 10                  	movq	0x10(%rax), %rax
   665c9: 48 85 c0                     	testq	%rax, %rax
   665cc: 0f 84 14 1f 00 00            	je	0x684e6 <f.102+0x2516>
   665d2: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   665d6: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   665de: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   665e7: e8 a4 e9 ff ff               	callq	0x64f90 <f.45>
   665ec: 48 83 ec 08                  	subq	$0x8, %rsp
   665f0: 48 8b 0d 71 80 06 00         	movq	0x68071(%rip), %rcx     # 0xce668 <g.9>
   665f7: 83 f8 06                     	cmpl	$0x6, %eax
   665fa: 0f 85 b1 00 00 00            	jne	0x666b1 <f.102+0x6e1>
   66600: 48 85 c9                     	testq	%rcx, %rcx
   66603: 0f 84 dd 1e 00 00            	je	0x684e6 <f.102+0x2516>
   66609: 48 83 3d d7 81 06 00 00      	cmpq	$0x0, 0x681d7(%rip)     # 0xce7e8 <g.61>
   66611: 0f 84 cf 1e 00 00            	je	0x684e6 <f.102+0x2516>
   66617: 48 83 3d 29 80 06 00 00      	cmpq	$0x0, 0x68029(%rip)     # 0xce648 <g.4>
   6661f: 0f 84 c1 1e 00 00            	je	0x684e6 <f.102+0x2516>
   66625: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
   6662a: 48 85 c9                     	testq	%rcx, %rcx
   6662d: 0f 84 b3 1e 00 00            	je	0x684e6 <f.102+0x2516>
   66633: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   66637: 0f 85 a9 1e 00 00            	jne	0x684e6 <f.102+0x2516>
   6663d: f6 c1 01                     	testb	$0x1, %cl
   66640: 0f 85 a0 1e 00 00            	jne	0x684e6 <f.102+0x2516>
   66646: 48 8b 01                     	movq	(%rcx), %rax
   66649: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   6664f: 0f 85 af 1c 00 00            	jne	0x68304 <f.102+0x2334>
   66655: 48 8b 41 10                  	movq	0x10(%rcx), %rax
   66659: 48 85 c0                     	testq	%rax, %rax
   6665c: 0f 84 84 1e 00 00            	je	0x684e6 <f.102+0x2516>
   66662: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   66666: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   6666e: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   66677: e8 14 e9 ff ff               	callq	0x64f90 <f.45>
   6667c: 48 83 ec 08                  	subq	$0x8, %rsp
   66680: 48 83 3d 98 81 06 00 00      	cmpq	$0x0, 0x68198(%rip)     # 0xce820 <g.68>
   66688: 0f 84 58 1e 00 00            	je	0x684e6 <f.102+0x2516>
   6668e: 48 83 3d f2 80 06 00 00      	cmpq	$0x0, 0x680f2(%rip)     # 0xce788 <g.48>
   66696: 0f 84 4a 1e 00 00            	je	0x684e6 <f.102+0x2516>
   6669c: 83 f8 06                     	cmpl	$0x6, %eax
   6669f: 0f 85 5a 03 00 00            	jne	0x669ff <f.102+0xa2f>
   666a5: 48 8b 05 6c 81 06 00         	movq	0x6816c(%rip), %rax     # 0xce818 <g.67>
   666ac: e9 55 03 00 00               	jmp	0x66a06 <f.102+0xa36>
   666b1: 48 85 c9                     	testq	%rcx, %rcx
   666b4: 0f 84 2c 1e 00 00            	je	0x684e6 <f.102+0x2516>
   666ba: 48 83 3d 66 81 06 00 00      	cmpq	$0x0, 0x68166(%rip)     # 0xce828 <g.69>
   666c2: 0f 84 1e 1e 00 00            	je	0x684e6 <f.102+0x2516>
   666c8: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   666cd: 48 85 c0                     	testq	%rax, %rax
   666d0: 0f 84 10 1e 00 00            	je	0x684e6 <f.102+0x2516>
   666d6: 48 8b 40 10                  	movq	0x10(%rax), %rax
   666da: 48 85 c0                     	testq	%rax, %rax
   666dd: 0f 84 03 1e 00 00            	je	0x684e6 <f.102+0x2516>
   666e3: 48 8b 48 08                  	movq	0x8(%rax), %rcx
   666e7: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
   666ec: 48 85 c9                     	testq	%rcx, %rcx
   666ef: 0f 84 f1 1d 00 00            	je	0x684e6 <f.102+0x2516>
   666f5: 83 79 08 04                  	cmpl	$0x4, 0x8(%rcx)
   666f9: 0f 85 e7 1d 00 00            	jne	0x684e6 <f.102+0x2516>
   666ff: 48 83 3d c9 80 06 00 00      	cmpq	$0x0, 0x680c9(%rip)     # 0xce7d0 <g.58>
   66707: 0f 84 d9 1d 00 00            	je	0x684e6 <f.102+0x2516>
   6670d: f6 c1 01                     	testb	$0x1, %cl
   66710: 0f 85 d0 1d 00 00            	jne	0x684e6 <f.102+0x2516>
   66716: 48 8b 01                     	movq	(%rcx), %rax
   66719: 48 3d 1a 03 00 00            	cmpq	$0x31a, %rax            # imm = 0x31A
   6671f: 0f 85 13 1c 00 00            	jne	0x68338 <f.102+0x2368>
   66725: 48 8b 41 10                  	movq	0x10(%rcx), %rax
   66729: 48 85 c0                     	testq	%rax, %rax
   6672c: 0f 84 b4 1d 00 00            	je	0x684e6 <f.102+0x2516>
   66732: 8b 58 08                     	movl	0x8(%rax), %ebx
   66735: 48 c7 44 24 28 0a 00 00 00   	movq	$0xa, 0x28(%rsp)
   6673e: 89 df                        	movl	%ebx, %edi
   66740: e8 db 03 fc ff               	callq	0x26b20 <snail:datum/symbol-length>
   66745: 48 83 3d 53 7f 06 00 00      	cmpq	$0x0, 0x67f53(%rip)     # 0xce6a0 <g.19>
   6674d: 0f 84 93 1d 00 00            	je	0x684e6 <f.102+0x2516>
   66753: 49 89 c6                     	movq	%rax, %r14
   66756: 48 39 e8                     	cmpq	%rbp, %rax
   66759: 0f 87 87 1d 00 00            	ja	0x684e6 <f.102+0x2516>
   6675f: 48 c7 44 24 28 0a 00 00 00   	movq	$0xa, 0x28(%rsp)
   66768: 44 89 f7                     	movl	%r14d, %edi
   6676b: e8 30 25 00 00               	callq	0x68ca0 <f.23>
   66770: 48 83 ec 08                  	subq	$0x8, %rsp
   66774: 48 89 84 24 80 00 00 00      	movq	%rax, 0x80(%rsp)
   6677c: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   66785: 89 df                        	movl	%ebx, %edi
   66787: 4c 89 f6                     	movq	%r14, %rsi
   6678a: 48 89 c2                     	movq	%rax, %rdx
   6678d: e8 ee 27 00 00               	callq	0x68f80 <f.32>
   66792: 48 83 ec 08                  	subq	$0x8, %rsp
   66796: 48 89 44 24 60               	movq	%rax, 0x60(%rsp)
   6679b: 48 85 c0                     	testq	%rax, %rax
   6679e: 0f 84 42 1d 00 00            	je	0x684e6 <f.102+0x2516>
   667a4: 83 78 10 00                  	cmpl	$0x0, 0x10(%rax)
   667a8: 0f 84 38 1d 00 00            	je	0x684e6 <f.102+0x2516>
   667ae: 48 8b 40 18                  	movq	0x18(%rax), %rax
   667b2: 48 85 c0                     	testq	%rax, %rax
   667b5: 0f 84 2b 1d 00 00            	je	0x684e6 <f.102+0x2516>
   667bb: 89 c1                        	movl	%eax, %ecx
   667bd: 83 e1 01                     	andl	$0x1, %ecx
   667c0: 0f 85 20 1d 00 00            	jne	0x684e6 <f.102+0x2516>
   667c6: 48 83 78 08 00               	cmpq	$0x0, 0x8(%rax)
   667cb: 0f 84 15 1d 00 00            	je	0x684e6 <f.102+0x2516>
   667d1: 83 78 10 3f                  	cmpl	$0x3f, 0x10(%rax)
   667d5: 48 8b 05 8c 7e 06 00         	movq	0x67e8c(%rip), %rax     # 0xce668 <g.9>
   667dc: 0f 85 78 03 00 00            	jne	0x66b5a <f.102+0xb8a>
   667e2: 48 85 c0                     	testq	%rax, %rax
   667e5: 0f 84 fb 1c 00 00            	je	0x684e6 <f.102+0x2516>
   667eb: 48 83 3d fd 7f 06 00 00      	cmpq	$0x0, 0x67ffd(%rip)     # 0xce7f0 <g.62>
   667f3: 0f 84 ed 1c 00 00            	je	0x684e6 <f.102+0x2516>
   667f9: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   667fe: 48 85 c0                     	testq	%rax, %rax
   66801: 0f 84 df 1c 00 00            	je	0x684e6 <f.102+0x2516>
   66807: 48 8b 40 10                  	movq	0x10(%rax), %rax
   6680b: 48 85 c0                     	testq	%rax, %rax
   6680e: 0f 84 d2 1c 00 00            	je	0x684e6 <f.102+0x2516>
   66814: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   66818: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
   6681d: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   66825: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   6682d: 48 c7 44 24 28 0c 00 00 00   	movq	$0xc, 0x28(%rsp)
   66836: e8 a5 28 00 00               	callq	0x690e0 <f.53>
   6683b: 48 83 ec 08                  	subq	$0x8, %rsp
   6683f: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
   66844: 48 83 3d f4 7e 06 00 00      	cmpq	$0x0, 0x67ef4(%rip)     # 0xce740 <g.39>
   6684c: 0f 84 94 1c 00 00            	je	0x684e6 <f.102+0x2516>
   66852: 48 83 3d ee 7d 06 00 00      	cmpq	$0x0, 0x67dee(%rip)     # 0xce648 <g.4>
   6685a: 0f 84 86 1c 00 00            	je	0x684e6 <f.102+0x2516>
   66860: 48 89 84 24 80 00 00 00      	movq	%rax, 0x80(%rsp)
   66868: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   66871: 48 89 c7                     	movq	%rax, %rdi
   66874: e8 17 e7 ff ff               	callq	0x64f90 <f.45>
   66879: 48 83 ec 08                  	subq	$0x8, %rsp
   6687d: 83 f8 01                     	cmpl	$0x1, %eax
   66880: 75 3a                        	jne	0x668bc <f.102+0x8ec>
   66882: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
   66887: 48 85 c9                     	testq	%rcx, %rcx
   6688a: 0f 84 56 1c 00 00            	je	0x684e6 <f.102+0x2516>
   66890: 83 79 08 01                  	cmpl	$0x1, 0x8(%rcx)
   66894: 0f 85 4c 1c 00 00            	jne	0x684e6 <f.102+0x2516>
   6689a: f6 c1 01                     	testb	$0x1, %cl
   6689d: 0f 85 43 1c 00 00            	jne	0x684e6 <f.102+0x2516>
   668a3: 48 8b 01                     	movq	(%rcx), %rax
   668a6: 48 3d 4a 01 00 00            	cmpq	$0x14a, %rax            # imm = 0x14A
   668ac: 0f 85 bb 1b 00 00            	jne	0x6846d <f.102+0x249d>
   668b2: 83 79 10 00                  	cmpl	$0x0, 0x10(%rcx)
   668b6: 0f 84 d3 08 00 00            	je	0x6718f <f.102+0x11bf>
   668bc: 48 83 3d 74 7d 06 00 00      	cmpq	$0x0, 0x67d74(%rip)     # 0xce638 <g.1>
   668c4: 0f 84 1c 1c 00 00            	je	0x684e6 <f.102+0x2516>
   668ca: 48 83 3d 5e 7d 06 00 00      	cmpq	$0x0, 0x67d5e(%rip)     # 0xce630 <g.0>
   668d2: 0f 84 0e 1c 00 00            	je	0x684e6 <f.102+0x2516>
   668d8: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
   668dd: 48 85 c9                     	testq	%rcx, %rcx
   668e0: 0f 84 00 1c 00 00            	je	0x684e6 <f.102+0x2516>
   668e6: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   668ea: 0f 85 f6 1b 00 00            	jne	0x684e6 <f.102+0x2516>
   668f0: f6 c1 01                     	testb	$0x1, %cl
   668f3: 0f 85 ed 1b 00 00            	jne	0x684e6 <f.102+0x2516>
   668f9: 48 8b 01                     	movq	(%rcx), %rax
   668fc: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   66902: 0f 85 34 1b 00 00            	jne	0x6843c <f.102+0x246c>
   66908: 48 8b 41 18                  	movq	0x18(%rcx), %rax
   6690c: 48 85 c0                     	testq	%rax, %rax
   6690f: 0f 84 d1 1b 00 00            	je	0x684e6 <f.102+0x2516>
   66915: 4c 8b 70 08                  	movq	0x8(%rax), %r14
   66919: 4c 89 b4 24 80 00 00 00      	movq	%r14, 0x80(%rsp)
   66921: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   6692a: 48 8b 0d e7 82 06 00         	movq	0x682e7(%rip), %rcx     # 0xcec18 <collection_interval>
   66931: 48 85 c9                     	testq	%rcx, %rcx
   66934: 74 30                        	je	0x66966 <f.102+0x996>
   66936: 48 8b 05 e3 82 06 00         	movq	0x682e3(%rip), %rax     # 0xcec20 <allocations>
   6693d: 48 ff c0                     	incq	%rax
   66940: 48 89 05 d9 82 06 00         	movq	%rax, 0x682d9(%rip)     # 0xcec20 <allocations>
   66947: 48 89 c2                     	movq	%rax, %rdx
   6694a: 48 09 ca                     	orq	%rcx, %rdx
   6694d: 48 c1 ea 20                  	shrq	$0x20, %rdx
   66951: 0f 84 02 08 00 00            	je	0x67159 <f.102+0x1189>
   66957: 31 d2                        	xorl	%edx, %edx
   66959: 48 f7 f1                     	divq	%rcx
   6695c: 48 85 d2                     	testq	%rdx, %rdx
   6695f: 75 05                        	jne	0x66966 <f.102+0x996>
   66961: e8 4a d0 05 00               	callq	0xc39b0 <native_gc_collect>
   66966: 48 8b 05 73 7b 06 00         	movq	0x67b73(%rip), %rax     # 0xce4e0 <heap_bytes>
   6696d: 48 83 c0 e8                  	addq	$-0x18, %rax
   66971: 48 83 f8 10                  	cmpq	$0x10, %rax
   66975: 0f 82 bc 16 00 00            	jb	0x68037 <f.102+0x2067>
   6697b: 48 8b 05 a6 82 06 00         	movq	0x682a6(%rip), %rax     # 0xcec28 <since_collection>
   66982: 48 3b 05 5f 7b 06 00         	cmpq	0x67b5f(%rip), %rax     # 0xce4e8 <budget>
   66989: 72 05                        	jb	0x66990 <f.102+0x9c0>
   6698b: e8 20 d0 05 00               	callq	0xc39b0 <native_gc_collect>
   66990: 48 8b 1d 11 83 06 00         	movq	0x68311(%rip), %rbx     # 0xceca8 <cursor>
   66997: 48 85 db                     	testq	%rbx, %rbx
   6699a: 74 14                        	je	0x669b0 <f.102+0x9e0>
   6699c: 48 8b 05 0d 83 06 00         	movq	0x6830d(%rip), %rax     # 0xcecb0 <limit>
   669a3: 48 29 d8                     	subq	%rbx, %rax
   669a6: 48 83 f8 1f                  	cmpq	$0x1f, %rax
   669aa: 0f 87 5b 04 00 00            	ja	0x66e0b <f.102+0xe3b>
   669b0: bf 20 00 00 00               	movl	$0x20, %edi
   669b5: e8 06 ed 05 00               	callq	0xc56c0 <allocate_slow>
   669ba: 48 85 c0                     	testq	%rax, %rax
   669bd: 75 38                        	jne	0x669f7 <f.102+0xa27>
   669bf: e8 ec cf 05 00               	callq	0xc39b0 <native_gc_collect>
   669c4: 48 8b 1d dd 82 06 00         	movq	0x682dd(%rip), %rbx     # 0xceca8 <cursor>
   669cb: 48 85 db                     	testq	%rbx, %rbx
   669ce: 74 14                        	je	0x669e4 <f.102+0xa14>
   669d0: 48 8b 05 d9 82 06 00         	movq	0x682d9(%rip), %rax     # 0xcecb0 <limit>
   669d7: 48 29 d8                     	subq	%rbx, %rax
   669da: 48 83 f8 1f                  	cmpq	$0x1f, %rax
   669de: 0f 87 27 04 00 00            	ja	0x66e0b <f.102+0xe3b>
   669e4: bf 20 00 00 00               	movl	$0x20, %edi
   669e9: e8 d2 ec 05 00               	callq	0xc56c0 <allocate_slow>
   669ee: 48 85 c0                     	testq	%rax, %rax
   669f1: 0f 84 40 16 00 00            	je	0x68037 <f.102+0x2067>
   669f7: 48 89 c3                     	movq	%rax, %rbx
   669fa: e9 17 04 00 00               	jmp	0x66e16 <f.102+0xe46>
   669ff: 48 8b 05 5a 7d 06 00         	movq	0x67d5a(%rip), %rax     # 0xce760 <g.43>
   66a06: 48 85 c0                     	testq	%rax, %rax
   66a09: 0f 84 d7 1a 00 00            	je	0x684e6 <f.102+0x2516>
   66a0f: 83 78 08 00                  	cmpl	$0x0, 0x8(%rax)
   66a13: 0f 84 d6 11 00 00            	je	0x67bef <f.102+0x1c1f>
   66a19: 48 83 3d 47 7c 06 00 00      	cmpq	$0x0, 0x67c47(%rip)     # 0xce668 <g.9>
   66a21: 0f 84 bf 1a 00 00            	je	0x684e6 <f.102+0x2516>
   66a27: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
   66a2c: 48 85 c9                     	testq	%rcx, %rcx
   66a2f: 0f 84 b1 1a 00 00            	je	0x684e6 <f.102+0x2516>
   66a35: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   66a39: 0f 85 a7 1a 00 00            	jne	0x684e6 <f.102+0x2516>
   66a3f: f6 c1 01                     	testb	$0x1, %cl
   66a42: 0f 85 9e 1a 00 00            	jne	0x684e6 <f.102+0x2516>
   66a48: 48 8b 01                     	movq	(%rcx), %rax
   66a4b: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   66a51: 0f 85 15 19 00 00            	jne	0x6836c <f.102+0x239c>
   66a57: 48 8b 41 10                  	movq	0x10(%rcx), %rax
   66a5b: 48 85 c0                     	testq	%rax, %rax
   66a5e: 0f 84 82 1a 00 00            	je	0x684e6 <f.102+0x2516>
   66a64: 48 8b 70 08                  	movq	0x8(%rax), %rsi
   66a68: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
   66a6d: 80 3d f4 7c 06 00 00         	cmpb	$0x0, 0x67cf4(%rip)     # 0xce768 <g.44>
   66a74: 0f 84 6c 1a 00 00            	je	0x684e6 <f.102+0x2516>
   66a7a: 48 83 3d b6 7c 06 00 00      	cmpq	$0x0, 0x67cb6(%rip)     # 0xce738 <g.38>
   66a82: 0f 84 5e 1a 00 00            	je	0x684e6 <f.102+0x2516>
   66a88: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   66a8d: 48 85 c0                     	testq	%rax, %rax
   66a90: 0f 84 50 1a 00 00            	je	0x684e6 <f.102+0x2516>
   66a96: 48 8b 40 10                  	movq	0x10(%rax), %rax
   66a9a: 48 85 c0                     	testq	%rax, %rax
   66a9d: 0f 84 43 1a 00 00            	je	0x684e6 <f.102+0x2516>
   66aa3: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   66aa7: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
   66aac: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   66ab4: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   66abc: 48 89 94 24 90 00 00 00      	movq	%rdx, 0x90(%rsp)
   66ac4: 48 c7 44 24 28 0d 00 00 00   	movq	$0xd, 0x28(%rsp)
   66acd: e8 fe f4 ff ff               	callq	0x65fd0 <f.102>
   66ad2: 48 83 ec 08                  	subq	$0x8, %rsp
   66ad6: 48 89 44 24 78               	movq	%rax, 0x78(%rsp)
   66adb: 48 83 3d a5 7c 06 00 00      	cmpq	$0x0, 0x67ca5(%rip)     # 0xce788 <g.48>
   66ae3: 0f 84 fd 19 00 00            	je	0x684e6 <f.102+0x2516>
   66ae9: 83 78 08 00                  	cmpl	$0x0, 0x8(%rax)
   66aed: 0f 84 fc 10 00 00            	je	0x67bef <f.102+0x1c1f>
   66af3: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   66af8: 48 85 c0                     	testq	%rax, %rax
   66afb: 0f 84 e5 19 00 00            	je	0x684e6 <f.102+0x2516>
   66b01: 48 8b 40 18                  	movq	0x18(%rax), %rax
   66b05: 48 85 c0                     	testq	%rax, %rax
   66b08: 0f 84 d8 19 00 00            	je	0x684e6 <f.102+0x2516>
   66b0e: 48 8b 40 08                  	movq	0x8(%rax), %rax
   66b12: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
   66b17: 48 83 3d 19 7b 06 00 00      	cmpq	$0x0, 0x67b19(%rip)     # 0xce638 <g.1>
   66b1f: 0f 84 c1 19 00 00            	je	0x684e6 <f.102+0x2516>
   66b25: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
   66b2a: 48 85 c9                     	testq	%rcx, %rcx
   66b2d: 0f 84 b3 19 00 00            	je	0x684e6 <f.102+0x2516>
   66b33: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   66b37: 0f 85 a9 19 00 00            	jne	0x684e6 <f.102+0x2516>
   66b3d: f6 c1 01                     	testb	$0x1, %cl
   66b40: 0f 85 a0 19 00 00            	jne	0x684e6 <f.102+0x2516>
   66b46: 48 8b 01                     	movq	(%rcx), %rax
   66b49: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   66b4f: 0f 84 95 f7 ff ff            	je	0x662ea <f.102+0x31a>
   66b55: e9 46 18 00 00               	jmp	0x683a0 <f.102+0x23d0>
   66b5a: 48 85 c0                     	testq	%rax, %rax
   66b5d: 0f 84 83 19 00 00            	je	0x684e6 <f.102+0x2516>
   66b63: 48 83 3d bd 7c 06 00 00      	cmpq	$0x0, 0x67cbd(%rip)     # 0xce828 <g.69>
   66b6b: 0f 84 75 19 00 00            	je	0x684e6 <f.102+0x2516>
   66b71: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   66b76: 48 85 c0                     	testq	%rax, %rax
   66b79: 0f 84 67 19 00 00            	je	0x684e6 <f.102+0x2516>
   66b7f: 48 8b 40 10                  	movq	0x10(%rax), %rax
   66b83: 48 85 c0                     	testq	%rax, %rax
   66b86: 0f 84 5a 19 00 00            	je	0x684e6 <f.102+0x2516>
   66b8c: 48 8b 48 08                  	movq	0x8(%rax), %rcx
   66b90: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
   66b95: 48 85 c9                     	testq	%rcx, %rcx
   66b98: 0f 84 48 19 00 00            	je	0x684e6 <f.102+0x2516>
   66b9e: 83 79 08 04                  	cmpl	$0x4, 0x8(%rcx)
   66ba2: 0f 85 3e 19 00 00            	jne	0x684e6 <f.102+0x2516>
   66ba8: 48 83 3d 20 7c 06 00 00      	cmpq	$0x0, 0x67c20(%rip)     # 0xce7d0 <g.58>
   66bb0: 0f 84 30 19 00 00            	je	0x684e6 <f.102+0x2516>
   66bb6: f6 c1 01                     	testb	$0x1, %cl
   66bb9: 0f 85 27 19 00 00            	jne	0x684e6 <f.102+0x2516>
   66bbf: 48 8b 01                     	movq	(%rcx), %rax
   66bc2: 48 3d 1a 03 00 00            	cmpq	$0x31a, %rax            # imm = 0x31A
   66bc8: 0f 85 06 18 00 00            	jne	0x683d4 <f.102+0x2404>
   66bce: 48 8b 41 10                  	movq	0x10(%rcx), %rax
   66bd2: 48 85 c0                     	testq	%rax, %rax
   66bd5: 0f 84 0b 19 00 00            	je	0x684e6 <f.102+0x2516>
   66bdb: 8b 58 08                     	movl	0x8(%rax), %ebx
   66bde: 48 c7 44 24 28 0a 00 00 00   	movq	$0xa, 0x28(%rsp)
   66be7: 89 df                        	movl	%ebx, %edi
   66be9: e8 32 ff fb ff               	callq	0x26b20 <snail:datum/symbol-length>
   66bee: 48 83 3d aa 7a 06 00 00      	cmpq	$0x0, 0x67aaa(%rip)     # 0xce6a0 <g.19>
   66bf6: 0f 84 ea 18 00 00            	je	0x684e6 <f.102+0x2516>
   66bfc: 49 89 c6                     	movq	%rax, %r14
   66bff: 48 39 e8                     	cmpq	%rbp, %rax
   66c02: 0f 87 de 18 00 00            	ja	0x684e6 <f.102+0x2516>
   66c08: 48 c7 44 24 28 0a 00 00 00   	movq	$0xa, 0x28(%rsp)
   66c11: 44 89 f7                     	movl	%r14d, %edi
   66c14: e8 87 20 00 00               	callq	0x68ca0 <f.23>
   66c19: 48 83 ec 08                  	subq	$0x8, %rsp
   66c1d: 48 89 84 24 80 00 00 00      	movq	%rax, 0x80(%rsp)
   66c25: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   66c2e: 89 df                        	movl	%ebx, %edi
   66c30: 4c 89 f6                     	movq	%r14, %rsi
   66c33: 48 89 c2                     	movq	%rax, %rdx
   66c36: e8 45 23 00 00               	callq	0x68f80 <f.32>
   66c3b: 48 83 ec 08                  	subq	$0x8, %rsp
   66c3f: 48 89 44 24 60               	movq	%rax, 0x60(%rsp)
   66c44: 48 85 c0                     	testq	%rax, %rax
   66c47: 0f 84 99 18 00 00            	je	0x684e6 <f.102+0x2516>
   66c4d: 83 78 10 00                  	cmpl	$0x0, 0x10(%rax)
   66c51: 0f 84 8f 18 00 00            	je	0x684e6 <f.102+0x2516>
   66c57: 48 8b 40 18                  	movq	0x18(%rax), %rax
   66c5b: 48 85 c0                     	testq	%rax, %rax
   66c5e: 0f 84 82 18 00 00            	je	0x684e6 <f.102+0x2516>
   66c64: 89 c1                        	movl	%eax, %ecx
   66c66: 83 e1 01                     	andl	$0x1, %ecx
   66c69: 0f 85 77 18 00 00            	jne	0x684e6 <f.102+0x2516>
   66c6f: 48 83 78 08 00               	cmpq	$0x0, 0x8(%rax)
   66c74: 0f 84 6c 18 00 00            	je	0x684e6 <f.102+0x2516>
   66c7a: 83 78 10 2a                  	cmpl	$0x2a, 0x10(%rax)
   66c7e: 0f 85 6b 0f 00 00            	jne	0x67bef <f.102+0x1c1f>
   66c84: 48 83 3d dc 79 06 00 00      	cmpq	$0x0, 0x679dc(%rip)     # 0xce668 <g.9>
   66c8c: 0f 84 54 18 00 00            	je	0x684e6 <f.102+0x2516>
   66c92: 48 83 3d 56 7b 06 00 00      	cmpq	$0x0, 0x67b56(%rip)     # 0xce7f0 <g.62>
   66c9a: 0f 84 46 18 00 00            	je	0x684e6 <f.102+0x2516>
   66ca0: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   66ca5: 48 85 c0                     	testq	%rax, %rax
   66ca8: 0f 84 38 18 00 00            	je	0x684e6 <f.102+0x2516>
   66cae: 48 8b 40 10                  	movq	0x10(%rax), %rax
   66cb2: 48 85 c0                     	testq	%rax, %rax
   66cb5: 0f 84 2b 18 00 00            	je	0x684e6 <f.102+0x2516>
   66cbb: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   66cbf: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
   66cc4: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   66ccc: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   66cd4: 48 c7 44 24 28 0c 00 00 00   	movq	$0xc, 0x28(%rsp)
   66cdd: e8 fe 23 00 00               	callq	0x690e0 <f.53>
   66ce2: 48 83 ec 08                  	subq	$0x8, %rsp
   66ce6: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
   66ceb: 48 83 3d 4d 7a 06 00 00      	cmpq	$0x0, 0x67a4d(%rip)     # 0xce740 <g.39>
   66cf3: 0f 84 ed 17 00 00            	je	0x684e6 <f.102+0x2516>
   66cf9: 48 83 3d 47 79 06 00 00      	cmpq	$0x0, 0x67947(%rip)     # 0xce648 <g.4>
   66d01: 0f 84 df 17 00 00            	je	0x684e6 <f.102+0x2516>
   66d07: 48 89 84 24 80 00 00 00      	movq	%rax, 0x80(%rsp)
   66d0f: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   66d18: 48 89 c7                     	movq	%rax, %rdi
   66d1b: e8 70 e2 ff ff               	callq	0x64f90 <f.45>
   66d20: 48 83 ec 08                  	subq	$0x8, %rsp
   66d24: 83 f8 01                     	cmpl	$0x1, %eax
   66d27: 75 3a                        	jne	0x66d63 <f.102+0xd93>
   66d29: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
   66d2e: 48 85 c9                     	testq	%rcx, %rcx
   66d31: 0f 84 af 17 00 00            	je	0x684e6 <f.102+0x2516>
   66d37: 83 79 08 01                  	cmpl	$0x1, 0x8(%rcx)
   66d3b: 0f 85 a5 17 00 00            	jne	0x684e6 <f.102+0x2516>
   66d41: f6 c1 01                     	testb	$0x1, %cl
   66d44: 0f 85 9c 17 00 00            	jne	0x684e6 <f.102+0x2516>
   66d4a: 48 8b 01                     	movq	(%rcx), %rax
   66d4d: 48 3d 4a 01 00 00            	cmpq	$0x14a, %rax            # imm = 0x14A
   66d53: 0f 85 3d 17 00 00            	jne	0x68496 <f.102+0x24c6>
   66d59: 83 79 10 00                  	cmpl	$0x0, 0x10(%rcx)
   66d5d: 0f 84 ed 0e 00 00            	je	0x67c50 <f.102+0x1c80>
   66d63: 48 83 3d cd 78 06 00 00      	cmpq	$0x0, 0x678cd(%rip)     # 0xce638 <g.1>
   66d6b: 0f 84 75 17 00 00            	je	0x684e6 <f.102+0x2516>
   66d71: 48 83 3d ff 7a 06 00 00      	cmpq	$0x0, 0x67aff(%rip)     # 0xce878 <g.79>
   66d79: 0f 84 67 17 00 00            	je	0x684e6 <f.102+0x2516>
   66d7f: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
   66d84: 48 85 c9                     	testq	%rcx, %rcx
   66d87: 0f 84 59 17 00 00            	je	0x684e6 <f.102+0x2516>
   66d8d: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   66d91: 0f 85 4f 17 00 00            	jne	0x684e6 <f.102+0x2516>
   66d97: f6 c1 01                     	testb	$0x1, %cl
   66d9a: 0f 85 46 17 00 00            	jne	0x684e6 <f.102+0x2516>
   66da0: 48 8b 01                     	movq	(%rcx), %rax
   66da3: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   66da9: 0f 85 59 16 00 00            	jne	0x68408 <f.102+0x2438>
   66daf: 48 8b 41 18                  	movq	0x18(%rcx), %rax
   66db3: 48 85 c0                     	testq	%rax, %rax
   66db6: 0f 84 2a 17 00 00            	je	0x684e6 <f.102+0x2516>
   66dbc: 48 8b 4c 24 48               	movq	0x48(%rsp), %rcx
   66dc1: 48 85 c9                     	testq	%rcx, %rcx
   66dc4: 0f 84 1c 17 00 00            	je	0x684e6 <f.102+0x2516>
   66dca: 48 8b 49 18                  	movq	0x18(%rcx), %rcx
   66dce: 48 85 c9                     	testq	%rcx, %rcx
   66dd1: 0f 84 0f 17 00 00            	je	0x684e6 <f.102+0x2516>
   66dd7: 48 8b 78 08                  	movq	0x8(%rax), %rdi
   66ddb: 48 8b 71 08                  	movq	0x8(%rcx), %rsi
   66ddf: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   66de7: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   66def: 48 c7 44 24 28 0c 00 00 00   	movq	$0xc, 0x28(%rsp)
   66df8: e8 33 27 00 00               	callq	0x69530 <f.52>
   66dfd: 48 83 ec 08                  	subq	$0x8, %rsp
   66e01: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
   66e06: e9 f5 f4 ff ff               	jmp	0x66300 <f.102+0x330>
   66e0b: 48 8d 43 20                  	leaq	0x20(%rbx), %rax
   66e0f: 48 89 05 92 7e 06 00         	movq	%rax, 0x67e92(%rip)     # 0xceca8 <cursor>
   66e16: 48 89 d8                     	movq	%rbx, %rax
   66e19: 48 2b 05 80 7e 06 00         	subq	0x67e80(%rip), %rax     # 0xceca0 <arena>
   66e20: 89 c1                        	movl	%eax, %ecx
   66e22: c1 e9 04                     	shrl	$0x4, %ecx
   66e25: ba 01 00 00 00               	movl	$0x1, %edx
   66e2a: 48 d3 e2                     	shlq	%cl, %rdx
   66e2d: 48 89 c1                     	movq	%rax, %rcx
   66e30: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   66e34: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   66e3b: 48 03 0d 16 7e 06 00         	addq	0x67e16(%rip), %rcx     # 0xcec58 <blocks>
   66e42: c1 e8 07                     	shrl	$0x7, %eax
   66e45: 25 f8 00 00 00               	andl	$0xf8, %eax
   66e4a: 48 09 14 08                  	orq	%rdx, (%rax,%rcx)
   66e4e: 48 c7 03 41 00 00 00         	movq	$0x41, (%rbx)
   66e55: 48 83 05 cb 7d 06 00 20      	addq	$0x20, 0x67dcb(%rip)    # 0xcec28 <since_collection>
   66e5d: 48 83 05 cb 7d 06 00 10      	addq	$0x10, 0x67dcb(%rip)    # 0xcec30 <allocated_bytes>
   66e65: 48 ff 05 cc 7d 06 00         	incq	0x67dcc(%rip)           # 0xcec38 <allocated_objects>
   66e6c: 48 c7 43 08 aa 02 00 00      	movq	$0x2aa, 0x8(%rbx)       # imm = 0x2AA
   66e74: 4c 89 73 10                  	movq	%r14, 0x10(%rbx)
   66e78: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   66e7d: 48 85 c0                     	testq	%rax, %rax
   66e80: 0f 84 60 16 00 00            	je	0x684e6 <f.102+0x2516>
   66e86: 48 8b 40 18                  	movq	0x18(%rax), %rax
   66e8a: 48 85 c0                     	testq	%rax, %rax
   66e8d: 0f 84 53 16 00 00            	je	0x684e6 <f.102+0x2516>
   66e93: 48 83 c3 08                  	addq	$0x8, %rbx
   66e97: 4c 8b 68 08                  	movq	0x8(%rax), %r13
   66e9b: 4c 89 ac 24 80 00 00 00      	movq	%r13, 0x80(%rsp)
   66ea3: 48 89 9c 24 88 00 00 00      	movq	%rbx, 0x88(%rsp)
   66eab: 48 c7 44 24 28 0c 00 00 00   	movq	$0xc, 0x28(%rsp)
   66eb4: 48 8b 0d 5d 7d 06 00         	movq	0x67d5d(%rip), %rcx     # 0xcec18 <collection_interval>
   66ebb: 48 85 c9                     	testq	%rcx, %rcx
   66ebe: 74 30                        	je	0x66ef0 <f.102+0xf20>
   66ec0: 48 8b 05 59 7d 06 00         	movq	0x67d59(%rip), %rax     # 0xcec20 <allocations>
   66ec7: 48 ff c0                     	incq	%rax
   66eca: 48 89 05 4f 7d 06 00         	movq	%rax, 0x67d4f(%rip)     # 0xcec20 <allocations>
   66ed1: 48 89 c2                     	movq	%rax, %rdx
   66ed4: 48 09 ca                     	orq	%rcx, %rdx
   66ed7: 48 c1 ea 20                  	shrq	$0x20, %rdx
   66edb: 0f 84 8a 02 00 00            	je	0x6716b <f.102+0x119b>
   66ee1: 31 d2                        	xorl	%edx, %edx
   66ee3: 48 f7 f1                     	divq	%rcx
   66ee6: 48 85 d2                     	testq	%rdx, %rdx
   66ee9: 75 05                        	jne	0x66ef0 <f.102+0xf20>
   66eeb: e8 c0 ca 05 00               	callq	0xc39b0 <native_gc_collect>
   66ef0: 48 8b 05 e9 75 06 00         	movq	0x675e9(%rip), %rax     # 0xce4e0 <heap_bytes>
   66ef7: 48 83 c0 e8                  	addq	$-0x18, %rax
   66efb: 48 83 f8 10                  	cmpq	$0x10, %rax
   66eff: 0f 82 32 11 00 00            	jb	0x68037 <f.102+0x2067>
   66f05: 48 8b 05 1c 7d 06 00         	movq	0x67d1c(%rip), %rax     # 0xcec28 <since_collection>
   66f0c: 48 3b 05 d5 75 06 00         	cmpq	0x675d5(%rip), %rax     # 0xce4e8 <budget>
   66f13: 72 05                        	jb	0x66f1a <f.102+0xf4a>
   66f15: e8 96 ca 05 00               	callq	0xc39b0 <native_gc_collect>
   66f1a: 48 8b 05 87 7d 06 00         	movq	0x67d87(%rip), %rax     # 0xceca8 <cursor>
   66f21: 48 85 c0                     	testq	%rax, %rax
   66f24: 74 10                        	je	0x66f36 <f.102+0xf66>
   66f26: 48 8b 0d 83 7d 06 00         	movq	0x67d83(%rip), %rcx     # 0xcecb0 <limit>
   66f2d: 48 29 c1                     	subq	%rax, %rcx
   66f30: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   66f34: 77 44                        	ja	0x66f7a <f.102+0xfaa>
   66f36: bf 20 00 00 00               	movl	$0x20, %edi
   66f3b: e8 80 e7 05 00               	callq	0xc56c0 <allocate_slow>
   66f40: 48 85 c0                     	testq	%rax, %rax
   66f43: 75 40                        	jne	0x66f85 <f.102+0xfb5>
   66f45: e8 66 ca 05 00               	callq	0xc39b0 <native_gc_collect>
   66f4a: 48 8b 05 57 7d 06 00         	movq	0x67d57(%rip), %rax     # 0xceca8 <cursor>
   66f51: 48 85 c0                     	testq	%rax, %rax
   66f54: 74 10                        	je	0x66f66 <f.102+0xf96>
   66f56: 48 8b 0d 53 7d 06 00         	movq	0x67d53(%rip), %rcx     # 0xcecb0 <limit>
   66f5d: 48 29 c1                     	subq	%rax, %rcx
   66f60: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   66f64: 77 14                        	ja	0x66f7a <f.102+0xfaa>
   66f66: bf 20 00 00 00               	movl	$0x20, %edi
   66f6b: e8 50 e7 05 00               	callq	0xc56c0 <allocate_slow>
   66f70: 48 85 c0                     	testq	%rax, %rax
   66f73: 75 10                        	jne	0x66f85 <f.102+0xfb5>
   66f75: e9 bd 10 00 00               	jmp	0x68037 <f.102+0x2067>
   66f7a: 48 8d 48 20                  	leaq	0x20(%rax), %rcx
   66f7e: 48 89 0d 23 7d 06 00         	movq	%rcx, 0x67d23(%rip)     # 0xceca8 <cursor>
   66f85: 48 89 c2                     	movq	%rax, %rdx
   66f88: 48 2b 15 11 7d 06 00         	subq	0x67d11(%rip), %rdx     # 0xceca0 <arena>
   66f8f: 89 d1                        	movl	%edx, %ecx
   66f91: c1 e9 04                     	shrl	$0x4, %ecx
   66f94: be 01 00 00 00               	movl	$0x1, %esi
   66f99: 48 d3 e6                     	shlq	%cl, %rsi
   66f9c: 48 89 d1                     	movq	%rdx, %rcx
   66f9f: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   66fa3: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   66faa: 48 03 0d a7 7c 06 00         	addq	0x67ca7(%rip), %rcx     # 0xcec58 <blocks>
   66fb1: c1 ea 07                     	shrl	$0x7, %edx
   66fb4: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   66fba: 48 09 34 0a                  	orq	%rsi, (%rdx,%rcx)
   66fbe: 48 c7 00 41 00 00 00         	movq	$0x41, (%rax)
   66fc5: 48 83 05 5b 7c 06 00 20      	addq	$0x20, 0x67c5b(%rip)    # 0xcec28 <since_collection>
   66fcd: 48 83 05 5b 7c 06 00 10      	addq	$0x10, 0x67c5b(%rip)    # 0xcec30 <allocated_bytes>
   66fd5: 48 ff 05 5c 7c 06 00         	incq	0x67c5c(%rip)           # 0xcec38 <allocated_objects>
   66fdc: 4c 8d 70 08                  	leaq	0x8(%rax), %r14
   66fe0: 48 c7 40 08 aa 02 00 00      	movq	$0x2aa, 0x8(%rax)       # imm = 0x2AA
   66fe8: 4c 89 68 10                  	movq	%r13, 0x10(%rax)
   66fec: 4c 89 b4 24 80 00 00 00      	movq	%r14, 0x80(%rsp)
   66ff4: 48 89 9c 24 88 00 00 00      	movq	%rbx, 0x88(%rsp)
   66ffc: 48 c7 44 24 28 0c 00 00 00   	movq	$0xc, 0x28(%rsp)
   67005: 48 8b 0d 0c 7c 06 00         	movq	0x67c0c(%rip), %rcx     # 0xcec18 <collection_interval>
   6700c: 48 85 c9                     	testq	%rcx, %rcx
   6700f: 74 30                        	je	0x67041 <f.102+0x1071>
   67011: 48 8b 05 08 7c 06 00         	movq	0x67c08(%rip), %rax     # 0xcec20 <allocations>
   67018: 48 ff c0                     	incq	%rax
   6701b: 48 89 05 fe 7b 06 00         	movq	%rax, 0x67bfe(%rip)     # 0xcec20 <allocations>
   67022: 48 89 c2                     	movq	%rax, %rdx
   67025: 48 09 ca                     	orq	%rcx, %rdx
   67028: 48 c1 ea 20                  	shrq	$0x20, %rdx
   6702c: 0f 84 4b 01 00 00            	je	0x6717d <f.102+0x11ad>
   67032: 31 d2                        	xorl	%edx, %edx
   67034: 48 f7 f1                     	divq	%rcx
   67037: 48 85 d2                     	testq	%rdx, %rdx
   6703a: 75 05                        	jne	0x67041 <f.102+0x1071>
   6703c: e8 6f c9 05 00               	callq	0xc39b0 <native_gc_collect>
   67041: 48 8b 05 98 74 06 00         	movq	0x67498(%rip), %rax     # 0xce4e0 <heap_bytes>
   67048: 48 83 c0 e8                  	addq	$-0x18, %rax
   6704c: 48 83 f8 20                  	cmpq	$0x20, %rax
   67050: 0f 82 e1 0f 00 00            	jb	0x68037 <f.102+0x2067>
   67056: 48 8b 05 cb 7b 06 00         	movq	0x67bcb(%rip), %rax     # 0xcec28 <since_collection>
   6705d: 48 3b 05 84 74 06 00         	cmpq	0x67484(%rip), %rax     # 0xce4e8 <budget>
   67064: 72 05                        	jb	0x6706b <f.102+0x109b>
   67066: e8 45 c9 05 00               	callq	0xc39b0 <native_gc_collect>
   6706b: 48 8b 05 36 7c 06 00         	movq	0x67c36(%rip), %rax     # 0xceca8 <cursor>
   67072: 48 85 c0                     	testq	%rax, %rax
   67075: 74 10                        	je	0x67087 <f.102+0x10b7>
   67077: 48 8b 0d 32 7c 06 00         	movq	0x67c32(%rip), %rcx     # 0xcecb0 <limit>
   6707e: 48 29 c1                     	subq	%rax, %rcx
   67081: 48 83 f9 2f                  	cmpq	$0x2f, %rcx
   67085: 77 44                        	ja	0x670cb <f.102+0x10fb>
   67087: bf 30 00 00 00               	movl	$0x30, %edi
   6708c: e8 2f e6 05 00               	callq	0xc56c0 <allocate_slow>
   67091: 48 85 c0                     	testq	%rax, %rax
   67094: 75 40                        	jne	0x670d6 <f.102+0x1106>
   67096: e8 15 c9 05 00               	callq	0xc39b0 <native_gc_collect>
   6709b: 48 8b 05 06 7c 06 00         	movq	0x67c06(%rip), %rax     # 0xceca8 <cursor>
   670a2: 48 85 c0                     	testq	%rax, %rax
   670a5: 74 10                        	je	0x670b7 <f.102+0x10e7>
   670a7: 48 8b 0d 02 7c 06 00         	movq	0x67c02(%rip), %rcx     # 0xcecb0 <limit>
   670ae: 48 29 c1                     	subq	%rax, %rcx
   670b1: 48 83 f9 2f                  	cmpq	$0x2f, %rcx
   670b5: 77 14                        	ja	0x670cb <f.102+0x10fb>
   670b7: bf 30 00 00 00               	movl	$0x30, %edi
   670bc: e8 ff e5 05 00               	callq	0xc56c0 <allocate_slow>
   670c1: 48 85 c0                     	testq	%rax, %rax
   670c4: 75 10                        	jne	0x670d6 <f.102+0x1106>
   670c6: e9 6c 0f 00 00               	jmp	0x68037 <f.102+0x2067>
   670cb: 48 8d 48 30                  	leaq	0x30(%rax), %rcx
   670cf: 48 89 0d d2 7b 06 00         	movq	%rcx, 0x67bd2(%rip)     # 0xceca8 <cursor>
   670d6: 48 89 c2                     	movq	%rax, %rdx
   670d9: 48 2b 15 c0 7b 06 00         	subq	0x67bc0(%rip), %rdx     # 0xceca0 <arena>
   670e0: 89 d1                        	movl	%edx, %ecx
   670e2: c1 e9 04                     	shrl	$0x4, %ecx
   670e5: be 01 00 00 00               	movl	$0x1, %esi
   670ea: 48 d3 e6                     	shlq	%cl, %rsi
   670ed: 48 89 d1                     	movq	%rdx, %rcx
   670f0: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   670f4: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   670fb: 48 03 0d 56 7b 06 00         	addq	0x67b56(%rip), %rcx     # 0xcec58 <blocks>
   67102: c1 ea 07                     	shrl	$0x7, %edx
   67105: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   6710b: 48 09 34 0a                  	orq	%rsi, (%rdx,%rcx)
   6710f: 48 c7 00 81 00 00 00         	movq	$0x81, (%rax)
   67116: c7 40 14 00 00 00 00         	movl	$0x0, 0x14(%rax)
   6711d: 48 83 05 03 7b 06 00 30      	addq	$0x30, 0x67b03(%rip)    # 0xcec28 <since_collection>
   67125: 48 8d 48 08                  	leaq	0x8(%rax), %rcx
   67129: 48 83 05 ff 7a 06 00 20      	addq	$0x20, 0x67aff(%rip)    # 0xcec30 <allocated_bytes>
   67131: 48 ff 05 00 7b 06 00         	incq	0x67b00(%rip)           # 0xcec38 <allocated_objects>
   67138: 48 c7 40 08 5a 01 00 00      	movq	$0x15a, 0x8(%rax)       # imm = 0x15A
   67140: c7 40 10 06 00 00 00         	movl	$0x6, 0x10(%rax)
   67147: 48 89 58 18                  	movq	%rbx, 0x18(%rax)
   6714b: 4c 89 70 20                  	movq	%r14, 0x20(%rax)
   6714f: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
   67154: e9 a7 f1 ff ff               	jmp	0x66300 <f.102+0x330>
   67159: 31 d2                        	xorl	%edx, %edx
   6715b: f7 f1                        	divl	%ecx
   6715d: 48 85 d2                     	testq	%rdx, %rdx
   67160: 0f 85 00 f8 ff ff            	jne	0x66966 <f.102+0x996>
   67166: e9 f6 f7 ff ff               	jmp	0x66961 <f.102+0x991>
   6716b: 31 d2                        	xorl	%edx, %edx
   6716d: f7 f1                        	divl	%ecx
   6716f: 48 85 d2                     	testq	%rdx, %rdx
   67172: 0f 85 78 fd ff ff            	jne	0x66ef0 <f.102+0xf20>
   67178: e9 6e fd ff ff               	jmp	0x66eeb <f.102+0xf1b>
   6717d: 31 d2                        	xorl	%edx, %edx
   6717f: f7 f1                        	divl	%ecx
   67181: 48 85 d2                     	testq	%rdx, %rdx
   67184: 0f 85 b7 fe ff ff            	jne	0x67041 <f.102+0x1071>
   6718a: e9 ad fe ff ff               	jmp	0x6703c <f.102+0x106c>
   6718f: 48 83 3d a1 74 06 00 00      	cmpq	$0x0, 0x674a1(%rip)     # 0xce638 <g.1>
   67197: 0f 84 49 13 00 00            	je	0x684e6 <f.102+0x2516>
   6719d: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
   671a2: 48 85 c9                     	testq	%rcx, %rcx
   671a5: 0f 84 3b 13 00 00            	je	0x684e6 <f.102+0x2516>
   671ab: 83 79 08 06                  	cmpl	$0x6, 0x8(%rcx)
   671af: 0f 85 31 13 00 00            	jne	0x684e6 <f.102+0x2516>
   671b5: f6 c1 01                     	testb	$0x1, %cl
   671b8: 0f 85 28 13 00 00            	jne	0x684e6 <f.102+0x2516>
   671be: 48 8b 01                     	movq	(%rcx), %rax
   671c1: 48 3d 5a 01 00 00            	cmpq	$0x15a, %rax            # imm = 0x15A
   671c7: 0f 85 f2 12 00 00            	jne	0x684bf <f.102+0x24ef>
   671cd: 48 89 4c 24 50               	movq	%rcx, 0x50(%rsp)
   671d2: 48 8b 41 18                  	movq	0x18(%rcx), %rax
   671d6: 48 85 c0                     	testq	%rax, %rax
   671d9: 0f 84 07 13 00 00            	je	0x684e6 <f.102+0x2516>
   671df: 48 8b 70 08                  	movq	0x8(%rax), %rsi
   671e3: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
   671e8: 48 83 3d 78 74 06 00 00      	cmpq	$0x0, 0x67478(%rip)     # 0xce668 <g.9>
   671f0: 0f 84 f0 12 00 00            	je	0x684e6 <f.102+0x2516>
   671f6: 48 83 3d 32 74 06 00 00      	cmpq	$0x0, 0x67432(%rip)     # 0xce630 <g.0>
   671fe: 0f 84 e2 12 00 00            	je	0x684e6 <f.102+0x2516>
   67204: 80 3d 5d 75 06 00 00         	cmpb	$0x0, 0x6755d(%rip)     # 0xce768 <g.44>
   6720b: 0f 84 d5 12 00 00            	je	0x684e6 <f.102+0x2516>
   67211: 48 83 3d 1f 75 06 00 00      	cmpq	$0x0, 0x6751f(%rip)     # 0xce738 <g.38>
   67219: 0f 84 c7 12 00 00            	je	0x684e6 <f.102+0x2516>
   6721f: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
   67224: 48 85 c0                     	testq	%rax, %rax
   67227: 0f 84 b9 12 00 00            	je	0x684e6 <f.102+0x2516>
   6722d: 48 8b 48 18                  	movq	0x18(%rax), %rcx
   67231: 48 85 c9                     	testq	%rcx, %rcx
   67234: 0f 84 ac 12 00 00            	je	0x684e6 <f.102+0x2516>
   6723a: 48 8b 40 10                  	movq	0x10(%rax), %rax
   6723e: 48 85 c0                     	testq	%rax, %rax
   67241: 0f 84 9f 12 00 00            	je	0x684e6 <f.102+0x2516>
   67247: 48 8b 79 08                  	movq	0x8(%rcx), %rdi
   6724b: 4c 8b 70 08                  	movq	0x8(%rax), %r14
   6724f: 4c 89 b4 24 80 00 00 00      	movq	%r14, 0x80(%rsp)
   67257: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
   6725f: 48 89 bc 24 90 00 00 00      	movq	%rdi, 0x90(%rsp)
   67267: 48 c7 44 24 28 0d 00 00 00   	movq	$0xd, 0x28(%rsp)
   67270: 48 8b 0d a1 79 06 00         	movq	0x679a1(%rip), %rcx     # 0xcec18 <collection_interval>
   67277: 48 85 c9                     	testq	%rcx, %rcx
   6727a: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
   6727f: 48 89 fd                     	movq	%rdi, %rbp
   67282: 74 3a                        	je	0x672be <f.102+0x12ee>
   67284: 48 8b 05 95 79 06 00         	movq	0x67995(%rip), %rax     # 0xcec20 <allocations>
   6728b: 48 ff c0                     	incq	%rax
   6728e: 48 89 05 8b 79 06 00         	movq	%rax, 0x6798b(%rip)     # 0xcec20 <allocations>
   67295: 48 89 c2                     	movq	%rax, %rdx
   67298: 48 09 ca                     	orq	%rcx, %rdx
   6729b: 48 c1 ea 20                  	shrq	$0x20, %rdx
   6729f: 74 07                        	je	0x672a8 <f.102+0x12d8>
   672a1: 31 d2                        	xorl	%edx, %edx
   672a3: 48 f7 f1                     	divq	%rcx
   672a6: eb 04                        	jmp	0x672ac <f.102+0x12dc>
   672a8: 31 d2                        	xorl	%edx, %edx
   672aa: f7 f1                        	divl	%ecx
   672ac: 48 85 d2                     	testq	%rdx, %rdx
   672af: 75 0d                        	jne	0x672be <f.102+0x12ee>
   672b1: e8 fa c6 05 00               	callq	0xc39b0 <native_gc_collect>
   672b6: 48 89 ef                     	movq	%rbp, %rdi
   672b9: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   672be: 48 8b 05 1b 72 06 00         	movq	0x6721b(%rip), %rax     # 0xce4e0 <heap_bytes>
   672c5: 48 83 c0 e8                  	addq	$-0x18, %rax
   672c9: 48 83 f8 10                  	cmpq	$0x10, %rax
   672cd: 0f 82 64 0d 00 00            	jb	0x68037 <f.102+0x2067>
   672d3: 48 8b 05 4e 79 06 00         	movq	0x6794e(%rip), %rax     # 0xcec28 <since_collection>
   672da: 48 3b 05 07 72 06 00         	cmpq	0x67207(%rip), %rax     # 0xce4e8 <budget>
   672e1: 72 0d                        	jb	0x672f0 <f.102+0x1320>
   672e3: e8 c8 c6 05 00               	callq	0xc39b0 <native_gc_collect>
   672e8: 48 89 ef                     	movq	%rbp, %rdi
   672eb: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   672f0: 48 8b 1d b1 79 06 00         	movq	0x679b1(%rip), %rbx     # 0xceca8 <cursor>
   672f7: 48 85 db                     	testq	%rbx, %rbx
   672fa: 74 10                        	je	0x6730c <f.102+0x133c>
   672fc: 48 8b 05 ad 79 06 00         	movq	0x679ad(%rip), %rax     # 0xcecb0 <limit>
   67303: 48 29 d8                     	subq	%rbx, %rax
   67306: 48 83 f8 1f                  	cmpq	$0x1f, %rax
   6730a: 77 65                        	ja	0x67371 <f.102+0x13a1>
   6730c: bf 20 00 00 00               	movl	$0x20, %edi
   67311: e8 aa e3 05 00               	callq	0xc56c0 <allocate_slow>
   67316: 48 85 c0                     	testq	%rax, %rax
   67319: 74 0d                        	je	0x67328 <f.102+0x1358>
   6731b: 48 89 c3                     	movq	%rax, %rbx
   6731e: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   67323: 48 89 ef                     	movq	%rbp, %rdi
   67326: eb 54                        	jmp	0x6737c <f.102+0x13ac>
   67328: e8 83 c6 05 00               	callq	0xc39b0 <native_gc_collect>
   6732d: 48 8b 1d 74 79 06 00         	movq	0x67974(%rip), %rbx     # 0xceca8 <cursor>
   67334: 48 85 db                     	testq	%rbx, %rbx
   67337: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   6733c: 74 13                        	je	0x67351 <f.102+0x1381>
   6733e: 48 89 ef                     	movq	%rbp, %rdi
   67341: 48 8b 05 68 79 06 00         	movq	0x67968(%rip), %rax     # 0xcecb0 <limit>
   67348: 48 29 d8                     	subq	%rbx, %rax
   6734b: 48 83 f8 1f                  	cmpq	$0x1f, %rax
   6734f: 77 20                        	ja	0x67371 <f.102+0x13a1>
   67351: bf 20 00 00 00               	movl	$0x20, %edi
   67356: e8 65 e3 05 00               	callq	0xc56c0 <allocate_slow>
   6735b: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   67360: 48 85 c0                     	testq	%rax, %rax
   67363: 0f 84 ce 0c 00 00            	je	0x68037 <f.102+0x2067>
   67369: 48 89 ef                     	movq	%rbp, %rdi
   6736c: 48 89 c3                     	movq	%rax, %rbx
   6736f: eb 0b                        	jmp	0x6737c <f.102+0x13ac>
   67371: 48 8d 43 20                  	leaq	0x20(%rbx), %rax
   67375: 48 89 05 2c 79 06 00         	movq	%rax, 0x6792c(%rip)     # 0xceca8 <cursor>
   6737c: 48 89 d8                     	movq	%rbx, %rax
   6737f: 48 2b 05 1a 79 06 00         	subq	0x6791a(%rip), %rax     # 0xceca0 <arena>
   67386: 89 c1                        	movl	%eax, %ecx
   67388: c1 e9 04                     	shrl	$0x4, %ecx
   6738b: ba 01 00 00 00               	movl	$0x1, %edx
   67390: 48 d3 e2                     	shlq	%cl, %rdx
   67393: 48 89 c1                     	movq	%rax, %rcx
   67396: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   6739a: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   673a1: 48 03 0d b0 78 06 00         	addq	0x678b0(%rip), %rcx     # 0xcec58 <blocks>
   673a8: c1 e8 07                     	shrl	$0x7, %eax
   673ab: 25 f8 00 00 00               	andl	$0xf8, %eax
   673b0: 48 09 14 08                  	orq	%rdx, (%rax,%rcx)
   673b4: 48 c7 03 41 00 00 00         	movq	$0x41, (%rbx)
   673bb: 48 83 05 65 78 06 00 20      	addq	$0x20, 0x67865(%rip)    # 0xcec28 <since_collection>
   673c3: 48 83 05 65 78 06 00 10      	addq	$0x10, 0x67865(%rip)    # 0xcec30 <allocated_bytes>
   673cb: 48 ff 05 66 78 06 00         	incq	0x67866(%rip)           # 0xcec38 <allocated_objects>
   673d2: 48 c7 43 08 aa 02 00 00      	movq	$0x2aa, 0x8(%rbx)       # imm = 0x2AA
   673da: 4c 89 73 10                  	movq	%r14, 0x10(%rbx)
   673de: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
   673e3: 48 85 c0                     	testq	%rax, %rax
   673e6: 0f 84 fa 10 00 00            	je	0x684e6 <f.102+0x2516>
   673ec: 48 8b 40 10                  	movq	0x10(%rax), %rax
   673f0: 48 85 c0                     	testq	%rax, %rax
   673f3: 0f 84 ed 10 00 00            	je	0x684e6 <f.102+0x2516>
   673f9: 48 83 c3 08                  	addq	$0x8, %rbx
   673fd: 4c 8b 70 08                  	movq	0x8(%rax), %r14
   67401: 4c 89 b4 24 80 00 00 00      	movq	%r14, 0x80(%rsp)
   67409: 48 89 9c 24 88 00 00 00      	movq	%rbx, 0x88(%rsp)
   67411: 48 89 b4 24 90 00 00 00      	movq	%rsi, 0x90(%rsp)
   67419: 48 89 bc 24 98 00 00 00      	movq	%rdi, 0x98(%rsp)
   67421: 48 c7 44 24 28 0e 00 00 00   	movq	$0xe, 0x28(%rsp)
   6742a: 48 8b 0d e7 77 06 00         	movq	0x677e7(%rip), %rcx     # 0xcec18 <collection_interval>
   67431: 48 85 c9                     	testq	%rcx, %rcx
   67434: 74 32                        	je	0x67468 <f.102+0x1498>
   67436: 48 8b 05 e3 77 06 00         	movq	0x677e3(%rip), %rax     # 0xcec20 <allocations>
   6743d: 48 ff c0                     	incq	%rax
   67440: 48 89 05 d9 77 06 00         	movq	%rax, 0x677d9(%rip)     # 0xcec20 <allocations>
   67447: 48 89 c2                     	movq	%rax, %rdx
   6744a: 48 09 ca                     	orq	%rcx, %rdx
   6744d: 48 c1 ea 20                  	shrq	$0x20, %rdx
   67451: 74 07                        	je	0x6745a <f.102+0x148a>
   67453: 31 d2                        	xorl	%edx, %edx
   67455: 48 f7 f1                     	divq	%rcx
   67458: eb 04                        	jmp	0x6745e <f.102+0x148e>
   6745a: 31 d2                        	xorl	%edx, %edx
   6745c: f7 f1                        	divl	%ecx
   6745e: 48 85 d2                     	testq	%rdx, %rdx
   67461: 75 05                        	jne	0x67468 <f.102+0x1498>
   67463: e8 48 c5 05 00               	callq	0xc39b0 <native_gc_collect>
   67468: 48 8b 05 71 70 06 00         	movq	0x67071(%rip), %rax     # 0xce4e0 <heap_bytes>
   6746f: 48 83 c0 e8                  	addq	$-0x18, %rax
   67473: 48 83 f8 10                  	cmpq	$0x10, %rax
   67477: 0f 82 ba 0b 00 00            	jb	0x68037 <f.102+0x2067>
   6747d: 48 8b 05 a4 77 06 00         	movq	0x677a4(%rip), %rax     # 0xcec28 <since_collection>
   67484: 48 3b 05 5d 70 06 00         	cmpq	0x6705d(%rip), %rax     # 0xce4e8 <budget>
   6748b: 72 05                        	jb	0x67492 <f.102+0x14c2>
   6748d: e8 1e c5 05 00               	callq	0xc39b0 <native_gc_collect>
   67492: 48 8b 05 0f 78 06 00         	movq	0x6780f(%rip), %rax     # 0xceca8 <cursor>
   67499: 48 85 c0                     	testq	%rax, %rax
   6749c: 74 10                        	je	0x674ae <f.102+0x14de>
   6749e: 48 8b 0d 0b 78 06 00         	movq	0x6780b(%rip), %rcx     # 0xcecb0 <limit>
   674a5: 48 29 c1                     	subq	%rax, %rcx
   674a8: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   674ac: 77 49                        	ja	0x674f7 <f.102+0x1527>
   674ae: bf 20 00 00 00               	movl	$0x20, %edi
   674b3: e8 08 e2 05 00               	callq	0xc56c0 <allocate_slow>
   674b8: 48 85 c0                     	testq	%rax, %rax
   674bb: 75 45                        	jne	0x67502 <f.102+0x1532>
   674bd: e8 ee c4 05 00               	callq	0xc39b0 <native_gc_collect>
   674c2: 48 8b 05 df 77 06 00         	movq	0x677df(%rip), %rax     # 0xceca8 <cursor>
   674c9: 48 85 c0                     	testq	%rax, %rax
   674cc: 74 10                        	je	0x674de <f.102+0x150e>
   674ce: 48 8b 0d db 77 06 00         	movq	0x677db(%rip), %rcx     # 0xcecb0 <limit>
   674d5: 48 29 c1                     	subq	%rax, %rcx
   674d8: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   674dc: 77 19                        	ja	0x674f7 <f.102+0x1527>
   674de: bf 20 00 00 00               	movl	$0x20, %edi
   674e3: e8 d8 e1 05 00               	callq	0xc56c0 <allocate_slow>
   674e8: 48 85 c0                     	testq	%rax, %rax
   674eb: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
   674f0: 75 15                        	jne	0x67507 <f.102+0x1537>
   674f2: e9 40 0b 00 00               	jmp	0x68037 <f.102+0x2067>
   674f7: 48 8d 48 20                  	leaq	0x20(%rax), %rcx
   674fb: 48 89 0d a6 77 06 00         	movq	%rcx, 0x677a6(%rip)     # 0xceca8 <cursor>
   67502: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
   67507: 48 89 ee                     	movq	%rbp, %rsi
   6750a: 48 89 c2                     	movq	%rax, %rdx
   6750d: 48 2b 15 8c 77 06 00         	subq	0x6778c(%rip), %rdx     # 0xceca0 <arena>
   67514: 89 d1                        	movl	%edx, %ecx
   67516: c1 e9 04                     	shrl	$0x4, %ecx
   67519: 41 b8 01 00 00 00            	movl	$0x1, %r8d
   6751f: 49 d3 e0                     	shlq	%cl, %r8
   67522: 48 89 d1                     	movq	%rdx, %rcx
   67525: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   67529: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   67530: 48 03 0d 21 77 06 00         	addq	0x67721(%rip), %rcx     # 0xcec58 <blocks>
   67537: c1 ea 07                     	shrl	$0x7, %edx
   6753a: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   67540: 4c 09 04 0a                  	orq	%r8, (%rdx,%rcx)
   67544: 48 c7 00 41 00 00 00         	movq	$0x41, (%rax)
   6754b: 48 83 05 d5 76 06 00 20      	addq	$0x20, 0x676d5(%rip)    # 0xcec28 <since_collection>
   67553: 4c 8d 68 08                  	leaq	0x8(%rax), %r13
   67557: 48 83 05 d1 76 06 00 10      	addq	$0x10, 0x676d1(%rip)    # 0xcec30 <allocated_bytes>
   6755f: 48 ff 05 d2 76 06 00         	incq	0x676d2(%rip)           # 0xcec38 <allocated_objects>
   67566: 48 c7 40 08 aa 02 00 00      	movq	$0x2aa, 0x8(%rax)       # imm = 0x2AA
   6756e: 4c 89 70 10                  	movq	%r14, 0x10(%rax)
   67572: 4c 89 ac 24 80 00 00 00      	movq	%r13, 0x80(%rsp)
   6757a: 48 89 9c 24 88 00 00 00      	movq	%rbx, 0x88(%rsp)
   67582: 48 89 bc 24 90 00 00 00      	movq	%rdi, 0x90(%rsp)
   6758a: 48 89 ac 24 98 00 00 00      	movq	%rbp, 0x98(%rsp)
   67592: 48 c7 44 24 28 0e 00 00 00   	movq	$0xe, 0x28(%rsp)
   6759b: 48 8b 0d 76 76 06 00         	movq	0x67676(%rip), %rcx     # 0xcec18 <collection_interval>
   675a2: 48 85 c9                     	testq	%rcx, %rcx
   675a5: 74 3a                        	je	0x675e1 <f.102+0x1611>
   675a7: 48 8b 05 72 76 06 00         	movq	0x67672(%rip), %rax     # 0xcec20 <allocations>
   675ae: 48 ff c0                     	incq	%rax
   675b1: 48 89 05 68 76 06 00         	movq	%rax, 0x67668(%rip)     # 0xcec20 <allocations>
   675b8: 48 89 c2                     	movq	%rax, %rdx
   675bb: 48 09 ca                     	orq	%rcx, %rdx
   675be: 48 c1 ea 20                  	shrq	$0x20, %rdx
   675c2: 74 07                        	je	0x675cb <f.102+0x15fb>
   675c4: 31 d2                        	xorl	%edx, %edx
   675c6: 48 f7 f1                     	divq	%rcx
   675c9: eb 04                        	jmp	0x675cf <f.102+0x15ff>
   675cb: 31 d2                        	xorl	%edx, %edx
   675cd: f7 f1                        	divl	%ecx
   675cf: 48 85 d2                     	testq	%rdx, %rdx
   675d2: 75 0d                        	jne	0x675e1 <f.102+0x1611>
   675d4: e8 d7 c3 05 00               	callq	0xc39b0 <native_gc_collect>
   675d9: 48 89 ee                     	movq	%rbp, %rsi
   675dc: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
   675e1: 48 8b 05 f8 6e 06 00         	movq	0x66ef8(%rip), %rax     # 0xce4e0 <heap_bytes>
   675e8: 48 83 c0 e8                  	addq	$-0x18, %rax
   675ec: 48 83 f8 20                  	cmpq	$0x20, %rax
   675f0: 0f 82 41 0a 00 00            	jb	0x68037 <f.102+0x2067>
   675f6: 48 8b 05 2b 76 06 00         	movq	0x6762b(%rip), %rax     # 0xcec28 <since_collection>
   675fd: 48 3b 05 e4 6e 06 00         	cmpq	0x66ee4(%rip), %rax     # 0xce4e8 <budget>
   67604: 72 0d                        	jb	0x67613 <f.102+0x1643>
   67606: e8 a5 c3 05 00               	callq	0xc39b0 <native_gc_collect>
   6760b: 48 89 ee                     	movq	%rbp, %rsi
   6760e: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
   67613: 48 8b 05 8e 76 06 00         	movq	0x6768e(%rip), %rax     # 0xceca8 <cursor>
   6761a: 48 85 c0                     	testq	%rax, %rax
   6761d: 74 10                        	je	0x6762f <f.102+0x165f>
   6761f: 48 8b 0d 8a 76 06 00         	movq	0x6768a(%rip), %rcx     # 0xcecb0 <limit>
   67626: 48 29 c1                     	subq	%rax, %rcx
   67629: 48 83 f9 2f                  	cmpq	$0x2f, %rcx
   6762d: 77 5f                        	ja	0x6768e <f.102+0x16be>
   6762f: bf 30 00 00 00               	movl	$0x30, %edi
   67634: e8 87 e0 05 00               	callq	0xc56c0 <allocate_slow>
   67639: 48 85 c0                     	testq	%rax, %rax
   6763c: 74 0a                        	je	0x67648 <f.102+0x1678>
   6763e: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
   67643: 48 89 ee                     	movq	%rbp, %rsi
   67646: eb 51                        	jmp	0x67699 <f.102+0x16c9>
   67648: e8 63 c3 05 00               	callq	0xc39b0 <native_gc_collect>
   6764d: 48 8b 05 54 76 06 00         	movq	0x67654(%rip), %rax     # 0xceca8 <cursor>
   67654: 48 85 c0                     	testq	%rax, %rax
   67657: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
   6765c: 74 13                        	je	0x67671 <f.102+0x16a1>
   6765e: 48 89 ee                     	movq	%rbp, %rsi
   67661: 48 8b 0d 48 76 06 00         	movq	0x67648(%rip), %rcx     # 0xcecb0 <limit>
   67668: 48 29 c1                     	subq	%rax, %rcx
   6766b: 48 83 f9 2f                  	cmpq	$0x2f, %rcx
   6766f: 77 1d                        	ja	0x6768e <f.102+0x16be>
   67671: bf 30 00 00 00               	movl	$0x30, %edi
   67676: e8 45 e0 05 00               	callq	0xc56c0 <allocate_slow>
   6767b: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
   67680: 48 85 c0                     	testq	%rax, %rax
   67683: 0f 84 ae 09 00 00            	je	0x68037 <f.102+0x2067>
   67689: 48 89 ee                     	movq	%rbp, %rsi
   6768c: eb 0b                        	jmp	0x67699 <f.102+0x16c9>
   6768e: 48 8d 48 30                  	leaq	0x30(%rax), %rcx
   67692: 48 89 0d 0f 76 06 00         	movq	%rcx, 0x6760f(%rip)     # 0xceca8 <cursor>
   67699: 48 89 c2                     	movq	%rax, %rdx
   6769c: 48 2b 15 fd 75 06 00         	subq	0x675fd(%rip), %rdx     # 0xceca0 <arena>
   676a3: 89 d1                        	movl	%edx, %ecx
   676a5: c1 e9 04                     	shrl	$0x4, %ecx
   676a8: 41 b8 01 00 00 00            	movl	$0x1, %r8d
   676ae: 49 d3 e0                     	shlq	%cl, %r8
   676b1: 48 89 d1                     	movq	%rdx, %rcx
   676b4: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   676b8: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   676bf: 48 03 0d 92 75 06 00         	addq	0x67592(%rip), %rcx     # 0xcec58 <blocks>
   676c6: c1 ea 07                     	shrl	$0x7, %edx
   676c9: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   676cf: 4c 09 04 0a                  	orq	%r8, (%rdx,%rcx)
   676d3: 48 c7 00 81 00 00 00         	movq	$0x81, (%rax)
   676da: c7 40 14 00 00 00 00         	movl	$0x0, 0x14(%rax)
   676e1: 48 83 05 3f 75 06 00 30      	addq	$0x30, 0x6753f(%rip)    # 0xcec28 <since_collection>
   676e9: 48 83 05 3f 75 06 00 20      	addq	$0x20, 0x6753f(%rip)    # 0xcec30 <allocated_bytes>
   676f1: 48 ff 05 40 75 06 00         	incq	0x67540(%rip)           # 0xcec38 <allocated_objects>
   676f8: 4c 8d 70 08                  	leaq	0x8(%rax), %r14
   676fc: 48 c7 40 08 5a 01 00 00      	movq	$0x15a, 0x8(%rax)       # imm = 0x15A
   67704: c7 40 10 06 00 00 00         	movl	$0x6, 0x10(%rax)
   6770b: 48 89 58 18                  	movq	%rbx, 0x18(%rax)
   6770f: 4c 89 68 20                  	movq	%r13, 0x20(%rax)
   67713: 4c 89 b4 24 80 00 00 00      	movq	%r14, 0x80(%rsp)
   6771b: 48 89 bc 24 88 00 00 00      	movq	%rdi, 0x88(%rsp)
   67723: 48 89 b4 24 90 00 00 00      	movq	%rsi, 0x90(%rsp)
   6772b: 48 c7 44 24 28 0d 00 00 00   	movq	$0xd, 0x28(%rsp)
   67734: 48 8b 0d dd 74 06 00         	movq	0x674dd(%rip), %rcx     # 0xcec18 <collection_interval>
   6773b: 48 85 c9                     	testq	%rcx, %rcx
   6773e: 74 32                        	je	0x67772 <f.102+0x17a2>
   67740: 48 8b 05 d9 74 06 00         	movq	0x674d9(%rip), %rax     # 0xcec20 <allocations>
   67747: 48 ff c0                     	incq	%rax
   6774a: 48 89 05 cf 74 06 00         	movq	%rax, 0x674cf(%rip)     # 0xcec20 <allocations>
   67751: 48 89 c2                     	movq	%rax, %rdx
   67754: 48 09 ca                     	orq	%rcx, %rdx
   67757: 48 c1 ea 20                  	shrq	$0x20, %rdx
   6775b: 74 07                        	je	0x67764 <f.102+0x1794>
   6775d: 31 d2                        	xorl	%edx, %edx
   6775f: 48 f7 f1                     	divq	%rcx
   67762: eb 04                        	jmp	0x67768 <f.102+0x1798>
   67764: 31 d2                        	xorl	%edx, %edx
   67766: f7 f1                        	divl	%ecx
   67768: 48 85 d2                     	testq	%rdx, %rdx
   6776b: 75 05                        	jne	0x67772 <f.102+0x17a2>
   6776d: e8 3e c2 05 00               	callq	0xc39b0 <native_gc_collect>
   67772: 48 8b 05 67 6d 06 00         	movq	0x66d67(%rip), %rax     # 0xce4e0 <heap_bytes>
   67779: 48 83 c0 e8                  	addq	$-0x18, %rax
   6777d: 48 83 f8 10                  	cmpq	$0x10, %rax
   67781: 0f 82 b0 08 00 00            	jb	0x68037 <f.102+0x2067>
   67787: 48 8b 05 9a 74 06 00         	movq	0x6749a(%rip), %rax     # 0xcec28 <since_collection>
   6778e: 48 3b 05 53 6d 06 00         	cmpq	0x66d53(%rip), %rax     # 0xce4e8 <budget>
   67795: 72 05                        	jb	0x6779c <f.102+0x17cc>
   67797: e8 14 c2 05 00               	callq	0xc39b0 <native_gc_collect>
   6779c: 48 8b 05 05 75 06 00         	movq	0x67505(%rip), %rax     # 0xceca8 <cursor>
   677a3: 48 85 c0                     	testq	%rax, %rax
   677a6: 74 10                        	je	0x677b8 <f.102+0x17e8>
   677a8: 48 8b 0d 01 75 06 00         	movq	0x67501(%rip), %rcx     # 0xcecb0 <limit>
   677af: 48 29 c1                     	subq	%rax, %rcx
   677b2: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   677b6: 77 49                        	ja	0x67801 <f.102+0x1831>
   677b8: bf 20 00 00 00               	movl	$0x20, %edi
   677bd: e8 fe de 05 00               	callq	0xc56c0 <allocate_slow>
   677c2: 48 85 c0                     	testq	%rax, %rax
   677c5: 75 45                        	jne	0x6780c <f.102+0x183c>
   677c7: e8 e4 c1 05 00               	callq	0xc39b0 <native_gc_collect>
   677cc: 48 8b 05 d5 74 06 00         	movq	0x674d5(%rip), %rax     # 0xceca8 <cursor>
   677d3: 48 85 c0                     	testq	%rax, %rax
   677d6: 74 10                        	je	0x677e8 <f.102+0x1818>
   677d8: 48 8b 0d d1 74 06 00         	movq	0x674d1(%rip), %rcx     # 0xcecb0 <limit>
   677df: 48 29 c1                     	subq	%rax, %rcx
   677e2: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   677e6: 77 19                        	ja	0x67801 <f.102+0x1831>
   677e8: bf 20 00 00 00               	movl	$0x20, %edi
   677ed: e8 ce de 05 00               	callq	0xc56c0 <allocate_slow>
   677f2: 48 85 c0                     	testq	%rax, %rax
   677f5: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   677fa: 75 15                        	jne	0x67811 <f.102+0x1841>
   677fc: e9 36 08 00 00               	jmp	0x68037 <f.102+0x2067>
   67801: 48 8d 48 20                  	leaq	0x20(%rax), %rcx
   67805: 48 89 0d 9c 74 06 00         	movq	%rcx, 0x6749c(%rip)     # 0xceca8 <cursor>
   6780c: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   67811: 48 89 c7                     	movq	%rax, %rdi
   67814: 48 2b 3d 85 74 06 00         	subq	0x67485(%rip), %rdi     # 0xceca0 <arena>
   6781b: 89 f9                        	movl	%edi, %ecx
   6781d: c1 e9 04                     	shrl	$0x4, %ecx
   67820: 41 b8 01 00 00 00            	movl	$0x1, %r8d
   67826: 49 d3 e0                     	shlq	%cl, %r8
   67829: 48 89 f9                     	movq	%rdi, %rcx
   6782c: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   67830: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   67837: 48 03 0d 1a 74 06 00         	addq	0x6741a(%rip), %rcx     # 0xcec58 <blocks>
   6783e: c1 ef 07                     	shrl	$0x7, %edi
   67841: 81 e7 f8 00 00 00            	andl	$0xf8, %edi
   67847: 4c 09 04 0f                  	orq	%r8, (%rdi,%rcx)
   6784b: 48 c7 00 41 00 00 00         	movq	$0x41, (%rax)
   67852: 48 83 05 ce 73 06 00 20      	addq	$0x20, 0x673ce(%rip)    # 0xcec28 <since_collection>
   6785a: 48 83 05 ce 73 06 00 10      	addq	$0x10, 0x673ce(%rip)    # 0xcec30 <allocated_bytes>
   67862: 48 ff 05 cf 73 06 00         	incq	0x673cf(%rip)           # 0xcec38 <allocated_objects>
   67869: 48 8d 58 08                  	leaq	0x8(%rax), %rbx
   6786d: 48 c7 40 08 aa 02 00 00      	movq	$0x2aa, 0x8(%rax)       # imm = 0x2AA
   67875: 4c 89 70 10                  	movq	%r14, 0x10(%rax)
   67879: 4c 8b 74 24 40               	movq	0x40(%rsp), %r14
   6787e: 4c 89 b4 24 80 00 00 00      	movq	%r14, 0x80(%rsp)
   67886: 48 89 9c 24 88 00 00 00      	movq	%rbx, 0x88(%rsp)
   6788e: 48 89 b4 24 90 00 00 00      	movq	%rsi, 0x90(%rsp)
   67896: 48 89 ac 24 98 00 00 00      	movq	%rbp, 0x98(%rsp)
   6789e: 48 c7 44 24 28 0e 00 00 00   	movq	$0xe, 0x28(%rsp)
   678a7: 48 8b 0d 6a 73 06 00         	movq	0x6736a(%rip), %rcx     # 0xcec18 <collection_interval>
   678ae: 48 85 c9                     	testq	%rcx, %rcx
   678b1: 74 32                        	je	0x678e5 <f.102+0x1915>
   678b3: 48 8b 05 66 73 06 00         	movq	0x67366(%rip), %rax     # 0xcec20 <allocations>
   678ba: 48 ff c0                     	incq	%rax
   678bd: 48 89 05 5c 73 06 00         	movq	%rax, 0x6735c(%rip)     # 0xcec20 <allocations>
   678c4: 48 89 c2                     	movq	%rax, %rdx
   678c7: 48 09 ca                     	orq	%rcx, %rdx
   678ca: 48 c1 ea 20                  	shrq	$0x20, %rdx
   678ce: 74 07                        	je	0x678d7 <f.102+0x1907>
   678d0: 31 d2                        	xorl	%edx, %edx
   678d2: 48 f7 f1                     	divq	%rcx
   678d5: eb 04                        	jmp	0x678db <f.102+0x190b>
   678d7: 31 d2                        	xorl	%edx, %edx
   678d9: f7 f1                        	divl	%ecx
   678db: 48 85 d2                     	testq	%rdx, %rdx
   678de: 75 05                        	jne	0x678e5 <f.102+0x1915>
   678e0: e8 cb c0 05 00               	callq	0xc39b0 <native_gc_collect>
   678e5: 48 8b 05 f4 6b 06 00         	movq	0x66bf4(%rip), %rax     # 0xce4e0 <heap_bytes>
   678ec: 48 83 c0 e8                  	addq	$-0x18, %rax
   678f0: 48 83 f8 10                  	cmpq	$0x10, %rax
   678f4: 0f 82 3d 07 00 00            	jb	0x68037 <f.102+0x2067>
   678fa: 48 8b 05 27 73 06 00         	movq	0x67327(%rip), %rax     # 0xcec28 <since_collection>
   67901: 48 3b 05 e0 6b 06 00         	cmpq	0x66be0(%rip), %rax     # 0xce4e8 <budget>
   67908: 72 05                        	jb	0x6790f <f.102+0x193f>
   6790a: e8 a1 c0 05 00               	callq	0xc39b0 <native_gc_collect>
   6790f: 48 8b 05 92 73 06 00         	movq	0x67392(%rip), %rax     # 0xceca8 <cursor>
   67916: 48 85 c0                     	testq	%rax, %rax
   67919: 74 10                        	je	0x6792b <f.102+0x195b>
   6791b: 48 8b 0d 8e 73 06 00         	movq	0x6738e(%rip), %rcx     # 0xcecb0 <limit>
   67922: 48 29 c1                     	subq	%rax, %rcx
   67925: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   67929: 77 49                        	ja	0x67974 <f.102+0x19a4>
   6792b: bf 20 00 00 00               	movl	$0x20, %edi
   67930: e8 8b dd 05 00               	callq	0xc56c0 <allocate_slow>
   67935: 48 85 c0                     	testq	%rax, %rax
   67938: 75 45                        	jne	0x6797f <f.102+0x19af>
   6793a: e8 71 c0 05 00               	callq	0xc39b0 <native_gc_collect>
   6793f: 48 8b 05 62 73 06 00         	movq	0x67362(%rip), %rax     # 0xceca8 <cursor>
   67946: 48 85 c0                     	testq	%rax, %rax
   67949: 74 10                        	je	0x6795b <f.102+0x198b>
   6794b: 48 8b 0d 5e 73 06 00         	movq	0x6735e(%rip), %rcx     # 0xcecb0 <limit>
   67952: 48 29 c1                     	subq	%rax, %rcx
   67955: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   67959: 77 19                        	ja	0x67974 <f.102+0x19a4>
   6795b: bf 20 00 00 00               	movl	$0x20, %edi
   67960: e8 5b dd 05 00               	callq	0xc56c0 <allocate_slow>
   67965: 48 85 c0                     	testq	%rax, %rax
   67968: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   6796d: 75 15                        	jne	0x67984 <f.102+0x19b4>
   6796f: e9 c3 06 00 00               	jmp	0x68037 <f.102+0x2067>
   67974: 48 8d 48 20                  	leaq	0x20(%rax), %rcx
   67978: 48 89 0d 29 73 06 00         	movq	%rcx, 0x67329(%rip)     # 0xceca8 <cursor>
   6797f: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   67984: 48 89 ef                     	movq	%rbp, %rdi
   67987: 48 89 c2                     	movq	%rax, %rdx
   6798a: 48 2b 15 0f 73 06 00         	subq	0x6730f(%rip), %rdx     # 0xceca0 <arena>
   67991: 89 d1                        	movl	%edx, %ecx
   67993: c1 e9 04                     	shrl	$0x4, %ecx
   67996: 41 b8 01 00 00 00            	movl	$0x1, %r8d
   6799c: 49 d3 e0                     	shlq	%cl, %r8
   6799f: 48 89 d1                     	movq	%rdx, %rcx
   679a2: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   679a6: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   679ad: 48 03 0d a4 72 06 00         	addq	0x672a4(%rip), %rcx     # 0xcec58 <blocks>
   679b4: c1 ea 07                     	shrl	$0x7, %edx
   679b7: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   679bd: 4c 09 04 0a                  	orq	%r8, (%rdx,%rcx)
   679c1: 48 c7 00 41 00 00 00         	movq	$0x41, (%rax)
   679c8: 48 83 05 58 72 06 00 20      	addq	$0x20, 0x67258(%rip)    # 0xcec28 <since_collection>
   679d0: 4c 8d 68 08                  	leaq	0x8(%rax), %r13
   679d4: 48 83 05 54 72 06 00 10      	addq	$0x10, 0x67254(%rip)    # 0xcec30 <allocated_bytes>
   679dc: 48 ff 05 55 72 06 00         	incq	0x67255(%rip)           # 0xcec38 <allocated_objects>
   679e3: 48 c7 40 08 aa 02 00 00      	movq	$0x2aa, 0x8(%rax)       # imm = 0x2AA
   679eb: 4c 89 70 10                  	movq	%r14, 0x10(%rax)
   679ef: 4c 89 ac 24 80 00 00 00      	movq	%r13, 0x80(%rsp)
   679f7: 48 89 9c 24 88 00 00 00      	movq	%rbx, 0x88(%rsp)
   679ff: 48 89 b4 24 90 00 00 00      	movq	%rsi, 0x90(%rsp)
   67a07: 48 89 ac 24 98 00 00 00      	movq	%rbp, 0x98(%rsp)
   67a0f: 48 c7 44 24 28 0e 00 00 00   	movq	$0xe, 0x28(%rsp)
   67a18: 48 8b 0d f9 71 06 00         	movq	0x671f9(%rip), %rcx     # 0xcec18 <collection_interval>
   67a1f: 48 85 c9                     	testq	%rcx, %rcx
   67a22: 74 3a                        	je	0x67a5e <f.102+0x1a8e>
   67a24: 48 8b 05 f5 71 06 00         	movq	0x671f5(%rip), %rax     # 0xcec20 <allocations>
   67a2b: 48 ff c0                     	incq	%rax
   67a2e: 48 89 05 eb 71 06 00         	movq	%rax, 0x671eb(%rip)     # 0xcec20 <allocations>
   67a35: 48 89 c2                     	movq	%rax, %rdx
   67a38: 48 09 ca                     	orq	%rcx, %rdx
   67a3b: 48 c1 ea 20                  	shrq	$0x20, %rdx
   67a3f: 74 07                        	je	0x67a48 <f.102+0x1a78>
   67a41: 31 d2                        	xorl	%edx, %edx
   67a43: 48 f7 f1                     	divq	%rcx
   67a46: eb 04                        	jmp	0x67a4c <f.102+0x1a7c>
   67a48: 31 d2                        	xorl	%edx, %edx
   67a4a: f7 f1                        	divl	%ecx
   67a4c: 48 85 d2                     	testq	%rdx, %rdx
   67a4f: 75 0d                        	jne	0x67a5e <f.102+0x1a8e>
   67a51: e8 5a bf 05 00               	callq	0xc39b0 <native_gc_collect>
   67a56: 48 89 ef                     	movq	%rbp, %rdi
   67a59: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   67a5e: 48 8b 05 7b 6a 06 00         	movq	0x66a7b(%rip), %rax     # 0xce4e0 <heap_bytes>
   67a65: 48 83 c0 e8                  	addq	$-0x18, %rax
   67a69: 48 83 f8 20                  	cmpq	$0x20, %rax
   67a6d: 0f 82 c4 05 00 00            	jb	0x68037 <f.102+0x2067>
   67a73: 48 8b 05 ae 71 06 00         	movq	0x671ae(%rip), %rax     # 0xcec28 <since_collection>
   67a7a: 48 3b 05 67 6a 06 00         	cmpq	0x66a67(%rip), %rax     # 0xce4e8 <budget>
   67a81: 72 0d                        	jb	0x67a90 <f.102+0x1ac0>
   67a83: e8 28 bf 05 00               	callq	0xc39b0 <native_gc_collect>
   67a88: 48 89 ef                     	movq	%rbp, %rdi
   67a8b: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   67a90: 48 8b 05 11 72 06 00         	movq	0x67211(%rip), %rax     # 0xceca8 <cursor>
   67a97: 48 85 c0                     	testq	%rax, %rax
   67a9a: 74 10                        	je	0x67aac <f.102+0x1adc>
   67a9c: 48 8b 0d 0d 72 06 00         	movq	0x6720d(%rip), %rcx     # 0xcecb0 <limit>
   67aa3: 48 29 c1                     	subq	%rax, %rcx
   67aa6: 48 83 f9 2f                  	cmpq	$0x2f, %rcx
   67aaa: 77 5f                        	ja	0x67b0b <f.102+0x1b3b>
   67aac: bf 30 00 00 00               	movl	$0x30, %edi
   67ab1: e8 0a dc 05 00               	callq	0xc56c0 <allocate_slow>
   67ab6: 48 85 c0                     	testq	%rax, %rax
   67ab9: 74 0a                        	je	0x67ac5 <f.102+0x1af5>
   67abb: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   67ac0: 48 89 ef                     	movq	%rbp, %rdi
   67ac3: eb 51                        	jmp	0x67b16 <f.102+0x1b46>
   67ac5: e8 e6 be 05 00               	callq	0xc39b0 <native_gc_collect>
   67aca: 48 8b 05 d7 71 06 00         	movq	0x671d7(%rip), %rax     # 0xceca8 <cursor>
   67ad1: 48 85 c0                     	testq	%rax, %rax
   67ad4: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   67ad9: 74 13                        	je	0x67aee <f.102+0x1b1e>
   67adb: 48 89 ef                     	movq	%rbp, %rdi
   67ade: 48 8b 0d cb 71 06 00         	movq	0x671cb(%rip), %rcx     # 0xcecb0 <limit>
   67ae5: 48 29 c1                     	subq	%rax, %rcx
   67ae8: 48 83 f9 2f                  	cmpq	$0x2f, %rcx
   67aec: 77 1d                        	ja	0x67b0b <f.102+0x1b3b>
   67aee: bf 30 00 00 00               	movl	$0x30, %edi
   67af3: e8 c8 db 05 00               	callq	0xc56c0 <allocate_slow>
   67af8: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
   67afd: 48 85 c0                     	testq	%rax, %rax
   67b00: 0f 84 31 05 00 00            	je	0x68037 <f.102+0x2067>
   67b06: 48 89 ef                     	movq	%rbp, %rdi
   67b09: eb 0b                        	jmp	0x67b16 <f.102+0x1b46>
   67b0b: 48 8d 48 30                  	leaq	0x30(%rax), %rcx
   67b0f: 48 89 0d 92 71 06 00         	movq	%rcx, 0x67192(%rip)     # 0xceca8 <cursor>
   67b16: 48 89 c2                     	movq	%rax, %rdx
   67b19: 48 2b 15 80 71 06 00         	subq	0x67180(%rip), %rdx     # 0xceca0 <arena>
   67b20: 89 d1                        	movl	%edx, %ecx
   67b22: c1 e9 04                     	shrl	$0x4, %ecx
   67b25: 41 b8 01 00 00 00            	movl	$0x1, %r8d
   67b2b: 49 d3 e0                     	shlq	%cl, %r8
   67b2e: 48 89 d1                     	movq	%rdx, %rcx
   67b31: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   67b35: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   67b3c: 48 03 0d 15 71 06 00         	addq	0x67115(%rip), %rcx     # 0xcec58 <blocks>
   67b43: c1 ea 07                     	shrl	$0x7, %edx
   67b46: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   67b4c: 4c 09 04 0a                  	orq	%r8, (%rdx,%rcx)
   67b50: 48 c7 00 81 00 00 00         	movq	$0x81, (%rax)
   67b57: c7 40 14 00 00 00 00         	movl	$0x0, 0x14(%rax)
   67b5e: 48 83 05 c2 70 06 00 30      	addq	$0x30, 0x670c2(%rip)    # 0xcec28 <since_collection>
   67b66: 48 83 05 c2 70 06 00 20      	addq	$0x20, 0x670c2(%rip)    # 0xcec30 <allocated_bytes>
   67b6e: 48 8d 50 08                  	leaq	0x8(%rax), %rdx
   67b72: 48 ff 05 bf 70 06 00         	incq	0x670bf(%rip)           # 0xcec38 <allocated_objects>
   67b79: 48 c7 40 08 5a 01 00 00      	movq	$0x15a, 0x8(%rax)       # imm = 0x15A
   67b81: c7 40 10 06 00 00 00         	movl	$0x6, 0x10(%rax)
   67b88: 48 89 58 18                  	movq	%rbx, 0x18(%rax)
   67b8c: 4c 89 68 20                  	movq	%r13, 0x20(%rax)
   67b90: bd fe ff ff ff               	movl	$0xfffffffe, %ebp       # imm = 0xFFFFFFFE
   67b95: 48 83 7c 24 20 00            	cmpq	$0x0, 0x20(%rsp)
   67b9b: 0f 85 5f e4 ff ff            	jne	0x66000 <f.102+0x30>
   67ba1: e9 6d e4 ff ff               	jmp	0x66013 <f.102+0x43>
   67ba6: 48 85 c9                     	testq	%rcx, %rcx
   67ba9: 0f 84 37 09 00 00            	je	0x684e6 <f.102+0x2516>
   67baf: 48 83 3d 91 6a 06 00 00      	cmpq	$0x0, 0x66a91(%rip)     # 0xce648 <g.4>
   67bb7: 0f 84 29 09 00 00            	je	0x684e6 <f.102+0x2516>
   67bbd: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
   67bc2: 48 89 bc 24 80 00 00 00      	movq	%rdi, 0x80(%rsp)
   67bca: 48 c7 44 24 28 0b 00 00 00   	movq	$0xb, 0x28(%rsp)
   67bd3: e8 b8 d3 ff ff               	callq	0x64f90 <f.45>
   67bd8: 48 83 ec 08                  	subq	$0x8, %rsp
   67bdc: 48 83 3d 3c 6c 06 00 00      	cmpq	$0x0, 0x66c3c(%rip)     # 0xce820 <g.68>
   67be4: 0f 84 fc 08 00 00            	je	0x684e6 <f.102+0x2516>
   67bea: 48 85 c0                     	testq	%rax, %rax
   67bed: 74 22                        	je	0x67c11 <f.102+0x1c41>
   67bef: 48 8b 05 6a 6b 06 00         	movq	0x66b6a(%rip), %rax     # 0xce760 <g.43>
   67bf6: 48 85 c0                     	testq	%rax, %rax
   67bf9: 75 26                        	jne	0x67c21 <f.102+0x1c51>
   67bfb: e9 e6 08 00 00               	jmp	0x684e6 <f.102+0x2516>
   67c00: 48 8b 05 51 6f 06 00         	movq	0x66f51(%rip), %rax     # 0xceb58 <g.179>
   67c07: 48 85 c0                     	testq	%rax, %rax
   67c0a: 75 15                        	jne	0x67c21 <f.102+0x1c51>
   67c0c: e9 d5 08 00 00               	jmp	0x684e6 <f.102+0x2516>
   67c11: 48 8b 05 00 6c 06 00         	movq	0x66c00(%rip), %rax     # 0xce818 <g.67>
   67c18: 48 85 c0                     	testq	%rax, %rax
   67c1b: 0f 84 c5 08 00 00            	je	0x684e6 <f.102+0x2516>
   67c21: 48 83 7c 24 20 00            	cmpq	$0x0, 0x20(%rsp)
   67c27: 74 13                        	je	0x67c3c <f.102+0x1c6c>
   67c29: 48 8b 4c 24 18               	movq	0x18(%rsp), %rcx
   67c2e: 48 89 0d a3 70 06 00         	movq	%rcx, 0x670a3(%rip)     # 0xcecd8 <native_roots>
   67c35: 48 ff 0d cc 6f 06 00         	decq	0x66fcc(%rip)           # 0xcec08 <root_depth>
   67c3c: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
   67c43: 5b                           	popq	%rbx
   67c44: 41 5c                        	popq	%r12
   67c46: 41 5d                        	popq	%r13
   67c48: 41 5e                        	popq	%r14
   67c4a: 41 5f                        	popq	%r15
   67c4c: 5d                           	popq	%rbp
   67c4d: c2 08 00                     	retq	$0x8
   67c50: 48 83 3d d8 69 06 00 00      	cmpq	$0x0, 0x669d8(%rip)     # 0xce630 <g.0>
   67c58: 0f 84 88 08 00 00            	je	0x684e6 <f.102+0x2516>
   67c5e: 48 8b 5c 24 40               	movq	0x40(%rsp), %rbx
   67c63: 4c 8b 74 24 48               	movq	0x48(%rsp), %r14
   67c68: 4c 8d 25 31 8e fa ff         	leaq	-0x571cf(%rip), %r12    # 0x10aa0 <object.10.0>
   67c6f: 4c 89 64 24 70               	movq	%r12, 0x70(%rsp)
   67c74: 4c 89 a4 24 80 00 00 00      	movq	%r12, 0x80(%rsp)
   67c7c: 4c 89 a4 24 88 00 00 00      	movq	%r12, 0x88(%rsp)
   67c84: 48 89 9c 24 90 00 00 00      	movq	%rbx, 0x90(%rsp)
   67c8c: 4c 89 b4 24 98 00 00 00      	movq	%r14, 0x98(%rsp)
   67c94: 48 c7 44 24 28 0e 00 00 00   	movq	$0xe, 0x28(%rsp)
   67c9d: 48 8b 0d 74 6f 06 00         	movq	0x66f74(%rip), %rcx     # 0xcec18 <collection_interval>
   67ca4: 48 85 c9                     	testq	%rcx, %rcx
   67ca7: 74 32                        	je	0x67cdb <f.102+0x1d0b>
   67ca9: 48 8b 05 70 6f 06 00         	movq	0x66f70(%rip), %rax     # 0xcec20 <allocations>
   67cb0: 48 ff c0                     	incq	%rax
   67cb3: 48 89 05 66 6f 06 00         	movq	%rax, 0x66f66(%rip)     # 0xcec20 <allocations>
   67cba: 48 89 c2                     	movq	%rax, %rdx
   67cbd: 48 09 ca                     	orq	%rcx, %rdx
   67cc0: 48 c1 ea 20                  	shrq	$0x20, %rdx
   67cc4: 74 07                        	je	0x67ccd <f.102+0x1cfd>
   67cc6: 31 d2                        	xorl	%edx, %edx
   67cc8: 48 f7 f1                     	divq	%rcx
   67ccb: eb 04                        	jmp	0x67cd1 <f.102+0x1d01>
   67ccd: 31 d2                        	xorl	%edx, %edx
   67ccf: f7 f1                        	divl	%ecx
   67cd1: 48 85 d2                     	testq	%rdx, %rdx
   67cd4: 75 05                        	jne	0x67cdb <f.102+0x1d0b>
   67cd6: e8 d5 bc 05 00               	callq	0xc39b0 <native_gc_collect>
   67cdb: 48 8b 05 fe 67 06 00         	movq	0x667fe(%rip), %rax     # 0xce4e0 <heap_bytes>
   67ce2: 48 83 c0 e8                  	addq	$-0x18, %rax
   67ce6: 48 83 f8 10                  	cmpq	$0x10, %rax
   67cea: 0f 82 47 03 00 00            	jb	0x68037 <f.102+0x2067>
   67cf0: 48 8b 05 31 6f 06 00         	movq	0x66f31(%rip), %rax     # 0xcec28 <since_collection>
   67cf7: 48 3b 05 ea 67 06 00         	cmpq	0x667ea(%rip), %rax     # 0xce4e8 <budget>
   67cfe: 72 05                        	jb	0x67d05 <f.102+0x1d35>
   67d00: e8 ab bc 05 00               	callq	0xc39b0 <native_gc_collect>
   67d05: 48 8b 05 9c 6f 06 00         	movq	0x66f9c(%rip), %rax     # 0xceca8 <cursor>
   67d0c: 48 85 c0                     	testq	%rax, %rax
   67d0f: 74 10                        	je	0x67d21 <f.102+0x1d51>
   67d11: 48 8b 0d 98 6f 06 00         	movq	0x66f98(%rip), %rcx     # 0xcecb0 <limit>
   67d18: 48 29 c1                     	subq	%rax, %rcx
   67d1b: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   67d1f: 77 44                        	ja	0x67d65 <f.102+0x1d95>
   67d21: bf 20 00 00 00               	movl	$0x20, %edi
   67d26: e8 95 d9 05 00               	callq	0xc56c0 <allocate_slow>
   67d2b: 48 85 c0                     	testq	%rax, %rax
   67d2e: 75 40                        	jne	0x67d70 <f.102+0x1da0>
   67d30: e8 7b bc 05 00               	callq	0xc39b0 <native_gc_collect>
   67d35: 48 8b 05 6c 6f 06 00         	movq	0x66f6c(%rip), %rax     # 0xceca8 <cursor>
   67d3c: 48 85 c0                     	testq	%rax, %rax
   67d3f: 74 10                        	je	0x67d51 <f.102+0x1d81>
   67d41: 48 8b 0d 68 6f 06 00         	movq	0x66f68(%rip), %rcx     # 0xcecb0 <limit>
   67d48: 48 29 c1                     	subq	%rax, %rcx
   67d4b: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   67d4f: 77 14                        	ja	0x67d65 <f.102+0x1d95>
   67d51: bf 20 00 00 00               	movl	$0x20, %edi
   67d56: e8 65 d9 05 00               	callq	0xc56c0 <allocate_slow>
   67d5b: 48 85 c0                     	testq	%rax, %rax
   67d5e: 75 10                        	jne	0x67d70 <f.102+0x1da0>
   67d60: e9 d2 02 00 00               	jmp	0x68037 <f.102+0x2067>
   67d65: 48 8d 48 20                  	leaq	0x20(%rax), %rcx
   67d69: 48 89 0d 38 6f 06 00         	movq	%rcx, 0x66f38(%rip)     # 0xceca8 <cursor>
   67d70: 48 89 c2                     	movq	%rax, %rdx
   67d73: 48 2b 15 26 6f 06 00         	subq	0x66f26(%rip), %rdx     # 0xceca0 <arena>
   67d7a: 89 d1                        	movl	%edx, %ecx
   67d7c: c1 e9 04                     	shrl	$0x4, %ecx
   67d7f: be 01 00 00 00               	movl	$0x1, %esi
   67d84: 48 d3 e6                     	shlq	%cl, %rsi
   67d87: 48 89 d1                     	movq	%rdx, %rcx
   67d8a: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   67d8e: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   67d95: 48 03 0d bc 6e 06 00         	addq	0x66ebc(%rip), %rcx     # 0xcec58 <blocks>
   67d9c: c1 ea 07                     	shrl	$0x7, %edx
   67d9f: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   67da5: 48 09 34 0a                  	orq	%rsi, (%rdx,%rcx)
   67da9: 48 c7 00 41 00 00 00         	movq	$0x41, (%rax)
   67db0: 48 83 05 70 6e 06 00 20      	addq	$0x20, 0x66e70(%rip)    # 0xcec28 <since_collection>
   67db8: 48 83 05 70 6e 06 00 10      	addq	$0x10, 0x66e70(%rip)    # 0xcec30 <allocated_bytes>
   67dc0: 48 ff 05 71 6e 06 00         	incq	0x66e71(%rip)           # 0xcec38 <allocated_objects>
   67dc7: 4c 8d 78 08                  	leaq	0x8(%rax), %r15
   67dcb: 48 c7 40 08 aa 02 00 00      	movq	$0x2aa, 0x8(%rax)       # imm = 0x2AA
   67dd3: 4c 89 60 10                  	movq	%r12, 0x10(%rax)
   67dd7: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
   67ddc: 48 89 ac 24 80 00 00 00      	movq	%rbp, 0x80(%rsp)
   67de4: 4c 89 bc 24 88 00 00 00      	movq	%r15, 0x88(%rsp)
   67dec: 4c 89 a4 24 90 00 00 00      	movq	%r12, 0x90(%rsp)
   67df4: 48 89 9c 24 98 00 00 00      	movq	%rbx, 0x98(%rsp)
   67dfc: 4c 89 b4 24 a0 00 00 00      	movq	%r14, 0xa0(%rsp)
   67e04: 48 c7 44 24 28 0f 00 00 00   	movq	$0xf, 0x28(%rsp)
   67e0d: 48 8b 0d 04 6e 06 00         	movq	0x66e04(%rip), %rcx     # 0xcec18 <collection_interval>
   67e14: 48 85 c9                     	testq	%rcx, %rcx
   67e17: 74 32                        	je	0x67e4b <f.102+0x1e7b>
   67e19: 48 8b 05 00 6e 06 00         	movq	0x66e00(%rip), %rax     # 0xcec20 <allocations>
   67e20: 48 ff c0                     	incq	%rax
   67e23: 48 89 05 f6 6d 06 00         	movq	%rax, 0x66df6(%rip)     # 0xcec20 <allocations>
   67e2a: 48 89 c2                     	movq	%rax, %rdx
   67e2d: 48 09 ca                     	orq	%rcx, %rdx
   67e30: 48 c1 ea 20                  	shrq	$0x20, %rdx
   67e34: 74 07                        	je	0x67e3d <f.102+0x1e6d>
   67e36: 31 d2                        	xorl	%edx, %edx
   67e38: 48 f7 f1                     	divq	%rcx
   67e3b: eb 04                        	jmp	0x67e41 <f.102+0x1e71>
   67e3d: 31 d2                        	xorl	%edx, %edx
   67e3f: f7 f1                        	divl	%ecx
   67e41: 48 85 d2                     	testq	%rdx, %rdx
   67e44: 75 05                        	jne	0x67e4b <f.102+0x1e7b>
   67e46: e8 65 bb 05 00               	callq	0xc39b0 <native_gc_collect>
   67e4b: 48 8b 05 8e 66 06 00         	movq	0x6668e(%rip), %rax     # 0xce4e0 <heap_bytes>
   67e52: 48 83 c0 e8                  	addq	$-0x18, %rax
   67e56: 48 83 f8 10                  	cmpq	$0x10, %rax
   67e5a: 0f 82 d7 01 00 00            	jb	0x68037 <f.102+0x2067>
   67e60: 48 8b 05 c1 6d 06 00         	movq	0x66dc1(%rip), %rax     # 0xcec28 <since_collection>
   67e67: 48 3b 05 7a 66 06 00         	cmpq	0x6667a(%rip), %rax     # 0xce4e8 <budget>
   67e6e: 72 05                        	jb	0x67e75 <f.102+0x1ea5>
   67e70: e8 3b bb 05 00               	callq	0xc39b0 <native_gc_collect>
   67e75: 48 8b 05 2c 6e 06 00         	movq	0x66e2c(%rip), %rax     # 0xceca8 <cursor>
   67e7c: 48 85 c0                     	testq	%rax, %rax
   67e7f: 74 10                        	je	0x67e91 <f.102+0x1ec1>
   67e81: 48 8b 0d 28 6e 06 00         	movq	0x66e28(%rip), %rcx     # 0xcecb0 <limit>
   67e88: 48 29 c1                     	subq	%rax, %rcx
   67e8b: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   67e8f: 77 44                        	ja	0x67ed5 <f.102+0x1f05>
   67e91: bf 20 00 00 00               	movl	$0x20, %edi
   67e96: e8 25 d8 05 00               	callq	0xc56c0 <allocate_slow>
   67e9b: 48 85 c0                     	testq	%rax, %rax
   67e9e: 75 40                        	jne	0x67ee0 <f.102+0x1f10>
   67ea0: e8 0b bb 05 00               	callq	0xc39b0 <native_gc_collect>
   67ea5: 48 8b 05 fc 6d 06 00         	movq	0x66dfc(%rip), %rax     # 0xceca8 <cursor>
   67eac: 48 85 c0                     	testq	%rax, %rax
   67eaf: 74 10                        	je	0x67ec1 <f.102+0x1ef1>
   67eb1: 48 8b 0d f8 6d 06 00         	movq	0x66df8(%rip), %rcx     # 0xcecb0 <limit>
   67eb8: 48 29 c1                     	subq	%rax, %rcx
   67ebb: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   67ebf: 77 14                        	ja	0x67ed5 <f.102+0x1f05>
   67ec1: bf 20 00 00 00               	movl	$0x20, %edi
   67ec6: e8 f5 d7 05 00               	callq	0xc56c0 <allocate_slow>
   67ecb: 48 85 c0                     	testq	%rax, %rax
   67ece: 75 10                        	jne	0x67ee0 <f.102+0x1f10>
   67ed0: e9 62 01 00 00               	jmp	0x68037 <f.102+0x2067>
   67ed5: 48 8d 48 20                  	leaq	0x20(%rax), %rcx
   67ed9: 48 89 0d c8 6d 06 00         	movq	%rcx, 0x66dc8(%rip)     # 0xceca8 <cursor>
   67ee0: 48 89 c2                     	movq	%rax, %rdx
   67ee3: 48 2b 15 b6 6d 06 00         	subq	0x66db6(%rip), %rdx     # 0xceca0 <arena>
   67eea: 89 d1                        	movl	%edx, %ecx
   67eec: c1 e9 04                     	shrl	$0x4, %ecx
   67eef: be 01 00 00 00               	movl	$0x1, %esi
   67ef4: 48 d3 e6                     	shlq	%cl, %rsi
   67ef7: 48 89 d1                     	movq	%rdx, %rcx
   67efa: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   67efe: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   67f05: 48 03 0d 4c 6d 06 00         	addq	0x66d4c(%rip), %rcx     # 0xcec58 <blocks>
   67f0c: c1 ea 07                     	shrl	$0x7, %edx
   67f0f: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   67f15: 48 09 34 0a                  	orq	%rsi, (%rdx,%rcx)
   67f19: 48 c7 00 41 00 00 00         	movq	$0x41, (%rax)
   67f20: 48 83 05 00 6d 06 00 20      	addq	$0x20, 0x66d00(%rip)    # 0xcec28 <since_collection>
   67f28: 48 83 05 00 6d 06 00 10      	addq	$0x10, 0x66d00(%rip)    # 0xcec30 <allocated_bytes>
   67f30: 48 ff 05 01 6d 06 00         	incq	0x66d01(%rip)           # 0xcec38 <allocated_objects>
   67f37: 4c 8d 68 08                  	leaq	0x8(%rax), %r13
   67f3b: 48 c7 40 08 aa 02 00 00      	movq	$0x2aa, 0x8(%rax)       # imm = 0x2AA
   67f43: 48 89 68 10                  	movq	%rbp, 0x10(%rax)
   67f47: 4c 89 ac 24 80 00 00 00      	movq	%r13, 0x80(%rsp)
   67f4f: 4c 89 bc 24 88 00 00 00      	movq	%r15, 0x88(%rsp)
   67f57: 4c 89 a4 24 90 00 00 00      	movq	%r12, 0x90(%rsp)
   67f5f: 48 89 9c 24 98 00 00 00      	movq	%rbx, 0x98(%rsp)
   67f67: 4c 89 b4 24 a0 00 00 00      	movq	%r14, 0xa0(%rsp)
   67f6f: 48 c7 44 24 28 0f 00 00 00   	movq	$0xf, 0x28(%rsp)
   67f78: 48 8b 0d 99 6c 06 00         	movq	0x66c99(%rip), %rcx     # 0xcec18 <collection_interval>
   67f7f: 48 85 c9                     	testq	%rcx, %rcx
   67f82: 74 32                        	je	0x67fb6 <f.102+0x1fe6>
   67f84: 48 8b 05 95 6c 06 00         	movq	0x66c95(%rip), %rax     # 0xcec20 <allocations>
   67f8b: 48 ff c0                     	incq	%rax
   67f8e: 48 89 05 8b 6c 06 00         	movq	%rax, 0x66c8b(%rip)     # 0xcec20 <allocations>
   67f95: 48 89 c2                     	movq	%rax, %rdx
   67f98: 48 09 ca                     	orq	%rcx, %rdx
   67f9b: 48 c1 ea 20                  	shrq	$0x20, %rdx
   67f9f: 74 07                        	je	0x67fa8 <f.102+0x1fd8>
   67fa1: 31 d2                        	xorl	%edx, %edx
   67fa3: 48 f7 f1                     	divq	%rcx
   67fa6: eb 04                        	jmp	0x67fac <f.102+0x1fdc>
   67fa8: 31 d2                        	xorl	%edx, %edx
   67faa: f7 f1                        	divl	%ecx
   67fac: 48 85 d2                     	testq	%rdx, %rdx
   67faf: 75 05                        	jne	0x67fb6 <f.102+0x1fe6>
   67fb1: e8 fa b9 05 00               	callq	0xc39b0 <native_gc_collect>
   67fb6: 48 8b 05 23 65 06 00         	movq	0x66523(%rip), %rax     # 0xce4e0 <heap_bytes>
   67fbd: 48 83 c0 e8                  	addq	$-0x18, %rax
   67fc1: 48 83 f8 20                  	cmpq	$0x20, %rax
   67fc5: 72 70                        	jb	0x68037 <f.102+0x2067>
   67fc7: 48 8b 05 5a 6c 06 00         	movq	0x66c5a(%rip), %rax     # 0xcec28 <since_collection>
   67fce: 48 3b 05 13 65 06 00         	cmpq	0x66513(%rip), %rax     # 0xce4e8 <budget>
   67fd5: 72 05                        	jb	0x67fdc <f.102+0x200c>
   67fd7: e8 d4 b9 05 00               	callq	0xc39b0 <native_gc_collect>
   67fdc: 48 8b 05 c5 6c 06 00         	movq	0x66cc5(%rip), %rax     # 0xceca8 <cursor>
   67fe3: 48 85 c0                     	testq	%rax, %rax
   67fe6: 74 10                        	je	0x67ff8 <f.102+0x2028>
   67fe8: 48 8b 0d c1 6c 06 00         	movq	0x66cc1(%rip), %rcx     # 0xcecb0 <limit>
   67fef: 48 29 c1                     	subq	%rax, %rcx
   67ff2: 48 83 f9 2f                  	cmpq	$0x2f, %rcx
   67ff6: 77 4b                        	ja	0x68043 <f.102+0x2073>
   67ff8: bf 30 00 00 00               	movl	$0x30, %edi
   67ffd: e8 be d6 05 00               	callq	0xc56c0 <allocate_slow>
   68002: 48 85 c0                     	testq	%rax, %rax
   68005: 75 47                        	jne	0x6804e <f.102+0x207e>
   68007: e8 a4 b9 05 00               	callq	0xc39b0 <native_gc_collect>
   6800c: 48 8b 05 95 6c 06 00         	movq	0x66c95(%rip), %rax     # 0xceca8 <cursor>
   68013: 48 85 c0                     	testq	%rax, %rax
   68016: 74 10                        	je	0x68028 <f.102+0x2058>
   68018: 48 8b 0d 91 6c 06 00         	movq	0x66c91(%rip), %rcx     # 0xcecb0 <limit>
   6801f: 48 29 c1                     	subq	%rax, %rcx
   68022: 48 83 f9 2f                  	cmpq	$0x2f, %rcx
   68026: 77 1b                        	ja	0x68043 <f.102+0x2073>
   68028: bf 30 00 00 00               	movl	$0x30, %edi
   6802d: e8 8e d6 05 00               	callq	0xc56c0 <allocate_slow>
   68032: 48 85 c0                     	testq	%rax, %rax
   68035: 75 17                        	jne	0x6804e <f.102+0x207e>
   68037: 48 8d 3d db 17 fa ff         	leaq	-0x5e825(%rip), %rdi    # 0x9819 <writev+0x9819>
   6803e: e8 9d b3 05 00               	callq	0xc33e0 <native_fail>
   68043: 48 8d 48 30                  	leaq	0x30(%rax), %rcx
   68047: 48 89 0d 5a 6c 06 00         	movq	%rcx, 0x66c5a(%rip)     # 0xceca8 <cursor>
   6804e: 48 89 c2                     	movq	%rax, %rdx
   68051: 48 2b 15 48 6c 06 00         	subq	0x66c48(%rip), %rdx     # 0xceca0 <arena>
   68058: 89 d1                        	movl	%edx, %ecx
   6805a: c1 e9 04                     	shrl	$0x4, %ecx
   6805d: be 01 00 00 00               	movl	$0x1, %esi
   68062: 48 d3 e6                     	shlq	%cl, %rsi
   68065: 48 89 d1                     	movq	%rdx, %rcx
   68068: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   6806c: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   68073: 48 03 0d de 6b 06 00         	addq	0x66bde(%rip), %rcx     # 0xcec58 <blocks>
   6807a: c1 ea 07                     	shrl	$0x7, %edx
   6807d: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   68083: 48 09 34 0a                  	orq	%rsi, (%rdx,%rcx)
   68087: 48 c7 00 81 00 00 00         	movq	$0x81, (%rax)
   6808e: c7 40 14 00 00 00 00         	movl	$0x0, 0x14(%rax)
   68095: 48 83 05 8b 6b 06 00 30      	addq	$0x30, 0x66b8b(%rip)    # 0xcec28 <since_collection>
   6809d: 48 83 05 8b 6b 06 00 20      	addq	$0x20, 0x66b8b(%rip)    # 0xcec30 <allocated_bytes>
   680a5: 48 ff 05 8c 6b 06 00         	incq	0x66b8c(%rip)           # 0xcec38 <allocated_objects>
   680ac: 48 8d 50 08                  	leaq	0x8(%rax), %rdx
   680b0: 48 c7 40 08 5a 01 00 00      	movq	$0x15a, 0x8(%rax)       # imm = 0x15A
   680b8: c7 40 10 06 00 00 00         	movl	$0x6, 0x10(%rax)
   680bf: 4c 89 78 18                  	movq	%r15, 0x18(%rax)
   680c3: 4c 89 68 20                  	movq	%r13, 0x20(%rax)
   680c7: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
   680cc: 48 83 7c 24 20 00            	cmpq	$0x0, 0x20(%rsp)
   680d2: 74 13                        	je	0x680e7 <f.102+0x2117>
   680d4: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
   680d9: 48 89 05 f8 6b 06 00         	movq	%rax, 0x66bf8(%rip)     # 0xcecd8 <native_roots>
   680e0: 48 ff 0d 21 6b 06 00         	decq	0x66b21(%rip)           # 0xcec08 <root_depth>
   680e7: 4c 89 f7                     	movq	%r14, %rdi
   680ea: 48 89 de                     	movq	%rbx, %rsi
   680ed: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
   680f4: 5b                           	popq	%rbx
   680f5: 41 5c                        	popq	%r12
   680f7: 41 5d                        	popq	%r13
   680f9: 41 5e                        	popq	%r14
   680fb: 41 5f                        	popq	%r15
   680fd: 5d                           	popq	%rbp
   680fe: e9 3d 1a 00 00               	jmp	0x69b40 <f.103>
   68103: 48 85 c0                     	testq	%rax, %rax
   68106: 0f 84 da 03 00 00            	je	0x684e6 <f.102+0x2516>
   6810c: 48 8d 0d bd 8a fa ff         	leaq	-0x57543(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   68113: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)
   68120: 48 c1 e8 02                  	shrq	$0x2, %rax
   68124: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   68128: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   6812f: 0f 83 b1 03 00 00            	jae	0x684e6 <f.102+0x2516>
   68135: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   6813a: 48 85 c0                     	testq	%rax, %rax
   6813d: 75 e1                        	jne	0x68120 <f.102+0x2150>
   6813f: e9 a2 03 00 00               	jmp	0x684e6 <f.102+0x2516>
   68144: 48 85 c0                     	testq	%rax, %rax
   68147: 0f 84 99 03 00 00            	je	0x684e6 <f.102+0x2516>
   6814d: 48 8d 0d 7c 8a fa ff         	leaq	-0x57584(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   68154: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)
   68160: 48 c1 e8 02                  	shrq	$0x2, %rax
   68164: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   68168: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   6816f: 0f 83 71 03 00 00            	jae	0x684e6 <f.102+0x2516>
   68175: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   6817a: 48 85 c0                     	testq	%rax, %rax
   6817d: 75 e1                        	jne	0x68160 <f.102+0x2190>
   6817f: e9 62 03 00 00               	jmp	0x684e6 <f.102+0x2516>
   68184: 48 85 c0                     	testq	%rax, %rax
   68187: 0f 84 59 03 00 00            	je	0x684e6 <f.102+0x2516>
   6818d: 48 8d 0d 3c 8a fa ff         	leaq	-0x575c4(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   68194: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)
   681a0: 48 c1 e8 02                  	shrq	$0x2, %rax
   681a4: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   681a8: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   681af: 0f 83 31 03 00 00            	jae	0x684e6 <f.102+0x2516>
   681b5: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   681ba: 48 85 c0                     	testq	%rax, %rax
   681bd: 75 e1                        	jne	0x681a0 <f.102+0x21d0>
   681bf: e9 22 03 00 00               	jmp	0x684e6 <f.102+0x2516>
   681c4: 48 85 c9                     	testq	%rcx, %rcx
   681c7: 0f 84 19 03 00 00            	je	0x684e6 <f.102+0x2516>
   681cd: 48 8d 05 fc 89 fa ff         	leaq	-0x57604(%rip), %rax    # 0x10bd0 <native_gc_parents>
   681d4: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)
   681e0: 48 c1 e9 02                  	shrq	$0x2, %rcx
   681e4: 48 8d 51 ff                  	leaq	-0x1(%rcx), %rdx
   681e8: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   681ef: 0f 83 f1 02 00 00            	jae	0x684e6 <f.102+0x2516>
   681f5: 48 8b 4c c8 f8               	movq	-0x8(%rax,%rcx,8), %rcx
   681fa: 48 85 c9                     	testq	%rcx, %rcx
   681fd: 75 e1                        	jne	0x681e0 <f.102+0x2210>
   681ff: e9 e2 02 00 00               	jmp	0x684e6 <f.102+0x2516>
   68204: 48 85 d2                     	testq	%rdx, %rdx
   68207: 0f 84 d9 02 00 00            	je	0x684e6 <f.102+0x2516>
   6820d: 48 8d 05 bc 89 fa ff         	leaq	-0x57644(%rip), %rax    # 0x10bd0 <native_gc_parents>
   68214: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)
   68220: 48 c1 ea 02                  	shrq	$0x2, %rdx
   68224: 48 8d 4a ff                  	leaq	-0x1(%rdx), %rcx
   68228: 48 81 f9 e6 00 00 00         	cmpq	$0xe6, %rcx
   6822f: 0f 83 b1 02 00 00            	jae	0x684e6 <f.102+0x2516>
   68235: 48 8b 54 d0 f8               	movq	-0x8(%rax,%rdx,8), %rdx
   6823a: 48 85 d2                     	testq	%rdx, %rdx
   6823d: 75 e1                        	jne	0x68220 <f.102+0x2250>
   6823f: e9 a2 02 00 00               	jmp	0x684e6 <f.102+0x2516>
   68244: 48 85 c0                     	testq	%rax, %rax
   68247: 0f 84 99 02 00 00            	je	0x684e6 <f.102+0x2516>
   6824d: 48 8d 0d 7c 89 fa ff         	leaq	-0x57684(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   68254: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)
   68260: 48 c1 e8 02                  	shrq	$0x2, %rax
   68264: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   68268: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   6826f: 0f 83 71 02 00 00            	jae	0x684e6 <f.102+0x2516>
   68275: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   6827a: 48 85 c0                     	testq	%rax, %rax
   6827d: 75 e1                        	jne	0x68260 <f.102+0x2290>
   6827f: e9 62 02 00 00               	jmp	0x684e6 <f.102+0x2516>
   68284: 48 85 c0                     	testq	%rax, %rax
   68287: 0f 84 59 02 00 00            	je	0x684e6 <f.102+0x2516>
   6828d: 48 8d 0d 3c 89 fa ff         	leaq	-0x576c4(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   68294: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)
   682a0: 48 c1 e8 02                  	shrq	$0x2, %rax
   682a4: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   682a8: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   682af: 0f 83 31 02 00 00            	jae	0x684e6 <f.102+0x2516>
   682b5: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   682ba: 48 85 c0                     	testq	%rax, %rax
   682bd: 75 e1                        	jne	0x682a0 <f.102+0x22d0>
   682bf: e9 22 02 00 00               	jmp	0x684e6 <f.102+0x2516>
   682c4: 48 85 c0                     	testq	%rax, %rax
   682c7: 0f 84 19 02 00 00            	je	0x684e6 <f.102+0x2516>
   682cd: 48 8d 0d fc 88 fa ff         	leaq	-0x57704(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   682d4: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)
   682e0: 48 c1 e8 02                  	shrq	$0x2, %rax
   682e4: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   682e8: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   682ef: 0f 83 f1 01 00 00            	jae	0x684e6 <f.102+0x2516>
   682f5: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   682fa: 48 85 c0                     	testq	%rax, %rax
   682fd: 75 e1                        	jne	0x682e0 <f.102+0x2310>
   682ff: e9 e2 01 00 00               	jmp	0x684e6 <f.102+0x2516>
   68304: 48 85 c0                     	testq	%rax, %rax
   68307: 0f 84 d9 01 00 00            	je	0x684e6 <f.102+0x2516>
   6830d: 48 8d 0d bc 88 fa ff         	leaq	-0x57744(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   68314: 48 c1 e8 02                  	shrq	$0x2, %rax
   68318: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   6831c: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   68323: 0f 83 bd 01 00 00            	jae	0x684e6 <f.102+0x2516>
   68329: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   6832e: 48 85 c0                     	testq	%rax, %rax
   68331: 75 e1                        	jne	0x68314 <f.102+0x2344>
   68333: e9 ae 01 00 00               	jmp	0x684e6 <f.102+0x2516>
   68338: 48 85 c0                     	testq	%rax, %rax
   6833b: 0f 84 a5 01 00 00            	je	0x684e6 <f.102+0x2516>
   68341: 48 8d 0d 88 88 fa ff         	leaq	-0x57778(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   68348: 48 c1 e8 02                  	shrq	$0x2, %rax
   6834c: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   68350: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   68357: 0f 83 89 01 00 00            	jae	0x684e6 <f.102+0x2516>
   6835d: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   68362: 48 85 c0                     	testq	%rax, %rax
   68365: 75 e1                        	jne	0x68348 <f.102+0x2378>
   68367: e9 7a 01 00 00               	jmp	0x684e6 <f.102+0x2516>
   6836c: 48 85 c0                     	testq	%rax, %rax
   6836f: 0f 84 71 01 00 00            	je	0x684e6 <f.102+0x2516>
   68375: 48 8d 0d 54 88 fa ff         	leaq	-0x577ac(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   6837c: 48 c1 e8 02                  	shrq	$0x2, %rax
   68380: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   68384: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   6838b: 0f 83 55 01 00 00            	jae	0x684e6 <f.102+0x2516>
   68391: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   68396: 48 85 c0                     	testq	%rax, %rax
   68399: 75 e1                        	jne	0x6837c <f.102+0x23ac>
   6839b: e9 46 01 00 00               	jmp	0x684e6 <f.102+0x2516>
   683a0: 48 85 c0                     	testq	%rax, %rax
   683a3: 0f 84 3d 01 00 00            	je	0x684e6 <f.102+0x2516>
   683a9: 48 8d 0d 20 88 fa ff         	leaq	-0x577e0(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   683b0: 48 c1 e8 02                  	shrq	$0x2, %rax
   683b4: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   683b8: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   683bf: 0f 83 21 01 00 00            	jae	0x684e6 <f.102+0x2516>
   683c5: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   683ca: 48 85 c0                     	testq	%rax, %rax
   683cd: 75 e1                        	jne	0x683b0 <f.102+0x23e0>
   683cf: e9 12 01 00 00               	jmp	0x684e6 <f.102+0x2516>
   683d4: 48 85 c0                     	testq	%rax, %rax
   683d7: 0f 84 09 01 00 00            	je	0x684e6 <f.102+0x2516>
   683dd: 48 8d 0d ec 87 fa ff         	leaq	-0x57814(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   683e4: 48 c1 e8 02                  	shrq	$0x2, %rax
   683e8: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   683ec: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   683f3: 0f 83 ed 00 00 00            	jae	0x684e6 <f.102+0x2516>
   683f9: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   683fe: 48 85 c0                     	testq	%rax, %rax
   68401: 75 e1                        	jne	0x683e4 <f.102+0x2414>
   68403: e9 de 00 00 00               	jmp	0x684e6 <f.102+0x2516>
   68408: 48 85 c0                     	testq	%rax, %rax
   6840b: 0f 84 d5 00 00 00            	je	0x684e6 <f.102+0x2516>
   68411: 48 8d 0d b8 87 fa ff         	leaq	-0x57848(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   68418: 48 c1 e8 02                  	shrq	$0x2, %rax
   6841c: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   68420: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   68427: 0f 83 b9 00 00 00            	jae	0x684e6 <f.102+0x2516>
   6842d: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   68432: 48 85 c0                     	testq	%rax, %rax
   68435: 75 e1                        	jne	0x68418 <f.102+0x2448>
   68437: e9 aa 00 00 00               	jmp	0x684e6 <f.102+0x2516>
   6843c: 48 85 c0                     	testq	%rax, %rax
   6843f: 0f 84 a1 00 00 00            	je	0x684e6 <f.102+0x2516>
   68445: 48 8d 0d 84 87 fa ff         	leaq	-0x5787c(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   6844c: 48 c1 e8 02                  	shrq	$0x2, %rax
   68450: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   68454: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   6845b: 0f 83 85 00 00 00            	jae	0x684e6 <f.102+0x2516>
   68461: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   68466: 48 85 c0                     	testq	%rax, %rax
   68469: 75 e1                        	jne	0x6844c <f.102+0x247c>
   6846b: eb 79                        	jmp	0x684e6 <f.102+0x2516>
   6846d: 48 85 c0                     	testq	%rax, %rax
   68470: 74 74                        	je	0x684e6 <f.102+0x2516>
   68472: 48 8d 0d 57 87 fa ff         	leaq	-0x578a9(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   68479: 48 c1 e8 02                  	shrq	$0x2, %rax
   6847d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   68481: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   68488: 73 5c                        	jae	0x684e6 <f.102+0x2516>
   6848a: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   6848f: 48 85 c0                     	testq	%rax, %rax
   68492: 75 e5                        	jne	0x68479 <f.102+0x24a9>
   68494: eb 50                        	jmp	0x684e6 <f.102+0x2516>
   68496: 48 85 c0                     	testq	%rax, %rax
   68499: 74 4b                        	je	0x684e6 <f.102+0x2516>
   6849b: 48 8d 0d 2e 87 fa ff         	leaq	-0x578d2(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   684a2: 48 c1 e8 02                  	shrq	$0x2, %rax
   684a6: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   684aa: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   684b1: 73 33                        	jae	0x684e6 <f.102+0x2516>
   684b3: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   684b8: 48 85 c0                     	testq	%rax, %rax
   684bb: 75 e5                        	jne	0x684a2 <f.102+0x24d2>
   684bd: eb 27                        	jmp	0x684e6 <f.102+0x2516>
   684bf: 48 85 c0                     	testq	%rax, %rax
   684c2: 74 22                        	je	0x684e6 <f.102+0x2516>
   684c4: 48 8d 0d 05 87 fa ff         	leaq	-0x578fb(%rip), %rcx    # 0x10bd0 <native_gc_parents>
   684cb: 48 c1 e8 02                  	shrq	$0x2, %rax
   684cf: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   684d3: 48 81 fa e6 00 00 00         	cmpq	$0xe6, %rdx
   684da: 73 0a                        	jae	0x684e6 <f.102+0x2516>
   684dc: 48 8b 44 c1 f8               	movq	-0x8(%rcx,%rax,8), %rax
   684e1: 48 85 c0                     	testq	%rax, %rax
   684e4: 75 e5                        	jne	0x684cb <f.102+0x24fb>
   684e6: e8 e5 af 05 00               	callq	0xc34d0 <native_trap>
   684eb: cc                           	int3
   684ec: cc                           	int3
   684ed: cc                           	int3
   684ee: cc                           	int3
   684ef: cc                           	int3

