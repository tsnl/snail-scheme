(func $function244 (type $18) (param $0 (ref $type13)) (param $1 i32) (param $2 i32) (param $3 (ref $type13)) (result i32)
  (local $4 (ref $type13))
  (local $5 (ref $type21))
  (drop
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global353)
   )
  )
  (if (result i32)
   (i64.eqz
    (call $function107
     (local.get $3)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global803)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $0)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (ref.as_non_null
      (global.get $global780)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global796)
     )
    )
    (local.set $4
     (call $function221
      (struct.get $type32 0
       (struct.get $type31 1
        (ref.cast (ref $type31)
         (local.get $0)
        )
       )
      )
      (i32.const 0)
      (i32.const 1)
      (struct.get $type32 0
       (global.get $global802)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global371)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global353)
     )
    )
    (drop
     (call $function245
      (local.get $3)
      (i32.const 0)
      (i32.const 1)
      (if (result (ref $type13))
       (if (result i32)
        (i64.eq
         (call $function107
          (local.get $4)
         )
         (i64.const 1)
        )
        (then
         (if
          (i32.ne
           (struct.get $type13 0
            (local.get $4)
           )
           (i32.const 1)
          )
          (then
           (unreachable)
          )
         )
         (struct.get $type15 1
          (ref.cast (ref $type15)
           (local.get $4)
          )
         )
        )
        (else
         (i32.const 1)
        )
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global345)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global796)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.get $4)
          )
          (i32.const 6)
         )
         (then
          (unreachable)
         )
        )
        (local.set $4
         (call $function221
          (local.get $5)
          (i32.const 0)
          (i32.const 1)
          (struct.get $type32 0
           (struct.get $type31 2
            (ref.cast (ref $type31)
             (local.get $4)
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global371)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global353)
         )
        )
        (if (result (ref $type13))
         (if (result i32)
          (i64.eq
           (call $function107
            (local.get $4)
           )
           (i64.const 1)
          )
          (then
           (if
            (i32.ne
             (struct.get $type13 0
              (local.get $4)
             )
             (i32.const 1)
            )
            (then
             (unreachable)
            )
           )
           (struct.get $type15 1
            (ref.cast (ref $type15)
             (local.get $4)
            )
           )
          )
          (else
           (i32.const 1)
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global345)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $4)
            )
            (i32.const 6)
           )
           (then
            (unreachable)
           )
          )
          (struct.get $type32 0
           (struct.get $type31 2
            (ref.cast (ref $type31)
             (local.get $4)
            )
           )
          )
         )
         (else
          (struct.new $type15
           (i32.const 1)
           (i32.const 0)
          )
         )
        )
       )
       (else
        (struct.new $type15
         (i32.const 1)
         (i32.const 0)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $3)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type32 0
      (struct.get $type31 2
       (ref.cast (ref $type31)
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function244
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
