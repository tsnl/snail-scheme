(func $function244 (param $capture879 (ref $type13)) (param $capture880 i32) (param $initialized880 i32) (param $argument881 (ref $type13)) (result i32)
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local3 (ref null $type13))
  (local $local4 (ref null $type13))
  (local $local5 (ref null $type13))
  (local $local7 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local2 (ref null $type99))
  (local $local6 (ref null $type99))
  (local $local8 (ref null $type98))
  (local $local12 (ref null $type102))
  (local $local9 i32)
  (local $local10 i32)
  (local.set $local11
   (ref.as_non_null
    (local.get $argument881)
   )
  )
  (local.set $local12
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (if (result i32)
   (call $function109
    (struct.get $type102 1
     (ref.as_non_null
      (local.get $local12)
     )
    )
    (ref.as_non_null
     (local.get $local11)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $local5
     (ref.as_non_null
      (local.get $capture879)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (local.set $local4
     (call $function103
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local5)
      )
     )
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global780)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global803)
     )
    )
    (local.set $local3
     (call $function222
      (struct.get $type98 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local4)
      )
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local10
     (i32.const 0)
    )
    (local.set $local9
     (i32.const 1)
    )
    (drop
     (i32.const 0)
    )
    (if
     (i32.eqz
      (local.get $local9)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $local10)
    )
    (drop
     (call $function245
      (ref.as_non_null
       (local.get $argument881)
      )
      (local.get $local10)
      (local.get $local9)
      (ref.as_non_null
       (local.get $local3)
      )
     )
    )
    (local.set $local1
     (ref.as_non_null
      (local.get $argument881)
     )
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (local.set $local0
     (call $function104
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $initialized880)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture880)
    )
    (return_call $function244
     (ref.as_non_null
      (local.get $capture879)
     )
     (local.get $capture880)
     (local.get $initialized880)
     (ref.as_non_null
      (local.get $local0)
     )
    )
   )
  )
 )
