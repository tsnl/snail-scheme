(func $function252 (type $35) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 (ref $type13)) (result i64)
  (local $scratch (ref $type13))
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global905)
     )
    )
    (drop
     (call $function243
      (ref.as_non_null
       (global.get $global902)
      )
      (block (result i32)
       (if
        (i32.eqz
         (call $foreign26)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global873)
        )
       )
       (local.set $4
        (ref.as_non_null
         (global.get $global872)
        )
       )
       (if
        (i32.eqz
         (global.get $ready875)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global875)
        )
       )
       (i32.const 0)
      )
      (i32.const 1)
      (local.get $4)
     )
    )
    (local.set $4
     (call $function119
      (ref.as_non_null
       (global.get $global791)
      )
      (block (result (ref $type13))
       (drop
        (ref.as_non_null
         (global.get $global402)
        )
       )
       (local.set $scratch
        (call $function119
         (ref.as_non_null
          (global.get $global789)
         )
         (ref.as_non_null
          (global.get $global872)
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global402)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function252
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global406)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (call $function120
       (local.get $4)
       (ref.as_non_null
        (global.get $global903)
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
