(func $function117 (type $call98) (param $environment eqref) (param $argument396 (ref $type13)) (param $argument397 (ref $type13)) (result (ref $type13))
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local3 (ref null $type13))
  (local $local4 (ref null $type13))
  (local $local5 (ref null $type13))
  (local $local7 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local2 (ref null $type99))
  (local $local6 (ref null $type99))
  (local $local8 (ref null $type98))
  (local $local9 (ref null $type98))
  (local $local11 (ref null $type102))
  (local.set $local10
   (ref.as_non_null
    (local.get $argument396)
   )
  )
  (local.set $local11
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (if (result (ref $type13))
   (call $function109
    (struct.get $type102 1
     (ref.as_non_null
      (local.get $local11)
     )
    )
    (ref.as_non_null
     (local.get $local10)
    )
   )
   (then
    (ref.as_non_null
     (local.get $argument397)
    )
   )
   (else
    (local.set $local1
     (ref.as_non_null
      (local.get $argument396)
     )
    )
    (local.set $local2
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (local.set $local0
     (call $function103
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local2)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
     )
    )
    (local.set $local5
     (ref.as_non_null
      (local.get $argument396)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (local.set $local4
     (call $function104
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (ref.as_non_null
       (local.get $local5)
      )
     )
    )
    (local.set $local7
     (ref.as_non_null
      (local.get $argument397)
     )
    )
    (if
     (i32.eqz
      (global.get $ready395)
     )
     (then
      (unreachable)
     )
    )
    (local.set $local8
     (ref.as_non_null
      (global.get $global395)
     )
    )
    (local.set $local3
     (call $function117
      (struct.get $type98 1
       (ref.as_non_null
        (local.get $local8)
       )
      )
      (ref.as_non_null
       (local.get $local4)
      )
      (ref.as_non_null
       (local.get $local7)
      )
     )
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global340)
     )
    )
    (return_call $function102
     (struct.get $type98 1
      (ref.as_non_null
       (local.get $local9)
      )
     )
     (ref.as_non_null
      (local.get $local0)
     )
     (ref.as_non_null
      (local.get $local3)
     )
    )
   )
  )
 )
