(func $function240 (param $capture859 (ref $type13)) (param $capture861 (ref $type13)) (param $capture867 i32) (param $initialized867 i32) (param $argument868 (ref $type13)) (param $argument869 (ref $type13)) (param $argument870 (ref $type13)) (result (ref $type196))
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local2 (ref null $type13))
  (local $local3 (ref null $type13))
  (local $local4 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local8 (ref null $type13))
  (local $local11 (ref null $type13))
  (local $local12 (ref null $type13))
  (local $local14 (ref null $type13))
  (local $local15 (ref null $type13))
  (local $local17 (ref null $type13))
  (local $local21 (ref null $type13))
  (local $local26 (ref null $type13))
  (local $local29 (ref null $type13))
  (local $local30 (ref null $type13))
  (local $local32 (ref null $type13))
  (local $local33 (ref null $type13))
  (local $local34 (ref null $type13))
  (local $local35 (ref null $type13))
  (local $local36 (ref null $type13))
  (local $local38 (ref null $type13))
  (local $local40 (ref null $type13))
  (local $local5 (ref null $type99))
  (local $local13 (ref null $type99))
  (local $local16 (ref null $type99))
  (local $local31 (ref null $type99))
  (local $local37 (ref null $type99))
  (local $local7 (ref null $type102))
  (local $local18 (ref null $type102))
  (local $local22 (ref null $type102))
  (local $local27 (ref null $type102))
  (local $local9 (ref null $type98))
  (local $local10 (ref null $type98))
  (local $local39 (ref null $type98))
  (local $local41 (ref null $type98))
  (local $local23 (ref null $type200))
  (local $local28 (ref null $type196))
  (local $local42 (ref null $type207))
  (local $local43 (ref null $type201))
  (local $local19 i32)
  (local $local20 i32)
  (local $local24 i32)
  (local $local25 i32)
  (local.set $local26
   (ref.as_non_null
    (local.get $argument869)
   )
  )
  (local.set $local27
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (local.set $local25
   (call $function109
    (struct.get $type102 1
     (ref.as_non_null
      (local.get $local27)
     )
    )
    (ref.as_non_null
     (local.get $local26)
    )
   )
  )
  (local.set $local24
   (i32.const 1)
  )
  (if
   (i32.eqz
    (local.get $local24)
   )
   (then
    (unreachable)
   )
  )
  (if
   (if (result i32)
    (local.get $local25)
    (then
     (if
      (i32.eqz
       (local.get $local24)
      )
      (then
       (unreachable)
      )
     )
     (local.get $local25)
    )
    (else
     (local.set $local30
      (ref.as_non_null
       (local.get $capture859)
      )
     )
     (local.set $local31
      (ref.as_non_null
       (global.get $global345)
      )
     )
     (local.set $local29
      (call $function104
       (struct.get $type99 1
        (ref.as_non_null
         (local.get $local31)
        )
       )
       (ref.as_non_null
        (local.get $local30)
       )
      )
     )
     (local.set $local32
      (ref.as_non_null
       (local.get $argument870)
      )
     )
     (local.set $local36
      (ref.as_non_null
       (local.get $capture859)
      )
     )
     (local.set $local37
      (ref.as_non_null
       (global.get $global343)
      )
     )
     (local.set $local35
      (call $function103
       (struct.get $type99 1
        (ref.as_non_null
         (local.get $local37)
        )
       )
       (ref.as_non_null
        (local.get $local36)
       )
      )
     )
     (local.set $local38
      (ref.as_non_null
       (local.get $argument868)
      )
     )
     (local.set $local39
      (ref.as_non_null
       (global.get $global340)
      )
     )
     (local.set $local34
      (call $function102
       (struct.get $type98 1
        (ref.as_non_null
         (local.get $local39)
        )
       )
       (ref.as_non_null
        (local.get $local35)
       )
       (ref.as_non_null
        (local.get $local38)
       )
      )
     )
     (local.set $local40
      (ref.as_non_null
       (local.get $capture861)
      )
     )
     (local.set $local41
      (ref.as_non_null
       (global.get $global340)
      )
     )
     (local.set $local33
      (call $function102
       (struct.get $type98 1
        (ref.as_non_null
         (local.get $local41)
        )
       )
       (ref.as_non_null
        (local.get $local34)
       )
       (ref.as_non_null
        (local.get $local40)
       )
      )
     )
     (if
      (i32.eqz
       (global.get $ready858)
      )
      (then
       (unreachable)
      )
     )
     (local.set $local42
      (ref.as_non_null
       (global.get $global858)
      )
     )
     (local.set $local28
      (call $function239
       (struct.get $type207 1
        (ref.as_non_null
         (local.get $local42)
        )
       )
       (ref.as_non_null
        (local.get $local29)
       )
       (ref.as_non_null
        (local.get $local32)
       )
       (ref.as_non_null
        (local.get $local33)
       )
      )
     )
     (local.set $local43
      (ref.as_non_null
       (global.get $global773)
      )
     )
     (call $function213
      (struct.get $type201 1
       (ref.as_non_null
        (local.get $local43)
       )
      )
      (ref.as_non_null
       (local.get $local28)
      )
     )
    )
   )
   (then
    (drop
     (i32.const 0)
    )
    (local.set $local21
     (ref.as_non_null
      (local.get $argument869)
     )
    )
    (local.set $local22
     (ref.as_non_null
      (global.get $global367)
     )
    )
    (local.set $local20
     (call $function109
      (struct.get $type102 1
       (ref.as_non_null
        (local.get $local22)
       )
      )
      (ref.as_non_null
       (local.get $local21)
      )
     )
    )
    (local.set $local19
     (i32.eqz
      (local.get $local20)
     )
    )
    (local.set $local23
     (ref.as_non_null
      (global.get $global771)
     )
    )
    (return_call $function212
     (struct.get $type200 1
      (ref.as_non_null
       (local.get $local23)
      )
     )
     (local.get $local19)
    )
   )
   (else
    (local.set $local1
     (ref.as_non_null
      (local.get $argument868)
     )
    )
    (local.set $local6
     (ref.as_non_null
      (local.get $argument870)
     )
    )
    (local.set $local7
     (ref.as_non_null
      (global.get $global367)
     )
    )
    (local.set $local3
     (if (result (ref $type13))
      (call $function109
       (struct.get $type102 1
        (ref.as_non_null
         (local.get $local7)
        )
       )
       (ref.as_non_null
        (local.get $local6)
       )
      )
      (then
       (global.get $empty14)
      )
      (else
       (local.set $local4
        (ref.as_non_null
         (local.get $argument870)
        )
       )
       (local.set $local5
        (ref.as_non_null
         (global.get $global343)
        )
       )
       (call $function103
        (struct.get $type99 1
         (ref.as_non_null
          (local.get $local5)
         )
        )
        (ref.as_non_null
         (local.get $local4)
        )
       )
      )
     )
    )
    (local.set $local8
     (global.get $empty14)
    )
    (local.set $local9
     (ref.as_non_null
      (global.get $global340)
     )
    )
    (local.set $local2
     (call $function102
      (struct.get $type98 1
       (ref.as_non_null
        (local.get $local9)
       )
      )
      (ref.as_non_null
       (local.get $local3)
      )
      (ref.as_non_null
       (local.get $local8)
      )
     )
    )
    (local.set $local10
     (ref.as_non_null
      (global.get $global816)
     )
    )
    (local.set $local0
     (call $function225
      (struct.get $type98 1
       (ref.as_non_null
        (local.get $local10)
       )
      )
      (ref.as_non_null
       (local.get $local1)
      )
      (ref.as_non_null
       (local.get $local2)
      )
     )
    )
    (local.set $local12
     (ref.as_non_null
      (local.get $argument869)
     )
    )
    (local.set $local13
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (local.set $local11
     (call $function104
      (struct.get $type99 1
       (ref.as_non_null
        (local.get $local13)
       )
      )
      (ref.as_non_null
       (local.get $local12)
      )
     )
    )
    (local.set $local17
     (ref.as_non_null
      (local.get $argument870)
     )
    )
    (local.set $local18
     (ref.as_non_null
      (global.get $global367)
     )
    )
    (local.set $local14
     (if (result (ref $type13))
      (call $function109
       (struct.get $type102 1
        (ref.as_non_null
         (local.get $local18)
        )
       )
       (ref.as_non_null
        (local.get $local17)
       )
      )
      (then
       (global.get $empty14)
      )
      (else
       (local.set $local15
        (ref.as_non_null
         (local.get $argument870)
        )
       )
       (local.set $local16
        (ref.as_non_null
         (global.get $global345)
        )
       )
       (call $function104
        (struct.get $type99 1
         (ref.as_non_null
          (local.get $local16)
         )
        )
        (ref.as_non_null
         (local.get $local15)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $initialized867)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (local.get $capture867)
    )
    (return_call $function240
     (ref.as_non_null
      (local.get $capture859)
     )
     (ref.as_non_null
      (local.get $capture861)
     )
     (local.get $capture867)
     (local.get $initialized867)
     (ref.as_non_null
      (local.get $local0)
     )
     (ref.as_non_null
      (local.get $local11)
     )
     (ref.as_non_null
      (local.get $local14)
     )
    )
   )
  )
  (unreachable)
 )
