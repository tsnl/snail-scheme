(func $function245 (type $43) (param $0 (ref $type13)) (param $1 i32) (param $2 i32) (param $3 (ref $type13)) (result i32)
  (local $4 (ref $type31))
  (drop
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global353)
   )
  )
  (if (result i32)
   (i64.eqz
    (call $function107
     (local.get $3)
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global858)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $0)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $3)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function239
      (struct.get $type32 0
       (struct.get $type31 1
        (ref.cast (ref $type31)
         (local.get $0)
        )
       )
      )
      (struct.get $type32 0
       (struct.get $type31 1
        (local.tee $4
         (ref.cast (ref $type31)
          (local.get $3)
         )
        )
       )
      )
      (global.get $empty14)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function245
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (struct.get $type32 0
      (struct.get $type31 2
       (local.get $4)
      )
     )
    )
   )
  )
 )
