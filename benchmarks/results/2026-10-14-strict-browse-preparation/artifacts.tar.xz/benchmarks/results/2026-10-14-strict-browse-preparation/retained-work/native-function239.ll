define internal tailcc i64 @f.102(i64 %arg0, i64 %arg1, i64 %arg2) {
entry:
  %slot10 = alloca i32, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i32, align 8
  %slot13 = alloca i32, align 8
  %slot15 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot920 = alloca i32, align 8
  %slot1365 = alloca i64, align 8
  %slot1410 = alloca i32, align 8
  %roots = alloca { ptr, i64, i64, [15 x i64] }, align 8
  call void @native_roots_enter(ptr %roots, i64 15)
  %v1 = getelementptr i64, ptr %roots, i64 3
  store i64 %arg0, ptr %v1, align 1
  %v2 = getelementptr i64, ptr %roots, i64 4
  store i64 %arg1, ptr %v2, align 1
  %v3 = getelementptr i64, ptr %roots, i64 5
  store i64 %arg2, ptr %v3, align 1
  %v4 = getelementptr i64, ptr %roots, i64 6
  store i64 0, ptr %v4, align 1
  %v5 = getelementptr i64, ptr %roots, i64 7
  store i64 0, ptr %v5, align 1
  %v6 = getelementptr i64, ptr %roots, i64 8
  store i64 0, ptr %v6, align 1
  %v7 = getelementptr i64, ptr %roots, i64 9
  store i64 0, ptr %v7, align 1
  %v8 = getelementptr i64, ptr %roots, i64 10
  store i64 0, ptr %v8, align 1
  %v9 = getelementptr i64, ptr %roots, i64 11
  store i64 0, ptr %v9, align 1
  store i32 0, ptr %slot10, align 1
  store i64 0, ptr %slot11, align 1
  store i32 0, ptr %slot12, align 1
  store i32 0, ptr %slot13, align 1
  %v14 = getelementptr i64, ptr %roots, i64 12
  store i64 0, ptr %v14, align 1
  %v17 = load i64, ptr @g.5, align 1
  %v18 = icmp ne i64 %v17, 0
  br i1 %v18, label %ok20, label %trap19
trap19:
  call void @native_trap()
  unreachable
ok20:
  %v21 = load i64, ptr @g.4, align 1
  %v22 = icmp ne i64 %v21, 0
  br i1 %v22, label %ok24, label %trap23
trap23:
  call void @native_trap()
  unreachable
ok24:
  %v26 = load i64, ptr %v1, align 1
  %v27 = getelementptr i64, ptr %roots, i64 13
  store i64 %v26, ptr %v27, align 1
  %v28 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v28, align 1
  %v29 = call tailcc i64 @f.45(i64 %v26)
  %v30 = icmp eq i64 %v29, 0
  %v31 = zext i1 %v30 to i32
  %v36 = icmp ne i32 %v31, 0
  br i1 %v36, label %then35, label %else34
then35:
  %v37 = load i64, ptr @g.5, align 1
  %v38 = icmp ne i64 %v37, 0
  br i1 %v38, label %ok40, label %trap39
trap39:
  call void @native_trap()
  unreachable
ok40:
  %v41 = load i64, ptr @g.4, align 1
  %v42 = icmp ne i64 %v41, 0
  br i1 %v42, label %ok44, label %trap43
trap43:
  call void @native_trap()
  unreachable
ok44:
  %v47 = load i64, ptr %v2, align 1
  %v48 = getelementptr i64, ptr %roots, i64 13
  store i64 %v47, ptr %v48, align 1
  %v49 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v49, align 1
  %v50 = call tailcc i64 @f.45(i64 %v47)
  %v51 = icmp eq i64 %v50, 0
  %v52 = zext i1 %v51 to i32
  store i32 %v52, ptr %slot12, align 1
  %v53 = load i64, ptr @g.68, align 1
  %v54 = icmp ne i64 %v53, 0
  br i1 %v54, label %ok56, label %trap55
trap55:
  call void @native_trap()
  unreachable
ok56:
  %v57 = load i32, ptr %slot12, align 1
  store i32 %v57, ptr %slot45, align 1
  br label %block46
block46:
  %v58 = load i32, ptr %slot45, align 1
  %v63 = icmp ne i32 %v58, 0
  br i1 %v63, label %then62, label %else61
then62:
  %v64 = load i64, ptr @g.67, align 1
  %v65 = icmp ne i64 %v64, 0
  br i1 %v65, label %ok67, label %trap66
trap66:
  call void @native_trap()
  unreachable
ok67:
  store i64 %v64, ptr %slot59, align 1
  br label %block60
else61:
  %v68 = load i64, ptr @g.43, align 1
  %v69 = icmp ne i64 %v68, 0
  br i1 %v69, label %ok71, label %trap70
trap70:
  call void @native_trap()
  unreachable
ok71:
  store i64 %v68, ptr %slot59, align 1
  br label %block60
block60:
  %v72 = load i64, ptr %slot59, align 1
  call void @native_roots_leave(ptr %roots)
  ret i64 %v72
else34:
  %v73 = load i64, ptr @g.5, align 1
  %v74 = icmp ne i64 %v73, 0
  br i1 %v74, label %ok76, label %trap75
trap75:
  call void @native_trap()
  unreachable
ok76:
  %v77 = load i64, ptr @g.4, align 1
  %v78 = icmp ne i64 %v77, 0
  br i1 %v78, label %ok80, label %trap79
trap79:
  call void @native_trap()
  unreachable
ok80:
  %v81 = load i64, ptr %v2, align 1
  %v82 = getelementptr i64, ptr %roots, i64 13
  store i64 %v81, ptr %v82, align 1
  %v83 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v83, align 1
  %v84 = call tailcc i64 @f.45(i64 %v81)
  %v85 = icmp eq i64 %v84, 0
  %v86 = zext i1 %v85 to i32
  %v91 = icmp ne i32 %v86, 0
  br i1 %v91, label %then90, label %else89
then90:
  %v92 = load i64, ptr @g.179, align 1
  %v93 = icmp ne i64 %v92, 0
  br i1 %v93, label %ok95, label %trap94
trap94:
  call void @native_trap()
  unreachable
ok95:
  store i64 %v92, ptr %slot87, align 1
  br label %block88
else89:
  %v96 = load i64, ptr @g.9, align 1
  %v97 = icmp ne i64 %v96, 0
  br i1 %v97, label %ok99, label %trap98
trap98:
  call void @native_trap()
  unreachable
ok99:
  %v100 = load i64, ptr @g.46, align 1
  %v101 = icmp ne i64 %v100, 0
  br i1 %v101, label %ok103, label %trap102
trap102:
  call void @native_trap()
  unreachable
ok103:
  %v104 = load i64, ptr %v1, align 1
  %v105 = icmp ne i64 %v104, 0
  br i1 %v105, label %ok107, label %trap106
trap106:
  call void @native_trap()
  unreachable
ok107:
  %v108 = inttoptr i64 %v104 to ptr
  %v109 = getelementptr i64, ptr %v108, i64 1
  %v110 = load i32, ptr %v109, align 1
  %v111 = icmp ne i32 %v110, 6
  %v112 = zext i1 %v111 to i32
  %v116 = icmp ne i32 %v112, 0
  br i1 %v116, label %then115, label %else114
then115:
  call void @native_trap()
  unreachable
else114:
  br label %block113
block113:
  %v117 = load i64, ptr %v1, align 1
  %v118 = call i32 @native_ref_test(i64 %v117, i64 346, i32 0, i32 0)
  %v119 = icmp ne i32 %v118, 0
  br i1 %v119, label %ok121, label %trap120
trap120:
  call void @native_trap()
  unreachable
ok121:
  %v122 = icmp ne i64 %v117, 0
  br i1 %v122, label %ok124, label %trap123
trap123:
  call void @native_trap()
  unreachable
ok124:
  %v125 = inttoptr i64 %v117 to ptr
  %v126 = getelementptr i64, ptr %v125, i64 2
  %v127 = load i64, ptr %v126, align 1
  %v128 = icmp ne i64 %v127, 0
  br i1 %v128, label %ok130, label %trap129
trap129:
  call void @native_trap()
  unreachable
ok130:
  %v131 = inttoptr i64 %v127 to ptr
  %v132 = getelementptr i64, ptr %v131, i64 1
  %v133 = load i64, ptr %v132, align 1
  %v134 = load i64, ptr @g.182, align 1
  %v135 = icmp ne i64 %v134, 0
  br i1 %v135, label %ok137, label %trap136
trap136:
  call void @native_trap()
  unreachable
ok137:
  %v138 = getelementptr i64, ptr %roots, i64 13
  store i64 %v133, ptr %v138, align 1
  %v139 = getelementptr i64, ptr %roots, i64 14
  store i64 %v134, ptr %v139, align 1
  %v140 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v140, align 1
  %v141 = call tailcc i32 @f.47(i64 %v133, i64 %v134)
  store i32 %v141, ptr %slot10, align 1
  %v146 = icmp ne i32 %v141, 0
  br i1 %v146, label %then145, label %else144
then145:
  %v147 = load i32, ptr %slot10, align 1
  store i32 %v147, ptr %slot142, align 1
  br label %block143
else144:
  %v148 = load i64, ptr @g.9, align 1
  %v149 = icmp ne i64 %v148, 0
  br i1 %v149, label %ok151, label %trap150
trap150:
  call void @native_trap()
  unreachable
ok151:
  %v152 = load i64, ptr @g.46, align 1
  %v153 = icmp ne i64 %v152, 0
  br i1 %v153, label %ok155, label %trap154
trap154:
  call void @native_trap()
  unreachable
ok155:
  %v156 = load i64, ptr %v1, align 1
  %v157 = icmp ne i64 %v156, 0
  br i1 %v157, label %ok159, label %trap158
trap158:
  call void @native_trap()
  unreachable
ok159:
  %v160 = inttoptr i64 %v156 to ptr
  %v161 = getelementptr i64, ptr %v160, i64 1
  %v162 = load i32, ptr %v161, align 1
  %v163 = icmp ne i32 %v162, 6
  %v164 = zext i1 %v163 to i32
  %v168 = icmp ne i32 %v164, 0
  br i1 %v168, label %then167, label %else166
then167:
  call void @native_trap()
  unreachable
else166:
  br label %block165
block165:
  %v169 = load i64, ptr %v2, align 1
  %v170 = icmp ne i64 %v169, 0
  br i1 %v170, label %ok172, label %trap171
trap171:
  call void @native_trap()
  unreachable
ok172:
  %v173 = inttoptr i64 %v169 to ptr
  %v174 = getelementptr i64, ptr %v173, i64 1
  %v175 = load i32, ptr %v174, align 1
  %v176 = icmp ne i32 %v175, 6
  %v177 = zext i1 %v176 to i32
  %v181 = icmp ne i32 %v177, 0
  br i1 %v181, label %then180, label %else179
then180:
  call void @native_trap()
  unreachable
else179:
  br label %block178
block178:
  %v182 = load i64, ptr %v1, align 1
  %v183 = call i32 @native_ref_test(i64 %v182, i64 346, i32 0, i32 0)
  %v184 = icmp ne i32 %v183, 0
  br i1 %v184, label %ok186, label %trap185
trap185:
  call void @native_trap()
  unreachable
ok186:
  %v187 = icmp ne i64 %v182, 0
  br i1 %v187, label %ok189, label %trap188
trap188:
  call void @native_trap()
  unreachable
ok189:
  %v190 = inttoptr i64 %v182 to ptr
  %v191 = getelementptr i64, ptr %v190, i64 2
  %v192 = load i64, ptr %v191, align 1
  %v193 = icmp ne i64 %v192, 0
  br i1 %v193, label %ok195, label %trap194
trap194:
  call void @native_trap()
  unreachable
ok195:
  %v196 = inttoptr i64 %v192 to ptr
  %v197 = getelementptr i64, ptr %v196, i64 1
  %v198 = load i64, ptr %v197, align 1
  %v199 = load i64, ptr %v2, align 1
  %v200 = call i32 @native_ref_test(i64 %v199, i64 346, i32 0, i32 0)
  %v201 = icmp ne i32 %v200, 0
  br i1 %v201, label %ok203, label %trap202
trap202:
  call void @native_trap()
  unreachable
ok203:
  %v204 = icmp ne i64 %v199, 0
  br i1 %v204, label %ok206, label %trap205
trap205:
  call void @native_trap()
  unreachable
ok206:
  %v207 = inttoptr i64 %v199 to ptr
  %v208 = getelementptr i64, ptr %v207, i64 2
  %v209 = load i64, ptr %v208, align 1
  %v210 = icmp ne i64 %v209, 0
  br i1 %v210, label %ok212, label %trap211
trap211:
  call void @native_trap()
  unreachable
ok212:
  %v213 = inttoptr i64 %v209 to ptr
  %v214 = getelementptr i64, ptr %v213, i64 1
  %v215 = load i64, ptr %v214, align 1
  %v216 = getelementptr i64, ptr %roots, i64 13
  store i64 %v198, ptr %v216, align 1
  %v217 = getelementptr i64, ptr %roots, i64 14
  store i64 %v215, ptr %v217, align 1
  %v218 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v218, align 1
  %v219 = call tailcc i32 @f.47(i64 %v198, i64 %v215)
  store i32 %v219, ptr %slot142, align 1
  br label %block143
block143:
  %v220 = load i32, ptr %slot142, align 1
  %v225 = icmp ne i32 %v220, 0
  br i1 %v225, label %then224, label %else223
then224:
  %v226 = load i64, ptr @g.1, align 1
  %v227 = icmp ne i64 %v226, 0
  br i1 %v227, label %ok229, label %trap228
trap228:
  call void @native_trap()
  unreachable
ok229:
  %v230 = load i64, ptr %v1, align 1
  %v231 = icmp ne i64 %v230, 0
  br i1 %v231, label %ok233, label %trap232
trap232:
  call void @native_trap()
  unreachable
ok233:
  %v234 = inttoptr i64 %v230 to ptr
  %v235 = getelementptr i64, ptr %v234, i64 1
  %v236 = load i32, ptr %v235, align 1
  %v237 = icmp ne i32 %v236, 6
  %v238 = zext i1 %v237 to i32
  %v242 = icmp ne i32 %v238, 0
  br i1 %v242, label %then241, label %else240
then241:
  call void @native_trap()
  unreachable
else240:
  br label %block239
block239:
  %v243 = load i64, ptr %v1, align 1
  %v244 = call i32 @native_ref_test(i64 %v243, i64 346, i32 0, i32 0)
  %v245 = icmp ne i32 %v244, 0
  br i1 %v245, label %ok247, label %trap246
trap246:
  call void @native_trap()
  unreachable
ok247:
  %v248 = icmp ne i64 %v243, 0
  br i1 %v248, label %ok250, label %trap249
trap249:
  call void @native_trap()
  unreachable
ok250:
  %v251 = inttoptr i64 %v243 to ptr
  %v252 = getelementptr i64, ptr %v251, i64 3
  %v253 = load i64, ptr %v252, align 1
  %v254 = icmp ne i64 %v253, 0
  br i1 %v254, label %ok256, label %trap255
trap255:
  call void @native_trap()
  unreachable
ok256:
  %v257 = inttoptr i64 %v253 to ptr
  %v258 = getelementptr i64, ptr %v257, i64 1
  %v259 = load i64, ptr %v258, align 1
  store i64 %v259, ptr %v1, align 1
  %v260 = load i64, ptr @g.1, align 1
  %v261 = icmp ne i64 %v260, 0
  br i1 %v261, label %ok263, label %trap262
trap262:
  call void @native_trap()
  unreachable
ok263:
  %v264 = load i64, ptr %v2, align 1
  %v265 = icmp ne i64 %v264, 0
  br i1 %v265, label %ok267, label %trap266
trap266:
  call void @native_trap()
  unreachable
ok267:
  %v268 = inttoptr i64 %v264 to ptr
  %v269 = getelementptr i64, ptr %v268, i64 1
  %v270 = load i32, ptr %v269, align 1
  %v271 = icmp ne i32 %v270, 6
  %v272 = zext i1 %v271 to i32
  %v276 = icmp ne i32 %v272, 0
  br i1 %v276, label %then275, label %else274
then275:
  call void @native_trap()
  unreachable
else274:
  br label %block273
block273:
  %v277 = load i64, ptr %v2, align 1
  %v278 = call i32 @native_ref_test(i64 %v277, i64 346, i32 0, i32 0)
  %v279 = icmp ne i32 %v278, 0
  br i1 %v279, label %ok281, label %trap280
trap280:
  call void @native_trap()
  unreachable
ok281:
  %v282 = icmp ne i64 %v277, 0
  br i1 %v282, label %ok284, label %trap283
trap283:
  call void @native_trap()
  unreachable
ok284:
  %v285 = inttoptr i64 %v277 to ptr
  %v286 = getelementptr i64, ptr %v285, i64 3
  %v287 = load i64, ptr %v286, align 1
  %v288 = icmp ne i64 %v287, 0
  br i1 %v288, label %ok290, label %trap289
trap289:
  call void @native_trap()
  unreachable
ok290:
  %v291 = inttoptr i64 %v287 to ptr
  %v292 = getelementptr i64, ptr %v291, i64 1
  %v293 = load i64, ptr %v292, align 1
  store i64 %v293, ptr %v2, align 1
  br label %block25
else223:
  %v294 = load i64, ptr @g.9, align 1
  %v295 = icmp ne i64 %v294, 0
  br i1 %v295, label %ok297, label %trap296
trap296:
  call void @native_trap()
  unreachable
ok297:
  %v298 = load i64, ptr @g.46, align 1
  %v299 = icmp ne i64 %v298, 0
  br i1 %v299, label %ok301, label %trap300
trap300:
  call void @native_trap()
  unreachable
ok301:
  %v302 = load i64, ptr %v1, align 1
  %v303 = icmp ne i64 %v302, 0
  br i1 %v303, label %ok305, label %trap304
trap304:
  call void @native_trap()
  unreachable
ok305:
  %v306 = inttoptr i64 %v302 to ptr
  %v307 = getelementptr i64, ptr %v306, i64 1
  %v308 = load i32, ptr %v307, align 1
  %v309 = icmp ne i32 %v308, 6
  %v310 = zext i1 %v309 to i32
  %v314 = icmp ne i32 %v310, 0
  br i1 %v314, label %then313, label %else312
then313:
  call void @native_trap()
  unreachable
else312:
  br label %block311
block311:
  %v315 = load i64, ptr %v1, align 1
  %v316 = call i32 @native_ref_test(i64 %v315, i64 346, i32 0, i32 0)
  %v317 = icmp ne i32 %v316, 0
  br i1 %v317, label %ok319, label %trap318
trap318:
  call void @native_trap()
  unreachable
ok319:
  store i64 %v315, ptr %v4, align 1
  %v320 = icmp ne i64 %v315, 0
  br i1 %v320, label %ok322, label %trap321
trap321:
  call void @native_trap()
  unreachable
ok322:
  %v323 = inttoptr i64 %v315 to ptr
  %v324 = getelementptr i64, ptr %v323, i64 2
  %v325 = load i64, ptr %v324, align 1
  %v326 = icmp ne i64 %v325, 0
  br i1 %v326, label %ok328, label %trap327
trap327:
  call void @native_trap()
  unreachable
ok328:
  %v329 = inttoptr i64 %v325 to ptr
  %v330 = getelementptr i64, ptr %v329, i64 1
  %v331 = load i64, ptr %v330, align 1
  %v332 = load i64, ptr @g.183, align 1
  %v333 = icmp ne i64 %v332, 0
  br i1 %v333, label %ok335, label %trap334
trap334:
  call void @native_trap()
  unreachable
ok335:
  %v336 = getelementptr i64, ptr %roots, i64 13
  store i64 %v331, ptr %v336, align 1
  %v337 = getelementptr i64, ptr %roots, i64 14
  store i64 %v332, ptr %v337, align 1
  %v338 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v338, align 1
  %v339 = call tailcc i32 @f.47(i64 %v331, i64 %v332)
  %v344 = icmp ne i32 %v339, 0
  br i1 %v344, label %then343, label %else342
then343:
  %v345 = load i64, ptr @g.1, align 1
  %v346 = icmp ne i64 %v345, 0
  br i1 %v346, label %ok348, label %trap347
trap347:
  call void @native_trap()
  unreachable
ok348:
  %v349 = load i32, ptr @g.44, align 1
  %v350 = icmp eq i32 %v349, 0
  %v351 = zext i1 %v350 to i32
  %v355 = icmp ne i32 %v351, 0
  br i1 %v355, label %then354, label %else353
then354:
  call void @native_trap()
  unreachable
else353:
  br label %block352
block352:
  %v356 = load i64, ptr @g.38, align 1
  %v357 = icmp ne i64 %v356, 0
  br i1 %v357, label %ok359, label %trap358
trap358:
  call void @native_trap()
  unreachable
ok359:
  %v360 = load i64, ptr %v4, align 1
  %v361 = icmp ne i64 %v360, 0
  br i1 %v361, label %ok363, label %trap362
trap362:
  call void @native_trap()
  unreachable
ok363:
  %v364 = inttoptr i64 %v360 to ptr
  %v365 = getelementptr i64, ptr %v364, i64 3
  %v366 = load i64, ptr %v365, align 1
  %v367 = icmp ne i64 %v366, 0
  br i1 %v367, label %ok369, label %trap368
trap368:
  call void @native_trap()
  unreachable
ok369:
  %v370 = inttoptr i64 %v366 to ptr
  %v371 = getelementptr i64, ptr %v370, i64 1
  %v372 = load i64, ptr %v371, align 1
  %v373 = load i64, ptr %v2, align 1
  %v374 = load i64, ptr %v3, align 1
  %v375 = getelementptr i64, ptr %roots, i64 13
  store i64 %v372, ptr %v375, align 1
  %v376 = getelementptr i64, ptr %roots, i64 14
  store i64 %v373, ptr %v376, align 1
  %v377 = getelementptr i64, ptr %roots, i64 15
  store i64 %v374, ptr %v377, align 1
  %v378 = getelementptr i64, ptr %roots, i64 2
  store i64 13, ptr %v378, align 1
  %v379 = call tailcc i64 @f.102(i64 %v372, i64 %v373, i64 %v374)
  store i64 %v379, ptr %v6, align 1
  %v380 = load i64, ptr @g.48, align 1
  %v381 = icmp ne i64 %v380, 0
  br i1 %v381, label %ok383, label %trap382
trap382:
  call void @native_trap()
  unreachable
ok383:
  %v384 = load i64, ptr %v6, align 1
  %v385 = icmp ne i64 %v384, 0
  br i1 %v385, label %ok387, label %trap386
trap386:
  call void @native_trap()
  unreachable
ok387:
  %v388 = inttoptr i64 %v384 to ptr
  %v389 = getelementptr i64, ptr %v388, i64 1
  %v390 = load i32, ptr %v389, align 1
  %v395 = icmp ne i32 %v390, 0
  br i1 %v395, label %then394, label %else393
then394:
  %v396 = load i64, ptr %v6, align 1
  store i64 %v396, ptr %slot391, align 1
  br label %block392
else393:
  %v397 = load i64, ptr @g.1, align 1
  %v398 = icmp ne i64 %v397, 0
  br i1 %v398, label %ok400, label %trap399
trap399:
  call void @native_trap()
  unreachable
ok400:
  %v401 = load i64, ptr %v2, align 1
  %v402 = icmp ne i64 %v401, 0
  br i1 %v402, label %ok404, label %trap403
trap403:
  call void @native_trap()
  unreachable
ok404:
  %v405 = inttoptr i64 %v401 to ptr
  %v406 = getelementptr i64, ptr %v405, i64 1
  %v407 = load i32, ptr %v406, align 1
  %v408 = icmp ne i32 %v407, 6
  %v409 = zext i1 %v408 to i32
  %v413 = icmp ne i32 %v409, 0
  br i1 %v413, label %then412, label %else411
then412:
  call void @native_trap()
  unreachable
else411:
  br label %block410
block410:
  %v414 = load i64, ptr %v2, align 1
  %v415 = call i32 @native_ref_test(i64 %v414, i64 346, i32 0, i32 0)
  %v416 = icmp ne i32 %v415, 0
  br i1 %v416, label %ok418, label %trap417
trap417:
  call void @native_trap()
  unreachable
ok418:
  %v419 = icmp ne i64 %v414, 0
  br i1 %v419, label %ok421, label %trap420
trap420:
  call void @native_trap()
  unreachable
ok421:
  %v422 = inttoptr i64 %v414 to ptr
  %v423 = getelementptr i64, ptr %v422, i64 3
  %v424 = load i64, ptr %v423, align 1
  %v425 = icmp ne i64 %v424, 0
  br i1 %v425, label %ok427, label %trap426
trap426:
  call void @native_trap()
  unreachable
ok427:
  %v428 = inttoptr i64 %v424 to ptr
  %v429 = getelementptr i64, ptr %v428, i64 1
  %v430 = load i64, ptr %v429, align 1
  store i64 %v430, ptr %v8, align 1
  %v431 = load i32, ptr @g.44, align 1
  %v432 = icmp eq i32 %v431, 0
  %v433 = zext i1 %v432 to i32
  %v437 = icmp ne i32 %v433, 0
  br i1 %v437, label %then436, label %else435
then436:
  call void @native_trap()
  unreachable
else435:
  br label %block434
block434:
  %v438 = load i64, ptr @g.38, align 1
  %v439 = icmp ne i64 %v438, 0
  br i1 %v439, label %ok441, label %trap440
trap440:
  call void @native_trap()
  unreachable
ok441:
  %v442 = load i64, ptr %v4, align 1
  %v443 = icmp ne i64 %v442, 0
  br i1 %v443, label %ok445, label %trap444
trap444:
  call void @native_trap()
  unreachable
ok445:
  %v446 = inttoptr i64 %v442 to ptr
  %v447 = getelementptr i64, ptr %v446, i64 3
  %v448 = load i64, ptr %v447, align 1
  %v449 = icmp ne i64 %v448, 0
  br i1 %v449, label %ok451, label %trap450
trap450:
  call void @native_trap()
  unreachable
ok451:
  %v452 = inttoptr i64 %v448 to ptr
  %v453 = getelementptr i64, ptr %v452, i64 1
  %v454 = load i64, ptr %v453, align 1
  %v455 = load i64, ptr %v8, align 1
  %v456 = load i64, ptr %v3, align 1
  %v457 = getelementptr i64, ptr %roots, i64 13
  store i64 %v454, ptr %v457, align 1
  %v458 = getelementptr i64, ptr %roots, i64 14
  store i64 %v455, ptr %v458, align 1
  %v459 = getelementptr i64, ptr %roots, i64 15
  store i64 %v456, ptr %v459, align 1
  %v460 = getelementptr i64, ptr %roots, i64 2
  store i64 13, ptr %v460, align 1
  %v461 = call tailcc i64 @f.102(i64 %v454, i64 %v455, i64 %v456)
  store i64 %v461, ptr %v6, align 1
  %v462 = load i64, ptr @g.48, align 1
  %v463 = icmp ne i64 %v462, 0
  br i1 %v463, label %ok465, label %trap464
trap464:
  call void @native_trap()
  unreachable
ok465:
  %v466 = load i64, ptr %v6, align 1
  %v467 = icmp ne i64 %v466, 0
  br i1 %v467, label %ok469, label %trap468
trap468:
  call void @native_trap()
  unreachable
ok469:
  %v470 = inttoptr i64 %v466 to ptr
  %v471 = getelementptr i64, ptr %v470, i64 1
  %v472 = load i32, ptr %v471, align 1
  %v477 = icmp ne i32 %v472, 0
  br i1 %v477, label %then476, label %else475
then476:
  %v478 = load i64, ptr %v6, align 1
  store i64 %v478, ptr %slot473, align 1
  br label %block474
else475:
  %v479 = load i64, ptr @g.1, align 1
  %v480 = icmp ne i64 %v479, 0
  br i1 %v480, label %ok482, label %trap481
trap481:
  call void @native_trap()
  unreachable
ok482:
  %v483 = load i64, ptr %v2, align 1
  %v484 = icmp ne i64 %v483, 0
  br i1 %v484, label %ok486, label %trap485
trap485:
  call void @native_trap()
  unreachable
ok486:
  %v487 = inttoptr i64 %v483 to ptr
  %v488 = getelementptr i64, ptr %v487, i64 1
  %v489 = load i32, ptr %v488, align 1
  %v490 = icmp ne i32 %v489, 6
  %v491 = zext i1 %v490 to i32
  %v495 = icmp ne i32 %v491, 0
  br i1 %v495, label %then494, label %else493
then494:
  call void @native_trap()
  unreachable
else493:
  br label %block492
block492:
  %v496 = load i64, ptr %v2, align 1
  %v497 = call i32 @native_ref_test(i64 %v496, i64 346, i32 0, i32 0)
  %v498 = icmp ne i32 %v497, 0
  br i1 %v498, label %ok500, label %trap499
trap499:
  call void @native_trap()
  unreachable
ok500:
  %v501 = icmp ne i64 %v496, 0
  br i1 %v501, label %ok503, label %trap502
trap502:
  call void @native_trap()
  unreachable
ok503:
  %v504 = inttoptr i64 %v496 to ptr
  %v505 = getelementptr i64, ptr %v504, i64 3
  %v506 = load i64, ptr %v505, align 1
  %v507 = icmp ne i64 %v506, 0
  br i1 %v507, label %ok509, label %trap508
trap508:
  call void @native_trap()
  unreachable
ok509:
  %v510 = inttoptr i64 %v506 to ptr
  %v511 = getelementptr i64, ptr %v510, i64 1
  %v512 = load i64, ptr %v511, align 1
  store i64 %v512, ptr %v2, align 1
  br label %block25
block474:
  %v513 = load i64, ptr %slot473, align 1
  store i64 %v513, ptr %slot391, align 1
  br label %block392
block392:
  %v514 = load i64, ptr %slot391, align 1
  store i64 %v514, ptr %slot340, align 1
  br label %block341
else342:
  %v515 = load i64, ptr @g.9, align 1
  %v516 = icmp ne i64 %v515, 0
  br i1 %v516, label %ok518, label %trap517
trap517:
  call void @native_trap()
  unreachable
ok518:
  %v519 = load i64, ptr @g.61, align 1
  %v520 = icmp ne i64 %v519, 0
  br i1 %v520, label %ok522, label %trap521
trap521:
  call void @native_trap()
  unreachable
ok522:
  %v523 = load i64, ptr @g.4, align 1
  %v524 = icmp ne i64 %v523, 0
  br i1 %v524, label %ok526, label %trap525
trap525:
  call void @native_trap()
  unreachable
ok526:
  %v527 = load i64, ptr %v4, align 1
  %v528 = icmp ne i64 %v527, 0
  br i1 %v528, label %ok530, label %trap529
trap529:
  call void @native_trap()
  unreachable
ok530:
  %v531 = inttoptr i64 %v527 to ptr
  %v532 = getelementptr i64, ptr %v531, i64 2
  %v533 = load i64, ptr %v532, align 1
  %v534 = icmp ne i64 %v533, 0
  br i1 %v534, label %ok536, label %trap535
trap535:
  call void @native_trap()
  unreachable
ok536:
  %v537 = inttoptr i64 %v533 to ptr
  %v538 = getelementptr i64, ptr %v537, i64 1
  %v539 = load i64, ptr %v538, align 1
  %v540 = getelementptr i64, ptr %roots, i64 13
  store i64 %v539, ptr %v540, align 1
  %v541 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v541, align 1
  %v542 = call tailcc i64 @f.45(i64 %v539)
  %v543 = icmp eq i64 %v542, 6
  %v544 = zext i1 %v543 to i32
  %v549 = icmp ne i32 %v544, 0
  br i1 %v549, label %then548, label %else547
then548:
  %v550 = load i64, ptr @g.9, align 1
  %v551 = icmp ne i64 %v550, 0
  br i1 %v551, label %ok553, label %trap552
trap552:
  call void @native_trap()
  unreachable
ok553:
  %v554 = load i64, ptr @g.61, align 1
  %v555 = icmp ne i64 %v554, 0
  br i1 %v555, label %ok557, label %trap556
trap556:
  call void @native_trap()
  unreachable
ok557:
  %v558 = load i64, ptr @g.4, align 1
  %v559 = icmp ne i64 %v558, 0
  br i1 %v559, label %ok561, label %trap560
trap560:
  call void @native_trap()
  unreachable
ok561:
  %v562 = load i64, ptr %v2, align 1
  %v563 = icmp ne i64 %v562, 0
  br i1 %v563, label %ok565, label %trap564
trap564:
  call void @native_trap()
  unreachable
ok565:
  %v566 = inttoptr i64 %v562 to ptr
  %v567 = getelementptr i64, ptr %v566, i64 1
  %v568 = load i32, ptr %v567, align 1
  %v569 = icmp ne i32 %v568, 6
  %v570 = zext i1 %v569 to i32
  %v574 = icmp ne i32 %v570, 0
  br i1 %v574, label %then573, label %else572
then573:
  call void @native_trap()
  unreachable
else572:
  br label %block571
block571:
  %v577 = load i64, ptr %v2, align 1
  %v578 = call i32 @native_ref_test(i64 %v577, i64 346, i32 0, i32 0)
  %v579 = icmp ne i32 %v578, 0
  br i1 %v579, label %ok581, label %trap580
trap580:
  call void @native_trap()
  unreachable
ok581:
  %v582 = icmp ne i64 %v577, 0
  br i1 %v582, label %ok584, label %trap583
trap583:
  call void @native_trap()
  unreachable
ok584:
  %v585 = inttoptr i64 %v577 to ptr
  %v586 = getelementptr i64, ptr %v585, i64 2
  %v587 = load i64, ptr %v586, align 1
  %v588 = icmp ne i64 %v587, 0
  br i1 %v588, label %ok590, label %trap589
trap589:
  call void @native_trap()
  unreachable
ok590:
  %v591 = inttoptr i64 %v587 to ptr
  %v592 = getelementptr i64, ptr %v591, i64 1
  %v593 = load i64, ptr %v592, align 1
  %v594 = getelementptr i64, ptr %roots, i64 13
  store i64 %v593, ptr %v594, align 1
  %v595 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v595, align 1
  %v596 = call tailcc i64 @f.45(i64 %v593)
  %v597 = icmp eq i64 %v596, 6
  %v598 = zext i1 %v597 to i32
  store i32 %v598, ptr %slot13, align 1
  %v599 = load i64, ptr @g.68, align 1
  %v600 = icmp ne i64 %v599, 0
  br i1 %v600, label %ok602, label %trap601
trap601:
  call void @native_trap()
  unreachable
ok602:
  %v603 = load i64, ptr @g.48, align 1
  %v604 = icmp ne i64 %v603, 0
  br i1 %v604, label %ok606, label %trap605
trap605:
  call void @native_trap()
  unreachable
ok606:
  %v607 = load i32, ptr %slot13, align 1
  store i32 %v607, ptr %slot575, align 1
  br label %block576
block576:
  %v608 = load i32, ptr %slot575, align 1
  %v613 = icmp ne i32 %v608, 0
  br i1 %v613, label %then612, label %else611
then612:
  %v614 = load i64, ptr @g.67, align 1
  %v615 = icmp ne i64 %v614, 0
  br i1 %v615, label %ok617, label %trap616
trap616:
  call void @native_trap()
  unreachable
ok617:
  store i64 %v614, ptr %slot609, align 1
  br label %block610
else611:
  %v618 = load i64, ptr @g.43, align 1
  %v619 = icmp ne i64 %v618, 0
  br i1 %v619, label %ok621, label %trap620
trap620:
  call void @native_trap()
  unreachable
ok621:
  store i64 %v618, ptr %slot609, align 1
  br label %block610
block610:
  %v622 = load i64, ptr %slot609, align 1
  %v623 = icmp ne i64 %v622, 0
  br i1 %v623, label %ok625, label %trap624
trap624:
  call void @native_trap()
  unreachable
ok625:
  %v626 = inttoptr i64 %v622 to ptr
  %v627 = getelementptr i64, ptr %v626, i64 1
  %v628 = load i32, ptr %v627, align 1
  %v633 = icmp ne i32 %v628, 0
  br i1 %v633, label %then632, label %else631
then632:
  %v634 = load i64, ptr @g.9, align 1
  %v635 = icmp ne i64 %v634, 0
  br i1 %v635, label %ok637, label %trap636
trap636:
  call void @native_trap()
  unreachable
ok637:
  %v638 = load i64, ptr %v2, align 1
  %v639 = icmp ne i64 %v638, 0
  br i1 %v639, label %ok641, label %trap640
trap640:
  call void @native_trap()
  unreachable
ok641:
  %v642 = inttoptr i64 %v638 to ptr
  %v643 = getelementptr i64, ptr %v642, i64 1
  %v644 = load i32, ptr %v643, align 1
  %v645 = icmp ne i32 %v644, 6
  %v646 = zext i1 %v645 to i32
  %v650 = icmp ne i32 %v646, 0
  br i1 %v650, label %then649, label %else648
then649:
  call void @native_trap()
  unreachable
else648:
  br label %block647
block647:
  %v651 = load i64, ptr %v2, align 1
  %v652 = call i32 @native_ref_test(i64 %v651, i64 346, i32 0, i32 0)
  %v653 = icmp ne i32 %v652, 0
  br i1 %v653, label %ok655, label %trap654
trap654:
  call void @native_trap()
  unreachable
ok655:
  %v656 = icmp ne i64 %v651, 0
  br i1 %v656, label %ok658, label %trap657
trap657:
  call void @native_trap()
  unreachable
ok658:
  %v659 = inttoptr i64 %v651 to ptr
  %v660 = getelementptr i64, ptr %v659, i64 2
  %v661 = load i64, ptr %v660, align 1
  %v662 = icmp ne i64 %v661, 0
  br i1 %v662, label %ok664, label %trap663
trap663:
  call void @native_trap()
  unreachable
ok664:
  %v665 = inttoptr i64 %v661 to ptr
  %v666 = getelementptr i64, ptr %v665, i64 1
  %v667 = load i64, ptr %v666, align 1
  store i64 %v667, ptr %v1, align 1
  %v668 = load i32, ptr @g.44, align 1
  %v669 = icmp eq i32 %v668, 0
  %v670 = zext i1 %v669 to i32
  %v674 = icmp ne i32 %v670, 0
  br i1 %v674, label %then673, label %else672
then673:
  call void @native_trap()
  unreachable
else672:
  br label %block671
block671:
  %v675 = load i64, ptr @g.38, align 1
  %v676 = icmp ne i64 %v675, 0
  br i1 %v676, label %ok678, label %trap677
trap677:
  call void @native_trap()
  unreachable
ok678:
  %v681 = load i64, ptr %v4, align 1
  %v682 = icmp ne i64 %v681, 0
  br i1 %v682, label %ok684, label %trap683
trap683:
  call void @native_trap()
  unreachable
ok684:
  %v685 = inttoptr i64 %v681 to ptr
  %v686 = getelementptr i64, ptr %v685, i64 2
  %v687 = load i64, ptr %v686, align 1
  %v688 = icmp ne i64 %v687, 0
  br i1 %v688, label %ok690, label %trap689
trap689:
  call void @native_trap()
  unreachable
ok690:
  %v691 = inttoptr i64 %v687 to ptr
  %v692 = getelementptr i64, ptr %v691, i64 1
  %v693 = load i64, ptr %v692, align 1
  %v694 = load i64, ptr %v1, align 1
  %v695 = load i64, ptr %v3, align 1
  %v696 = getelementptr i64, ptr %roots, i64 13
  store i64 %v693, ptr %v696, align 1
  %v697 = getelementptr i64, ptr %roots, i64 14
  store i64 %v694, ptr %v697, align 1
  %v698 = getelementptr i64, ptr %roots, i64 15
  store i64 %v695, ptr %v698, align 1
  %v699 = getelementptr i64, ptr %roots, i64 2
  store i64 13, ptr %v699, align 1
  %v700 = call tailcc i64 @f.102(i64 %v693, i64 %v694, i64 %v695)
  store i64 %v700, ptr %v14, align 1
  %v701 = load i64, ptr @g.48, align 1
  %v702 = icmp ne i64 %v701, 0
  br i1 %v702, label %ok704, label %trap703
trap703:
  call void @native_trap()
  unreachable
ok704:
  %v705 = load i64, ptr %v14, align 1
  store i64 %v705, ptr %slot679, align 1
  br label %block680
block680:
  %v706 = load i64, ptr %slot679, align 1
  %v707 = icmp ne i64 %v706, 0
  br i1 %v707, label %ok709, label %trap708
trap708:
  call void @native_trap()
  unreachable
ok709:
  %v710 = inttoptr i64 %v706 to ptr
  %v711 = getelementptr i64, ptr %v710, i64 1
  %v712 = load i32, ptr %v711, align 1
  %v717 = icmp ne i32 %v712, 0
  br i1 %v717, label %then716, label %else715
then716:
  %v718 = load i64, ptr %v4, align 1
  %v719 = icmp ne i64 %v718, 0
  br i1 %v719, label %ok721, label %trap720
trap720:
  call void @native_trap()
  unreachable
ok721:
  %v722 = inttoptr i64 %v718 to ptr
  %v723 = getelementptr i64, ptr %v722, i64 3
  %v724 = load i64, ptr %v723, align 1
  %v725 = icmp ne i64 %v724, 0
  br i1 %v725, label %ok727, label %trap726
trap726:
  call void @native_trap()
  unreachable
ok727:
  %v728 = inttoptr i64 %v724 to ptr
  %v729 = getelementptr i64, ptr %v728, i64 1
  %v730 = load i64, ptr %v729, align 1
  store i64 %v730, ptr %v1, align 1
  %v731 = load i64, ptr @g.1, align 1
  %v732 = icmp ne i64 %v731, 0
  br i1 %v732, label %ok734, label %trap733
trap733:
  call void @native_trap()
  unreachable
ok734:
  %v735 = load i64, ptr %v2, align 1
  %v736 = icmp ne i64 %v735, 0
  br i1 %v736, label %ok738, label %trap737
trap737:
  call void @native_trap()
  unreachable
ok738:
  %v739 = inttoptr i64 %v735 to ptr
  %v740 = getelementptr i64, ptr %v739, i64 1
  %v741 = load i32, ptr %v740, align 1
  %v742 = icmp ne i32 %v741, 6
  %v743 = zext i1 %v742 to i32
  %v747 = icmp ne i32 %v743, 0
  br i1 %v747, label %then746, label %else745
then746:
  call void @native_trap()
  unreachable
else745:
  br label %block744
block744:
  %v748 = load i64, ptr %v2, align 1
  %v749 = call i32 @native_ref_test(i64 %v748, i64 346, i32 0, i32 0)
  %v750 = icmp ne i32 %v749, 0
  br i1 %v750, label %ok752, label %trap751
trap751:
  call void @native_trap()
  unreachable
ok752:
  %v753 = icmp ne i64 %v748, 0
  br i1 %v753, label %ok755, label %trap754
trap754:
  call void @native_trap()
  unreachable
ok755:
  %v756 = inttoptr i64 %v748 to ptr
  %v757 = getelementptr i64, ptr %v756, i64 3
  %v758 = load i64, ptr %v757, align 1
  %v759 = icmp ne i64 %v758, 0
  br i1 %v759, label %ok761, label %trap760
trap760:
  call void @native_trap()
  unreachable
ok761:
  %v762 = inttoptr i64 %v758 to ptr
  %v763 = getelementptr i64, ptr %v762, i64 1
  %v764 = load i64, ptr %v763, align 1
  store i64 %v764, ptr %v2, align 1
  br label %block25
else715:
  %v765 = load i64, ptr @g.43, align 1
  %v766 = icmp ne i64 %v765, 0
  br i1 %v766, label %ok768, label %trap767
trap767:
  call void @native_trap()
  unreachable
ok768:
  store i64 %v765, ptr %slot713, align 1
  br label %block714
block714:
  %v769 = load i64, ptr %slot713, align 1
  store i64 %v769, ptr %slot629, align 1
  br label %block630
else631:
  %v770 = load i64, ptr @g.43, align 1
  %v771 = icmp ne i64 %v770, 0
  br i1 %v771, label %ok773, label %trap772
trap772:
  call void @native_trap()
  unreachable
ok773:
  store i64 %v770, ptr %slot629, align 1
  br label %block630
block630:
  %v774 = load i64, ptr %slot629, align 1
  store i64 %v774, ptr %slot545, align 1
  br label %block546
else547:
  %v775 = load i64, ptr @g.9, align 1
  %v776 = icmp ne i64 %v775, 0
  br i1 %v776, label %ok778, label %trap777
trap777:
  call void @native_trap()
  unreachable
ok778:
  %v779 = load i64, ptr @g.69, align 1
  %v780 = icmp ne i64 %v779, 0
  br i1 %v780, label %ok782, label %trap781
trap781:
  call void @native_trap()
  unreachable
ok782:
  %v783 = load i64, ptr %v4, align 1
  %v784 = icmp ne i64 %v783, 0
  br i1 %v784, label %ok786, label %trap785
trap785:
  call void @native_trap()
  unreachable
ok786:
  %v787 = inttoptr i64 %v783 to ptr
  %v788 = getelementptr i64, ptr %v787, i64 2
  %v789 = load i64, ptr %v788, align 1
  %v790 = icmp ne i64 %v789, 0
  br i1 %v790, label %ok792, label %trap791
trap791:
  call void @native_trap()
  unreachable
ok792:
  %v793 = inttoptr i64 %v789 to ptr
  %v794 = getelementptr i64, ptr %v793, i64 1
  %v795 = load i64, ptr %v794, align 1
  store i64 %v795, ptr %v1, align 1
  %v796 = icmp ne i64 %v795, 0
  br i1 %v796, label %ok798, label %trap797
trap797:
  call void @native_trap()
  unreachable
ok798:
  %v799 = inttoptr i64 %v795 to ptr
  %v800 = getelementptr i64, ptr %v799, i64 1
  %v801 = load i32, ptr %v800, align 1
  %v802 = icmp ne i32 %v801, 4
  %v803 = zext i1 %v802 to i32
  %v807 = icmp ne i32 %v803, 0
  br i1 %v807, label %then806, label %else805
then806:
  call void @native_trap()
  unreachable
else805:
  br label %block804
block804:
  %v808 = load i64, ptr @g.58, align 1
  %v809 = icmp ne i64 %v808, 0
  br i1 %v809, label %ok811, label %trap810
trap810:
  call void @native_trap()
  unreachable
ok811:
  %v812 = load i64, ptr %v1, align 1
  %v813 = call i32 @native_ref_test(i64 %v812, i64 794, i32 0, i32 0)
  %v814 = icmp ne i32 %v813, 0
  br i1 %v814, label %ok816, label %trap815
trap815:
  call void @native_trap()
  unreachable
ok816:
  %v817 = icmp ne i64 %v812, 0
  br i1 %v817, label %ok819, label %trap818
trap818:
  call void @native_trap()
  unreachable
ok819:
  %v820 = inttoptr i64 %v812 to ptr
  %v821 = getelementptr i64, ptr %v820, i64 2
  %v822 = load i64, ptr %v821, align 1
  %v823 = icmp ne i64 %v822, 0
  br i1 %v823, label %ok825, label %trap824
trap824:
  call void @native_trap()
  unreachable
ok825:
  %v826 = inttoptr i64 %v822 to ptr
  %v827 = getelementptr i64, ptr %v826, i64 1
  %v828 = load i32, ptr %v827, align 1
  store i32 %v828, ptr %slot10, align 1
  %v829 = getelementptr i64, ptr %roots, i64 2
  store i64 10, ptr %v829, align 1
  %v830 = call tailcc i64 @f.6(i32 %v828)
  store i64 %v830, ptr %slot11, align 1
  %v831 = load i64, ptr @g.19, align 1
  %v832 = icmp ne i64 %v831, 0
  br i1 %v832, label %ok834, label %trap833
trap833:
  call void @native_trap()
  unreachable
ok834:
  %v835 = load i64, ptr %slot11, align 1
  %v836 = icmp ugt i64 %v835, 4294967294
  %v837 = zext i1 %v836 to i32
  %v841 = icmp ne i32 %v837, 0
  br i1 %v841, label %then840, label %else839
then840:
  call void @native_trap()
  unreachable
else839:
  br label %block838
block838:
  %v842 = load i32, ptr %slot10, align 1
  %v843 = load i64, ptr %slot11, align 1
  %v844 = load i64, ptr %slot11, align 1
  %v845 = trunc i64 %v844 to i32
  %v846 = getelementptr i64, ptr %roots, i64 2
  store i64 10, ptr %v846, align 1
  %v847 = call tailcc i64 @f.23(i32 %v845)
  %v848 = getelementptr i64, ptr %roots, i64 13
  store i64 %v847, ptr %v848, align 1
  %v849 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v849, align 1
  %v850 = call tailcc i64 @f.32(i32 %v842, i64 %v843, i64 %v847, i32 0, i32 1, i64 0)
  store i64 %v850, ptr %v7, align 1
  %v851 = icmp ne i64 %v850, 0
  br i1 %v851, label %ok853, label %trap852
trap852:
  call void @native_trap()
  unreachable
ok853:
  %v854 = inttoptr i64 %v850 to ptr
  %v855 = getelementptr i64, ptr %v854, i64 2
  %v856 = load i32, ptr %v855, align 1
  %v857 = zext i32 %v856 to i64
  %v858 = icmp eq i64 %v857, 0
  %v859 = zext i1 %v858 to i32
  %v863 = icmp ne i32 %v859, 0
  br i1 %v863, label %then862, label %else861
then862:
  call void @native_trap()
  unreachable
else861:
  br label %block860
block860:
  %v864 = load i64, ptr %v7, align 1
  %v865 = icmp ne i64 %v864, 0
  br i1 %v865, label %ok867, label %trap866
trap866:
  call void @native_trap()
  unreachable
ok867:
  %v868 = inttoptr i64 %v864 to ptr
  %v869 = getelementptr i64, ptr %v868, i64 3
  %v870 = load i64, ptr %v869, align 1
  %v871 = call ptr @native_array_slot(i64 %v870, i32 0, i32 4)
  %v872 = load i32, ptr %v871, align 1
  %v873 = icmp eq i32 %v872, 63
  %v874 = zext i1 %v873 to i32
  %v879 = icmp ne i32 %v874, 0
  br i1 %v879, label %then878, label %else877
then878:
  %v880 = load i64, ptr @g.9, align 1
  %v881 = icmp ne i64 %v880, 0
  br i1 %v881, label %ok883, label %trap882
trap882:
  call void @native_trap()
  unreachable
ok883:
  %v884 = load i64, ptr @g.62, align 1
  %v885 = icmp ne i64 %v884, 0
  br i1 %v885, label %ok887, label %trap886
trap886:
  call void @native_trap()
  unreachable
ok887:
  %v888 = load i64, ptr %v4, align 1
  %v889 = icmp ne i64 %v888, 0
  br i1 %v889, label %ok891, label %trap890
trap890:
  call void @native_trap()
  unreachable
ok891:
  %v892 = inttoptr i64 %v888 to ptr
  %v893 = getelementptr i64, ptr %v892, i64 2
  %v894 = load i64, ptr %v893, align 1
  %v895 = icmp ne i64 %v894, 0
  br i1 %v895, label %ok897, label %trap896
trap896:
  call void @native_trap()
  unreachable
ok897:
  %v898 = inttoptr i64 %v894 to ptr
  %v899 = getelementptr i64, ptr %v898, i64 1
  %v900 = load i64, ptr %v899, align 1
  %v901 = load i64, ptr %v3, align 1
  %v902 = getelementptr i64, ptr %roots, i64 13
  store i64 %v900, ptr %v902, align 1
  %v903 = getelementptr i64, ptr %roots, i64 14
  store i64 %v901, ptr %v903, align 1
  %v904 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v904, align 1
  %v905 = call tailcc i64 @f.53(i64 %v900, i64 %v901)
  store i64 %v905, ptr %v1, align 1
  %v906 = load i64, ptr @g.39, align 1
  %v907 = icmp ne i64 %v906, 0
  br i1 %v907, label %ok909, label %trap908
trap908:
  call void @native_trap()
  unreachable
ok909:
  %v910 = load i64, ptr @g.4, align 1
  %v911 = icmp ne i64 %v910, 0
  br i1 %v911, label %ok913, label %trap912
trap912:
  call void @native_trap()
  unreachable
ok913:
  %v914 = load i64, ptr %v1, align 1
  %v915 = getelementptr i64, ptr %roots, i64 13
  store i64 %v914, ptr %v915, align 1
  %v916 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v916, align 1
  %v917 = call tailcc i64 @f.45(i64 %v914)
  %v918 = icmp eq i64 %v917, 1
  %v919 = zext i1 %v918 to i32
  %v924 = icmp ne i32 %v919, 0
  br i1 %v924, label %then923, label %else922
then923:
  %v925 = load i64, ptr %v1, align 1
  %v926 = icmp ne i64 %v925, 0
  br i1 %v926, label %ok928, label %trap927
trap927:
  call void @native_trap()
  unreachable
ok928:
  %v929 = inttoptr i64 %v925 to ptr
  %v930 = getelementptr i64, ptr %v929, i64 1
  %v931 = load i32, ptr %v930, align 1
  %v932 = icmp ne i32 %v931, 1
  %v933 = zext i1 %v932 to i32
  %v937 = icmp ne i32 %v933, 0
  br i1 %v937, label %then936, label %else935
then936:
  call void @native_trap()
  unreachable
else935:
  br label %block934
block934:
  %v938 = load i64, ptr %v1, align 1
  %v939 = call i32 @native_ref_test(i64 %v938, i64 330, i32 0, i32 0)
  %v940 = icmp ne i32 %v939, 0
  br i1 %v940, label %ok942, label %trap941
trap941:
  call void @native_trap()
  unreachable
ok942:
  %v943 = icmp ne i64 %v938, 0
  br i1 %v943, label %ok945, label %trap944
trap944:
  call void @native_trap()
  unreachable
ok945:
  %v946 = inttoptr i64 %v938 to ptr
  %v947 = getelementptr i64, ptr %v946, i64 2
  %v948 = load i32, ptr %v947, align 1
  store i32 %v948, ptr %slot920, align 1
  br label %block921
else922:
  store i32 1, ptr %slot920, align 1
  br label %block921
block921:
  %v949 = load i32, ptr %slot920, align 1
  %v953 = icmp ne i32 %v949, 0
  br i1 %v953, label %then952, label %else951
then952:
  %v954 = load i64, ptr @g.1, align 1
  %v955 = icmp ne i64 %v954, 0
  br i1 %v955, label %ok957, label %trap956
trap956:
  call void @native_trap()
  unreachable
ok957:
  %v958 = load i64, ptr @g.0, align 1
  %v959 = icmp ne i64 %v958, 0
  br i1 %v959, label %ok961, label %trap960
trap960:
  call void @native_trap()
  unreachable
ok961:
  %v962 = load i64, ptr %v1, align 1
  %v963 = icmp ne i64 %v962, 0
  br i1 %v963, label %ok965, label %trap964
trap964:
  call void @native_trap()
  unreachable
ok965:
  %v966 = inttoptr i64 %v962 to ptr
  %v967 = getelementptr i64, ptr %v966, i64 1
  %v968 = load i32, ptr %v967, align 1
  %v969 = icmp ne i32 %v968, 6
  %v970 = zext i1 %v969 to i32
  %v974 = icmp ne i32 %v970, 0
  br i1 %v974, label %then973, label %else972
then973:
  call void @native_trap()
  unreachable
else972:
  br label %block971
block971:
  %v975 = load i64, ptr %v1, align 1
  %v976 = call i32 @native_ref_test(i64 %v975, i64 346, i32 0, i32 0)
  %v977 = icmp ne i32 %v976, 0
  br i1 %v977, label %ok979, label %trap978
trap978:
  call void @native_trap()
  unreachable
ok979:
  %v980 = icmp ne i64 %v975, 0
  br i1 %v980, label %ok982, label %trap981
trap981:
  call void @native_trap()
  unreachable
ok982:
  %v983 = inttoptr i64 %v975 to ptr
  %v984 = getelementptr i64, ptr %v983, i64 3
  %v985 = load i64, ptr %v984, align 1
  %v986 = icmp ne i64 %v985, 0
  br i1 %v986, label %ok988, label %trap987
trap987:
  call void @native_trap()
  unreachable
ok988:
  %v989 = inttoptr i64 %v985 to ptr
  %v990 = getelementptr i64, ptr %v989, i64 1
  %v991 = load i64, ptr %v990, align 1
  %v992 = getelementptr i64, ptr %roots, i64 13
  store i64 %v991, ptr %v992, align 1
  %v993 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v993, align 1
  %v994 = call i64 @native_alloc(i64 16)
  %v995 = icmp ne i64 %v994, 0
  br i1 %v995, label %ok997, label %trap996
trap996:
  call void @native_trap()
  unreachable
ok997:
  %v998 = inttoptr i64 %v994 to ptr
  %v999 = getelementptr i64, ptr %v998, i64 0
  store i64 682, ptr %v999, align 1
  %v1000 = icmp ne i64 %v994, 0
  br i1 %v1000, label %ok1002, label %trap1001
trap1001:
  call void @native_trap()
  unreachable
ok1002:
  %v1003 = inttoptr i64 %v994 to ptr
  %v1004 = getelementptr i64, ptr %v1003, i64 1
  store i64 %v991, ptr %v1004, align 1
  %v1005 = load i64, ptr %v4, align 1
  %v1006 = icmp ne i64 %v1005, 0
  br i1 %v1006, label %ok1008, label %trap1007
trap1007:
  call void @native_trap()
  unreachable
ok1008:
  %v1009 = inttoptr i64 %v1005 to ptr
  %v1010 = getelementptr i64, ptr %v1009, i64 3
  %v1011 = load i64, ptr %v1010, align 1
  %v1012 = icmp ne i64 %v1011, 0
  br i1 %v1012, label %ok1014, label %trap1013
trap1013:
  call void @native_trap()
  unreachable
ok1014:
  %v1015 = inttoptr i64 %v1011 to ptr
  %v1016 = getelementptr i64, ptr %v1015, i64 1
  %v1017 = load i64, ptr %v1016, align 1
  %v1018 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1017, ptr %v1018, align 1
  %v1019 = getelementptr i64, ptr %roots, i64 14
  store i64 %v994, ptr %v1019, align 1
  %v1020 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v1020, align 1
  %v1021 = call i64 @native_alloc(i64 16)
  %v1022 = icmp ne i64 %v1021, 0
  br i1 %v1022, label %ok1024, label %trap1023
trap1023:
  call void @native_trap()
  unreachable
ok1024:
  %v1025 = inttoptr i64 %v1021 to ptr
  %v1026 = getelementptr i64, ptr %v1025, i64 0
  store i64 682, ptr %v1026, align 1
  %v1027 = icmp ne i64 %v1021, 0
  br i1 %v1027, label %ok1029, label %trap1028
trap1028:
  call void @native_trap()
  unreachable
ok1029:
  %v1030 = inttoptr i64 %v1021 to ptr
  %v1031 = getelementptr i64, ptr %v1030, i64 1
  store i64 %v1017, ptr %v1031, align 1
  %v1032 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1021, ptr %v1032, align 1
  %v1033 = getelementptr i64, ptr %roots, i64 14
  store i64 %v994, ptr %v1033, align 1
  %v1034 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v1034, align 1
  %v1035 = call i64 @native_alloc(i64 32)
  %v1036 = icmp ne i64 %v1035, 0
  br i1 %v1036, label %ok1038, label %trap1037
trap1037:
  call void @native_trap()
  unreachable
ok1038:
  %v1039 = inttoptr i64 %v1035 to ptr
  %v1040 = getelementptr i64, ptr %v1039, i64 0
  store i64 346, ptr %v1040, align 1
  %v1041 = icmp ne i64 %v1035, 0
  br i1 %v1041, label %ok1043, label %trap1042
trap1042:
  call void @native_trap()
  unreachable
ok1043:
  %v1044 = inttoptr i64 %v1035 to ptr
  %v1045 = getelementptr i64, ptr %v1044, i64 1
  store i32 6, ptr %v1045, align 1
  %v1046 = icmp ne i64 %v1035, 0
  br i1 %v1046, label %ok1048, label %trap1047
trap1047:
  call void @native_trap()
  unreachable
ok1048:
  %v1049 = inttoptr i64 %v1035 to ptr
  %v1050 = getelementptr i64, ptr %v1049, i64 2
  store i64 %v994, ptr %v1050, align 1
  %v1051 = icmp ne i64 %v1035, 0
  br i1 %v1051, label %ok1053, label %trap1052
trap1052:
  call void @native_trap()
  unreachable
ok1053:
  %v1054 = inttoptr i64 %v1035 to ptr
  %v1055 = getelementptr i64, ptr %v1054, i64 3
  store i64 %v1021, ptr %v1055, align 1
  store i64 %v1035, ptr %v1, align 1
  br label %block25
else951:
  %v1056 = load i64, ptr @g.1, align 1
  %v1057 = icmp ne i64 %v1056, 0
  br i1 %v1057, label %ok1059, label %trap1058
trap1058:
  call void @native_trap()
  unreachable
ok1059:
  %v1060 = load i64, ptr %v2, align 1
  %v1061 = icmp ne i64 %v1060, 0
  br i1 %v1061, label %ok1063, label %trap1062
trap1062:
  call void @native_trap()
  unreachable
ok1063:
  %v1064 = inttoptr i64 %v1060 to ptr
  %v1065 = getelementptr i64, ptr %v1064, i64 1
  %v1066 = load i32, ptr %v1065, align 1
  %v1067 = icmp ne i32 %v1066, 6
  %v1068 = zext i1 %v1067 to i32
  %v1072 = icmp ne i32 %v1068, 0
  br i1 %v1072, label %then1071, label %else1070
then1071:
  call void @native_trap()
  unreachable
else1070:
  br label %block1069
block1069:
  %v1073 = load i64, ptr %v2, align 1
  %v1074 = call i32 @native_ref_test(i64 %v1073, i64 346, i32 0, i32 0)
  %v1075 = icmp ne i32 %v1074, 0
  br i1 %v1075, label %ok1077, label %trap1076
trap1076:
  call void @native_trap()
  unreachable
ok1077:
  store i64 %v1073, ptr %v5, align 1
  %v1078 = icmp ne i64 %v1073, 0
  br i1 %v1078, label %ok1080, label %trap1079
trap1079:
  call void @native_trap()
  unreachable
ok1080:
  %v1081 = inttoptr i64 %v1073 to ptr
  %v1082 = getelementptr i64, ptr %v1081, i64 3
  %v1083 = load i64, ptr %v1082, align 1
  %v1084 = icmp ne i64 %v1083, 0
  br i1 %v1084, label %ok1086, label %trap1085
trap1085:
  call void @native_trap()
  unreachable
ok1086:
  %v1087 = inttoptr i64 %v1083 to ptr
  %v1088 = getelementptr i64, ptr %v1087, i64 1
  %v1089 = load i64, ptr %v1088, align 1
  store i64 %v1089, ptr %v1, align 1
  %v1090 = load i64, ptr @g.9, align 1
  %v1091 = icmp ne i64 %v1090, 0
  br i1 %v1091, label %ok1093, label %trap1092
trap1092:
  call void @native_trap()
  unreachable
ok1093:
  %v1094 = load i64, ptr @g.0, align 1
  %v1095 = icmp ne i64 %v1094, 0
  br i1 %v1095, label %ok1097, label %trap1096
trap1096:
  call void @native_trap()
  unreachable
ok1097:
  %v1098 = load i32, ptr @g.44, align 1
  %v1099 = icmp eq i32 %v1098, 0
  %v1100 = zext i1 %v1099 to i32
  %v1104 = icmp ne i32 %v1100, 0
  br i1 %v1104, label %then1103, label %else1102
then1103:
  call void @native_trap()
  unreachable
else1102:
  br label %block1101
block1101:
  %v1105 = load i64, ptr @g.38, align 1
  %v1106 = icmp ne i64 %v1105, 0
  br i1 %v1106, label %ok1108, label %trap1107
trap1107:
  call void @native_trap()
  unreachable
ok1108:
  %v1109 = load i64, ptr %v4, align 1
  %v1110 = icmp ne i64 %v1109, 0
  br i1 %v1110, label %ok1112, label %trap1111
trap1111:
  call void @native_trap()
  unreachable
ok1112:
  %v1113 = inttoptr i64 %v1109 to ptr
  %v1114 = getelementptr i64, ptr %v1113, i64 3
  %v1115 = load i64, ptr %v1114, align 1
  %v1116 = icmp ne i64 %v1115, 0
  br i1 %v1116, label %ok1118, label %trap1117
trap1117:
  call void @native_trap()
  unreachable
ok1118:
  %v1119 = inttoptr i64 %v1115 to ptr
  %v1120 = getelementptr i64, ptr %v1119, i64 1
  %v1121 = load i64, ptr %v1120, align 1
  %v1122 = load i64, ptr %v1, align 1
  %v1123 = load i64, ptr %v4, align 1
  %v1124 = icmp ne i64 %v1123, 0
  br i1 %v1124, label %ok1126, label %trap1125
trap1125:
  call void @native_trap()
  unreachable
ok1126:
  %v1127 = inttoptr i64 %v1123 to ptr
  %v1128 = getelementptr i64, ptr %v1127, i64 2
  %v1129 = load i64, ptr %v1128, align 1
  %v1130 = icmp ne i64 %v1129, 0
  br i1 %v1130, label %ok1132, label %trap1131
trap1131:
  call void @native_trap()
  unreachable
ok1132:
  %v1133 = inttoptr i64 %v1129 to ptr
  %v1134 = getelementptr i64, ptr %v1133, i64 1
  %v1135 = load i64, ptr %v1134, align 1
  %v1136 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1135, ptr %v1136, align 1
  %v1137 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1122, ptr %v1137, align 1
  %v1138 = getelementptr i64, ptr %roots, i64 15
  store i64 %v1121, ptr %v1138, align 1
  %v1139 = getelementptr i64, ptr %roots, i64 2
  store i64 13, ptr %v1139, align 1
  %v1140 = call i64 @native_alloc(i64 16)
  %v1141 = icmp ne i64 %v1140, 0
  br i1 %v1141, label %ok1143, label %trap1142
trap1142:
  call void @native_trap()
  unreachable
ok1143:
  %v1144 = inttoptr i64 %v1140 to ptr
  %v1145 = getelementptr i64, ptr %v1144, i64 0
  store i64 682, ptr %v1145, align 1
  %v1146 = icmp ne i64 %v1140, 0
  br i1 %v1146, label %ok1148, label %trap1147
trap1147:
  call void @native_trap()
  unreachable
ok1148:
  %v1149 = inttoptr i64 %v1140 to ptr
  %v1150 = getelementptr i64, ptr %v1149, i64 1
  store i64 %v1135, ptr %v1150, align 1
  %v1151 = load i64, ptr %v5, align 1
  %v1152 = icmp ne i64 %v1151, 0
  br i1 %v1152, label %ok1154, label %trap1153
trap1153:
  call void @native_trap()
  unreachable
ok1154:
  %v1155 = inttoptr i64 %v1151 to ptr
  %v1156 = getelementptr i64, ptr %v1155, i64 2
  %v1157 = load i64, ptr %v1156, align 1
  %v1158 = icmp ne i64 %v1157, 0
  br i1 %v1158, label %ok1160, label %trap1159
trap1159:
  call void @native_trap()
  unreachable
ok1160:
  %v1161 = inttoptr i64 %v1157 to ptr
  %v1162 = getelementptr i64, ptr %v1161, i64 1
  %v1163 = load i64, ptr %v1162, align 1
  %v1164 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1163, ptr %v1164, align 1
  %v1165 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1140, ptr %v1165, align 1
  %v1166 = getelementptr i64, ptr %roots, i64 15
  store i64 %v1122, ptr %v1166, align 1
  %v1167 = getelementptr i64, ptr %roots, i64 16
  store i64 %v1121, ptr %v1167, align 1
  %v1168 = getelementptr i64, ptr %roots, i64 2
  store i64 14, ptr %v1168, align 1
  %v1169 = call i64 @native_alloc(i64 16)
  %v1170 = icmp ne i64 %v1169, 0
  br i1 %v1170, label %ok1172, label %trap1171
trap1171:
  call void @native_trap()
  unreachable
ok1172:
  %v1173 = inttoptr i64 %v1169 to ptr
  %v1174 = getelementptr i64, ptr %v1173, i64 0
  store i64 682, ptr %v1174, align 1
  %v1175 = icmp ne i64 %v1169, 0
  br i1 %v1175, label %ok1177, label %trap1176
trap1176:
  call void @native_trap()
  unreachable
ok1177:
  %v1178 = inttoptr i64 %v1169 to ptr
  %v1179 = getelementptr i64, ptr %v1178, i64 1
  store i64 %v1163, ptr %v1179, align 1
  %v1180 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1169, ptr %v1180, align 1
  %v1181 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1140, ptr %v1181, align 1
  %v1182 = getelementptr i64, ptr %roots, i64 15
  store i64 %v1122, ptr %v1182, align 1
  %v1183 = getelementptr i64, ptr %roots, i64 16
  store i64 %v1121, ptr %v1183, align 1
  %v1184 = getelementptr i64, ptr %roots, i64 2
  store i64 14, ptr %v1184, align 1
  %v1185 = call i64 @native_alloc(i64 32)
  %v1186 = icmp ne i64 %v1185, 0
  br i1 %v1186, label %ok1188, label %trap1187
trap1187:
  call void @native_trap()
  unreachable
ok1188:
  %v1189 = inttoptr i64 %v1185 to ptr
  %v1190 = getelementptr i64, ptr %v1189, i64 0
  store i64 346, ptr %v1190, align 1
  %v1191 = icmp ne i64 %v1185, 0
  br i1 %v1191, label %ok1193, label %trap1192
trap1192:
  call void @native_trap()
  unreachable
ok1193:
  %v1194 = inttoptr i64 %v1185 to ptr
  %v1195 = getelementptr i64, ptr %v1194, i64 1
  store i32 6, ptr %v1195, align 1
  %v1196 = icmp ne i64 %v1185, 0
  br i1 %v1196, label %ok1198, label %trap1197
trap1197:
  call void @native_trap()
  unreachable
ok1198:
  %v1199 = inttoptr i64 %v1185 to ptr
  %v1200 = getelementptr i64, ptr %v1199, i64 2
  store i64 %v1140, ptr %v1200, align 1
  %v1201 = icmp ne i64 %v1185, 0
  br i1 %v1201, label %ok1203, label %trap1202
trap1202:
  call void @native_trap()
  unreachable
ok1203:
  %v1204 = inttoptr i64 %v1185 to ptr
  %v1205 = getelementptr i64, ptr %v1204, i64 3
  store i64 %v1169, ptr %v1205, align 1
  %v1206 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1185, ptr %v1206, align 1
  %v1207 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1122, ptr %v1207, align 1
  %v1208 = getelementptr i64, ptr %roots, i64 15
  store i64 %v1121, ptr %v1208, align 1
  %v1209 = getelementptr i64, ptr %roots, i64 2
  store i64 13, ptr %v1209, align 1
  %v1210 = call i64 @native_alloc(i64 16)
  %v1211 = icmp ne i64 %v1210, 0
  br i1 %v1211, label %ok1213, label %trap1212
trap1212:
  call void @native_trap()
  unreachable
ok1213:
  %v1214 = inttoptr i64 %v1210 to ptr
  %v1215 = getelementptr i64, ptr %v1214, i64 0
  store i64 682, ptr %v1215, align 1
  %v1216 = icmp ne i64 %v1210, 0
  br i1 %v1216, label %ok1218, label %trap1217
trap1217:
  call void @native_trap()
  unreachable
ok1218:
  %v1219 = inttoptr i64 %v1210 to ptr
  %v1220 = getelementptr i64, ptr %v1219, i64 1
  store i64 %v1185, ptr %v1220, align 1
  %v1221 = load i64, ptr %v3, align 1
  %v1222 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1221, ptr %v1222, align 1
  %v1223 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1210, ptr %v1223, align 1
  %v1224 = getelementptr i64, ptr %roots, i64 15
  store i64 %v1122, ptr %v1224, align 1
  %v1225 = getelementptr i64, ptr %roots, i64 16
  store i64 %v1121, ptr %v1225, align 1
  %v1226 = getelementptr i64, ptr %roots, i64 2
  store i64 14, ptr %v1226, align 1
  %v1227 = call i64 @native_alloc(i64 16)
  %v1228 = icmp ne i64 %v1227, 0
  br i1 %v1228, label %ok1230, label %trap1229
trap1229:
  call void @native_trap()
  unreachable
ok1230:
  %v1231 = inttoptr i64 %v1227 to ptr
  %v1232 = getelementptr i64, ptr %v1231, i64 0
  store i64 682, ptr %v1232, align 1
  %v1233 = icmp ne i64 %v1227, 0
  br i1 %v1233, label %ok1235, label %trap1234
trap1234:
  call void @native_trap()
  unreachable
ok1235:
  %v1236 = inttoptr i64 %v1227 to ptr
  %v1237 = getelementptr i64, ptr %v1236, i64 1
  store i64 %v1221, ptr %v1237, align 1
  %v1238 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1227, ptr %v1238, align 1
  %v1239 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1210, ptr %v1239, align 1
  %v1240 = getelementptr i64, ptr %roots, i64 15
  store i64 %v1122, ptr %v1240, align 1
  %v1241 = getelementptr i64, ptr %roots, i64 16
  store i64 %v1121, ptr %v1241, align 1
  %v1242 = getelementptr i64, ptr %roots, i64 2
  store i64 14, ptr %v1242, align 1
  %v1243 = call i64 @native_alloc(i64 32)
  %v1244 = icmp ne i64 %v1243, 0
  br i1 %v1244, label %ok1246, label %trap1245
trap1245:
  call void @native_trap()
  unreachable
ok1246:
  %v1247 = inttoptr i64 %v1243 to ptr
  %v1248 = getelementptr i64, ptr %v1247, i64 0
  store i64 346, ptr %v1248, align 1
  %v1249 = icmp ne i64 %v1243, 0
  br i1 %v1249, label %ok1251, label %trap1250
trap1250:
  call void @native_trap()
  unreachable
ok1251:
  %v1252 = inttoptr i64 %v1243 to ptr
  %v1253 = getelementptr i64, ptr %v1252, i64 1
  store i32 6, ptr %v1253, align 1
  %v1254 = icmp ne i64 %v1243, 0
  br i1 %v1254, label %ok1256, label %trap1255
trap1255:
  call void @native_trap()
  unreachable
ok1256:
  %v1257 = inttoptr i64 %v1243 to ptr
  %v1258 = getelementptr i64, ptr %v1257, i64 2
  store i64 %v1210, ptr %v1258, align 1
  %v1259 = icmp ne i64 %v1243, 0
  br i1 %v1259, label %ok1261, label %trap1260
trap1260:
  call void @native_trap()
  unreachable
ok1261:
  %v1262 = inttoptr i64 %v1243 to ptr
  %v1263 = getelementptr i64, ptr %v1262, i64 3
  store i64 %v1227, ptr %v1263, align 1
  call void @native_roots_leave(ptr %roots)
  %v1264 = tail call tailcc i64 @f.102(i64 %v1121, i64 %v1122, i64 %v1243)
  ret i64 %v1264
else877:
  %v1265 = load i64, ptr @g.9, align 1
  %v1266 = icmp ne i64 %v1265, 0
  br i1 %v1266, label %ok1268, label %trap1267
trap1267:
  call void @native_trap()
  unreachable
ok1268:
  %v1269 = load i64, ptr @g.69, align 1
  %v1270 = icmp ne i64 %v1269, 0
  br i1 %v1270, label %ok1272, label %trap1271
trap1271:
  call void @native_trap()
  unreachable
ok1272:
  %v1273 = load i64, ptr %v4, align 1
  %v1274 = icmp ne i64 %v1273, 0
  br i1 %v1274, label %ok1276, label %trap1275
trap1275:
  call void @native_trap()
  unreachable
ok1276:
  %v1277 = inttoptr i64 %v1273 to ptr
  %v1278 = getelementptr i64, ptr %v1277, i64 2
  %v1279 = load i64, ptr %v1278, align 1
  %v1280 = icmp ne i64 %v1279, 0
  br i1 %v1280, label %ok1282, label %trap1281
trap1281:
  call void @native_trap()
  unreachable
ok1282:
  %v1283 = inttoptr i64 %v1279 to ptr
  %v1284 = getelementptr i64, ptr %v1283, i64 1
  %v1285 = load i64, ptr %v1284, align 1
  store i64 %v1285, ptr %v1, align 1
  %v1286 = icmp ne i64 %v1285, 0
  br i1 %v1286, label %ok1288, label %trap1287
trap1287:
  call void @native_trap()
  unreachable
ok1288:
  %v1289 = inttoptr i64 %v1285 to ptr
  %v1290 = getelementptr i64, ptr %v1289, i64 1
  %v1291 = load i32, ptr %v1290, align 1
  %v1292 = icmp ne i32 %v1291, 4
  %v1293 = zext i1 %v1292 to i32
  %v1297 = icmp ne i32 %v1293, 0
  br i1 %v1297, label %then1296, label %else1295
then1296:
  call void @native_trap()
  unreachable
else1295:
  br label %block1294
block1294:
  %v1298 = load i64, ptr @g.58, align 1
  %v1299 = icmp ne i64 %v1298, 0
  br i1 %v1299, label %ok1301, label %trap1300
trap1300:
  call void @native_trap()
  unreachable
ok1301:
  %v1302 = load i64, ptr %v1, align 1
  %v1303 = call i32 @native_ref_test(i64 %v1302, i64 794, i32 0, i32 0)
  %v1304 = icmp ne i32 %v1303, 0
  br i1 %v1304, label %ok1306, label %trap1305
trap1305:
  call void @native_trap()
  unreachable
ok1306:
  %v1307 = icmp ne i64 %v1302, 0
  br i1 %v1307, label %ok1309, label %trap1308
trap1308:
  call void @native_trap()
  unreachable
ok1309:
  %v1310 = inttoptr i64 %v1302 to ptr
  %v1311 = getelementptr i64, ptr %v1310, i64 2
  %v1312 = load i64, ptr %v1311, align 1
  %v1313 = icmp ne i64 %v1312, 0
  br i1 %v1313, label %ok1315, label %trap1314
trap1314:
  call void @native_trap()
  unreachable
ok1315:
  %v1316 = inttoptr i64 %v1312 to ptr
  %v1317 = getelementptr i64, ptr %v1316, i64 1
  %v1318 = load i32, ptr %v1317, align 1
  store i32 %v1318, ptr %slot10, align 1
  %v1319 = getelementptr i64, ptr %roots, i64 2
  store i64 10, ptr %v1319, align 1
  %v1320 = call tailcc i64 @f.6(i32 %v1318)
  store i64 %v1320, ptr %slot11, align 1
  %v1321 = load i64, ptr @g.19, align 1
  %v1322 = icmp ne i64 %v1321, 0
  br i1 %v1322, label %ok1324, label %trap1323
trap1323:
  call void @native_trap()
  unreachable
ok1324:
  %v1325 = load i64, ptr %slot11, align 1
  %v1326 = icmp ugt i64 %v1325, 4294967294
  %v1327 = zext i1 %v1326 to i32
  %v1331 = icmp ne i32 %v1327, 0
  br i1 %v1331, label %then1330, label %else1329
then1330:
  call void @native_trap()
  unreachable
else1329:
  br label %block1328
block1328:
  %v1332 = load i32, ptr %slot10, align 1
  %v1333 = load i64, ptr %slot11, align 1
  %v1334 = load i64, ptr %slot11, align 1
  %v1335 = trunc i64 %v1334 to i32
  %v1336 = getelementptr i64, ptr %roots, i64 2
  store i64 10, ptr %v1336, align 1
  %v1337 = call tailcc i64 @f.23(i32 %v1335)
  %v1338 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1337, ptr %v1338, align 1
  %v1339 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v1339, align 1
  %v1340 = call tailcc i64 @f.32(i32 %v1332, i64 %v1333, i64 %v1337, i32 0, i32 1, i64 0)
  store i64 %v1340, ptr %v7, align 1
  %v1341 = icmp ne i64 %v1340, 0
  br i1 %v1341, label %ok1343, label %trap1342
trap1342:
  call void @native_trap()
  unreachable
ok1343:
  %v1344 = inttoptr i64 %v1340 to ptr
  %v1345 = getelementptr i64, ptr %v1344, i64 2
  %v1346 = load i32, ptr %v1345, align 1
  %v1347 = zext i32 %v1346 to i64
  %v1348 = icmp eq i64 %v1347, 0
  %v1349 = zext i1 %v1348 to i32
  %v1353 = icmp ne i32 %v1349, 0
  br i1 %v1353, label %then1352, label %else1351
then1352:
  call void @native_trap()
  unreachable
else1351:
  br label %block1350
block1350:
  %v1354 = load i64, ptr %v7, align 1
  %v1355 = icmp ne i64 %v1354, 0
  br i1 %v1355, label %ok1357, label %trap1356
trap1356:
  call void @native_trap()
  unreachable
ok1357:
  %v1358 = inttoptr i64 %v1354 to ptr
  %v1359 = getelementptr i64, ptr %v1358, i64 3
  %v1360 = load i64, ptr %v1359, align 1
  %v1361 = call ptr @native_array_slot(i64 %v1360, i32 0, i32 4)
  %v1362 = load i32, ptr %v1361, align 1
  %v1363 = icmp eq i32 %v1362, 42
  %v1364 = zext i1 %v1363 to i32
  %v1369 = icmp ne i32 %v1364, 0
  br i1 %v1369, label %then1368, label %else1367
then1368:
  %v1370 = load i64, ptr @g.9, align 1
  %v1371 = icmp ne i64 %v1370, 0
  br i1 %v1371, label %ok1373, label %trap1372
trap1372:
  call void @native_trap()
  unreachable
ok1373:
  %v1374 = load i64, ptr @g.62, align 1
  %v1375 = icmp ne i64 %v1374, 0
  br i1 %v1375, label %ok1377, label %trap1376
trap1376:
  call void @native_trap()
  unreachable
ok1377:
  %v1378 = load i64, ptr %v4, align 1
  %v1379 = icmp ne i64 %v1378, 0
  br i1 %v1379, label %ok1381, label %trap1380
trap1380:
  call void @native_trap()
  unreachable
ok1381:
  %v1382 = inttoptr i64 %v1378 to ptr
  %v1383 = getelementptr i64, ptr %v1382, i64 2
  %v1384 = load i64, ptr %v1383, align 1
  %v1385 = icmp ne i64 %v1384, 0
  br i1 %v1385, label %ok1387, label %trap1386
trap1386:
  call void @native_trap()
  unreachable
ok1387:
  %v1388 = inttoptr i64 %v1384 to ptr
  %v1389 = getelementptr i64, ptr %v1388, i64 1
  %v1390 = load i64, ptr %v1389, align 1
  %v1391 = load i64, ptr %v3, align 1
  %v1392 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1390, ptr %v1392, align 1
  %v1393 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1391, ptr %v1393, align 1
  %v1394 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v1394, align 1
  %v1395 = call tailcc i64 @f.53(i64 %v1390, i64 %v1391)
  store i64 %v1395, ptr %v1, align 1
  %v1396 = load i64, ptr @g.39, align 1
  %v1397 = icmp ne i64 %v1396, 0
  br i1 %v1397, label %ok1399, label %trap1398
trap1398:
  call void @native_trap()
  unreachable
ok1399:
  %v1400 = load i64, ptr @g.4, align 1
  %v1401 = icmp ne i64 %v1400, 0
  br i1 %v1401, label %ok1403, label %trap1402
trap1402:
  call void @native_trap()
  unreachable
ok1403:
  %v1404 = load i64, ptr %v1, align 1
  %v1405 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1404, ptr %v1405, align 1
  %v1406 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v1406, align 1
  %v1407 = call tailcc i64 @f.45(i64 %v1404)
  %v1408 = icmp eq i64 %v1407, 1
  %v1409 = zext i1 %v1408 to i32
  %v1414 = icmp ne i32 %v1409, 0
  br i1 %v1414, label %then1413, label %else1412
then1413:
  %v1415 = load i64, ptr %v1, align 1
  %v1416 = icmp ne i64 %v1415, 0
  br i1 %v1416, label %ok1418, label %trap1417
trap1417:
  call void @native_trap()
  unreachable
ok1418:
  %v1419 = inttoptr i64 %v1415 to ptr
  %v1420 = getelementptr i64, ptr %v1419, i64 1
  %v1421 = load i32, ptr %v1420, align 1
  %v1422 = icmp ne i32 %v1421, 1
  %v1423 = zext i1 %v1422 to i32
  %v1427 = icmp ne i32 %v1423, 0
  br i1 %v1427, label %then1426, label %else1425
then1426:
  call void @native_trap()
  unreachable
else1425:
  br label %block1424
block1424:
  %v1428 = load i64, ptr %v1, align 1
  %v1429 = call i32 @native_ref_test(i64 %v1428, i64 330, i32 0, i32 0)
  %v1430 = icmp ne i32 %v1429, 0
  br i1 %v1430, label %ok1432, label %trap1431
trap1431:
  call void @native_trap()
  unreachable
ok1432:
  %v1433 = icmp ne i64 %v1428, 0
  br i1 %v1433, label %ok1435, label %trap1434
trap1434:
  call void @native_trap()
  unreachable
ok1435:
  %v1436 = inttoptr i64 %v1428 to ptr
  %v1437 = getelementptr i64, ptr %v1436, i64 2
  %v1438 = load i32, ptr %v1437, align 1
  store i32 %v1438, ptr %slot1410, align 1
  br label %block1411
else1412:
  store i32 1, ptr %slot1410, align 1
  br label %block1411
block1411:
  %v1439 = load i32, ptr %slot1410, align 1
  %v1443 = icmp ne i32 %v1439, 0
  br i1 %v1443, label %then1442, label %else1441
then1442:
  %v1444 = load i64, ptr @g.1, align 1
  %v1445 = icmp ne i64 %v1444, 0
  br i1 %v1445, label %ok1447, label %trap1446
trap1446:
  call void @native_trap()
  unreachable
ok1447:
  %v1448 = load i64, ptr @g.79, align 1
  %v1449 = icmp ne i64 %v1448, 0
  br i1 %v1449, label %ok1451, label %trap1450
trap1450:
  call void @native_trap()
  unreachable
ok1451:
  %v1452 = load i64, ptr %v1, align 1
  %v1453 = icmp ne i64 %v1452, 0
  br i1 %v1453, label %ok1455, label %trap1454
trap1454:
  call void @native_trap()
  unreachable
ok1455:
  %v1456 = inttoptr i64 %v1452 to ptr
  %v1457 = getelementptr i64, ptr %v1456, i64 1
  %v1458 = load i32, ptr %v1457, align 1
  %v1459 = icmp ne i32 %v1458, 6
  %v1460 = zext i1 %v1459 to i32
  %v1464 = icmp ne i32 %v1460, 0
  br i1 %v1464, label %then1463, label %else1462
then1463:
  call void @native_trap()
  unreachable
else1462:
  br label %block1461
block1461:
  %v1465 = load i64, ptr %v1, align 1
  %v1466 = call i32 @native_ref_test(i64 %v1465, i64 346, i32 0, i32 0)
  %v1467 = icmp ne i32 %v1466, 0
  br i1 %v1467, label %ok1469, label %trap1468
trap1468:
  call void @native_trap()
  unreachable
ok1469:
  %v1470 = icmp ne i64 %v1465, 0
  br i1 %v1470, label %ok1472, label %trap1471
trap1471:
  call void @native_trap()
  unreachable
ok1472:
  %v1473 = inttoptr i64 %v1465 to ptr
  %v1474 = getelementptr i64, ptr %v1473, i64 3
  %v1475 = load i64, ptr %v1474, align 1
  %v1476 = icmp ne i64 %v1475, 0
  br i1 %v1476, label %ok1478, label %trap1477
trap1477:
  call void @native_trap()
  unreachable
ok1478:
  %v1479 = inttoptr i64 %v1475 to ptr
  %v1480 = getelementptr i64, ptr %v1479, i64 1
  %v1481 = load i64, ptr %v1480, align 1
  %v1482 = load i64, ptr %v4, align 1
  %v1483 = icmp ne i64 %v1482, 0
  br i1 %v1483, label %ok1485, label %trap1484
trap1484:
  call void @native_trap()
  unreachable
ok1485:
  %v1486 = inttoptr i64 %v1482 to ptr
  %v1487 = getelementptr i64, ptr %v1486, i64 3
  %v1488 = load i64, ptr %v1487, align 1
  %v1489 = icmp ne i64 %v1488, 0
  br i1 %v1489, label %ok1491, label %trap1490
trap1490:
  call void @native_trap()
  unreachable
ok1491:
  %v1492 = inttoptr i64 %v1488 to ptr
  %v1493 = getelementptr i64, ptr %v1492, i64 1
  %v1494 = load i64, ptr %v1493, align 1
  %v1495 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1481, ptr %v1495, align 1
  %v1496 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1494, ptr %v1496, align 1
  %v1497 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v1497, align 1
  %v1498 = call tailcc i64 @f.52(i64 %v1481, i64 %v1494)
  store i64 %v1498, ptr %v1, align 1
  br label %block25
else1441:
  %v1499 = load i64, ptr @g.0, align 1
  %v1500 = icmp ne i64 %v1499, 0
  br i1 %v1500, label %ok1502, label %trap1501
trap1501:
  call void @native_trap()
  unreachable
ok1502:
  %v1503 = load i64, ptr %v4, align 1
  %v1504 = load i64, ptr %v3, align 1
  %v1505 = load i64, ptr @g.10, align 1
  store i64 %v1505, ptr %v9, align 1
  %v1506 = load i64, ptr %v9, align 1
  %v1507 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1506, ptr %v1507, align 1
  %v1508 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1505, ptr %v1508, align 1
  %v1509 = getelementptr i64, ptr %roots, i64 15
  store i64 %v1504, ptr %v1509, align 1
  %v1510 = getelementptr i64, ptr %roots, i64 16
  store i64 %v1503, ptr %v1510, align 1
  %v1511 = getelementptr i64, ptr %roots, i64 2
  store i64 14, ptr %v1511, align 1
  %v1512 = call i64 @native_alloc(i64 16)
  %v1513 = icmp ne i64 %v1512, 0
  br i1 %v1513, label %ok1515, label %trap1514
trap1514:
  call void @native_trap()
  unreachable
ok1515:
  %v1516 = inttoptr i64 %v1512 to ptr
  %v1517 = getelementptr i64, ptr %v1516, i64 0
  store i64 682, ptr %v1517, align 1
  %v1518 = icmp ne i64 %v1512, 0
  br i1 %v1518, label %ok1520, label %trap1519
trap1519:
  call void @native_trap()
  unreachable
ok1520:
  %v1521 = inttoptr i64 %v1512 to ptr
  %v1522 = getelementptr i64, ptr %v1521, i64 1
  store i64 %v1506, ptr %v1522, align 1
  %v1523 = load i64, ptr %v2, align 1
  %v1524 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1523, ptr %v1524, align 1
  %v1525 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1512, ptr %v1525, align 1
  %v1526 = getelementptr i64, ptr %roots, i64 15
  store i64 %v1505, ptr %v1526, align 1
  %v1527 = getelementptr i64, ptr %roots, i64 16
  store i64 %v1504, ptr %v1527, align 1
  %v1528 = getelementptr i64, ptr %roots, i64 17
  store i64 %v1503, ptr %v1528, align 1
  %v1529 = getelementptr i64, ptr %roots, i64 2
  store i64 15, ptr %v1529, align 1
  %v1530 = call i64 @native_alloc(i64 16)
  %v1531 = icmp ne i64 %v1530, 0
  br i1 %v1531, label %ok1533, label %trap1532
trap1532:
  call void @native_trap()
  unreachable
ok1533:
  %v1534 = inttoptr i64 %v1530 to ptr
  %v1535 = getelementptr i64, ptr %v1534, i64 0
  store i64 682, ptr %v1535, align 1
  %v1536 = icmp ne i64 %v1530, 0
  br i1 %v1536, label %ok1538, label %trap1537
trap1537:
  call void @native_trap()
  unreachable
ok1538:
  %v1539 = inttoptr i64 %v1530 to ptr
  %v1540 = getelementptr i64, ptr %v1539, i64 1
  store i64 %v1523, ptr %v1540, align 1
  %v1541 = getelementptr i64, ptr %roots, i64 13
  store i64 %v1530, ptr %v1541, align 1
  %v1542 = getelementptr i64, ptr %roots, i64 14
  store i64 %v1512, ptr %v1542, align 1
  %v1543 = getelementptr i64, ptr %roots, i64 15
  store i64 %v1505, ptr %v1543, align 1
  %v1544 = getelementptr i64, ptr %roots, i64 16
  store i64 %v1504, ptr %v1544, align 1
  %v1545 = getelementptr i64, ptr %roots, i64 17
  store i64 %v1503, ptr %v1545, align 1
  %v1546 = getelementptr i64, ptr %roots, i64 2
  store i64 15, ptr %v1546, align 1
  %v1547 = call i64 @native_alloc(i64 32)
  %v1548 = icmp ne i64 %v1547, 0
  br i1 %v1548, label %ok1550, label %trap1549
trap1549:
  call void @native_trap()
  unreachable
ok1550:
  %v1551 = inttoptr i64 %v1547 to ptr
  %v1552 = getelementptr i64, ptr %v1551, i64 0
  store i64 346, ptr %v1552, align 1
  %v1553 = icmp ne i64 %v1547, 0
  br i1 %v1553, label %ok1555, label %trap1554
trap1554:
  call void @native_trap()
  unreachable
ok1555:
  %v1556 = inttoptr i64 %v1547 to ptr
  %v1557 = getelementptr i64, ptr %v1556, i64 1
  store i32 6, ptr %v1557, align 1
  %v1558 = icmp ne i64 %v1547, 0
  br i1 %v1558, label %ok1560, label %trap1559
trap1559:
  call void @native_trap()
  unreachable
ok1560:
  %v1561 = inttoptr i64 %v1547 to ptr
  %v1562 = getelementptr i64, ptr %v1561, i64 2
  store i64 %v1512, ptr %v1562, align 1
  %v1563 = icmp ne i64 %v1547, 0
  br i1 %v1563, label %ok1565, label %trap1564
trap1564:
  call void @native_trap()
  unreachable
ok1565:
  %v1566 = inttoptr i64 %v1547 to ptr
  %v1567 = getelementptr i64, ptr %v1566, i64 3
  store i64 %v1530, ptr %v1567, align 1
  %v1568 = load i64, ptr %v2, align 1
  call void @native_roots_leave(ptr %roots)
  %v1569 = tail call tailcc i64 @f.103(i64 %v1503, i64 %v1504, i32 0, i32 1, i64 %v1505, i64 %v1547, i64 %v1568)
  ret i64 %v1569
else1367:
  %v1570 = load i64, ptr @g.43, align 1
  %v1571 = icmp ne i64 %v1570, 0
  br i1 %v1571, label %ok1573, label %trap1572
trap1572:
  call void @native_trap()
  unreachable
ok1573:
  store i64 %v1570, ptr %slot1365, align 1
  br label %block1366
block1366:
  %v1574 = load i64, ptr %slot1365, align 1
  store i64 %v1574, ptr %slot875, align 1
  br label %block876
block876:
  %v1575 = load i64, ptr %slot875, align 1
  store i64 %v1575, ptr %slot545, align 1
  br label %block546
block546:
  %v1576 = load i64, ptr %slot545, align 1
  store i64 %v1576, ptr %slot340, align 1
  br label %block341
block341:
  %v1577 = load i64, ptr %slot340, align 1
  store i64 %v1577, ptr %slot221, align 1
  br label %block222
block222:
  %v1578 = load i64, ptr %slot221, align 1
  store i64 %v1578, ptr %slot87, align 1
  br label %block88
block88:
  %v1579 = load i64, ptr %slot87, align 1
  store i64 %v1579, ptr %slot32, align 1
  br label %block33
block33:
  %v1580 = load i64, ptr %slot32, align 1
  call void @native_roots_leave(ptr %roots)
  ret i64 %v1580
block25:
  %v1581 = load i32, ptr @g.44, align 1
  %v1582 = icmp eq i32 %v1581, 0
  %v1583 = zext i1 %v1582 to i32
  %v1587 = icmp ne i32 %v1583, 0
  br i1 %v1587, label %then1586, label %else1585
then1586:
  call void @native_trap()
  unreachable
else1585:
  br label %block1584
block1584:
  %v1588 = load i64, ptr @g.38, align 1
  %v1589 = icmp ne i64 %v1588, 0
  br i1 %v1589, label %ok1591, label %trap1590
trap1590:
  call void @native_trap()
  unreachable
ok1591:
  %v1592 = load i64, ptr %v1, align 1
  %v1593 = load i64, ptr %v2, align 1
  %v1594 = load i64, ptr %v3, align 1
  call void @native_roots_leave(ptr %roots)
  %v1595 = tail call tailcc i64 @f.102(i64 %v1592, i64 %v1593, i64 %v1594)
  ret i64 %v1595
}
