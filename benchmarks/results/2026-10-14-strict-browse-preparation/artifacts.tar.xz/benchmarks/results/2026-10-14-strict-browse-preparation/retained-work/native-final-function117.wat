(func $function117 (type $call98) (param $0 (ref $type13)) (param $1 (ref $type13)) (result (ref $type13))
  (local $2 (ref $type31))
  (drop
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global353)
   )
  )
  (if (result (ref $type13))
   (i64.eqz
    (call $function107
     (local.get $0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global343)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $0)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $0
     (struct.get $type32 0
      (struct.get $type31 1
       (local.tee $2
        (ref.cast (ref $type31)
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (if
     (i32.eqz
      (global.get $ready395)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global395)
     )
    )
    (local.set $1
     (call $function117
      (struct.get $type32 0
       (struct.get $type31 2
        (local.get $2)
       )
      )
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global340)
     )
    )
    (struct.new $type31
     (i32.const 6)
     (struct.new $type32
      (local.get $0)
     )
     (struct.new $type32
      (local.get $1)
     )
    )
   )
  )
 )
