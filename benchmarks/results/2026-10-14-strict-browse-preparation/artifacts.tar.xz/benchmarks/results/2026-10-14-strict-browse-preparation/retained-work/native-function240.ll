define internal tailcc i64 @f.103(i64 %arg0, i64 %arg1, i32 %arg2, i32 %arg3, i64 %arg4, i64 %arg5, i64 %arg6) {
entry:
  %slot3 = alloca i32, align 8
  %slot4 = alloca i32, align 8
  %slot8 = alloca i32, align 8
  %slot13 = alloca i32, align 8
  %slot14 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %roots = alloca { ptr, i64, i64, [13 x i64] }, align 8
  call void @native_roots_enter(ptr %roots, i64 13)
  %v1 = getelementptr i64, ptr %roots, i64 3
  store i64 %arg0, ptr %v1, align 1
  %v2 = getelementptr i64, ptr %roots, i64 4
  store i64 %arg1, ptr %v2, align 1
  store i32 %arg2, ptr %slot3, align 1
  store i32 %arg3, ptr %slot4, align 1
  %v5 = getelementptr i64, ptr %roots, i64 5
  store i64 %arg4, ptr %v5, align 1
  %v6 = getelementptr i64, ptr %roots, i64 6
  store i64 %arg5, ptr %v6, align 1
  %v7 = getelementptr i64, ptr %roots, i64 7
  store i64 %arg6, ptr %v7, align 1
  store i32 0, ptr %slot8, align 1
  %v9 = getelementptr i64, ptr %roots, i64 8
  store i64 0, ptr %v9, align 1
  %v10 = getelementptr i64, ptr %roots, i64 9
  store i64 0, ptr %v10, align 1
  %v11 = getelementptr i64, ptr %roots, i64 10
  store i64 0, ptr %v11, align 1
  %v12 = getelementptr i64, ptr %roots, i64 11
  store i64 0, ptr %v12, align 1
  store i32 0, ptr %slot13, align 1
  %v16 = load i64, ptr @g.5, align 1
  %v17 = icmp ne i64 %v16, 0
  br i1 %v17, label %ok19, label %trap18
trap18:
  call void @native_trap()
  unreachable
ok19:
  %v20 = load i64, ptr @g.4, align 1
  %v21 = icmp ne i64 %v20, 0
  br i1 %v21, label %ok23, label %trap22
trap22:
  call void @native_trap()
  unreachable
ok23:
  %v24 = load i64, ptr %v6, align 1
  %v25 = getelementptr i64, ptr %roots, i64 12
  store i64 %v24, ptr %v25, align 1
  %v26 = getelementptr i64, ptr %roots, i64 2
  store i64 10, ptr %v26, align 1
  %v27 = call tailcc i64 @f.45(i64 %v24)
  %v28 = icmp eq i64 %v27, 0
  %v29 = zext i1 %v28 to i32
  store i32 %v29, ptr %slot8, align 1
  %v34 = icmp ne i32 %v29, 0
  br i1 %v34, label %then33, label %else32
then33:
  %v35 = load i32, ptr %slot8, align 1
  store i32 %v35, ptr %slot30, align 1
  br label %block31
else32:
  %v36 = load i64, ptr @g.1, align 1
  %v37 = icmp ne i64 %v36, 0
  br i1 %v37, label %ok39, label %trap38
trap38:
  call void @native_trap()
  unreachable
ok39:
  %v40 = load i64, ptr %v1, align 1
  %v41 = icmp ne i64 %v40, 0
  br i1 %v41, label %ok43, label %trap42
trap42:
  call void @native_trap()
  unreachable
ok43:
  %v44 = inttoptr i64 %v40 to ptr
  %v45 = getelementptr i64, ptr %v44, i64 1
  %v46 = load i32, ptr %v45, align 1
  %v47 = icmp ne i32 %v46, 6
  %v48 = zext i1 %v47 to i32
  %v52 = icmp ne i32 %v48, 0
  br i1 %v52, label %then51, label %else50
then51:
  call void @native_trap()
  unreachable
else50:
  br label %block49
block49:
  %v53 = load i64, ptr @g.9, align 1
  %v54 = icmp ne i64 %v53, 0
  br i1 %v54, label %ok56, label %trap55
trap55:
  call void @native_trap()
  unreachable
ok56:
  %v57 = load i64, ptr @g.0, align 1
  %v58 = icmp ne i64 %v57, 0
  br i1 %v58, label %ok60, label %trap59
trap59:
  call void @native_trap()
  unreachable
ok60:
  %v61 = load i32, ptr @g.44, align 1
  %v62 = icmp eq i32 %v61, 0
  %v63 = zext i1 %v62 to i32
  %v67 = icmp ne i32 %v63, 0
  br i1 %v67, label %then66, label %else65
then66:
  call void @native_trap()
  unreachable
else65:
  br label %block64
block64:
  %v68 = load i64, ptr @g.38, align 1
  %v69 = icmp ne i64 %v68, 0
  br i1 %v69, label %ok71, label %trap70
trap70:
  call void @native_trap()
  unreachable
ok71:
  %v74 = load i64, ptr %v1, align 1
  %v75 = call i32 @native_ref_test(i64 %v74, i64 346, i32 0, i32 0)
  %v76 = icmp ne i32 %v75, 0
  br i1 %v76, label %ok78, label %trap77
trap77:
  call void @native_trap()
  unreachable
ok78:
  store i64 %v74, ptr %v9, align 1
  %v79 = icmp ne i64 %v74, 0
  br i1 %v79, label %ok81, label %trap80
trap80:
  call void @native_trap()
  unreachable
ok81:
  %v82 = inttoptr i64 %v74 to ptr
  %v83 = getelementptr i64, ptr %v82, i64 3
  %v84 = load i64, ptr %v83, align 1
  %v85 = icmp ne i64 %v84, 0
  br i1 %v85, label %ok87, label %trap86
trap86:
  call void @native_trap()
  unreachable
ok87:
  %v88 = inttoptr i64 %v84 to ptr
  %v89 = getelementptr i64, ptr %v88, i64 1
  %v90 = load i64, ptr %v89, align 1
  %v91 = load i64, ptr %v7, align 1
  %v92 = load i64, ptr %v9, align 1
  %v93 = icmp ne i64 %v92, 0
  br i1 %v93, label %ok95, label %trap94
trap94:
  call void @native_trap()
  unreachable
ok95:
  %v96 = inttoptr i64 %v92 to ptr
  %v97 = getelementptr i64, ptr %v96, i64 2
  %v98 = load i64, ptr %v97, align 1
  %v99 = icmp ne i64 %v98, 0
  br i1 %v99, label %ok101, label %trap100
trap100:
  call void @native_trap()
  unreachable
ok101:
  %v102 = inttoptr i64 %v98 to ptr
  %v103 = getelementptr i64, ptr %v102, i64 1
  %v104 = load i64, ptr %v103, align 1
  %v105 = getelementptr i64, ptr %roots, i64 12
  store i64 %v104, ptr %v105, align 1
  %v106 = getelementptr i64, ptr %roots, i64 13
  store i64 %v91, ptr %v106, align 1
  %v107 = getelementptr i64, ptr %roots, i64 14
  store i64 %v90, ptr %v107, align 1
  %v108 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v108, align 1
  %v109 = call i64 @native_alloc(i64 16)
  %v110 = icmp ne i64 %v109, 0
  br i1 %v110, label %ok112, label %trap111
trap111:
  call void @native_trap()
  unreachable
ok112:
  %v113 = inttoptr i64 %v109 to ptr
  %v114 = getelementptr i64, ptr %v113, i64 0
  store i64 682, ptr %v114, align 1
  %v115 = icmp ne i64 %v109, 0
  br i1 %v115, label %ok117, label %trap116
trap116:
  call void @native_trap()
  unreachable
ok117:
  %v118 = inttoptr i64 %v109 to ptr
  %v119 = getelementptr i64, ptr %v118, i64 1
  store i64 %v104, ptr %v119, align 1
  %v120 = load i64, ptr %v5, align 1
  %v121 = getelementptr i64, ptr %roots, i64 12
  store i64 %v120, ptr %v121, align 1
  %v122 = getelementptr i64, ptr %roots, i64 13
  store i64 %v109, ptr %v122, align 1
  %v123 = getelementptr i64, ptr %roots, i64 14
  store i64 %v91, ptr %v123, align 1
  %v124 = getelementptr i64, ptr %roots, i64 15
  store i64 %v90, ptr %v124, align 1
  %v125 = getelementptr i64, ptr %roots, i64 2
  store i64 13, ptr %v125, align 1
  %v126 = call i64 @native_alloc(i64 16)
  %v127 = icmp ne i64 %v126, 0
  br i1 %v127, label %ok129, label %trap128
trap128:
  call void @native_trap()
  unreachable
ok129:
  %v130 = inttoptr i64 %v126 to ptr
  %v131 = getelementptr i64, ptr %v130, i64 0
  store i64 682, ptr %v131, align 1
  %v132 = icmp ne i64 %v126, 0
  br i1 %v132, label %ok134, label %trap133
trap133:
  call void @native_trap()
  unreachable
ok134:
  %v135 = inttoptr i64 %v126 to ptr
  %v136 = getelementptr i64, ptr %v135, i64 1
  store i64 %v120, ptr %v136, align 1
  %v137 = getelementptr i64, ptr %roots, i64 12
  store i64 %v126, ptr %v137, align 1
  %v138 = getelementptr i64, ptr %roots, i64 13
  store i64 %v109, ptr %v138, align 1
  %v139 = getelementptr i64, ptr %roots, i64 14
  store i64 %v91, ptr %v139, align 1
  %v140 = getelementptr i64, ptr %roots, i64 15
  store i64 %v90, ptr %v140, align 1
  %v141 = getelementptr i64, ptr %roots, i64 2
  store i64 13, ptr %v141, align 1
  %v142 = call i64 @native_alloc(i64 32)
  %v143 = icmp ne i64 %v142, 0
  br i1 %v143, label %ok145, label %trap144
trap144:
  call void @native_trap()
  unreachable
ok145:
  %v146 = inttoptr i64 %v142 to ptr
  %v147 = getelementptr i64, ptr %v146, i64 0
  store i64 346, ptr %v147, align 1
  %v148 = icmp ne i64 %v142, 0
  br i1 %v148, label %ok150, label %trap149
trap149:
  call void @native_trap()
  unreachable
ok150:
  %v151 = inttoptr i64 %v142 to ptr
  %v152 = getelementptr i64, ptr %v151, i64 1
  store i32 6, ptr %v152, align 1
  %v153 = icmp ne i64 %v142, 0
  br i1 %v153, label %ok155, label %trap154
trap154:
  call void @native_trap()
  unreachable
ok155:
  %v156 = inttoptr i64 %v142 to ptr
  %v157 = getelementptr i64, ptr %v156, i64 2
  store i64 %v109, ptr %v157, align 1
  %v158 = icmp ne i64 %v142, 0
  br i1 %v158, label %ok160, label %trap159
trap159:
  call void @native_trap()
  unreachable
ok160:
  %v161 = inttoptr i64 %v142 to ptr
  %v162 = getelementptr i64, ptr %v161, i64 3
  store i64 %v126, ptr %v162, align 1
  %v163 = getelementptr i64, ptr %roots, i64 12
  store i64 %v142, ptr %v163, align 1
  %v164 = getelementptr i64, ptr %roots, i64 13
  store i64 %v91, ptr %v164, align 1
  %v165 = getelementptr i64, ptr %roots, i64 14
  store i64 %v90, ptr %v165, align 1
  %v166 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v166, align 1
  %v167 = call i64 @native_alloc(i64 16)
  %v168 = icmp ne i64 %v167, 0
  br i1 %v168, label %ok170, label %trap169
trap169:
  call void @native_trap()
  unreachable
ok170:
  %v171 = inttoptr i64 %v167 to ptr
  %v172 = getelementptr i64, ptr %v171, i64 0
  store i64 682, ptr %v172, align 1
  %v173 = icmp ne i64 %v167, 0
  br i1 %v173, label %ok175, label %trap174
trap174:
  call void @native_trap()
  unreachable
ok175:
  %v176 = inttoptr i64 %v167 to ptr
  %v177 = getelementptr i64, ptr %v176, i64 1
  store i64 %v142, ptr %v177, align 1
  %v178 = load i64, ptr %v2, align 1
  %v179 = getelementptr i64, ptr %roots, i64 12
  store i64 %v178, ptr %v179, align 1
  %v180 = getelementptr i64, ptr %roots, i64 13
  store i64 %v167, ptr %v180, align 1
  %v181 = getelementptr i64, ptr %roots, i64 14
  store i64 %v91, ptr %v181, align 1
  %v182 = getelementptr i64, ptr %roots, i64 15
  store i64 %v90, ptr %v182, align 1
  %v183 = getelementptr i64, ptr %roots, i64 2
  store i64 13, ptr %v183, align 1
  %v184 = call i64 @native_alloc(i64 16)
  %v185 = icmp ne i64 %v184, 0
  br i1 %v185, label %ok187, label %trap186
trap186:
  call void @native_trap()
  unreachable
ok187:
  %v188 = inttoptr i64 %v184 to ptr
  %v189 = getelementptr i64, ptr %v188, i64 0
  store i64 682, ptr %v189, align 1
  %v190 = icmp ne i64 %v184, 0
  br i1 %v190, label %ok192, label %trap191
trap191:
  call void @native_trap()
  unreachable
ok192:
  %v193 = inttoptr i64 %v184 to ptr
  %v194 = getelementptr i64, ptr %v193, i64 1
  store i64 %v178, ptr %v194, align 1
  %v195 = getelementptr i64, ptr %roots, i64 12
  store i64 %v184, ptr %v195, align 1
  %v196 = getelementptr i64, ptr %roots, i64 13
  store i64 %v167, ptr %v196, align 1
  %v197 = getelementptr i64, ptr %roots, i64 14
  store i64 %v91, ptr %v197, align 1
  %v198 = getelementptr i64, ptr %roots, i64 15
  store i64 %v90, ptr %v198, align 1
  %v199 = getelementptr i64, ptr %roots, i64 2
  store i64 13, ptr %v199, align 1
  %v200 = call i64 @native_alloc(i64 32)
  %v201 = icmp ne i64 %v200, 0
  br i1 %v201, label %ok203, label %trap202
trap202:
  call void @native_trap()
  unreachable
ok203:
  %v204 = inttoptr i64 %v200 to ptr
  %v205 = getelementptr i64, ptr %v204, i64 0
  store i64 346, ptr %v205, align 1
  %v206 = icmp ne i64 %v200, 0
  br i1 %v206, label %ok208, label %trap207
trap207:
  call void @native_trap()
  unreachable
ok208:
  %v209 = inttoptr i64 %v200 to ptr
  %v210 = getelementptr i64, ptr %v209, i64 1
  store i32 6, ptr %v210, align 1
  %v211 = icmp ne i64 %v200, 0
  br i1 %v211, label %ok213, label %trap212
trap212:
  call void @native_trap()
  unreachable
ok213:
  %v214 = inttoptr i64 %v200 to ptr
  %v215 = getelementptr i64, ptr %v214, i64 2
  store i64 %v167, ptr %v215, align 1
  %v216 = icmp ne i64 %v200, 0
  br i1 %v216, label %ok218, label %trap217
trap217:
  call void @native_trap()
  unreachable
ok218:
  %v219 = inttoptr i64 %v200 to ptr
  %v220 = getelementptr i64, ptr %v219, i64 3
  store i64 %v184, ptr %v220, align 1
  %v221 = getelementptr i64, ptr %roots, i64 12
  store i64 %v90, ptr %v221, align 1
  %v222 = getelementptr i64, ptr %roots, i64 13
  store i64 %v91, ptr %v222, align 1
  %v223 = getelementptr i64, ptr %roots, i64 14
  store i64 %v200, ptr %v223, align 1
  %v224 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v224, align 1
  %v225 = call tailcc i64 @f.102(i64 %v90, i64 %v91, i64 %v200)
  store i64 %v225, ptr %v12, align 1
  %v226 = load i64, ptr @g.48, align 1
  %v227 = icmp ne i64 %v226, 0
  br i1 %v227, label %ok229, label %trap228
trap228:
  call void @native_trap()
  unreachable
ok229:
  %v230 = load i64, ptr %v12, align 1
  store i64 %v230, ptr %slot72, align 1
  br label %block73
block73:
  %v231 = load i64, ptr %slot72, align 1
  %v232 = icmp ne i64 %v231, 0
  br i1 %v232, label %ok234, label %trap233
trap233:
  call void @native_trap()
  unreachable
ok234:
  %v235 = inttoptr i64 %v231 to ptr
  %v236 = getelementptr i64, ptr %v235, i64 1
  %v237 = load i32, ptr %v236, align 1
  store i32 %v237, ptr %slot30, align 1
  br label %block31
block31:
  %v238 = load i32, ptr %slot30, align 1
  %v243 = icmp ne i32 %v238, 0
  br i1 %v243, label %then242, label %else241
then242:
  %v244 = load i64, ptr @g.5, align 1
  %v245 = icmp ne i64 %v244, 0
  br i1 %v245, label %ok247, label %trap246
trap246:
  call void @native_trap()
  unreachable
ok247:
  %v248 = load i64, ptr @g.4, align 1
  %v249 = icmp ne i64 %v248, 0
  br i1 %v249, label %ok251, label %trap250
trap250:
  call void @native_trap()
  unreachable
ok251:
  %v254 = load i64, ptr %v6, align 1
  %v255 = getelementptr i64, ptr %roots, i64 12
  store i64 %v254, ptr %v255, align 1
  %v256 = getelementptr i64, ptr %roots, i64 2
  store i64 10, ptr %v256, align 1
  %v257 = call tailcc i64 @f.45(i64 %v254)
  %v258 = icmp ne i64 %v257, 0
  %v259 = zext i1 %v258 to i32
  store i32 %v259, ptr %slot13, align 1
  %v260 = load i64, ptr @g.68, align 1
  %v261 = icmp ne i64 %v260, 0
  br i1 %v261, label %ok263, label %trap262
trap262:
  call void @native_trap()
  unreachable
ok263:
  %v264 = load i32, ptr %slot13, align 1
  store i32 %v264, ptr %slot252, align 1
  br label %block253
block253:
  %v265 = load i32, ptr %slot252, align 1
  %v270 = icmp ne i32 %v265, 0
  br i1 %v270, label %then269, label %else268
then269:
  %v271 = load i64, ptr @g.67, align 1
  %v272 = icmp ne i64 %v271, 0
  br i1 %v272, label %ok274, label %trap273
trap273:
  call void @native_trap()
  unreachable
ok274:
  store i64 %v271, ptr %slot266, align 1
  br label %block267
else268:
  %v275 = load i64, ptr @g.43, align 1
  %v276 = icmp ne i64 %v275, 0
  br i1 %v276, label %ok278, label %trap277
trap277:
  call void @native_trap()
  unreachable
ok278:
  store i64 %v275, ptr %slot266, align 1
  br label %block267
block267:
  %v279 = load i64, ptr %slot266, align 1
  store i64 %v279, ptr %slot239, align 1
  br label %block240
else241:
  %v280 = load i64, ptr @g.5, align 1
  %v281 = icmp ne i64 %v280, 0
  br i1 %v281, label %ok283, label %trap282
trap282:
  call void @native_trap()
  unreachable
ok283:
  %v284 = load i64, ptr @g.4, align 1
  %v285 = icmp ne i64 %v284, 0
  br i1 %v285, label %ok287, label %trap286
trap286:
  call void @native_trap()
  unreachable
ok287:
  %v288 = load i64, ptr %v7, align 1
  %v289 = getelementptr i64, ptr %roots, i64 12
  store i64 %v288, ptr %v289, align 1
  %v290 = getelementptr i64, ptr %roots, i64 2
  store i64 10, ptr %v290, align 1
  %v291 = call tailcc i64 @f.45(i64 %v288)
  %v292 = icmp eq i64 %v291, 0
  %v293 = zext i1 %v292 to i32
  %v298 = icmp ne i32 %v293, 0
  br i1 %v298, label %then297, label %else296
then297:
  %v299 = load i64, ptr @g.10, align 1
  store i64 %v299, ptr %slot294, align 1
  br label %block295
else296:
  %v300 = load i64, ptr @g.9, align 1
  %v301 = icmp ne i64 %v300, 0
  br i1 %v301, label %ok303, label %trap302
trap302:
  call void @native_trap()
  unreachable
ok303:
  %v304 = load i64, ptr %v7, align 1
  %v305 = icmp ne i64 %v304, 0
  br i1 %v305, label %ok307, label %trap306
trap306:
  call void @native_trap()
  unreachable
ok307:
  %v308 = inttoptr i64 %v304 to ptr
  %v309 = getelementptr i64, ptr %v308, i64 1
  %v310 = load i32, ptr %v309, align 1
  %v311 = icmp ne i32 %v310, 6
  %v312 = zext i1 %v311 to i32
  %v316 = icmp ne i32 %v312, 0
  br i1 %v316, label %then315, label %else314
then315:
  call void @native_trap()
  unreachable
else314:
  br label %block313
block313:
  %v317 = load i64, ptr %v7, align 1
  %v318 = call i32 @native_ref_test(i64 %v317, i64 346, i32 0, i32 0)
  %v319 = icmp ne i32 %v318, 0
  br i1 %v319, label %ok321, label %trap320
trap320:
  call void @native_trap()
  unreachable
ok321:
  %v322 = icmp ne i64 %v317, 0
  br i1 %v322, label %ok324, label %trap323
trap323:
  call void @native_trap()
  unreachable
ok324:
  %v325 = inttoptr i64 %v317 to ptr
  %v326 = getelementptr i64, ptr %v325, i64 2
  %v327 = load i64, ptr %v326, align 1
  %v328 = icmp ne i64 %v327, 0
  br i1 %v328, label %ok330, label %trap329
trap329:
  call void @native_trap()
  unreachable
ok330:
  %v331 = inttoptr i64 %v327 to ptr
  %v332 = getelementptr i64, ptr %v331, i64 1
  %v333 = load i64, ptr %v332, align 1
  store i64 %v333, ptr %slot294, align 1
  br label %block295
block295:
  %v334 = load i64, ptr %slot294, align 1
  store i64 %v334, ptr %v11, align 1
  %v335 = load i64, ptr @g.0, align 1
  %v336 = icmp ne i64 %v335, 0
  br i1 %v336, label %ok338, label %trap337
trap337:
  call void @native_trap()
  unreachable
ok338:
  %v339 = load i64, ptr @g.185, align 1
  %v340 = icmp ne i64 %v339, 0
  br i1 %v340, label %ok342, label %trap341
trap341:
  call void @native_trap()
  unreachable
ok342:
  %v343 = load i64, ptr %v5, align 1
  %v344 = load i64, ptr %v11, align 1
  %v345 = getelementptr i64, ptr %roots, i64 12
  store i64 %v344, ptr %v345, align 1
  %v346 = getelementptr i64, ptr %roots, i64 13
  store i64 %v343, ptr %v346, align 1
  %v347 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v347, align 1
  %v348 = call i64 @native_alloc(i64 16)
  %v349 = icmp ne i64 %v348, 0
  br i1 %v349, label %ok351, label %trap350
trap350:
  call void @native_trap()
  unreachable
ok351:
  %v352 = inttoptr i64 %v348 to ptr
  %v353 = getelementptr i64, ptr %v352, i64 0
  store i64 682, ptr %v353, align 1
  %v354 = icmp ne i64 %v348, 0
  br i1 %v354, label %ok356, label %trap355
trap355:
  call void @native_trap()
  unreachable
ok356:
  %v357 = inttoptr i64 %v348 to ptr
  %v358 = getelementptr i64, ptr %v357, i64 1
  store i64 %v344, ptr %v358, align 1
  %v359 = load i64, ptr @g.10, align 1
  %v360 = getelementptr i64, ptr %roots, i64 12
  store i64 %v359, ptr %v360, align 1
  %v361 = getelementptr i64, ptr %roots, i64 13
  store i64 %v348, ptr %v361, align 1
  %v362 = getelementptr i64, ptr %roots, i64 14
  store i64 %v343, ptr %v362, align 1
  %v363 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v363, align 1
  %v364 = call i64 @native_alloc(i64 16)
  %v365 = icmp ne i64 %v364, 0
  br i1 %v365, label %ok367, label %trap366
trap366:
  call void @native_trap()
  unreachable
ok367:
  %v368 = inttoptr i64 %v364 to ptr
  %v369 = getelementptr i64, ptr %v368, i64 0
  store i64 682, ptr %v369, align 1
  %v370 = icmp ne i64 %v364, 0
  br i1 %v370, label %ok372, label %trap371
trap371:
  call void @native_trap()
  unreachable
ok372:
  %v373 = inttoptr i64 %v364 to ptr
  %v374 = getelementptr i64, ptr %v373, i64 1
  store i64 %v359, ptr %v374, align 1
  %v375 = getelementptr i64, ptr %roots, i64 12
  store i64 %v364, ptr %v375, align 1
  %v376 = getelementptr i64, ptr %roots, i64 13
  store i64 %v348, ptr %v376, align 1
  %v377 = getelementptr i64, ptr %roots, i64 14
  store i64 %v343, ptr %v377, align 1
  %v378 = getelementptr i64, ptr %roots, i64 2
  store i64 12, ptr %v378, align 1
  %v379 = call i64 @native_alloc(i64 32)
  %v380 = icmp ne i64 %v379, 0
  br i1 %v380, label %ok382, label %trap381
trap381:
  call void @native_trap()
  unreachable
ok382:
  %v383 = inttoptr i64 %v379 to ptr
  %v384 = getelementptr i64, ptr %v383, i64 0
  store i64 346, ptr %v384, align 1
  %v385 = icmp ne i64 %v379, 0
  br i1 %v385, label %ok387, label %trap386
trap386:
  call void @native_trap()
  unreachable
ok387:
  %v388 = inttoptr i64 %v379 to ptr
  %v389 = getelementptr i64, ptr %v388, i64 1
  store i32 6, ptr %v389, align 1
  %v390 = icmp ne i64 %v379, 0
  br i1 %v390, label %ok392, label %trap391
trap391:
  call void @native_trap()
  unreachable
ok392:
  %v393 = inttoptr i64 %v379 to ptr
  %v394 = getelementptr i64, ptr %v393, i64 2
  store i64 %v348, ptr %v394, align 1
  %v395 = icmp ne i64 %v379, 0
  br i1 %v395, label %ok397, label %trap396
trap396:
  call void @native_trap()
  unreachable
ok397:
  %v398 = inttoptr i64 %v379 to ptr
  %v399 = getelementptr i64, ptr %v398, i64 3
  store i64 %v364, ptr %v399, align 1
  %v400 = getelementptr i64, ptr %roots, i64 12
  store i64 %v343, ptr %v400, align 1
  %v401 = getelementptr i64, ptr %roots, i64 13
  store i64 %v379, ptr %v401, align 1
  %v402 = getelementptr i64, ptr %roots, i64 2
  store i64 11, ptr %v402, align 1
  %v403 = call tailcc i64 @f.89(i64 %v343, i64 %v379)
  store i64 %v403, ptr %v5, align 1
  %v404 = load i64, ptr @g.1, align 1
  %v405 = icmp ne i64 %v404, 0
  br i1 %v405, label %ok407, label %trap406
trap406:
  call void @native_trap()
  unreachable
ok407:
  %v408 = load i64, ptr %v6, align 1
  %v409 = icmp ne i64 %v408, 0
  br i1 %v409, label %ok411, label %trap410
trap410:
  call void @native_trap()
  unreachable
ok411:
  %v412 = inttoptr i64 %v408 to ptr
  %v413 = getelementptr i64, ptr %v412, i64 1
  %v414 = load i32, ptr %v413, align 1
  %v415 = icmp ne i32 %v414, 6
  %v416 = zext i1 %v415 to i32
  %v420 = icmp ne i32 %v416, 0
  br i1 %v420, label %then419, label %else418
then419:
  call void @native_trap()
  unreachable
else418:
  br label %block417
block417:
  %v421 = load i64, ptr %v6, align 1
  %v422 = call i32 @native_ref_test(i64 %v421, i64 346, i32 0, i32 0)
  %v423 = icmp ne i32 %v422, 0
  br i1 %v423, label %ok425, label %trap424
trap424:
  call void @native_trap()
  unreachable
ok425:
  %v426 = icmp ne i64 %v421, 0
  br i1 %v426, label %ok428, label %trap427
trap427:
  call void @native_trap()
  unreachable
ok428:
  %v429 = inttoptr i64 %v421 to ptr
  %v430 = getelementptr i64, ptr %v429, i64 3
  %v431 = load i64, ptr %v430, align 1
  %v432 = icmp ne i64 %v431, 0
  br i1 %v432, label %ok434, label %trap433
trap433:
  call void @native_trap()
  unreachable
ok434:
  %v435 = inttoptr i64 %v431 to ptr
  %v436 = getelementptr i64, ptr %v435, i64 1
  %v437 = load i64, ptr %v436, align 1
  store i64 %v437, ptr %v6, align 1
  %v438 = load i64, ptr @g.5, align 1
  %v439 = icmp ne i64 %v438, 0
  br i1 %v439, label %ok441, label %trap440
trap440:
  call void @native_trap()
  unreachable
ok441:
  %v442 = load i64, ptr @g.4, align 1
  %v443 = icmp ne i64 %v442, 0
  br i1 %v443, label %ok445, label %trap444
trap444:
  call void @native_trap()
  unreachable
ok445:
  %v446 = load i64, ptr %v7, align 1
  %v447 = getelementptr i64, ptr %roots, i64 12
  store i64 %v446, ptr %v447, align 1
  %v448 = getelementptr i64, ptr %roots, i64 2
  store i64 10, ptr %v448, align 1
  %v449 = call tailcc i64 @f.45(i64 %v446)
  %v450 = icmp eq i64 %v449, 0
  %v451 = zext i1 %v450 to i32
  %v456 = icmp ne i32 %v451, 0
  br i1 %v456, label %then455, label %else454
then455:
  %v457 = load i64, ptr @g.10, align 1
  store i64 %v457, ptr %slot452, align 1
  br label %block453
else454:
  %v458 = load i64, ptr @g.1, align 1
  %v459 = icmp ne i64 %v458, 0
  br i1 %v459, label %ok461, label %trap460
trap460:
  call void @native_trap()
  unreachable
ok461:
  %v462 = load i64, ptr %v7, align 1
  %v463 = icmp ne i64 %v462, 0
  br i1 %v463, label %ok465, label %trap464
trap464:
  call void @native_trap()
  unreachable
ok465:
  %v466 = inttoptr i64 %v462 to ptr
  %v467 = getelementptr i64, ptr %v466, i64 1
  %v468 = load i32, ptr %v467, align 1
  %v469 = icmp ne i32 %v468, 6
  %v470 = zext i1 %v469 to i32
  %v474 = icmp ne i32 %v470, 0
  br i1 %v474, label %then473, label %else472
then473:
  call void @native_trap()
  unreachable
else472:
  br label %block471
block471:
  %v475 = load i64, ptr %v7, align 1
  %v476 = call i32 @native_ref_test(i64 %v475, i64 346, i32 0, i32 0)
  %v477 = icmp ne i32 %v476, 0
  br i1 %v477, label %ok479, label %trap478
trap478:
  call void @native_trap()
  unreachable
ok479:
  %v480 = icmp ne i64 %v475, 0
  br i1 %v480, label %ok482, label %trap481
trap481:
  call void @native_trap()
  unreachable
ok482:
  %v483 = inttoptr i64 %v475 to ptr
  %v484 = getelementptr i64, ptr %v483, i64 3
  %v485 = load i64, ptr %v484, align 1
  %v486 = icmp ne i64 %v485, 0
  br i1 %v486, label %ok488, label %trap487
trap487:
  call void @native_trap()
  unreachable
ok488:
  %v489 = inttoptr i64 %v485 to ptr
  %v490 = getelementptr i64, ptr %v489, i64 1
  %v491 = load i64, ptr %v490, align 1
  store i64 %v491, ptr %slot452, align 1
  br label %block453
block453:
  %v492 = load i64, ptr %slot452, align 1
  store i64 %v492, ptr %v7, align 1
  %v493 = load i32, ptr %slot4, align 1
  %v494 = icmp eq i32 %v493, 0
  %v495 = zext i1 %v494 to i32
  %v499 = icmp ne i32 %v495, 0
  br i1 %v499, label %then498, label %else497
then498:
  call void @native_trap()
  unreachable
else497:
  br label %block496
block496:
  %v500 = load i64, ptr %v1, align 1
  %v501 = load i64, ptr %v2, align 1
  %v502 = load i32, ptr %slot3, align 1
  %v503 = load i32, ptr %slot4, align 1
  %v504 = load i64, ptr %v5, align 1
  %v505 = load i64, ptr %v6, align 1
  %v506 = load i64, ptr %v7, align 1
  call void @native_roots_leave(ptr %roots)
  %v507 = tail call tailcc i64 @f.103(i64 %v500, i64 %v501, i32 %v502, i32 %v503, i64 %v504, i64 %v505, i64 %v506)
  ret i64 %v507
block240:
  %v508 = load i64, ptr %slot239, align 1
  store i64 %v508, ptr %slot14, align 1
  br label %return15
return15:
  %v509 = load i64, ptr %slot14, align 1
  call void @native_roots_leave(ptr %roots)
  ret i64 %v509
}
