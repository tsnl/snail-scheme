(func $function239 (type $call207) (param $environment eqref) (param $argument859 (ref $type13)) (param $argument860 (ref $type13)) (param $argument861 (ref $type13)) (result (ref $type196))
  (local $local0 (ref null $type13))
  (local $local1 (ref null $type13))
  (local $local3 (ref null $type13))
  (local $local4 (ref null $type13))
  (local $local6 (ref null $type13))
  (local $local9 (ref null $type13))
  (local $local10 (ref null $type13))
  (local $local12 (ref null $type13))
  (local $local13 (ref null $type13))
  (local $local15 (ref null $type13))
  (local $local20 (ref null $type13))
  (local $local21 (ref null $type13))
  (local $local27 (ref null $type13))
  (local $local28 (ref null $type13))
  (local $local29 (ref null $type13))
  (local $local31 (ref null $type13))
  (local $local33 (ref null $type13))
  (local $local34 (ref null $type13))
  (local $local35 (ref null $type13))
  (local $local36 (ref null $type13))
  (local $local38 (ref null $type13))
  (local $local41 (ref null $type13))
  (local $local42 (ref null $type13))
  (local $local43 (ref null $type13))
  (local $local45 (ref null $type13))
  (local $local46 (ref null $type13))
  (local $local49 (ref null $type13))
  (local $local50 (ref null $type13))
  (local $local52 (ref null $type13))
  (local $local56 (ref null $type13))
  (local $local57 (ref null $type13))
  (local $local64 (ref null $type13))
  (local $local65 (ref null $type13))
  (local $local66 (ref null $type13))
  (local $local68 (ref null $type13))
  (local $local70 (ref null $type13))
  (local $local71 (ref null $type13))
  (local $local73 (ref null $type13))
  (local $local74 (ref null $type13))
  (local $local76 (ref null $type13))
  (local $local77 (ref null $type13))
  (local $local78 (ref null $type13))
  (local $local79 (ref null $type13))
  (local $local81 (ref null $type13))
  (local $local82 (ref null $type13))
  (local $local85 (ref null $type13))
  (local $local88 (ref null $type13))
  (local $local89 (ref null $type13))
  (local $local90 (ref null $type13))
  (local $local92 (ref null $type13))
  (local $local93 (ref null $type13))
  (local $local96 (ref null $type13))
  (local $local97 (ref null $type13))
  (local $local99 (ref null $type13))
  (local $local103 (ref null $type13))
  (local $local104 (ref null $type13))
  (local $local111 (ref null $type13))
  (local $local112 (ref null $type13))
  (local $local117 (ref null $type13))
  (local $local118 (ref null $type13))
  (local $local120 (ref null $type13))
  (local $local121 (ref null $type13))
  (local $local125 (ref null $type13))
  (local $local126 (ref null $type13))
  (local $local128 (ref null $type13))
  (local $local129 (ref null $type13))
  (local $local131 (ref null $type13))
  (local $local133 (ref null $type13))
  (local $local134 (ref null $type13))
  (local $local135 (ref null $type13))
  (local $local137 (ref null $type13))
  (local $local143 (ref null $type13))
  (local $local144 (ref null $type13))
  (local $local146 (ref null $type13))
  (local $local148 (ref null $type13))
  (local $local149 (ref null $type13))
  (local $local151 (ref null $type13))
  (local $local152 (ref null $type13))
  (local $local154 (ref null $type13))
  (local $local158 (ref null $type13))
  (local $local159 (ref null $type13))
  (local $local161 (ref null $type13))
  (local $local163 (ref null $type13))
  (local $local164 (ref null $type13))
  (local $local166 (ref null $type13))
  (local $local167 (ref null $type13))
  (local $local170 (ref null $type13))
  (local $local173 (ref null $type13))
  (local $local176 (ref null $type13))
  (local $local2 (ref null $type99))
  (local $local5 (ref null $type99))
  (local $local11 (ref null $type99))
  (local $local14 (ref null $type99))
  (local $local22 (ref null $type99))
  (local $local30 (ref null $type99))
  (local $local44 (ref null $type99))
  (local $local47 (ref null $type99))
  (local $local58 (ref null $type99))
  (local $local67 (ref null $type99))
  (local $local72 (ref null $type99))
  (local $local75 (ref null $type99))
  (local $local80 (ref null $type99))
  (local $local83 (ref null $type99))
  (local $local91 (ref null $type99))
  (local $local94 (ref null $type99))
  (local $local105 (ref null $type99))
  (local $local113 (ref null $type99))
  (local $local119 (ref null $type99))
  (local $local127 (ref null $type99))
  (local $local130 (ref null $type99))
  (local $local136 (ref null $type99))
  (local $local145 (ref null $type99))
  (local $local150 (ref null $type99))
  (local $local153 (ref null $type99))
  (local $local160 (ref null $type99))
  (local $local165 (ref null $type99))
  (local $local168 (ref null $type99))
  (local $local7 (ref null $type207))
  (local $local16 (ref null $type207))
  (local $local51 (ref null $type207))
  (local $local87 (ref null $type207))
  (local $local98 (ref null $type207))
  (local $local122 (ref null $type207))
  (local $local132 (ref null $type207))
  (local $local138 (ref null $type207))
  (local $local155 (ref null $type207))
  (local $local8 (ref null $type196))
  (local $local18 (ref null $type196))
  (local $local116 (ref null $type196))
  (local $local124 (ref null $type196))
  (local $local139 (ref null $type196))
  (local $local141 (ref null $type196))
  (local $local17 (ref null $type201))
  (local $local25 (ref null $type201))
  (local $local140 (ref null $type201))
  (local $local142 (ref null $type201))
  (local $local23 (ref null $type102))
  (local $local53 (ref null $type102))
  (local $local100 (ref null $type102))
  (local $local114 (ref null $type102))
  (local $local171 (ref null $type102))
  (local $local174 (ref null $type102))
  (local $local177 (ref null $type102))
  (local $local24 (ref null $type200))
  (local $local175 (ref null $type200))
  (local $local32 (ref null $type98))
  (local $local37 (ref null $type98))
  (local $local48 (ref null $type98))
  (local $local69 (ref null $type98))
  (local $local84 (ref null $type98))
  (local $local86 (ref null $type98))
  (local $local95 (ref null $type98))
  (local $local55 (ref null $type18))
  (local $local102 (ref null $type18))
  (local $local59 (ref null $type203))
  (local $local106 (ref null $type203))
  (local $local147 (ref null $type103))
  (local $local162 (ref null $type103))
  (local $local169 (ref null $type103))
  (local $local19 i32)
  (local $local26 i32)
  (local $local39 i32)
  (local $local40 i32)
  (local $local54 i32)
  (local $local61 i32)
  (local $local62 i32)
  (local $local63 i32)
  (local $local101 i32)
  (local $local108 i32)
  (local $local109 i32)
  (local $local110 i32)
  (local $local115 i32)
  (local $local123 i32)
  (local $local156 i32)
  (local $local157 i32)
  (local $local172 i32)
  (local $local60 i64)
  (local $local107 i64)
  (local.set $local176
   (ref.as_non_null
    (local.get $argument859)
   )
  )
  (local.set $local177
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (if (result (ref $type196))
   (call $function109
    (struct.get $type102 1
     (ref.as_non_null
      (local.get $local177)
     )
    )
    (ref.as_non_null
     (local.get $local176)
    )
   )
   (then
    (local.set $local173
     (ref.as_non_null
      (local.get $argument860)
     )
    )
    (local.set $local174
     (ref.as_non_null
      (global.get $global367)
     )
    )
    (local.set $local172
     (call $function109
      (struct.get $type102 1
       (ref.as_non_null
        (local.get $local174)
       )
      )
      (ref.as_non_null
       (local.get $local173)
      )
     )
    )
    (local.set $local175
     (ref.as_non_null
      (global.get $global771)
     )
    )
    (return_call $function212
     (struct.get $type200 1
      (ref.as_non_null
       (local.get $local175)
      )
     )
     (local.get $local172)
    )
   )
   (else
    (local.set $local170
     (ref.as_non_null
      (local.get $argument860)
     )
    )
    (local.set $local171
     (ref.as_non_null
      (global.get $global367)
     )
    )
    (if (result (ref $type196))
     (call $function109
      (struct.get $type102 1
       (ref.as_non_null
        (local.get $local171)
       )
      )
      (ref.as_non_null
       (local.get $local170)
      )
     )
     (then
      (ref.as_non_null
       (global.get $global770)
      )
     )
     (else
      (local.set $local159
       (ref.as_non_null
        (local.get $argument859)
       )
      )
      (local.set $local160
       (ref.as_non_null
        (global.get $global343)
       )
      )
      (local.set $local158
       (call $function103
        (struct.get $type99 1
         (ref.as_non_null
          (local.get $local160)
         )
        )
        (ref.as_non_null
         (local.get $local159)
        )
       )
      )
      (local.set $local161
       (ref.as_non_null
        (global.get $global781)
       )
      )
      (local.set $local162
       (ref.as_non_null
        (global.get $global373)
       )
      )
      (local.set $local157
       (call $function112
        (struct.get $type103 1
         (ref.as_non_null
          (local.get $local162)
         )
        )
        (ref.as_non_null
         (local.get $local158)
        )
        (ref.as_non_null
         (local.get $local161)
        )
       )
      )
      (local.set $local156
       (i32.const 1)
      )
      (if
       (i32.eqz
        (local.get $local156)
       )
       (then
        (unreachable)
       )
      )
      (if (result (ref $type196))
       (if (result i32)
        (local.get $local157)
        (then
         (if
          (i32.eqz
           (local.get $local156)
          )
          (then
           (unreachable)
          )
         )
         (local.get $local157)
        )
        (else
         (local.set $local164
          (ref.as_non_null
           (local.get $argument859)
          )
         )
         (local.set $local165
          (ref.as_non_null
           (global.get $global343)
          )
         )
         (local.set $local163
          (call $function103
           (struct.get $type99 1
            (ref.as_non_null
             (local.get $local165)
            )
           )
           (ref.as_non_null
            (local.get $local164)
           )
          )
         )
         (local.set $local167
          (ref.as_non_null
           (local.get $argument860)
          )
         )
         (local.set $local168
          (ref.as_non_null
           (global.get $global343)
          )
         )
         (local.set $local166
          (call $function103
           (struct.get $type99 1
            (ref.as_non_null
             (local.get $local168)
            )
           )
           (ref.as_non_null
            (local.get $local167)
           )
          )
         )
         (local.set $local169
          (ref.as_non_null
           (global.get $global373)
          )
         )
         (call $function112
          (struct.get $type103 1
           (ref.as_non_null
            (local.get $local169)
           )
          )
          (ref.as_non_null
           (local.get $local163)
          )
          (ref.as_non_null
           (local.get $local166)
          )
         )
        )
       )
       (then
        (local.set $local149
         (ref.as_non_null
          (local.get $argument859)
         )
        )
        (local.set $local150
         (ref.as_non_null
          (global.get $global345)
         )
        )
        (local.set $local148
         (call $function104
          (struct.get $type99 1
           (ref.as_non_null
            (local.get $local150)
           )
          )
          (ref.as_non_null
           (local.get $local149)
          )
         )
        )
        (local.set $local152
         (ref.as_non_null
          (local.get $argument860)
         )
        )
        (local.set $local153
         (ref.as_non_null
          (global.get $global345)
         )
        )
        (local.set $local151
         (call $function104
          (struct.get $type99 1
           (ref.as_non_null
            (local.get $local153)
           )
          )
          (ref.as_non_null
           (local.get $local152)
          )
         )
        )
        (local.set $local154
         (ref.as_non_null
          (local.get $argument861)
         )
        )
        (if
         (i32.eqz
          (global.get $ready858)
         )
         (then
          (unreachable)
         )
        )
        (local.set $local155
         (ref.as_non_null
          (global.get $global858)
         )
        )
        (return_call $function239
         (struct.get $type207 1
          (ref.as_non_null
           (local.get $local155)
          )
         )
         (ref.as_non_null
          (local.get $local148)
         )
         (ref.as_non_null
          (local.get $local151)
         )
         (ref.as_non_null
          (local.get $local154)
         )
        )
       )
       (else
        (local.set $local144
         (ref.as_non_null
          (local.get $argument859)
         )
        )
        (local.set $local145
         (ref.as_non_null
          (global.get $global343)
         )
        )
        (local.set $local143
         (call $function103
          (struct.get $type99 1
           (ref.as_non_null
            (local.get $local145)
           )
          )
          (ref.as_non_null
           (local.get $local144)
          )
         )
        )
        (local.set $local146
         (ref.as_non_null
          (global.get $global782)
         )
        )
        (local.set $local147
         (ref.as_non_null
          (global.get $global373)
         )
        )
        (if (result (ref $type196))
         (call $function112
          (struct.get $type103 1
           (ref.as_non_null
            (local.get $local147)
           )
          )
          (ref.as_non_null
           (local.get $local143)
          )
          (ref.as_non_null
           (local.get $local146)
          )
         )
         (then
          (local.set $local118
           (ref.as_non_null
            (local.get $argument859)
           )
          )
          (local.set $local119
           (ref.as_non_null
            (global.get $global345)
           )
          )
          (local.set $local117
           (call $function104
            (struct.get $type99 1
             (ref.as_non_null
              (local.get $local119)
             )
            )
            (ref.as_non_null
             (local.get $local118)
            )
           )
          )
          (local.set $local120
           (ref.as_non_null
            (local.get $argument860)
           )
          )
          (local.set $local121
           (ref.as_non_null
            (local.get $argument861)
           )
          )
          (if
           (i32.eqz
            (global.get $ready858)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local122
           (ref.as_non_null
            (global.get $global858)
           )
          )
          (local.set $local116
           (call $function239
            (struct.get $type207 1
             (ref.as_non_null
              (local.get $local122)
             )
            )
            (ref.as_non_null
             (local.get $local117)
            )
            (ref.as_non_null
             (local.get $local120)
            )
            (ref.as_non_null
             (local.get $local121)
            )
           )
          )
          (local.set $local115
           (i32.const 1)
          )
          (if
           (i32.eqz
            (local.get $local115)
           )
           (then
            (unreachable)
           )
          )
          (local.set $local141
           (ref.as_non_null
            (local.get $local116)
           )
          )
          (local.set $local142
           (ref.as_non_null
            (global.get $global773)
           )
          )
          (if (result (ref $type196))
           (call $function213
            (struct.get $type201 1
             (ref.as_non_null
              (local.get $local142)
             )
            )
            (ref.as_non_null
             (local.get $local141)
            )
           )
           (then
            (if
             (i32.eqz
              (local.get $local115)
             )
             (then
              (unreachable)
             )
            )
            (ref.as_non_null
             (local.get $local116)
            )
           )
           (else
            (local.set $local126
             (ref.as_non_null
              (local.get $argument859)
             )
            )
            (local.set $local127
             (ref.as_non_null
              (global.get $global345)
             )
            )
            (local.set $local125
             (call $function104
              (struct.get $type99 1
               (ref.as_non_null
                (local.get $local127)
               )
              )
              (ref.as_non_null
               (local.get $local126)
              )
             )
            )
            (local.set $local129
             (ref.as_non_null
              (local.get $argument860)
             )
            )
            (local.set $local130
             (ref.as_non_null
              (global.get $global345)
             )
            )
            (local.set $local128
             (call $function104
              (struct.get $type99 1
               (ref.as_non_null
                (local.get $local130)
               )
              )
              (ref.as_non_null
               (local.get $local129)
              )
             )
            )
            (local.set $local131
             (ref.as_non_null
              (local.get $argument861)
             )
            )
            (if
             (i32.eqz
              (global.get $ready858)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local132
             (ref.as_non_null
              (global.get $global858)
             )
            )
            (local.set $local124
             (call $function239
              (struct.get $type207 1
               (ref.as_non_null
                (local.get $local132)
               )
              )
              (ref.as_non_null
               (local.get $local125)
              )
              (ref.as_non_null
               (local.get $local128)
              )
              (ref.as_non_null
               (local.get $local131)
              )
             )
            )
            (local.set $local123
             (i32.const 1)
            )
            (if
             (i32.eqz
              (local.get $local123)
             )
             (then
              (unreachable)
             )
            )
            (local.set $local139
             (ref.as_non_null
              (local.get $local124)
             )
            )
            (local.set $local140
             (ref.as_non_null
              (global.get $global773)
             )
            )
            (if (result (ref $type196))
             (call $function213
              (struct.get $type201 1
               (ref.as_non_null
                (local.get $local140)
               )
              )
              (ref.as_non_null
               (local.get $local139)
              )
             )
             (then
              (if
               (i32.eqz
                (local.get $local123)
               )
               (then
                (unreachable)
               )
              )
              (ref.as_non_null
               (local.get $local124)
              )
             )
             (else
              (local.set $local133
               (ref.as_non_null
                (local.get $argument859)
               )
              )
              (local.set $local135
               (ref.as_non_null
                (local.get $argument860)
               )
              )
              (local.set $local136
               (ref.as_non_null
                (global.get $global345)
               )
              )
              (local.set $local134
               (call $function104
                (struct.get $type99 1
                 (ref.as_non_null
                  (local.get $local136)
                 )
                )
                (ref.as_non_null
                 (local.get $local135)
                )
               )
              )
              (local.set $local137
               (ref.as_non_null
                (local.get $argument861)
               )
              )
              (if
               (i32.eqz
                (global.get $ready858)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local138
               (ref.as_non_null
                (global.get $global858)
               )
              )
              (return_call $function239
               (struct.get $type207 1
                (ref.as_non_null
                 (local.get $local138)
                )
               )
               (ref.as_non_null
                (local.get $local133)
               )
               (ref.as_non_null
                (local.get $local134)
               )
               (ref.as_non_null
                (local.get $local137)
               )
              )
             )
            )
           )
          )
         )
         (else
          (local.set $local112
           (ref.as_non_null
            (local.get $argument859)
           )
          )
          (local.set $local113
           (ref.as_non_null
            (global.get $global343)
           )
          )
          (local.set $local111
           (call $function103
            (struct.get $type99 1
             (ref.as_non_null
              (local.get $local113)
             )
            )
            (ref.as_non_null
             (local.get $local112)
            )
           )
          )
          (local.set $local114
           (ref.as_non_null
            (global.get $global369)
           )
          )
          (local.set $local110
           (call $function110
            (struct.get $type102 1
             (ref.as_non_null
              (local.get $local114)
             )
            )
            (ref.as_non_null
             (local.get $local111)
            )
           )
          )
          (if (result (ref $type196))
           (i32.eqz
            (local.get $local110)
           )
           (then
            (local.set $local104
             (ref.as_non_null
              (local.get $argument859)
             )
            )
            (local.set $local105
             (ref.as_non_null
              (global.get $global343)
             )
            )
            (local.set $local103
             (call $function103
              (struct.get $type99 1
               (ref.as_non_null
                (local.get $local105)
               )
              )
              (ref.as_non_null
               (local.get $local104)
              )
             )
            )
            (local.set $local106
             (ref.as_non_null
              (global.get $global787)
             )
            )
            (local.set $local102
             (call $function217
              (struct.get $type203 1
               (ref.as_non_null
                (local.get $local106)
               )
              )
              (ref.as_non_null
               (local.get $local103)
              )
             )
            )
            (local.set $local107
             (i64.const 0)
            )
            (if
             (i64.ge_u
              (local.get $local107)
              (i64.extend_i32_u
               (struct.get $type18 1
                (ref.as_non_null
                 (local.get $local102)
                )
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $local108
             (i32.wrap_i64
              (local.get $local107)
             )
            )
            (local.set $local101
             (array.get $type19
              (call $string-block
               (ref.as_non_null
                (local.get $local102)
               )
               (local.get $local108)
              )
              (i32.and
               (local.get $local108)
               (i32.const 8191)
              )
             )
            )
            (local.set $local109
             (i32.const 63)
            )
            (if (result (ref $type196))
             (i32.eq
              (local.get $local101)
              (local.get $local109)
             )
             (then
              (local.set $local66
               (ref.as_non_null
                (local.get $argument859)
               )
              )
              (local.set $local67
               (ref.as_non_null
                (global.get $global343)
               )
              )
              (local.set $local65
               (call $function103
                (struct.get $type99 1
                 (ref.as_non_null
                  (local.get $local67)
                 )
                )
                (ref.as_non_null
                 (local.get $local66)
                )
               )
              )
              (local.set $local68
               (ref.as_non_null
                (local.get $argument861)
               )
              )
              (local.set $local69
               (ref.as_non_null
                (global.get $global398)
               )
              )
              (local.set $local64
               (call $function118
                (struct.get $type98 1
                 (ref.as_non_null
                  (local.get $local69)
                 )
                )
                (ref.as_non_null
                 (local.get $local65)
                )
                (ref.as_non_null
                 (local.get $local68)
                )
               )
              )
              (local.set $local63
               (i32.const 1)
              )
              (if
               (i32.eqz
                (local.get $local63)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local99
               (ref.as_non_null
                (local.get $local64)
               )
              )
              (local.set $local100
               (ref.as_non_null
                (global.get $global371)
               )
              )
              (if
               (call $function111
                (struct.get $type102 1
                 (ref.as_non_null
                  (local.get $local100)
                 )
                )
                (ref.as_non_null
                 (local.get $local99)
                )
               )
               (then
                (if
                 (i32.eqz
                  (local.get $local63)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local90
                 (ref.as_non_null
                  (local.get $local64)
                 )
                )
                (local.set $local91
                 (ref.as_non_null
                  (global.get $global345)
                 )
                )
                (local.set $local89
                 (call $function104
                  (struct.get $type99 1
                   (ref.as_non_null
                    (local.get $local91)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local90)
                  )
                 )
                )
                (local.set $local93
                 (ref.as_non_null
                  (local.get $argument859)
                 )
                )
                (local.set $local94
                 (ref.as_non_null
                  (global.get $global345)
                 )
                )
                (local.set $local92
                 (call $function104
                  (struct.get $type99 1
                   (ref.as_non_null
                    (local.get $local94)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local93)
                  )
                 )
                )
                (local.set $local95
                 (ref.as_non_null
                  (global.get $global340)
                 )
                )
                (local.set $local88
                 (call $function102
                  (struct.get $type98 1
                   (ref.as_non_null
                    (local.get $local95)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local89)
                  )
                  (ref.as_non_null
                   (local.get $local92)
                  )
                 )
                )
                (local.set $local96
                 (ref.as_non_null
                  (local.get $argument860)
                 )
                )
                (local.set $local97
                 (ref.as_non_null
                  (local.get $argument861)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready858)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local98
                 (ref.as_non_null
                  (global.get $global858)
                 )
                )
                (return_call $function239
                 (struct.get $type207 1
                  (ref.as_non_null
                   (local.get $local98)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local88)
                 )
                 (ref.as_non_null
                  (local.get $local96)
                 )
                 (ref.as_non_null
                  (local.get $local97)
                 )
                )
               )
               (else
                (local.set $local71
                 (ref.as_non_null
                  (local.get $argument859)
                 )
                )
                (local.set $local72
                 (ref.as_non_null
                  (global.get $global345)
                 )
                )
                (local.set $local70
                 (call $function104
                  (struct.get $type99 1
                   (ref.as_non_null
                    (local.get $local72)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local71)
                  )
                 )
                )
                (local.set $local74
                 (ref.as_non_null
                  (local.get $argument860)
                 )
                )
                (local.set $local75
                 (ref.as_non_null
                  (global.get $global345)
                 )
                )
                (local.set $local73
                 (call $function104
                  (struct.get $type99 1
                   (ref.as_non_null
                    (local.get $local75)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local74)
                  )
                 )
                )
                (local.set $local79
                 (ref.as_non_null
                  (local.get $argument859)
                 )
                )
                (local.set $local80
                 (ref.as_non_null
                  (global.get $global343)
                 )
                )
                (local.set $local78
                 (call $function103
                  (struct.get $type99 1
                   (ref.as_non_null
                    (local.get $local80)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local79)
                  )
                 )
                )
                (local.set $local82
                 (ref.as_non_null
                  (local.get $argument860)
                 )
                )
                (local.set $local83
                 (ref.as_non_null
                  (global.get $global343)
                 )
                )
                (local.set $local81
                 (call $function103
                  (struct.get $type99 1
                   (ref.as_non_null
                    (local.get $local83)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local82)
                  )
                 )
                )
                (local.set $local84
                 (ref.as_non_null
                  (global.get $global340)
                 )
                )
                (local.set $local77
                 (call $function102
                  (struct.get $type98 1
                   (ref.as_non_null
                    (local.get $local84)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local78)
                  )
                  (ref.as_non_null
                   (local.get $local81)
                  )
                 )
                )
                (local.set $local85
                 (ref.as_non_null
                  (local.get $argument861)
                 )
                )
                (local.set $local86
                 (ref.as_non_null
                  (global.get $global340)
                 )
                )
                (local.set $local76
                 (call $function102
                  (struct.get $type98 1
                   (ref.as_non_null
                    (local.get $local86)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local77)
                  )
                  (ref.as_non_null
                   (local.get $local85)
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready858)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local87
                 (ref.as_non_null
                  (global.get $global858)
                 )
                )
                (return_call $function239
                 (struct.get $type207 1
                  (ref.as_non_null
                   (local.get $local87)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local70)
                 )
                 (ref.as_non_null
                  (local.get $local73)
                 )
                 (ref.as_non_null
                  (local.get $local76)
                 )
                )
               )
              )
              (unreachable)
             )
             (else
              (local.set $local57
               (ref.as_non_null
                (local.get $argument859)
               )
              )
              (local.set $local58
               (ref.as_non_null
                (global.get $global343)
               )
              )
              (local.set $local56
               (call $function103
                (struct.get $type99 1
                 (ref.as_non_null
                  (local.get $local58)
                 )
                )
                (ref.as_non_null
                 (local.get $local57)
                )
               )
              )
              (local.set $local59
               (ref.as_non_null
                (global.get $global787)
               )
              )
              (local.set $local55
               (call $function217
                (struct.get $type203 1
                 (ref.as_non_null
                  (local.get $local59)
                 )
                )
                (ref.as_non_null
                 (local.get $local56)
                )
               )
              )
              (local.set $local60
               (i64.const 0)
              )
              (if
               (i64.ge_u
                (local.get $local60)
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (ref.as_non_null
                   (local.get $local55)
                  )
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $local61
               (i32.wrap_i64
                (local.get $local60)
               )
              )
              (local.set $local54
               (array.get $type19
                (call $string-block
                 (ref.as_non_null
                  (local.get $local55)
                 )
                 (local.get $local61)
                )
                (i32.and
                 (local.get $local61)
                 (i32.const 8191)
                )
               )
              )
              (local.set $local62
               (i32.const 42)
              )
              (if (result (ref $type196))
               (i32.eq
                (local.get $local54)
                (local.get $local62)
               )
               (then
                (local.set $local29
                 (ref.as_non_null
                  (local.get $argument859)
                 )
                )
                (local.set $local30
                 (ref.as_non_null
                  (global.get $global343)
                 )
                )
                (local.set $local28
                 (call $function103
                  (struct.get $type99 1
                   (ref.as_non_null
                    (local.get $local30)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local29)
                  )
                 )
                )
                (local.set $local31
                 (ref.as_non_null
                  (local.get $argument861)
                 )
                )
                (local.set $local32
                 (ref.as_non_null
                  (global.get $global398)
                 )
                )
                (local.set $local27
                 (call $function118
                  (struct.get $type98 1
                   (ref.as_non_null
                    (local.get $local32)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local28)
                  )
                  (ref.as_non_null
                   (local.get $local31)
                  )
                 )
                )
                (local.set $local26
                 (i32.const 1)
                )
                (if
                 (i32.eqz
                  (local.get $local26)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local52
                 (ref.as_non_null
                  (local.get $local27)
                 )
                )
                (local.set $local53
                 (ref.as_non_null
                  (global.get $global371)
                 )
                )
                (if
                 (call $function111
                  (struct.get $type102 1
                   (ref.as_non_null
                    (local.get $local53)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local52)
                  )
                 )
                 (then
                  (if
                   (i32.eqz
                    (local.get $local26)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local43
                   (ref.as_non_null
                    (local.get $local27)
                   )
                  )
                  (local.set $local44
                   (ref.as_non_null
                    (global.get $global345)
                   )
                  )
                  (local.set $local42
                   (call $function104
                    (struct.get $type99 1
                     (ref.as_non_null
                      (local.get $local44)
                     )
                    )
                    (ref.as_non_null
                     (local.get $local43)
                    )
                   )
                  )
                  (local.set $local46
                   (ref.as_non_null
                    (local.get $argument859)
                   )
                  )
                  (local.set $local47
                   (ref.as_non_null
                    (global.get $global345)
                   )
                  )
                  (local.set $local45
                   (call $function104
                    (struct.get $type99 1
                     (ref.as_non_null
                      (local.get $local47)
                     )
                    )
                    (ref.as_non_null
                     (local.get $local46)
                    )
                   )
                  )
                  (local.set $local48
                   (ref.as_non_null
                    (global.get $global395)
                   )
                  )
                  (local.set $local41
                   (call $function117
                    (struct.get $type98 1
                     (ref.as_non_null
                      (local.get $local48)
                     )
                    )
                    (ref.as_non_null
                     (local.get $local42)
                    )
                    (ref.as_non_null
                     (local.get $local45)
                    )
                   )
                  )
                  (local.set $local49
                   (ref.as_non_null
                    (local.get $argument860)
                   )
                  )
                  (local.set $local50
                   (ref.as_non_null
                    (local.get $argument861)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready858)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $local51
                   (ref.as_non_null
                    (global.get $global858)
                   )
                  )
                  (return_call $function239
                   (struct.get $type207 1
                    (ref.as_non_null
                     (local.get $local51)
                    )
                   )
                   (ref.as_non_null
                    (local.get $local41)
                   )
                   (ref.as_non_null
                    (local.get $local49)
                   )
                   (ref.as_non_null
                    (local.get $local50)
                   )
                  )
                 )
                 (else
                  (local.set $local33
                   (global.get $empty14)
                  )
                  (local.set $local35
                   (global.get $empty14)
                  )
                  (local.set $local36
                   (ref.as_non_null
                    (local.get $argument860)
                   )
                  )
                  (local.set $local37
                   (ref.as_non_null
                    (global.get $global340)
                   )
                  )
                  (local.set $local34
                   (call $function102
                    (struct.get $type98 1
                     (ref.as_non_null
                      (local.get $local37)
                     )
                    )
                    (ref.as_non_null
                     (local.get $local35)
                    )
                    (ref.as_non_null
                     (local.get $local36)
                    )
                   )
                  )
                  (local.set $local38
                   (ref.as_non_null
                    (local.get $argument860)
                   )
                  )
                  (local.set $local40
                   (i32.const 0)
                  )
                  (local.set $local39
                   (i32.const 1)
                  )
                  (drop
                   (i32.const 0)
                  )
                  (if
                   (i32.eqz
                    (local.get $local39)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (local.get $local40)
                  )
                  (return_call $function240
                   (ref.as_non_null
                    (local.get $argument859)
                   )
                   (ref.as_non_null
                    (local.get $argument861)
                   )
                   (local.get $local40)
                   (local.get $local39)
                   (ref.as_non_null
                    (local.get $local33)
                   )
                   (ref.as_non_null
                    (local.get $local34)
                   )
                   (ref.as_non_null
                    (local.get $local38)
                   )
                  )
                 )
                )
                (unreachable)
               )
               (else
                (ref.as_non_null
                 (global.get $global768)
                )
               )
              )
             )
            )
           )
           (else
            (local.set $local21
             (ref.as_non_null
              (local.get $argument860)
             )
            )
            (local.set $local22
             (ref.as_non_null
              (global.get $global343)
             )
            )
            (local.set $local20
             (call $function103
              (struct.get $type99 1
               (ref.as_non_null
                (local.get $local22)
               )
              )
              (ref.as_non_null
               (local.get $local21)
              )
             )
            )
            (local.set $local23
             (ref.as_non_null
              (global.get $global369)
             )
            )
            (local.set $local19
             (call $function110
              (struct.get $type102 1
               (ref.as_non_null
                (local.get $local23)
               )
              )
              (ref.as_non_null
               (local.get $local20)
              )
             )
            )
            (local.set $local24
             (ref.as_non_null
              (global.get $global771)
             )
            )
            (local.set $local18
             (call $function212
              (struct.get $type200 1
               (ref.as_non_null
                (local.get $local24)
               )
              )
              (local.get $local19)
             )
            )
            (local.set $local25
             (ref.as_non_null
              (global.get $global773)
             )
            )
            (if (result (ref $type196))
             (call $function213
              (struct.get $type201 1
               (ref.as_non_null
                (local.get $local25)
               )
              )
              (ref.as_non_null
               (local.get $local18)
              )
             )
             (then
              (local.set $local10
               (ref.as_non_null
                (local.get $argument859)
               )
              )
              (local.set $local11
               (ref.as_non_null
                (global.get $global343)
               )
              )
              (local.set $local9
               (call $function103
                (struct.get $type99 1
                 (ref.as_non_null
                  (local.get $local11)
                 )
                )
                (ref.as_non_null
                 (local.get $local10)
                )
               )
              )
              (local.set $local13
               (ref.as_non_null
                (local.get $argument860)
               )
              )
              (local.set $local14
               (ref.as_non_null
                (global.get $global343)
               )
              )
              (local.set $local12
               (call $function103
                (struct.get $type99 1
                 (ref.as_non_null
                  (local.get $local14)
                 )
                )
                (ref.as_non_null
                 (local.get $local13)
                )
               )
              )
              (local.set $local15
               (ref.as_non_null
                (local.get $argument861)
               )
              )
              (if
               (i32.eqz
                (global.get $ready858)
               )
               (then
                (unreachable)
               )
              )
              (local.set $local16
               (ref.as_non_null
                (global.get $global858)
               )
              )
              (local.set $local8
               (call $function239
                (struct.get $type207 1
                 (ref.as_non_null
                  (local.get $local16)
                 )
                )
                (ref.as_non_null
                 (local.get $local9)
                )
                (ref.as_non_null
                 (local.get $local12)
                )
                (ref.as_non_null
                 (local.get $local15)
                )
               )
              )
              (local.set $local17
               (ref.as_non_null
                (global.get $global773)
               )
              )
              (if (result (ref $type196))
               (call $function213
                (struct.get $type201 1
                 (ref.as_non_null
                  (local.get $local17)
                 )
                )
                (ref.as_non_null
                 (local.get $local8)
                )
               )
               (then
                (local.set $local1
                 (ref.as_non_null
                  (local.get $argument859)
                 )
                )
                (local.set $local2
                 (ref.as_non_null
                  (global.get $global345)
                 )
                )
                (local.set $local0
                 (call $function104
                  (struct.get $type99 1
                   (ref.as_non_null
                    (local.get $local2)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local1)
                  )
                 )
                )
                (local.set $local4
                 (ref.as_non_null
                  (local.get $argument860)
                 )
                )
                (local.set $local5
                 (ref.as_non_null
                  (global.get $global345)
                 )
                )
                (local.set $local3
                 (call $function104
                  (struct.get $type99 1
                   (ref.as_non_null
                    (local.get $local5)
                   )
                  )
                  (ref.as_non_null
                   (local.get $local4)
                  )
                 )
                )
                (local.set $local6
                 (ref.as_non_null
                  (local.get $argument861)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready858)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $local7
                 (ref.as_non_null
                  (global.get $global858)
                 )
                )
                (return_call $function239
                 (struct.get $type207 1
                  (ref.as_non_null
                   (local.get $local7)
                  )
                 )
                 (ref.as_non_null
                  (local.get $local0)
                 )
                 (ref.as_non_null
                  (local.get $local3)
                 )
                 (ref.as_non_null
                  (local.get $local6)
                 )
                )
               )
               (else
                (ref.as_non_null
                 (global.get $global768)
                )
               )
              )
             )
             (else
              (ref.as_non_null
               (global.get $global768)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
