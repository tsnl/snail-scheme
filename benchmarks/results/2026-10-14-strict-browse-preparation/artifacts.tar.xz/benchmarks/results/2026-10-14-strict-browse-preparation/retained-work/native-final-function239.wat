(func $function239 (type $call207) (param $0 (ref $type13)) (param $1 (ref $type13)) (param $2 (ref $type13)) (result (ref $type196))
  (local $3 (ref $type31))
  (local $4 (ref $type31))
  (local $5 (ref $type196))
  (local $6 (ref $type18))
  (local $7 (ref $type13))
  (local $8 (ref $type14))
  (local $9 i32)
  (local $10 i64)
  (local $scratch i32)
  (local $scratch_12 i32)
  (local $scratch_13 (ref $type196))
  (drop
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global353)
   )
  )
  (block $block
   (return
    (if (result (ref $type196))
     (i64.eqz
      (call $function107
       (local.get $0)
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global367)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global353)
       )
      )
      (return
       (if (result (ref $type196))
        (block (result i32)
         (local.set $scratch
          (i64.eqz
           (call $function107
            (local.get $1)
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global771)
          )
         )
         (local.get $scratch)
        )
        (then
         (ref.as_non_null
          (global.get $global769)
         )
        )
        (else
         (ref.as_non_null
          (global.get $global768)
         )
        )
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global367)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global353)
       )
      )
      (if (result (ref $type196))
       (i64.eqz
        (call $function107
         (local.get $1)
        )
       )
       (then
        (ref.as_non_null
         (global.get $global770)
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global343)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global373)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 6)
         )
         (then
          (unreachable)
         )
        )
        (if (result (ref $type196))
         (if (result i32)
          (local.tee $9
           (call $function112
            (struct.get $type32 0
             (struct.get $type31 1
              (ref.cast (ref $type31)
               (local.get $0)
              )
             )
            )
            (ref.as_non_null
             (global.get $global781)
            )
           )
          )
          (then
           (local.get $9)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global343)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global373)
            )
           )
           (if
            (i32.ne
             (struct.get $type13 0
              (local.get $0)
             )
             (i32.const 6)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.ne
             (struct.get $type13 0
              (local.get $1)
             )
             (i32.const 6)
            )
            (then
             (unreachable)
            )
           )
           (call $function112
            (struct.get $type32 0
             (struct.get $type31 1
              (ref.cast (ref $type31)
               (local.get $0)
              )
             )
            )
            (struct.get $type32 0
             (struct.get $type31 1
              (ref.cast (ref $type31)
               (local.get $1)
              )
             )
            )
           )
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global345)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 6)
           )
           (then
            (unreachable)
           )
          )
          (local.set $0
           (struct.get $type32 0
            (struct.get $type31 2
             (ref.cast (ref $type31)
              (local.get $0)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global345)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $1)
            )
            (i32.const 6)
           )
           (then
            (unreachable)
           )
          )
          (local.set $1
           (struct.get $type32 0
            (struct.get $type31 2
             (ref.cast (ref $type31)
              (local.get $1)
             )
            )
           )
          )
          (br $block)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global343)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global373)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 6)
           )
           (then
            (unreachable)
           )
          )
          (if (result (ref $type196))
           (call $function112
            (struct.get $type32 0
             (struct.get $type31 1
              (local.tee $3
               (ref.cast (ref $type31)
                (local.get $0)
               )
              )
             )
            )
            (ref.as_non_null
             (global.get $global782)
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global345)
             )
            )
            (if
             (i32.eqz
              (global.get $ready858)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global858)
             )
            )
            (local.set $5
             (call $function239
              (struct.get $type32 0
               (struct.get $type31 2
                (local.get $3)
               )
              )
              (local.get $1)
              (local.get $2)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global773)
             )
            )
            (if (result (ref $type196))
             (struct.get $type196 0
              (local.get $5)
             )
             (then
              (local.get $5)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global345)
               )
              )
              (if
               (i32.ne
                (struct.get $type13 0
                 (local.get $1)
                )
                (i32.const 6)
               )
               (then
                (unreachable)
               )
              )
              (local.set $7
               (struct.get $type32 0
                (struct.get $type31 2
                 (ref.cast (ref $type31)
                  (local.get $1)
                 )
                )
               )
              )
              (if
               (i32.eqz
                (global.get $ready858)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global858)
               )
              )
              (local.set $5
               (call $function239
                (struct.get $type32 0
                 (struct.get $type31 2
                  (local.get $3)
                 )
                )
                (local.get $7)
                (local.get $2)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global773)
               )
              )
              (if (result (ref $type196))
               (struct.get $type196 0
                (local.get $5)
               )
               (then
                (local.get $5)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global345)
                 )
                )
                (if
                 (i32.ne
                  (struct.get $type13 0
                   (local.get $1)
                  )
                  (i32.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $1
                 (struct.get $type32 0
                  (struct.get $type31 2
                   (ref.cast (ref $type31)
                    (local.get $1)
                   )
                  )
                 )
                )
                (br $block)
               )
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global343)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global369)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global353)
             )
            )
            (if (result (ref $type197))
             (i64.eq
              (call $function107
               (struct.get $type32 0
                (struct.get $type31 1
                 (local.get $3)
                )
               )
              )
              (i64.const 6)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global343)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global369)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global353)
               )
              )
              (if
               (i32.ne
                (struct.get $type13 0
                 (local.get $1)
                )
                (i32.const 6)
               )
               (then
                (unreachable)
               )
              )
              (if (result (ref $type197))
               (struct.get $type196 0
                (if (result (ref $type196))
                 (block (result i32)
                  (local.set $scratch_12
                   (i64.eq
                    (call $function107
                     (struct.get $type32 0
                      (struct.get $type31 1
                       (ref.cast (ref $type31)
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (i64.const 6)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global771)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global773)
                   )
                  )
                  (local.get $scratch_12)
                 )
                 (then
                  (ref.as_non_null
                   (global.get $global769)
                  )
                 )
                 (else
                  (ref.as_non_null
                   (global.get $global768)
                  )
                 )
                )
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global343)
                 )
                )
                (if
                 (i32.ne
                  (struct.get $type13 0
                   (local.get $1)
                  )
                  (i32.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $0
                 (struct.get $type32 0
                  (struct.get $type31 1
                   (ref.cast (ref $type31)
                    (local.get $1)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready858)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global858)
                 )
                )
                (if (result (ref $type197))
                 (struct.get $type196 0
                  (block (result (ref $type196))
                   (local.set $scratch_13
                    (call $function239
                     (struct.get $type32 0
                      (struct.get $type31 1
                       (local.get $3)
                      )
                     )
                     (local.get $0)
                     (local.get $2)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global773)
                    )
                   )
                   (local.get $scratch_13)
                  )
                 )
                 (then
                  (local.set $0
                   (struct.get $type32 0
                    (struct.get $type31 2
                     (local.get $3)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global345)
                   )
                  )
                  (if
                   (i32.ne
                    (struct.get $type13 0
                     (local.get $1)
                    )
                    (i32.const 6)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $1
                   (struct.get $type32 0
                    (struct.get $type31 2
                     (ref.cast (ref $type31)
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (br $block)
                 )
                 (else
                  (ref.as_non_null
                   (global.get $global768)
                  )
                 )
                )
               )
               (else
                (ref.as_non_null
                 (global.get $global768)
                )
               )
              )
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global343)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global787)
               )
              )
              (if
               (i32.ne
                (struct.get $type13 0
                 (local.tee $0
                  (struct.get $type32 0
                   (struct.get $type31 1
                    (local.get $3)
                   )
                  )
                 )
                )
                (i32.const 4)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global263)
               )
              )
              (local.set $10
               (call $foreign6
                (local.tee $9
                 (struct.get $type22 0
                  (struct.get $type21 1
                   (ref.cast (ref $type21)
                    (local.get $0)
                   )
                  )
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global61)
               )
              )
              (if
               (i64.gt_u
                (local.get $10)
                (i64.const 4294967294)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i64.eqz
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.tee $6
                   (call $function87
                    (local.get $9)
                    (local.get $10)
                    (call $string-new
                     (i32.wrap_i64
                      (local.get $10)
                     )
                    )
                    (i32.const 0)
                    (i32.const 1)
                    (i64.const 0)
                   )
                  )
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (if (result (ref $type197))
               (i32.eq
                (array.get $type19
                 (struct.get $type18 2
                  (local.get $6)
                 )
                 (i32.const 0)
                )
                (i32.const 63)
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global343)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global398)
                 )
                )
                (local.set $0
                 (call $function118
                  (struct.get $type32 0
                   (struct.get $type31 1
                    (local.get $3)
                   )
                  )
                  (local.get $2)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global371)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global353)
                 )
                )
                (if
                 (if (result i32)
                  (i64.eq
                   (call $function107
                    (local.get $0)
                   )
                   (i64.const 1)
                  )
                  (then
                   (if
                    (i32.ne
                     (struct.get $type13 0
                      (local.get $0)
                     )
                     (i32.const 1)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (struct.get $type15 1
                    (ref.cast (ref $type15)
                     (local.get $0)
                    )
                   )
                  )
                  (else
                   (i32.const 1)
                  )
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global345)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global340)
                   )
                  )
                  (if
                   (i32.ne
                    (struct.get $type13 0
                     (local.get $0)
                    )
                    (i32.const 6)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $0
                   (struct.new $type31
                    (i32.const 6)
                    (struct.new $type32
                     (struct.get $type32 0
                      (struct.get $type31 2
                       (ref.cast (ref $type31)
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (struct.new $type32
                     (struct.get $type32 0
                      (struct.get $type31 2
                       (local.get $3)
                      )
                     )
                    )
                   )
                  )
                  (br $block)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global345)
                   )
                  )
                  (if
                   (i32.ne
                    (struct.get $type13 0
                     (local.get $1)
                    )
                    (i32.const 6)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $0
                   (struct.get $type32 0
                    (struct.get $type31 2
                     (local.tee $4
                      (ref.cast (ref $type31)
                       (local.get $1)
                      )
                     )
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global343)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global340)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready858)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global858)
                   )
                  )
                  (return_call $function239
                   (struct.get $type32 0
                    (struct.get $type31 2
                     (local.get $3)
                    )
                   )
                   (local.get $0)
                   (struct.new $type31
                    (i32.const 6)
                    (struct.new $type32
                     (struct.new $type31
                      (i32.const 6)
                      (struct.new $type32
                       (struct.get $type32 0
                        (struct.get $type31 1
                         (local.get $3)
                        )
                       )
                      )
                      (struct.new $type32
                       (struct.get $type32 0
                        (struct.get $type31 1
                         (local.get $4)
                        )
                       )
                      )
                     )
                    )
                    (struct.new $type32
                     (local.get $2)
                    )
                   )
                  )
                 )
                )
                (unreachable)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global343)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global787)
                 )
                )
                (if
                 (i32.ne
                  (struct.get $type13 0
                   (local.tee $0
                    (struct.get $type32 0
                     (struct.get $type31 1
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (i32.const 4)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global263)
                 )
                )
                (local.set $10
                 (call $foreign6
                  (local.tee $9
                   (struct.get $type22 0
                    (struct.get $type21 1
                     (ref.cast (ref $type21)
                      (local.get $0)
                     )
                    )
                   )
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global61)
                 )
                )
                (if
                 (i64.gt_u
                  (local.get $10)
                  (i64.const 4294967294)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i64.eqz
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.tee $6
                     (call $function87
                      (local.get $9)
                      (local.get $10)
                      (call $string-new
                       (i32.wrap_i64
                        (local.get $10)
                       )
                      )
                      (i32.const 0)
                      (i32.const 1)
                      (i64.const 0)
                     )
                    )
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (if (result (ref $type197))
                 (i32.eq
                  (array.get $type19
                   (struct.get $type18 2
                    (local.get $6)
                   )
                   (i32.const 0)
                  )
                  (i32.const 42)
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global343)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global398)
                   )
                  )
                  (local.set $0
                   (call $function118
                    (struct.get $type32 0
                     (struct.get $type31 1
                      (local.get $3)
                     )
                    )
                    (local.get $2)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global371)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global353)
                   )
                  )
                  (if
                   (if (result i32)
                    (i64.eq
                     (call $function107
                      (local.get $0)
                     )
                     (i64.const 1)
                    )
                    (then
                     (if
                      (i32.ne
                       (struct.get $type13 0
                        (local.get $0)
                       )
                       (i32.const 1)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (struct.get $type15 1
                      (ref.cast (ref $type15)
                       (local.get $0)
                      )
                     )
                    )
                    (else
                     (i32.const 1)
                    )
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global345)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global395)
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $0)
                      )
                      (i32.const 6)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $0
                     (call $function117
                      (struct.get $type32 0
                       (struct.get $type31 2
                        (ref.cast (ref $type31)
                         (local.get $0)
                        )
                       )
                      )
                      (struct.get $type32 0
                       (struct.get $type31 2
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (br $block)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global340)
                     )
                    )
                    (return_call $function240
                     (local.get $3)
                     (local.get $2)
                     (i32.const 0)
                     (i32.const 1)
                     (local.tee $8
                      (global.get $empty14)
                     )
                     (struct.new $type31
                      (i32.const 6)
                      (struct.new $type32
                       (local.get $8)
                      )
                      (struct.new $type32
                       (local.get $1)
                      )
                     )
                     (local.get $1)
                    )
                   )
                  )
                  (unreachable)
                 )
                 (else
                  (ref.as_non_null
                   (global.get $global768)
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready858)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global858)
   )
  )
  (return_call $function239
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
 )
