(func $function240 (type $11) (param $0 (ref $type13)) (param $1 (ref $type13)) (param $2 i32) (param $3 i32) (param $4 (ref $type13)) (param $5 (ref $type13)) (param $6 (ref $type13)) (result (ref $type196))
  (local $7 i32)
  (local $8 (ref $type31))
  (local $9 (ref $type196))
  (local $10 (ref $type13))
  (local $scratch (ref $type196))
  (local $scratch_12 i32)
  (drop
   (ref.as_non_null
    (global.get $global367)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global353)
   )
  )
  (if (result (ref $type196))
   (if (result i32)
    (local.tee $7
     (i64.eqz
      (call $function107
       (local.get $5)
      )
     )
    )
    (then
     (local.get $7)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global345)
      )
     )
     (if
      (i32.ne
       (struct.get $type13 0
        (local.get $0)
       )
       (i32.const 6)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global343)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global340)
      )
     )
     (if
      (i32.eqz
       (global.get $ready858)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global858)
      )
     )
     (struct.get $type196 0
      (block (result (ref $type196))
       (local.set $scratch
        (call $function239
         (struct.get $type32 0
          (struct.get $type31 2
           (local.tee $8
            (ref.cast (ref $type31)
             (local.get $0)
            )
           )
          )
         )
         (local.get $6)
         (struct.new $type31
          (i32.const 6)
          (struct.new $type32
           (struct.new $type31
            (i32.const 6)
            (struct.new $type32
             (struct.get $type32 0
              (struct.get $type31 1
               (local.get $8)
              )
             )
            )
            (struct.new $type32
             (local.get $4)
            )
           )
          )
          (struct.new $type32
           (local.get $1)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global773)
        )
       )
       (local.get $scratch)
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global367)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global353)
     )
    )
    (if (result (ref $type196))
     (block (result i32)
      (local.set $scratch_12
       (i64.ne
        (call $function107
         (local.get $5)
        )
        (i64.const 0)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global771)
       )
      )
      (local.get $scratch_12)
     )
     (then
      (ref.as_non_null
       (global.get $global769)
      )
     )
     (else
      (ref.as_non_null
       (global.get $global768)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global367)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global353)
     )
    )
    (local.set $10
     (if (result (ref $type13))
      (i64.eqz
       (call $function107
        (local.get $6)
       )
      )
      (then
       (global.get $empty14)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global343)
        )
       )
       (if
        (i32.ne
         (struct.get $type13 0
          (local.get $6)
         )
         (i32.const 6)
        )
        (then
         (unreachable)
        )
       )
       (struct.get $type32 0
        (struct.get $type31 1
         (ref.cast (ref $type31)
          (local.get $6)
         )
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global340)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global816)
     )
    )
    (local.set $4
     (call $function225
      (local.get $4)
      (struct.new $type31
       (i32.const 6)
       (struct.new $type32
        (local.get $10)
       )
       (struct.new $type32
        (global.get $empty14)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global345)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $5)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type32 0
      (struct.get $type31 2
       (ref.cast (ref $type31)
        (local.get $5)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global367)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global353)
     )
    )
    (local.set $6
     (if (result (ref $type13))
      (i64.eqz
       (call $function107
        (local.get $6)
       )
      )
      (then
       (global.get $empty14)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global345)
        )
       )
       (if
        (i32.ne
         (struct.get $type13 0
          (local.get $6)
         )
         (i32.const 6)
        )
        (then
         (unreachable)
        )
       )
       (struct.get $type32 0
        (struct.get $type31 2
         (ref.cast (ref $type31)
          (local.get $6)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function240
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
     (local.get $6)
    )
   )
  )
 )
