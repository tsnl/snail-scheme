   c5ee0: 55                           	pushq	%rbp
   c5ee1: 48 89 e5                     	movq	%rsp, %rbp
   c5ee4: 41 57                        	pushq	%r15
   c5ee6: 41 56                        	pushq	%r14
   c5ee8: 41 54                        	pushq	%r12
   c5eea: 53                           	pushq	%rbx
   c5eeb: 48 83 ec 70                  	subq	$0x70, %rsp
   c5eef: 64 48 8b 04 25 28 00 00 00   	movq	%fs:0x28, %rax
   c5ef8: 48 89 45 d8                  	movq	%rax, -0x28(%rbp)
   c5efc: 48 8b 1d dd 85 00 00         	movq	0x85dd(%rip), %rbx      # 0xce4e0 <heap_bytes>
   c5f03: 48 8d 3d 9f 34 f4 ff         	leaq	-0xbcb61(%rip), %rdi    # 0x93a9 <writev+0x93a9>
   c5f0a: e8 f1 07 00 00               	callq	0xc6700 <getenv@plt>
   c5f0f: 48 85 c0                     	testq	%rax, %rax
   c5f12: 74 5a                        	je	0xc5f6e <main+0x8e>
   c5f14: 49 89 c7                     	movq	%rax, %r15
   c5f17: e8 64 08 00 00               	callq	0xc6780 <__errno_location@plt>
   c5f1c: 49 89 c6                     	movq	%rax, %r14
   c5f1f: c7 00 00 00 00 00            	movl	$0x0, (%rax)
   c5f25: 48 8d 75 98                  	leaq	-0x68(%rbp), %rsi
   c5f29: 4c 89 ff                     	movq	%r15, %rdi
   c5f2c: ba 0a 00 00 00               	movl	$0xa, %edx
   c5f31: e8 da 07 00 00               	callq	0xc6710 <__isoc23_strtoull@plt>
   c5f36: 48 89 c3                     	movq	%rax, %rbx
   c5f39: 41 0f b6 07                  	movzbl	(%r15), %eax
   c5f3d: 85 c0                        	testl	%eax, %eax
   c5f3f: 0f 84 59 06 00 00            	je	0xc659e <main+0x6be>
   c5f45: 83 f8 2d                     	cmpl	$0x2d, %eax
   c5f48: 0f 84 50 06 00 00            	je	0xc659e <main+0x6be>
   c5f4e: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   c5f52: 80 38 00                     	cmpb	$0x0, (%rax)
   c5f55: 0f 85 43 06 00 00            	jne	0xc659e <main+0x6be>
   c5f5b: 41 83 3e 00                  	cmpl	$0x0, (%r14)
   c5f5f: 0f 85 39 06 00 00            	jne	0xc659e <main+0x6be>
   c5f65: 48 85 db                     	testq	%rbx, %rbx
   c5f68: 0f 84 30 06 00 00            	je	0xc659e <main+0x6be>
   c5f6e: 49 89 de                     	movq	%rbx, %r14
   c5f71: 49 81 e6 00 80 ff ff         	andq	$-0x8000, %r14          # imm = 0x8000
   c5f78: 4c 89 35 61 85 00 00         	movq	%r14, 0x8561(%rip)      # 0xce4e0 <heap_bytes>
   c5f7f: 48 b8 00 00 00 00 00 00 00 c0	movabsq	$-0x4000000000000000, %rax # imm = 0xC000000000000000
   c5f89: 48 01 c3                     	addq	%rax, %rbx
   c5f8c: 48 0d 00 80 00 00            	orq	$0x8000, %rax           # imm = 0x8000
   c5f92: 48 39 c3                     	cmpq	%rax, %rbx
   c5f95: 0f 82 03 06 00 00            	jb	0xc659e <main+0x6be>
   c5f9b: 48 8b 1d 4e 85 00 00         	movq	0x854e(%rip), %rbx      # 0xce4f0 <minimum_budget>
   c5fa2: 48 8d 3d f6 30 f4 ff         	leaq	-0xbcf0a(%rip), %rdi    # 0x909f <writev+0x909f>
   c5fa9: e8 52 07 00 00               	callq	0xc6700 <getenv@plt>
   c5fae: 48 85 c0                     	testq	%rax, %rax
   c5fb1: 74 61                        	je	0xc6014 <main+0x134>
   c5fb3: 49 89 c7                     	movq	%rax, %r15
   c5fb6: e8 c5 07 00 00               	callq	0xc6780 <__errno_location@plt>
   c5fbb: 49 89 c6                     	movq	%rax, %r14
   c5fbe: c7 00 00 00 00 00            	movl	$0x0, (%rax)
   c5fc4: 48 8d 75 98                  	leaq	-0x68(%rbp), %rsi
   c5fc8: 4c 89 ff                     	movq	%r15, %rdi
   c5fcb: ba 0a 00 00 00               	movl	$0xa, %edx
   c5fd0: e8 3b 07 00 00               	callq	0xc6710 <__isoc23_strtoull@plt>
   c5fd5: 48 89 c3                     	movq	%rax, %rbx
   c5fd8: 41 0f b6 07                  	movzbl	(%r15), %eax
   c5fdc: 85 c0                        	testl	%eax, %eax
   c5fde: 0f 84 ba 05 00 00            	je	0xc659e <main+0x6be>
   c5fe4: 83 f8 2d                     	cmpl	$0x2d, %eax
   c5fe7: 0f 84 b1 05 00 00            	je	0xc659e <main+0x6be>
   c5fed: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   c5ff1: 80 38 00                     	cmpb	$0x0, (%rax)
   c5ff4: 0f 85 a4 05 00 00            	jne	0xc659e <main+0x6be>
   c5ffa: 41 83 3e 00                  	cmpl	$0x0, (%r14)
   c5ffe: 0f 85 9a 05 00 00            	jne	0xc659e <main+0x6be>
   c6004: 48 85 db                     	testq	%rbx, %rbx
   c6007: 0f 84 91 05 00 00            	je	0xc659e <main+0x6be>
   c600d: 4c 8b 35 cc 84 00 00         	movq	0x84cc(%rip), %r14      # 0xce4e0 <heap_bytes>
   c6014: 48 89 1d cd 84 00 00         	movq	%rbx, 0x84cd(%rip)      # 0xce4e8 <budget>
   c601b: 48 89 1d ce 84 00 00         	movq	%rbx, 0x84ce(%rip)      # 0xce4f0 <minimum_budget>
   c6022: 4c 89 f0                     	movq	%r14, %rax
   c6025: 48 c1 e8 0f                  	shrq	$0xf, %rax
   c6029: 48 89 05 68 8c 00 00         	movq	%rax, 0x8c68(%rip)      # 0xcec98 <block_count>
   c6030: 31 ff                        	xorl	%edi, %edi
   c6032: 4c 89 f6                     	movq	%r14, %rsi
   c6035: ba 03 00 00 00               	movl	$0x3, %edx
   c603a: b9 22 00 00 00               	movl	$0x22, %ecx
   c603f: 41 b8 ff ff ff ff            	movl	$0xffffffff, %r8d       # imm = 0xFFFFFFFF
   c6045: 45 31 c9                     	xorl	%r9d, %r9d
   c6048: e8 f3 06 00 00               	callq	0xc6740 <mmap@plt>
   c604d: 48 89 c3                     	movq	%rax, %rbx
   c6050: 48 89 05 49 8c 00 00         	movq	%rax, 0x8c49(%rip)      # 0xceca0 <arena>
   c6057: 48 8b 3d 3a 8c 00 00         	movq	0x8c3a(%rip), %rdi      # 0xcec98 <block_count>
   c605e: be 10 02 00 00               	movl	$0x210, %esi            # imm = 0x210
   c6063: e8 c8 06 00 00               	callq	0xc6730 <calloc@plt>
   c6068: 48 89 05 e9 8b 00 00         	movq	%rax, 0x8be9(%rip)      # 0xcec58 <blocks>
   c606f: 48 83 fb ff                  	cmpq	$-0x1, %rbx
   c6073: 0f 84 25 05 00 00            	je	0xc659e <main+0x6be>
   c6079: 48 85 c0                     	testq	%rax, %rax
   c607c: 0f 84 1c 05 00 00            	je	0xc659e <main+0x6be>
   c6082: 48 8d 3d 9e 28 f4 ff         	leaq	-0xbd762(%rip), %rdi    # 0x8927 <writev+0x8927>
   c6089: e8 72 06 00 00               	callq	0xc6700 <getenv@plt>
   c608e: 48 85 c0                     	testq	%rax, %rax
   c6091: 0f 95 05 b0 8b 00 00         	setne	0x8bb0(%rip)            # 0xcec48 <statistics>
   c6098: 74 0c                        	je	0xc60a6 <main+0x1c6>
   c609a: 48 8d 3d ef fc ff ff         	leaq	-0x311(%rip), %rdi      # 0xc5d90 <report_statistics>
   c60a1: e8 ea d0 f9 ff               	callq	0x63190 <atexit>
   c60a6: 48 8d 3d ca 3b f4 ff         	leaq	-0xbc436(%rip), %rdi    # 0x9c77 <writev+0x9c77>
   c60ad: e8 4e 06 00 00               	callq	0xc6700 <getenv@plt>
   c60b2: 48 85 c0                     	testq	%rax, %rax
   c60b5: 74 16                        	je	0xc60cd <main+0x1ed>
   c60b7: 48 89 c7                     	movq	%rax, %rdi
   c60ba: 31 f6                        	xorl	%esi, %esi
   c60bc: ba 0a 00 00 00               	movl	$0xa, %edx
   c60c1: e8 4a 06 00 00               	callq	0xc6710 <__isoc23_strtoull@plt>
   c60c6: 48 89 05 4b 8b 00 00         	movq	%rax, 0x8b4b(%rip)      # 0xcec18 <collection_interval>
   c60cd: e8 3e 62 fa ff               	callq	0x6c310 <f.111>
   c60d2: 48 83 ec 08                  	subq	$0x8, %rsp
   c60d6: 83 3d b3 86 00 00 02         	cmpl	$0x2, 0x86b3(%rip)      # 0xce790 <g.49>
   c60dd: 0f 85 bb 04 00 00            	jne	0xc659e <main+0x6be>
   c60e3: 80 3d ee 8a 00 00 00         	cmpb	$0x0, 0x8aee(%rip)      # 0xcebd8 <g.197>
   c60ea: 0f 84 ae 04 00 00            	je	0xc659e <main+0x6be>
   c60f0: 48 83 3d d8 8a 00 00 00      	cmpq	$0x0, 0x8ad8(%rip)      # 0xcebd0 <g.196>
   c60f8: 0f 84 a0 04 00 00            	je	0xc659e <main+0x6be>
   c60fe: 48 8b 05 33 87 00 00         	movq	0x8733(%rip), %rax      # 0xce838 <g.71>
   c6105: 48 85 c0                     	testq	%rax, %rax
   c6108: 0f 84 90 04 00 00            	je	0xc659e <main+0x6be>
   c610e: 48 8b 1d e3 8a 00 00         	movq	0x8ae3(%rip), %rbx      # 0xcebf8 <released_resources>
   c6115: 4c 8b 70 08                  	movq	0x8(%rax), %r14
   c6119: 48 8d 75 88                  	leaq	-0x78(%rbp), %rsi
   c611d: bf 01 00 00 00               	movl	$0x1, %edi
   c6122: e8 29 06 00 00               	callq	0xc6750 <clock_gettime@plt>
   c6127: 85 c0                        	testl	%eax, %eax
   c6129: 74 22                        	je	0xc614d <main+0x26d>
   c612b: e8 e0 36 f6 ff               	callq	0x29810 <snail_native_cleanup>
   c6130: b8 03 00 00 00               	movl	$0x3, %eax
   c6135: 64 48 8b 0c 25 28 00 00 00   	movq	%fs:0x28, %rcx
   c613e: 48 3b 4d d8                  	cmpq	-0x28(%rbp), %rcx
   c6142: 0f 84 ae 03 00 00            	je	0xc64f6 <main+0x616>
   c6148: e9 3a 04 00 00               	jmp	0xc6587 <main+0x6a7>
   c614d: 83 3d 3c 86 00 00 02         	cmpl	$0x2, 0x863c(%rip)      # 0xce790 <g.49>
   c6154: 0f 85 44 04 00 00            	jne	0xc659e <main+0x6be>
   c615a: 80 3d 8f 8a 00 00 00         	cmpb	$0x0, 0x8a8f(%rip)      # 0xcebf0 <g.200>
   c6161: 0f 84 37 04 00 00            	je	0xc659e <main+0x6be>
   c6167: 48 83 3d 79 8a 00 00 00      	cmpq	$0x0, 0x8a79(%rip)      # 0xcebe8 <g.199>
   c616f: 0f 84 29 04 00 00            	je	0xc659e <main+0x6be>
   c6175: 48 8b 0d 9c 8a 00 00         	movq	0x8a9c(%rip), %rcx      # 0xcec18 <collection_interval>
   c617c: 48 85 c9                     	testq	%rcx, %rcx
   c617f: 74 30                        	je	0xc61b1 <main+0x2d1>
   c6181: 48 8b 05 98 8a 00 00         	movq	0x8a98(%rip), %rax      # 0xcec20 <allocations>
   c6188: 48 ff c0                     	incq	%rax
   c618b: 48 89 05 8e 8a 00 00         	movq	%rax, 0x8a8e(%rip)      # 0xcec20 <allocations>
   c6192: 48 89 c2                     	movq	%rax, %rdx
   c6195: 48 09 ca                     	orq	%rcx, %rdx
   c6198: 48 c1 ea 20                  	shrq	$0x20, %rdx
   c619c: 0f 84 ea 03 00 00            	je	0xc658c <main+0x6ac>
   c61a2: 31 d2                        	xorl	%edx, %edx
   c61a4: 48 f7 f1                     	divq	%rcx
   c61a7: 48 85 d2                     	testq	%rdx, %rdx
   c61aa: 75 05                        	jne	0xc61b1 <main+0x2d1>
   c61ac: e8 ff d7 ff ff               	callq	0xc39b0 <native_gc_collect>
   c61b1: 48 8b 05 28 83 00 00         	movq	0x8328(%rip), %rax      # 0xce4e0 <heap_bytes>
   c61b8: 48 83 c0 e8                  	addq	$-0x18, %rax
   c61bc: 48 83 f8 18                  	cmpq	$0x18, %rax
   c61c0: 72 70                        	jb	0xc6232 <main+0x352>
   c61c2: 48 8b 05 5f 8a 00 00         	movq	0x8a5f(%rip), %rax      # 0xcec28 <since_collection>
   c61c9: 48 3b 05 18 83 00 00         	cmpq	0x8318(%rip), %rax      # 0xce4e8 <budget>
   c61d0: 72 05                        	jb	0xc61d7 <main+0x2f7>
   c61d2: e8 d9 d7 ff ff               	callq	0xc39b0 <native_gc_collect>
   c61d7: 48 8b 05 ca 8a 00 00         	movq	0x8aca(%rip), %rax      # 0xceca8 <cursor>
   c61de: 48 85 c0                     	testq	%rax, %rax
   c61e1: 74 10                        	je	0xc61f3 <main+0x313>
   c61e3: 48 8b 0d c6 8a 00 00         	movq	0x8ac6(%rip), %rcx      # 0xcecb0 <limit>
   c61ea: 48 29 c1                     	subq	%rax, %rcx
   c61ed: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   c61f1: 77 4b                        	ja	0xc623e <main+0x35e>
   c61f3: bf 20 00 00 00               	movl	$0x20, %edi
   c61f8: e8 c3 f4 ff ff               	callq	0xc56c0 <allocate_slow>
   c61fd: 48 85 c0                     	testq	%rax, %rax
   c6200: 75 47                        	jne	0xc6249 <main+0x369>
   c6202: e8 a9 d7 ff ff               	callq	0xc39b0 <native_gc_collect>
   c6207: 48 8b 05 9a 8a 00 00         	movq	0x8a9a(%rip), %rax      # 0xceca8 <cursor>
   c620e: 48 85 c0                     	testq	%rax, %rax
   c6211: 74 10                        	je	0xc6223 <main+0x343>
   c6213: 48 8b 0d 96 8a 00 00         	movq	0x8a96(%rip), %rcx      # 0xcecb0 <limit>
   c621a: 48 29 c1                     	subq	%rax, %rcx
   c621d: 48 83 f9 1f                  	cmpq	$0x1f, %rcx
   c6221: 77 1b                        	ja	0xc623e <main+0x35e>
   c6223: bf 20 00 00 00               	movl	$0x20, %edi
   c6228: e8 93 f4 ff ff               	callq	0xc56c0 <allocate_slow>
   c622d: 48 85 c0                     	testq	%rax, %rax
   c6230: 75 17                        	jne	0xc6249 <main+0x369>
   c6232: 48 8d 3d e0 35 f4 ff         	leaq	-0xbca20(%rip), %rdi    # 0x9819 <writev+0x9819>
   c6239: e8 a2 d1 ff ff               	callq	0xc33e0 <native_fail>
   c623e: 48 8d 48 20                  	leaq	0x20(%rax), %rcx
   c6242: 48 89 0d 5f 8a 00 00         	movq	%rcx, 0x8a5f(%rip)      # 0xceca8 <cursor>
   c6249: 48 89 c2                     	movq	%rax, %rdx
   c624c: 48 2b 15 4d 8a 00 00         	subq	0x8a4d(%rip), %rdx      # 0xceca0 <arena>
   c6253: 89 d1                        	movl	%edx, %ecx
   c6255: c1 e9 04                     	shrl	$0x4, %ecx
   c6258: be 01 00 00 00               	movl	$0x1, %esi
   c625d: 48 d3 e6                     	shlq	%cl, %rsi
   c6260: 48 89 d1                     	movq	%rdx, %rcx
   c6263: 48 c1 e9 0f                  	shrq	$0xf, %rcx
   c6267: 48 69 c9 10 02 00 00         	imulq	$0x210, %rcx, %rcx      # imm = 0x210
   c626e: 48 03 0d e3 89 00 00         	addq	0x89e3(%rip), %rcx      # 0xcec58 <blocks>
   c6275: c1 ea 07                     	shrl	$0x7, %edx
   c6278: 81 e2 f8 00 00 00            	andl	$0xf8, %edx
   c627e: 48 09 34 0a                  	orq	%rsi, (%rdx,%rcx)
   c6282: 48 c7 00 61 00 00 00         	movq	$0x61, (%rax)
   c6289: 48 c7 40 14 00 00 00 00      	movq	$0x0, 0x14(%rax)
   c6291: c7 40 1c 00 00 00 00         	movl	$0x0, 0x1c(%rax)
   c6298: 48 83 05 88 89 00 00 20      	addq	$0x20, 0x8988(%rip)     # 0xcec28 <since_collection>
   c62a0: 48 83 05 88 89 00 00 18      	addq	$0x18, 0x8988(%rip)     # 0xcec30 <allocated_bytes>
   c62a8: 48 ff 05 89 89 00 00         	incq	0x8989(%rip)            # 0xcec38 <allocated_objects>
   c62af: 48 8d 78 08                  	leaq	0x8(%rax), %rdi
   c62b3: 48 c7 40 08 4a 01 00 00      	movq	$0x14a, 0x8(%rax)       # imm = 0x14A
   c62bb: c7 40 10 01 00 00 00         	movl	$0x1, 0x10(%rax)
   c62c2: 45 31 ff                     	xorl	%r15d, %r15d
   c62c5: 4d 85 f6                     	testq	%r14, %r14
   c62c8: 4d 0f 4f fe                  	cmovgq	%r14, %r15
   c62cc: 4c 8d 65 98                  	leaq	-0x68(%rbp), %r12
   c62d0: 48 c7 45 a0 05 00 00 00      	movq	$0x5, -0x60(%rbp)
   c62d8: 48 c7 45 a8 00 00 00 00      	movq	$0x0, -0x58(%rbp)
   c62e0: 48 8b 05 f1 89 00 00         	movq	0x89f1(%rip), %rax      # 0xcecd8 <native_roots>
   c62e7: 48 89 45 98                  	movq	%rax, -0x68(%rbp)
   c62eb: 4c 89 25 e6 89 00 00         	movq	%r12, 0x89e6(%rip)      # 0xcecd8 <native_roots>
   c62f2: 48 8b 05 0f 89 00 00         	movq	0x890f(%rip), %rax      # 0xcec08 <root_depth>
   c62f9: 48 ff c0                     	incq	%rax
   c62fc: 48 89 05 05 89 00 00         	movq	%rax, 0x8905(%rip)      # 0xcec08 <root_depth>
   c6303: 48 3b 05 06 89 00 00         	cmpq	0x8906(%rip), %rax      # 0xcec10 <peak_root_depth>
   c630a: 76 07                        	jbe	0xc6313 <main+0x433>
   c630c: 48 89 05 fd 88 00 00         	movq	%rax, 0x88fd(%rip)      # 0xcec10 <peak_root_depth>
   c6313: 48 89 7d b0                  	movq	%rdi, -0x50(%rbp)
   c6317: 48 c7 45 b8 00 00 00 00      	movq	$0x0, -0x48(%rbp)
   c631f: 49 83 ef 01                  	subq	$0x1, %r15
   c6323: 0f 82 45 01 00 00            	jb	0xc646e <main+0x58e>
   c6329: 48 83 3d af 88 00 00 00      	cmpq	$0x0, 0x88af(%rip)      # 0xcebe0 <g.198>
   c6331: 0f 84 67 02 00 00            	je	0xc659e <main+0x6be>
   c6337: 4c 8b 35 82 88 00 00         	movq	0x8882(%rip), %r14      # 0xcebc0 <g.194>
   c633e: 4d 85 f6                     	testq	%r14, %r14
   c6341: 0f 84 57 02 00 00            	je	0xc659e <main+0x6be>
   c6347: 4c 89 75 c0                  	movq	%r14, -0x40(%rbp)
   c634b: 48 c7 45 a8 03 00 00 00      	movq	$0x3, -0x58(%rbp)
   c6353: e8 48 42 f5 ff               	callq	0x1a5a0 <barrier>
   c6358: 85 c0                        	testl	%eax, %eax
   c635a: 0f 84 3e 02 00 00            	je	0xc659e <main+0x6be>
   c6360: 48 83 3d 40 88 00 00 00      	cmpq	$0x0, 0x8840(%rip)      # 0xceba8 <g.191>
   c6368: 0f 84 30 02 00 00            	je	0xc659e <main+0x6be>
   c636e: 48 8b 35 53 84 00 00         	movq	0x8453(%rip), %rsi      # 0xce7c8 <g.57>
   c6375: 48 85 f6                     	testq	%rsi, %rsi
   c6378: 0f 84 20 02 00 00            	je	0xc659e <main+0x6be>
   c637e: 48 89 75 b0                  	movq	%rsi, -0x50(%rbp)
   c6382: 80 3d c7 85 00 00 00         	cmpb	$0x0, 0x85c7(%rip)      # 0xce950 <g.107>
   c6389: 0f 84 0f 02 00 00            	je	0xc659e <main+0x6be>
   c638f: 48 83 3d b1 85 00 00 00      	cmpq	$0x0, 0x85b1(%rip)      # 0xce948 <g.106>
   c6397: 0f 84 01 02 00 00            	je	0xc659e <main+0x6be>
   c639d: 4c 89 75 c0                  	movq	%r14, -0x40(%rbp)
   c63a1: 48 89 75 c8                  	movq	%rsi, -0x38(%rbp)
   c63a5: 48 c7 45 a8 04 00 00 00      	movq	$0x4, -0x58(%rbp)
   c63ad: 4c 89 f7                     	movq	%r14, %rdi
   c63b0: e8 fb cd f9 ff               	callq	0x631b0 <f.105>
   c63b5: 48 83 ec 08                  	subq	$0x8, %rsp
   c63b9: 4c 8b 35 70 85 00 00         	movq	0x8570(%rip), %r14      # 0xce930 <g.103>
   c63c0: 4d 85 f6                     	testq	%r14, %r14
   c63c3: 0f 84 d5 01 00 00            	je	0xc659e <main+0x6be>
   c63c9: 48 83 3d af 83 00 00 00      	cmpq	$0x0, 0x83af(%rip)      # 0xce780 <g.47>
   c63d1: 0f 84 c7 01 00 00            	je	0xc659e <main+0x6be>
   c63d7: 48 8b 3d 4a 85 00 00         	movq	0x854a(%rip), %rdi      # 0xce928 <g.102>
   c63de: 48 85 ff                     	testq	%rdi, %rdi
   c63e1: 0f 84 b7 01 00 00            	je	0xc659e <main+0x6be>
   c63e7: 48 8b 35 da 83 00 00         	movq	0x83da(%rip), %rsi      # 0xce7c8 <g.57>
   c63ee: 48 85 f6                     	testq	%rsi, %rsi
   c63f1: 0f 84 a7 01 00 00            	je	0xc659e <main+0x6be>
   c63f7: 4c 89 75 c0                  	movq	%r14, -0x40(%rbp)
   c63fb: 48 89 7d c8                  	movq	%rdi, -0x38(%rbp)
   c63ff: 48 89 75 d0                  	movq	%rsi, -0x30(%rbp)
   c6403: 48 c7 45 a8 05 00 00 00      	movq	$0x5, -0x58(%rbp)
   c640b: e8 90 d8 f9 ff               	callq	0x63ca0 <f.54>
   c6410: 48 83 ec 08                  	subq	$0x8, %rsp
   c6414: 48 89 45 b8                  	movq	%rax, -0x48(%rbp)
   c6418: 48 83 3d 60 83 00 00 00      	cmpq	$0x0, 0x8360(%rip)      # 0xce780 <g.47>
   c6420: 0f 84 78 01 00 00            	je	0xc659e <main+0x6be>
   c6426: 4c 89 75 c0                  	movq	%r14, -0x40(%rbp)
   c642a: 48 89 45 c8                  	movq	%rax, -0x38(%rbp)
   c642e: 48 c7 45 a8 04 00 00 00      	movq	$0x4, -0x58(%rbp)
   c6436: 4c 89 f7                     	movq	%r14, %rdi
   c6439: 48 89 c6                     	movq	%rax, %rsi
   c643c: e8 5f d8 f9 ff               	callq	0x63ca0 <f.54>
   c6441: 48 83 ec 08                  	subq	$0x8, %rsp
   c6445: 48 89 c7                     	movq	%rax, %rdi
   c6448: 48 89 45 b0                  	movq	%rax, -0x50(%rbp)
   c644c: 48 83 7d a0 00               	cmpq	$0x0, -0x60(%rbp)
   c6451: 0f 84 79 fe ff ff            	je	0xc62d0 <main+0x3f0>
   c6457: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   c645b: 48 89 05 76 88 00 00         	movq	%rax, 0x8876(%rip)      # 0xcecd8 <native_roots>
   c6462: 48 ff 0d 9f 87 00 00         	decq	0x879f(%rip)            # 0xcec08 <root_depth>
   c6469: e9 62 fe ff ff               	jmp	0xc62d0 <main+0x3f0>
   c646e: 48 83 3d 2a 83 00 00 00      	cmpq	$0x0, 0x832a(%rip)      # 0xce7a0 <g.52>
   c6476: 0f 84 22 01 00 00            	je	0xc659e <main+0x6be>
   c647c: 48 8b 35 45 87 00 00         	movq	0x8745(%rip), %rsi      # 0xcebc8 <g.195>
   c6483: 48 85 f6                     	testq	%rsi, %rsi
   c6486: 0f 84 12 01 00 00            	je	0xc659e <main+0x6be>
   c648c: 48 89 7d c0                  	movq	%rdi, -0x40(%rbp)
   c6490: 48 89 75 c8                  	movq	%rsi, -0x38(%rbp)
   c6494: 48 c7 45 a8 04 00 00 00      	movq	$0x4, -0x58(%rbp)
   c649c: e8 4f de f9 ff               	callq	0x642f0 <f.55>
   c64a1: 48 83 ec 08                  	subq	$0x8, %rsp
   c64a5: 45 31 f6                     	xorl	%r14d, %r14d
   c64a8: 85 c0                        	testl	%eax, %eax
   c64aa: 41 0f 95 c7                  	setne	%r15b
   c64ae: 48 83 7d a0 00               	cmpq	$0x0, -0x60(%rbp)
   c64b3: 74 12                        	je	0xc64c7 <main+0x5e7>
   c64b5: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   c64b9: 48 89 05 18 88 00 00         	movq	%rax, 0x8818(%rip)      # 0xcecd8 <native_roots>
   c64c0: 48 ff 0d 41 87 00 00         	decq	0x8741(%rip)            # 0xcec08 <root_depth>
   c64c7: 48 8d 75 98                  	leaq	-0x68(%rbp), %rsi
   c64cb: bf 01 00 00 00               	movl	$0x1, %edi
   c64d0: e8 7b 02 00 00               	callq	0xc6750 <clock_gettime@plt>
   c64d5: 85 c0                        	testl	%eax, %eax
   c64d7: 74 2a                        	je	0xc6503 <main+0x623>
   c64d9: e8 32 33 f6 ff               	callq	0x29810 <snail_native_cleanup>
   c64de: b8 04 00 00 00               	movl	$0x4, %eax
   c64e3: 64 48 8b 0c 25 28 00 00 00   	movq	%fs:0x28, %rcx
   c64ec: 48 3b 4d d8                  	cmpq	-0x28(%rbp), %rcx
   c64f0: 0f 85 91 00 00 00            	jne	0xc6587 <main+0x6a7>
   c64f6: 48 83 c4 70                  	addq	$0x70, %rsp
   c64fa: 5b                           	popq	%rbx
   c64fb: 41 5c                        	popq	%r12
   c64fd: 41 5e                        	popq	%r14
   c64ff: 41 5f                        	popq	%r15
   c6501: 5d                           	popq	%rbp
   c6502: c3                           	retq
   c6503: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   c6507: 48 2b 45 88                  	subq	-0x78(%rbp), %rax
   c650b: f2 48 0f 2a c0               	cvtsi2sd	%rax, %xmm0
   c6510: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   c6514: 48 2b 45 90                  	subq	-0x70(%rbp), %rax
   c6518: f2 48 0f 2a c8               	cvtsi2sd	%rax, %xmm1
   c651d: f2 0f 59 0d eb 00 f4 ff      	mulsd	-0xbff15(%rip), %xmm1   # 0x6610 <writev+0x6610>
   c6525: 45 88 fe                     	movb	%r15b, %r14b
   c6528: f2 0f 58 c8                  	addsd	%xmm0, %xmm1
   c652c: f2 0f 11 4d 80               	movsd	%xmm1, -0x80(%rbp)
   c6531: 4c 8b 3d c0 86 00 00         	movq	0x86c0(%rip), %r15      # 0xcebf8 <released_resources>
   c6538: 49 29 df                     	subq	%rbx, %r15
   c653b: e8 d0 32 f6 ff               	callq	0x29810 <snail_native_cleanup>
   c6540: 45 31 e4                     	xorl	%r12d, %r12d
   c6543: 85 c0                        	testl	%eax, %eax
   c6545: 41 0f 95 c4                  	setne	%r12b
   c6549: e8 62 40 f5 ff               	callq	0x1a5b0 <reader_barriers>
   c654e: 48 8b 0d a3 86 00 00         	movq	0x86a3(%rip), %rcx      # 0xcebf8 <released_resources>
   c6555: 48 89 0c 24                  	movq	%rcx, (%rsp)
   c6559: f2 0f 10 45 80               	movsd	-0x80(%rbp), %xmm0
   c655e: 4c 89 f2                     	movq	%r14, %rdx
   c6561: 48 89 c1                     	movq	%rax, %rcx
   c6564: 49 89 d8                     	movq	%rbx, %r8
   c6567: 4d 89 f9                     	movq	%r15, %r9
   c656a: b0 01                        	movb	$0x1, %al
   c656c: e8 3f 00 00 00               	callq	0xc65b0 <_ZL6printfPKcU17pass_object_size1z>
   c6571: 44 89 e0                     	movl	%r12d, %eax
   c6574: 64 48 8b 0c 25 28 00 00 00   	movq	%fs:0x28, %rcx
   c657d: 48 3b 4d d8                  	cmpq	-0x28(%rbp), %rcx
   c6581: 0f 84 6f ff ff ff            	je	0xc64f6 <main+0x616>
   c6587: e8 44 02 00 00               	callq	0xc67d0 <__stack_chk_fail@plt>
   c658c: 31 d2                        	xorl	%edx, %edx
   c658e: f7 f1                        	divl	%ecx
   c6590: 48 85 d2                     	testq	%rdx, %rdx
   c6593: 0f 85 18 fc ff ff            	jne	0xc61b1 <main+0x2d1>
   c6599: e9 0e fc ff ff               	jmp	0xc61ac <main+0x2cc>
   c659e: e8 2d cf ff ff               	callq	0xc34d0 <native_trap>
   c65a3: cc                           	int3
   c65a4: cc                           	int3
   c65a5: cc                           	int3
   c65a6: cc                           	int3
   c65a7: cc                           	int3
   c65a8: cc                           	int3
   c65a9: cc                           	int3
   c65aa: cc                           	int3
   c65ab: cc                           	int3
   c65ac: cc                           	int3
   c65ad: cc                           	int3
   c65ae: cc                           	int3
   c65af: cc                           	int3

