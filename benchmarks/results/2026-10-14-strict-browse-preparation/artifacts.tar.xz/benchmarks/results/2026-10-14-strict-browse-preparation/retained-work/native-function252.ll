define internal tailcc i64 @f.108(i64 %arg0, i32 %arg1, i32 %arg2, i64 %arg3, i64 %arg4) {
entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i32, align 8
  %slot3 = alloca i32, align 8
  %slot4 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot26 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %roots = alloca { ptr, i64, i64, [5 x i64] }, align 8
  call void @native_roots_enter(ptr %roots, i64 5)
  store i64 %arg0, ptr %slot1, align 1
  store i32 %arg1, ptr %slot2, align 1
  store i32 %arg2, ptr %slot3, align 1
  store i64 %arg3, ptr %slot4, align 1
  %v5 = getelementptr i64, ptr %roots, i64 3
  store i64 %arg4, ptr %v5, align 1
  %v6 = getelementptr i64, ptr %roots, i64 4
  store i64 0, ptr %v6, align 1
  %v9 = load i64, ptr %slot1, align 1
  %v10 = load i64, ptr %slot4, align 1
  %v11 = icmp sgt i64 %v9, %v10
  %v12 = zext i1 %v11 to i32
  %v17 = icmp ne i32 %v12, 0
  br i1 %v17, label %then16, label %else15
then16:
  %v18 = load i64, ptr @g.198, align 1
  %v19 = icmp ne i64 %v18, 0
  br i1 %v19, label %ok21, label %trap20
trap20:
  call void @native_trap()
  unreachable
ok21:
  %v22 = load i64, ptr @g.194, align 1
  %v23 = icmp ne i64 %v22, 0
  br i1 %v23, label %ok25, label %trap24
trap24:
  call void @native_trap()
  unreachable
ok25:
  %v28 = getelementptr i64, ptr %roots, i64 5
  store i64 %v22, ptr %v28, align 1
  %v29 = getelementptr i64, ptr %roots, i64 2
  store i64 3, ptr %v29, align 1
  %v30 = call tailcc i32 @f.22()
  %v31 = icmp eq i32 %v30, 0
  %v32 = zext i1 %v31 to i32
  %v36 = icmp ne i32 %v32, 0
  br i1 %v36, label %then35, label %else34
then35:
  call void @native_trap()
  unreachable
else34:
  br label %block33
block33:
  %v37 = load i64, ptr @g.191, align 1
  %v38 = icmp ne i64 %v37, 0
  br i1 %v38, label %ok40, label %trap39
trap39:
  call void @native_trap()
  unreachable
ok40:
  %v41 = load i64, ptr @g.57, align 1
  %v42 = icmp ne i64 %v41, 0
  br i1 %v42, label %ok44, label %trap43
trap43:
  call void @native_trap()
  unreachable
ok44:
  store i64 %v41, ptr %v5, align 1
  %v45 = load i32, ptr @g.107, align 1
  %v46 = icmp eq i32 %v45, 0
  %v47 = zext i1 %v46 to i32
  %v51 = icmp ne i32 %v47, 0
  br i1 %v51, label %then50, label %else49
then50:
  call void @native_trap()
  unreachable
else49:
  br label %block48
block48:
  %v52 = load i64, ptr @g.106, align 1
  %v53 = icmp ne i64 %v52, 0
  br i1 %v53, label %ok55, label %trap54
trap54:
  call void @native_trap()
  unreachable
ok55:
  store i32 0, ptr %slot26, align 1
  br label %block27
block27:
  %v56 = load i32, ptr %slot26, align 1
  %v57 = load i64, ptr %v5, align 1
  %v58 = getelementptr i64, ptr %roots, i64 5
  store i64 %v22, ptr %v58, align 1
  %v59 = getelementptr i64, ptr %roots, i64 6
  store i64 %v57, ptr %v59, align 1
  %v60 = getelementptr i64, ptr %roots, i64 2
  store i64 4, ptr %v60, align 1
  %v61 = call tailcc i32 @f.105(i64 %v22, i32 %v56, i32 1, i64 %v57)
  %v62 = load i64, ptr @g.103, align 1
  %v63 = icmp ne i64 %v62, 0
  br i1 %v63, label %ok65, label %trap64
trap64:
  call void @native_trap()
  unreachable
ok65:
  %v68 = load i64, ptr @g.47, align 1
  %v69 = icmp ne i64 %v68, 0
  br i1 %v69, label %ok71, label %trap70
trap70:
  call void @native_trap()
  unreachable
ok71:
  %v72 = load i64, ptr @g.102, align 1
  %v73 = icmp ne i64 %v72, 0
  br i1 %v73, label %ok75, label %trap74
trap74:
  call void @native_trap()
  unreachable
ok75:
  %v76 = load i64, ptr @g.57, align 1
  %v77 = icmp ne i64 %v76, 0
  br i1 %v77, label %ok79, label %trap78
trap78:
  call void @native_trap()
  unreachable
ok79:
  %v80 = getelementptr i64, ptr %roots, i64 5
  store i64 %v62, ptr %v80, align 1
  %v81 = getelementptr i64, ptr %roots, i64 6
  store i64 %v72, ptr %v81, align 1
  %v82 = getelementptr i64, ptr %roots, i64 7
  store i64 %v76, ptr %v82, align 1
  %v83 = getelementptr i64, ptr %roots, i64 2
  store i64 5, ptr %v83, align 1
  %v84 = call tailcc i64 @f.54(i64 %v72, i64 %v76)
  store i64 %v84, ptr %v6, align 1
  %v85 = load i64, ptr @g.47, align 1
  %v86 = icmp ne i64 %v85, 0
  br i1 %v86, label %ok88, label %trap87
trap87:
  call void @native_trap()
  unreachable
ok88:
  %v89 = load i64, ptr %v6, align 1
  store i64 %v89, ptr %slot66, align 1
  br label %block67
block67:
  %v90 = load i64, ptr %slot66, align 1
  %v91 = getelementptr i64, ptr %roots, i64 5
  store i64 %v62, ptr %v91, align 1
  %v92 = getelementptr i64, ptr %roots, i64 6
  store i64 %v90, ptr %v92, align 1
  %v93 = getelementptr i64, ptr %roots, i64 2
  store i64 4, ptr %v93, align 1
  %v94 = call tailcc i64 @f.54(i64 %v62, i64 %v90)
  store i64 %v94, ptr %v5, align 1
  %v95 = load i32, ptr %slot3, align 1
  %v96 = icmp eq i32 %v95, 0
  %v97 = zext i1 %v96 to i32
  %v101 = icmp ne i32 %v97, 0
  br i1 %v101, label %then100, label %else99
then100:
  call void @native_trap()
  unreachable
else99:
  br label %block98
block98:
  %v102 = load i64, ptr %slot1, align 1
  %v103 = load i32, ptr %slot2, align 1
  %v104 = load i32, ptr %slot3, align 1
  %v105 = load i64, ptr %slot4, align 1
  %v106 = add i64 %v105, 1
  %v107 = load i64, ptr %v5, align 1
  call void @native_roots_leave(ptr %roots)
  %v108 = tail call tailcc i64 @f.108(i64 %v102, i32 %v103, i32 %v104, i64 %v106, i64 %v107)
  ret i64 %v108
else15:
  %v109 = load i64, ptr @g.52, align 1
  %v110 = icmp ne i64 %v109, 0
  br i1 %v110, label %ok112, label %trap111
trap111:
  call void @native_trap()
  unreachable
ok112:
  %v113 = load i64, ptr %v5, align 1
  %v114 = load i64, ptr @g.195, align 1
  %v115 = icmp ne i64 %v114, 0
  br i1 %v115, label %ok117, label %trap116
trap116:
  call void @native_trap()
  unreachable
ok117:
  %v118 = getelementptr i64, ptr %roots, i64 5
  store i64 %v113, ptr %v118, align 1
  %v119 = getelementptr i64, ptr %roots, i64 6
  store i64 %v114, ptr %v119, align 1
  %v120 = getelementptr i64, ptr %roots, i64 2
  store i64 4, ptr %v120, align 1
  %v121 = call tailcc i32 @f.55(i64 %v113, i64 %v114)
  %v122 = icmp ne i32 %v121, 0
  %v123 = zext i1 %v122 to i32
  %v124 = zext i32 %v123 to i64
  store i64 %v124, ptr %slot13, align 1
  br label %block14
block14:
  %v125 = load i64, ptr %slot13, align 1
  store i64 %v125, ptr %slot7, align 1
  br label %return8
return8:
  %v126 = load i64, ptr %slot7, align 1
  call void @native_roots_leave(ptr %roots)
  ret i64 %v126
}
