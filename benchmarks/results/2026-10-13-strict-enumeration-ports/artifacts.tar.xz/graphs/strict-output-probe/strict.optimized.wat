(module
 (rec
  (type $type53 (struct))
  (type $call101 (func (param (ref $environment99) (ref null $type25) i64) (result i64)))
  (type $call59 (func (param (ref null $environment97) (ref null $type25)) (result (ref null $type13))))
  (type $type101 (struct (field (ref $environment99))))
  (type $type102 (struct (field (mut i32)) (field (mut (ref null $type101)))))
  (type $type100 (struct (field (mut i32)) (field (mut (ref null $type59)))))
  (type $environment99 (struct (field (ref $type102))))
  (type $environment97 (struct (field (ref $type100))))
  (type $8 (func (param (ref null $type25)) (result (ref $type13))))
  (type $environment95 (struct (field (ref $type14)) (field (ref $type61))))
  (type $call58 (func (param (ref $type14) (ref null $type13)) (result (ref null $type13))))
  (type $call96 (func (param (ref $environment88) (ref null $type13) i64) (result i64)))
  (type $type96 (struct (field (ref $environment88))))
  (type $type97 (struct (field (mut i32)) (field (mut (ref null $type96)))))
  (type $environment88 (struct (field (ref $type97))))
  (type $type88 (struct (field (ref $environment76))))
  (type $type89 (struct (field (mut i32)) (field (mut (ref null $type88)))))
  (type $call90 (func (param (ref $environment85) i64 i64 (ref null $type25)) (result (ref null $type25))))
  (type $call94 (func (param (ref $environment81) (ref null $type16)) (result i32)))
  (type $type94 (struct (field (ref $environment81))))
  (type $type41 (struct (field (ref $environment79))))
  (type $environment79 (struct (field i64)))
  (type $type95 (struct (field (mut i32)) (field (mut (ref null $type94)))))
  (type $environment81 (struct (field (ref $type41)) (field (ref $type95))))
  (type $environment84 (struct (field (ref $type62))))
  (type $type87 (struct (field i32) (field (ref $type8))))
  (type $environment83 (struct (field i64) (field (ref $type28)) (field (ref $type85))))
  (type $environment78 (struct (field (ref null $type16))))
  (type $type16 (struct (field (ref $type17)) (field (ref null $type16))))
  (type $type8 (struct (field (ref $call8)) (field (ref $environment74))))
  (type $call92 (func (param (ref $environment77) i64 i64 (ref null $type13) (ref null $type16) (ref null $type25)) (result (ref null $type25))))
  (type $type25 (struct (field (ref $type14)) (field (ref null $type25))))
  (type $type90 (struct (field (ref $environment85))))
  (type $environment85 (struct (field i64) (field (ref $type63)) (field (ref $type89)) (field (ref $type91)) (field (ref $type79)) (field i64) (field (ref $type62)) (field (ref $type69))))
  (type $type92 (struct (field (ref $environment77))))
  (type $environment77 (struct (field (ref $type75)) (field i64) (field (ref $type69)) (field (ref $type93)) (field (ref $type79)) (field (ref $type87)) (field (ref $type62)) (field i64)))
  (type $type85 (struct (field (mut i32)) (field (mut (ref null $type28)))))
  (type $environment76 (struct (field (ref $type85)) (field (ref $type75)) (field (ref $type62)) (field (ref $type79)) (field i64) (field (ref $type87)) (field (ref $type53)) (field i64) (field (ref $type63)) (field (ref $type89))))
  (type $type91 (struct (field (mut i32)) (field (mut (ref null $type90)))))
  (type $type93 (struct (field (mut i32)) (field (mut (ref null $type92)))))
  (type $call88 (func (param (ref $environment76) i64 (ref null $type25)) (result (ref null $type25))))
  (type $environment75 (struct (field (ref $type79)) (field (ref $type75))))
  (type $environment74 (struct (field (ref $type84)) (field (ref $type75)) (field (ref $type79)) (field (ref $type86))))
  (type $call8 (func (param (ref $environment74)) (result i32)))
  (type $type48 (struct (field (ref $environment40))))
  (type $type84 (struct (field i32) (field (ref $type48))))
  (type $type86 (struct (field i32) (field (ref $type49))))
  (type $environment72 (struct (field (ref $type84)) (field (ref $type79)) (field (ref $type86))))
  (type $environment71 (struct (field i64)))
  (type $environment66 (struct (field (ref $type69)) (field (ref $type69))))
  (type $environment68 (struct (field i64) (field (ref $type31)) (field (ref $type64))))
  (type $environment65 (struct (field (ref $type79)) (field i64) (field i64) (field (ref $type69))))
  (type $environment64 (struct (field (ref $type79)) (field i64)))
  (type $environment63 (struct (field i64) (field (ref $type79)) (field (ref $type37)) (field (ref $type64))))
  (type $type37 (struct (field (ref $call37)) (field (ref struct))))
  (type $type79 (struct (field i32) (field (ref $type18))))
  (type $56 (func (param i64 (ref $type37)) (result (ref $type18))))
  (type $call30 (func (param (ref $type31) (ref null $type13)) (result i32)))
  (type $environment55 (struct (field (ref $type69))))
  (type $environment54 (struct (field i64) (field (ref $type14))))
  (type $call37 (func (param (ref struct) i64) (result (ref $type17))))
  (type $call56 (func (param (ref null $environment52) (ref null $type13) (ref null $type13)) (result (ref null $type13))))
  (type $environment52 (struct (field (ref $type78)) (field (ref $type33))))
  (type $type78 (struct (field (mut i32)) (field (mut (ref null $type56)))))
  (type $call44 (func (param (ref $environment50) i64 i32) (result i32)))
  (type $environment50 (struct (field (ref $type72)) (field (ref null $type13)) (field (ref $type76)) (field (ref $type77))))
  (type $environment49 (struct (field (ref $type74)) (field (ref $type76)) (field (ref $type75)) (field (ref null $type13))))
  (type $type77 (struct (field (mut i32)) (field (ref $type45))))
  (type $type75 (struct (field (mut i32)) (field i64)))
  (type $type76 (struct (field (mut i32)) (field (ref null $type13))))
  (type $call73 (func (param (ref $environment48) (ref null $type13) (ref null $type13) i32) (result i32)))
  (type $type73 (struct (field (ref $environment48))))
  (type $environment48 (struct (field (ref $type45)) (field (ref $type74)) (field (ref $type43)) (field i64) (field (ref $type72))))
  (type $call49 (func (param (ref null $environment75) (ref $type50) (ref $type45)) (result i32)))
  (type $type49 (struct (field (ref $call49)) (field (ref null $environment75))))
  (type $type74 (struct (field (mut i32)) (field (mut (ref null $type73)))))
  (type $call71 (func (param (ref $environment47) (ref null $type13) i64 i32 (ref $type45)) (result i32)))
  (type $type17 (array (mut i32)))
  (type $call60 (func (param (ref null $environment43) i64) (result i64)))
  (type $environment43 (struct (field i64) (field (ref $type69)) (field (ref $type50)) (field (ref $type69)) (field (ref $type18)) (field i64) (field (ref $type70))))
  (type $type18 (array (mut (ref $type17))))
  (type $type69 (struct (field (mut i32)) (field (mut (ref null $type17)))))
  (type $type70 (struct (field (mut i32)) (field (mut (ref null $type60)))))
  (type $call51 (func (param (ref $type18) (ref $type50) i64 i64) (result i64)))
  (type $call45 (func (param (ref null $environment49) i32) (result i32)))
  (type $type44 (struct (field (ref $environment50))))
  (type $type50 (array (mut i64)))
  (type $call43 (func (param (ref $environment41) i64 i64 i32 (ref $type44) (ref $type45)) (result i32)))
  (type $type45 (struct (field (ref $call45)) (field (ref null $environment49))))
  (type $type71 (struct (field (ref $environment47))))
  (type $environment47 (struct (field (ref $type46)) (field (ref $type43)) (field (ref $type72))))
  (type $type46 (struct (field (ref $environment44))))
  (type $environment44 (struct (field (ref $type49)) (field (ref $type63))))
  (type $environment40 (struct (field (ref $type62)) (field (ref $type63))))
  (type $environment41 (struct (field (ref $type18)) (field (ref $type63))))
  (type $type43 (struct (field (ref $environment41))))
  (type $type63 (struct (field i32) (field (ref $type50))))
  (type $type72 (struct (field (mut i32)) (field (mut (ref null $type71)))))
  (type $call48 (func (param (ref $environment40) i64 (ref $type18) (ref $type49)) (result i32)))
  (type $call31 (func (param (ref struct) i64) (result i32)))
  (type $environment39 (struct (field i64) (field (ref $type62)) (field (ref $type35)) (field (ref $type64))))
  (type $type14 (array (mut (ref null $type13))))
  (type $type31 (struct (field (ref $call31)) (field (ref struct))))
  (type $type62 (struct (field i32) (field (ref $type14))))
  (type $type64 (struct (field (mut i32)) (field (mut (ref null $type31)))))
  (type $105 (func (param i64 (ref $type35)) (result (ref $type14))))
  (type $call28 (func (param structref i64) (result i32)))
  (type $environment31 (struct (field (ref $type61))))
  (type $call35 (func (param (ref null $environment84) i64) (result (ref null $type13))))
  (type $call27 (func (param (ref null $type13) (ref null $type13)) (result i32)))
  (type $type13 (struct (field i64) (field (ref null $type13))))
  (type $type33 (struct (field (ref $call33)) (field structref)))
  (type $type61 (struct (field (mut i32)) (field (mut (ref null $type33)))))
  (type $environment26 (struct (field (ref $type61))))
  (type $call33 (func (param structref i64 (ref null $type13)) (result (ref null $type13))))
  (type $type60 (struct (field (ref $call60)) (field (ref null $environment43))))
  (type $type59 (struct (field (ref null $environment97))))
  (type $type58 (struct))
  (type $type56 (struct (field (ref $call56)) (field (ref null $environment52))))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type52 (struct))
  (type $type51 (struct))
  (type $type47 (struct))
  (type $type42 (struct))
  (type $type40 (struct))
  (type $type39 (struct))
  (type $type38 (struct))
  (type $type35 (struct (field (ref $call35)) (field (ref null $environment84))))
  (type $type36 (struct))
  (type $type34 (struct))
  (type $type32 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type28 (struct (field (ref $call28)) (field structref)))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type24 (struct))
  (type $type23 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type15 (struct))
  (type $type11 (struct))
 )
 (type $143 (func (param i64) (result i64)))
 (type $144 (func (result i64)))
 (type $145 (func (param i32) (result i64)))
 (type $146 (func))
 (import "benchmark" "expected_length" (func $foreign0 (result i64)))
 (import "benchmark" "expected_i64" (func $foreign1 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign2 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global85 (mut (ref null $type11)) (ref.null none))
 (global $ready85 (mut i32) (i32.const 0))
 (global $global169 (mut (ref null $type15)) (ref.null none))
 (global $ready169 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type19)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global171 (mut (ref null $type20)) (ref.null none))
 (global $ready171 (mut i32) (i32.const 0))
 (global $global265 (mut (ref null $type23)) (ref.null none))
 (global $ready265 (mut i32) (i32.const 0))
 (global $global293 (mut (ref null $type24)) (ref.null none))
 (global $ready293 (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type26)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global65 (mut (ref null $type27)) (ref.null none))
 (global $ready65 (mut i32) (i32.const 0))
 (global $global79 (mut (ref null $type28)) (ref.null none))
 (global $ready79 (mut i32) (i32.const 0))
 (global $global68 (mut (ref null $type29)) (ref.null none))
 (global $ready68 (mut i32) (i32.const 0))
 (global $global163 (mut (ref null $type30)) (ref.null none))
 (global $ready163 (mut i32) (i32.const 0))
 (global $global149 (mut (ref null $type32)) (ref.null none))
 (global $ready149 (mut i32) (i32.const 0))
 (global $global82 (mut (ref null $type34)) (ref.null none))
 (global $ready82 (mut i32) (i32.const 0))
 (global $global166 (mut (ref null $type36)) (ref.null none))
 (global $ready166 (mut i32) (i32.const 0))
 (global $global74 (mut (ref null $type35)) (ref.null none))
 (global $ready74 (mut i32) (i32.const 0))
 (global $global190 (mut (ref null $type38)) (ref.null none))
 (global $ready190 (mut i32) (i32.const 0))
 (global $global242 (mut (ref null $type39)) (ref.null none))
 (global $ready242 (mut i32) (i32.const 0))
 (global $global236 (mut (ref null $type40)) (ref.null none))
 (global $ready236 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type42)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global71 (mut (ref null $type47)) (ref.null none))
 (global $ready71 (mut i32) (i32.const 0))
 (global $global112 (mut (ref null $type51)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (global $global197 (mut (ref null $type52)) (ref.null none))
 (global $ready197 (mut i32) (i32.const 0))
 (global $global156 (mut (ref null $type54)) (ref.null none))
 (global $ready156 (mut i32) (i32.const 0))
 (global $global195 (mut (ref null $type55)) (ref.null none))
 (global $ready195 (mut i32) (i32.const 0))
 (global $global270 (mut (ref null $type56)) (ref.null none))
 (global $ready270 (mut i32) (i32.const 0))
 (global $global262 (mut (ref null $type56)) (ref.null none))
 (global $ready262 (mut i32) (i32.const 0))
 (global $global283 (mut (ref null $type58)) (ref.null none))
 (global $ready283 (mut i32) (i32.const 0))
 (global $global289 (mut (ref null $type59)) (ref.null none))
 (global $ready289 (mut i32) (i32.const 0))
 (global $global298 (mut i64) (i64.const 0))
 (global $ready298 (mut i32) (i32.const 0))
 (global $global301 (mut (ref null $type60)) (ref.null none))
 (global $ready301 (mut i32) (i32.const 0))
 (export "enumeration-probe" (func $export0))
 (export "main" (func $main))
 (func $function26 (type $call33) (param $0 structref) (param $1 i64) (param $2 (ref null $type13)) (result (ref null $type13))
  (local $3 i64)
  (if (result (ref null $type13))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (call $foreign1
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment26 0
        (ref.cast (ref $environment26)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function26
     (struct.get $type33 1
      (struct.get $type61 1
       (struct.get $environment26 0
        (ref.cast (ref $environment26)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type13
      (local.get $3)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function27 (type $call27) (param $0 (ref null $type13)) (param $1 (ref null $type13)) (result i32)
  (local $scratch (ref null $type13))
  (if (result i32)
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.is_null
     (local.get $1)
    )
   )
   (else
    (if (result i32)
     (ref.is_null
      (local.get $1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type13 0
         (local.get $0)
        )
        (struct.get $type13 0
         (local.get $1)
        )
       )
       (then
        (return_call $function27
         (struct.get $type13 1
          (local.get $0)
         )
         (block (result (ref null $type13))
          (local.set $scratch
           (struct.get $type13 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready65)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global65)
           )
          )
          (local.get $scratch)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
  )
 )
 (func $function30 (type $call35) (param $0 (ref null $environment84)) (param $1 i64) (result (ref null $type13))
  (local $2 (ref $type61))
  (local $3 (ref $type33))
  (struct.set $type61 1
   (local.tee $2
    (struct.new_default $type61)
   )
   (struct.new $type33
    (ref.func $function31)
    (struct.new $environment31
     (local.get $2)
    )
   )
  )
  (struct.set $type61 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type61 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call33
   (struct.get $type33 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type61 1
       (local.get $2)
      )
     )
    )
   )
   (local.get $1)
   (ref.null none)
   (struct.get $type33 0
    (local.get $3)
   )
  )
 )
 (func $function31 (type $call33) (param $0 structref) (param $1 i64) (param $2 (ref null $type13)) (result (ref null $type13))
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type28 1
    (global.get $global79)
   )
  )
  (if (result (ref null $type13))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment31 0
        (ref.cast (ref $environment31)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function31
     (struct.get $type33 1
      (struct.get $type61 1
       (struct.get $environment31 0
        (ref.cast (ref $environment31)
         (local.get $0)
        )
       )
      )
     )
     (local.tee $1
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
     (struct.new $type13
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function32 (type $call28) (param $0 structref) (param $1 i64) (result i32)
  (i64.eqz
   (local.get $1)
  )
 )
 (func $function33 (type $105) (param $0 i64) (param $1 (ref $type35)) (result (ref $type14))
  (local $2 (ref $type64))
  (local $3 (ref $type62))
  (local $4 (ref $type31))
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type28 1
    (global.get $global79)
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready85)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global85)
     )
    )
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global87)
     )
    )
    (array.new_fixed $type14 0)
   )
   (else
    (struct.set $type64 1
     (local.tee $2
      (struct.new_default $type64)
     )
     (struct.new $type31
      (ref.func $function39)
      (struct.new $environment39
       (local.get $0)
       (local.tee $3
        (struct.new $type62
         (i32.const 1)
         (array.new $type14
          (call_ref $call35
           (struct.get $type35 1
            (local.get $1)
           )
           (i64.const 0)
           (struct.get $type35 0
            (local.get $1)
           )
          )
          (block (result i32)
           (if
            (i64.gt_u
             (local.get $0)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $0)
           )
          )
         )
        )
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type64 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call31
      (struct.get $type31 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type64 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1)
      (struct.get $type31 0
       (local.get $4)
      )
     )
    )
    (struct.get $type62 1
     (local.get $3)
    )
   )
  )
 )
 (func $function39 (type $call31) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment39))
  (local $3 (ref $type35))
  (local $4 (ref null $type13))
  (if (result i32)
   (i64.gt_s
    (struct.get $environment39 0
     (local.tee $2
      (ref.cast (ref $environment39)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $4
     (call_ref $call35
      (struct.get $type35 1
       (local.tee $3
        (struct.get $environment39 2
         (local.get $2)
        )
       )
      )
      (local.get $1)
      (struct.get $type35 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (struct.get $type62 1
      (struct.get $environment39 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (struct.get $environment39 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function39
     (struct.get $type31 1
      (struct.get $type64 1
       (struct.get $environment39 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function40 (type $call48) (param $0 (ref $environment40)) (param $1 i64) (param $2 (ref $type18)) (param $3 (ref $type49)) (result i32)
  (local $4 (ref $type72))
  (local $5 (ref null $type13))
  (local $6 (ref $type63))
  (local $7 (ref $type43))
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (array.get $type14
    (struct.get $type62 1
     (struct.get $environment40 0
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (local.set $7
   (struct.new $type43
    (struct.new $environment41
     (local.get $2)
     (local.tee $6
      (struct.get $environment40 1
       (local.get $0)
      )
     )
    )
   )
  )
  (struct.set $type72 1
   (local.tee $4
    (struct.new_default $type72)
   )
   (struct.new $type71
    (struct.new $environment47
     (struct.new $type46
      (struct.new $environment44
       (local.get $3)
       (local.get $6)
      )
     )
     (local.get $7)
     (local.get $4)
    )
   )
  )
  (struct.set $type72 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type72 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function47
   (struct.get $type71 0
    (struct.get $type72 1
     (local.get $4)
    )
   )
   (local.get $5)
   (i64.const 0)
   (i32.const 1)
   (struct.new $type45
    (ref.func $function46)
    (ref.null none)
   )
  )
 )
 (func $function42 (type $call51) (param $0 (ref $type18)) (param $1 (ref $type50)) (param $2 i64) (param $3 i64) (result i64)
  (local $4 (ref $type70))
  (local $5 (ref $type69))
  (local $6 (ref $type69))
  (local $7 (ref $type60))
  (if
   (i64.gt_u
    (local.get $2)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.new $type69
    (i32.const 1)
    (array.get $type18
     (local.get $0)
     (i32.wrap_i64
      (local.get $2)
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.new $type69
    (i32.const 0)
    (array.get $type18
     (local.get $0)
     (i32.wrap_i64
      (local.get $3)
     )
    )
   )
  )
  (struct.set $type69 0
   (local.get $5)
   (i32.const 1)
  )
  (struct.set $type70 1
   (local.tee $4
    (struct.new_default $type70)
   )
   (struct.new $type60
    (ref.func $function43)
    (struct.new $environment43
     (local.get $2)
     (local.get $6)
     (local.get $1)
     (local.get $5)
     (local.get $0)
     (local.get $3)
     (local.get $4)
    )
   )
  )
  (struct.set $type70 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type70 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call60
   (struct.get $type60 1
    (local.tee $7
     (ref.as_non_null
      (struct.get $type70 1
       (local.get $4)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type60 0
    (local.get $7)
   )
  )
 )
 (func $function43 (type $call60) (param $0 (ref null $environment43)) (param $1 i64) (result i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (local $5 i64)
  (if (result i64)
   (i64.eq
    (local.get $1)
    (struct.get $environment43 0
     (local.get $0)
    )
   )
   (then
    (i64.const 1)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment43 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (array.get $type17
      (struct.get $type69 1
       (struct.get $environment43 1
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (array.get $type50
      (struct.get $environment43 2
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment43 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.get $type17
      (struct.get $type69 1
       (struct.get $environment43 3
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready68)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global68)
     )
    )
    (if (result i64)
     (select
      (local.get $3)
      (i32.eqz
       (local.get $3)
      )
      (local.get $2)
     )
     (then
      (local.set $4
       (struct.get $environment43 0
        (local.get $0)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (array.get $type17
        (array.get $type18
         (struct.get $environment43 4
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (local.set $4
       (struct.get $environment43 5
        (local.get $0)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (array.get $type17
        (array.get $type18
         (struct.get $environment43 4
          (local.get $0)
         )
         (i32.wrap_i64
          (local.get $5)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready68)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global68)
       )
      )
      (if (result i64)
       (select
        (local.get $3)
        (i32.eqz
         (local.get $3)
        )
        (local.get $2)
       )
       (then
        (if
         (i32.eqz
          (struct.get $type70 0
           (struct.get $environment43 6
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (return_call $function43
         (struct.get $type60 1
          (struct.get $type70 1
           (struct.get $environment43 6
            (local.get $0)
           )
          )
         )
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (else
        (select
         (i64.const 0)
         (i64.const 2)
         (local.get $2)
        )
       )
      )
     )
     (else
      (select
       (i64.const 0)
       (i64.const 2)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function46 (type $call45) (param $0 (ref null $environment49)) (param $1 i32) (result i32)
  (local.get $1)
 )
 (func $function47 (type $call71) (param $0 (ref $environment47)) (param $1 (ref null $type13)) (param $2 i64) (param $3 i32) (param $4 (ref $type45)) (result i32)
  (local $5 (ref $type74))
  (local $6 (ref $environment44))
  (local $7 (ref $type49))
  (if
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.set $6
     (struct.get $type46 0
      (struct.get $environment47 0
       (local.get $0)
      )
     )
    )
    (return_call_ref $call49
     (struct.get $type49 1
      (local.tee $7
       (struct.get $environment44 0
        (local.get $6)
       )
      )
     )
     (struct.get $type63 1
      (struct.get $environment44 1
       (local.get $6)
      )
     )
     (local.get $4)
     (struct.get $type49 0
      (local.get $7)
     )
    )
   )
   (else
    (struct.set $type74 1
     (local.tee $5
      (struct.new_default $type74)
     )
     (struct.new $type73
      (struct.new $environment48
       (local.get $4)
       (local.get $5)
       (struct.get $environment47 1
        (local.get $0)
       )
       (local.get $2)
       (struct.get $environment47 2
        (local.get $0)
       )
      )
     )
    )
    (struct.set $type74 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type74 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (struct.get $type73 0
      (struct.get $type74 1
       (local.get $5)
      )
     )
     (local.get $1)
     (ref.null none)
     (local.get $3)
    )
   )
  )
  (unreachable)
 )
 (func $function48 (type $call73) (param $0 (ref $environment48)) (param $1 (ref null $type13)) (param $2 (ref null $type13)) (param $3 i32) (result i32)
  (local $4 (ref $environment50))
  (local $5 (ref $type78))
  (local $6 (ref $type75))
  (local $7 (ref $type76))
  (local $8 (ref $environment41))
  (local $9 (ref $type77))
  (local $10 (ref $type45))
  (local $11 (ref $type56))
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (if
   (i32.eqz
    (struct.get $type76 0
     (local.tee $7
      (struct.new $type76
       (i32.const 1)
       (struct.get $type13 1
        (local.get $1)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.new $type75
    (i32.const 1)
    (struct.get $type13 0
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type75 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type77 0
     (local.tee $9
      (struct.new $type77
       (i32.const 1)
       (if (result (ref $type45))
        (ref.is_null
         (struct.get $type76 1
          (local.get $7)
         )
        )
        (then
         (struct.get $environment48 0
          (local.get $0)
         )
        )
        (else
         (struct.new $type45
          (ref.func $function49)
          (struct.new $environment49
           (struct.get $environment48 1
            (local.get $0)
           )
           (local.get $7)
           (local.get $6)
           (local.get $2)
          )
         )
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $8
   (struct.get $type43 0
    (struct.get $environment48 2
     (local.get $0)
    )
   )
  )
  (local.set $13
   (struct.get $type75 1
    (local.get $6)
   )
  )
  (local.set $12
   (struct.get $environment48 3
    (local.get $0)
   )
  )
  (local.set $10
   (struct.get $type77 1
    (local.get $9)
   )
  )
  (if
   (i32.eqz
    (global.get $ready112)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global112)
   )
  )
  (local.set $4
   (struct.new $environment50
    (struct.get $environment48 4
     (local.get $0)
    )
    (local.get $2)
    (local.get $7)
    (local.get $9)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $14
     (call $function42
      (struct.get $environment41 0
       (local.get $8)
      )
      (struct.get $type63 1
       (struct.get $environment41 1
        (local.get $8)
       )
      )
      (local.get $12)
      (local.get $13)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eq
      (local.get $14)
      (i64.const 1)
     )
     (then
      (if
       (i64.gt_u
        (local.get $12)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type50
       (struct.get $type63 1
        (struct.get $environment41 1
         (local.get $8)
        )
       )
       (i32.wrap_i64
        (local.get $12)
       )
       (local.get $13)
      )
      (if
       (i32.eqz
        (struct.get $type76 0
         (struct.get $environment50 2
          (local.get $4)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready149)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global149)
       )
      )
      (struct.set $type78 1
       (local.tee $5
        (struct.new_default $type78)
       )
       (struct.new $type56
        (ref.func $function52)
        (struct.new $environment52
         (local.get $5)
         (struct.new $type33
          (ref.func $primitive0)
          (ref.null none)
         )
        )
       )
      )
      (struct.set $type78 0
       (local.get $5)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type78 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (call_ref $call56
        (struct.get $type56 1
         (local.tee $11
          (ref.as_non_null
           (struct.get $type78 1
            (local.get $5)
           )
          )
         )
        )
        (struct.get $environment50 1
         (local.get $4)
        )
        (struct.get $type76 1
         (struct.get $environment50 2
          (local.get $4)
         )
        )
        (struct.get $type56 0
         (local.get $11)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type77 0
         (struct.get $environment50 3
          (local.get $4)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (struct.get $type72 0
         (struct.get $environment50 0
          (local.get $4)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function47
       (struct.get $type71 0
        (struct.get $type72 1
         (struct.get $environment50 0
          (local.get $4)
         )
        )
       )
       (local.get $1)
       (i64.add
        (local.get $12)
        (i64.const 1)
       )
       (local.get $3)
       (struct.get $type77 1
        (struct.get $environment50 3
         (local.get $4)
        )
       )
      )
     )
     (else
      (if
       (i64.eq
        (local.get $14)
        (i64.const 2)
       )
       (then
        (return_call_ref $call45
         (struct.get $type45 1
          (local.get $10)
         )
         (local.get $3)
         (struct.get $type45 0
          (local.get $10)
         )
        )
       )
       (else
        (unreachable)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function49 (type $call45) (param $0 (ref null $environment49)) (param $1 i32) (result i32)
  (local $2 (ref null $type13))
  (local $3 (ref null $type13))
  (local $4 i64)
  (if
   (i32.eqz
    (struct.get $type76 0
     (struct.get $environment49 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (struct.get $type76 1
    (struct.get $environment49 1
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type75 0
     (struct.get $environment49 2
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.get $type75 1
    (struct.get $environment49 2
     (local.get $0)
    )
   )
  )
  (local.set $3
   (struct.get $environment49 3
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (struct.get $type74 0
     (struct.get $environment49 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call $function48
   (struct.get $type73 0
    (struct.get $type74 1
     (struct.get $environment49 0
      (local.get $0)
     )
    )
   )
   (local.get $2)
   (struct.new $type13
    (local.get $4)
    (local.get $3)
   )
   (local.get $1)
  )
 )
 (func $function52 (type $call56) (param $0 (ref null $environment52)) (param $1 (ref null $type13)) (param $2 (ref null $type13)) (result (ref null $type13))
  (local $3 (ref null $type13))
  (local $4 (ref $type33))
  (if (result (ref null $type13))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $3
     (struct.get $type13 1
      (local.get $1)
     )
    )
    (local.set $1
     (call_ref $call33
      (struct.get $type33 1
       (local.tee $4
        (struct.get $environment52 1
         (local.get $0)
        )
       )
      )
      (struct.get $type13 0
       (local.get $1)
      )
      (local.get $2)
      (struct.get $type33 0
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type78 0
       (struct.get $environment52 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function52
     (struct.get $type56 1
      (struct.get $type78 1
       (struct.get $environment52 0
        (local.get $0)
       )
      )
     )
     (local.get $3)
     (local.get $1)
    )
   )
  )
 )
 (func $function54 (type $call37) (param $0 (ref struct)) (param $1 i64) (result (ref $type17))
  (local $2 (ref null $type13))
  (local $3 (ref $type31))
  (local $4 (ref $type69))
  (local $5 i64)
  (if
   (i64.gt_u
    (local.tee $5
     (struct.get $environment54 0
      (ref.cast (ref $environment54)
       (local.get $0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type69 0
     (local.tee $4
      (struct.new $type69
       (i32.const 1)
       (array.new_default $type17
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (struct.get $type69 1
    (local.get $4)
   )
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.const 1)
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (array.get $type14
    (struct.get $environment54 1
     (ref.cast (ref $environment54)
      (local.get $0)
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready163)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global163)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.get $2)
    )
    (then
     (i32.const 0)
    )
    (else
     (drop
      (call_ref $call31
       (struct.get $type31 1
        (local.tee $3
         (struct.new $type31
          (ref.func $function55)
          (struct.new $environment55
           (local.get $4)
          )
         )
        )
       )
       (struct.get $type13 0
        (local.get $2)
       )
       (struct.get $type31 0
        (local.get $3)
       )
      )
     )
     (local.set $2
      (struct.get $type13 1
       (local.get $2)
      )
     )
     (if
      (i32.eqz
       (global.get $ready163)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global163)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $2)
      )
      (then
       (i32.const 0)
      )
      (else
       (drop
        (call_ref $call31
         (struct.get $type31 1
          (local.get $3)
         )
         (struct.get $type13 0
          (local.get $2)
         )
         (struct.get $type31 0
          (local.get $3)
         )
        )
       )
       (local.set $2
        (struct.get $type13 1
         (local.get $2)
        )
       )
       (if
        (i32.eqz
         (global.get $ready163)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global163)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $2)
        )
        (then
         (i32.const 0)
        )
        (else
         (drop
          (call_ref $call31
           (struct.get $type31 1
            (local.get $3)
           )
           (struct.get $type13 0
            (local.get $2)
           )
           (struct.get $type31 0
            (local.get $3)
           )
          )
         )
         (local.set $2
          (struct.get $type13 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (global.get $ready163)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global163)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i32.const 0)
          )
          (else
           (drop
            (call_ref $call31
             (struct.get $type31 1
              (local.get $3)
             )
             (struct.get $type13 0
              (local.get $2)
             )
             (struct.get $type31 0
              (local.get $3)
             )
            )
           )
           (local.set $2
            (struct.get $type13 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (global.get $ready163)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global163)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $2)
            )
            (then
             (i32.const 0)
            )
            (else
             (drop
              (call_ref $call31
               (struct.get $type31 1
                (local.get $3)
               )
               (struct.get $type13 0
                (local.get $2)
               )
               (struct.get $type31 0
                (local.get $3)
               )
              )
             )
             (local.set $2
              (struct.get $type13 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (global.get $ready163)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global163)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $2)
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (call_ref $call31
                 (struct.get $type31 1
                  (local.get $3)
                 )
                 (struct.get $type13 0
                  (local.get $2)
                 )
                 (struct.get $type31 0
                  (local.get $3)
                 )
                )
               )
               (local.set $2
                (struct.get $type13 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready163)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global163)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (drop
                  (call_ref $call31
                   (struct.get $type31 1
                    (local.get $3)
                   )
                   (struct.get $type13 0
                    (local.get $2)
                   )
                   (struct.get $type31 0
                    (local.get $3)
                   )
                  )
                 )
                 (local.set $2
                  (struct.get $type13 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready163)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global163)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (call_ref $call31
                     (struct.get $type31 1
                      (local.get $3)
                     )
                     (struct.get $type13 0
                      (local.get $2)
                     )
                     (struct.get $type31 0
                      (local.get $3)
                     )
                    )
                   )
                   (local.set $2
                    (struct.get $type13 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready163)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global163)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $2)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (drop
                      (call_ref $call31
                       (struct.get $type31 1
                        (local.get $3)
                       )
                       (struct.get $type13 0
                        (local.get $2)
                       )
                       (struct.get $type31 0
                        (local.get $3)
                       )
                      )
                     )
                     (local.set $2
                      (struct.get $type13 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready163)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global163)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (drop
                        (call_ref $call31
                         (struct.get $type31 1
                          (local.get $3)
                         )
                         (struct.get $type13 0
                          (local.get $2)
                         )
                         (struct.get $type31 0
                          (local.get $3)
                         )
                        )
                       )
                       (local.set $2
                        (struct.get $type13 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready163)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global163)
                        )
                       )
                       (call $function56
                        (local.get $3)
                        (local.get $2)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type69 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (ref.as_non_null
   (struct.get $type69 1
    (local.get $4)
   )
  )
 )
 (func $function55 (type $call31) (param $0 (ref struct)) (param $1 i64) (result i32)
  (if
   (i32.eqz
    (struct.get $type69 0
     (struct.get $environment55 0
      (ref.cast (ref $environment55)
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type17
   (struct.get $type69 1
    (struct.get $environment55 0
     (ref.cast (ref $environment55)
      (local.get $0)
     )
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
   (i32.const 1)
  )
  (i32.const 0)
 )
 (func $function56 (type $call30) (param $0 (ref $type31)) (param $1 (ref null $type13)) (result i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call31
      (struct.get $type31 1
       (local.get $0)
      )
      (struct.get $type13 0
       (local.get $1)
      )
      (struct.get $type31 0
       (local.get $0)
      )
     )
    )
    (local.set $1
     (struct.get $type13 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready163)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global163)
     )
    )
    (return_call $function56
     (local.get $0)
     (local.get $1)
    )
   )
  )
 )
 (func $function57 (type $56) (param $0 i64) (param $1 (ref $type37)) (result (ref $type18))
  (local $2 (ref $type64))
  (local $3 (ref $type79))
  (local $4 (ref $type31))
  (if
   (i32.eqz
    (global.get $ready79)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (struct.get $type28 1
    (global.get $global79)
   )
  )
  (if (result (ref $type18))
   (i64.eqz
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready169)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global169)
     )
    )
    (if
     (i32.eqz
      (global.get $ready171)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global171)
     )
    )
    (array.new_fixed $type18 0)
   )
   (else
    (struct.set $type64 1
     (local.tee $2
      (struct.new_default $type64)
     )
     (struct.new $type31
      (ref.func $function63)
      (struct.new $environment63
       (local.get $0)
       (local.tee $3
        (struct.new $type79
         (i32.const 1)
         (array.new $type18
          (call_ref $call37
           (struct.get $type37 1
            (local.get $1)
           )
           (i64.const 0)
           (struct.get $type37 0
            (local.get $1)
           )
          )
          (block (result i32)
           (if
            (i64.gt_u
             (local.get $0)
             (i64.const 4294967295)
            )
            (then
             (unreachable)
            )
           )
           (i32.wrap_i64
            (local.get $0)
           )
          )
         )
        )
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
    (struct.set $type64 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call_ref $call31
      (struct.get $type31 1
       (local.tee $4
        (ref.as_non_null
         (struct.get $type64 1
          (local.get $2)
         )
        )
       )
      )
      (i64.const 1)
      (struct.get $type31 0
       (local.get $4)
      )
     )
    )
    (struct.get $type79 1
     (local.get $3)
    )
   )
  )
 )
 (func $function63 (type $call31) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment63))
  (local $3 (ref $type37))
  (local $4 (ref $type17))
  (if (result i32)
   (i64.gt_s
    (struct.get $environment63 0
     (local.tee $2
      (ref.cast (ref $environment63)
       (local.get $0)
      )
     )
    )
    (local.get $1)
   )
   (then
    (local.set $4
     (call_ref $call37
      (struct.get $type37 1
       (local.tee $3
        (struct.get $environment63 2
         (local.get $2)
        )
       )
      )
      (local.get $1)
      (struct.get $type37 0
       (local.get $3)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type18
     (struct.get $type79 1
      (struct.get $environment63 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (struct.get $environment63 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function63
     (struct.get $type31 1
      (struct.get $type64 1
       (struct.get $environment63 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function64 (type $call31) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type64))
  (local $3 (ref $environment64))
  (local $4 (ref $type69))
  (local $5 (ref $type31))
  (local $6 i64)
  (drop
   (ref.cast (ref $environment64)
    (local.get $0)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (local.set $4
   (struct.new $type69
    (i32.const 1)
    (array.get $type18
     (struct.get $type79 1
      (struct.get $environment64 0
       (local.tee $3
        (ref.cast (ref $environment64)
         (local.get $0)
        )
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready190)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global190)
   )
  )
  (struct.set $type64 1
   (local.tee $2
    (struct.new_default $type64)
   )
   (struct.new $type31
    (ref.func $function68)
    (struct.new $environment68
     (local.tee $6
      (struct.get $environment64 1
       (local.get $3)
      )
     )
     (struct.new $type31
      (ref.func $function65)
      (struct.new $environment65
       (struct.get $environment64 0
        (local.get $3)
       )
       (local.get $1)
       (local.get $6)
       (local.get $4)
      )
     )
     (local.get $2)
    )
   )
  )
  (struct.set $type64 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type64 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call31
   (struct.get $type31 1
    (local.tee $5
     (ref.as_non_null
      (struct.get $type64 1
       (local.get $2)
      )
     )
    )
   )
   (i64.const 0)
   (struct.get $type31 0
    (local.get $5)
   )
  )
 )
 (func $function65 (type $call31) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type64))
  (local $3 (ref $type69))
  (local $4 (ref $environment65))
  (local $5 (ref $type31))
  (drop
   (ref.cast (ref $environment65)
    (local.get $0)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type69 0
     (local.tee $3
      (struct.new $type69
       (i32.const 1)
       (array.get $type18
        (struct.get $type79 1
         (struct.get $environment65 0
          (ref.cast (ref $environment65)
           (local.get $0)
          )
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $1
     (struct.get $environment65 1
      (ref.cast (ref $environment65)
       (local.get $0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (array.get $type17
    (struct.get $type69 1
     (local.get $3)
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (then
    (local.set $1
     (struct.get $environment65 2
      (local.tee $4
       (ref.cast (ref $environment65)
        (local.get $0)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready190)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global190)
     )
    )
    (struct.set $type64 1
     (local.tee $2
      (struct.new_default $type64)
     )
     (struct.new $type31
      (ref.func $function68)
      (struct.new $environment68
       (local.get $1)
       (struct.new $type31
        (ref.func $function66)
        (struct.new $environment66
         (struct.get $environment65 3
          (local.get $4)
         )
         (local.get $3)
        )
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type64 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call31
     (struct.get $type31 1
      (local.tee $5
       (ref.as_non_null
        (struct.get $type64 1
         (local.get $2)
        )
       )
      )
     )
     (i64.const 0)
     (struct.get $type31 0
      (local.get $5)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function66 (type $call31) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment66))
  (if
   (i32.eqz
    (struct.get $type69 0
     (struct.get $environment66 0
      (ref.cast (ref $environment66)
       (local.get $0)
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.get $type17
    (struct.get $type69 1
     (struct.get $environment66 0
      (local.tee $2
       (ref.cast (ref $environment66)
        (local.get $0)
       )
      )
     )
    )
    (i32.wrap_i64
     (local.get $1)
    )
   )
   (then
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment66 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $type69 1
      (struct.get $environment66 1
       (ref.cast (ref $environment66)
        (local.get $2)
       )
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
   )
  )
  (i32.const 0)
 )
 (func $function68 (type $call31) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment68))
  (local $3 (ref $type31))
  (if (result i32)
   (i64.eq
    (struct.get $environment68 0
     (ref.cast (ref $environment68)
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (call_ref $call31
      (struct.get $type31 1
       (local.tee $3
        (struct.get $environment68 1
         (local.tee $2
          (ref.cast (ref $environment68)
           (local.get $0)
          )
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type31 0
       (local.get $3)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type64 0
       (struct.get $environment68 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function68
     (struct.get $type31 1
      (struct.get $type64 1
       (struct.get $environment68 2
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function71 (type $call37) (param $0 (ref struct)) (param $1 i64) (result (ref $type17))
  (if
   (i64.gt_u
    (local.tee $1
     (struct.get $environment71 0
      (ref.cast (ref $environment71)
       (local.get $0)
      )
     )
    )
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.new_default $type17
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function72 (type $call28) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment72))
  (local $3 (ref $type18))
  (drop
   (ref.cast (ref $environment72)
    (local.get $0)
   )
  )
  (local.set $3
   (struct.get $type79 1
    (struct.get $environment72 1
     (local.tee $2
      (ref.cast (ref $environment72)
       (local.get $0)
      )
     )
    )
   )
  )
  (return_call $function40
   (struct.get $type48 0
    (struct.get $type84 1
     (struct.get $environment72 0
      (local.get $2)
     )
    )
   )
   (local.get $1)
   (local.get $3)
   (struct.get $type86 1
    (struct.get $environment72 2
     (local.get $2)
    )
   )
  )
 )
 (func $function73 (type $call49) (param $0 (ref null $environment75)) (param $1 (ref $type50)) (param $2 (ref $type45)) (result i32)
  (return_call_ref $call45
   (struct.get $type45 1
    (local.get $2)
   )
   (i32.const 1)
   (struct.get $type45 0
    (local.get $2)
   )
  )
 )
 (func $function74 (type $call8) (param $0 (ref $environment74)) (result i32)
  (unreachable)
 )
 (func $function75 (type $call49) (param $0 (ref null $environment75)) (param $1 (ref $type50)) (param $2 (ref $type45)) (result i32)
  (local $3 i64)
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type18))
  (local $7 (ref $type75))
  (drop
   (struct.get $environment75 0
    (local.get $0)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.tee $3
     (call $function42
      (struct.get $type79 1
       (struct.get $environment75 0
        (local.get $0)
       )
      )
      (block (result (ref $type50))
       (if
        (i32.eqz
         (struct.get $type75 0
          (struct.get $environment75 1
           (local.get $0)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (struct.get $type75 1
         (local.tee $7
          (struct.get $environment75 1
           (local.get $0)
          )
         )
        )
       )
       (if
        (i32.eqz
         (struct.get $type75 0
          (local.get $7)
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $4
        (struct.get $type75 1
         (struct.get $environment75 1
          (local.get $0)
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready112)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global112)
        )
       )
       (local.get $1)
      )
      (local.get $3)
      (local.get $4)
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (if (result i32)
      (local.tee $5
       (i64.eq
        (local.get $3)
        (i64.const 1)
       )
      )
      (then
       (local.get $5)
      )
      (else
       (i64.eq
        (local.get $3)
        (i64.const 2)
       )
      )
     )
     (then
      (return_call_ref $call45
       (struct.get $type45 1
        (local.get $2)
       )
       (i32.const 1)
       (struct.get $type45 0
        (local.get $2)
       )
      )
     )
     (else
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function76 (type $call88) (param $0 (ref $environment76)) (param $1 i64) (param $2 (ref null $type25)) (result (ref null $type25))
  (local $3 (ref $type64))
  (local $4 (ref $type93))
  (local $5 (ref $type91))
  (local $6 (ref $type69))
  (local $7 (ref $type79))
  (local $8 (ref $type79))
  (local $9 (ref $type28))
  (local $10 (ref $type75))
  (local $11 (ref $type31))
  (if
   (i32.eqz
    (struct.get $type85 0
     (struct.get $environment76 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref null $type25))
   (call_ref $call28
    (struct.get $type28 1
     (local.tee $9
      (ref.as_non_null
       (struct.get $type85 1
        (struct.get $environment76 0
         (local.get $0)
        )
       )
      )
     )
    )
    (local.get $1)
    (struct.get $type28 0
     (local.get $9)
    )
   )
   (then
    (if
     (i32.eqz
      (struct.get $type75 0
       (struct.get $environment76 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.eq
      (struct.get $type75 1
       (local.tee $10
        (struct.get $environment76 1
         (local.get $0)
        )
       )
      )
      (local.get $1)
     )
     (then
      (if
       (i32.eqz
        (struct.get $type75 0
         (local.get $10)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.eqz
        (global.get $ready156)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global156)
       )
      )
      (if
       (i32.eqz
        (global.get $ready166)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global166)
       )
      )
      (local.set $7
       (struct.new $type79
        (i32.const 1)
        (call $function57
         (local.tee $1
          (struct.get $type75 1
           (struct.get $environment76 1
            (local.get $0)
           )
          )
         )
         (struct.new $type37
          (ref.func $function54)
          (struct.new $environment54
           (local.get $1)
           (struct.get $type62 1
            (struct.get $environment76 2
             (local.get $0)
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready190)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global190)
       )
      )
      (struct.set $type64 1
       (local.tee $3
        (struct.new_default $type64)
       )
       (struct.new $type31
        (ref.func $function68)
        (struct.new $environment68
         (local.get $1)
         (struct.new $type31
          (ref.func $function64)
          (struct.new $environment64
           (local.get $7)
           (local.get $1)
          )
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type64 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type64 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call31
        (struct.get $type31 1
         (local.tee $11
          (ref.as_non_null
           (struct.get $type64 1
            (local.get $3)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type31 0
         (local.get $11)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type75 0
         (struct.get $environment76 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $1
         (struct.get $type75 1
          (struct.get $environment76 1
           (local.get $0)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (struct.new $type69
        (i32.const 1)
        (array.get $type18
         (struct.get $type79 1
          (struct.get $environment76 3
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (struct.set $type93 1
       (local.tee $4
        (struct.new_default $type93)
       )
       (struct.new $type92
        (struct.new $environment77
         (struct.get $environment76 1
          (local.get $0)
         )
         (i64.const 2)
         (local.get $6)
         (local.get $4)
         (struct.new $type79
          (i32.const 1)
          (struct.get $type79 1
           (local.get $7)
          )
         )
         (struct.get $environment76 5
          (local.get $0)
         )
         (struct.get $environment76 2
          (local.get $0)
         )
         (struct.get $environment76 7
          (local.get $0)
         )
        )
       )
      )
      (struct.set $type93 0
       (local.get $4)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type93 0
         (local.get $4)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function77
       (struct.get $type92 0
        (struct.get $type93 1
         (local.get $4)
        )
       )
       (i64.const 0)
       (i64.const 0)
       (ref.null none)
       (ref.null none)
       (local.get $2)
      )
     )
     (else
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (local.set $6
       (struct.new $type69
        (i32.const 1)
        (array.get $type18
         (struct.get $type79 1
          (local.tee $8
           (struct.get $environment76 3
            (local.get $0)
           )
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (struct.set $type91 1
       (local.tee $5
        (struct.new_default $type91)
       )
       (struct.new $type90
        (struct.new $environment85
         (local.get $1)
         (struct.get $environment76 8
          (local.get $0)
         )
         (struct.get $environment76 9
          (local.get $0)
         )
         (local.get $5)
         (local.get $8)
         (i64.const 2)
         (struct.get $environment76 2
          (local.get $0)
         )
         (local.get $6)
        )
       )
      )
      (struct.set $type91 0
       (local.get $5)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type91 0
         (local.get $5)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function85
       (struct.get $type90 0
        (struct.get $type91 1
         (local.get $5)
        )
       )
       (i64.const 0)
       (i64.const 0)
       (local.get $2)
      )
     )
    )
    (unreachable)
   )
   (else
    (local.get $2)
   )
  )
 )
 (func $function77 (type $call92) (param $0 (ref $environment77)) (param $1 i64) (param $2 i64) (param $3 (ref null $type13)) (param $4 (ref null $type16)) (param $5 (ref null $type25)) (result (ref null $type25))
  (local $6 (ref $type85))
  (local $7 (ref $environment74))
  (local $8 (ref $type28))
  (local $9 (ref $type16))
  (local $10 i32)
  (if
   (i32.eqz
    (struct.get $type75 0
     (struct.get $environment77 0
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if (result (ref null $type25))
   (if (result i32)
    (local.tee $10
     (i64.eq
      (struct.get $type75 1
       (struct.get $environment77 0
        (local.get $0)
       )
      )
      (local.get $1)
     )
    )
    (then
     (local.get $10)
    )
    (else
     (i64.eq
      (local.get $2)
      (i64.const 2)
     )
    )
   )
   (then
    (if
     (i32.eqz
      (struct.get $type75 0
       (struct.get $environment77 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready242)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global242)
     )
    )
    (struct.set $type85 1
     (local.tee $6
      (struct.new_default $type85)
     )
     (struct.new $type28
      (ref.func $function83)
      (struct.new $environment83
       (struct.get $type75 1
        (struct.get $environment77 0
         (local.get $0)
        )
       )
       (struct.new $type28
        (ref.func $function78)
        (struct.new $environment78
         (local.get $4)
        )
       )
       (local.get $6)
      )
     )
    )
    (struct.set $type85 0
     (local.get $6)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type85 0
       (local.get $6)
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref null $type25))
     (if (result i32)
      (call_ref $call28
       (struct.get $type28 1
        (local.tee $8
         (ref.as_non_null
          (struct.get $type85 1
           (local.get $6)
          )
         )
        )
       )
       (i64.const 0)
       (struct.get $type28 0
        (local.get $8)
       )
      )
      (then
       (if
        (i32.eqz
         (struct.get $type75 0
          (struct.get $environment74 1
           (local.tee $7
            (struct.get $type8 1
             (struct.get $type87 1
              (struct.get $environment77 5
               (local.get $0)
              )
             )
            )
           )
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (call $function40
        (struct.get $type48 0
         (struct.get $type84 1
          (struct.get $environment74 0
           (local.get $7)
          )
         )
        )
        (struct.get $type75 1
         (struct.get $environment74 1
          (local.get $7)
         )
        )
        (struct.get $type79 1
         (struct.get $environment74 2
          (local.get $7)
         )
        )
        (struct.get $type86 1
         (struct.get $environment74 3
          (local.get $7)
         )
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type75 0
         (struct.get $environment77 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.tee $1
         (struct.get $type75 1
          (struct.get $environment77 0
           (local.get $0)
          )
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type14
       (struct.get $type62 1
        (struct.get $environment77 6
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $3)
      )
      (if
       (i32.eqz
        (global.get $ready82)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global82)
       )
      )
      (struct.new $type25
       (call $function33
        (struct.get $environment77 7
         (local.get $0)
        )
        (struct.new $type35
         (ref.func $function84)
         (struct.new $environment84
          (struct.get $environment77 6
           (local.get $0)
          )
         )
        )
       )
       (local.get $5)
      )
     )
     (else
      (local.get $5)
     )
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment77 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $type69 1
      (struct.get $environment77 2
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 1)
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (struct.new $type16
      (array.get $type18
       (struct.get $type79 1
        (struct.get $environment77 4
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (struct.get $type93 0
       (struct.get $environment77 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (call $function77
      (struct.get $type92 0
       (struct.get $type93 1
        (struct.get $environment77 3
         (local.get $0)
        )
       )
      )
      (i64.add
       (local.get $1)
       (i64.const 1)
      )
      (i64.add
       (local.get $2)
       (i64.const 1)
      )
      (struct.new $type13
       (local.get $1)
       (local.get $3)
      )
      (local.get $9)
      (local.get $5)
     )
    )
    (if
     (i32.eqz
      (struct.get $type69 0
       (struct.get $environment77 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type17
     (struct.get $type69 1
      (struct.get $environment77 2
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (i32.const 0)
    )
    (if
     (i32.eqz
      (struct.get $type93 0
       (struct.get $environment77 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function77
     (struct.get $type92 0
      (struct.get $type93 1
       (struct.get $environment77 3
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $function78 (type $call28) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref null $type16))
  (local $3 (ref $environment81))
  (local $4 (ref $type17))
  (local $5 (ref $type95))
  (local $6 i32)
  (local.set $2
   (struct.get $environment78 0
    (ref.cast (ref $environment78)
     (local.get $0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready236)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global236)
   )
  )
  (struct.set $type95 1
   (local.tee $5
    (struct.new_default $type95)
   )
   (struct.new $type94
    (struct.new $environment81
     (struct.new $type41
      (struct.new $environment79
       (local.get $1)
      )
     )
     (local.get $5)
    )
   )
  )
  (struct.set $type95 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type95 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type94 0
    (struct.get $type95 1
     (local.get $5)
    )
   )
  )
  (if (result i32)
   (ref.is_null
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $6
      (array.get $type17
       (struct.get $type16 0
        (local.get $2)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $1
           (struct.get $environment79 0
            (struct.get $type41 0
             (struct.get $environment81 0
              (local.get $3)
             )
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (then
      (local.get $6)
     )
     (else
      (local.set $2
       (struct.get $type16 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (struct.get $type95 0
         (struct.get $environment81 1
          (local.get $3)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type94 0
        (struct.get $type95 1
         (struct.get $environment81 1
          (local.get $3)
         )
        )
       )
      )
      (if (result i32)
       (ref.is_null
        (local.get $2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if (result i32)
         (local.tee $6
          (array.get $type17
           (struct.get $type16 0
            (local.get $2)
           )
           (block (result i32)
            (if
             (i64.gt_u
              (local.tee $1
               (struct.get $environment79 0
                (struct.get $type41 0
                 (struct.get $environment81 0
                  (local.get $3)
                 )
                )
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
         (then
          (local.get $6)
         )
         (else
          (local.set $2
           (struct.get $type16 1
            (local.get $2)
           )
          )
          (if
           (i32.eqz
            (struct.get $type95 0
             (struct.get $environment81 1
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type94 0
            (struct.get $type95 1
             (struct.get $environment81 1
              (local.get $3)
             )
            )
           )
          )
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (local.tee $6
              (array.get $type17
               (struct.get $type16 0
                (local.get $2)
               )
               (block (result i32)
                (if
                 (i64.gt_u
                  (local.tee $1
                   (struct.get $environment79 0
                    (struct.get $type41 0
                     (struct.get $environment81 0
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (i64.const 4294967295)
                 )
                 (then
                  (unreachable)
                 )
                )
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
             (then
              (local.get $6)
             )
             (else
              (local.set $2
               (struct.get $type16 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (struct.get $type95 0
                 (struct.get $environment81 1
                  (local.get $3)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type94 0
                (struct.get $type95 1
                 (struct.get $environment81 1
                  (local.get $3)
                 )
                )
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $2)
               )
               (then
                (i32.const 0)
               )
               (else
                (if (result i32)
                 (local.tee $6
                  (array.get $type17
                   (struct.get $type16 0
                    (local.get $2)
                   )
                   (block (result i32)
                    (if
                     (i64.gt_u
                      (local.tee $1
                       (struct.get $environment79 0
                        (struct.get $type41 0
                         (struct.get $environment81 0
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (i64.const 4294967295)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (i32.wrap_i64
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (then
                  (local.get $6)
                 )
                 (else
                  (local.set $2
                   (struct.get $type16 1
                    (local.get $2)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type95 0
                     (struct.get $environment81 1
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type94 0
                    (struct.get $type95 1
                     (struct.get $environment81 1
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (ref.is_null
                    (local.get $2)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if (result i32)
                     (local.tee $6
                      (array.get $type17
                       (struct.get $type16 0
                        (local.get $2)
                       )
                       (block (result i32)
                        (if
                         (i64.gt_u
                          (local.tee $1
                           (struct.get $environment79 0
                            (struct.get $type41 0
                             (struct.get $environment81 0
                              (local.get $3)
                             )
                            )
                           )
                          )
                          (i64.const 4294967295)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (i32.wrap_i64
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (then
                      (local.get $6)
                     )
                     (else
                      (local.set $2
                       (struct.get $type16 1
                        (local.get $2)
                       )
                      )
                      (if
                       (i32.eqz
                        (struct.get $type95 0
                         (struct.get $environment81 1
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $3
                       (struct.get $type94 0
                        (struct.get $type95 1
                         (struct.get $environment81 1
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (local.tee $6
                          (array.get $type17
                           (struct.get $type16 0
                            (local.get $2)
                           )
                           (block (result i32)
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (struct.get $environment79 0
                                (struct.get $type41 0
                                 (struct.get $environment81 0
                                  (local.get $3)
                                 )
                                )
                               )
                              )
                              (i64.const 4294967295)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (then
                          (local.get $6)
                         )
                         (else
                          (local.set $2
                           (struct.get $type16 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (struct.get $type95 0
                             (struct.get $environment81 1
                              (local.get $3)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (local.set $3
                           (struct.get $type94 0
                            (struct.get $type95 1
                             (struct.get $environment81 1
                              (local.get $3)
                             )
                            )
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $2)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if (result i32)
                             (local.tee $6
                              (array.get $type17
                               (struct.get $type16 0
                                (local.get $2)
                               )
                               (block (result i32)
                                (if
                                 (i64.gt_u
                                  (local.tee $1
                                   (struct.get $environment79 0
                                    (struct.get $type41 0
                                     (struct.get $environment81 0
                                      (local.get $3)
                                     )
                                    )
                                   )
                                  )
                                  (i64.const 4294967295)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (i32.wrap_i64
                                 (local.get $1)
                                )
                               )
                              )
                             )
                             (then
                              (local.get $6)
                             )
                             (else
                              (local.set $2
                               (struct.get $type16 1
                                (local.get $2)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type95 0
                                 (struct.get $environment81 1
                                  (local.get $3)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $3
                               (struct.get $type94 0
                                (struct.get $type95 1
                                 (struct.get $environment81 1
                                  (local.get $3)
                                 )
                                )
                               )
                              )
                              (if (result i32)
                               (ref.is_null
                                (local.get $2)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if (result i32)
                                 (local.tee $6
                                  (array.get $type17
                                   (struct.get $type16 0
                                    (local.get $2)
                                   )
                                   (block (result i32)
                                    (if
                                     (i64.gt_u
                                      (local.tee $1
                                       (struct.get $environment79 0
                                        (struct.get $type41 0
                                         (struct.get $environment81 0
                                          (local.get $3)
                                         )
                                        )
                                       )
                                      )
                                      (i64.const 4294967295)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (i32.wrap_i64
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $6)
                                 )
                                 (else
                                  (local.set $2
                                   (struct.get $type16 1
                                    (local.get $2)
                                   )
                                  )
                                  (if
                                   (i32.eqz
                                    (struct.get $type95 0
                                     (struct.get $environment81 1
                                      (local.get $3)
                                     )
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (local.set $3
                                   (struct.get $type94 0
                                    (struct.get $type95 1
                                     (struct.get $environment81 1
                                      (local.get $3)
                                     )
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (local.tee $6
                                      (array.get $type17
                                       (struct.get $type16 0
                                        (local.get $2)
                                       )
                                       (block (result i32)
                                        (if
                                         (i64.gt_u
                                          (local.tee $1
                                           (struct.get $environment79 0
                                            (struct.get $type41 0
                                             (struct.get $environment81 0
                                              (local.get $3)
                                             )
                                            )
                                           )
                                          )
                                          (i64.const 4294967295)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (i32.wrap_i64
                                         (local.get $1)
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $6)
                                     )
                                     (else
                                      (local.set $2
                                       (struct.get $type16 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (struct.get $type95 0
                                         (struct.get $environment81 1
                                          (local.get $3)
                                         )
                                        )
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (return_call $function81
                                       (struct.get $type94 0
                                        (struct.get $type95 1
                                         (struct.get $environment81 1
                                          (local.get $3)
                                         )
                                        )
                                       )
                                       (local.get $2)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function81 (type $call94) (param $0 (ref $environment81)) (param $1 (ref null $type16)) (result i32)
  (local $2 (ref $type17))
  (local $3 i64)
  (local $4 i32)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if (result i32)
     (local.tee $4
      (array.get $type17
       (struct.get $type16 0
        (local.get $1)
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $3
           (struct.get $environment79 0
            (struct.get $type41 0
             (struct.get $environment81 0
              (local.get $0)
             )
            )
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
     )
     (then
      (local.get $4)
     )
     (else
      (local.set $1
       (struct.get $type16 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type95 0
         (struct.get $environment81 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function81
       (struct.get $type94 0
        (struct.get $type95 1
         (struct.get $environment81 1
          (local.get $0)
         )
        )
       )
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function83 (type $call28) (param $0 structref) (param $1 i64) (result i32)
  (local $2 (ref $environment83))
  (local $3 (ref $type28))
  (local $4 i32)
  (if (result i32)
   (local.tee $4
    (i64.eq
     (struct.get $environment83 0
      (ref.cast (ref $environment83)
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (local.get $4)
   )
   (else
    (if (result i32)
     (call_ref $call28
      (struct.get $type28 1
       (local.tee $3
        (struct.get $environment83 1
         (local.tee $2
          (ref.cast (ref $environment83)
           (local.get $0)
          )
         )
        )
       )
      )
      (local.get $1)
      (struct.get $type28 0
       (local.get $3)
      )
     )
     (then
      (if
       (i32.eqz
        (struct.get $type85 0
         (struct.get $environment83 2
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call $function83
       (struct.get $type28 1
        (struct.get $type85 1
         (struct.get $environment83 2
          (local.get $2)
         )
        )
       )
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function84 (type $call35) (param $0 (ref null $environment84)) (param $1 i64) (result (ref null $type13))
  (drop
   (struct.get $environment84 0
    (local.get $0)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type14
   (struct.get $type62 1
    (struct.get $environment84 0
     (local.get $0)
    )
   )
   (i32.wrap_i64
    (local.get $1)
   )
  )
 )
 (func $function85 (type $call90) (param $0 (ref $environment85)) (param $1 i64) (param $2 i64) (param $3 (ref null $type25)) (result (ref null $type25))
  (local $4 i64)
  (local $5 i64)
  (local $6 i32)
  (local $7 (ref $type14))
  (local $8 (ref null $type13))
  (local $9 (ref $type17))
  (if (result (ref null $type25))
   (i64.eq
    (local.tee $4
     (struct.get $environment85 0
      (local.get $0)
     )
    )
    (local.get $1)
   )
   (then
    (if
     (i64.gt_u
      (local.tee $1
       (local.get $4)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type50
     (struct.get $type63 1
      (struct.get $environment85 1
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $2)
    )
    (if
     (i32.eqz
      (struct.get $type89 0
       (struct.get $environment85 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function76
     (struct.get $type88 0
      (struct.get $type89 1
       (struct.get $environment85 2
        (local.get $0)
       )
      )
     )
     (i64.add
      (struct.get $environment85 0
       (local.get $0)
      )
      (i64.const 1)
     )
     (local.get $3)
    )
   )
   (else
    (if
     (i32.eqz
      (struct.get $type91 0
       (struct.get $environment85 3
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (call $function85
      (struct.get $type90 0
       (struct.get $type91 1
        (struct.get $environment85 3
         (local.get $0)
        )
       )
      )
      (i64.add
       (local.get $1)
       (i64.const 1)
      )
      (local.get $2)
      (local.get $3)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $9
     (array.get $type18
      (struct.get $type79 1
       (struct.get $environment85 4
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ne
      (local.tee $5
       (array.get $type50
        (struct.get $type63 1
         (struct.get $environment85 1
          (local.get $0)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (i64.const 2)
     )
     (then
      (array.set $type14
       (struct.get $type62 1
        (struct.get $environment85 6
         (local.get $0)
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.tee $6
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
       (struct.new $type13
        (local.tee $4
         (struct.get $environment85 0
          (local.get $0)
         )
        )
        (array.get $type14
         (struct.get $type62 1
          (struct.get $environment85 6
           (local.get $0)
          )
         )
         (local.get $6)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $9)
       (i32.wrap_i64
        (local.get $4)
       )
       (i32.const 1)
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type50
       (struct.get $type63 1
        (struct.get $environment85 1
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (i64.add
        (local.get $5)
        (i64.const 1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type91 0
         (struct.get $environment85 3
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $function85
        (struct.get $type90 0
         (struct.get $type91 1
          (struct.get $environment85 3
           (local.get $0)
          )
         )
        )
        (i64.add
         (local.get $1)
         (i64.const 1)
        )
        (local.get $2)
        (local.get $3)
       )
      )
      (if
       (i64.ne
        (local.get $2)
        (i64.const 2)
       )
       (then
        (if
         (i32.eqz
          (struct.get $type69 0
           (struct.get $environment85 7
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type17
         (struct.get $type69 1
          (struct.get $environment85 7
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
         (i32.const 1)
        )
        (array.set $type14
         (struct.get $type62 1
          (struct.get $environment85 6
           (local.get $0)
          )
         )
         (block (result i32)
          (if
           (i64.gt_u
            (local.tee $4
             (struct.get $environment85 0
              (local.get $0)
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i64.gt_u
            (local.get $4)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.tee $6
           (i32.wrap_i64
            (local.get $4)
           )
          )
         )
         (struct.new $type13
          (local.get $1)
          (array.get $type14
           (struct.get $type62 1
            (struct.get $environment85 6
             (local.get $0)
            )
           )
           (local.get $6)
          )
         )
        )
        (if
         (i32.eqz
          (struct.get $type91 0
           (struct.get $environment85 3
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (local.set $3
         (call $function85
          (struct.get $type90 0
           (struct.get $type91 1
            (struct.get $environment85 3
             (local.get $0)
            )
           )
          )
          (i64.add
           (local.get $1)
           (i64.const 1)
          )
          (i64.add
           (local.get $2)
           (i64.const 1)
          )
          (local.get $3)
         )
        )
        (array.set $type14
         (struct.get $type62 1
          (struct.get $environment85 6
           (local.get $0)
          )
         )
         (block (result i32)
          (if
           (i64.gt_u
            (local.tee $4
             (struct.get $environment85 0
              (local.get $0)
             )
            )
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (local.set $8
           (struct.get $type13 1
            (array.get $type14
             (struct.get $type62 1
              (struct.get $environment85 6
               (local.get $0)
              )
             )
             (i32.wrap_i64
              (local.get $4)
             )
            )
           )
          )
          (if
           (i64.gt_u
            (local.get $4)
            (i64.const 4294967295)
           )
           (then
            (unreachable)
           )
          )
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (local.get $8)
        )
        (if
         (i32.eqz
          (struct.get $type69 0
           (struct.get $environment85 7
            (local.get $0)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type17
         (struct.get $type69 1
          (struct.get $environment85 7
           (local.get $0)
          )
         )
         (i32.wrap_i64
          (local.get $1)
         )
         (i32.const 0)
        )
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type50
       (struct.get $type63 1
        (struct.get $environment85 1
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (local.get $5)
      )
      (if
       (i64.gt_u
        (local.tee $4
         (struct.get $environment85 0
          (local.get $0)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (local.get $9)
       (i32.wrap_i64
        (local.get $4)
       )
       (i32.const 0)
      )
      (array.set $type14
       (struct.get $type62 1
        (struct.get $environment85 6
         (local.get $0)
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $8
         (struct.get $type13 1
          (array.get $type14
           (struct.get $type62 1
            (struct.get $environment85 6
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (local.get $8)
      )
     )
    )
    (if
     (i64.ne
      (local.get $2)
      (i64.const 2)
     )
     (then
      (array.set $type14
       (struct.get $type62 1
        (struct.get $environment85 6
         (local.get $0)
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $4
           (struct.get $environment85 0
            (local.get $0)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.gt_u
          (local.get $4)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.tee $6
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (struct.new $type13
        (local.get $1)
        (array.get $type14
         (struct.get $type62 1
          (struct.get $environment85 6
           (local.get $0)
          )
         )
         (local.get $6)
        )
       )
      )
      (if
       (i32.eqz
        (struct.get $type69 0
         (struct.get $environment85 7
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (struct.get $type69 1
        (struct.get $environment85 7
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type91 0
         (struct.get $environment85 3
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (call $function85
        (struct.get $type90 0
         (struct.get $type91 1
          (struct.get $environment85 3
           (local.get $0)
          )
         )
        )
        (i64.add
         (local.get $1)
         (i64.const 1)
        )
        (i64.add
         (local.get $2)
         (i64.const 1)
        )
        (local.get $3)
       )
      )
      (if
       (i32.eqz
        (struct.get $type69 0
         (struct.get $environment85 7
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type17
       (struct.get $type69 1
        (struct.get $environment85 7
         (local.get $0)
        )
       )
       (i32.wrap_i64
        (local.get $1)
       )
       (i32.const 0)
      )
      (array.set $type14
       (struct.get $type62 1
        (struct.get $environment85 6
         (local.get $0)
        )
       )
       (block (result i32)
        (if
         (i64.gt_u
          (local.tee $1
           (struct.get $environment85 0
            (local.get $0)
           )
          )
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $8
         (struct.get $type13 1
          (array.get $type14
           (struct.get $type62 1
            (struct.get $environment85 6
             (local.get $0)
            )
           )
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
       (local.get $8)
      )
     )
    )
    (local.get $3)
   )
  )
 )
 (func $function86 (type $call56) (param $0 (ref null $environment52)) (param $1 (ref null $type13)) (param $2 (ref null $type13)) (result (ref null $type13))
  (local $3 (ref $environment88))
  (local $4 (ref null $type13))
  (local $5 (ref $type97))
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready265)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global265)
   )
  )
  (struct.set $type97 1
   (local.tee $5
    (struct.new_default $type97)
   )
   (struct.new $type96
    (struct.new $environment88
     (local.get $5)
    )
   )
  )
  (struct.set $type97 0
   (local.get $5)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type97 0
     (local.get $5)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type96 0
    (struct.get $type97 1
     (local.get $5)
    )
   )
  )
  (struct.new $type13
   (if (result i64)
    (ref.is_null
     (local.get $1)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $4
      (struct.get $type13 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (struct.get $type97 0
        (struct.get $environment88 0
         (local.get $3)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $3
      (struct.get $type96 0
       (struct.get $type97 1
        (struct.get $environment88 0
         (local.get $3)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $4)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $4
        (struct.get $type13 1
         (local.get $4)
        )
       )
       (if
        (i32.eqz
         (struct.get $type97 0
          (struct.get $environment88 0
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (struct.get $type96 0
         (struct.get $type97 1
          (struct.get $environment88 0
           (local.get $3)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $4)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $4
          (struct.get $type13 1
           (local.get $4)
          )
         )
         (if
          (i32.eqz
           (struct.get $type97 0
            (struct.get $environment88 0
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $3
          (struct.get $type96 0
           (struct.get $type97 1
            (struct.get $environment88 0
             (local.get $3)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $4)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $4
            (struct.get $type13 1
             (local.get $4)
            )
           )
           (if
            (i32.eqz
             (struct.get $type97 0
              (struct.get $environment88 0
               (local.get $3)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $3
            (struct.get $type96 0
             (struct.get $type97 1
              (struct.get $environment88 0
               (local.get $3)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $4)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $4
              (struct.get $type13 1
               (local.get $4)
              )
             )
             (if
              (i32.eqz
               (struct.get $type97 0
                (struct.get $environment88 0
                 (local.get $3)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $3
              (struct.get $type96 0
               (struct.get $type97 1
                (struct.get $environment88 0
                 (local.get $3)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $4)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $4
                (struct.get $type13 1
                 (local.get $4)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type97 0
                  (struct.get $environment88 0
                   (local.get $3)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $3
                (struct.get $type96 0
                 (struct.get $type97 1
                  (struct.get $environment88 0
                   (local.get $3)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $4
                  (struct.get $type13 1
                   (local.get $4)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type97 0
                    (struct.get $environment88 0
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $3
                  (struct.get $type96 0
                   (struct.get $type97 1
                    (struct.get $environment88 0
                     (local.get $3)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $4
                    (struct.get $type13 1
                     (local.get $4)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type97 0
                      (struct.get $environment88 0
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $3
                    (struct.get $type96 0
                     (struct.get $type97 1
                      (struct.get $environment88 0
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $4
                      (struct.get $type13 1
                       (local.get $4)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type97 0
                        (struct.get $environment88 0
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function88
                      (struct.get $type96 0
                       (struct.get $type97 1
                        (struct.get $environment88 0
                         (local.get $3)
                        )
                       )
                      )
                      (local.get $4)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (block (result (ref null $type13))
    (if
     (i32.eqz
      (global.get $ready270)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type56 1
      (global.get $global270)
     )
    )
    (if (result (ref null $type13))
     (ref.is_null
      (local.get $1)
     )
     (then
      (local.get $2)
     )
     (else
      (struct.new $type13
       (struct.get $type13 0
        (local.get $1)
       )
       (block (result (ref null $type13))
        (local.set $1
         (struct.get $type13 1
          (local.get $1)
         )
        )
        (if
         (i32.eqz
          (global.get $ready270)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (struct.get $type56 1
          (global.get $global270)
         )
        )
        (if (result (ref null $type13))
         (ref.is_null
          (local.get $1)
         )
         (then
          (local.get $2)
         )
         (else
          (struct.new $type13
           (struct.get $type13 0
            (local.get $1)
           )
           (block (result (ref null $type13))
            (local.set $1
             (struct.get $type13 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (global.get $ready270)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (struct.get $type56 1
              (global.get $global270)
             )
            )
            (if (result (ref null $type13))
             (ref.is_null
              (local.get $1)
             )
             (then
              (local.get $2)
             )
             (else
              (struct.new $type13
               (struct.get $type13 0
                (local.get $1)
               )
               (block (result (ref null $type13))
                (local.set $1
                 (struct.get $type13 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready270)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (struct.get $type56 1
                  (global.get $global270)
                 )
                )
                (if (result (ref null $type13))
                 (ref.is_null
                  (local.get $1)
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (struct.new $type13
                   (struct.get $type13 0
                    (local.get $1)
                   )
                   (block (result (ref null $type13))
                    (local.set $1
                     (struct.get $type13 1
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready270)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (struct.get $type56 1
                      (global.get $global270)
                     )
                    )
                    (if (result (ref null $type13))
                     (ref.is_null
                      (local.get $1)
                     )
                     (then
                      (local.get $2)
                     )
                     (else
                      (struct.new $type13
                       (struct.get $type13 0
                        (local.get $1)
                       )
                       (block (result (ref null $type13))
                        (local.set $1
                         (struct.get $type13 1
                          (local.get $1)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready270)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (struct.get $type56 1
                          (global.get $global270)
                         )
                        )
                        (if (result (ref null $type13))
                         (ref.is_null
                          (local.get $1)
                         )
                         (then
                          (local.get $2)
                         )
                         (else
                          (struct.new $type13
                           (struct.get $type13 0
                            (local.get $1)
                           )
                           (block (result (ref null $type13))
                            (local.set $1
                             (struct.get $type13 1
                              (local.get $1)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready270)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (struct.get $type56 1
                              (global.get $global270)
                             )
                            )
                            (if (result (ref null $type13))
                             (ref.is_null
                              (local.get $1)
                             )
                             (then
                              (local.get $2)
                             )
                             (else
                              (struct.new $type13
                               (struct.get $type13 0
                                (local.get $1)
                               )
                               (block (result (ref null $type13))
                                (local.set $1
                                 (struct.get $type13 1
                                  (local.get $1)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready270)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (struct.get $type56 1
                                  (global.get $global270)
                                 )
                                )
                                (if (result (ref null $type13))
                                 (ref.is_null
                                  (local.get $1)
                                 )
                                 (then
                                  (local.get $2)
                                 )
                                 (else
                                  (struct.new $type13
                                   (struct.get $type13 0
                                    (local.get $1)
                                   )
                                   (block (result (ref null $type13))
                                    (local.set $1
                                     (struct.get $type13 1
                                      (local.get $1)
                                     )
                                    )
                                    (if
                                     (i32.eqz
                                      (global.get $ready270)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (struct.get $type56 1
                                      (global.get $global270)
                                     )
                                    )
                                    (if (result (ref null $type13))
                                     (ref.is_null
                                      (local.get $1)
                                     )
                                     (then
                                      (local.get $2)
                                     )
                                     (else
                                      (struct.new $type13
                                       (struct.get $type13 0
                                        (local.get $1)
                                       )
                                       (block (result (ref null $type13))
                                        (local.set $1
                                         (struct.get $type13 1
                                          (local.get $1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready270)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (struct.get $type56 1
                                          (global.get $global270)
                                         )
                                        )
                                        (if (result (ref null $type13))
                                         (ref.is_null
                                          (local.get $1)
                                         )
                                         (then
                                          (local.get $2)
                                         )
                                         (else
                                          (struct.new $type13
                                           (struct.get $type13 0
                                            (local.get $1)
                                           )
                                           (block (result (ref null $type13))
                                            (local.set $1
                                             (struct.get $type13 1
                                              (local.get $1)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready270)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (call $function89
                                             (struct.get $type56 1
                                              (global.get $global270)
                                             )
                                             (local.get $1)
                                             (local.get $2)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function88 (type $call96) (param $0 (ref $environment88)) (param $1 (ref null $type13)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type13 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type97 0
       (struct.get $environment88 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function88
     (struct.get $type96 0
      (struct.get $type97 1
       (struct.get $environment88 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function89 (type $call56) (param $0 (ref null $environment52)) (param $1 (ref null $type13)) (param $2 (ref null $type13)) (result (ref null $type13))
  (local $3 i64)
  (if (result (ref null $type13))
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (struct.new $type13
     (struct.get $type13 0
      (local.get $1)
     )
     (block (result (ref null $type13))
      (local.set $1
       (struct.get $type13 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready270)
       )
       (then
        (unreachable)
       )
      )
      (call $function89
       (struct.get $type56 1
        (global.get $global270)
       )
       (local.get $1)
       (local.get $2)
      )
     )
    )
   )
  )
 )
 (func $function94 (type $call58) (param $0 (ref $type14)) (param $1 (ref null $type13)) (result (ref null $type13))
  (local $2 (ref $type61))
  (local $3 (ref $type33))
  (struct.set $type61 1
   (local.tee $2
    (struct.new_default $type61)
   )
   (struct.new $type33
    (ref.func $function95)
    (struct.new $environment95
     (local.get $0)
     (local.get $2)
    )
   )
  )
  (struct.set $type61 0
   (local.get $2)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type61 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (return_call_ref $call33
   (struct.get $type33 1
    (local.tee $3
     (ref.as_non_null
      (struct.get $type61 1
       (local.get $2)
      )
     )
    )
   )
   (i64.sub
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (i64.const 1)
   )
   (local.get $1)
   (struct.get $type33 0
    (local.get $3)
   )
  )
 )
 (func $function95 (type $call33) (param $0 structref) (param $1 i64) (param $2 (ref null $type13)) (result (ref null $type13))
  (local $3 (ref null $type13))
  (if (result (ref $type13))
   (i64.lt_s
    (local.get $1)
    (i64.const 0)
   )
   (then
    (struct.new $type13
     (i64.extend_i32_u
      (array.len
       (struct.get $environment95 0
        (ref.cast (ref $environment95)
         (local.get $0)
        )
       )
      )
     )
     (local.get $2)
    )
   )
   (else
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (array.get $type14
      (struct.get $environment95 0
       (ref.cast (ref $environment95)
        (local.get $0)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready262)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (call $function86
      (struct.get $type56 1
       (global.get $global262)
      )
      (local.get $3)
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (struct.get $type61 0
       (struct.get $environment95 1
        (ref.cast (ref $environment95)
         (local.get $0)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function95
     (struct.get $type33 1
      (struct.get $type61 1
       (struct.get $environment95 1
        (ref.cast (ref $environment95)
         (local.get $0)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
  )
 )
 (func $function96 (type $8) (param $0 (ref null $type25)) (result (ref $type13))
  (local $1 (ref $type61))
  (local $2 (ref null $environment97))
  (local $3 (ref $environment99))
  (local $4 (ref null $type25))
  (local $5 (ref null $type13))
  (local $6 (ref $type33))
  (local $7 (ref $type100))
  (local $8 (ref $type102))
  (local $9 (ref $type14))
  (local $10 (ref $type14))
  (local $11 (ref $type14))
  (local $12 (ref $type14))
  (local $13 (ref $type14))
  (local $14 (ref $type14))
  (local $15 (ref $type14))
  (local $16 (ref $type14))
  (local $17 (ref $type14))
  (local $18 (ref $type14))
  (local $19 i64)
  (local $scratch (ref null $type13))
  (struct.set $type100 1
   (local.tee $7
    (struct.new_default $type100)
   )
   (struct.new $type59
    (struct.new $environment97
     (local.get $7)
    )
   )
  )
  (struct.set $type100 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready293)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global293)
   )
  )
  (struct.set $type102 1
   (local.tee $8
    (struct.new_default $type102)
   )
   (struct.new $type101
    (struct.new $environment99
     (local.get $8)
    )
   )
  )
  (struct.set $type102 0
   (local.get $8)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type102 0
     (local.get $8)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type101 0
    (struct.get $type102 1
     (local.get $8)
    )
   )
  )
  (struct.new $type13
   (if (result i64)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $4
      (struct.get $type25 1
       (local.get $0)
      )
     )
     (if
      (i32.eqz
       (struct.get $type102 0
        (struct.get $environment99 0
         (local.get $3)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $3
      (struct.get $type101 0
       (struct.get $type102 1
        (struct.get $environment99 0
         (local.get $3)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $4)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $4
        (struct.get $type25 1
         (local.get $4)
        )
       )
       (if
        (i32.eqz
         (struct.get $type102 0
          (struct.get $environment99 0
           (local.get $3)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $3
        (struct.get $type101 0
         (struct.get $type102 1
          (struct.get $environment99 0
           (local.get $3)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $4)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $4
          (struct.get $type25 1
           (local.get $4)
          )
         )
         (if
          (i32.eqz
           (struct.get $type102 0
            (struct.get $environment99 0
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $3
          (struct.get $type101 0
           (struct.get $type102 1
            (struct.get $environment99 0
             (local.get $3)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $4)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $4
            (struct.get $type25 1
             (local.get $4)
            )
           )
           (if
            (i32.eqz
             (struct.get $type102 0
              (struct.get $environment99 0
               (local.get $3)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $3
            (struct.get $type101 0
             (struct.get $type102 1
              (struct.get $environment99 0
               (local.get $3)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $4)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $4
              (struct.get $type25 1
               (local.get $4)
              )
             )
             (if
              (i32.eqz
               (struct.get $type102 0
                (struct.get $environment99 0
                 (local.get $3)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $3
              (struct.get $type101 0
               (struct.get $type102 1
                (struct.get $environment99 0
                 (local.get $3)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $4)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $4
                (struct.get $type25 1
                 (local.get $4)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type102 0
                  (struct.get $environment99 0
                   (local.get $3)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $3
                (struct.get $type101 0
                 (struct.get $type102 1
                  (struct.get $environment99 0
                   (local.get $3)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $4
                  (struct.get $type25 1
                   (local.get $4)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type102 0
                    (struct.get $environment99 0
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $3
                  (struct.get $type101 0
                   (struct.get $type102 1
                    (struct.get $environment99 0
                     (local.get $3)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $4
                    (struct.get $type25 1
                     (local.get $4)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type102 0
                      (struct.get $environment99 0
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $3
                    (struct.get $type101 0
                     (struct.get $type102 1
                      (struct.get $environment99 0
                       (local.get $3)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $4)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $4
                      (struct.get $type25 1
                       (local.get $4)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type102 0
                        (struct.get $environment99 0
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function99
                      (struct.get $type101 0
                       (struct.get $type102 1
                        (struct.get $environment99 0
                         (local.get $3)
                        )
                       )
                      )
                      (local.get $4)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (block (result (ref null $type13))
    (if
     (i32.eqz
      (struct.get $type100 0
       (local.get $7)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type59 0
      (struct.get $type100 1
       (local.get $7)
      )
     )
    )
    (if (result (ref null $type13))
     (ref.is_null
      (local.get $0)
     )
     (then
      (ref.null none)
     )
     (else
      (local.set $9
       (struct.get $type25 0
        (local.get $0)
       )
      )
      (local.set $0
       (struct.get $type25 1
        (local.get $0)
       )
      )
      (if
       (i32.eqz
        (struct.get $type100 0
         (struct.get $environment97 0
          (local.get $2)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $2
       (struct.get $type59 0
        (struct.get $type100 1
         (struct.get $environment97 0
          (local.get $2)
         )
        )
       )
      )
      (local.set $5
       (if (result (ref null $type13))
        (ref.is_null
         (local.get $0)
        )
        (then
         (ref.null none)
        )
        (else
         (local.set $10
          (struct.get $type25 0
           (local.get $0)
          )
         )
         (local.set $0
          (struct.get $type25 1
           (local.get $0)
          )
         )
         (if
          (i32.eqz
           (struct.get $type100 0
            (struct.get $environment97 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $2
          (struct.get $type59 0
           (struct.get $type100 1
            (struct.get $environment97 0
             (local.get $2)
            )
           )
          )
         )
         (local.set $5
          (if (result (ref null $type13))
           (ref.is_null
            (local.get $0)
           )
           (then
            (ref.null none)
           )
           (else
            (local.set $11
             (struct.get $type25 0
              (local.get $0)
             )
            )
            (local.set $0
             (struct.get $type25 1
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (struct.get $type100 0
               (struct.get $environment97 0
                (local.get $2)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $2
             (struct.get $type59 0
              (struct.get $type100 1
               (struct.get $environment97 0
                (local.get $2)
               )
              )
             )
            )
            (local.set $5
             (if (result (ref null $type13))
              (ref.is_null
               (local.get $0)
              )
              (then
               (ref.null none)
              )
              (else
               (local.set $12
                (struct.get $type25 0
                 (local.get $0)
                )
               )
               (local.set $0
                (struct.get $type25 1
                 (local.get $0)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type100 0
                  (struct.get $environment97 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $2
                (struct.get $type59 0
                 (struct.get $type100 1
                  (struct.get $environment97 0
                   (local.get $2)
                  )
                 )
                )
               )
               (local.set $5
                (if (result (ref null $type13))
                 (ref.is_null
                  (local.get $0)
                 )
                 (then
                  (ref.null none)
                 )
                 (else
                  (local.set $13
                   (struct.get $type25 0
                    (local.get $0)
                   )
                  )
                  (local.set $0
                   (struct.get $type25 1
                    (local.get $0)
                   )
                  )
                  (if
                   (i32.eqz
                    (struct.get $type100 0
                     (struct.get $environment97 0
                      (local.get $2)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $2
                   (struct.get $type59 0
                    (struct.get $type100 1
                     (struct.get $environment97 0
                      (local.get $2)
                     )
                    )
                   )
                  )
                  (local.set $5
                   (if (result (ref null $type13))
                    (ref.is_null
                     (local.get $0)
                    )
                    (then
                     (ref.null none)
                    )
                    (else
                     (local.set $14
                      (struct.get $type25 0
                       (local.get $0)
                      )
                     )
                     (local.set $0
                      (struct.get $type25 1
                       (local.get $0)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type100 0
                        (struct.get $environment97 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $2
                      (struct.get $type59 0
                       (struct.get $type100 1
                        (struct.get $environment97 0
                         (local.get $2)
                        )
                       )
                      )
                     )
                     (local.set $5
                      (if (result (ref null $type13))
                       (ref.is_null
                        (local.get $0)
                       )
                       (then
                        (ref.null none)
                       )
                       (else
                        (local.set $15
                         (struct.get $type25 0
                          (local.get $0)
                         )
                        )
                        (local.set $0
                         (struct.get $type25 1
                          (local.get $0)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type100 0
                           (struct.get $environment97 0
                            (local.get $2)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $2
                         (struct.get $type59 0
                          (struct.get $type100 1
                           (struct.get $environment97 0
                            (local.get $2)
                           )
                          )
                         )
                        )
                        (local.set $5
                         (if (result (ref null $type13))
                          (ref.is_null
                           (local.get $0)
                          )
                          (then
                           (ref.null none)
                          )
                          (else
                           (local.set $16
                            (struct.get $type25 0
                             (local.get $0)
                            )
                           )
                           (local.set $0
                            (struct.get $type25 1
                             (local.get $0)
                            )
                           )
                           (if
                            (i32.eqz
                             (struct.get $type100 0
                              (struct.get $environment97 0
                               (local.get $2)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (local.set $2
                            (struct.get $type59 0
                             (struct.get $type100 1
                              (struct.get $environment97 0
                               (local.get $2)
                              )
                             )
                            )
                           )
                           (local.set $5
                            (if (result (ref null $type13))
                             (ref.is_null
                              (local.get $0)
                             )
                             (then
                              (ref.null none)
                             )
                             (else
                              (local.set $17
                               (struct.get $type25 0
                                (local.get $0)
                               )
                              )
                              (local.set $0
                               (struct.get $type25 1
                                (local.get $0)
                               )
                              )
                              (if
                               (i32.eqz
                                (struct.get $type100 0
                                 (struct.get $environment97 0
                                  (local.get $2)
                                 )
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (local.set $2
                               (struct.get $type59 0
                                (struct.get $type100 1
                                 (struct.get $environment97 0
                                  (local.get $2)
                                 )
                                )
                               )
                              )
                              (local.set $5
                               (if (result (ref null $type13))
                                (ref.is_null
                                 (local.get $0)
                                )
                                (then
                                 (ref.null none)
                                )
                                (else
                                 (call $function94
                                  (struct.get $type25 0
                                   (local.get $0)
                                  )
                                  (block (result (ref null $type13))
                                   (local.set $0
                                    (struct.get $type25 1
                                     (local.get $0)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (struct.get $type100 0
                                      (struct.get $environment97 0
                                       (local.get $2)
                                      )
                                     )
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (local.set $scratch
                                    (call $function97
                                     (struct.get $type59 0
                                      (struct.get $type100 1
                                       (struct.get $environment97 0
                                        (local.get $2)
                                       )
                                      )
                                     )
                                     (local.get $0)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready283)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global283)
                                    )
                                   )
                                   (local.get $scratch)
                                  )
                                 )
                                )
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready283)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global283)
                               )
                              )
                              (struct.set $type61 1
                               (local.tee $1
                                (struct.new_default $type61)
                               )
                               (struct.new $type33
                                (ref.func $function95)
                                (struct.new $environment95
                                 (local.get $17)
                                 (local.get $1)
                                )
                               )
                              )
                              (struct.set $type61 0
                               (local.get $1)
                               (i32.const 1)
                              )
                              (if
                               (i32.eqz
                                (struct.get $type61 0
                                 (local.get $1)
                                )
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call_ref $call33
                               (struct.get $type33 1
                                (local.tee $6
                                 (ref.as_non_null
                                  (struct.get $type61 1
                                   (local.get $1)
                                  )
                                 )
                                )
                               )
                               (i64.sub
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $17)
                                 )
                                )
                                (i64.const 1)
                               )
                               (local.get $5)
                               (struct.get $type33 0
                                (local.get $6)
                               )
                              )
                             )
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready283)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global283)
                            )
                           )
                           (struct.set $type61 1
                            (local.tee $1
                             (struct.new_default $type61)
                            )
                            (struct.new $type33
                             (ref.func $function95)
                             (struct.new $environment95
                              (local.get $16)
                              (local.get $1)
                             )
                            )
                           )
                           (struct.set $type61 0
                            (local.get $1)
                            (i32.const 1)
                           )
                           (if
                            (i32.eqz
                             (struct.get $type61 0
                              (local.get $1)
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (call_ref $call33
                            (struct.get $type33 1
                             (local.tee $6
                              (ref.as_non_null
                               (struct.get $type61 1
                                (local.get $1)
                               )
                              )
                             )
                            )
                            (i64.sub
                             (i64.extend_i32_u
                              (array.len
                               (local.get $16)
                              )
                             )
                             (i64.const 1)
                            )
                            (local.get $5)
                            (struct.get $type33 0
                             (local.get $6)
                            )
                           )
                          )
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready283)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global283)
                         )
                        )
                        (struct.set $type61 1
                         (local.tee $1
                          (struct.new_default $type61)
                         )
                         (struct.new $type33
                          (ref.func $function95)
                          (struct.new $environment95
                           (local.get $15)
                           (local.get $1)
                          )
                         )
                        )
                        (struct.set $type61 0
                         (local.get $1)
                         (i32.const 1)
                        )
                        (if
                         (i32.eqz
                          (struct.get $type61 0
                           (local.get $1)
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call_ref $call33
                         (struct.get $type33 1
                          (local.tee $6
                           (ref.as_non_null
                            (struct.get $type61 1
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (i64.sub
                          (i64.extend_i32_u
                           (array.len
                            (local.get $15)
                           )
                          )
                          (i64.const 1)
                         )
                         (local.get $5)
                         (struct.get $type33 0
                          (local.get $6)
                         )
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready283)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global283)
                      )
                     )
                     (struct.set $type61 1
                      (local.tee $1
                       (struct.new_default $type61)
                      )
                      (struct.new $type33
                       (ref.func $function95)
                       (struct.new $environment95
                        (local.get $14)
                        (local.get $1)
                       )
                      )
                     )
                     (struct.set $type61 0
                      (local.get $1)
                      (i32.const 1)
                     )
                     (if
                      (i32.eqz
                       (struct.get $type61 0
                        (local.get $1)
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call_ref $call33
                      (struct.get $type33 1
                       (local.tee $6
                        (ref.as_non_null
                         (struct.get $type61 1
                          (local.get $1)
                         )
                        )
                       )
                      )
                      (i64.sub
                       (i64.extend_i32_u
                        (array.len
                         (local.get $14)
                        )
                       )
                       (i64.const 1)
                      )
                      (local.get $5)
                      (struct.get $type33 0
                       (local.get $6)
                      )
                     )
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready283)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global283)
                   )
                  )
                  (struct.set $type61 1
                   (local.tee $1
                    (struct.new_default $type61)
                   )
                   (struct.new $type33
                    (ref.func $function95)
                    (struct.new $environment95
                     (local.get $13)
                     (local.get $1)
                    )
                   )
                  )
                  (struct.set $type61 0
                   (local.get $1)
                   (i32.const 1)
                  )
                  (if
                   (i32.eqz
                    (struct.get $type61 0
                     (local.get $1)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call_ref $call33
                   (struct.get $type33 1
                    (local.tee $6
                     (ref.as_non_null
                      (struct.get $type61 1
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (i64.sub
                    (i64.extend_i32_u
                     (array.len
                      (local.get $13)
                     )
                    )
                    (i64.const 1)
                   )
                   (local.get $5)
                   (struct.get $type33 0
                    (local.get $6)
                   )
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready283)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global283)
                )
               )
               (struct.set $type61 1
                (local.tee $1
                 (struct.new_default $type61)
                )
                (struct.new $type33
                 (ref.func $function95)
                 (struct.new $environment95
                  (local.get $12)
                  (local.get $1)
                 )
                )
               )
               (struct.set $type61 0
                (local.get $1)
                (i32.const 1)
               )
               (if
                (i32.eqz
                 (struct.get $type61 0
                  (local.get $1)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (call_ref $call33
                (struct.get $type33 1
                 (local.tee $6
                  (ref.as_non_null
                   (struct.get $type61 1
                    (local.get $1)
                   )
                  )
                 )
                )
                (i64.sub
                 (i64.extend_i32_u
                  (array.len
                   (local.get $12)
                  )
                 )
                 (i64.const 1)
                )
                (local.get $5)
                (struct.get $type33 0
                 (local.get $6)
                )
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready283)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global283)
             )
            )
            (struct.set $type61 1
             (local.tee $1
              (struct.new_default $type61)
             )
             (struct.new $type33
              (ref.func $function95)
              (struct.new $environment95
               (local.get $11)
               (local.get $1)
              )
             )
            )
            (struct.set $type61 0
             (local.get $1)
             (i32.const 1)
            )
            (if
             (i32.eqz
              (struct.get $type61 0
               (local.get $1)
              )
             )
             (then
              (unreachable)
             )
            )
            (call_ref $call33
             (struct.get $type33 1
              (local.tee $6
               (ref.as_non_null
                (struct.get $type61 1
                 (local.get $1)
                )
               )
              )
             )
             (i64.sub
              (i64.extend_i32_u
               (array.len
                (local.get $11)
               )
              )
              (i64.const 1)
             )
             (local.get $5)
             (struct.get $type33 0
              (local.get $6)
             )
            )
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready283)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global283)
          )
         )
         (struct.set $type61 1
          (local.tee $1
           (struct.new_default $type61)
          )
          (struct.new $type33
           (ref.func $function95)
           (struct.new $environment95
            (local.get $10)
            (local.get $1)
           )
          )
         )
         (struct.set $type61 0
          (local.get $1)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type61 0
            (local.get $1)
           )
          )
          (then
           (unreachable)
          )
         )
         (call_ref $call33
          (struct.get $type33 1
           (local.tee $6
            (ref.as_non_null
             (struct.get $type61 1
              (local.get $1)
             )
            )
           )
          )
          (i64.sub
           (i64.extend_i32_u
            (array.len
             (local.get $10)
            )
           )
           (i64.const 1)
          )
          (local.get $5)
          (struct.get $type33 0
           (local.get $6)
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready283)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global283)
       )
      )
      (struct.set $type61 1
       (local.tee $1
        (struct.new_default $type61)
       )
       (struct.new $type33
        (ref.func $function95)
        (struct.new $environment95
         (local.get $9)
         (local.get $1)
        )
       )
      )
      (struct.set $type61 0
       (local.get $1)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type61 0
         (local.get $1)
        )
       )
       (then
        (unreachable)
       )
      )
      (call_ref $call33
       (struct.get $type33 1
        (local.tee $6
         (ref.as_non_null
          (struct.get $type61 1
           (local.get $1)
          )
         )
        )
       )
       (i64.sub
        (i64.extend_i32_u
         (array.len
          (local.get $9)
         )
        )
        (i64.const 1)
       )
       (local.get $5)
       (struct.get $type33 0
        (local.get $6)
       )
      )
     )
    )
   )
  )
 )
 (func $function97 (type $call59) (param $0 (ref null $environment97)) (param $1 (ref null $type25)) (result (ref null $type13))
  (local $2 (ref $type14))
  (local $3 (ref null $type13))
  (local $scratch (ref null $type13))
  (if (result nullref)
   (ref.is_null
    (local.get $1)
   )
   (then
    (ref.null none)
   )
   (else
    (return_call $function94
     (struct.get $type25 0
      (local.get $1)
     )
     (block (result (ref null $type13))
      (local.set $1
       (struct.get $type25 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (struct.get $type100 0
         (struct.get $environment97 0
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $scratch
       (call $function97
        (struct.get $type59 0
         (struct.get $type100 1
          (struct.get $environment97 0
           (local.get $0)
          )
         )
        )
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready283)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global283)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function99 (type $call101) (param $0 (ref $environment99)) (param $1 (ref null $type25)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type25 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type102 0
       (struct.get $environment99 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function99
     (struct.get $type101 0
      (struct.get $type102 1
       (struct.get $environment99 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function100 (type $call60) (param $0 (ref null $environment43)) (param $1 i64) (result i64)
  (local $2 (ref null $type13))
  (local $3 (ref null $type13))
  (local $4 (ref $type79))
  (local $5 (ref $type75))
  (local $6 (ref $type89))
  (local $7 (ref $type61))
  (local $8 (ref $type13))
  (local $9 (ref $type35))
  (local $10 (ref $type62))
  (local $11 (ref $type84))
  (local $12 (ref null $type25))
  (local $13 (ref $type33))
  (local $14 i64)
  (local $15 i32)
  (local $scratch (ref null $type25))
  (local $scratch_17 (ref null $type13))
  (if
   (i32.eqz
    (global.get $ready298)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready195)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global195)
   )
  )
  (if
   (i32.eqz
    (global.get $ready197)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global197)
   )
  )
  (if
   (i32.eqz
    (global.get $ready166)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global166)
   )
  )
  (local.set $4
   (struct.new $type79
    (i32.const 1)
    (call $function57
     (local.tee $1
      (global.get $global298)
     )
     (struct.new $type37
      (ref.func $function71)
      (struct.new $environment71
       (local.get $1)
      )
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (struct.get $type75 0
     (local.tee $5
      (struct.new $type75
       (i32.const 1)
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready71)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global71)
   )
  )
  (if
   (i32.eqz
    (global.get $ready74)
   )
   (then
    (unreachable)
   )
  )
  (local.set $9
   (ref.as_non_null
    (global.get $global74)
   )
  )
  (if
   (i32.eqz
    (global.get $ready82)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global82)
   )
  )
  (local.set $10
   (struct.new $type62
    (i32.const 1)
    (call $function33
     (i64.add
      (local.tee $14
       (struct.get $type75 1
        (local.get $5)
       )
      )
      (i64.const 1)
     )
     (local.get $9)
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $14)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type89 1
   (local.tee $6
    (struct.new_default $type89)
   )
   (struct.new $type88
    (struct.new $environment76
     (struct.new $type85
      (i32.const 1)
      (struct.new $type28
       (ref.func $function72)
       (struct.new $environment72
        (local.tee $11
         (struct.new $type84
          (i32.const 1)
          (struct.new $type48
           (struct.new $environment40
            (local.get $10)
            (struct.new $type63
             (i32.const 1)
             (array.new_default $type50
              (i32.wrap_i64
               (local.get $14)
              )
             )
            )
           )
          )
         )
        )
        (local.get $4)
        (struct.new $type86
         (i32.const 1)
         (struct.new $type49
          (ref.func $function73)
          (ref.null none)
         )
        )
       )
      )
     )
     (local.get $5)
     (struct.new $type62
      (i32.const 1)
      (array.new_default $type14
       (local.tee $15
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
     (local.get $4)
     (i64.const 2)
     (struct.new $type87
      (i32.const 1)
      (struct.new $type8
       (ref.func $function74)
       (struct.new $environment74
        (local.get $11)
        (local.get $5)
        (local.get $4)
        (struct.new $type86
         (i32.const 1)
         (struct.new $type49
          (ref.func $function75)
          (struct.new $environment75
           (local.get $4)
           (local.get $5)
          )
         )
        )
       )
      )
     )
     (struct.new_default $type53)
     (local.get $1)
     (struct.new $type63
      (i32.const 1)
      (array.new_default $type50
       (local.get $15)
      )
     )
     (local.get $6)
    )
   )
  )
  (struct.set $type89 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type89 0
     (local.get $6)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $8
   (call $function96
    (block (result (ref null $type25))
     (local.set $scratch
      (call $function76
       (struct.get $type88 0
        (struct.get $type89 1
         (local.get $6)
        )
       )
       (i64.const 0)
       (ref.null none)
      )
     )
     (if
      (i32.eqz
       (global.get $ready289)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (struct.get $type59 0
       (global.get $global289)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $1
   (call $foreign0)
  )
  (struct.set $type61 1
   (local.tee $7
    (struct.new_default $type61)
   )
   (struct.new $type33
    (ref.func $function26)
    (struct.new $environment26
     (local.get $7)
    )
   )
  )
  (struct.set $type61 0
   (local.get $7)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type61 0
     (local.get $7)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $2
   (call_ref $call33
    (struct.get $type33 1
     (local.tee $13
      (ref.as_non_null
       (struct.get $type61 1
        (local.get $7)
       )
      )
     )
    )
    (local.get $1)
    (ref.null none)
    (struct.get $type33 0
     (local.get $13)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready65)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global65)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (ref.is_null
      (local.get $2)
     )
     (then
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i64.eq
        (struct.get $type13 0
         (local.get $8)
        )
        (struct.get $type13 0
         (local.get $2)
        )
       )
       (then
        (local.set $2
         (struct.get $type13 1
          (local.get $2)
         )
        )
        (if
         (i32.eqz
          (global.get $ready65)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global65)
         )
        )
        (if (result i32)
         (ref.is_null
          (local.tee $3
           (struct.get $type13 1
            (local.get $8)
           )
          )
         )
         (then
          (ref.is_null
           (local.get $2)
          )
         )
         (else
          (if (result i32)
           (ref.is_null
            (local.get $2)
           )
           (then
            (i32.const 0)
           )
           (else
            (if (result i32)
             (i64.eq
              (struct.get $type13 0
               (local.get $3)
              )
              (struct.get $type13 0
               (local.get $2)
              )
             )
             (then
              (local.set $3
               (struct.get $type13 1
                (local.get $3)
               )
              )
              (local.set $2
               (struct.get $type13 1
                (local.get $2)
               )
              )
              (if
               (i32.eqz
                (global.get $ready65)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global65)
               )
              )
              (if (result i32)
               (ref.is_null
                (local.get $3)
               )
               (then
                (ref.is_null
                 (local.get $2)
                )
               )
               (else
                (if (result i32)
                 (ref.is_null
                  (local.get $2)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if (result i32)
                   (i64.eq
                    (struct.get $type13 0
                     (local.get $3)
                    )
                    (struct.get $type13 0
                     (local.get $2)
                    )
                   )
                   (then
                    (local.set $3
                     (struct.get $type13 1
                      (local.get $3)
                     )
                    )
                    (local.set $2
                     (struct.get $type13 1
                      (local.get $2)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready65)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global65)
                     )
                    )
                    (if (result i32)
                     (ref.is_null
                      (local.get $3)
                     )
                     (then
                      (ref.is_null
                       (local.get $2)
                      )
                     )
                     (else
                      (if (result i32)
                       (ref.is_null
                        (local.get $2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if (result i32)
                         (i64.eq
                          (struct.get $type13 0
                           (local.get $3)
                          )
                          (struct.get $type13 0
                           (local.get $2)
                          )
                         )
                         (then
                          (local.set $3
                           (struct.get $type13 1
                            (local.get $3)
                           )
                          )
                          (local.set $2
                           (struct.get $type13 1
                            (local.get $2)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready65)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global65)
                           )
                          )
                          (if (result i32)
                           (ref.is_null
                            (local.get $3)
                           )
                           (then
                            (ref.is_null
                             (local.get $2)
                            )
                           )
                           (else
                            (if (result i32)
                             (ref.is_null
                              (local.get $2)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if (result i32)
                               (i64.eq
                                (struct.get $type13 0
                                 (local.get $3)
                                )
                                (struct.get $type13 0
                                 (local.get $2)
                                )
                               )
                               (then
                                (local.set $3
                                 (struct.get $type13 1
                                  (local.get $3)
                                 )
                                )
                                (local.set $2
                                 (struct.get $type13 1
                                  (local.get $2)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready65)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global65)
                                 )
                                )
                                (if (result i32)
                                 (ref.is_null
                                  (local.get $3)
                                 )
                                 (then
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                 )
                                 (else
                                  (if (result i32)
                                   (ref.is_null
                                    (local.get $2)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if (result i32)
                                     (i64.eq
                                      (struct.get $type13 0
                                       (local.get $3)
                                      )
                                      (struct.get $type13 0
                                       (local.get $2)
                                      )
                                     )
                                     (then
                                      (local.set $3
                                       (struct.get $type13 1
                                        (local.get $3)
                                       )
                                      )
                                      (local.set $2
                                       (struct.get $type13 1
                                        (local.get $2)
                                       )
                                      )
                                      (if
                                       (i32.eqz
                                        (global.get $ready65)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global65)
                                       )
                                      )
                                      (if (result i32)
                                       (ref.is_null
                                        (local.get $3)
                                       )
                                       (then
                                        (ref.is_null
                                         (local.get $2)
                                        )
                                       )
                                       (else
                                        (if (result i32)
                                         (ref.is_null
                                          (local.get $2)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (if (result i32)
                                           (i64.eq
                                            (struct.get $type13 0
                                             (local.get $3)
                                            )
                                            (struct.get $type13 0
                                             (local.get $2)
                                            )
                                           )
                                           (then
                                            (local.set $3
                                             (struct.get $type13 1
                                              (local.get $3)
                                             )
                                            )
                                            (local.set $2
                                             (struct.get $type13 1
                                              (local.get $2)
                                             )
                                            )
                                            (if
                                             (i32.eqz
                                              (global.get $ready65)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global65)
                                             )
                                            )
                                            (if (result i32)
                                             (ref.is_null
                                              (local.get $3)
                                             )
                                             (then
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                             )
                                             (else
                                              (if (result i32)
                                               (ref.is_null
                                                (local.get $2)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (if (result i32)
                                                 (i64.eq
                                                  (struct.get $type13 0
                                                   (local.get $3)
                                                  )
                                                  (struct.get $type13 0
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (then
                                                  (local.set $3
                                                   (struct.get $type13 1
                                                    (local.get $3)
                                                   )
                                                  )
                                                  (local.set $2
                                                   (struct.get $type13 1
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (if
                                                   (i32.eqz
                                                    (global.get $ready65)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global65)
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (ref.is_null
                                                    (local.get $3)
                                                   )
                                                   (then
                                                    (ref.is_null
                                                     (local.get $2)
                                                    )
                                                   )
                                                   (else
                                                    (if (result i32)
                                                     (ref.is_null
                                                      (local.get $2)
                                                     )
                                                     (then
                                                      (i32.const 0)
                                                     )
                                                     (else
                                                      (if (result i32)
                                                       (i64.eq
                                                        (struct.get $type13 0
                                                         (local.get $3)
                                                        )
                                                        (struct.get $type13 0
                                                         (local.get $2)
                                                        )
                                                       )
                                                       (then
                                                        (local.set $3
                                                         (struct.get $type13 1
                                                          (local.get $3)
                                                         )
                                                        )
                                                        (local.set $2
                                                         (struct.get $type13 1
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (if
                                                         (i32.eqz
                                                          (global.get $ready65)
                                                         )
                                                         (then
                                                          (unreachable)
                                                         )
                                                        )
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global65)
                                                         )
                                                        )
                                                        (if (result i32)
                                                         (ref.is_null
                                                          (local.get $3)
                                                         )
                                                         (then
                                                          (ref.is_null
                                                           (local.get $2)
                                                          )
                                                         )
                                                         (else
                                                          (if (result i32)
                                                           (ref.is_null
                                                            (local.get $2)
                                                           )
                                                           (then
                                                            (i32.const 0)
                                                           )
                                                           (else
                                                            (if (result i32)
                                                             (i64.eq
                                                              (struct.get $type13 0
                                                               (local.get $3)
                                                              )
                                                              (struct.get $type13 0
                                                               (local.get $2)
                                                              )
                                                             )
                                                             (then
                                                              (call $function27
                                                               (struct.get $type13 1
                                                                (local.get $3)
                                                               )
                                                               (block (result (ref null $type13))
                                                                (local.set $scratch_17
                                                                 (struct.get $type13 1
                                                                  (local.get $2)
                                                                 )
                                                                )
                                                                (if
                                                                 (i32.eqz
                                                                  (global.get $ready65)
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (drop
                                                                 (ref.as_non_null
                                                                  (global.get $global65)
                                                                 )
                                                                )
                                                                (local.get $scratch_17)
                                                               )
                                                              )
                                                             )
                                                             (else
                                                              (i32.const 0)
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                       (else
                                                        (i32.const 0)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (i32.const 0)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (else
                                            (i32.const 0)
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (i32.const 0)
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (i32.const 0)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $primitive0 (type $call33) (param $0 structref) (param $1 i64) (param $2 (ref null $type13)) (result (ref null $type13))
  (struct.new $type13
   (local.get $1)
   (local.get $2)
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready301)
   )
   (then
    (unreachable)
   )
  )
  (return_call $function100
   (struct.get $type60 1
    (global.get $global301)
   )
   (local.get $0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global85
   (struct.new_default $type11)
  )
  (global.set $ready85
   (i32.const 1)
  )
  (global.set $global169
   (struct.new_default $type15)
  )
  (global.set $ready169
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type19)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global171
   (struct.new_default $type20)
  )
  (global.set $ready171
   (i32.const 1)
  )
  (global.set $global265
   (struct.new_default $type23)
  )
  (global.set $ready265
   (i32.const 1)
  )
  (global.set $global293
   (struct.new_default $type24)
  )
  (global.set $ready293
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type26)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global65
   (struct.new_default $type27)
  )
  (global.set $ready65
   (i32.const 1)
  )
  (global.set $global79
   (struct.new $type28
    (ref.func $function32)
    (ref.null none)
   )
  )
  (global.set $ready79
   (i32.const 1)
  )
  (global.set $global68
   (struct.new_default $type29)
  )
  (global.set $ready68
   (i32.const 1)
  )
  (global.set $global163
   (struct.new_default $type30)
  )
  (global.set $ready163
   (i32.const 1)
  )
  (global.set $global149
   (struct.new_default $type32)
  )
  (global.set $ready149
   (i32.const 1)
  )
  (global.set $global82
   (struct.new_default $type34)
  )
  (global.set $ready82
   (i32.const 1)
  )
  (global.set $global166
   (struct.new_default $type36)
  )
  (global.set $ready166
   (i32.const 1)
  )
  (global.set $global74
   (struct.new $type35
    (ref.func $function30)
    (ref.null none)
   )
  )
  (global.set $ready74
   (i32.const 1)
  )
  (global.set $global190
   (struct.new_default $type38)
  )
  (global.set $ready190
   (i32.const 1)
  )
  (global.set $global242
   (struct.new_default $type39)
  )
  (global.set $ready242
   (i32.const 1)
  )
  (global.set $global236
   (struct.new_default $type40)
  )
  (global.set $ready236
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type42)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global71
   (struct.new_default $type47)
  )
  (global.set $ready71
   (i32.const 1)
  )
  (global.set $global112
   (struct.new_default $type51)
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $global197
   (struct.new_default $type52)
  )
  (global.set $ready197
   (i32.const 1)
  )
  (global.set $global156
   (struct.new_default $type54)
  )
  (global.set $ready156
   (i32.const 1)
  )
  (global.set $global195
   (struct.new_default $type55)
  )
  (global.set $ready195
   (i32.const 1)
  )
  (global.set $global270
   (struct.new $type56
    (ref.func $function89)
    (ref.null none)
   )
  )
  (global.set $ready270
   (i32.const 1)
  )
  (global.set $global262
   (struct.new $type56
    (ref.func $function86)
    (ref.null none)
   )
  )
  (global.set $ready262
   (i32.const 1)
  )
  (global.set $global283
   (struct.new_default $type58)
  )
  (global.set $ready283
   (i32.const 1)
  )
  (global.set $global289
   (struct.new_default $type59)
  )
  (global.set $ready289
   (i32.const 1)
  )
  (global.set $global298
   (call $foreign2
    (i32.const 0)
   )
  )
  (global.set $ready298
   (i32.const 1)
  )
  (drop
   (call $foreign2
    (i32.const 1)
   )
  )
  (drop
   (call $foreign2
    (i32.const 2)
   )
  )
  (global.set $global301
   (struct.new $type60
    (ref.func $function100)
    (ref.null none)
   )
  )
  (global.set $ready301
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

