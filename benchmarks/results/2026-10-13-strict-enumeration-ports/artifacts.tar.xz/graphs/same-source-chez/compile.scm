(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-enumeration-preparation-20261013/graphs/same-source-chez/program.scm" "/tmp/snail-strict-enumeration-preparation-20261013/graphs/same-source-chez/program.so"))
