"""Rebuild this fixed, diagnostic-only identity observer; never a timed module."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
FEATURES = ['--mvp-features', '--enable-gc', '--enable-reference-types',
            '--enable-tail-call', '--enable-mutable-globals', '--enable-sign-ext',
            '--enable-bulk-memory', '--enable-nontrapping-float-to-int']
LAYOUTS = [
    '(type $type12 (array (mut (ref null $type13))))',
    '(type $type13 (struct (field (ref null $type14)) (field (ref null $type13))))',
    '(type $type14 (struct (field i64) (field (ref null $type14))))',
    '(type $type28 (struct (field (ref $type29)) (field (ref $type29)) (field (ref $type30)) (field (ref $type30))))',
    '(type $type29 (struct (field (mut (ref null $type13)))))',
    '(type $type30 (struct (field (mut (ref $type12)))))',
    '(global $global130 (mut (ref null $type28)) (ref.null $type28))',
]

source = (ROOT / 'strict.wasm.wat').read_text()
for layout in LAYOUTS:
    assert source.count(layout) == 1, layout
assert source.rstrip().endswith(')')
(ROOT / 'identity.wat').write_text(source.rstrip()[:-1] + '\n' + (ROOT / 'identity-getters.wat').read_text() + ')\n')
(ROOT / 'layouts.json').write_text(json.dumps(dict(
    producer_wat_sha256=hashlib.sha256(source.encode()).hexdigest(),
    witness_global='$global130', layouts=LAYOUTS,
    scope='Hand-written scalar Wasm observer appended before assembly/optimization; no compiler export ABI change.'), indent=2) + '\n')

commands = [
    [os.environ['WASM_AS'], '-g', *FEATURES, 'identity.wat', '-o', 'identity.raw.wasm'],
    [os.environ['WASM_OPT'], '-g', *FEATURES, '-O3', '--closed-world',
     '--always-inline-max-function-size=40', '--converge', 'identity.raw.wasm', '-o', 'identity.wasm'],
    [os.environ['WASM_DIS'], 'identity.wasm', '-o', 'identity.optimized.wat'],
    [os.environ['NODE'], 'check.mjs', 'identity.raw.wasm'],
    [os.environ['NODE'], 'check.mjs', 'identity.wasm'],
]
records = []
for command in commands:
    run = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    records.append(dict(command=command, returncode=run.returncode, stdout=run.stdout, stderr=run.stderr))
    (ROOT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    assert run.returncode == 0 and not run.stderr, records[-1]
print('Raw and optimized identity witness passed.')
