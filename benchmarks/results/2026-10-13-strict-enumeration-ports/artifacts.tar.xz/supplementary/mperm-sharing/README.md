# Shared tails, fresh generation and queue identity

This bounded witness checks identity in the frozen adapted mperm kernel. It is
separate from both canonical modules. `source-identity.json` verifies that the
kernel text matches the final canonical adaptation except for capturing the
queue/work/predicate at the diagnostic harness boundary.

`strict.scm` exports a normal scalar `sharing-prepare` function. Its Scheme code
checks that the work thunk returns the original queue and that the saved vector
snapshot is distinct. It creates two independent three-element permutation
graphs and snapshots a K=4, L=1 queue before and after one work step.

`identity-getters.wat` is a hand-written Wasm scalar observer appended to the
generated WAT. `build-witness.py` checks the exact producer layouts/global before
assembly and optimization. This is diagnostic code, **not implemented Scheme
GC-reference import/export support**. The observer returns a ten-bit mask:

1. The final two permutations share their unchanged tail after two cdr steps.
2. Independent generation produces distinct outer roots.
3. Independent generation produces distinct corresponding shared tails.
4. Old queue slot 1 is the new slot 0 by identity.
5. Old queue slot 2 is the new slot 1 by identity.
6. The new batch root differs from old slot 0.
7. The new batch root differs from old slot 1.
8. The new batch root differs from old slot 2.
9. The new final slot is null.
10. The old final slot is null.

`commands.json` retains assembly, optimization, disassembly and both Node checks.
Both raw and optimized modules return 1023; the two Scheme vector checks pass.
`chez-checks.json` records all 12 corresponding checks passing in original and
adapted Chez. Both also traverse the entire small object graph by identity and
count 2, 6, 21, 88, 445 and 2676 unique pairs for N=1 through 6.

These observations establish the listed small sharing relationships. The added
observer deliberately keeps its data visible, so canonical retention is audited
separately in `../../retention-audit.json`. This witness provides no allocation
timing, heap-volume, dynamic lifetime or general ABI evidence.
