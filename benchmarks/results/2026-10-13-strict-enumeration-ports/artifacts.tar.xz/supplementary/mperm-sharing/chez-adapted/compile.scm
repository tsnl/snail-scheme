(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-enumeration-preparation-20261013/supplementary/mperm-sharing/chez-adapted/program.scm" "/tmp/snail-strict-enumeration-preparation-20261013/supplementary/mperm-sharing/chez-adapted/program.so"))
