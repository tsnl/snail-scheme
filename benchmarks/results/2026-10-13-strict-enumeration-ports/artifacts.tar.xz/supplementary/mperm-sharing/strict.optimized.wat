(module
 (rec
  (type $type25 (struct (field (ref $environment45))))
  (type $type30 (struct (field (mut (ref $type12)))))
  (type $type24 (struct (field (ref $type12)) (field (ref $type25))))
  (type $call31 (func (param i64) (result i64)))
  (type $type10 (struct (field (ref $environment31))))
  (type $type39 (struct (field i32) (field (ref $type10))))
  (type $environment45 (struct (field (ref $type37)) (field i64) (field i64) (field (ref $type39)) (field (ref $type36))))
  (type $environment31 (struct (field i64) (field (ref $type36)) (field i64)))
  (type $call25 (func (param (ref $environment45)) (result (ref $type12))))
  (type $call48 (func (param (ref $environment44) (ref null $type14) i64 (ref $type14)) (result (ref null $type14))))
  (type $call50 (func (param (ref $environment43) (ref null $type14) i64) (result (ref null $type14))))
  (type $call34 (func (param (ref $environment39) (ref null $type14) i64) (result i64)))
  (type $environment41 (struct (field (ref $type41)) (field i64) (field (ref $type41)) (field (ref $type41))))
  (type $type34 (struct (field (ref $environment39))))
  (type $type50 (struct (field (ref $environment43))))
  (type $environment43 (struct (field (ref $type49))))
  (type $type48 (struct (field (ref $environment44))))
  (type $environment44 (struct (field (ref $type47))))
  (type $environment42 (struct (field (ref $type44)) (field (ref $type47)) (field (ref $type49)) (field (ref $type46))))
  (type $type29 (struct (field (mut (ref null $type13)))))
  (type $type45 (struct (field (mut (ref null $type14)))))
  (type $environment40 (struct (field (ref $type41)) (field (ref $type41))))
  (type $type46 (struct (field i32) (field (ref $type29))))
  (type $type44 (struct (field i32) (field (ref $type45))))
  (type $type49 (struct (field (mut i32)) (field (mut (ref null $type50)))))
  (type $type47 (struct (field (mut i32)) (field (mut (ref null $type48)))))
  (type $type35 (struct (field (mut i32)) (field (mut (ref null $type34)))))
  (type $environment39 (struct (field (ref $type35))))
  (type $call20 (func (param (ref null $type14)) (result (ref null $type13))))
  (type $call16 (func (param i64) (result i32)))
  (type $call42 (func (param (ref $environment35) i64 (ref $type14)) (result (ref null $type14))))
  (type $type38 (struct (field (ref $environment33))))
  (type $type37 (struct (field (mut i32)) (field (mut (ref null $type38)))))
  (type $type42 (struct (field (ref $environment35))))
  (type $environment33 (struct (field (ref $type36)) (field i64) (field (ref $type37))))
  (type $type43 (struct (field (mut i32)) (field (mut (ref null $type42)))))
  (type $type14 (struct (field i64) (field (ref null $type14))))
  (type $environment35 (struct (field (ref $type43))))
  (type $call38 (func (param (ref $environment33) i64 i64) (result i32)))
  (type $type40 (struct (field (ref $call40)) (field (ref struct))))
  (type $type41 (struct (field (mut i32)) (field (mut (ref null $type40)))))
  (type $type36 (struct (field i32) (field (ref $type12))))
  (type $type13 (struct))
  (type $type12 (array (mut (ref null $type13))))
  (type $environment32 (struct (field i64) (field (ref $type36)) (field i64) (field (ref $type41))))
  (type $call40 (func (param (ref struct) i64) (result i32)))
  (type $type31 (struct))
  (type $type28 (struct (field (ref $type29)) (field (ref $type29)) (field (ref $type30)) (field (ref $type30))))
  (type $type27 (struct))
  (type $type22 (struct))
  (type $type20 (struct))
  (type $type16 (struct))
  (type $type15 (struct))
  (type $type11 (struct))
 )
 (type $54 (func (param i64) (result i64)))
 (type $55 (func))
 (global $execution (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type11)) (ref.null none))
 (global $ready135 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type15)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global92 (mut (ref null $type16)) (ref.null none))
 (global $ready92 (mut i32) (i32.const 0))
 (global $global77 (mut (ref null $type16)) (ref.null none))
 (global $ready77 (mut i32) (i32.const 0))
 (global $global94 (mut (ref null $type20)) (ref.null none))
 (global $ready94 (mut i32) (i32.const 0))
 (global $global87 (mut (ref null $type22)) (ref.null none))
 (global $ready87 (mut i32) (i32.const 0))
 (global $global72 (mut (ref null $type27)) (ref.null none))
 (global $ready72 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type28)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global131 (mut (ref null $type31)) (ref.null none))
 (global $ready131 (mut i32) (i32.const 0))
 (export "sharing-prepare" (func $export0))
 (export "main" (func $main))
 (func $function32 (type $call40) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment32))
  (local $3 (ref null $type13))
  (local $4 i64)
  (local.set $2
   (ref.cast (ref $environment32)
    (local.get $0)
   )
  )
  (if (result i32)
   (i64.lt_s
    (local.get $1)
    (i64.const 4)
   )
   (then
    (local.set $3
     (if (result (ref null $type13))
      (i64.lt_s
       (local.tee $4
        (i64.add
         (local.get $1)
         (i64.const 1)
        )
       )
       (i64.const 4)
      )
      (then
       (if
        (i64.gt_u
         (local.get $4)
         (i64.const 4294967295)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type12
        (struct.get $type36 1
         (struct.get $environment32 1
          (local.get $2)
         )
        )
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (else
       (ref.null none)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type36 1
      (struct.get $environment32 1
       (local.get $2)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $3)
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (struct.get $environment32 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function32
     (struct.get $type40 1
      (struct.get $type41 1
       (struct.get $environment32 3
        (local.get $2)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function33 (type $call38) (param $0 (ref $environment33)) (param $1 i64) (param $2 i64) (result i32)
  (local $3 (ref $environment35))
  (local $4 (ref $type14))
  (local $5 (ref $type43))
  (local $6 (ref null $type14))
  (local $7 (ref null $type13))
  (local $8 i64)
  (local $9 i64)
  (local $scratch (ref null $type14))
  (if (result i32)
   (i64.lt_s
    (local.get $1)
    (local.get $2)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready87)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global87)
     )
    )
    (struct.set $type43 1
     (local.tee $5
      (struct.new_default $type43)
     )
     (struct.new $type42
      (struct.new $environment35
       (local.get $5)
      )
     )
    )
    (struct.set $type43 0
     (local.get $5)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type43 0
       (local.get $5)
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (struct.get $type42 0
      (struct.get $type43 1
       (local.get $5)
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (local.set $7
     (call $function37
      (block (result (ref null $type14))
       (local.set $scratch
        (if (result (ref null $type14))
         (i64.eqz
          (local.tee $8
           (struct.get $environment33 1
            (local.get $0)
           )
          )
         )
         (then
          (ref.null none)
         )
         (else
          (if
           (i32.eqz
            (struct.get $type43 0
             (struct.get $environment35 0
              (local.get $3)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $3
           (struct.get $type42 0
            (struct.get $type43 1
             (struct.get $environment35 0
              (local.get $3)
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready92)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global92)
           )
          )
          (local.set $4
           (struct.new $type14
            (local.get $8)
            (ref.null none)
           )
          )
          (if (result (ref null $type14))
           (i64.eqz
            (local.tee $8
             (i64.sub
              (local.get $8)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $4)
           )
           (else
            (if
             (i32.eqz
              (struct.get $type43 0
               (struct.get $environment35 0
                (local.get $3)
               )
              )
             )
             (then
              (unreachable)
             )
            )
            (local.set $3
             (struct.get $type42 0
              (struct.get $type43 1
               (struct.get $environment35 0
                (local.get $3)
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready92)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global92)
             )
            )
            (local.set $4
             (struct.new $type14
              (local.get $8)
              (local.get $4)
             )
            )
            (if (result (ref null $type14))
             (i64.eqz
              (local.tee $8
               (i64.sub
                (local.get $8)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $4)
             )
             (else
              (if
               (i32.eqz
                (struct.get $type43 0
                 (struct.get $environment35 0
                  (local.get $3)
                 )
                )
               )
               (then
                (unreachable)
               )
              )
              (local.set $3
               (struct.get $type42 0
                (struct.get $type43 1
                 (struct.get $environment35 0
                  (local.get $3)
                 )
                )
               )
              )
              (if
               (i32.eqz
                (global.get $ready92)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global92)
               )
              )
              (local.set $4
               (struct.new $type14
                (local.get $8)
                (local.get $4)
               )
              )
              (if (result (ref null $type14))
               (i64.eqz
                (local.tee $8
                 (i64.sub
                  (local.get $8)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $4)
               )
               (else
                (if
                 (i32.eqz
                  (struct.get $type43 0
                   (struct.get $environment35 0
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (local.set $3
                 (struct.get $type42 0
                  (struct.get $type43 1
                   (struct.get $environment35 0
                    (local.get $3)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready92)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global92)
                 )
                )
                (local.set $4
                 (struct.new $type14
                  (local.get $8)
                  (local.get $4)
                 )
                )
                (if (result (ref null $type14))
                 (i64.eqz
                  (local.tee $8
                   (i64.sub
                    (local.get $8)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $4)
                 )
                 (else
                  (if
                   (i32.eqz
                    (struct.get $type43 0
                     (struct.get $environment35 0
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $3
                   (struct.get $type42 0
                    (struct.get $type43 1
                     (struct.get $environment35 0
                      (local.get $3)
                     )
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready92)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global92)
                   )
                  )
                  (local.set $4
                   (struct.new $type14
                    (local.get $8)
                    (local.get $4)
                   )
                  )
                  (if (result (ref null $type14))
                   (i64.eqz
                    (local.tee $8
                     (i64.sub
                      (local.get $8)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $4)
                   )
                   (else
                    (if
                     (i32.eqz
                      (struct.get $type43 0
                       (struct.get $environment35 0
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $3
                     (struct.get $type42 0
                      (struct.get $type43 1
                       (struct.get $environment35 0
                        (local.get $3)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready92)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global92)
                     )
                    )
                    (local.set $4
                     (struct.new $type14
                      (local.get $8)
                      (local.get $4)
                     )
                    )
                    (if (result (ref null $type14))
                     (i64.eqz
                      (local.tee $8
                       (i64.sub
                        (local.get $8)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $4)
                     )
                     (else
                      (if
                       (i32.eqz
                        (struct.get $type43 0
                         (struct.get $environment35 0
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (local.set $3
                       (struct.get $type42 0
                        (struct.get $type43 1
                         (struct.get $environment35 0
                          (local.get $3)
                         )
                        )
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready92)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global92)
                       )
                      )
                      (local.set $4
                       (struct.new $type14
                        (local.get $8)
                        (local.get $4)
                       )
                      )
                      (if (result (ref null $type14))
                       (i64.eqz
                        (local.tee $9
                         (i64.sub
                          (local.get $8)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (local.get $4)
                       )
                       (else
                        (if
                         (i32.eqz
                          (struct.get $type43 0
                           (struct.get $environment35 0
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (local.set $3
                         (struct.get $type42 0
                          (struct.get $type43 1
                           (struct.get $environment35 0
                            (local.get $3)
                           )
                          )
                         )
                        )
                        (local.set $8
                         (i64.sub
                          (local.get $9)
                          (i64.const 1)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready92)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global92)
                         )
                        )
                        (local.set $4
                         (struct.new $type14
                          (local.get $9)
                          (local.get $4)
                         )
                        )
                        (if (result (ref null $type14))
                         (i64.eqz
                          (local.get $8)
                         )
                         (then
                          (local.get $4)
                         )
                         (else
                          (if
                           (i32.eqz
                            (struct.get $type43 0
                             (struct.get $environment35 0
                              (local.get $3)
                             )
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $function35
                           (struct.get $type42 0
                            (struct.get $type43 1
                             (struct.get $environment35 0
                              (local.get $3)
                             )
                            )
                           )
                           (i64.sub
                            (local.get $8)
                            (i64.const 1)
                           )
                           (struct.new $type14
                            (local.get $8)
                            (local.get $4)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (if
        (i32.eqz
         (global.get $ready94)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global94)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type12
     (struct.get $type36 1
      (struct.get $environment33 0
       (local.get $0)
      )
     )
     (i32.wrap_i64
      (local.get $1)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (struct.get $type37 0
       (struct.get $environment33 2
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function33
     (struct.get $type38 0
      (struct.get $type37 1
       (struct.get $environment33 2
        (local.get $0)
       )
      )
     )
     (i64.add
      (local.get $1)
      (i64.const 1)
     )
     (local.get $2)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function35 (type $call42) (param $0 (ref $environment35)) (param $1 i64) (param $2 (ref $type14)) (result (ref null $type14))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref $type14))
   (i64.eqz
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i32.eqz
      (struct.get $type43 0
       (struct.get $environment35 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function35
     (struct.get $type42 0
      (struct.get $type43 1
       (struct.get $environment35 0
        (local.get $0)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.new $type14
      (local.get $1)
      (local.get $2)
     )
    )
   )
  )
 )
 (func $function36 (type $call16) (param $0 i64) (result i32)
  (i64.eqz
   (local.get $0)
  )
 )
 (func $function37 (type $call20) (param $0 (ref null $type14)) (result (ref null $type13))
  (local $1 (ref $environment39))
  (local $2 (ref $type41))
  (local $3 (ref $type41))
  (local $4 (ref $type35))
  (local $5 (ref $type47))
  (local $6 (ref $type49))
  (local $7 (ref $type44))
  (local $8 (ref $type46))
  (local $9 (ref struct))
  (local $10 (ref $environment40))
  (local $11 (ref $type40))
  (local $12 i64)
  (struct.set $type41 1
   (local.tee $2
    (struct.new_default $type41)
   )
   (struct.new $type40
    (ref.func $function40)
    (struct.new $environment40
     (local.get $2)
     (local.tee $3
      (struct.new_default $type41)
     )
    )
   )
  )
  (struct.set $type41 0
   (local.get $2)
   (i32.const 1)
  )
  (struct.set $type41 1
   (local.get $3)
   (struct.new $type40
    (ref.func $function42)
    (struct.new $environment42
     (local.tee $7
      (struct.new $type44
       (i32.const 1)
       (struct.new $type45
        (local.get $0)
       )
      )
     )
     (local.tee $5
      (struct.new_default $type47)
     )
     (local.tee $6
      (struct.new_default $type49)
     )
     (local.tee $8
      (struct.new $type46
       (i32.const 1)
       (struct.new $type29
        (struct.new_default $type13)
       )
      )
     )
    )
   )
  )
  (struct.set $type41 0
   (local.get $3)
   (i32.const 1)
  )
  (struct.set $type47 1
   (local.get $5)
   (struct.new $type48
    (struct.new $environment44
     (local.get $5)
    )
   )
  )
  (struct.set $type47 0
   (local.get $5)
   (i32.const 1)
  )
  (struct.set $type49 1
   (local.get $6)
   (struct.new $type50
    (struct.new $environment43
     (local.get $6)
    )
   )
  )
  (struct.set $type49 0
   (local.get $6)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (local.set $0
   (struct.get $type45 0
    (struct.get $type44 1
     (local.get $7)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (struct.set $type35 1
   (local.tee $4
    (struct.new_default $type35)
   )
   (struct.new $type34
    (struct.new $environment39
     (local.get $4)
    )
   )
  )
  (struct.set $type35 0
   (local.get $4)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (struct.get $type35 0
     (local.get $4)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (struct.get $type34 0
    (struct.get $type35 1
     (local.get $4)
    )
   )
  )
  (local.set $12
   (if (result i64)
    (ref.is_null
     (local.get $0)
    )
    (then
     (i64.const 0)
    )
    (else
     (local.set $0
      (struct.get $type14 1
       (local.get $0)
      )
     )
     (if
      (i32.eqz
       (struct.get $type35 0
        (struct.get $environment39 0
         (local.get $1)
        )
       )
      )
      (then
       (unreachable)
      )
     )
     (local.set $1
      (struct.get $type34 0
       (struct.get $type35 1
        (struct.get $environment39 0
         (local.get $1)
        )
       )
      )
     )
     (if (result i64)
      (ref.is_null
       (local.get $0)
      )
      (then
       (i64.const 1)
      )
      (else
       (local.set $0
        (struct.get $type14 1
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (struct.get $type35 0
          (struct.get $environment39 0
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $1
        (struct.get $type34 0
         (struct.get $type35 1
          (struct.get $environment39 0
           (local.get $1)
          )
         )
        )
       )
       (if (result i64)
        (ref.is_null
         (local.get $0)
        )
        (then
         (i64.const 2)
        )
        (else
         (local.set $0
          (struct.get $type14 1
           (local.get $0)
          )
         )
         (if
          (i32.eqz
           (struct.get $type35 0
            (struct.get $environment39 0
             (local.get $1)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $1
          (struct.get $type34 0
           (struct.get $type35 1
            (struct.get $environment39 0
             (local.get $1)
            )
           )
          )
         )
         (if (result i64)
          (ref.is_null
           (local.get $0)
          )
          (then
           (i64.const 3)
          )
          (else
           (local.set $0
            (struct.get $type14 1
             (local.get $0)
            )
           )
           (if
            (i32.eqz
             (struct.get $type35 0
              (struct.get $environment39 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type34 0
             (struct.get $type35 1
              (struct.get $environment39 0
               (local.get $1)
              )
             )
            )
           )
           (if (result i64)
            (ref.is_null
             (local.get $0)
            )
            (then
             (i64.const 4)
            )
            (else
             (local.set $0
              (struct.get $type14 1
               (local.get $0)
              )
             )
             (if
              (i32.eqz
               (struct.get $type35 0
                (struct.get $environment39 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type34 0
               (struct.get $type35 1
                (struct.get $environment39 0
                 (local.get $1)
                )
               )
              )
             )
             (if (result i64)
              (ref.is_null
               (local.get $0)
              )
              (then
               (i64.const 5)
              )
              (else
               (local.set $0
                (struct.get $type14 1
                 (local.get $0)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type35 0
                  (struct.get $environment39 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type34 0
                 (struct.get $type35 1
                  (struct.get $environment39 0
                   (local.get $1)
                  )
                 )
                )
               )
               (if (result i64)
                (ref.is_null
                 (local.get $0)
                )
                (then
                 (i64.const 6)
                )
                (else
                 (local.set $0
                  (struct.get $type14 1
                   (local.get $0)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type35 0
                    (struct.get $environment39 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type34 0
                   (struct.get $type35 1
                    (struct.get $environment39 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if (result i64)
                  (ref.is_null
                   (local.get $0)
                  )
                  (then
                   (i64.const 7)
                  )
                  (else
                   (local.set $0
                    (struct.get $type14 1
                     (local.get $0)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type35 0
                      (struct.get $environment39 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type34 0
                     (struct.get $type35 1
                      (struct.get $environment39 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if (result i64)
                    (ref.is_null
                     (local.get $0)
                    )
                    (then
                     (i64.const 8)
                    )
                    (else
                     (local.set $0
                      (struct.get $type14 1
                       (local.get $0)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type35 0
                        (struct.get $environment39 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (call $function39
                      (struct.get $type34 0
                       (struct.get $type35 1
                        (struct.get $environment39 0
                         (local.get $1)
                        )
                       )
                      )
                      (local.get $0)
                      (i64.const 9)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (struct.get $type41 0
     (local.get $2)
    )
   )
   (then
    (unreachable)
   )
  )
  (local.set $9
   (struct.get $type40 1
    (struct.get $type41 1
     (local.get $2)
    )
   )
  )
  (drop
   (if (result i32)
    (i64.gt_s
     (local.get $12)
     (i64.const 1)
    )
    (then
     (struct.set $type41 1
      (local.tee $2
       (struct.new_default $type41)
      )
      (struct.new $type40
       (ref.func $function41)
       (struct.new $environment41
        (struct.get $environment40 0
         (local.tee $10
          (ref.cast (ref $environment40)
           (local.get $9)
          )
         )
        )
        (local.get $12)
        (struct.get $environment40 1
         (local.get $10)
        )
        (local.get $2)
       )
      )
     )
     (struct.set $type41 0
      (local.get $2)
      (i32.const 1)
     )
     (if
      (i32.eqz
       (struct.get $type41 0
        (local.get $2)
       )
      )
      (then
       (unreachable)
      )
     )
     (call_ref $call40
      (struct.get $type40 1
       (local.tee $11
        (ref.as_non_null
         (struct.get $type41 1
          (local.get $2)
         )
        )
       )
      )
      (i64.sub
       (local.get $12)
       (i64.const 1)
      )
      (struct.get $type40 0
       (local.get $11)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (struct.get $type29 0
   (struct.get $type46 1
    (local.get $8)
   )
  )
 )
 (func $function39 (type $call34) (param $0 (ref $environment39)) (param $1 (ref null $type14)) (param $2 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $1)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $1
     (struct.get $type14 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type35 0
       (struct.get $environment39 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function39
     (struct.get $type34 0
      (struct.get $type35 1
       (struct.get $environment39 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function40 (type $call40) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $type41))
  (local $3 (ref $environment40))
  (local $4 (ref $type40))
  (if (result i32)
   (i64.gt_s
    (local.get $1)
    (i64.const 1)
   )
   (then
    (struct.set $type41 1
     (local.tee $2
      (struct.new_default $type41)
     )
     (struct.new $type40
      (ref.func $function41)
      (struct.new $environment41
       (struct.get $environment40 0
        (local.tee $3
         (ref.cast (ref $environment40)
          (local.get $0)
         )
        )
       )
       (local.get $1)
       (struct.get $environment40 1
        (local.get $3)
       )
       (local.get $2)
      )
     )
    )
    (struct.set $type41 0
     (local.get $2)
     (i32.const 1)
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (local.get $2)
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call_ref $call40
     (struct.get $type40 1
      (local.tee $4
       (ref.as_non_null
        (struct.get $type41 1
         (local.get $2)
        )
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
     (struct.get $type40 0
      (local.get $4)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function41 (type $call40) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref $environment41))
  (local $3 (ref $type41))
  (local $4 (ref $environment40))
  (local $5 (ref $type40))
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $1)
   )
   (then
    (if (result i32)
     (i64.gt_s
      (local.tee $1
       (i64.sub
        (struct.get $environment41 1
         (local.tee $2
          (ref.cast (ref $environment41)
           (local.get $0)
          )
         )
        )
        (block (result i64)
         (if
          (i32.eqz
           (struct.get $type41 0
            (struct.get $environment41 0
             (local.get $2)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $0
          (struct.get $type40 1
           (struct.get $type41 1
            (struct.get $environment41 0
             (local.get $2)
            )
           )
          )
         )
         (i64.const 1)
        )
       )
      )
      (i64.const 1)
     )
     (then
      (struct.set $type41 1
       (local.tee $3
        (struct.new_default $type41)
       )
       (struct.new $type40
        (ref.func $function41)
        (struct.new $environment41
         (struct.get $environment40 0
          (local.tee $4
           (ref.cast (ref $environment40)
            (local.get $0)
           )
          )
         )
         (local.get $1)
         (struct.get $environment40 1
          (local.get $4)
         )
         (local.get $3)
        )
       )
      )
      (struct.set $type41 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type41 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (return_call_ref $call40
       (struct.get $type40 1
        (local.tee $5
         (ref.as_non_null
          (struct.get $type41 1
           (local.get $3)
          )
         )
        )
       )
       (i64.sub
        (local.get $1)
        (i64.const 1)
       )
       (struct.get $type40 0
        (local.get $5)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
   (else
    (drop
     (if (result i32)
      (i64.gt_s
       (local.tee $6
        (i64.sub
         (struct.get $environment41 1
          (local.tee $2
           (ref.cast (ref $environment41)
            (local.get $0)
           )
          )
         )
         (block (result i64)
          (if
           (i32.eqz
            (struct.get $type41 0
             (struct.get $environment41 0
              (local.get $2)
             )
            )
           )
           (then
            (unreachable)
           )
          )
          (local.set $0
           (struct.get $type40 1
            (struct.get $type41 1
             (struct.get $environment41 0
              (local.get $2)
             )
            )
           )
          )
          (i64.const 1)
         )
        )
       )
       (i64.const 1)
      )
      (then
       (struct.set $type41 1
        (local.tee $3
         (struct.new_default $type41)
        )
        (struct.new $type40
         (ref.func $function41)
         (struct.new $environment41
          (struct.get $environment40 0
           (local.tee $4
            (ref.cast (ref $environment40)
             (local.get $0)
            )
           )
          )
          (local.get $6)
          (struct.get $environment40 1
           (local.get $4)
          )
          (local.get $3)
         )
        )
       )
       (struct.set $type41 0
        (local.get $3)
        (i32.const 1)
       )
       (if
        (i32.eqz
         (struct.get $type41 0
          (local.get $3)
         )
        )
        (then
         (unreachable)
        )
       )
       (call_ref $call40
        (struct.get $type40 1
         (local.tee $5
          (ref.as_non_null
           (struct.get $type41 1
            (local.get $3)
           )
          )
         )
        )
        (i64.sub
         (local.get $6)
         (i64.const 1)
        )
        (struct.get $type40 0
         (local.get $5)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (struct.get $environment41 2
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function42
      (struct.get $type40 1
       (struct.get $type41 1
        (struct.get $environment41 2
         (local.get $2)
        )
       )
      )
      (struct.get $environment41 1
       (local.get $2)
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type41 0
       (struct.get $environment41 3
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function41
     (struct.get $type40 1
      (struct.get $type41 1
       (struct.get $environment41 3
        (local.get $2)
       )
      )
     )
     (i64.sub
      (local.get $1)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function42 (type $call40) (param $0 (ref struct)) (param $1 i64) (result i32)
  (local $2 (ref null $type14))
  (local $3 (ref null $type14))
  (local $4 (ref null $type14))
  (local $5 (ref $environment43))
  (local $6 (ref $environment44))
  (local $7 (ref $type14))
  (local $8 (ref $environment42))
  (local $9 (ref $type45))
  (local $10 i64)
  (struct.set $type45 0
   (struct.get $type44 1
    (struct.get $environment42 0
     (local.tee $8
      (ref.cast (ref $environment42)
       (local.get $0)
      )
     )
    )
   )
   (block (result (ref null $type14))
    (local.set $3
     (local.tee $2
      (struct.get $type45 0
       (struct.get $type44 1
        (struct.get $environment42 0
         (local.get $8)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (struct.get $environment42 2
        (local.get $8)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (struct.get $type50 0
      (struct.get $type49 1
       (struct.get $environment42 2
        (local.get $8)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (if
     (i64.ne
      (local.get $1)
      (i64.const 0)
     )
     (then
      (local.set $2
       (struct.get $type14 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (struct.get $type49 0
         (struct.get $environment43 0
          (local.get $5)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (struct.get $type50 0
        (struct.get $type49 1
         (struct.get $environment43 0
          (local.get $5)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready92)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global92)
       )
      )
      (local.set $2
       (if (result (ref null $type14))
        (i64.eqz
         (local.tee $10
          (i64.sub
           (local.get $1)
           (i64.const 1)
          )
         )
        )
        (then
         (local.get $2)
        )
        (else
         (local.set $2
          (struct.get $type14 1
           (local.get $2)
          )
         )
         (if
          (i32.eqz
           (struct.get $type49 0
            (struct.get $environment43 0
             (local.get $5)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $5
          (struct.get $type50 0
           (struct.get $type49 1
            (struct.get $environment43 0
             (local.get $5)
            )
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready92)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global92)
          )
         )
         (if (result (ref null $type14))
          (i64.eqz
           (local.tee $10
            (i64.sub
             (local.get $10)
             (i64.const 1)
            )
           )
          )
          (then
           (local.get $2)
          )
          (else
           (local.set $2
            (struct.get $type14 1
             (local.get $2)
            )
           )
           (if
            (i32.eqz
             (struct.get $type49 0
              (struct.get $environment43 0
               (local.get $5)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (struct.get $type50 0
             (struct.get $type49 1
              (struct.get $environment43 0
               (local.get $5)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (if (result (ref null $type14))
            (i64.eqz
             (local.tee $10
              (i64.sub
               (local.get $10)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $2)
            )
            (else
             (local.set $2
              (struct.get $type14 1
               (local.get $2)
              )
             )
             (if
              (i32.eqz
               (struct.get $type49 0
                (struct.get $environment43 0
                 (local.get $5)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $5
              (struct.get $type50 0
               (struct.get $type49 1
                (struct.get $environment43 0
                 (local.get $5)
                )
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (if (result (ref null $type14))
              (i64.eqz
               (local.tee $10
                (i64.sub
                 (local.get $10)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $2)
              )
              (else
               (local.set $2
                (struct.get $type14 1
                 (local.get $2)
                )
               )
               (if
                (i32.eqz
                 (struct.get $type49 0
                  (struct.get $environment43 0
                   (local.get $5)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $5
                (struct.get $type50 0
                 (struct.get $type49 1
                  (struct.get $environment43 0
                   (local.get $5)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (if (result (ref null $type14))
                (i64.eqz
                 (local.tee $10
                  (i64.sub
                   (local.get $10)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $2)
                )
                (else
                 (local.set $2
                  (struct.get $type14 1
                   (local.get $2)
                  )
                 )
                 (if
                  (i32.eqz
                   (struct.get $type49 0
                    (struct.get $environment43 0
                     (local.get $5)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $5
                  (struct.get $type50 0
                   (struct.get $type49 1
                    (struct.get $environment43 0
                     (local.get $5)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (if (result (ref null $type14))
                  (i64.eqz
                   (local.tee $10
                    (i64.sub
                     (local.get $10)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (local.set $2
                    (struct.get $type14 1
                     (local.get $2)
                    )
                   )
                   (if
                    (i32.eqz
                     (struct.get $type49 0
                      (struct.get $environment43 0
                       (local.get $5)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $5
                    (struct.get $type50 0
                     (struct.get $type49 1
                      (struct.get $environment43 0
                       (local.get $5)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (if (result (ref null $type14))
                    (i64.eqz
                     (local.tee $10
                      (i64.sub
                       (local.get $10)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (local.set $2
                      (struct.get $type14 1
                       (local.get $2)
                      )
                     )
                     (if
                      (i32.eqz
                       (struct.get $type49 0
                        (struct.get $environment43 0
                         (local.get $5)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $5
                      (struct.get $type50 0
                       (struct.get $type49 1
                        (struct.get $environment43 0
                         (local.get $5)
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (if (result (ref null $type14))
                      (i64.eqz
                       (local.tee $10
                        (i64.sub
                         (local.get $10)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (local.set $2
                        (struct.get $type14 1
                         (local.get $2)
                        )
                       )
                       (if
                        (i32.eqz
                         (struct.get $type49 0
                          (struct.get $environment43 0
                           (local.get $5)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $5
                        (struct.get $type50 0
                         (struct.get $type49 1
                          (struct.get $environment43 0
                           (local.get $5)
                          )
                         )
                        )
                       )
                       (local.set $10
                        (i64.sub
                         (local.get $10)
                         (i64.const 1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready92)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global92)
                        )
                       )
                       (if (result (ref null $type14))
                        (call $function36
                         (local.get $10)
                        )
                        (then
                         (local.get $2)
                        )
                        (else
                         (local.set $2
                          (struct.get $type14 1
                           (local.get $2)
                          )
                         )
                         (if
                          (i32.eqz
                           (struct.get $type49 0
                            (struct.get $environment43 0
                             (local.get $5)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (call $function43
                          (struct.get $type50 0
                           (struct.get $type49 1
                            (struct.get $environment43 0
                             (local.get $5)
                            )
                           )
                          )
                          (local.get $2)
                          (i64.sub
                           (local.get $10)
                           (i64.const 1)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment42 1
        (local.get $8)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (struct.get $type48 0
      (struct.get $type47 1
       (struct.get $environment42 1
        (local.get $8)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready92)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global92)
     )
    )
    (if (result (ref null $type14))
     (i64.eqz
      (local.get $1)
     )
     (then
      (local.get $2)
     )
     (else
      (local.set $4
       (struct.get $type14 1
        (local.get $3)
       )
      )
      (local.set $7
       (struct.new $type14
        (struct.get $type14 0
         (local.get $3)
        )
        (block (result (ref null $type14))
         (if
          (i32.eqz
           (struct.get $type47 0
            (struct.get $environment44 0
             (local.get $6)
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (local.set $6
          (struct.get $type48 0
           (struct.get $type47 1
            (struct.get $environment44 0
             (local.get $6)
            )
           )
          )
         )
         (if
          (i32.eqz
           (global.get $ready92)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global92)
          )
         )
         (local.get $2)
        )
       )
      )
      (if (result (ref null $type14))
       (i64.eqz
        (local.tee $1
         (i64.sub
          (local.get $1)
          (i64.const 1)
         )
        )
       )
       (then
        (local.get $7)
       )
       (else
        (local.set $2
         (struct.get $type14 1
          (local.get $4)
         )
        )
        (local.set $7
         (struct.new $type14
          (struct.get $type14 0
           (local.get $4)
          )
          (block (result (ref $type14))
           (if
            (i32.eqz
             (struct.get $type47 0
              (struct.get $environment44 0
               (local.get $6)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $6
            (struct.get $type48 0
             (struct.get $type47 1
              (struct.get $environment44 0
               (local.get $6)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (local.get $7)
          )
         )
        )
        (if (result (ref null $type14))
         (i64.eqz
          (local.tee $1
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
         )
         (then
          (local.get $7)
         )
         (else
          (local.set $3
           (struct.get $type14 1
            (local.get $2)
           )
          )
          (local.set $7
           (struct.new $type14
            (struct.get $type14 0
             (local.get $2)
            )
            (block (result (ref $type14))
             (if
              (i32.eqz
               (struct.get $type47 0
                (struct.get $environment44 0
                 (local.get $6)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $6
              (struct.get $type48 0
               (struct.get $type47 1
                (struct.get $environment44 0
                 (local.get $6)
                )
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (local.get $7)
            )
           )
          )
          (if (result (ref null $type14))
           (i64.eqz
            (local.tee $1
             (i64.sub
              (local.get $1)
              (i64.const 1)
             )
            )
           )
           (then
            (local.get $7)
           )
           (else
            (local.set $2
             (struct.get $type14 1
              (local.get $3)
             )
            )
            (local.set $7
             (struct.new $type14
              (struct.get $type14 0
               (local.get $3)
              )
              (block (result (ref $type14))
               (if
                (i32.eqz
                 (struct.get $type47 0
                  (struct.get $environment44 0
                   (local.get $6)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $6
                (struct.get $type48 0
                 (struct.get $type47 1
                  (struct.get $environment44 0
                   (local.get $6)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (local.get $7)
              )
             )
            )
            (if (result (ref null $type14))
             (i64.eqz
              (local.tee $1
               (i64.sub
                (local.get $1)
                (i64.const 1)
               )
              )
             )
             (then
              (local.get $7)
             )
             (else
              (local.set $3
               (struct.get $type14 1
                (local.get $2)
               )
              )
              (local.set $7
               (struct.new $type14
                (struct.get $type14 0
                 (local.get $2)
                )
                (block (result (ref $type14))
                 (if
                  (i32.eqz
                   (struct.get $type47 0
                    (struct.get $environment44 0
                     (local.get $6)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $6
                  (struct.get $type48 0
                   (struct.get $type47 1
                    (struct.get $environment44 0
                     (local.get $6)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (local.get $7)
                )
               )
              )
              (if (result (ref null $type14))
               (i64.eqz
                (local.tee $1
                 (i64.sub
                  (local.get $1)
                  (i64.const 1)
                 )
                )
               )
               (then
                (local.get $7)
               )
               (else
                (local.set $2
                 (struct.get $type14 1
                  (local.get $3)
                 )
                )
                (local.set $7
                 (struct.new $type14
                  (struct.get $type14 0
                   (local.get $3)
                  )
                  (block (result (ref $type14))
                   (if
                    (i32.eqz
                     (struct.get $type47 0
                      (struct.get $environment44 0
                       (local.get $6)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $6
                    (struct.get $type48 0
                     (struct.get $type47 1
                      (struct.get $environment44 0
                       (local.get $6)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (local.get $7)
                  )
                 )
                )
                (if (result (ref null $type14))
                 (i64.eqz
                  (local.tee $1
                   (i64.sub
                    (local.get $1)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (local.get $7)
                 )
                 (else
                  (local.set $3
                   (struct.get $type14 1
                    (local.get $2)
                   )
                  )
                  (local.set $7
                   (struct.new $type14
                    (struct.get $type14 0
                     (local.get $2)
                    )
                    (block (result (ref $type14))
                     (if
                      (i32.eqz
                       (struct.get $type47 0
                        (struct.get $environment44 0
                         (local.get $6)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $6
                      (struct.get $type48 0
                       (struct.get $type47 1
                        (struct.get $environment44 0
                         (local.get $6)
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (local.get $7)
                    )
                   )
                  )
                  (if (result (ref null $type14))
                   (i64.eqz
                    (local.tee $1
                     (i64.sub
                      (local.get $1)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (local.get $7)
                   )
                   (else
                    (local.set $4
                     (struct.get $type14 1
                      (local.get $3)
                     )
                    )
                    (local.set $7
                     (struct.new $type14
                      (struct.get $type14 0
                       (local.get $3)
                      )
                      (block (result (ref $type14))
                       (if
                        (i32.eqz
                         (struct.get $type47 0
                          (struct.get $environment44 0
                           (local.get $6)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $6
                        (struct.get $type48 0
                         (struct.get $type47 1
                          (struct.get $environment44 0
                           (local.get $6)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready92)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global92)
                        )
                       )
                       (local.get $7)
                      )
                     )
                    )
                    (if (result (ref null $type14))
                     (i64.eqz
                      (local.tee $1
                       (i64.sub
                        (local.get $1)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (local.get $7)
                     )
                     (else
                      (local.set $2
                       (struct.get $type14 1
                        (local.get $4)
                       )
                      )
                      (local.set $7
                       (struct.new $type14
                        (struct.get $type14 0
                         (local.get $4)
                        )
                        (block (result (ref $type14))
                         (if
                          (i32.eqz
                           (struct.get $type47 0
                            (struct.get $environment44 0
                             (local.get $6)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $6
                          (struct.get $type48 0
                           (struct.get $type47 1
                            (struct.get $environment44 0
                             (local.get $6)
                            )
                           )
                          )
                         )
                         (local.set $1
                          (i64.sub
                           (local.get $1)
                           (i64.const 1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready92)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global92)
                          )
                         )
                         (local.get $7)
                        )
                       )
                      )
                      (if (result (ref null $type14))
                       (call $function36
                        (local.get $1)
                       )
                       (then
                        (local.get $7)
                       )
                       (else
                        (local.set $3
                         (struct.get $type14 1
                          (local.get $2)
                         )
                        )
                        (local.set $10
                         (struct.get $type14 0
                          (local.get $2)
                         )
                        )
                        (if
                         (i32.eqz
                          (struct.get $type47 0
                           (struct.get $environment44 0
                            (local.get $6)
                           )
                          )
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $function44
                         (struct.get $type48 0
                          (struct.get $type47 1
                           (struct.get $environment44 0
                            (local.get $6)
                           )
                          )
                         )
                         (local.get $3)
                         (i64.sub
                          (local.get $1)
                          (i64.const 1)
                         )
                         (struct.new $type14
                          (local.get $10)
                          (local.get $7)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (struct.set $type29 0
   (struct.get $type46 1
    (struct.get $environment42 3
     (local.get $8)
    )
   )
   (struct.new_default $type13)
  )
  (i32.const 0)
 )
 (func $function43 (type $call50) (param $0 (ref $environment43)) (param $1 (ref null $type14)) (param $2 i64) (result (ref null $type14))
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref null $type14))
   (call $function36
    (local.get $2)
   )
   (then
    (local.get $1)
   )
   (else
    (local.set $1
     (struct.get $type14 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type49 0
       (struct.get $environment43 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (struct.get $type50 0
      (struct.get $type49 1
       (struct.get $environment43 0
        (local.get $0)
       )
      )
     )
     (local.get $1)
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function44 (type $call48) (param $0 (ref $environment44)) (param $1 (ref null $type14)) (param $2 i64) (param $3 (ref $type14)) (result (ref null $type14))
  (local $4 (ref null $type14))
  (local $5 i64)
  (if
   (i32.eqz
    (global.get $ready92)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global92)
   )
  )
  (if (result (ref $type14))
   (call $function36
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type14 1
      (local.get $1)
     )
    )
    (local.set $5
     (struct.get $type14 0
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (struct.get $type47 0
       (struct.get $environment44 0
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (struct.get $type48 0
      (struct.get $type47 1
       (struct.get $environment44 0
        (local.get $0)
       )
      )
     )
     (local.get $4)
     (i64.sub
      (local.get $2)
      (i64.const 1)
     )
     (struct.new $type14
      (local.get $5)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function51 (type $call31) (param $0 i64) (result i64)
  (local $1 (ref $environment35))
  (local $2 (ref $type14))
  (local $3 (ref $type43))
  (local $4 (ref $type37))
  (local $5 (ref $type12))
  (local $6 (ref $type12))
  (local $7 (ref $type41))
  (local $8 (ref $type29))
  (local $9 (ref null $type14))
  (local $10 (ref $type36))
  (local $11 (ref $environment45))
  (local $12 (ref $type24))
  (local $13 (ref $type30))
  (local $14 (ref $type40))
  (local $15 i64)
  (local $16 i64)
  (local $scratch (ref null $type14))
  (local $scratch_18 (ref null $type14))
  (if (result i64)
   (i64.eq
    (local.get $0)
    (i64.const 3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type29 0
     (struct.get $type28 0
      (global.get $global130)
     )
     (block (result (ref null $type13))
      (if
       (i32.eqz
        (global.get $ready87)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global87)
       )
      )
      (struct.set $type43 1
       (local.tee $3
        (struct.new_default $type43)
       )
       (struct.new $type42
        (struct.new $environment35
         (local.get $3)
        )
       )
      )
      (struct.set $type43 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type43 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type42 0
        (struct.get $type43 1
         (local.get $3)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready92)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global92)
       )
      )
      (call $function37
       (block (result (ref null $type14))
        (local.set $scratch
         (if (result (ref null $type14))
          (i64.eqz
           (local.get $0)
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i32.eqz
             (struct.get $type43 0
              (struct.get $environment35 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type42 0
             (struct.get $type43 1
              (struct.get $environment35 0
               (local.get $1)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (local.set $2
            (struct.new $type14
             (local.get $0)
             (ref.null none)
            )
           )
           (if (result (ref null $type14))
            (i64.eqz
             (local.tee $15
              (i64.sub
               (local.get $0)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $2)
            )
            (else
             (if
              (i32.eqz
               (struct.get $type43 0
                (struct.get $environment35 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type42 0
               (struct.get $type43 1
                (struct.get $environment35 0
                 (local.get $1)
                )
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (local.set $2
              (struct.new $type14
               (local.get $15)
               (local.get $2)
              )
             )
             (if (result (ref null $type14))
              (i64.eqz
               (local.tee $15
                (i64.sub
                 (local.get $15)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $2)
              )
              (else
               (if
                (i32.eqz
                 (struct.get $type43 0
                  (struct.get $environment35 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type42 0
                 (struct.get $type43 1
                  (struct.get $environment35 0
                   (local.get $1)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (local.set $2
                (struct.new $type14
                 (local.get $15)
                 (local.get $2)
                )
               )
               (if (result (ref null $type14))
                (i64.eqz
                 (local.tee $15
                  (i64.sub
                   (local.get $15)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $2)
                )
                (else
                 (if
                  (i32.eqz
                   (struct.get $type43 0
                    (struct.get $environment35 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type42 0
                   (struct.get $type43 1
                    (struct.get $environment35 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (local.set $2
                  (struct.new $type14
                   (local.get $15)
                   (local.get $2)
                  )
                 )
                 (if (result (ref null $type14))
                  (i64.eqz
                   (local.tee $15
                    (i64.sub
                     (local.get $15)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (if
                    (i32.eqz
                     (struct.get $type43 0
                      (struct.get $environment35 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type42 0
                     (struct.get $type43 1
                      (struct.get $environment35 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (local.set $2
                    (struct.new $type14
                     (local.get $15)
                     (local.get $2)
                    )
                   )
                   (if (result (ref null $type14))
                    (i64.eqz
                     (local.tee $15
                      (i64.sub
                       (local.get $15)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (if
                      (i32.eqz
                       (struct.get $type43 0
                        (struct.get $environment35 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (struct.get $type42 0
                       (struct.get $type43 1
                        (struct.get $environment35 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (local.set $2
                      (struct.new $type14
                       (local.get $15)
                       (local.get $2)
                      )
                     )
                     (if (result (ref null $type14))
                      (i64.eqz
                       (local.tee $15
                        (i64.sub
                         (local.get $15)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (if
                        (i32.eqz
                         (struct.get $type43 0
                          (struct.get $environment35 0
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $1
                        (struct.get $type42 0
                         (struct.get $type43 1
                          (struct.get $environment35 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready92)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global92)
                        )
                       )
                       (local.set $2
                        (struct.new $type14
                         (local.get $15)
                         (local.get $2)
                        )
                       )
                       (if (result (ref null $type14))
                        (i64.eqz
                         (local.tee $16
                          (i64.sub
                           (local.get $15)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (local.get $2)
                        )
                        (else
                         (if
                          (i32.eqz
                           (struct.get $type43 0
                            (struct.get $environment35 0
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $1
                          (struct.get $type42 0
                           (struct.get $type43 1
                            (struct.get $environment35 0
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (local.set $15
                          (i64.sub
                           (local.get $16)
                           (i64.const 1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready92)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global92)
                          )
                         )
                         (local.set $2
                          (struct.new $type14
                           (local.get $16)
                           (local.get $2)
                          )
                         )
                         (if (result (ref null $type14))
                          (i64.eqz
                           (local.get $15)
                          )
                          (then
                           (local.get $2)
                          )
                          (else
                           (if
                            (i32.eqz
                             (struct.get $type43 0
                              (struct.get $environment35 0
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (call $function35
                            (struct.get $type42 0
                             (struct.get $type43 1
                              (struct.get $environment35 0
                               (local.get $1)
                              )
                             )
                            )
                            (i64.sub
                             (local.get $15)
                             (i64.const 1)
                            )
                            (struct.new $type14
                             (local.get $15)
                             (local.get $2)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready94)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global94)
         )
        )
        (local.get $scratch)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type29 0
     (struct.get $type28 1
      (global.get $global130)
     )
     (block (result (ref null $type13))
      (if
       (i32.eqz
        (global.get $ready87)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global87)
       )
      )
      (struct.set $type43 1
       (local.tee $3
        (struct.new_default $type43)
       )
       (struct.new $type42
        (struct.new $environment35
         (local.get $3)
        )
       )
      )
      (struct.set $type43 0
       (local.get $3)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type43 0
         (local.get $3)
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type42 0
        (struct.get $type43 1
         (local.get $3)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready92)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global92)
       )
      )
      (call $function37
       (block (result (ref null $type14))
        (local.set $scratch_18
         (if (result (ref null $type14))
          (i64.eqz
           (local.get $0)
          )
          (then
           (ref.null none)
          )
          (else
           (if
            (i32.eqz
             (struct.get $type43 0
              (struct.get $environment35 0
               (local.get $1)
              )
             )
            )
            (then
             (unreachable)
            )
           )
           (local.set $1
            (struct.get $type42 0
             (struct.get $type43 1
              (struct.get $environment35 0
               (local.get $1)
              )
             )
            )
           )
           (if
            (i32.eqz
             (global.get $ready92)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global92)
            )
           )
           (local.set $2
            (struct.new $type14
             (local.get $0)
             (ref.null none)
            )
           )
           (if (result (ref null $type14))
            (i64.eqz
             (local.tee $15
              (i64.sub
               (local.get $0)
               (i64.const 1)
              )
             )
            )
            (then
             (local.get $2)
            )
            (else
             (if
              (i32.eqz
               (struct.get $type43 0
                (struct.get $environment35 0
                 (local.get $1)
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (local.set $1
              (struct.get $type42 0
               (struct.get $type43 1
                (struct.get $environment35 0
                 (local.get $1)
                )
               )
              )
             )
             (if
              (i32.eqz
               (global.get $ready92)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global92)
              )
             )
             (local.set $2
              (struct.new $type14
               (local.get $15)
               (local.get $2)
              )
             )
             (if (result (ref null $type14))
              (i64.eqz
               (local.tee $15
                (i64.sub
                 (local.get $15)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.get $2)
              )
              (else
               (if
                (i32.eqz
                 (struct.get $type43 0
                  (struct.get $environment35 0
                   (local.get $1)
                  )
                 )
                )
                (then
                 (unreachable)
                )
               )
               (local.set $1
                (struct.get $type42 0
                 (struct.get $type43 1
                  (struct.get $environment35 0
                   (local.get $1)
                  )
                 )
                )
               )
               (if
                (i32.eqz
                 (global.get $ready92)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global92)
                )
               )
               (local.set $2
                (struct.new $type14
                 (local.get $15)
                 (local.get $2)
                )
               )
               (if (result (ref null $type14))
                (i64.eqz
                 (local.tee $15
                  (i64.sub
                   (local.get $15)
                   (i64.const 1)
                  )
                 )
                )
                (then
                 (local.get $2)
                )
                (else
                 (if
                  (i32.eqz
                   (struct.get $type43 0
                    (struct.get $environment35 0
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (local.set $1
                  (struct.get $type42 0
                   (struct.get $type43 1
                    (struct.get $environment35 0
                     (local.get $1)
                    )
                   )
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready92)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global92)
                  )
                 )
                 (local.set $2
                  (struct.new $type14
                   (local.get $15)
                   (local.get $2)
                  )
                 )
                 (if (result (ref null $type14))
                  (i64.eqz
                   (local.tee $15
                    (i64.sub
                     (local.get $15)
                     (i64.const 1)
                    )
                   )
                  )
                  (then
                   (local.get $2)
                  )
                  (else
                   (if
                    (i32.eqz
                     (struct.get $type43 0
                      (struct.get $environment35 0
                       (local.get $1)
                      )
                     )
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (local.set $1
                    (struct.get $type42 0
                     (struct.get $type43 1
                      (struct.get $environment35 0
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready92)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global92)
                    )
                   )
                   (local.set $2
                    (struct.new $type14
                     (local.get $15)
                     (local.get $2)
                    )
                   )
                   (if (result (ref null $type14))
                    (i64.eqz
                     (local.tee $15
                      (i64.sub
                       (local.get $15)
                       (i64.const 1)
                      )
                     )
                    )
                    (then
                     (local.get $2)
                    )
                    (else
                     (if
                      (i32.eqz
                       (struct.get $type43 0
                        (struct.get $environment35 0
                         (local.get $1)
                        )
                       )
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (local.set $1
                      (struct.get $type42 0
                       (struct.get $type43 1
                        (struct.get $environment35 0
                         (local.get $1)
                        )
                       )
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready92)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global92)
                      )
                     )
                     (local.set $2
                      (struct.new $type14
                       (local.get $15)
                       (local.get $2)
                      )
                     )
                     (if (result (ref null $type14))
                      (i64.eqz
                       (local.tee $15
                        (i64.sub
                         (local.get $15)
                         (i64.const 1)
                        )
                       )
                      )
                      (then
                       (local.get $2)
                      )
                      (else
                       (if
                        (i32.eqz
                         (struct.get $type43 0
                          (struct.get $environment35 0
                           (local.get $1)
                          )
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (local.set $1
                        (struct.get $type42 0
                         (struct.get $type43 1
                          (struct.get $environment35 0
                           (local.get $1)
                          )
                         )
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready92)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global92)
                        )
                       )
                       (local.set $2
                        (struct.new $type14
                         (local.get $15)
                         (local.get $2)
                        )
                       )
                       (if (result (ref null $type14))
                        (i64.eqz
                         (local.tee $16
                          (i64.sub
                           (local.get $15)
                           (i64.const 1)
                          )
                         )
                        )
                        (then
                         (local.get $2)
                        )
                        (else
                         (if
                          (i32.eqz
                           (struct.get $type43 0
                            (struct.get $environment35 0
                             (local.get $1)
                            )
                           )
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (local.set $1
                          (struct.get $type42 0
                           (struct.get $type43 1
                            (struct.get $environment35 0
                             (local.get $1)
                            )
                           )
                          )
                         )
                         (local.set $15
                          (i64.sub
                           (local.get $16)
                           (i64.const 1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready92)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global92)
                          )
                         )
                         (local.set $2
                          (struct.new $type14
                           (local.get $16)
                           (local.get $2)
                          )
                         )
                         (if (result (ref null $type14))
                          (i64.eqz
                           (local.get $15)
                          )
                          (then
                           (local.get $2)
                          )
                          (else
                           (if
                            (i32.eqz
                             (struct.get $type43 0
                              (struct.get $environment35 0
                               (local.get $1)
                              )
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (call $function35
                            (struct.get $type42 0
                             (struct.get $type43 1
                              (struct.get $environment35 0
                               (local.get $1)
                              )
                             )
                            )
                            (i64.sub
                             (local.get $15)
                             (i64.const 1)
                            )
                            (struct.new $type14
                             (local.get $15)
                             (local.get $2)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (if
         (i32.eqz
          (global.get $ready94)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global94)
         )
        )
        (local.get $scratch_18)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready72)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global72)
     )
    )
    (if
     (i32.eqz
      (global.get $ready77)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global77)
     )
    )
    (local.set $5
     (struct.get $type24 0
      (local.tee $12
       (if (result (ref $type24))
        (if (result i32)
         (i64.gt_s
          (local.get $0)
          (i64.const 0)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready77)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global77)
           )
          )
          (i32.const 1)
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (struct.set $type37 1
          (local.tee $4
           (struct.new_default $type37)
          )
          (struct.new $type38
           (struct.new $environment33
            (local.tee $10
             (struct.new $type36
              (i32.const 1)
              (array.new_default $type12
               (i32.const 4)
              )
             )
            )
            (local.get $0)
            (local.get $4)
           )
          )
         )
         (struct.set $type37 0
          (local.get $4)
          (i32.const 1)
         )
         (if
          (i32.eqz
           (struct.get $type37 0
            (local.get $4)
           )
          )
          (then
           (unreachable)
          )
         )
         (drop
          (call $function33
           (struct.get $type38 0
            (struct.get $type37 1
             (local.get $4)
            )
           )
           (i64.const 0)
           (i64.const 3)
          )
         )
         (struct.new $type24
          (struct.get $type36 1
           (local.get $10)
          )
          (struct.new $type25
           (struct.new $environment45
            (local.get $4)
            (i64.const 4)
            (i64.const 1)
            (struct.new $type39
             (i32.const 1)
             (struct.new $type10
              (struct.new $environment31
               (i64.const 4)
               (local.get $10)
               (i64.const 1)
              )
             )
            )
            (local.get $10)
           )
          )
         )
        )
        (else
         (unreachable)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type30 0
     (struct.get $type28 2
      (global.get $global130)
     )
     (block (result (ref $type12))
      (if
       (i32.eqz
        (global.get $ready135)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global135)
       )
      )
      (if (result (ref $type12))
       (i64.eqz
        (local.tee $0
         (i64.extend_i32_u
          (array.len
           (local.get $5)
          )
         )
        )
       )
       (then
        (array.new_fixed $type12 0)
       )
       (else
        (if
         (i64.gt_u
          (local.get $0)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (local.set $6
         (array.new $type12
          (array.get $type12
           (local.get $5)
           (i32.const 0)
          )
          (i32.wrap_i64
           (local.get $0)
          )
         )
        )
        (if
         (i64.gt_u
          (local.get $0)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (array.copy $type12 $type12
         (local.get $6)
         (i32.const 0)
         (local.get $5)
         (i32.const 0)
         (i32.wrap_i64
          (local.get $0)
         )
        )
        (local.get $6)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type30 0
     (struct.get $type28 3
      (global.get $global130)
     )
     (block (result (ref $type12))
      (if
       (i32.eqz
        (struct.get $type37 0
         (struct.get $environment45 0
          (local.tee $11
           (struct.get $type25 0
            (struct.get $type24 1
             (local.get $12)
            )
           )
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call $function33
        (struct.get $type38 0
         (struct.get $type37 1
          (struct.get $environment45 0
           (local.get $11)
          )
         )
        )
        (i64.const 3)
        (i64.const 4)
       )
      )
      (struct.set $type41 1
       (local.tee $7
        (struct.new_default $type41)
       )
       (struct.new $type40
        (ref.func $function32)
        (struct.new $environment32
         (i64.const 4)
         (struct.get $environment31 1
          (struct.get $type10 0
           (struct.get $type39 1
            (struct.get $environment45 3
             (local.get $11)
            )
           )
          )
         )
         (i64.const 1)
         (local.get $7)
        )
       )
      )
      (struct.set $type41 0
       (local.get $7)
       (i32.const 1)
      )
      (if
       (i32.eqz
        (struct.get $type41 0
         (local.get $7)
        )
       )
       (then
        (unreachable)
       )
      )
      (drop
       (call_ref $call40
        (struct.get $type40 1
         (local.tee $14
          (ref.as_non_null
           (struct.get $type41 1
            (local.get $7)
           )
          )
         )
        )
        (i64.const 0)
        (struct.get $type40 0
         (local.get $14)
        )
       )
      )
      (struct.get $type36 1
       (struct.get $environment45 4
        (local.get $11)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready130)
     )
     (then
      (unreachable)
     )
    )
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (ref.eq
        (local.get $5)
        (struct.get $type30 0
         (struct.get $type28 3
          (global.get $global130)
         )
        )
       )
       (then
        (if
         (i32.eqz
          (global.get $ready130)
         )
         (then
          (unreachable)
         )
        )
        (i32.eqz
         (ref.eq
          (local.get $5)
          (struct.get $type30 0
           (struct.get $type28 2
            (global.get $global130)
           )
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
      (i32.const 0)
     )
    )
   )
   (else
    (unreachable)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready131)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global131)
   )
  )
  (return_call $function51
   (local.get $0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type11)
  )
  (global.set $ready135
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type15)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global92
   (struct.new_default $type16)
  )
  (global.set $ready92
   (i32.const 1)
  )
  (global.set $global77
   (struct.new_default $type16)
  )
  (global.set $ready77
   (i32.const 1)
  )
  (global.set $global94
   (struct.new_default $type20)
  )
  (global.set $ready94
   (i32.const 1)
  )
  (global.set $global87
   (struct.new_default $type22)
  )
  (global.set $ready87
   (i32.const 1)
  )
  (global.set $global72
   (struct.new_default $type27)
  )
  (global.set $ready72
   (i32.const 1)
  )
  (global.set $global130
   (struct.new $type28
    (struct.new_default $type29)
    (struct.new_default $type29)
    (struct.new $type30
     (array.new_fixed $type12 0)
    )
    (struct.new $type30
     (array.new_fixed $type12 0)
    )
   )
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global131
   (struct.new_default $type31)
  )
  (global.set $ready131
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

