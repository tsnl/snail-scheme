;; Diagnostic-only additions to the generated module, before assembly and -O3.
;; These functions are not emitted by the Scheme compiler and do not establish
;; support for managed Scheme imports or exports. All public results are scalar.
;; $global130 is the four-field SharingWitness value; checked in layouts.json.

(func $diagnostic-entry (param $values (ref null $type13)) (param $index i32)
  (result (ref null $type14))
  (if (result (ref null $type14)) (i32.eqz (local.get $index))
    (then (struct.get $type13 0 (local.get $values)))
    (else (return_call $diagnostic-entry
      (struct.get $type13 1 (local.get $values))
      (i32.sub (local.get $index) (i32.const 1))))))

(func $diagnostic-tail (param $values (ref null $type14)) (param $index i32)
  (result (ref null $type14))
  (if (result (ref null $type14)) (i32.eqz (local.get $index))
    (then (local.get $values))
    (else (return_call $diagnostic-tail
      (struct.get $type14 1 (local.get $values))
      (i32.sub (local.get $index) (i32.const 1))))))

(func $diagnostic-sharing (export "sharing-check") (result i32)
  (local $first (ref null $type13)) (local $second (ref null $type13))
  (local $before (ref null $type12)) (local $after (ref null $type12))
  (local $flags i32)
  (local.set $first (struct.get $type29 0 (struct.get $type28 0 (global.get $global130))))
  (local.set $second (struct.get $type29 0 (struct.get $type28 1 (global.get $global130))))
  (local.set $before (struct.get $type30 0 (struct.get $type28 2 (global.get $global130))))
  (local.set $after (struct.get $type30 0 (struct.get $type28 3 (global.get $global130))))
  ;; The last two grey-code permutations reverse two elements and share tail 1.
  (local.set $flags (ref.eq
    (call $diagnostic-tail (call $diagnostic-entry (local.get $first) (i32.const 0)) (i32.const 2))
    (call $diagnostic-tail (call $diagnostic-entry (local.get $first) (i32.const 1)) (i32.const 2))))
  ;; Separate generations have equal values and distinct list roots/tails.
  (local.set $flags (i32.or (local.get $flags) (i32.shl
    (i32.eqz (ref.eq (local.get $first) (local.get $second))) (i32.const 1))))
  (local.set $flags (i32.or (local.get $flags) (i32.shl
    (i32.eqz (ref.eq
      (call $diagnostic-tail (call $diagnostic-entry (local.get $first) (i32.const 0)) (i32.const 2))
      (call $diagnostic-tail (call $diagnostic-entry (local.get $second) (i32.const 0)) (i32.const 2))))
    (i32.const 2))))
  ;; K=4,L=1 shifts the old second and third roots without copying their pairs.
  (local.set $flags (i32.or (local.get $flags) (i32.shl (ref.eq
    (array.get $type12 (local.get $before) (i32.const 1))
    (array.get $type12 (local.get $after) (i32.const 0))) (i32.const 3))))
  (local.set $flags (i32.or (local.get $flags) (i32.shl (ref.eq
    (array.get $type12 (local.get $before) (i32.const 2))
    (array.get $type12 (local.get $after) (i32.const 1))) (i32.const 4))))
  ;; The newly filled root is fresh with respect to every surviving old root.
  (local.set $flags (i32.or (local.get $flags) (i32.shl (i32.eqz (ref.eq
    (array.get $type12 (local.get $before) (i32.const 0))
    (array.get $type12 (local.get $after) (i32.const 2)))) (i32.const 5))))
  (local.set $flags (i32.or (local.get $flags) (i32.shl (i32.eqz (ref.eq
    (array.get $type12 (local.get $before) (i32.const 1))
    (array.get $type12 (local.get $after) (i32.const 2)))) (i32.const 6))))
  (local.set $flags (i32.or (local.get $flags) (i32.shl (i32.eqz (ref.eq
    (array.get $type12 (local.get $before) (i32.const 2))
    (array.get $type12 (local.get $after) (i32.const 2)))) (i32.const 7))))
  (local.set $flags (i32.or (local.get $flags) (i32.shl
    (ref.is_null (array.get $type12 (local.get $after) (i32.const 3))) (i32.const 8))))
  (i32.or (local.get $flags) (i32.shl
    (ref.is_null (array.get $type12 (local.get $before) (i32.const 3))) (i32.const 9))))
