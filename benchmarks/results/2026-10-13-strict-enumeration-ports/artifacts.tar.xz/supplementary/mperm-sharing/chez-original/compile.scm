(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-graphs-mperm-20261013/build/enumeration-sharing-witness/chez-original/program.scm" "/tmp/snail-strict-graphs-mperm-20261013/build/enumeration-sharing-witness/chez-original/program.so"))
