import fs from 'node:fs';
import assert from 'node:assert/strict';

const {instance} = await WebAssembly.instantiate(fs.readFileSync(process.argv[2]));
instance.exports.main();
assert.equal(instance.exports['sharing-prepare'](3n), 1n);
const flags = instance.exports['sharing-check']();
assert.equal(flags, 1023);
console.log(JSON.stringify({flags, checks: 10, vectorIdentityChecks: 2}));
