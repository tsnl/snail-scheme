"""Record static evidence from the frozen canonical modules; execute no kernels."""

from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from data_ports import form


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def located_form(source, prefix):
    body = form(source, prefix)
    line = source.count('\n', 0, source.index(prefix)) + 1
    return dict(start_line=line, end_line=line + body.count('\n'), text=body)


def describe_function(source, name, role, origins):
    prefix = re.search(r'\(func ' + re.escape(name) + r'\s', source).group()
    result = located_form(source, prefix)
    body = result.pop('text')
    instructions = re.findall(r'\((array\.[\w_]+|struct\.[\w_]+|call|call_ref|return_call|return_call_ref|ref\.is_null|i64\.div_s)\b', body)
    return dict(function=name, role=role, source_origin=origins.get(name), **result,
                static_instruction_sites=dict(sorted(Counter(instructions).items())),
                direct_call_targets=re.findall(r'\((?:call|return_call) (\$[\w]+)', body),
                referenced_functions=re.findall(r'\(ref\.func (\$[\w]+)', body))


def source_origins(name):
    result = {}
    for line in (ROOT / 'audit' / (name + '-function-map.tsv')).read_text().splitlines():
        kind, *values = line.split('\t')
        if kind == 'function':
            number, line, column, path = values
            result['$function' + number] = dict(path=path, line=int(line), column=int(column))
    return result


def describe_case(name, roles, layouts):
    directory = ROOT / name
    raw, optimized = [(directory / filename).read_text() for filename in ('strict.wasm.wat', 'strict.optimized.wat')]
    result = dict(hashes={filename: digest(directory / filename) for filename in
                  ('strict.scm', 'strict.wasm.raw.wasm', 'strict.wasm', 'strict.optimized.wat')},
                  exports=re.findall(r'\(export "([^"]+)"', optimized),
                  functions=[describe_function(optimized, label, role, source_origins(name)) for label, role in roles.items()],
                  layouts={role: dict(raw=form(raw, '(type ' + label + ' '),
                                      optimized=form(optimized, '(type ' + label + ' ')) for label, role in layouts.items()})
    assert result['exports'] == ['bench', 'main']
    return result


GRAPH_ROLES = {
    '$function30': 'proc->vector: allocate and initialize a fresh vector of adjacency lists',
    '$function36': 'proc->vector element fill loop',
    '$function38': 'permutation branch comparison and continuation selection',
    '$function40': 'next-vertex comparison scan',
    '$function44': 'continuation-passing permutation tree fold',
    '$function51': 'reachability row initialization',
    '$function54': 'Boolean matrix allocation and initialization',
    '$function61': 'reachability outer traversal',
    '$function62': 'reachability edge traversal',
    '$function63': 'reachability update traversal',
    '$function65': 'reachability list traversal',
    '$function73': 'vertex enumeration',
    '$function74': 'root outgoing-edge enumeration and accepted result construction',
    '$function78': 'existential traversal of equivalent root-reachability rows',
    '$function80': 'all-vertices-root-reachable traversal',
    '$function81': 'read current adjacency row for accepted result vector',
    '$function82': 'non-root outgoing-edge enumeration and backtracking',
    '$function84': 'canonical repeat worker: enumerate and compute list length on every invocation',
    '$function87': 'result-list length traversal on each invocation',
}
GRAPH_LAYOUTS = {
    '$type13': 'I64 adjacency-list node', '$type14': 'adjacency-list vector',
    '$type16': 'reachability-row list', '$type17': 'Boolean row vector',
    '$type18': 'Boolean matrix', '$type24': 'graph-result list node',
    '$type48': 'I64 permutation/outdegree vector',
}
MPERM_ROLES = {
    '$function26': 'sumlists outer permutation traversal',
    '$function27': 'sumlists inner integer traversal',
    '$function32': 'flush: shift queue entries left, then clear trailing slots',
    '$function33': 'fill: construct each entire permutation batch before publishing it into its queue slot',
    '$function35': 'one..n input-list construction',
    '$function40': 'P recursive prefix-reversal generator',
    '$function41': 'P repeated prefix-reversal loop',
    '$function42': 'F prefix flip and outer permutation-list accumulation',
    '$function43': 'list-tail traversal preserving the unchanged suffix',
    '$function44': 'revloop prefix cons allocation',
    '$function45': 'work thunk: fill [K-L,K), flush, return the same queue',
    '$function46': 'final predicate: first-permutation equality and full sum traversal',
    '$function47': 'factorial for expected sum',
    '$function50': 'complete equality of two I64 permutations',
    '$function53': 'bench: obtain plan closures, repeat work, call predicate once',
    '$function54': 'canonical repeat loop',
    '$main': 'allocate queue, fill [0,K-L), and publish the work/predicate plan before bench',
}
MPERM_LAYOUTS = {
    '$type12': 'inner I64 permutation list', '$type16': 'outer permutation list',
    '$type20': 'queue array', '$type22': 'work/predicate plan',
    '$type33': 'queue binding storage', '$type42': 'Ref current permutation',
    '$type44': 'Ref accumulated permutations',
    '$environment33': 'fill environment with queue binding',
    '$environment45': 'work environment with fill, flush and queue binding',
}

graphs = describe_case('graphs', GRAPH_ROLES, GRAPH_LAYOUTS)
graphs.update(
    retained='Permutation/CPS enumeration, mutable Boolean matrices, adjacency and reachability traversals, backtracking, fresh accepted-result vector allocation/fill, result-list spines, final length and repeats.',
    eliminated='The graph-result list head is absent in optimized $type24. The freshly constructed result vector is discarded before the cdr-only list node is allocated; completed result graphs are no longer retained by that list.',
    allocation_claim='Static Wasm still constructs each accepted vector. No V8 machine-code inspection or dynamic allocation count establishes whether the engine performs further elimination.',
    later_timing_scope='Candidate for count-producing source-program timing after independent review; no equal-allocation or equal-live-result-graph claim.')
graph_wat = (ROOT / 'graphs/strict.optimized.wat').read_text()
accepted = form(graph_wat, '(func $function74 ')
assert '(call $function30' in accepted and '(struct.new $type24' in accepted
graphs['accepted_result_sequence'] = dict(
    function='$function74', ordering=['store root adjacency row', 'call $function30 and discard its fresh result vector', 'allocate cdr-only $type24 result-list node'],
    evidence_lines=[4197, 4227, 4242])

mperm = describe_case('mperm', MPERM_ROLES, MPERM_LAYOUTS)
mperm_wat = (ROOT / 'mperm/strict.optimized.wat').read_text()
fill, work = [form(mperm_wat, '(func $function' + str(number) + ' ') for number in (33, 45)]
assert fill.count('(array.set $type20') == 1
assert work.index('(call $function33') < work.index('(ref.func $function32')
mperm.update(
    retained='Input lists, all prefix reversal and shared-tail traversal, two explicit mutable cells per generator call, inner/outer list payloads, queue publication and shift/clear stores, final first-permutation comparison and full sum traversal.',
    canonical_root_path=['$global145 -> $type22 plan work field', '$type19 work closure -> $environment45', '$environment45 field 4 -> $type33 queue binding', '$type33 field 1 -> $type20 mutable queue array', '$type20 slots -> $type16 outer nodes -> $type12 inner nodes and cdr tails'],
    order_and_overlap='main allocates the queue and fills [0,K-L) before storing the plan. Each work call fills [K-L,K) before invoking flush. Fill has exactly one queue store, after the newly generated batch is complete. For K=2,L=1, queue[0] still strongly references the preceding batch during construction of queue[1]; flush then shifts queue[1] to queue[0] and clears queue[1].',
    source_schedule='The implementation generates K-L setup batches and M*L timed batches. Canonical M=20,N=10,K=2,L=1 means 1 setup plus 20 timed batches.',
    source_pair_counts='Per batch: N initial list pairs + N! outer pairs + F(N) prefix pairs, F(1)=0 and F(N)=N*F(N-1)+N*(N-1). N=10 gives 13,492,900 source pair constructions. This excludes explicit cells and closure/binding storage and is not a runtime allocator measurement.',
    rooting_limits='This establishes the reachable graph and fill-before-flush order in the exact optimized Wasm. It does not measure V8 machine-code liveness, heap high-water marks, allocation count, or original/adapted Chez retention.',
    later_timing_scope='Candidate for original queue/permutation source-program timing after independent review; no clean observations at this checkpoint.')
mperm['plan_global'] = form(mperm_wat, '(global $global145 ')
mperm['ordering_evidence_lines'] = dict(queue_allocation=5532, initial_fill=5559, work_fill=3120,
                                        fill_publish=1192, flush_loop=269, plan_store=5447)
prefix_pairs, counts = 0, []
for n in range(1, 11):
    prefix_pairs = n * prefix_pairs + n * (n - 1)
    counts.append(dict(n=n, initial_pairs=n, outer_pairs=math.factorial(n),
                       prefix_pairs=prefix_pairs, total=n + math.factorial(n) + prefix_pairs))
assert [item['total'] for item in counts[:6]] == [2, 6, 21, 88, 445, 2676]
assert counts[-1]['total'] == 13492900
mperm['source_pair_count_derivation'] = counts

result = dict(
    evidence_kind='Static source/layout inspection of exact canonical optimized Wasm, supplemented by source maps and isolated identity checks; not dynamic allocation or machine-code evidence.',
    compiler_commit='a4030ce190058db3e9d64f6942401b5fa38dbd58',
    driver_commit='37e11e67a0fbc7b3c9bd336d4f1f4f7f03d2833b',
    function_map_note='Macro-expanded do loops point to the macro-definition site in src/snail/strict.sld. Roles combine these source maps with the complete source and inspected call graph.',
    probe_isolation='Canonical modules export only bench and main. Supplemental encoders and the hand-written scalar Wasm identity observer are separate modules and do not root canonical fields.',
    performance_samples=0, cases=dict(graphs=graphs, mperm=mperm))
(ROOT / 'retention-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print('Recorded frozen graphs/mperm retention audit.')
