;; Read-only map from emitted function/global indices to located source.
(import (scheme base) (scheme process-context) (scheme write)
        (snail-scheme strict-compiler) (snail-scheme strict-specialize)
        (snail-scheme chromium-trace)
        (only (snail-scheme ir) node-loc value-definition-name)
        (snail-scheme source))
(define arguments (cdr (command-line)))
(define program
  (with-chromium-trace-to (car (cdr (cdr arguments)))
    (lambda ()
      (monomorphize (strict-source-file->core (car arguments) (cadr arguments)) 'bench))))
(for-each
 (lambda (function)
   (let ((loc (node-loc (function-source function))))
     (display "function\t") (display (function-index function)) (display "\t")
     (display (loc-line loc)) (display "\t") (display (loc-column loc))
     (display "\t") (display (loc-filename loc)) (newline)))
 (mono-program-functions program))
(for-each
 (lambda (value)
   (display "global\t") (display (value-index value)) (display "\t")
   (display (value-definition-name (site-source (value-site value)))) (newline))
 (site-values (mono-program-globals program)))
