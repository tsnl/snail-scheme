(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define-extern native-expected-length "benchmark" "expected_length" (-> I64))
(define-extern native-expected-i64 "benchmark" "expected_i64" (-> I64 I64))
(define (expected-list)
  (let loop ((n (native-expected-length)) (xs '()))
    (if (= n 0) xs
        (loop (- n 1) (cons (native-expected-i64 (- n 1)) xs)))))
(: same-i64-list? (-> (List I64) (List I64) Bool))
(define (same-i64-list? xs ys)
  (if (null? xs) (null? ys)
      (and (not (null? ys)) (= (car xs) (car ys))
           (same-i64-list? (cdr xs) (cdr ys)))))
(define (integer-zero? n) (= n 0))
(define (integer-positive? n) (> n 0))
(define (integer-max a b) (if (> a b) a b))
(define (nonempty-list? value) (not (null? value)))
(define (equal-permutation? left right)
  (if (null? left) (null? right)
      (and (not (null? right)) (= (car left) (car right))
           (equal-permutation? (cdr left) (cdr right)))))
(define-data QueueProbe
  (capture-queue
    (queue (Vector (List (List I64))) captured-queue)
    (work (-> (Vector (List (List I64)))) captured-work)
    (accept (-> (Vector (List (List I64))) Bool) captured-accept)))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; File:         perm9.sch
;; Description:  memory system benchmark using Zaks's permutation generator
;; Author:       Lars Hansen, Will Clinger, and Gene Luks
;; Created:      18-Mar-94
;; Language:     Scheme
;; Status:       Public Domain
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; 940720 / lth Added some more benchmarks for the thesis paper.
;; 970215 / wdc Increased problem size from 8 to 9; improved tenperm9-benchmark.
;; 970531 / wdc Cleaned up for public release.
;; 000820 / wdc Added the MpermNKL benchmark; revised for new run-benchmark.
;; 071127 / wdc Simplified and ported for R6RS.


;; This benchmark is in three parts.  Each tests a different aspect of
;; the memory system.
;;
;;    storage allocation (while generating no garbage)
;;    storage allocation and garbage collection at equilibrium
;;    traversal of a large, linked, self-sharing structure
;;
;; The perm9 benchmark generates a list of all 362880 permutations of
;; the first 9 integers, allocating 1349288 pairs (typically 10,794,304
;; bytes), all of which goes into the generated list.  (That is, the
;; perm9 benchmark generates absolutely no garbage.)  This represents
;; a savings of about 63% over the storage that would be required by
;; an unshared list of permutations.  The generated permutations are
;; in order of a grey code that bears no obvious relationship to a
;; lexicographic order.
;;
;; The tenperm9 benchmark repeats the perm9 benchmark 10 times, so it
;; allocates and reclaims 13492880 pairs (typically 107,943,040 bytes).
;; The live storage peaks at twice the storage that is allocated by the
;; perm9 benchmark.  At the end of each iteration, the oldest half of
;; the live storage becomes garbage.  Object lifetimes are distributed
;; uniformly between 10.3 and 20.6 megabytes.
;;
;; The tenperm9 benchmark is the perm10:9:2:1 special case of the
;; MpermNKL benchmark, which allocates a queue of size K and then
;; performs M iterations of the following operation:  Fill the queue
;; with individually computed copies of all permutations of a list of
;; size N, and then remove the oldest L copies from the queue.  At the
;; end of each iteration, the oldest L/K of the live storage becomes
;; garbage, and object lifetimes are distributed uniformly between two
;; volumes that depend upon N, K, and L.
;;
;; As a check on the result, and to preclude overly sophisticated
;; compiler optimizations,  we compute the sum of the permuted
;; integers over all permutations.
;;
;; The benchmarks are run by calling the following procedure:
;;
;;    (MpermNKL-benchmark M N K L)
;;
;; This benchmark assumes that
;;
;;    (RUN-BENCHMARK <string> <count> <thunk> <predicate>)
;;
;; reports the time required to call <thunk> the number of times
;; specified by <count>, and uses <predicate> to test whether the
;; result returned by <thunk> is correct.

;; Date: Thu, 17 Mar 94 19:43:32 -0800
;; From: luks@sisters.cs.uoregon.edu
;; To: will
;; Subject: Pancake flips
;;
;; Procedure P_n generates a grey code of all perms of n elements
;; on top of stack ending with reversal of starting sequence
;;
;; F_n is flip of top n elements.
;;
;;
;; procedure P_n
;;
;;   if n>1 then
;;     begin
;;        repeat   P_{n-1},F_n   n-1 times;
;;        P_{n-1}
;;     end
;;

(define (permutations x)
  (let ((x (ref x))
        (perms (ref (cons x '()))))
    (define (P n)
      (when (> n 1)
        (do ((j (- n 1) (- j 1)))
            ((integer-zero? j)
             (P (- n 1)))
          (P (- n 1))
          (F n))))
    (define (F n)
      (ref-set! x (revloop (ref-get x) n (list-tail (ref-get x) n)))
      (ref-set! perms (cons (ref-get x) (ref-get perms))))
    (define (revloop x n y)
      (if (integer-zero? n)
          y
          (revloop (cdr x)
                   (- n 1)
                   (cons (car x) y))))
    (define (list-tail x n)
      (if (integer-zero? n)
          x
          (list-tail (cdr x) (- n 1))))
    (P (length (ref-get x)))
    (ref-get perms)))

;; Given a list of lists of numbers, returns the sum of the sums
;; of those lists.
;;
;; for (; x != NULL; x = x->rest)
;;     for (y = x->first; y != NULL; y = y->rest)
;;         sum = sum + y->first;

(define (sumlists x)
  (do ((x x (cdr x))
       (sum 0 (do ((y (car x) (cdr y))
                   (sum sum (+ sum (car y))))
                  ((null? y) sum))))
      ((null? x) sum)))

(define (one..n n)
  (do ((n n (- n 1))
       (p '() (cons n p)))
      ((integer-zero? n) p)))

(define (tenperm . rest)
  (let ((n (if (null? rest) 9 (car rest))))
    (MpermNKL-benchmark 10 n 2 1)))

(define (MpermNKL-benchmark m n k ell)
  (if (and (<= 0 m)
           (integer-positive? n)
           (integer-positive? k)
           (and (<= 0 ell) (<= ell k)))
      (let ((queue (make-vector k '())))

        ;; Fills queue positions [i, j).

        (define (fill-queue i j)
          (when (< i j)
            (vector-set! queue i (permutations (one..n n)))
            (fill-queue (+ i 1) j)))

        ;; Removes ell elements from queue.

        (define (flush-queue)
          (let loop ((i 0))
            (when (< i k)
              (vector-set! queue
                           i
                           (let ((j (+ i ell)))
                             (if (< j k)
                                 (vector-ref queue j)
                                 '())))
              (loop (+ i 1)))))

        (fill-queue 0 (- k ell))
        (capture-queue queue
                       (lambda ()
                         (fill-queue (- k ell) k)
                         (flush-queue)
                         queue)
                       (lambda (q)
                         (define (factorial n)
                           (if (= n 0)
                               1
                               (* n (factorial (- n 1)))))
                         (let ((q0 (vector-ref q 0))
                               (qi (vector-ref q (integer-max 0 (- (- k ell) 1)))))
                           (and (or (and (null? q0) (null? qi))
                                    (and (nonempty-list? q0)
                                         (nonempty-list? qi)
                                         (equal-permutation? (car q0) (car qi))))
                                (= (sumlists q0)
                                   (quotient (* (* n (+ n 1)) (factorial n)) 2)))))))
      (unreachable)))



(define (encode-values values tail)
  (if (null? values) tail
      (cons (car values) (encode-values (cdr values) tail))))
(define (encode-permutation values tail)
  (cons (length values) (encode-values values tail)))
(define (encode-permutations values tail)
  (define (visit values)
    (if (null? values) tail
        (encode-permutation (car values) (visit (cdr values)))))
  (cons (length values) (visit values)))
(define (encode-queue queue tail)
  (let loop ((index (- (vector-length queue) 1)) (result tail))
    (if (< index 0) (cons (vector-length queue) result)
        (loop (- index 1) (encode-permutations (vector-ref queue index) result)))))
(define (queue-history m n k ell)
  (let* ((plan (MpermNKL-benchmark m n k ell))
         (queue (captured-queue plan)) (work (captured-work plan)))
    (let loop ((left m) (initial (encode-queue queue '())))
      (if (= left 0)
          (append-values initial (cons (if ((captured-accept plan) queue) 1 0) '()))
          (let ((result (work)))
            (if (not (vector-eq? result queue)) (unreachable)
                (append-values initial (loop (- left 1) (encode-queue result '())))))))))
(define (append-values left right)
  (if (null? left) right (cons (car left) (append-values (cdr left) right))))
(define (change-permutation-sum values)
  (cons (car values)
        (cons (cons (+ 1 (car (car (cdr values)))) (cdr (car (cdr values))))
              (cdr (cdr values)))))
(define (change-first-permutation values)
  (let ((first (car values)))
    (cons (cons (car (cdr first)) (cons (car first) (cdr (cdr first)))) (cdr values))))
(define (predicate-result mode n k ell)
  (let* ((plan (MpermNKL-benchmark 1 n k ell)) (queue ((captured-work plan)))
         (first (vector-ref queue 0)) (last (integer-max 0 (- (- k ell) 1))))
    (cond ((= mode 1) (vector-set! queue 0 (change-permutation-sum first)))
          ((= mode 2) (vector-set! queue 0 (change-first-permutation first)))
          ((= mode 3) (vector-set! queue last '()))
          ((= mode 4) (vector-set! queue 0 '()))
          ((= mode 5) (vector-set! queue 0 '()) (vector-set! queue last '()))
          (else (unit)))
    (if ((captured-accept plan) queue) 1 0)))
(define input0 (native-input-i64 (ann 0 I32)))
(define input1 (native-input-i64 (ann 1 I32)))
(define input2 (native-input-i64 (ann 2 I32)))(: enumeration-probe (-> I64 I64))
(define (enumeration-probe count)
  (if (same-i64-list? (encode-permutations (permutations (one..n input0)) '())
                    (expected-list)) 1 0))
(: queue-probe (-> I64 I64))
(define (queue-probe count)
  (if (same-i64-list? (queue-history count input0 input1 input2) (expected-list)) 1 0))
(: predicate-probe (-> I64 I64))
(define (predicate-probe mode)
  (if (same-i64-list? (cons (predicate-result mode input0 input1 input2) '())
                    (expected-list)) 1 0))

(unit)
