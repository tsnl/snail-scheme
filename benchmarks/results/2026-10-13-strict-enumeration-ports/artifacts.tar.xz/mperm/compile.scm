(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-enumeration-preparation-20261013/mperm/program.scm" "/tmp/snail-strict-enumeration-preparation-20261013/mperm/program.so"))
