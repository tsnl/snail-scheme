# R7RS suite

Upstream `85f6acdc4cc4e2b857f307ba56bd0ba931dcccd1` · 3 rounds · original inputs

Build/startup excluded. Each successful result passed the upstream result predicate.

| Benchmark | roundtrip | reuse-environment |
| --- | ---: | ---: |
| [cat](plots/cat.svg) | 22.6964s | 22.3703s |
