(import (scheme base) (snail-scheme build) (snail-scheme chromium-trace))
(with-chromium-trace-to "/tmp/snail-v8-gc-20261012/build/v8-worst-five/cases/deriv/snail-wasm/build.trace.json" (lambda ()
(build-wasm "/tmp/snail-v8-gc-20261012" "/tmp/snail-v8-gc-20261012/build/v8-worst-five/cases/deriv/snail-wasm/program.scm" "/tmp/snail-v8-gc-20261012/build/v8-worst-five/cases/deriv/snail-wasm/program.wasm")))
