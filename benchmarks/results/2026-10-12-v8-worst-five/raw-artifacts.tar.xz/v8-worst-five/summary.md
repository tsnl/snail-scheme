# R7RS suite

Upstream `85f6acdc4cc4e2b857f307ba56bd0ba931dcccd1` · 3 rounds · original inputs

Build/startup excluded. Each successful result passed the upstream result predicate.

| Benchmark | snail-wasm | chez |
| --- | ---: | ---: |
| [cat](plots/cat.svg) | 22.8015s | 0.704918s |
| [lattice](plots/lattice.svg) | 25.3604s | 1.16989s |
| [wc](plots/wc.svg) | 12.3662s | 0.651656s |
| [graphs](plots/graphs.svg) | 12.5125s | 0.771317s |
| [deriv](plots/deriv.svg) | 6.04233s | 0.418318s |
