(import (scheme base) (scheme file) (scheme write) (scheme process-context) (srfi 1) (srfi 95)
        (except (chibi filesystem) file-exists?)
        (only (chibi string) string-prefix? string-suffix? string-split)
        (wasm-native process) (sfir support))

;; ---- Fixed evidence, with local originals left intact ----

(define root "/tmp/snail-native-sweep-evidence-20261016")
(define preparation "/tmp/sfir-native-production-six-20261016/candidate")
(define coordinator "/tmp/snail-native-proof-evidence-20261016/build")
(define campaign "/tmp/sfir-native-sweep-probes-paired-20261016")
(define output (cadr (command-line)))
(define files '())
(define filtered '())
(define origins '())
(when (file-exists? output) (error "choose a new evidence directory" output))
(create-directory* output)

;; ---- Retain only the documented build and execution environment ----

(define environment-names
  '("PATH" "LANG" "LC_ALL" "TZ" "TMPDIR" "CHIBI_MODULE_PATH" "CHIBI_IGNORE_SYSTEM_PATH"
    "CC" "CXX" "AR" "AS" "LD" "NM" "RANLIB" "OBJCOPY" "OBJDUMP" "READELF" "STRIP"
    "RUSTC" "CARGO" "CARGO_HOME" "RUSTC_WRAPPER" "RUSTC_WORKSPACE_WRAPPER"
    "RUSTFLAGS" "CARGO_ENCODED_RUSTFLAGS" "CARGO_TARGET_DIR" "CARGO_BUILD_TARGET"
    "CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS" "CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER"
    "CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS" "CARGO_TARGET_WASM32_WASIP1_LINKER"
    "RUSTUP_HOME" "RUSTUP_TOOLCHAIN" "LD_LIBRARY_PATH" "LD_PRELOAD" "LIBRARY_PATH"
    "NIX_CC" "NIX_BINTOOLS" "NIX_LDFLAGS" "NIX_CFLAGS_COMPILE" "NIX_LD" "NIX_LD_LIBRARY_PATH"
    "NIX_ENFORCE_NO_NATIVE" "BINARYEN_CORES" "NODE_OPTIONS" "NODE_V8_COVERAGE" "SCHEMEHEAPDIRS"
    "SNAIL_NATIVE_SUPERVISOR" "SNAIL_NATIVE_LIBC" "SNAIL_NATIVE_GCC" "SNAIL_NATIVE_GC_INTERVAL"
    "SNAIL_GC_STATS" "SNAIL_GC_HEAP_BYTES" "SNAIL_GC_INITIAL_BYTES" "SNAIL_GC_MIN_BYTES"
    "SNAIL_NATIVE_CLEANUP_LOG" "SNAIL_NATIVE_TAIL_STRESS"
    "SNAIL_PROBE_MODE" "SNAIL_PROBE_CPU" "SNAIL_NATIVE_CPU" "SNAIL_PROCESS_RECORD"
    "CHIBI" "NODE" "CHEZ" "WASM_OPT" "WASM_AS" "WASM_DIS" "WASM_MERGE" "LLC" "LLVM_OPT"
    "TASKSET" "LDD" "GIT" "ENV" "REALPATH" "DATE" "TIMEOUT" "CP" "SHA256SUM"))

(define (environment-entry? entry)
  (member (symbol->string (car entry)) environment-names))

(define (filter-environment value)
  (cond ((vector? value) (list->vector (map filter-environment (vector->list value))))
        ((and (pair? value) (pair? (car value)) (symbol? (caar value)))
         (map (lambda (entry)
                (cons (car entry)
                      (if (and (memq (car entry) '(environment execution_environment))
                               (list? (cdr entry)))
                          (filter environment-entry? (cdr entry))
                          (filter-environment (cdr entry))))) value))
        (else value)))

(define (retain-json source destination relative)
  (let* ((original (read-json source)) (kept (filter-environment original)))
    (if (equal? original kept) (copy-file source destination)
        (begin (write-json destination kept)
               (set! filtered (cons `((file . ,relative) (original_sha256 . ,(file-sha256 source))) filtered))))))

(define (retain source relative)
  (unless (and (file-regular? source) (not (file-link? source)))
    (error "expected an ordinary evidence file" source))
  (let ((destination (path-join output relative)))
    (create-directory* (path-directory destination))
    ;; The prototype's textual environment is already explicit. Refuse an
    ;; unknown field instead of copying an ambient credential into the archive.
    (when (string-suffix? "/environment.tsv" source)
      (for-each (lambda (line)
                  (unless (or (string=? line "") (member (car (string-split line #\tab)) environment-names))
                    (error "unreviewed textual environment field" source)))
                (string-split (read-text source) #\newline)))
    ;; Interrupted build traces are intentionally incomplete JSON. Preserve the
    ;; phase-event bytes, including their missing terminators, without parsing.
    (if (and (string-suffix? ".json" source) (not (string-suffix? ".trace.json" source))
             (> (file-size source) 0))
        (retain-json source destination relative)
        (copy-file source destination))
    (chmod destination (file-mode source))
    (set! files (cons relative files))
    (set! origins (cons `((archive_path . ,relative) (source_path . ,source)) origins))))

;; ---- Exclude caches and repeated working-directory input copies ----

(define (excluded-directory? name)
  (member name '("." ".." ".git" "build" "target" "targets" "unit-target"
                "rust-target" "toolchain" "cargo-home" "runs" "node_modules"
                "workload" "__pycache__")))

(define (retain-tree source relative)
  (for-each
   (lambda (name)
     (let ((path (path-join source name)) (destination (path-join relative name)))
       (unless (or (and (file-directory? path) (excluded-directory? name)) (file-link? path))
         (if (file-directory? path) (retain-tree path destination)
             (when (file-regular? path) (retain path destination))))))
   (sort (directory-files source) string<?)))

;; ---- One rejected probe, its frozen inputs and original command evidence ----

(retain-tree "/tmp/sfir-native-gc-trace-probe-20261016" "prototype")
(define source "/tmp/snail-native-gc-trace-probe-20261016")
(for-each (lambda (name) (retain-tree (path-join source name) (path-join "source" name)))
          '("src" "lib" "scripts"))
(for-each (lambda (name)
            (when (and (string-prefix? "native" name) (file-regular? (path-join source "tests" name)))
              (retain (path-join source "tests" name) (path-join "source/tests" name))))
          (directory-files (path-join source "tests")))
(define plan (read-json (path-join campaign "plan.json")))
(define frozen-files
  (delete-duplicates (append-map (lambda (row) (map (lambda (entry) (symbol->string (car entry))) (field row 'files)))
                                (json-array (field plan 'rows)))))
(for-each (lambda (name) (retain (path-join preparation name) (path-join "frozen-production" name))) frozen-files)
(retain (path-join preparation "manifest.json") "baseline-manifest.json")
(retain (path-join preparation "machine.json") "machine.json")
(retain-tree campaign "measurement")
(retain-tree (path-join coordinator "sweep-probe-run") "coordinator")
(for-each (lambda (name) (retain (path-join coordinator name) name))
          '("configure-sweep-probe.scm" "sweep-probe-configuration.json" "audit-sweep-probe.scm" "sweep-probe-decision.txt"))
(retain "/tmp/snail-native-shared-lto-evidence-20261016/build/observe-host.scm" "observe-host.scm")
(retain (path-join root "build/archive-sweep.scm") "archive-sweep.scm")
(retain (path-join root "build/review-sweep.scm") "review-sweep.scm")
(retain (path-join root "build/independent-evidence-review.json") "independent-evidence-review.json")

(write-json (path-join output "environment-filtering.json")
 `((policy . "Only the explicit build/runtime environment allowlist in archive-sweep.scm is published. Safe records retain original bytes; changed records retain original hashes below. Original local evidence is unchanged. The prototype textual environment is required to contain only allowlisted fields. Empty and interrupted setup JSON retains its original bytes. Caches, installed toolchains and repeated runs are omitted; their identities remain in manifests. The retained source snapshot and patches identify both arms; only native fixture sources needed for the recorded semantic checks are copied from the root tests directory.")
   (changed_records . ,(list->vector (reverse filtered)))))
(write-json (path-join output "archive-paths.json") (list->vector (reverse origins)))
(set! files (append '("environment-filtering.json" "archive-paths.json") files))
(write-text (path-join output "evidence-files.sha256")
            (run-command! (append '("sha256sum" "--") (sort files string<?)) `((directory . ,output))))
(display (length files)) (display " retained sweep evidence files\n")

