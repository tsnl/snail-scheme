fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-production-six-20261016/candidate/timing/artifacts/gcbench/program.native.native-814313-0/module.bc");
}
