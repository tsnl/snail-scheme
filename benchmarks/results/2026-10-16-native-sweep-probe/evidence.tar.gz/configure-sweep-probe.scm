(import (scheme base) (scheme file) (wasm-native process) (sfir support))

(define evidence "/tmp/sfir-native-gc-trace-probe-20261016")
(define review-path (path-join evidence "review.json"))
(define review (read-json review-path))
(define (native-arm name)
  (let* ((item (field review name)) (program (field item 'elf)))
    (unless (equal? (file-sha256 program) (field item 'sha256))
      (error "frozen sweep executable changed" name))
    `((case . "gcbench") (name . ,(string-append "sweep-" (symbol->string name)))
      (source_route . "sfir-native") (command . ,(vector program)))))
(define metadata
  (map (lambda (path) `((file . ,path) (sha256 . ,(file-sha256 path))))
       (list review-path (field review 'experiment_patch)
             (field (field review 'common_baseline) 'patch) (field review 'hash_manifest))))
(write-json
 "/tmp/snail-native-proof-evidence-20261016/build/sweep-probe-configuration.json"
 `((freeze . "/tmp/sfir-native-production-six-20261016/candidate") (cpu . 2)
   (quiet_window . "All task-owned builds, tests, profiling, archive and Git jobs are idle for this window. Five-second host process-name snapshots retain observed activity without unrelated arguments; no external-session quiet attestation. One warmup and five rotated fresh-process samples on CPU 2, uninstrumented binaries, unchanged canonical inputs/counts/predicates, no replacement samples. Both native arms include the same allocation-inline baseline, use the portable CPU default and retain the default GC policy. Only the sweep bitmap publication differs.")
   (experimental_metadata . ,(list->vector metadata))
   (arms . ,(vector (native-arm 'control) (native-arm 'candidate)
                     '((case . "gcbench") (name . "v8") (source_route . "sfir-wasm"))))))
