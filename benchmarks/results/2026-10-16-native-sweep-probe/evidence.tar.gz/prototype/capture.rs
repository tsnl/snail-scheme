use std::{env, fs::{self, File}, path::{Path, PathBuf}, process::{Command, Stdio}, time::Instant};

const ROOT: &str = "/tmp/sfir-native-gc-trace-probe-20261016";
const SOURCE: &str = "/tmp/snail-native-gc-trace-probe-20261016";
const SUPERVISOR: &str = "/tmp/sfir-native-production-six-20261016/candidate/toolchain/snail-native-supervisor";

fn hashes(attempt: &Path, name: &str, arguments: &[String]) {
    let mut files: Vec<String> = ["wasm-native/src/native.rs", "wasm-native/src/native_gc.rs", "wasm-native/scheme/wasm-native/llvm.sld"]
        .iter().map(|name| format!("{SOURCE}/{name}")).collect();
    files.extend(arguments.iter().filter(|name| Path::new(name).is_file()).cloned());
    let output = Command::new("sha256sum").args(files).output().unwrap();
    assert!(output.status.success());
    fs::write(attempt.join(name), output.stdout).unwrap();
}

fn environment(command: &mut Command, attempt: &Path) {
    for row in fs::read_to_string(format!("{ROOT}/environment.tsv")).unwrap().lines() {
        let cells: Vec<&str> = row.splitn(3, '\t').collect();
        if cells[1] == "U" { command.env_remove(cells[0]); }
        else { command.env(cells[0], cells[2]); }
    }
    command.env("CARGO_HOME", format!("{ROOT}/cargo-home"));
    command.env("RUSTC_WRAPPER", format!("{SOURCE}/wasm-native/scripts/rustc-native"));
    command.env("SNAIL_PROCESS_RECORD", attempt.join("process.json"));
    command.env_remove("SNAIL_NATIVE_CPU");
}

fn main() {
    let mut arguments: Vec<String> = env::args().skip(1).collect();
    let name = arguments.remove(0);
    let attempt = PathBuf::from(format!("{ROOT}/attempts/{name}"));
    fs::create_dir(&attempt).unwrap();
    let cwd = if arguments[0] == "--cwd" { arguments.remove(0); PathBuf::from(arguments.remove(0)) } else { attempt.clone() };
    hashes(&attempt, "before.sha256", &arguments);
    let mut command = Command::new(SUPERVISOR);
    command.args(["--command", "1800000", "--"]).args(&arguments).current_dir(&cwd);
    environment(&mut command, &attempt);
    command.stdin(File::open(format!("{ROOT}/inputs/input.txt")).unwrap());
    command.stdout(Stdio::from(File::create(attempt.join("stdout.bin")).unwrap()));
    command.stderr(Stdio::from(File::create(attempt.join("stderr.bin")).unwrap()));
    fs::write(attempt.join("command.txt"), format!("cwd: {cwd:?}\ncommand: {command:?}\ndiagnostic_only: true\n")).unwrap();
    let started = Instant::now();
    let status = command.status().unwrap();
    hashes(&attempt, "after.sha256", &arguments);
    fs::write(attempt.join("result.txt"), format!("exit: {status}\ndiagnostic_wall_seconds: {:.9}\n", started.elapsed().as_secs_f64())).unwrap();
    println!("{name}: {status}; uncontrolled diagnostic, {:.3}s", started.elapsed().as_secs_f64());
    std::process::exit(status.code().unwrap_or(1));
}
