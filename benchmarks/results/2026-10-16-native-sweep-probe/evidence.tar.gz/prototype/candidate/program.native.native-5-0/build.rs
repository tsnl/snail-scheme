fn main() {
    println!("cargo:rustc-link-arg={}", "/tmp/sfir-native-gc-trace-probe-20261016/candidate/program.native.native-5-0/module.bc");
}
