   59c8a:	cmp    $0x20,%rbx
   59c8e:	je     59d10 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x320>
   59c94:	mov    (%rsi,%rbx,8),%r15
   59c98:	test   %r15,%r15
   59c9b:	je     59c80 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x290>
   59c9d:	mov    %rbx,%rdx
   59ca0:	shl    $0xa,%rdx
   59ca4:	mov    %r15,%rcx
   59ca7:	jmp    59cc5 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x2d5>
   59ca9:	nopl   0x0(%rax)
   59cb0:	btr    %r14,%r15
   59cb4:	xor    %r14d,%r14d
   59cb7:	mov    %r14,0x0(%r13,%r12,1)
   59cbc:	lea    -0x1(%rcx),%r10
   59cc0:	and    %r10,%rcx
   59cc3:	je     59c83 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x293>
   59cc5:	tzcnt  %rcx,%r14
   59cca:	mov    %r14d,%r12d
   59ccd:	shl    $0x4,%r12d
   59cd1:	mov    0x18(%r11),%r13
   59cd5:	add    %rbp,%r13
   59cd8:	add    %rdx,%r13
   59cdb:	mov    (%r12,%r13,1),%r10
   59cdf:	test   $0x2,%r10b
   59ce3:	je     59cb0 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x2c0>
   59ce5:	mov    %r10,%r14
   59ce8:	and    $0xfffffffffffffffd,%r14
   59cec:	shr    $0x2,%r10
   59cf0:	add    %r10,%r8
   59cf3:	mov    %r8,0xf8(%rdi)
   59cfa:	inc    %r9
   59cfd:	mov    %r9,0x100(%rdi)
   59d04:	jmp    59cb7 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x2c7>
   59d06:	cs nopw 0x0(%rax,%rax,1)
   59d10:	mov    0x10(%r11),%rsi
   59d14:	cmp    %rsi,%rax
   59d17:	mov    0x30(%rsp),%rbx
   59d1c:	mov    0x28(%rsp),%r14
   59d21:	lea    0x1(%rax),%r15
   59d25:	mov    0x20(%rsp),%r10
   59d2a:	mov    0x18(%rsp),%r13
