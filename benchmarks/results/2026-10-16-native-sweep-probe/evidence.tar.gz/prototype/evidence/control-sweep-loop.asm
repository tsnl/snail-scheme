   59c9d:	mov    (%rsi,%r8,8),%r14
   59ca1:	test   %r14,%r14
   59ca4:	je     59c90 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x2a0>
   59ca6:	mov    %r8,%rdx
   59ca9:	shl    $0xa,%rdx
   59cad:	jmp    59cd2 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x2e2>
   59caf:	nop
   59cb0:	mov    $0xfffffffffffffffe,%r15
   59cb7:	mov    %r11d,%ecx
   59cba:	rol    %cl,%r15
   59cbd:	and    %r15,(%rsi,%r8,8)
   59cc1:	xor    %r11d,%r11d
   59cc4:	mov    %r11,0x0(%rbp,%r13,1)
   59cc9:	lea    -0x1(%r14),%rcx
   59ccd:	and    %rcx,%r14
   59cd0:	je     59c90 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x2a0>
   59cd2:	tzcnt  %r14,%r11
   59cd7:	mov    %r11d,%r13d
   59cda:	shl    $0x4,%r13d
   59cde:	mov    0x18(%rbx),%rbp
   59ce2:	add    %rax,%rbp
   59ce5:	add    %rdx,%rbp
   59ce8:	mov    0x0(%r13,%rbp,1),%rcx
   59ced:	test   $0x2,%cl
   59cf0:	je     59cb0 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x2c0>
   59cf2:	mov    %rcx,%r11
   59cf5:	and    $0xfffffffffffffffd,%r11
   59cf9:	shr    $0x2,%rcx
   59cfd:	add    %rcx,%r9
   59d00:	mov    %r9,0xf8(%rdi)
   59d07:	inc    %r10
   59d0a:	mov    %r10,0x100(%rdi)
   59d11:	jmp    59cc4 <_ZN13snail_runtime9native_gc9Collector5sweep17hb17edec021b7312fE+0x2d4>
   59d13:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
