(module
 (type $0 (array (mut i8)))
 (type $1 (array (mut i16)))
 (rec
  (type $2 (sub (struct (field i64) (field (mut (ref null $3))))))
  (type $3 (sub final $2 (struct (field i64) (field (mut (ref null $3))))))
  (type $4 (func (param i64) (result i64)))
  (type $5 (func (param i32 eqref) (result eqref)))
  (type $6 (array (mut eqref)))
  (type $7 (array (mut f64)))
  (type $8 (array (mut f32)))
  (type $9 (array (mut i32)))
  (type $10 (struct (field (mut i64)) (field (mut (ref null $10)))))
  (type $11 (struct (field (mut (ref null $10)))))
 )
 (type $12 (func (result eqref)))
 (type $13 (func (param i32) (result i32)))
 (type $14 (func (param i32 i32) (result eqref)))
 (type $15 (func (param i32) (result i64)))
 (type $16 (func (result i64)))
 (type $17 (func (result i32)))
 (type $18 (func (param eqref) (result i32)))
 (type $19 (func (param f32) (result i32)))
 (type $20 (func (param f64) (result i32)))
 (type $21 (func (param f32) (result i64)))
 (type $22 (func (param f64) (result i64)))
 (type $23 (func (param i32)))
 (type $24 (func (param eqref) (result i64)))
 (type $25 (func))
 (type $26 (func (param i64) (result eqref)))
 (type $27 (func (param i32 i64) (result eqref)))
 (type $28 (func (param i32) (result eqref)))
 (type $29 (func (param (ref null $0) i32 i32) (result i32)))
 (global $global$0 (ref $11) (struct.new_default $11))
 (global $global$1 (ref $10) (struct.new $10
  (i64.const 10)
  (ref.null none)
 ))
 (global $global$2 (mut i32) (i32.const 11))
 (global $global$3 (ref i31) (ref.i31
  (i32.const -1)
 ))
 (global $global$4 (ref $0) (array.new_fixed $0 3
  (i32.const 255)
  (i32.const 4660)
  (i32.const 128)
 ))
 (global $global$5 (ref $1) (array.new_fixed $1 3
  (i32.const 65535)
  (i32.const 74565)
  (i32.const 32768)
 ))
 (global $global$6 (ref $9) (array.new_fixed $9 3
  (i32.const -1)
  (i32.const 42)
  (i32.const 2147483647)
 ))
 (global $global$7 (ref $8) (array.new_default $8
  (i32.const 3)
 ))
 (global $global$8 (ref $8) (array.new_fixed $8 2
  (f32.const -0)
  (f32.const nan:0x412345)
 ))
 (global $global$9 (ref $7) (array.new_fixed $7 3
  (f64.const -0)
  (f64.const 1.5)
  (f64.const nan:0x8000000001234)
 ))
 (global $global$10 (ref $6) (array.new_default $6
  (i32.const 3)
 ))
 (global $global$11 (ref $0) (array.new_default $0
  (i32.const 3)
 ))
 (global $global$12 (ref $1) (array.new_default $1
  (i32.const 3)
 ))
 (global $global$13 (ref $9) (array.new_default $9
  (i32.const 3)
 ))
 (global $global$14 (mut i32) (i32.const 0))
 (table $0 1 4 eqref)
 (table $1 2 2 funcref)
 (elem $0 (table $1) (i32.const 0) func $17 $18)
 (export "sat-i32-f32-s" (func $0))
 (export "sat-i32-f32-u" (func $1))
 (export "sat-i32-f64-s" (func $2))
 (export "sat-i32-f64-u" (func $3))
 (export "sat-i64-f32-s" (func $4))
 (export "sat-i64-f32-u" (func $5))
 (export "sat-i64-f64-s" (func $6))
 (export "sat-i64-f64-u" (func $7))
 (export "tail" (func $9))
 (export "root" (func $10))
 (export "tail-gc" (func $12))
 (export "gc-operands" (func $13))
 (export "gc-effects" (func $16))
 (export "i31-s" (func $19))
 (export "i31-u" (func $20))
 (export "i31-eq-negative" (func $21))
 (export "check" (func $22))
 (export "_start" (func $23))
 (export "trap" (func $24))
 (export "left" (func $25))
 (export "read-parent" (func $26))
 (export "read-right" (func $27))
 (export "same-left" (func $28))
 (export "is-right" (func $29))
 (export "cyclic" (func $30))
 (export "storage-u8" (func $31))
 (export "storage-u16" (func $32))
 (export "storage-i32" (func $33))
 (export "storage-f32" (func $34))
 (export "storage-f64" (func $35))
 (export "storage-refs" (func $36))
 (export "storage-static-u8" (func $37))
 (export "storage-static-u16" (func $38))
 (export "storage-static-i32" (func $39))
 (export "storage-static-f32" (func $40))
 (export "storage-static-f64" (func $41))
 (export "storage-global-f32-bits" (func $42))
 (export "storage-identity" (func $43))
 (export "storage-order" (func $44))
 (export "storage-access" (func $45))
 (export "storage-roots" (func $46))
 (export "storage-check" (func $47))
 (export "storage-trap" (func $48))
 (func $0 (param $0 f32) (result i32)
  (i32.trunc_sat_f32_s
   (local.get $0)
  )
 )
 (func $1 (param $0 f32) (result i32)
  (i32.trunc_sat_f32_u
   (local.get $0)
  )
 )
 (func $2 (param $0 f64) (result i32)
  (i32.trunc_sat_f64_s
   (local.get $0)
  )
 )
 (func $3 (param $0 f64) (result i32)
  (i32.trunc_sat_f64_u
   (local.get $0)
  )
 )
 (func $4 (param $0 f32) (result i64)
  (i64.trunc_sat_f32_s
   (local.get $0)
  )
 )
 (func $5 (param $0 f32) (result i64)
  (i64.trunc_sat_f32_u
   (local.get $0)
  )
 )
 (func $6 (param $0 f64) (result i64)
  (i64.trunc_sat_f64_s
   (local.get $0)
  )
 )
 (func $7 (param $0 f64) (result i64)
  (i64.trunc_sat_f64_u
   (local.get $0)
  )
 )
 (func $8 (type $5) (param $0 i32) (param $1 eqref) (result eqref)
  (if (result eqref)
   (local.get $0)
   (then
    (return_call $8
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
     (local.get $1)
    )
   )
   (else
    (local.get $1)
   )
  )
 )
 (func $9 (param $0 i32) (result i64)
  (local $1 (ref $10))
  (local.set $1
   (struct.new $10
    (i64.const 42)
    (ref.null none)
   )
  )
  (struct.get $10 0
   (ref.cast (ref $10)
    (if (result eqref)
     (local.get $0)
     (then
      (if (result eqref)
       (local.tee $0
        (i32.sub
         (local.get $0)
         (i32.const 1)
        )
       )
       (then
        (if (result eqref)
         (local.tee $0
          (i32.sub
           (local.get $0)
           (i32.const 1)
          )
         )
         (then
          (if (result eqref)
           (local.tee $0
            (i32.sub
             (local.get $0)
             (i32.const 1)
            )
           )
           (then
            (if (result eqref)
             (local.tee $0
              (i32.sub
               (local.get $0)
               (i32.const 1)
              )
             )
             (then
              (if (result eqref)
               (local.tee $0
                (i32.sub
                 (local.get $0)
                 (i32.const 1)
                )
               )
               (then
                (if (result eqref)
                 (local.tee $0
                  (i32.sub
                   (local.get $0)
                   (i32.const 1)
                  )
                 )
                 (then
                  (if (result eqref)
                   (local.tee $0
                    (i32.sub
                     (local.get $0)
                     (i32.const 1)
                    )
                   )
                   (then
                    (if (result eqref)
                     (local.tee $0
                      (i32.sub
                       (local.get $0)
                       (i32.const 1)
                      )
                     )
                     (then
                      (call $8
                       (i32.sub
                        (local.get $0)
                        (i32.const 1)
                       )
                       (local.get $1)
                      )
                     )
                     (else
                      (local.get $1)
                     )
                    )
                   )
                   (else
                    (local.get $1)
                   )
                  )
                 )
                 (else
                  (local.get $1)
                 )
                )
               )
               (else
                (local.get $1)
               )
              )
             )
             (else
              (local.get $1)
             )
            )
           )
           (else
            (local.get $1)
           )
          )
         )
         (else
          (local.get $1)
         )
        )
       )
       (else
        (local.get $1)
       )
      )
     )
     (else
      (local.get $1)
     )
    )
   )
  )
 )
 (func $10 (param $0 i32) (result i64)
  (loop $label
   (br_if $label
    (local.tee $0
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
    )
   )
  )
  (i64.const 99)
 )
 (func $11 (type $5) (param $0 i32) (param $1 eqref) (result eqref)
  (if (result eqref)
   (local.get $0)
   (then
    (return_call $11
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
     (local.get $1)
    )
   )
   (else
    (local.get $1)
   )
  )
 )
 (func $12 (param $0 i32) (result i64)
  (local $1 (ref $10))
  (local.set $1
   (struct.new $10
    (i64.const 42)
    (ref.null none)
   )
  )
  (struct.get $10 0
   (ref.cast (ref $10)
    (if (result eqref)
     (local.get $0)
     (then
      (if (result eqref)
       (local.tee $0
        (i32.sub
         (local.get $0)
         (i32.const 1)
        )
       )
       (then
        (if (result eqref)
         (local.tee $0
          (i32.sub
           (local.get $0)
           (i32.const 1)
          )
         )
         (then
          (if (result eqref)
           (local.tee $0
            (i32.sub
             (local.get $0)
             (i32.const 1)
            )
           )
           (then
            (if (result eqref)
             (local.tee $0
              (i32.sub
               (local.get $0)
               (i32.const 1)
              )
             )
             (then
              (if (result eqref)
               (local.tee $0
                (i32.sub
                 (local.get $0)
                 (i32.const 1)
                )
               )
               (then
                (if (result eqref)
                 (local.tee $0
                  (i32.sub
                   (local.get $0)
                   (i32.const 1)
                  )
                 )
                 (then
                  (if (result eqref)
                   (local.tee $0
                    (i32.sub
                     (local.get $0)
                     (i32.const 1)
                    )
                   )
                   (then
                    (if (result eqref)
                     (local.tee $0
                      (i32.sub
                       (local.get $0)
                       (i32.const 1)
                      )
                     )
                     (then
                      (call $11
                       (i32.sub
                        (local.get $0)
                        (i32.const 1)
                       )
                       (local.get $1)
                      )
                     )
                     (else
                      (local.get $1)
                     )
                    )
                   )
                   (else
                    (local.get $1)
                   )
                  )
                 )
                 (else
                  (local.get $1)
                 )
                )
               )
               (else
                (local.get $1)
               )
              )
             )
             (else
              (local.get $1)
             )
            )
           )
           (else
            (local.get $1)
           )
          )
         )
         (else
          (local.get $1)
         )
        )
       )
       (else
        (local.get $1)
       )
      )
     )
     (else
      (local.get $1)
     )
    )
   )
  )
 )
 (func $13 (result i64)
  (struct.set $11 0
   (global.get $global$0)
   (struct.new $10
    (i64.const 41)
    (ref.null none)
   )
  )
  (struct.set $10 1
   (global.get $global$1)
   (struct.new $10
    (i64.const 40)
    (ref.null none)
   )
  )
  (if
   (i64.ne
    (struct.get $10 0
     (struct.get $11 0
      (global.get $global$0)
     )
    )
    (i64.const 41)
   )
   (then
    (unreachable)
   )
  )
  (i64.add
   (struct.get $10 0
    (struct.get $10 1
     (global.get $global$1)
    )
   )
   (i64.const 2)
  )
 )
 (func $14 (type $5) (param $0 i32) (param $1 eqref) (result eqref)
  (if (result eqref)
   (local.get $0)
   (then
    (call $14
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
     (local.get $1)
    )
   )
   (else
    (local.get $1)
   )
  )
 )
 (func $15 (type $5) (param $0 i32) (param $1 eqref) (result eqref)
  (if (result eqref)
   (local.get $0)
   (then
    (call $15
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
     (local.get $1)
    )
   )
   (else
    (local.get $1)
   )
  )
 )
 (func $16 (result i64)
  (local $0 eqref)
  (drop
   (call $15
    (i32.const 11)
    (local.tee $0
     (call $14
      (i32.const 41)
      (struct.new $10
       (i64.const 42)
       (ref.null none)
      )
     )
    )
   )
  )
  (drop
   (call $15
    (i32.const 11)
    (local.get $0)
   )
  )
  (drop
   (call $15
    (i32.const 15)
    (local.get $0)
   )
  )
  (struct.get $10 0
   (ref.cast (ref $10)
    (local.get $0)
   )
  )
 )
 (func $17 (param $0 i32) (result i32)
  (unreachable)
 )
 (func $18 (type $4) (param $0 i64) (result i64)
  (unreachable)
 )
 (func $19 (param $0 i32) (result i32)
  (i31.get_s
   (ref.i31
    (local.get $0)
   )
  )
 )
 (func $20 (param $0 i32) (result i32)
  (i31.get_u
   (ref.i31
    (local.get $0)
   )
  )
 )
 (func $21 (param $0 i32) (result i32)
  (ref.eq
   (global.get $global$3)
   (ref.i31
    (local.get $0)
   )
  )
 )
 (func $22 (result i32)
  (local $0 (ref $6))
  (if
   (i32.ne
    (i32.add
     (global.get $global$2)
     (block (result i32)
      (global.set $global$2
       (i32.const 22)
      )
      (i32.const 1)
     )
    )
    (i32.const 12)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $10 0
   (global.get $global$1)
   (i64.const 20)
  )
  (if
   (i64.ne
    (struct.get $10 0
     (global.get $global$1)
    )
    (i64.const 20)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $6 $6
   (local.tee $0
    (array.new_fixed $6 3
     (ref.i31
      (i32.const 10)
     )
     (global.get $global$3)
     (ref.null none)
    )
   )
   (i32.const 1)
   (local.get $0)
   (i32.const 0)
   (i32.const 2)
  )
  (if
   (i32.ne
    (i31.get_s
     (ref.cast (ref i31)
      (array.get $6
       (local.get $0)
       (i32.const 2)
      )
     )
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (table.grow $0
     (global.get $global$1)
     (i32.const 2)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (table.grow $0
     (ref.null none)
     (i32.const 2)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (ref.eq
     (table.get $0
      (i32.const 2)
     )
     (global.get $global$1)
    )
   )
   (then
    (unreachable)
   )
  )
  (i32.const 0)
 )
 (func $23
  (drop
   (call $8
    (i32.const 91)
    (ref.i31
     (i32.const 42)
    )
   )
  )
 )
 (func $24 (param $0 i32)
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (drop
     (i64.div_s
      (i64.const -9223372036854775808)
      (i64.const -1)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 1)
   )
   (then
    (drop
     (i32.div_u
      (i32.const 1)
      (i32.const 0)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 2)
   )
   (then
    (drop
     (i64.trunc_f64_s
      (f64.const 9223372036854775808)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 3)
   )
   (then
    (drop
     (i32.trunc_f64_u
      (f64.const nan:0x8000000000000)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 4)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 5)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 6)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 7)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 8)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 9)
   )
   (then
    (drop
     (table.get $1
      (i32.const 2)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 10)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 11)
   )
   (then
    (array.copy $6 $6
     (array.new_default $6
      (i32.const 1)
     )
     (i32.const 1)
     (array.new_default $6
      (i32.const 1)
     )
     (i32.const 0)
     (i32.const 1)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 12)
   )
   (then
    (drop
     (i31.get_s
      (ref.null none)
     )
    )
   )
  )
 )
 (func $25 (param $0 i64) (result eqref)
  (local $1 (ref $3))
  (struct.set $3 1
   (local.tee $1
    (struct.new $3
     (local.get $0)
     (ref.null none)
    )
   )
   (local.get $1)
  )
  (local.get $1)
 )
 (func $26 (param $0 eqref) (result i64)
  (struct.get $2 0
   (ref.cast (ref $2)
    (local.get $0)
   )
  )
 )
 (func $27 (param $0 eqref) (result i64)
  (unreachable)
 )
 (func $28 (param $0 eqref) (result i32)
  (ref.test (ref $3)
   (local.get $0)
  )
 )
 (func $29 (param $0 eqref) (result i32)
  (i32.const 0)
 )
 (func $30 (param $0 eqref) (result i32)
  (local $1 (ref $2))
  (ref.eq
   (local.tee $1
    (ref.cast (ref $2)
     (local.get $0)
    )
   )
   (struct.get $2 1
    (local.get $1)
   )
  )
 )
 (func $31 (param $0 i32) (param $1 i32) (result eqref)
  (array.new $0
   (local.get $1)
   (local.get $0)
  )
 )
 (func $32 (param $0 i32) (param $1 i32) (result eqref)
  (array.new $1
   (local.get $1)
   (local.get $0)
  )
 )
 (func $33 (param $0 i32) (param $1 i32) (result eqref)
  (array.new $9
   (local.get $1)
   (local.get $0)
  )
 )
 (func $34 (param $0 i32) (param $1 i32) (result eqref)
  (array.new $8
   (f32.reinterpret_i32
    (local.get $1)
   )
   (local.get $0)
  )
 )
 (func $35 (param $0 i32) (param $1 i64) (result eqref)
  (array.new $7
   (f64.reinterpret_i64
    (local.get $1)
   )
   (local.get $0)
  )
 )
 (func $36 (param $0 i32) (result eqref)
  (array.new_default $6
   (local.get $0)
  )
 )
 (func $37 (result eqref)
  (global.get $global$4)
 )
 (func $38 (result eqref)
  (global.get $global$5)
 )
 (func $39 (result eqref)
  (global.get $global$6)
 )
 (func $40 (result eqref)
  (global.get $global$7)
 )
 (func $41 (result eqref)
  (global.get $global$9)
 )
 (func $42 (result eqref)
  (global.get $global$8)
 )
 (func $43 (result i32)
  (i32.const 1)
 )
 (func $44 (result i32)
  (global.get $global$14)
 )
 (func $45 (param $0 (ref null $0)) (param $1 i32) (param $2 i32) (result i32)
  (global.set $global$14
   (i32.const 0)
  )
  (if (result i32)
   (local.get $2)
   (then
    (if (result i32)
     (i32.eq
      (local.get $2)
      (i32.const 1)
     )
     (then
      (global.set $global$14
       (i32.const 1)
      )
      (array.get_u $0
       (local.get $0)
       (local.get $1)
      )
     )
     (else
      (global.set $global$14
       (i32.const 1)
      )
      (global.set $global$14
       (i32.const 2)
      )
      (array.set $0
       (local.get $0)
       (local.get $1)
       (i32.const 42)
      )
      (i32.const 42)
     )
    )
   )
   (else
    (array.len
     (local.get $0)
    )
   )
  )
 )
 (func $46 (result i64)
  (i64.const 77)
 )
 (func $47 (param $0 i32) (result i32)
  (local $1 (ref $0))
  (local $2 (ref $1))
  (local $3 (ref $9))
  (local $4 (ref $8))
  (local $5 (ref $7))
  (if
   (array.get_u $0
    (global.get $global$11)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.get_u $1
    (global.get $global$12)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (array.get $9
    (global.get $global$13)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (array.set $0
   (local.tee $1
    (array.new $0
     (local.get $0)
     (i32.const 4)
    )
   )
   (i32.const 0)
   (i32.const 128)
  )
  (array.set $0
   (local.get $1)
   (i32.const 1)
   (i32.const 52)
  )
  (array.copy $0 $0
   (local.get $1)
   (i32.const 1)
   (local.get $1)
   (i32.const 0)
   (i32.const 3)
  )
  (if
   (i32.ne
    (array.get_s $0
     (local.get $1)
     (i32.const 1)
    )
    (i32.const -128)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get_u $0
     (local.get $1)
     (i32.const 2)
    )
    (i32.const 52)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $0 $0
   (local.get $1)
   (i32.const 0)
   (local.get $1)
   (i32.const 1)
   (i32.const 3)
  )
  (if
   (i32.ne
    (i32.and
     (local.get $0)
     (i32.const 255)
    )
    (array.get_u $0
     (local.get $1)
     (i32.const 2)
    )
   )
   (then
    (unreachable)
   )
  )
  (array.copy $0 $0
   (local.get $1)
   (i32.const 4)
   (local.get $1)
   (i32.const 4)
   (i32.const 0)
  )
  (array.copy $0 $0
   (global.get $global$4)
   (i32.const 0)
   (local.get $1)
   (i32.const 0)
   (i32.const 3)
  )
  (if
   (i32.ne
    (array.get_u $0
     (global.get $global$4)
     (i32.const 1)
    )
    (i32.const 52)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $1 $1
   (local.tee $2
    (array.new_fixed $1 3
     (local.get $0)
     (i32.const 65535)
     (i32.const 74565)
    )
   )
   (i32.const 0)
   (local.get $2)
   (i32.const 1)
   (i32.const 2)
  )
  (if
   (i32.ne
    (array.get_s $1
     (local.get $2)
     (i32.const 0)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get_u $1
     (local.get $2)
     (i32.const 1)
    )
    (i32.const 9029)
   )
   (then
    (unreachable)
   )
  )
  (array.set $1
   (global.get $global$5)
   (i32.const 2)
   (i32.const 0)
  )
  (if
   (array.get_u $1
    (global.get $global$5)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (array.set $9
   (local.tee $3
    (array.new $9
     (local.get $0)
     (i32.const 3)
    )
   )
   (i32.const 1)
   (i32.const -1)
  )
  (array.copy $9 $9
   (local.get $3)
   (i32.const 2)
   (local.get $3)
   (i32.const 1)
   (i32.const 1)
  )
  (if
   (i32.ne
    (array.get $9
     (local.get $3)
     (i32.const 2)
    )
    (i32.const -1)
   )
   (then
    (unreachable)
   )
  )
  (array.set $8
   (local.tee $4
    (array.new $8
     (f32.const 1.5)
     (i32.const 3)
    )
   )
   (i32.const 1)
   (f32.const -0)
  )
  (array.copy $8 $8
   (global.get $global$7)
   (i32.const 0)
   (local.get $4)
   (i32.const 0)
   (i32.const 3)
  )
  (if
   (i32.ne
    (i32.reinterpret_f32
     (array.get $8
      (global.get $global$7)
      (i32.const 1)
     )
    )
    (i32.const -2147483648)
   )
   (then
    (unreachable)
   )
  )
  (array.copy $7 $7
   (local.tee $5
    (array.new_default $7
     (i32.const 2)
    )
   )
   (i32.const 0)
   (global.get $global$9)
   (i32.const 0)
   (i32.const 2)
  )
  (if
   (i64.ne
    (i64.reinterpret_f64
     (array.get $7
      (local.get $5)
      (i32.const 0)
     )
    )
    (i64.const -9223372036854775808)
   )
   (then
    (unreachable)
   )
  )
  (array.set $6
   (global.get $global$10)
   (i32.const 1)
   (struct.new $10
    (i64.const 42)
    (ref.null none)
   )
  )
  (if
   (i64.ne
    (struct.get $10 0
     (ref.cast (ref $10)
      (array.get $6
       (global.get $global$10)
       (i32.const 1)
      )
     )
    )
    (i64.const 42)
   )
   (then
    (unreachable)
   )
  )
  (i32.const 1)
 )
 (func $48 (param $0 i32)
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (drop
     (array.get_u $0
      (global.get $global$4)
      (i32.const -1)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 1)
   )
   (then
    (array.set $1
     (global.get $global$5)
     (i32.const 3)
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 2)
   )
   (then
    (array.copy $9 $9
     (global.get $global$6)
     (i32.const 4)
     (global.get $global$6)
     (i32.const 0)
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 3)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 4)
   )
   (then
    (array.copy $1 $1
     (global.get $global$5)
     (i32.const 0)
     (global.get $global$5)
     (i32.const -1)
     (i32.const 2)
    )
   )
  )
 )
)

