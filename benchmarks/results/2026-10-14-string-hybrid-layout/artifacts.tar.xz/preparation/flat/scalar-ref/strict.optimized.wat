(module
 (rec
  (type $0 (func (param i32 i32 i64 i64) (result i64)))
  (type $call26 (func (param i64 i64) (result i64)))
  (type $2 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $call27 (func (param i64) (result i64)))
  (type $4 (func (param i32 i32 i64) (result i32)))
  (type $type5 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct))
  (type $type14 (array (mut i32)))
  (type $type13 (struct))
 )
 (type $11 (func (param i64) (result i64)))
 (type $12 (func (param i32) (result i64)))
 (type $13 (func (param i64) (result i32)))
 (type $14 (func (result i64)))
 (type $15 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global109 (mut i64) (i64.const 0))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type14)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type25)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type26)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type25)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type5)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "probe-character" (func $export1))
 (export "probe-length" (func $export2))
 (export "main" (func $main))
 (func $function42 (type $4) (param $0 i32) (param $1 i32) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type14))
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (global.get $global109)
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (local.set $5
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.set $4
     (if (result i32)
      (i64.eqz
       (local.tee $3
        (i64.rem_s
         (local.get $2)
         (i64.const 5)
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (if (result i32)
        (i64.eq
         (local.get $3)
         (i64.const 1)
        )
        (then
         (i32.const 233)
        )
        (else
         (if (result i32)
          (i64.eq
           (local.get $3)
           (i64.const 2)
          )
          (then
           (i32.const 128512)
          )
          (else
           (select
            (i32.const 1114111)
            (i32.const 769)
            (i64.eq
             (local.get $3)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.ne
      (array.get $type14
       (local.get $5)
       (i32.const 0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.get $5)
     (i32.add
      (i32.wrap_i64
       (local.get $2)
      )
      (i32.const 1)
     )
     (local.get $4)
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function43 (type $call27) (param $0 i64) (result i64)
  (local $1 i64)
  (local $2 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (local.set $1
     (call $foreign0
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready121)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global121)
     )
    )
    (local.set $1
     (call $function46
      (i32.const 0)
      (i32.const 1)
      (local.get $1)
      (i64.const 0)
     )
    )
    (if (result i64)
     (i64.gt_s
      (local.get $0)
      (i64.const 1)
     )
     (then
      (local.set $2
       (call $foreign0
        (i64.const 0)
       )
      )
      (if
       (i32.eqz
        (global.get $ready121)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global121)
       )
      )
      (local.set $1
       (call $function46
        (i32.const 0)
        (i32.const 1)
        (local.get $2)
        (local.get $1)
       )
      )
      (if (result i64)
       (i64.gt_s
        (local.get $0)
        (i64.const 2)
       )
       (then
        (local.set $2
         (call $foreign0
          (i64.const 0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready121)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global121)
         )
        )
        (local.set $1
         (call $function46
          (i32.const 0)
          (i32.const 1)
          (local.get $2)
          (local.get $1)
         )
        )
        (if (result i64)
         (i64.gt_s
          (local.get $0)
          (i64.const 3)
         )
         (then
          (local.set $2
           (call $foreign0
            (i64.const 0)
           )
          )
          (if
           (i32.eqz
            (global.get $ready121)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global121)
           )
          )
          (local.set $1
           (call $function46
            (i32.const 0)
            (i32.const 1)
            (local.get $2)
            (local.get $1)
           )
          )
          (if (result i64)
           (i64.gt_s
            (local.get $0)
            (i64.const 4)
           )
           (then
            (local.set $2
             (call $foreign0
              (i64.const 0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready121)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global121)
             )
            )
            (local.set $1
             (call $function46
              (i32.const 0)
              (i32.const 1)
              (local.get $2)
              (local.get $1)
             )
            )
            (if (result i64)
             (i64.gt_s
              (local.get $0)
              (i64.const 5)
             )
             (then
              (local.set $2
               (call $foreign0
                (i64.const 0)
               )
              )
              (if
               (i32.eqz
                (global.get $ready121)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global121)
               )
              )
              (local.set $1
               (call $function46
                (i32.const 0)
                (i32.const 1)
                (local.get $2)
                (local.get $1)
               )
              )
              (if (result i64)
               (i64.gt_s
                (local.get $0)
                (i64.const 6)
               )
               (then
                (local.set $2
                 (call $foreign0
                  (i64.const 0)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready121)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global121)
                 )
                )
                (local.set $1
                 (call $function46
                  (i32.const 0)
                  (i32.const 1)
                  (local.get $2)
                  (local.get $1)
                 )
                )
                (if (result i64)
                 (i64.gt_s
                  (local.get $0)
                  (i64.const 7)
                 )
                 (then
                  (local.set $2
                   (call $foreign0
                    (i64.const 0)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready121)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global121)
                   )
                  )
                  (local.set $1
                   (call $function46
                    (i32.const 0)
                    (i32.const 1)
                    (local.get $2)
                    (local.get $1)
                   )
                  )
                  (if (result i64)
                   (i64.gt_s
                    (local.get $0)
                    (i64.const 8)
                   )
                   (then
                    (local.set $2
                     (call $foreign0
                      (i64.const 0)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready121)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global121)
                     )
                    )
                    (local.set $1
                     (call $function46
                      (i32.const 0)
                      (i32.const 1)
                      (local.get $2)
                      (local.get $1)
                     )
                    )
                    (if (result i64)
                     (i64.gt_s
                      (local.get $0)
                      (i64.const 9)
                     )
                     (then
                      (local.set $2
                       (call $foreign0
                        (i64.const 0)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready121)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global121)
                       )
                      )
                      (local.set $1
                       (call $function46
                        (i32.const 0)
                        (i32.const 1)
                        (local.get $2)
                        (local.get $1)
                       )
                      )
                      (if (result i64)
                       (i64.gt_s
                        (local.get $0)
                        (i64.const 10)
                       )
                       (then
                        (local.set $2
                         (call $foreign0
                          (i64.const 0)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready121)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global121)
                         )
                        )
                        (local.set $1
                         (call $function46
                          (i32.const 0)
                          (i32.const 1)
                          (local.get $2)
                          (local.get $1)
                         )
                        )
                        (if (result i64)
                         (i64.gt_s
                          (local.get $0)
                          (i64.const 11)
                         )
                         (then
                          (local.set $2
                           (call $foreign0
                            (i64.const 0)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready121)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global121)
                           )
                          )
                          (local.set $1
                           (call $function46
                            (i32.const 0)
                            (i32.const 1)
                            (local.get $2)
                            (local.get $1)
                           )
                          )
                          (if (result i64)
                           (i64.gt_s
                            (local.get $0)
                            (i64.const 12)
                           )
                           (then
                            (local.set $2
                             (call $foreign0
                              (i64.const 0)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready121)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global121)
                             )
                            )
                            (local.set $1
                             (call $function46
                              (i32.const 0)
                              (i32.const 1)
                              (local.get $2)
                              (local.get $1)
                             )
                            )
                            (if (result i64)
                             (i64.gt_s
                              (local.get $0)
                              (i64.const 13)
                             )
                             (then
                              (local.set $2
                               (call $foreign0
                                (i64.const 0)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready121)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global121)
                               )
                              )
                              (local.set $1
                               (call $function46
                                (i32.const 0)
                                (i32.const 1)
                                (local.get $2)
                                (local.get $1)
                               )
                              )
                              (if (result i64)
                               (i64.gt_s
                                (local.get $0)
                                (i64.const 14)
                               )
                               (then
                                (local.set $2
                                 (call $foreign0
                                  (i64.const 0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready121)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global121)
                                 )
                                )
                                (return_call $function44
                                 (local.get $0)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 15)
                                 (call $function45
                                  (local.get $2)
                                  (local.get $1)
                                 )
                                )
                               )
                               (else
                                (local.get $1)
                               )
                              )
                             )
                             (else
                              (local.get $1)
                             )
                            )
                           )
                           (else
                            (local.get $1)
                           )
                          )
                         )
                         (else
                          (local.get $1)
                         )
                        )
                       )
                       (else
                        (local.get $1)
                       )
                      )
                     )
                     (else
                      (local.get $1)
                     )
                    )
                   )
                   (else
                    (local.get $1)
                   )
                  )
                 )
                 (else
                  (local.get $1)
                 )
                )
               )
               (else
                (local.get $1)
               )
              )
             )
             (else
              (local.get $1)
             )
            )
           )
           (else
            (local.get $1)
           )
          )
         )
         (else
          (local.get $1)
         )
        )
       )
       (else
        (local.get $1)
       )
      )
     )
     (else
      (local.get $1)
     )
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function44 (type $2) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (local.set $4
     (call $function45
      (call $foreign0
       (i64.const 0)
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready121)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global121)
        )
       )
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (local.get $4)
   )
  )
 )
 (func $function45 (type $call26) (param $0 i64) (param $1 i64) (result i64)
  (return_call $function46
   (i32.const 0)
   (i32.const 1)
   (local.get $0)
   (local.get $1)
  )
 )
 (func $function46 (type $0) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i32)
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (i64.eq
    (global.get $global109)
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (array.get $type14
      (global.get $global110)
      (i32.add
       (i32.wrap_i64
        (local.get $2)
       )
       (i32.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
     (i64.add
      (i64.extend_i32_u
       (local.get $4)
      )
      (local.get $3)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (return_call $function43
   (local.get $0)
  )
 )
 (func $export1 (param $0 i64) (result i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type14
   (global.get $global110)
   (i32.add
    (i32.wrap_i64
     (local.get $0)
    )
    (i32.const 1)
   )
  )
 )
 (func $export2 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (i64.sub
   (i64.extend_i32_u
    (array.len
     (global.get $global110)
    )
   )
   (i64.const 1)
  )
 )
 (func $main
  (local $0 i64)
  (local $1 (ref $type14))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global109
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.tee $0
     (global.get $global109)
    )
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type14
   (local.tee $1
    (array.new_default $type14
     (i32.add
      (i32.wrap_i64
       (local.get $0)
      )
      (i32.const 1)
     )
    )
   )
   (i32.const 0)
   (i32.const 1)
  )
  (global.set $global110
   (local.get $1)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type25)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (drop
   (call $function42
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (global.set $global121
   (struct.new_default $type26)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type27)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type25)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type5)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

