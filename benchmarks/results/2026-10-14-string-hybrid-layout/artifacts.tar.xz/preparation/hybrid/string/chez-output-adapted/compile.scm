(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-string-hybrid-preparation-20261014/hybrid/string/chez-output-adapted/program.scm" "/tmp/snail-string-hybrid-preparation-20261014/hybrid/string/chez-output-adapted/program.so"))
