(module
 (rec
  (type $0 (func (param i64 i32 i32 i64) (result i64)))
  (type $1 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $call26 (func (param (ref eq) (ref null $type24) i64) (result i32)))
  (type $type24 (struct (field (ref eq)) (field (ref null $type24))))
  (type $4 (func (param i32 i32 (ref null $type24) i64) (result i64)))
  (type $call23 (func (param (ref $type24)) (result (ref eq))))
  (type $call21 (func (param (ref eq) i64 i64) (result (ref eq))))
  (type $7 (func (param (ref eq) i64 (ref eq) i64 i64)))
  (type $type16 (struct (field i32) (field (ref $type15)) (field (ref $type17))))
  (type $type17 (array (mut (ref null $type15))))
  (type $10 (func (param i32) (result (ref eq))))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct (field (mut (ref eq)))))
  (type $type28 (struct))
  (type $type26 (struct))
  (type $type25 (struct))
  (type $type23 (struct))
  (type $type21 (struct))
  (type $type13 (struct))
  (type $type15 (array (mut i32)))
 )
 (type $21 (func (param i64) (result i64)))
 (type $22 (func (param i32) (result i64)))
 (type $23 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type15) (array.new_fixed $type15 4
  (i32.const 0)
  (i32.const 49)
  (i32.const 50)
  (i32.const 51)
 ))
 (global $string1 (ref $type15) (array.new_fixed $type15 4
  (i32.const 0)
  (i32.const 52)
  (i32.const 53)
  (i32.const 54)
 ))
 (global $string2 (ref $type15) (array.new_fixed $type15 4
  (i32.const 0)
  (i32.const 55)
  (i32.const 56)
  (i32.const 57)
 ))
 (global $string3 (ref $type15) (array.new_fixed $type15 7
  (i32.const 0)
  (i32.const 97)
  (i32.const 98)
  (i32.const 99)
  (i32.const 100)
  (i32.const 101)
  (i32.const 102)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type21)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type23)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type25)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type26)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global119 (mut (ref null $type28)) (ref.null none))
 (global $ready119 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type29)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type30)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type31)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type31)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global111 (mut i64) (i64.const 0))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global112 (mut i64) (i64.const 0))
 (global $ready112 (mut i32) (i32.const 0))
 (global $global113 (mut i64) (i64.const 0))
 (global $ready113 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type31)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "main" (func $main))
 (func $string-new (type $10) (param $0 i32) (result (ref eq))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type15))
  (local $5 (ref $type17))
  (if (result (ref eq))
   (i32.le_u
    (local.get $0)
    (i32.const 8192)
   )
   (then
    (array.set $type15
     (local.tee $4
      (array.new_default $type15
       (i32.add
        (local.get $0)
        (i32.const 1)
       )
      )
     )
     (i32.const 0)
     (i32.const 1)
    )
    (local.get $4)
   )
   (else
    (local.set $4
     (array.new_default $type15
      (i32.const 8192)
     )
    )
    (local.set $1
     (i32.add
      (local.get $0)
      (i32.const -8192)
     )
    )
    (local.set $5
     (array.new_default $type17
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type17
      (local.get $5)
      (local.get $2)
      (array.new_default $type15
       (local.tee $3
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $3)
       )
      )
     )
    )
    (struct.new $type16
     (local.get $0)
     (local.get $4)
     (local.get $5)
    )
   )
  )
 )
 (func $string-copy (type $7) (param $0 (ref eq)) (param $1 i64) (param $2 (ref eq)) (param $3 i64) (param $4 i64)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i64)
  (local $13 i64)
  (local $14 (ref $type16))
  (if
   (i32.ne
    (if (result i32)
     (ref.test (ref $type15)
      (local.get $0)
     )
     (then
      (array.get $type15
       (ref.cast (ref $type15)
        (local.get $0)
       )
       (i32.const 0)
      )
     )
     (else
      (drop
       (ref.cast (ref $type16)
        (local.get $0)
       )
      )
      (i32.const 1)
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (local.set $12
   (if (result i64)
    (ref.test (ref $type15)
     (local.get $0)
    )
    (then
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (ref.cast (ref $type15)
         (local.get $0)
        )
       )
      )
      (i64.const 1)
     )
    )
    (else
     (i64.extend_i32_u
      (struct.get $type16 0
       (ref.cast (ref $type16)
        (local.get $0)
       )
      )
     )
    )
   )
  )
  (local.set $13
   (if (result i64)
    (ref.test (ref $type15)
     (local.get $2)
    )
    (then
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (ref.cast (ref $type15)
         (local.get $2)
        )
       )
      )
      (i64.const 1)
     )
    )
    (else
     (i64.extend_i32_u
      (struct.get $type16 0
       (ref.cast (ref $type16)
        (local.get $2)
       )
      )
     )
    )
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (local.get $12)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (local.get $13)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (local.get $4)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (i64.sub
     (local.get $4)
     (local.get $3)
    )
    (i64.sub
     (local.get $12)
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (ref.test (ref $type15)
     (local.get $0)
    )
    (ref.test (ref $type15)
     (local.get $2)
    )
   )
   (then
    (array.copy $type15 $type15
     (ref.cast (ref $type15)
      (local.get $0)
     )
     (i32.add
      (i32.wrap_i64
       (local.get $1)
      )
      (i32.const 1)
     )
     (ref.cast (ref $type15)
      (local.get $2)
     )
     (i32.add
      (i32.wrap_i64
       (local.get $3)
      )
      (i32.const 1)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $4)
       (local.get $3)
      )
     )
    )
   )
   (else
    (if
     (i32.and
      (i64.gt_u
       (local.get $1)
       (local.get $3)
      )
      (ref.eq
       (local.get $0)
       (local.get $2)
      )
     )
     (then
      (local.set $5
       (i32.add
        (local.tee $8
         (i32.wrap_i64
          (i64.sub
           (local.get $4)
           (local.get $3)
          )
         )
        )
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
      (local.set $6
       (i32.add
        (i32.wrap_i64
         (local.get $3)
        )
        (local.get $8)
       )
      )
      (loop $label
       (if
        (local.get $8)
        (then
         (local.set $5
          (i32.sub
           (local.get $5)
           (local.tee $7
            (select
             (local.get $8)
             (local.tee $5
              (select
               (local.tee $5
                (i32.add
                 (i32.and
                  (i32.sub
                   (local.get $5)
                   (i32.const 1)
                  )
                  (i32.const 8191)
                 )
                 (i32.const 1)
                )
               )
               (local.tee $7
                (i32.add
                 (i32.and
                  (i32.sub
                   (local.get $6)
                   (i32.const 1)
                  )
                  (i32.const 8191)
                 )
                 (i32.const 1)
                )
               )
               (i32.lt_u
                (local.get $5)
                (local.get $7)
               )
              )
             )
             (i32.gt_u
              (local.get $5)
              (local.get $8)
             )
            )
           )
          )
         )
         (local.set $6
          (i32.sub
           (local.get $6)
           (local.get $7)
          )
         )
         (array.copy $type15 $type15
          (if (result (ref $type15))
           (ref.test (ref $type15)
            (local.get $0)
           )
           (then
            (ref.cast (ref $type15)
             (local.get $0)
            )
           )
           (else
            (local.set $14
             (ref.cast (ref $type16)
              (local.get $0)
             )
            )
            (if (result (ref $type15))
             (i32.lt_u
              (local.get $5)
              (i32.const 8192)
             )
             (then
              (struct.get $type16 1
               (local.get $14)
              )
             )
             (else
              (ref.as_non_null
               (array.get $type17
                (struct.get $type16 2
                 (local.get $14)
                )
                (i32.sub
                 (i32.shr_u
                  (local.get $5)
                  (i32.const 13)
                 )
                 (i32.const 1)
                )
               )
              )
             )
            )
           )
          )
          (select
           (i32.add
            (local.get $5)
            (i32.const 1)
           )
           (i32.and
            (local.get $5)
            (i32.const 8191)
           )
           (ref.test (ref $type15)
            (local.get $0)
           )
          )
          (if (result (ref $type15))
           (ref.test (ref $type15)
            (local.get $2)
           )
           (then
            (ref.cast (ref $type15)
             (local.get $2)
            )
           )
           (else
            (local.set $14
             (ref.cast (ref $type16)
              (local.get $2)
             )
            )
            (if (result (ref $type15))
             (i32.lt_u
              (local.get $6)
              (i32.const 8192)
             )
             (then
              (struct.get $type16 1
               (local.get $14)
              )
             )
             (else
              (ref.as_non_null
               (array.get $type17
                (struct.get $type16 2
                 (local.get $14)
                )
                (i32.sub
                 (i32.shr_u
                  (local.get $6)
                  (i32.const 13)
                 )
                 (i32.const 1)
                )
               )
              )
             )
            )
           )
          )
          (select
           (i32.add
            (local.get $6)
            (i32.const 1)
           )
           (i32.and
            (local.get $6)
            (i32.const 8191)
           )
           (ref.test (ref $type15)
            (local.get $2)
           )
          )
          (local.get $7)
         )
         (local.set $8
          (i32.sub
           (local.get $8)
           (local.get $7)
          )
         )
         (br $label)
        )
       )
      )
     )
     (else
      (local.set $5
       (i32.wrap_i64
        (local.get $1)
       )
      )
      (local.set $6
       (i32.wrap_i64
        (local.get $3)
       )
      )
      (local.set $8
       (i32.wrap_i64
        (i64.sub
         (local.get $4)
         (local.get $3)
        )
       )
      )
      (loop $label1
       (if
        (local.get $8)
        (then
         (local.set $7
          (select
           (local.get $8)
           (local.tee $7
            (select
             (local.tee $7
              (i32.sub
               (i32.const 8192)
               (local.tee $9
                (i32.and
                 (local.get $5)
                 (i32.const 8191)
                )
               )
              )
             )
             (local.tee $11
              (i32.sub
               (i32.const 8192)
               (local.tee $10
                (i32.and
                 (local.get $6)
                 (i32.const 8191)
                )
               )
              )
             )
             (i32.lt_u
              (local.get $7)
              (local.get $11)
             )
            )
           )
           (i32.gt_u
            (local.get $7)
            (local.get $8)
           )
          )
         )
         (array.copy $type15 $type15
          (if (result (ref $type15))
           (ref.test (ref $type15)
            (local.get $0)
           )
           (then
            (ref.cast (ref $type15)
             (local.get $0)
            )
           )
           (else
            (local.set $14
             (ref.cast (ref $type16)
              (local.get $0)
             )
            )
            (if (result (ref $type15))
             (i32.lt_u
              (local.get $5)
              (i32.const 8192)
             )
             (then
              (struct.get $type16 1
               (local.get $14)
              )
             )
             (else
              (ref.as_non_null
               (array.get $type17
                (struct.get $type16 2
                 (local.get $14)
                )
                (i32.sub
                 (i32.shr_u
                  (local.get $5)
                  (i32.const 13)
                 )
                 (i32.const 1)
                )
               )
              )
             )
            )
           )
          )
          (select
           (i32.add
            (local.get $5)
            (i32.const 1)
           )
           (local.get $9)
           (ref.test (ref $type15)
            (local.get $0)
           )
          )
          (if (result (ref $type15))
           (ref.test (ref $type15)
            (local.get $2)
           )
           (then
            (ref.cast (ref $type15)
             (local.get $2)
            )
           )
           (else
            (local.set $14
             (ref.cast (ref $type16)
              (local.get $2)
             )
            )
            (if (result (ref $type15))
             (i32.lt_u
              (local.get $6)
              (i32.const 8192)
             )
             (then
              (struct.get $type16 1
               (local.get $14)
              )
             )
             (else
              (ref.as_non_null
               (array.get $type17
                (struct.get $type16 2
                 (local.get $14)
                )
                (i32.sub
                 (i32.shr_u
                  (local.get $6)
                  (i32.const 13)
                 )
                 (i32.const 1)
                )
               )
              )
             )
            )
           )
          )
          (select
           (i32.add
            (local.get $6)
            (i32.const 1)
           )
           (local.get $10)
           (ref.test (ref $type15)
            (local.get $2)
           )
          )
          (local.get $7)
         )
         (local.set $5
          (i32.add
           (local.get $5)
           (local.get $7)
          )
         )
         (local.set $6
          (i32.add
           (local.get $6)
           (local.get $7)
          )
         )
         (local.set $8
          (i32.sub
           (local.get $8)
           (local.get $7)
          )
         )
         (br $label1)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function33 (type $call21) (param $0 (ref eq)) (param $1 i64) (param $2 i64) (result (ref eq))
  (local $3 i32)
  (local $4 i64)
  (local $5 (ref eq))
  (if (result (ref eq))
   (if (result i32)
    (local.tee $3
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $3)
    )
    (else
     (if (result i32)
      (local.tee $3
       (i64.gt_s
        (local.get $1)
        (local.get $2)
       )
      )
      (then
       (local.get $3)
      )
      (else
       (i64.lt_s
        (if (result i64)
         (ref.test (ref $type15)
          (local.get $0)
         )
         (then
          (i64.sub
           (i64.extend_i32_u
            (array.len
             (ref.cast (ref $type15)
              (local.get $0)
             )
            )
           )
           (i64.const 1)
          )
         )
         (else
          (i64.extend_i32_u
           (struct.get $type16 0
            (ref.cast (ref $type16)
             (local.get $0)
            )
           )
          )
         )
        )
        (local.get $2)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (i64.sub
        (local.get $2)
        (local.get $1)
       )
      )
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (call $string-copy
     (local.tee $5
      (call $string-new
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (i64.const 0)
     (local.get $0)
     (local.get $1)
     (local.get $2)
    )
    (local.get $5)
   )
  )
 )
 (func $function35 (type $call23) (param $0 (ref $type24)) (result (ref eq))
  (local $1 (ref eq))
  (local $2 (ref null $type24))
  (local $3 (ref null $type24))
  (local $4 i64)
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $4
   (if (result i64)
    (i64.gt_s
     (local.tee $4
      (if (result i64)
       (ref.test (ref $type15)
        (local.tee $1
         (struct.get $type24 0
          (local.get $0)
         )
        )
       )
       (then
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (ref.cast (ref $type15)
            (local.get $1)
           )
          )
         )
         (i64.const 1)
        )
       )
       (else
        (i64.extend_i32_u
         (struct.get $type16 0
          (ref.cast (ref $type16)
           (local.get $1)
          )
         )
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $3
        (struct.get $type24 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $4)
      )
      (else
       (local.set $2
        (struct.get $type24 1
         (local.get $3)
        )
       )
       (if (result i64)
        (i64.gt_s
         (local.tee $4
          (i64.add
           (if (result i64)
            (ref.test (ref $type15)
             (local.tee $1
              (struct.get $type24 0
               (local.get $3)
              )
             )
            )
            (then
             (i64.sub
              (i64.extend_i32_u
               (array.len
                (ref.cast (ref $type15)
                 (local.get $1)
                )
               )
              )
              (i64.const 1)
             )
            )
            (else
             (i64.extend_i32_u
              (struct.get $type16 0
               (ref.cast (ref $type16)
                (local.get $1)
               )
              )
             )
            )
           )
           (local.get $4)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (local.get $4)
          )
          (else
           (local.set $3
            (struct.get $type24 1
             (local.get $2)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $4
              (i64.add
               (if (result i64)
                (ref.test (ref $type15)
                 (local.tee $1
                  (struct.get $type24 0
                   (local.get $2)
                  )
                 )
                )
                (then
                 (i64.sub
                  (i64.extend_i32_u
                   (array.len
                    (ref.cast (ref $type15)
                     (local.get $1)
                    )
                   )
                  )
                  (i64.const 1)
                 )
                )
                (else
                 (i64.extend_i32_u
                  (struct.get $type16 0
                   (ref.cast (ref $type16)
                    (local.get $1)
                   )
                  )
                 )
                )
               )
               (local.get $4)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $3)
              )
              (then
               (local.get $4)
              )
              (else
               (local.set $2
                (struct.get $type24 1
                 (local.get $3)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $4
                  (i64.add
                   (if (result i64)
                    (ref.test (ref $type15)
                     (local.tee $1
                      (struct.get $type24 0
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.sub
                      (i64.extend_i32_u
                       (array.len
                        (ref.cast (ref $type15)
                         (local.get $1)
                        )
                       )
                      )
                      (i64.const 1)
                     )
                    )
                    (else
                     (i64.extend_i32_u
                      (struct.get $type16 0
                       (ref.cast (ref $type16)
                        (local.get $1)
                       )
                      )
                     )
                    )
                   )
                   (local.get $4)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (local.get $4)
                  )
                  (else
                   (call $function37
                    (i32.const 0)
                    (i32.const 1)
                    (struct.get $type24 1
                     (local.get $2)
                    )
                    (i64.add
                     (if (result i64)
                      (ref.test (ref $type15)
                       (local.tee $1
                        (struct.get $type24 0
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (i64.sub
                        (i64.extend_i32_u
                         (array.len
                          (ref.cast (ref $type15)
                           (local.get $1)
                          )
                         )
                        )
                        (i64.const 1)
                       )
                      )
                      (else
                       (i64.extend_i32_u
                        (struct.get $type16 0
                         (ref.cast (ref $type16)
                          (local.get $1)
                         )
                        )
                       )
                      )
                     )
                     (local.get $4)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $1
   (call $string-new
    (i32.wrap_i64
     (local.get $4)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (call $function38
    (local.get $1)
    (local.get $0)
    (i64.const 0)
   )
  )
  (local.get $1)
 )
 (func $function37 (type $4) (param $0 i32) (param $1 i32) (param $2 (ref null $type24)) (param $3 i64) (result i64)
  (local $4 (ref eq))
  (local $5 (ref null $type24))
  (local $6 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $5
       (struct.get $type24 1
        (local.get $2)
       )
      )
      (local.set $6
       (if (result i64)
        (ref.test (ref $type15)
         (local.tee $4
          (struct.get $type24 0
           (local.get $2)
          )
         )
        )
        (then
         (i64.sub
          (i64.extend_i32_u
           (array.len
            (ref.cast (ref $type15)
             (local.get $4)
            )
           )
          )
          (i64.const 1)
         )
        )
        (else
         (i64.extend_i32_u
          (struct.get $type16 0
           (ref.cast (ref $type16)
            (local.get $4)
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $5)
       (i64.add
        (local.get $3)
        (local.get $6)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call26) (param $0 (ref eq)) (param $1 (ref null $type24)) (param $2 i64) (result i32)
  (local $3 (ref eq))
  (local $4 i64)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $3
      (struct.get $type24 0
       (local.get $1)
      )
     )
     (i64.const 0)
     (local.tee $4
      (if (result i64)
       (ref.test (ref $type15)
        (local.get $3)
       )
       (then
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (ref.cast (ref $type15)
            (local.get $3)
           )
          )
         )
         (i64.const 1)
        )
       )
       (else
        (i64.extend_i32_u
         (struct.get $type16 0
          (ref.cast (ref $type16)
           (local.get $3)
          )
         )
        )
       )
      )
     )
    )
    (local.set $1
     (struct.get $type24 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function43 (type $1) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.eqz
      (global.get $ready119)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global119)
     )
    )
    (local.set $4
     (call $function46
      (call $foreign0
       (global.get $global111)
      )
      (block (result i32)
       (if
        (i32.eqz
         (global.get $ready122)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global122)
        )
       )
       (i32.const 0)
      )
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (i64.extend_i32_u
     (i32.ne
      (if (result i32)
       (i64.eqz
        (local.get $3)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready112)
         )
         (then
          (unreachable)
         )
        )
        (i64.eqz
         (global.get $global112)
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready112)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (i64.eq
          (global.get $global112)
          (i64.const 2)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready113)
           )
           (then
            (unreachable)
           )
          )
          (i64.eq
           (global.get $global113)
           (local.get $4)
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function46 (type $0) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 (ref eq))
  (if (result i64)
   (i64.ge_s
    (local.get $3)
    (i64.const 10)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (ref.test (ref $type15)
      (local.tee $4
       (struct.get $type29 0
        (global.get $global109)
       )
      )
     )
     (then
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (ref.cast (ref $type15)
          (local.get $4)
         )
        )
       )
       (i64.const 1)
      )
     )
     (else
      (i64.extend_i32_u
       (struct.get $type16 0
        (ref.cast (ref $type16)
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type29 0
     (global.get $global109)
     (global.get $string3)
    )
    (if
     (i32.eqz
      (global.get $ready126)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global126)
     )
    )
    (drop
     (call $function48
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function48 (type $0) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 (ref eq))
  (local $5 (ref eq))
  (local $6 (ref eq))
  (local $7 (ref $type29))
  (local $8 i64)
  (local $9 i64)
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (i64.gt_s
    (if (result i64)
     (ref.test (ref $type15)
      (local.tee $4
       (struct.get $type29 0
        (global.get $global109)
       )
      )
     )
     (then
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (ref.cast (ref $type15)
          (local.get $4)
         )
        )
       )
       (i64.const 1)
      )
     )
     (else
      (i64.extend_i32_u
       (struct.get $type16 0
        (ref.cast (ref $type16)
         (local.get $4)
        )
       )
      )
     )
    )
    (local.get $0)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (if (result i64)
     (ref.test (ref $type15)
      (local.tee $4
       (struct.get $type29 0
        (global.get $global109)
       )
      )
     )
     (then
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (ref.cast (ref $type15)
          (local.get $4)
         )
        )
       )
       (i64.const 1)
      )
     )
     (else
      (i64.extend_i32_u
       (struct.get $type16 0
        (ref.cast (ref $type16)
         (local.get $4)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type29 0
     (ref.as_non_null
      (global.get $global109)
     )
     (block (result (ref eq))
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (struct.get $type29 0
        (global.get $global109)
       )
      )
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (struct.get $type29 0
        (global.get $global109)
       )
      )
      (if
       (i32.eqz
        (global.get $ready90)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global90)
       )
      )
      (call $function35
       (struct.new $type24
        (global.get $string0)
        (struct.new $type24
         (local.get $4)
         (struct.new $type24
          (global.get $string1)
          (struct.new $type24
           (local.get $5)
           (struct.new $type24
            (global.get $string2)
            (ref.null none)
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type29 0
     (ref.as_non_null
      (global.get $global109)
     )
     (block (result (ref eq))
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (call $function35
       (struct.new $type24
        (call $function33
         (struct.get $type29 0
          (global.get $global109)
         )
         (block (result i64)
          (if
           (i32.eqz
            (global.get $ready109)
           )
           (then
            (unreachable)
           )
          )
          (i64.div_s
           (if (result i64)
            (ref.test (ref $type15)
             (local.tee $4
              (struct.get $type29 0
               (global.get $global109)
              )
             )
            )
            (then
             (i64.sub
              (i64.extend_i32_u
               (array.len
                (ref.cast (ref $type15)
                 (local.get $4)
                )
               )
              )
              (i64.const 1)
             )
            )
            (else
             (i64.extend_i32_u
              (struct.get $type16 0
               (ref.cast (ref $type16)
                (local.get $4)
               )
              )
             )
            )
           )
           (block (result i64)
            (if
             (i32.eqz
              (global.get $ready109)
             )
             (then
              (unreachable)
             )
            )
            (local.set $9
             (if (result i64)
              (ref.test (ref $type15)
               (local.tee $4
                (struct.get $type29 0
                 (global.get $global109)
                )
               )
              )
              (then
               (i64.sub
                (i64.extend_i32_u
                 (array.len
                  (ref.cast (ref $type15)
                   (local.get $4)
                  )
                 )
                )
                (i64.const 1)
               )
              )
              (else
               (i64.extend_i32_u
                (struct.get $type16 0
                 (ref.cast (ref $type16)
                  (local.get $4)
                 )
                )
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready81)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global81)
             )
            )
            (i64.const 2)
           )
          )
         )
         (local.get $9)
        )
        (block (result (ref (exact $type24)))
         (if
          (i32.eqz
           (global.get $ready109)
          )
          (then
           (unreachable)
          )
         )
         (struct.new $type24
          (call $function33
           (struct.get $type29 0
            (global.get $global109)
           )
           (block (result i64)
            (if
             (i32.eqz
              (global.get $ready109)
             )
             (then
              (unreachable)
             )
            )
            (local.set $8
             (if (result i64)
              (ref.test (ref $type15)
               (local.tee $4
                (struct.get $type29 0
                 (global.get $global109)
                )
               )
              )
              (then
               (i64.sub
                (i64.extend_i32_u
                 (array.len
                  (ref.cast (ref $type15)
                   (local.get $4)
                  )
                 )
                )
                (i64.const 1)
               )
              )
              (else
               (i64.extend_i32_u
                (struct.get $type16 0
                 (ref.cast (ref $type16)
                  (local.get $4)
                 )
                )
               )
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready81)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global81)
             )
            )
            (i64.const 0)
           )
           (i64.add
            (i64.div_s
             (local.get $8)
             (i64.const 2)
            )
            (i64.const 1)
           )
          )
          (block (result nullref)
           (if
            (i32.eqz
             (global.get $ready90)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global90)
            )
           )
           (ref.null none)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (struct.get $type29 0
      (global.get $global109)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (return_call $function43
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
   (i64.const 0)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type21)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global90
   (struct.new_default $type23)
  )
  (global.set $ready90
   (i32.const 1)
  )
  (global.set $global93
   (struct.new_default $type25)
  )
  (global.set $ready93
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type26)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global119
   (struct.new_default $type28)
  )
  (global.set $ready119
   (i32.const 1)
  )
  (global.set $global109
   (struct.new $type29
    (global.get $string3)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type30)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global126
   (struct.new_default $type31)
  )
  (global.set $ready126
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type31)
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global111
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global112
   (call $foreign1
    (i32.const 1)
   )
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $global113
   (call $foreign1
    (i32.const 2)
   )
  )
  (global.set $ready113
   (i32.const 1)
  )
  (global.set $global114
   (struct.new_default $type31)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

