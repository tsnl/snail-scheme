(module
 (rec
  (type $0 (func (param i32 i32 i64 i64) (result i64)))
  (type $call29 (func (param i64 i64) (result i64)))
  (type $2 (func (param i64 i32 i32 i64 i64) (result i64)))
  (type $call30 (func (param i64) (result i64)))
  (type $type17 (array (mut (ref null $type15))))
  (type $type15 (array (mut i32)))
  (type $type16 (struct (field i32) (field (ref $type15)) (field (ref $type17))))
  (type $7 (func (param i32 i32 i64) (result i32)))
  (type $type5 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type13 (struct))
 )
 (type $13 (func (param i64) (result i64)))
 (type $14 (func (param i32) (result i64)))
 (type $15 (func (param i64) (result i32)))
 (type $16 (func (result i64)))
 (type $17 (func))
 (import "benchmark" "hide_i64" (func $foreign0 (param i64) (result i64)))
 (import "benchmark" "input_i64" (func $foreign1 (param i32) (result i64)))
 (global $execution (mut i32) (i32.const 0))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global109 (mut i64) (i64.const 0))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut eqref) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type28)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type29)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type30)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type28)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type5)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "probe-character" (func $export1))
 (export "probe-length" (func $export2))
 (export "main" (func $main))
 (func $function42 (type $7) (param $0 i32) (param $1 i32) (param $2 i64) (result i32)
  (local $3 (ref eq))
  (local $4 (ref $type16))
  (local $5 i64)
  (local $6 i32)
  (local $7 i32)
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (i64.eq
    (global.get $global109)
    (local.get $2)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.set $6
     (if (result i32)
      (i64.eqz
       (local.tee $5
        (i64.rem_s
         (local.get $2)
         (i64.const 5)
        )
       )
      )
      (then
       (i32.const 0)
      )
      (else
       (if (result i32)
        (i64.eq
         (local.get $5)
         (i64.const 1)
        )
        (then
         (i32.const 233)
        )
        (else
         (if (result i32)
          (i64.eq
           (local.get $5)
           (i64.const 2)
          )
          (then
           (i32.const 128512)
          )
          (else
           (select
            (i32.const 1114111)
            (i32.const 769)
            (i64.eq
             (local.get $5)
             (i64.const 3)
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.ne
      (if (result i32)
       (ref.test (ref $type15)
        (local.get $3)
       )
       (then
        (array.get $type15
         (ref.cast (ref $type15)
          (local.get $3)
         )
         (i32.const 0)
        )
       )
       (else
        (drop
         (ref.cast (ref $type16)
          (local.get $3)
         )
        )
        (i32.const 1)
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (ref.test (ref $type15)
      (local.get $3)
     )
     (then
      (if
       (i64.gt_u
        (local.get $2)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type15
       (ref.cast (ref $type15)
        (local.get $3)
       )
       (i32.add
        (i32.wrap_i64
         (local.get $2)
        )
        (i32.const 1)
       )
       (local.get $6)
      )
     )
     (else
      (if
       (i64.ge_u
        (local.get $2)
        (i64.extend_i32_u
         (struct.get $type16 0
          (ref.cast (ref $type16)
           (local.get $3)
          )
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (ref.cast (ref $type16)
        (local.get $3)
       )
      )
      (array.set $type15
       (if (result (ref $type15))
        (i32.lt_u
         (local.tee $7
          (i32.wrap_i64
           (local.get $2)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type16 1
          (local.get $4)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type17
           (struct.get $type16 2
            (local.get $4)
           )
           (i32.sub
            (i32.shr_u
             (local.get $7)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $7)
        (i32.const 8191)
       )
       (local.get $6)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function43 (type $call30) (param $0 i64) (result i64)
  (local $1 i64)
  (local $2 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (i64.const 0)
   )
   (then
    (local.set $1
     (call $foreign0
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready121)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global121)
     )
    )
    (local.set $1
     (call $function46
      (i32.const 0)
      (i32.const 1)
      (local.get $1)
      (i64.const 0)
     )
    )
    (if (result i64)
     (i64.gt_s
      (local.get $0)
      (i64.const 1)
     )
     (then
      (local.set $2
       (call $foreign0
        (i64.const 0)
       )
      )
      (if
       (i32.eqz
        (global.get $ready121)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global121)
       )
      )
      (local.set $1
       (call $function46
        (i32.const 0)
        (i32.const 1)
        (local.get $2)
        (local.get $1)
       )
      )
      (if (result i64)
       (i64.gt_s
        (local.get $0)
        (i64.const 2)
       )
       (then
        (local.set $2
         (call $foreign0
          (i64.const 0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready121)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global121)
         )
        )
        (local.set $1
         (call $function46
          (i32.const 0)
          (i32.const 1)
          (local.get $2)
          (local.get $1)
         )
        )
        (if (result i64)
         (i64.gt_s
          (local.get $0)
          (i64.const 3)
         )
         (then
          (local.set $2
           (call $foreign0
            (i64.const 0)
           )
          )
          (if
           (i32.eqz
            (global.get $ready121)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global121)
           )
          )
          (local.set $1
           (call $function46
            (i32.const 0)
            (i32.const 1)
            (local.get $2)
            (local.get $1)
           )
          )
          (if (result i64)
           (i64.gt_s
            (local.get $0)
            (i64.const 4)
           )
           (then
            (local.set $2
             (call $foreign0
              (i64.const 0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready121)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global121)
             )
            )
            (local.set $1
             (call $function46
              (i32.const 0)
              (i32.const 1)
              (local.get $2)
              (local.get $1)
             )
            )
            (if (result i64)
             (i64.gt_s
              (local.get $0)
              (i64.const 5)
             )
             (then
              (local.set $2
               (call $foreign0
                (i64.const 0)
               )
              )
              (if
               (i32.eqz
                (global.get $ready121)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global121)
               )
              )
              (local.set $1
               (call $function46
                (i32.const 0)
                (i32.const 1)
                (local.get $2)
                (local.get $1)
               )
              )
              (if (result i64)
               (i64.gt_s
                (local.get $0)
                (i64.const 6)
               )
               (then
                (local.set $2
                 (call $foreign0
                  (i64.const 0)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready121)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global121)
                 )
                )
                (local.set $1
                 (call $function46
                  (i32.const 0)
                  (i32.const 1)
                  (local.get $2)
                  (local.get $1)
                 )
                )
                (if (result i64)
                 (i64.gt_s
                  (local.get $0)
                  (i64.const 7)
                 )
                 (then
                  (local.set $2
                   (call $foreign0
                    (i64.const 0)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready121)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global121)
                   )
                  )
                  (local.set $1
                   (call $function46
                    (i32.const 0)
                    (i32.const 1)
                    (local.get $2)
                    (local.get $1)
                   )
                  )
                  (if (result i64)
                   (i64.gt_s
                    (local.get $0)
                    (i64.const 8)
                   )
                   (then
                    (local.set $2
                     (call $foreign0
                      (i64.const 0)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready121)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global121)
                     )
                    )
                    (local.set $1
                     (call $function46
                      (i32.const 0)
                      (i32.const 1)
                      (local.get $2)
                      (local.get $1)
                     )
                    )
                    (if (result i64)
                     (i64.gt_s
                      (local.get $0)
                      (i64.const 9)
                     )
                     (then
                      (local.set $2
                       (call $foreign0
                        (i64.const 0)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready121)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global121)
                       )
                      )
                      (local.set $1
                       (call $function46
                        (i32.const 0)
                        (i32.const 1)
                        (local.get $2)
                        (local.get $1)
                       )
                      )
                      (if (result i64)
                       (i64.gt_s
                        (local.get $0)
                        (i64.const 10)
                       )
                       (then
                        (local.set $2
                         (call $foreign0
                          (i64.const 0)
                         )
                        )
                        (if
                         (i32.eqz
                          (global.get $ready121)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global121)
                         )
                        )
                        (local.set $1
                         (call $function46
                          (i32.const 0)
                          (i32.const 1)
                          (local.get $2)
                          (local.get $1)
                         )
                        )
                        (if (result i64)
                         (i64.gt_s
                          (local.get $0)
                          (i64.const 11)
                         )
                         (then
                          (local.set $2
                           (call $foreign0
                            (i64.const 0)
                           )
                          )
                          (if
                           (i32.eqz
                            (global.get $ready121)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global121)
                           )
                          )
                          (local.set $1
                           (call $function46
                            (i32.const 0)
                            (i32.const 1)
                            (local.get $2)
                            (local.get $1)
                           )
                          )
                          (if (result i64)
                           (i64.gt_s
                            (local.get $0)
                            (i64.const 12)
                           )
                           (then
                            (local.set $2
                             (call $foreign0
                              (i64.const 0)
                             )
                            )
                            (if
                             (i32.eqz
                              (global.get $ready121)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global121)
                             )
                            )
                            (local.set $1
                             (call $function46
                              (i32.const 0)
                              (i32.const 1)
                              (local.get $2)
                              (local.get $1)
                             )
                            )
                            (if (result i64)
                             (i64.gt_s
                              (local.get $0)
                              (i64.const 13)
                             )
                             (then
                              (local.set $2
                               (call $foreign0
                                (i64.const 0)
                               )
                              )
                              (if
                               (i32.eqz
                                (global.get $ready121)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global121)
                               )
                              )
                              (local.set $1
                               (call $function46
                                (i32.const 0)
                                (i32.const 1)
                                (local.get $2)
                                (local.get $1)
                               )
                              )
                              (if (result i64)
                               (i64.gt_s
                                (local.get $0)
                                (i64.const 14)
                               )
                               (then
                                (local.set $2
                                 (call $foreign0
                                  (i64.const 0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready121)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global121)
                                 )
                                )
                                (return_call $function44
                                 (local.get $0)
                                 (i32.const 0)
                                 (i32.const 1)
                                 (i64.const 15)
                                 (call $function45
                                  (local.get $2)
                                  (local.get $1)
                                 )
                                )
                               )
                               (else
                                (local.get $1)
                               )
                              )
                             )
                             (else
                              (local.get $1)
                             )
                            )
                           )
                           (else
                            (local.get $1)
                           )
                          )
                         )
                         (else
                          (local.get $1)
                         )
                        )
                       )
                       (else
                        (local.get $1)
                       )
                      )
                     )
                     (else
                      (local.get $1)
                     )
                    )
                   )
                   (else
                    (local.get $1)
                   )
                  )
                 )
                 (else
                  (local.get $1)
                 )
                )
               )
               (else
                (local.get $1)
               )
              )
             )
             (else
              (local.get $1)
             )
            )
           )
           (else
            (local.get $1)
           )
          )
         )
         (else
          (local.get $1)
         )
        )
       )
       (else
        (local.get $1)
       )
      )
     )
     (else
      (local.get $1)
     )
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function44 (type $2) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result i64)
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (local.get $3)
   )
   (then
    (local.set $4
     (call $function45
      (call $foreign0
       (i64.const 0)
      )
      (block (result i64)
       (if
        (i32.eqz
         (global.get $ready121)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global121)
        )
       )
       (local.get $4)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function44
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (else
    (local.get $4)
   )
  )
 )
 (func $function45 (type $call29) (param $0 i64) (param $1 i64) (result i64)
  (return_call $function46
   (i32.const 0)
   (i32.const 1)
   (local.get $0)
   (local.get $1)
  )
 )
 (func $function46 (type $0) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (local $4 i32)
  (local $5 (ref eq))
  (local $6 (ref $type16))
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (i64.eq
    (global.get $global109)
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (local.set $4
     (if (result i32)
      (ref.test (ref $type15)
       (local.tee $5
        (ref.as_non_null
         (global.get $global110)
        )
       )
      )
      (then
       (if
        (i64.gt_u
         (local.get $2)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
       )
       (array.get $type15
        (ref.cast (ref $type15)
         (local.get $5)
        )
        (i32.add
         (i32.wrap_i64
          (local.get $2)
         )
         (i32.const 1)
        )
       )
      )
      (else
       (if
        (i64.ge_u
         (local.get $2)
         (i64.extend_i32_u
          (struct.get $type16 0
           (ref.cast (ref $type16)
            (local.get $5)
           )
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (local.set $6
        (ref.cast (ref $type16)
         (local.get $5)
        )
       )
       (array.get $type15
        (if (result (ref $type15))
         (i32.lt_u
          (local.tee $4
           (i32.wrap_i64
            (local.get $2)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type16 1
           (local.get $6)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type17
            (struct.get $type16 2
             (local.get $6)
            )
            (i32.sub
             (i32.shr_u
              (local.get $4)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $4)
         (i32.const 8191)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (i64.const 1)
     )
     (i64.add
      (i64.extend_i32_u
       (local.get $4)
      )
      (local.get $3)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (return_call $function43
   (local.get $0)
  )
 )
 (func $export1 (param $0 i64) (result i32)
  (local $1 (ref eq))
  (local $2 (ref $type16))
  (local $3 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (ref.test (ref $type15)
    (local.tee $1
     (ref.as_non_null
      (global.get $global110)
     )
    )
   )
   (then
    (if
     (i64.gt_u
      (local.get $0)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (array.get $type15
     (ref.cast (ref $type15)
      (local.get $1)
     )
     (i32.add
      (i32.wrap_i64
       (local.get $0)
      )
      (i32.const 1)
     )
    )
   )
   (else
    (if
     (i64.ge_u
      (local.get $0)
      (i64.extend_i32_u
       (struct.get $type16 0
        (ref.cast (ref $type16)
         (local.get $1)
        )
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (ref.cast (ref $type16)
      (local.get $1)
     )
    )
    (array.get $type15
     (if (result (ref $type15))
      (i32.lt_u
       (local.tee $3
        (i32.wrap_i64
         (local.get $0)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type16 1
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type17
         (struct.get $type16 2
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $3)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $3)
      (i32.const 8191)
     )
    )
   )
  )
 )
 (func $export2 (result i64)
  (local $0 (ref eq))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (ref.test (ref $type15)
    (local.tee $0
     (ref.as_non_null
      (global.get $global110)
     )
    )
   )
   (then
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (ref.cast (ref $type15)
        (local.get $0)
       )
      )
     )
     (i64.const 1)
    )
   )
   (else
    (i64.extend_i32_u
     (struct.get $type16 0
      (ref.cast (ref $type16)
       (local.get $0)
      )
     )
    )
   )
  )
 )
 (func $main
  (local $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (local $5 (ref $type15))
  (local $6 (ref $type17))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global109
   (call $foreign1
    (i32.const 0)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.tee $4
     (global.get $global109)
    )
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global110
   (if (result (ref eq))
    (i32.le_u
     (local.tee $0
      (i32.wrap_i64
       (local.get $4)
      )
     )
     (i32.const 8192)
    )
    (then
     (array.set $type15
      (local.tee $5
       (array.new_default $type15
        (i32.add
         (local.get $0)
         (i32.const 1)
        )
       )
      )
      (i32.const 0)
      (i32.const 1)
     )
     (local.get $5)
    )
    (else
     (local.set $5
      (array.new_default $type15
       (i32.const 8192)
      )
     )
     (local.set $1
      (i32.add
       (local.get $0)
       (i32.const -8192)
      )
     )
     (local.set $6
      (array.new_default $type17
       (i32.shr_u
        (i32.sub
         (local.get $0)
         (i32.const 1)
        )
        (i32.const 13)
       )
      )
     )
     (loop $label
      (array.set $type17
       (local.get $6)
       (local.get $2)
       (array.new_default $type15
        (local.tee $3
         (select
          (i32.const 8192)
          (local.get $1)
          (i32.ge_u
           (local.get $1)
           (i32.const 8192)
          )
         )
        )
       )
      )
      (local.set $2
       (i32.add
        (local.get $2)
        (i32.const 1)
       )
      )
      (br_if $label
       (local.tee $1
        (i32.sub
         (local.get $1)
         (local.get $3)
        )
       )
      )
     )
     (struct.new $type16
      (local.get $0)
      (local.get $5)
      (local.get $6)
     )
    )
   )
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type28)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (drop
   (call $function42
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (global.set $global121
   (struct.new_default $type29)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type30)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type28)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type5)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

