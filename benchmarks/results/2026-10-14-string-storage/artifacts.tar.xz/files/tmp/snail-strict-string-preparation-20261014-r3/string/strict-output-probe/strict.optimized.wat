(module
 (rec
  (type $0 (func (param i64 i32 i32 i64) (result i64)))
  (type $1 (func (param (ref $type14) i32 i32 i64) (result i32)))
  (type $call26 (func (result (ref $type14))))
  (type $call23 (func (param (ref $type14) (ref null $type21) i64) (result i32)))
  (type $4 (func (param i32 i32 (ref null $type21) i64) (result i64)))
  (type $type21 (struct (field (ref $type14)) (field (ref null $type21))))
  (type $call20 (func (param (ref $type21)) (result (ref $type14))))
  (type $call18 (func (param (ref $type14) i64 i64) (result (ref $type14))))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type5 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct (field (mut (ref $type14)))))
  (type $type23 (struct))
  (type $type22 (struct))
  (type $type20 (struct))
  (type $type18 (struct))
  (type $type13 (struct))
  (type $type14 (array (mut i32)))
 )
 (type $22 (func (param i64)))
 (type $23 (func (result i64)))
 (type $24 (func (result i32)))
 (type $25 (func (param i32)))
 (type $26 (func (param i64) (result i64)))
 (type $27 (func (param i64 i32)))
 (type $28 (func (param i64) (result i32)))
 (type $29 (func))
 (import "probe" "length" (func $foreign0 (param i64)))
 (import "probe" "trace" (func $foreign1 (result i32)))
 (import "probe" "character" (func $foreign2 (param i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (array.new_fixed $type14 4
  (i32.const 0)
  (i32.const 49)
  (i32.const 50)
  (i32.const 51)
 ))
 (global $string1 (ref $type14) (array.new_fixed $type14 4
  (i32.const 0)
  (i32.const 52)
  (i32.const 53)
  (i32.const 54)
 ))
 (global $string2 (ref $type14) (array.new_fixed $type14 4
  (i32.const 0)
  (i32.const 55)
  (i32.const 56)
  (i32.const 57)
 ))
 (global $string3 (ref $type14) (array.new_fixed $type14 7
  (i32.const 0)
  (i32.const 97)
  (i32.const 98)
  (i32.const 99)
  (i32.const 100)
  (i32.const 101)
  (i32.const 102)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type18)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type20)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type22)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type23)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type25)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type26)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global122 (mut (ref null $type27)) (ref.null none))
 (global $ready122 (mut i32) (i32.const 0))
 (global $global118 (mut (ref null $type27)) (ref.null none))
 (global $ready118 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type28)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type27)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global126 (mut (ref null $type5)) (ref.null none))
 (global $ready126 (mut i32) (i32.const 0))
 (global $global127 (mut (ref null $type29)) (ref.null none))
 (global $ready127 (mut i32) (i32.const 0))
 (global $global129 (mut (ref null $type30)) (ref.null none))
 (global $ready129 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type31)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (global $global134 (mut (ref null $type5)) (ref.null none))
 (global $ready134 (mut i32) (i32.const 0))
 (export "probe-run" (func $export0))
 (export "probe-grow" (func $export1))
 (export "probe-seed" (func $export2))
 (export "probe-set-character" (func $export3))
 (export "probe-character" (func $export4))
 (export "probe-length" (func $export5))
 (export "main" (func $main))
 (func $function33 (type $call18) (param $0 (ref $type14)) (param $1 i64) (param $2 i64) (result (ref $type14))
  (local $3 i32)
  (local $4 i64)
  (local $5 (ref $type14))
  (if (result (ref $type14))
   (if (result i32)
    (local.tee $3
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $3)
    )
    (else
     (if (result i32)
      (local.tee $3
       (i64.gt_s
        (local.get $1)
        (local.get $2)
       )
      )
      (then
       (local.get $3)
      )
      (else
       (i64.lt_s
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (i64.const 1)
        )
        (local.get $2)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (i64.sub
        (local.get $2)
        (local.get $1)
       )
      )
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.tee $5
      (array.new_default $type14
       (i32.add
        (i32.wrap_i64
         (local.get $4)
        )
        (i32.const 1)
       )
      )
     )
     (i32.const 0)
     (i32.const 1)
    )
    (if
     (i32.ne
      (array.get $type14
       (local.get $5)
       (i32.const 0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (local.get $1)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (i64.sub
       (local.get $2)
       (local.get $1)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type14 $type14
     (local.get $5)
     (i32.const 1)
     (local.get $0)
     (i32.add
      (i32.wrap_i64
       (local.get $1)
      )
      (i32.const 1)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $2)
       (local.get $1)
      )
     )
    )
    (local.get $5)
   )
  )
 )
 (func $function35 (type $call20) (param $0 (ref $type21)) (result (ref $type14))
  (local $1 i64)
  (local $2 (ref null $type21))
  (local $3 (ref null $type21))
  (local $4 (ref $type14))
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $1
   (if (result i64)
    (i64.gt_s
     (local.tee $1
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (struct.get $type21 0
          (local.get $0)
         )
        )
       )
       (i64.const 1)
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $3
        (struct.get $type21 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $1)
      )
      (else
       (local.set $2
        (struct.get $type21 1
         (local.get $3)
        )
       )
       (if (result i64)
        (i64.gt_s
         (local.tee $1
          (i64.add
           (i64.sub
            (i64.extend_i32_u
             (array.len
              (struct.get $type21 0
               (local.get $3)
              )
             )
            )
            (i64.const 1)
           )
           (local.get $1)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (local.get $1)
          )
          (else
           (local.set $3
            (struct.get $type21 1
             (local.get $2)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $1
              (i64.add
               (i64.sub
                (i64.extend_i32_u
                 (array.len
                  (struct.get $type21 0
                   (local.get $2)
                  )
                 )
                )
                (i64.const 1)
               )
               (local.get $1)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $3)
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $2
                (struct.get $type21 1
                 (local.get $3)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $1
                  (i64.add
                   (i64.sub
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type21 0
                       (local.get $3)
                      )
                     )
                    )
                    (i64.const 1)
                   )
                   (local.get $1)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $3
                    (struct.get $type21 1
                     (local.get $2)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.tee $1
                      (i64.add
                       (i64.sub
                        (i64.extend_i32_u
                         (array.len
                          (struct.get $type21 0
                           (local.get $2)
                          )
                         )
                        )
                        (i64.const 1)
                       )
                       (local.get $1)
                      )
                     )
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (local.set $2
                        (struct.get $type21 1
                         (local.get $3)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.tee $1
                          (i64.add
                           (i64.sub
                            (i64.extend_i32_u
                             (array.len
                              (struct.get $type21 0
                               (local.get $3)
                              )
                             )
                            )
                            (i64.const 1)
                           )
                           (local.get $1)
                          )
                         )
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $2)
                          )
                          (then
                           (local.get $1)
                          )
                          (else
                           (local.set $3
                            (struct.get $type21 1
                             (local.get $2)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.tee $1
                              (i64.add
                               (i64.sub
                                (i64.extend_i32_u
                                 (array.len
                                  (struct.get $type21 0
                                   (local.get $2)
                                  )
                                 )
                                )
                                (i64.const 1)
                               )
                               (local.get $1)
                              )
                             )
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (local.get $1)
                              )
                              (else
                               (local.set $2
                                (struct.get $type21 1
                                 (local.get $3)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.tee $1
                                  (i64.add
                                   (i64.sub
                                    (i64.extend_i32_u
                                     (array.len
                                      (struct.get $type21 0
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (i64.const 1)
                                   )
                                   (local.get $1)
                                  )
                                 )
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                  (then
                                   (local.get $1)
                                  )
                                  (else
                                   (call $function37
                                    (i32.const 0)
                                    (i32.const 1)
                                    (struct.get $type21 1
                                     (local.get $2)
                                    )
                                    (i64.add
                                     (i64.sub
                                      (i64.extend_i32_u
                                       (array.len
                                        (struct.get $type21 0
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (i64.const 1)
                                     )
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type14
   (local.tee $4
    (array.new_default $type14
     (i32.add
      (i32.wrap_i64
       (local.get $1)
      )
      (i32.const 1)
     )
    )
   )
   (i32.const 0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (call $function38
    (local.get $4)
    (local.get $0)
    (i64.const 0)
   )
  )
  (local.get $4)
 )
 (func $function37 (type $4) (param $0 i32) (param $1 i32) (param $2 (ref null $type21)) (param $3 i64) (result i64)
  (local $4 (ref null $type21))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $4
       (struct.get $type21 1
        (local.get $2)
       )
      )
      (local.set $5
       (i64.sub
        (i64.extend_i32_u
         (array.len
          (struct.get $type21 0
           (local.get $2)
          )
         )
        )
        (i64.const 1)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (i64.add
        (local.get $3)
        (local.get $5)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call23) (param $0 (ref $type14)) (param $1 (ref null $type21)) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 (ref $type14))
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.tee $4
         (struct.get $type21 0
          (local.get $1)
         )
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i32.ne
      (array.get $type14
       (local.get $0)
       (i32.const 0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (local.get $3)
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type14 $type14
     (local.get $0)
     (i32.add
      (i32.wrap_i64
       (local.get $2)
      )
      (i32.const 1)
     )
     (local.get $4)
     (i32.const 1)
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.set $1
     (struct.get $type21 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function41 (type $call26) (result (ref $type14))
  (local $0 (ref $type14))
  (local $1 (ref $type14))
  (local $2 (ref $type14))
  (local $3 (ref $type14))
  (local $4 (ref $type25))
  (local $5 i64)
  (local $6 i64)
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (ref.as_non_null
    (global.get $global109)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (struct.get $type25 0
      (global.get $global109)
     )
    )
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (local.set $2
     (struct.get $type25 0
      (global.get $global109)
     )
    )
    (if
     (i32.eqz
      (global.get $ready90)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global90)
     )
    )
    (local.set $0
     (call $function35
      (struct.new $type21
       (global.get $string0)
       (struct.new $type21
        (local.get $1)
        (struct.new $type21
         (global.get $string1)
         (struct.new $type21
          (local.get $2)
          (struct.new $type21
           (global.get $string2)
           (ref.null none)
          )
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.get $0)
   )
  )
  (drop
   (if (result i32)
    (call $foreign1)
    (then
     (call $foreign0
      (i64.sub
       (local.tee $5
        (i64.extend_i32_u
         (array.len
          (local.get $0)
         )
        )
       )
       (i64.const 1)
      )
     )
     (if (result i32)
      (i64.eq
       (local.get $5)
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $foreign2
        (array.get $type14
         (local.get $0)
         (i32.const 1)
        )
       )
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign2
          (array.get $type14
           (local.get $0)
           (i32.const 2)
          )
         )
         (if (result i32)
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign2
            (array.get $type14
             (local.get $0)
             (i32.const 3)
            )
           )
           (if (result i32)
            (i64.eq
             (i64.extend_i32_u
              (array.len
               (local.get $0)
              )
             )
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign2
              (array.get $type14
               (local.get $0)
               (i32.const 4)
              )
             )
             (if (result i32)
              (i64.eq
               (i64.extend_i32_u
                (array.len
                 (local.get $0)
                )
               )
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign2
                (array.get $type14
                 (local.get $0)
                 (i32.const 5)
                )
               )
               (if (result i32)
                (i64.eq
                 (i64.extend_i32_u
                  (array.len
                   (local.get $0)
                  )
                 )
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign2
                  (array.get $type14
                   (local.get $0)
                   (i32.const 6)
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (local.get $0)
                    )
                   )
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign2
                    (array.get $type14
                     (local.get $0)
                     (i32.const 7)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $0)
                      )
                     )
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign2
                      (array.get $type14
                       (local.get $0)
                       (i32.const 8)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $0)
                        )
                       )
                       (i64.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign2
                        (array.get $type14
                         (local.get $0)
                         (i32.const 9)
                        )
                       )
                       (call $function43
                        (local.get $0)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (ref.as_non_null
    (global.get $global109)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (local.set $0
     (call $function35
      (struct.new $type21
       (call $function33
        (struct.get $type25 0
         (global.get $global109)
        )
        (block (result i64)
         (if
          (i32.eqz
           (global.get $ready109)
          )
          (then
           (unreachable)
          )
         )
         (i64.div_s
          (i64.sub
           (i64.extend_i32_u
            (array.len
             (struct.get $type25 0
              (global.get $global109)
             )
            )
           )
           (i64.const 1)
          )
          (block (result i64)
           (if
            (i32.eqz
             (global.get $ready109)
            )
            (then
             (unreachable)
            )
           )
           (local.set $6
            (i64.sub
             (i64.extend_i32_u
              (array.len
               (struct.get $type25 0
                (global.get $global109)
               )
              )
             )
             (i64.const 1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready81)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global81)
            )
           )
           (i64.const 2)
          )
         )
        )
        (local.get $6)
       )
       (block (result (ref (exact $type21)))
        (if
         (i32.eqz
          (global.get $ready109)
         )
         (then
          (unreachable)
         )
        )
        (struct.new $type21
         (call $function33
          (struct.get $type25 0
           (global.get $global109)
          )
          (block (result i64)
           (if
            (i32.eqz
             (global.get $ready109)
            )
            (then
             (unreachable)
            )
           )
           (local.set $5
            (i64.sub
             (i64.extend_i32_u
              (array.len
               (struct.get $type25 0
                (global.get $global109)
               )
              )
             )
             (i64.const 1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready81)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global81)
            )
           )
           (i64.const 0)
          )
          (i64.add
           (i64.div_s
            (local.get $5)
            (i64.const 2)
           )
           (i64.const 1)
          )
         )
         (block (result nullref)
          (if
           (i32.eqz
            (global.get $ready90)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global90)
           )
          )
          (ref.null none)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global111)
     )
    )
    (local.get $0)
   )
  )
  (drop
   (if (result i32)
    (call $foreign1)
    (then
     (call $foreign0
      (i64.sub
       (local.tee $5
        (i64.extend_i32_u
         (array.len
          (local.get $0)
         )
        )
       )
       (i64.const 1)
      )
     )
     (if (result i32)
      (i64.eq
       (local.get $5)
       (i64.const 1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $foreign2
        (array.get $type14
         (local.get $0)
         (i32.const 1)
        )
       )
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (i64.const 2)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $foreign2
          (array.get $type14
           (local.get $0)
           (i32.const 2)
          )
         )
         (if (result i32)
          (i64.eq
           (i64.extend_i32_u
            (array.len
             (local.get $0)
            )
           )
           (i64.const 3)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $foreign2
            (array.get $type14
             (local.get $0)
             (i32.const 3)
            )
           )
           (if (result i32)
            (i64.eq
             (i64.extend_i32_u
              (array.len
               (local.get $0)
              )
             )
             (i64.const 4)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $foreign2
              (array.get $type14
               (local.get $0)
               (i32.const 4)
              )
             )
             (if (result i32)
              (i64.eq
               (i64.extend_i32_u
                (array.len
                 (local.get $0)
                )
               )
               (i64.const 5)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $foreign2
                (array.get $type14
                 (local.get $0)
                 (i32.const 5)
                )
               )
               (if (result i32)
                (i64.eq
                 (i64.extend_i32_u
                  (array.len
                   (local.get $0)
                  )
                 )
                 (i64.const 6)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $foreign2
                  (array.get $type14
                   (local.get $0)
                   (i32.const 6)
                  )
                 )
                 (if (result i32)
                  (i64.eq
                   (i64.extend_i32_u
                    (array.len
                     (local.get $0)
                    )
                   )
                   (i64.const 7)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $foreign2
                    (array.get $type14
                     (local.get $0)
                     (i32.const 7)
                    )
                   )
                   (if (result i32)
                    (i64.eq
                     (i64.extend_i32_u
                      (array.len
                       (local.get $0)
                      )
                     )
                     (i64.const 8)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $foreign2
                      (array.get $type14
                       (local.get $0)
                       (i32.const 8)
                      )
                     )
                     (if (result i32)
                      (i64.eq
                       (i64.extend_i32_u
                        (array.len
                         (local.get $0)
                        )
                       )
                       (i64.const 9)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $foreign2
                        (array.get $type14
                         (local.get $0)
                         (i32.const 9)
                        )
                       )
                       (call $function43
                        (local.get $0)
                        (i32.const 0)
                        (i32.const 1)
                        (i64.const 9)
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type25 0
   (global.get $global109)
  )
 )
 (func $function43 (type $1) (param $0 (ref $type14)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (local.get $0)
      )
     )
     (i64.const 1)
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign2
     (array.get $type14
      (local.get $0)
      (i32.add
       (i32.wrap_i64
        (local.get $3)
       )
       (i32.const 1)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function43
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function46 (type $0) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 (ref $type14))
  (local $5 (ref $type25))
  (if (result i64)
   (i64.ge_s
    (local.get $3)
    (i64.const 10)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (struct.get $type25 0
        (global.get $global109)
       )
      )
     )
     (i64.const 1)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type25 0
     (ref.as_non_null
      (global.get $global109)
     )
     (block (result (ref $type14))
      (if
       (i32.eqz
        (global.get $ready111)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global111)
       )
      )
      (local.tee $4
       (global.get $string3)
      )
     )
    )
    (if
     (call $foreign1)
     (then
      (call $foreign0
       (i64.const 6)
      )
      (call $foreign2
       (array.get $type14
        (local.get $4)
        (i32.const 1)
       )
      )
      (call $foreign2
       (array.get $type14
        (local.get $4)
        (i32.const 2)
       )
      )
      (call $foreign2
       (array.get $type14
        (local.get $4)
        (i32.const 3)
       )
      )
      (call $foreign2
       (array.get $type14
        (local.get $4)
        (i32.const 4)
       )
      )
      (call $foreign2
       (array.get $type14
        (local.get $4)
        (i32.const 5)
       )
      )
      (call $foreign2
       (array.get $type14
        (local.get $4)
        (i32.const 6)
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready122)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global122)
     )
    )
    (drop
     (call $function48
      (local.get $0)
      (i32.const 0)
      (i32.const 1)
      (i64.const 0)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function46
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function48 (type $0) (param $0 i64) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if (result i64)
   (i64.lt_s
    (local.get $0)
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (struct.get $type25 0
        (global.get $global109)
       )
      )
     )
     (i64.const 1)
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready109)
     )
     (then
      (unreachable)
     )
    )
    (i64.sub
     (i64.extend_i32_u
      (array.len
       (struct.get $type25 0
        (global.get $global109)
       )
      )
     )
     (i64.const 1)
    )
   )
   (else
    (if
     (i32.eqz
      (global.get $ready110)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global110)
     )
    )
    (drop
     (call $function41)
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function48
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global116)
   )
  )
  (if
   (i32.eqz
    (global.get $ready118)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global118)
   )
  )
  (return_call $function46
   (local.get $0)
   (i32.const 0)
   (i32.const 1)
   (i64.const 0)
  )
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready126)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global126)
   )
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (i64.sub
   (i64.extend_i32_u
    (array.len
     (call $function41)
    )
   )
   (i64.const 1)
  )
 )
 (func $export2 (param $0 i64)
  (local $1 (ref $type25))
  (local $2 (ref $type14))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready127)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global127)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (ref.as_non_null
    (global.get $global109)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.get $0)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.tee $2
      (array.new_default $type14
       (i32.add
        (i32.wrap_i64
         (local.get $0)
        )
        (i32.const 1)
       )
      )
     )
     (i32.const 0)
     (i32.const 1)
    )
    (local.get $2)
   )
  )
 )
 (func $export3 (param $0 i64) (param $1 i32)
  (local $2 (ref $type14))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready129)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global129)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (array.get $type14
     (local.tee $2
      (struct.get $type25 0
       (global.get $global109)
      )
     )
     (i32.const 0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type14
   (local.get $2)
   (i32.add
    (i32.wrap_i64
     (local.get $0)
    )
    (i32.const 1)
   )
   (local.get $1)
  )
 )
 (func $export4 (param $0 i64) (result i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $0)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (array.get $type14
   (struct.get $type25 0
    (global.get $global109)
   )
   (i32.add
    (i32.wrap_i64
     (local.get $0)
    )
    (i32.const 1)
   )
  )
 )
 (func $export5 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready134)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global134)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (i64.sub
   (i64.extend_i32_u
    (array.len
     (struct.get $type25 0
      (global.get $global109)
     )
    )
   )
   (i64.const 1)
  )
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type18)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global90
   (struct.new_default $type20)
  )
  (global.set $ready90
   (i32.const 1)
  )
  (global.set $global93
   (struct.new_default $type22)
  )
  (global.set $ready93
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type23)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global109
   (struct.new $type25
    (global.get $string3)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type26)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global122
   (struct.new_default $type27)
  )
  (global.set $ready122
   (i32.const 1)
  )
  (global.set $global118
   (struct.new_default $type27)
  )
  (global.set $ready118
   (i32.const 1)
  )
  (global.set $global111
   (struct.new_default $type28)
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global116
   (struct.new_default $type27)
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global126
   (struct.new_default $type5)
  )
  (global.set $ready126
   (i32.const 1)
  )
  (global.set $global127
   (struct.new_default $type29)
  )
  (global.set $ready127
   (i32.const 1)
  )
  (global.set $global129
   (struct.new_default $type30)
  )
  (global.set $ready129
   (i32.const 1)
  )
  (global.set $global132
   (struct.new_default $type31)
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $global134
   (struct.new_default $type5)
  )
  (global.set $ready134
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

