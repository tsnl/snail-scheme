(import (chezscheme))
;;; STRING -- One of the Kernighan and Van Wyk benchmarks.


(define s "abcdef")

(define (grow)
  (record-replacement! (string-append "123" s "456" s "789"))
  (record-replacement! (string-append
           (substring s (quotient (string-length s) 2) (string-length s))
           (substring s 0 (+ 1 (quotient (string-length s) 2)))))
  s)

(define (trial n)
  (do ((i 0 (+ i 1)))
      ((> (string-length s) n) (string-length s))
    (grow)))

(define (my-try n)
  (do ((i 0 (+ i 1)))
      ((>= i 10) (string-length s))
    (record-replacement! "abcdef")
    (trial n)))


(define stores '())
(define tracing? #f)
(define (record-replacement! value)
  (set! s value)
  (when tracing? (set! stores (cons (map char->integer (string->list value)) stores))))
(let* ((operation (read)) (threshold (read)) (seed (read)) (trace (read)))
  (set! s seed)
  (set! tracing? trace)
  (let ((result (if (= operation 0) (string-length (grow)) (my-try threshold))))
    (write (list result (map char->integer (string->list s)) (reverse stores)))
    (newline)))
