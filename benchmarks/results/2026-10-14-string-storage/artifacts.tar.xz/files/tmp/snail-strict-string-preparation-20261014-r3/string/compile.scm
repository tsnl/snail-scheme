(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-string-preparation-20261014-r3/string/program.scm" "/tmp/snail-strict-string-preparation-20261014-r3/string/program.so"))
