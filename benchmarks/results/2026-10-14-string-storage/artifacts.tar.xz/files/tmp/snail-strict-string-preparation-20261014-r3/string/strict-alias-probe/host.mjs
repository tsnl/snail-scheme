import fs from 'node:fs';
import assert from 'node:assert/strict';
const [artifact, specification] = process.argv.slice(2);
const config = JSON.parse(fs.readFileSync(specification, 'utf8'));
const stores = [];
const imports = {probe: {
  trace: () => Number(config.trace),
  length: value => stores.push({length: Number(value), characters: []}),
  character: value => stores.at(-1).characters.push(String.fromCodePoint(value)),
}};
const {instance: {exports}} = await WebAssembly.instantiate(fs.readFileSync(artifact), imports);
exports.main();
if (config.operation === 'grow') {
  const characters = [...config.seed];
  exports['probe-seed'](BigInt(characters.length));
  for (let i = 0; i < characters.length; i++)
    exports['probe-set-character'](BigInt(i), characters[i].codePointAt(0));
}
const result = config.operation === 'grow' ? exports['probe-grow']() : exports['probe-run'](BigInt(config.threshold));
const characters = [];
for (let i = 0; i < Number(exports['probe-length']()); i++)
  characters.push(String.fromCodePoint(exports['probe-character'](BigInt(i))));
console.log(JSON.stringify({result: Number(result), text: characters.join(''), stores: stores.map(value => {
  assert.equal(value.characters.length, value.length);
  return value.characters.join('');
})}));
