(import (snail strict))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(define (hide count x) (hide-i64 x))
;;; STRING -- One of the Kernighan and Van Wyk benchmarks.


(define s (ref "abcdef"))

(define (grow)
  (ref-set! s (string-append "123" (ref-get s) "456" (ref-get s) "789"))
  (ref-set! s (string-append
           (substring (ref-get s) (quotient (string-length (ref-get s)) 2) (string-length (ref-get s)))
           (substring (ref-get s) 0 (+ 1 (quotient (string-length (ref-get s)) 2)))))
  (ref-get s))

(define (trial n)
  (do ((i 0 (+ i 1)))
      ((> (string-length (ref-get s)) n) (string-length (ref-get s)))
    (grow)))

(define (my-try n)
  (do ((i 0 (+ i 1)))
      ((>= i 10) (string-length (ref-get s)))
    (ref-set! s "abcdef")
    (trial n)))

(define input0 (native-input-i64 (ann 0 I32)))
(define input1 (native-input-i64 (ann 1 I32)))
(define input2 (native-input-i64 (ann 2 I32)))
(: bench (-> I64 I64))
(define (bench count) (let loop ((i 0) (result 0))
  (if (< i count)
      (loop (+ i 1) (my-try (hide count input0)))
      (if (if (= i 0) (= input1 0)
              (and (= input1 2) (= result input2)))
          1 0))))
(unit)
