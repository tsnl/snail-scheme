(import (chezscheme))
(define (ref value) (vector value))
(define (ref-get cell) (vector-ref cell 0))
(define (ref-set! cell value) (vector-set! cell 0 value))
;;; STRING -- One of the Kernighan and Van Wyk benchmarks.


(define s (ref "abcdef"))

(define (grow)
  (record-replacement! (string-append "123" (ref-get s) "456" (ref-get s) "789"))
  (record-replacement! (string-append
           (substring (ref-get s) (quotient (string-length (ref-get s)) 2) (string-length (ref-get s)))
           (substring (ref-get s) 0 (+ 1 (quotient (string-length (ref-get s)) 2)))))
  (ref-get s))

(define (trial n)
  (do ((i 0 (+ i 1)))
      ((> (string-length (ref-get s)) n) (string-length (ref-get s)))
    (grow)))

(define (my-try n)
  (do ((i 0 (+ i 1)))
      ((>= i 10) (string-length (ref-get s)))
    (record-replacement! "abcdef")
    (trial n)))


(define stores '())
(define tracing? #f)
(define (record-replacement! value)
  (ref-set! s value)
  (when tracing? (set! stores (cons (map char->integer (string->list value)) stores))))
(let* ((operation (read)) (threshold (read)) (seed (read)) (trace (read)))
  (ref-set! s seed)
  (set! tracing? trace)
  (let ((result (if (= operation 0) (string-length (grow)) (my-try threshold))))
    (write (list result (map char->integer (string->list (ref-get s))) (reverse stores)))
    (newline)))
