(module
 (rec
  (type $call31 (func (param (ref null $type21) i64) (result (ref $type14))))
  (type $call34 (func (param i64) (result i64)))
  (type $call32 (func (param (ref null $type21)) (result (ref null $type21))))
  (type $call30 (func (param (ref null $type21) (ref null $type21) (ref $type14)) (result i32)))
  (type $call29 (func (param (ref null $type21)) (result i32)))
  (type $call28 (func (param (ref $type14) (ref null $type21)) (result i32)))
  (type $6 (func (param (ref $type14) (ref $type14) i32 i32 i64) (result i32)))
  (type $call23 (func (param (ref $type14) (ref null $type21) i64) (result i32)))
  (type $8 (func (param i32 i32 (ref null $type21) i64) (result i64)))
  (type $type21 (struct (field (ref $type14)) (field (ref null $type21))))
  (type $call20 (func (param (ref $type21)) (result (ref $type14))))
  (type $call18 (func (param (ref $type14) i64 i64) (result (ref $type14))))
  (type $type34 (struct))
  (type $type33 (struct))
  (type $type32 (struct))
  (type $type31 (struct))
  (type $type30 (struct))
  (type $type29 (struct))
  (type $type28 (struct))
  (type $type27 (struct))
  (type $type26 (struct))
  (type $type25 (struct (field (mut (ref $type14)))))
  (type $type24 (struct))
  (type $type23 (struct))
  (type $type22 (struct))
  (type $type20 (struct))
  (type $type19 (struct))
  (type $type18 (struct))
  (type $type13 (struct))
  (type $type14 (array (mut i32)))
 )
 (type $30 (func (param i64) (result i64)))
 (type $31 (func))
 (global $execution (mut i32) (i32.const 0))
 (global $string0 (ref $type14) (array.new_fixed $type14 4
  (i32.const 0)
  (i32.const 49)
  (i32.const 50)
  (i32.const 51)
 ))
 (global $string1 (ref $type14) (array.new_fixed $type14 4
  (i32.const 0)
  (i32.const 52)
  (i32.const 53)
  (i32.const 54)
 ))
 (global $string2 (ref $type14) (array.new_fixed $type14 4
  (i32.const 0)
  (i32.const 55)
  (i32.const 56)
  (i32.const 57)
 ))
 (global $string3 (ref $type14) (array.new_fixed $type14 5
  (i32.const 0)
  (i32.const 65)
  (i32.const 0)
  (i32.const 233)
  (i32.const 128512)
 ))
 (global $string4 (ref $type14) (array.new_fixed $type14 1
  (i32.const 0)
 ))
 (global $string5 (ref $type14) (array.new_fixed $type14 7
  (i32.const 0)
  (i32.const 97)
  (i32.const 98)
  (i32.const 99)
  (i32.const 100)
  (i32.const 101)
  (i32.const 102)
 ))
 (global $global61 (mut (ref null $type13)) (ref.null none))
 (global $ready61 (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type18)) (ref.null none))
 (global $ready81 (mut i32) (i32.const 0))
 (global $global88 (mut (ref null $type19)) (ref.null none))
 (global $ready88 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type20)) (ref.null none))
 (global $ready90 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type22)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global98 (mut (ref null $type23)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global103 (mut (ref null $type24)) (ref.null none))
 (global $ready103 (mut i32) (i32.const 0))
 (global $global109 (mut (ref null $type25)) (ref.null none))
 (global $ready109 (mut i32) (i32.const 0))
 (global $global110 (mut (ref null $type26)) (ref.null none))
 (global $ready110 (mut i32) (i32.const 0))
 (global $global111 (mut (ref null $type25)) (ref.null none))
 (global $ready111 (mut i32) (i32.const 0))
 (global $global115 (mut (ref null $type25)) (ref.null none))
 (global $ready115 (mut i32) (i32.const 0))
 (global $global116 (mut (ref null $type25)) (ref.null none))
 (global $ready116 (mut i32) (i32.const 0))
 (global $global112 (mut (ref null $type27)) (ref.null none))
 (global $ready112 (mut i32) (i32.const 0))
 (global $global117 (mut (ref null $type28)) (ref.null none))
 (global $ready117 (mut i32) (i32.const 0))
 (global $global121 (mut (ref null $type29)) (ref.null none))
 (global $ready121 (mut i32) (i32.const 0))
 (global $global124 (mut (ref null $type30)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global141 (mut (ref null $type31)) (ref.null none))
 (global $ready141 (mut i32) (i32.const 0))
 (global $global130 (mut (ref null $type32)) (ref.null none))
 (global $ready130 (mut i32) (i32.const 0))
 (global $global136 (mut (ref null $type33)) (ref.null none))
 (global $ready136 (mut i32) (i32.const 0))
 (global $global132 (mut (ref null $type34)) (ref.null none))
 (global $ready132 (mut i32) (i32.const 0))
 (export "probe-alias" (func $export0))
 (export "main" (func $main))
 (func $function33 (type $call18) (param $0 (ref $type14)) (param $1 i64) (param $2 i64) (result (ref $type14))
  (local $3 i32)
  (local $4 i64)
  (local $5 (ref $type14))
  (if (result (ref $type14))
   (if (result i32)
    (local.tee $3
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $3)
    )
    (else
     (if (result i32)
      (local.tee $3
       (i64.gt_s
        (local.get $1)
        (local.get $2)
       )
      )
      (then
       (local.get $3)
      )
      (else
       (i64.lt_s
        (i64.sub
         (i64.extend_i32_u
          (array.len
           (local.get $0)
          )
         )
         (i64.const 1)
        )
        (local.get $2)
       )
      )
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready61)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (i64.sub
        (local.get $2)
        (local.get $1)
       )
      )
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type14
     (local.tee $5
      (array.new_default $type14
       (i32.add
        (i32.wrap_i64
         (local.get $4)
        )
        (i32.const 1)
       )
      )
     )
     (i32.const 0)
     (i32.const 1)
    )
    (if
     (i32.ne
      (array.get $type14
       (local.get $5)
       (i32.const 0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_s
      (local.get $1)
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (i64.sub
       (local.get $2)
       (local.get $1)
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type14 $type14
     (local.get $5)
     (i32.const 1)
     (local.get $0)
     (i32.add
      (i32.wrap_i64
       (local.get $1)
      )
      (i32.const 1)
     )
     (i32.wrap_i64
      (i64.sub
       (local.get $2)
       (local.get $1)
      )
     )
    )
    (local.get $5)
   )
  )
 )
 (func $function35 (type $call20) (param $0 (ref $type21)) (result (ref $type14))
  (local $1 i64)
  (local $2 (ref null $type21))
  (local $3 (ref null $type21))
  (local $4 (ref $type14))
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $1
   (if (result i64)
    (i64.gt_s
     (local.tee $1
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (struct.get $type21 0
          (local.get $0)
         )
        )
       )
       (i64.const 1)
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $3
        (struct.get $type21 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $1)
      )
      (else
       (local.set $2
        (struct.get $type21 1
         (local.get $3)
        )
       )
       (if (result i64)
        (i64.gt_s
         (local.tee $1
          (i64.add
           (i64.sub
            (i64.extend_i32_u
             (array.len
              (struct.get $type21 0
               (local.get $3)
              )
             )
            )
            (i64.const 1)
           )
           (local.get $1)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (local.get $1)
          )
          (else
           (local.set $3
            (struct.get $type21 1
             (local.get $2)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $1
              (i64.add
               (i64.sub
                (i64.extend_i32_u
                 (array.len
                  (struct.get $type21 0
                   (local.get $2)
                  )
                 )
                )
                (i64.const 1)
               )
               (local.get $1)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $3)
              )
              (then
               (local.get $1)
              )
              (else
               (local.set $2
                (struct.get $type21 1
                 (local.get $3)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $1
                  (i64.add
                   (i64.sub
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type21 0
                       (local.get $3)
                      )
                     )
                    )
                    (i64.const 1)
                   )
                   (local.get $1)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $2)
                  )
                  (then
                   (local.get $1)
                  )
                  (else
                   (local.set $3
                    (struct.get $type21 1
                     (local.get $2)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.tee $1
                      (i64.add
                       (i64.sub
                        (i64.extend_i32_u
                         (array.len
                          (struct.get $type21 0
                           (local.get $2)
                          )
                         )
                        )
                        (i64.const 1)
                       )
                       (local.get $1)
                      )
                     )
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $3)
                      )
                      (then
                       (local.get $1)
                      )
                      (else
                       (local.set $2
                        (struct.get $type21 1
                         (local.get $3)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.tee $1
                          (i64.add
                           (i64.sub
                            (i64.extend_i32_u
                             (array.len
                              (struct.get $type21 0
                               (local.get $3)
                              )
                             )
                            )
                            (i64.const 1)
                           )
                           (local.get $1)
                          )
                         )
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $2)
                          )
                          (then
                           (local.get $1)
                          )
                          (else
                           (local.set $3
                            (struct.get $type21 1
                             (local.get $2)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.tee $1
                              (i64.add
                               (i64.sub
                                (i64.extend_i32_u
                                 (array.len
                                  (struct.get $type21 0
                                   (local.get $2)
                                  )
                                 )
                                )
                                (i64.const 1)
                               )
                               (local.get $1)
                              )
                             )
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $3)
                              )
                              (then
                               (local.get $1)
                              )
                              (else
                               (local.set $2
                                (struct.get $type21 1
                                 (local.get $3)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.tee $1
                                  (i64.add
                                   (i64.sub
                                    (i64.extend_i32_u
                                     (array.len
                                      (struct.get $type21 0
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (i64.const 1)
                                   )
                                   (local.get $1)
                                  )
                                 )
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $2)
                                  )
                                  (then
                                   (local.get $1)
                                  )
                                  (else
                                   (call $function37
                                    (i32.const 0)
                                    (i32.const 1)
                                    (struct.get $type21 1
                                     (local.get $2)
                                    )
                                    (i64.add
                                     (i64.sub
                                      (i64.extend_i32_u
                                       (array.len
                                        (struct.get $type21 0
                                         (local.get $2)
                                        )
                                       )
                                      )
                                      (i64.const 1)
                                     )
                                     (local.get $1)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready61)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type14
   (local.tee $4
    (array.new_default $type14
     (i32.add
      (i32.wrap_i64
       (local.get $1)
      )
      (i32.const 1)
     )
    )
   )
   (i32.const 0)
   (i32.const 1)
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (call $function38
    (local.get $4)
    (local.get $0)
    (i64.const 0)
   )
  )
  (local.get $4)
 )
 (func $function37 (type $8) (param $0 i32) (param $1 i32) (param $2 (ref null $type21)) (param $3 i64) (result i64)
  (local $4 (ref null $type21))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $4
       (struct.get $type21 1
        (local.get $2)
       )
      )
      (local.set $5
       (i64.sub
        (i64.extend_i32_u
         (array.len
          (struct.get $type21 0
           (local.get $2)
          )
         )
        )
        (i64.const 1)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (i64.add
        (local.get $3)
        (local.get $5)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call23) (param $0 (ref $type14)) (param $1 (ref null $type21)) (param $2 i64) (result i32)
  (local $3 i64)
  (local $4 (ref $type14))
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (local.set $3
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.tee $4
         (struct.get $type21 0
          (local.get $1)
         )
        )
       )
      )
      (i64.const 1)
     )
    )
    (if
     (i32.ne
      (array.get $type14
       (local.get $0)
       (i32.const 0)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_s
      (local.get $3)
      (i64.const 0)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.copy $type14 $type14
     (local.get $0)
     (i32.add
      (i32.wrap_i64
       (local.get $2)
      )
      (i32.const 1)
     )
     (local.get $4)
     (i32.const 1)
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (local.set $1
     (struct.get $type21 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function40 (type $6) (param $0 (ref $type14)) (param $1 (ref $type14)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.sub
      (i64.extend_i32_u
       (array.len
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type14
       (local.get $0)
       (local.tee $5
        (i32.add
         (i32.wrap_i64
          (local.get $4)
         )
         (i32.const 1)
        )
       )
      )
      (array.get $type14
       (local.get $1)
       (local.get $5)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function43 (type $call28) (param $0 (ref $type14)) (param $1 (ref null $type21)) (result i32)
  (local $2 i32)
  (if (result i32)
   (local.tee $2
    (ref.is_null
     (local.get $1)
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if (result i32)
     (ref.eq
      (local.get $0)
      (struct.get $type21 0
       (local.get $1)
      )
     )
     (then
      (i32.const 0)
     )
     (else
      (local.set $1
       (struct.get $type21 1
        (local.get $1)
       )
      )
      (if
       (i32.eqz
        (global.get $ready117)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global117)
       )
      )
      (return_call $function43
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function44 (type $call29) (param $0 (ref null $type21)) (result i32)
  (local $1 (ref null $type21))
  (local $2 (ref $type14))
  (local $3 i32)
  (local $scratch (ref null $type21))
  (if (result i32)
   (local.tee $3
    (ref.is_null
     (local.get $0)
    )
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type21 0
      (local.get $0)
     )
    )
    (local.set $1
     (struct.get $type21 1
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready117)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global117)
     )
    )
    (if (result i32)
     (if (result i32)
      (local.tee $3
       (ref.is_null
        (local.get $1)
       )
      )
      (then
       (local.get $3)
      )
      (else
       (if (result i32)
        (ref.eq
         (local.get $2)
         (struct.get $type21 0
          (local.get $1)
         )
        )
        (then
         (i32.const 0)
        )
        (else
         (local.set $1
          (struct.get $type21 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready117)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global117)
          )
         )
         (if (result i32)
          (local.tee $3
           (ref.is_null
            (local.get $1)
           )
          )
          (then
           (local.get $3)
          )
          (else
           (if (result i32)
            (ref.eq
             (local.get $2)
             (struct.get $type21 0
              (local.get $1)
             )
            )
            (then
             (i32.const 0)
            )
            (else
             (local.set $1
              (struct.get $type21 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready117)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global117)
              )
             )
             (if (result i32)
              (local.tee $3
               (ref.is_null
                (local.get $1)
               )
              )
              (then
               (local.get $3)
              )
              (else
               (if (result i32)
                (ref.eq
                 (local.get $2)
                 (struct.get $type21 0
                  (local.get $1)
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (local.set $1
                  (struct.get $type21 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready117)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global117)
                  )
                 )
                 (if (result i32)
                  (local.tee $3
                   (ref.is_null
                    (local.get $1)
                   )
                  )
                  (then
                   (local.get $3)
                  )
                  (else
                   (if (result i32)
                    (ref.eq
                     (local.get $2)
                     (struct.get $type21 0
                      (local.get $1)
                     )
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (local.set $1
                      (struct.get $type21 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready117)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global117)
                      )
                     )
                     (if (result i32)
                      (local.tee $3
                       (ref.is_null
                        (local.get $1)
                       )
                      )
                      (then
                       (local.get $3)
                      )
                      (else
                       (if (result i32)
                        (ref.eq
                         (local.get $2)
                         (struct.get $type21 0
                          (local.get $1)
                         )
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (local.set $1
                          (struct.get $type21 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready117)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global117)
                          )
                         )
                         (if (result i32)
                          (local.tee $3
                           (ref.is_null
                            (local.get $1)
                           )
                          )
                          (then
                           (local.get $3)
                          )
                          (else
                           (if (result i32)
                            (ref.eq
                             (local.get $2)
                             (struct.get $type21 0
                              (local.get $1)
                             )
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (local.set $1
                              (struct.get $type21 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready117)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global117)
                              )
                             )
                             (if (result i32)
                              (local.tee $3
                               (ref.is_null
                                (local.get $1)
                               )
                              )
                              (then
                               (local.get $3)
                              )
                              (else
                               (if (result i32)
                                (ref.eq
                                 (local.get $2)
                                 (struct.get $type21 0
                                  (local.get $1)
                                 )
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (local.set $1
                                  (struct.get $type21 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready117)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global117)
                                  )
                                 )
                                 (if (result i32)
                                  (local.tee $3
                                   (ref.is_null
                                    (local.get $1)
                                   )
                                  )
                                  (then
                                   (local.get $3)
                                  )
                                  (else
                                   (if (result i32)
                                    (ref.eq
                                     (local.get $2)
                                     (struct.get $type21 0
                                      (local.get $1)
                                     )
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (local.set $1
                                      (struct.get $type21 1
                                       (local.get $1)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready117)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global117)
                                      )
                                     )
                                     (if (result i32)
                                      (local.tee $3
                                       (ref.is_null
                                        (local.get $1)
                                       )
                                      )
                                      (then
                                       (local.get $3)
                                      )
                                      (else
                                       (if (result i32)
                                        (ref.eq
                                         (local.get $2)
                                         (struct.get $type21 0
                                          (local.get $1)
                                         )
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (local.set $1
                                          (struct.get $type21 1
                                           (local.get $1)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready117)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global117)
                                          )
                                         )
                                         (if (result i32)
                                          (local.tee $3
                                           (ref.is_null
                                            (local.get $1)
                                           )
                                          )
                                          (then
                                           (local.get $3)
                                          )
                                          (else
                                           (if (result i32)
                                            (ref.eq
                                             (local.get $2)
                                             (struct.get $type21 0
                                              (local.get $1)
                                             )
                                            )
                                            (then
                                             (i32.const 0)
                                            )
                                            (else
                                             (local.set $1
                                              (struct.get $type21 1
                                               (local.get $1)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready117)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global117)
                                              )
                                             )
                                             (call $function43
                                              (local.get $2)
                                              (local.get $1)
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (then
      (return_call $function44
       (block (result (ref null $type21))
        (local.set $scratch
         (struct.get $type21 1
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready121)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global121)
         )
        )
        (local.get $scratch)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function45 (type $call30) (param $0 (ref null $type21)) (param $1 (ref null $type21)) (param $2 (ref $type14)) (result i32)
  (local $3 i32)
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (if (result i32)
   (local.tee $3
    (ref.is_null
     (local.get $0)
    )
   )
   (then
    (local.get $3)
   )
   (else
    (if (result i32)
     (if (result i32)
      (local.tee $3
       (ref.eq
        (struct.get $type21 0
         (local.get $0)
        )
        (local.get $2)
       )
      )
      (then
       (local.get $3)
      )
      (else
       (local.set $4
        (struct.get $type21 0
         (local.get $0)
        )
       )
       (local.set $5
        (struct.get $type21 0
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready103)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global103)
        )
       )
       (if (result i32)
        (i64.eq
         (i64.extend_i32_u
          (array.len
           (local.get $4)
          )
         )
         (i64.extend_i32_u
          (array.len
           (local.get $5)
          )
         )
        )
        (then
         (call $function40
          (local.get $4)
          (local.get $5)
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
     )
     (then
      (return_call $function45
       (struct.get $type21 1
        (local.get $0)
       )
       (struct.get $type21 1
        (local.get $1)
       )
       (block (result (ref $type14))
        (if
         (i32.eqz
          (global.get $ready124)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global124)
         )
        )
        (local.get $2)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function46 (type $call32) (param $0 (ref null $type21)) (result (ref null $type21))
  (local $1 (ref $type14))
  (local $2 (ref $type14))
  (local $scratch (ref null $type21))
  (if (result (ref null $type21))
   (ref.is_null
    (local.get $0)
   )
   (then
    (ref.null none)
   )
   (else
    (local.set $1
     (struct.get $type21 0
      (local.get $0)
     )
    )
    (if
     (i32.eqz
      (global.get $ready88)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global88)
     )
    )
    (if
     (i32.eqz
      (global.get $ready81)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global81)
     )
    )
    (struct.new $type21
     (call $function33
      (local.get $1)
      (i64.const 0)
      (i64.sub
       (i64.extend_i32_u
        (array.len
         (local.get $1)
        )
       )
       (i64.const 1)
      )
     )
     (call $function46
      (block (result (ref null $type21))
       (local.set $scratch
        (struct.get $type21 1
         (local.get $0)
        )
       )
       (if
        (i32.eqz
         (global.get $ready130)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global130)
        )
       )
       (local.get $scratch)
      )
     )
    )
   )
  )
 )
 (func $function47 (type $call34) (param $0 i64) (result i64)
  (local $1 (ref null $type21))
  (local $2 (ref null $type21))
  (local $3 (ref $type14))
  (local $4 (ref $type14))
  (local $5 (ref $type14))
  (local $6 (ref $type14))
  (local $7 (ref $type14))
  (local $8 (ref $type14))
  (local $9 (ref $type25))
  (local $10 (ref $type25))
  (local $11 (ref $type21))
  (local $12 i64)
  (local $13 i64)
  (if
   (i32.eqz
    (global.get $ready88)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global88)
   )
  )
  (if
   (i32.eqz
    (global.get $ready81)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (local.set $6
   (call $function33
    (global.get $string3)
    (i64.const 0)
    (i64.const 4)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (global.get $global109)
   (local.get $6)
  )
  (if
   (i32.eqz
    (global.get $ready110)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global110)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (ref.as_non_null
    (global.get $global109)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (global.get $ready111)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type25 0
     (ref.as_non_null
      (global.get $global111)
     )
     (block (result (ref $type14))
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (local.set $3
       (struct.get $type25 0
        (global.get $global109)
       )
      )
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (local.set $5
       (struct.get $type25 0
        (global.get $global109)
       )
      )
      (if
       (i32.eqz
        (global.get $ready90)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global90)
       )
      )
      (local.set $4
       (call $function35
        (struct.new $type21
         (global.get $string0)
         (struct.new $type21
          (local.get $3)
          (struct.new $type21
           (global.get $string1)
           (struct.new $type21
            (local.get $5)
            (struct.new $type21
             (global.get $string2)
             (ref.null none)
            )
           )
          )
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready112)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global112)
       )
      )
      (local.get $4)
     )
    )
    (local.get $4)
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (struct.set $type25 0
   (ref.as_non_null
    (global.get $global109)
   )
   (block (result (ref $type14))
    (if
     (i32.eqz
      (global.get $ready115)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type25 0
     (ref.as_non_null
      (global.get $global115)
     )
     (block (result (ref $type14))
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (local.set $4
       (call $function33
        (struct.get $type25 0
         (global.get $global109)
        )
        (block (result i64)
         (if
          (i32.eqz
           (global.get $ready109)
          )
          (then
           (unreachable)
          )
         )
         (i64.div_s
          (i64.sub
           (i64.extend_i32_u
            (array.len
             (struct.get $type25 0
              (global.get $global109)
             )
            )
           )
           (i64.const 1)
          )
          (block (result i64)
           (if
            (i32.eqz
             (global.get $ready109)
            )
            (then
             (unreachable)
            )
           )
           (local.set $13
            (i64.sub
             (i64.extend_i32_u
              (array.len
               (struct.get $type25 0
                (global.get $global109)
               )
              )
             )
             (i64.const 1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready81)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global81)
            )
           )
           (i64.const 2)
          )
         )
        )
        (local.get $13)
       )
      )
      (if
       (i32.eqz
        (global.get $ready112)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global112)
       )
      )
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (global.get $ready116)
     )
     (then
      (unreachable)
     )
    )
    (struct.set $type25 0
     (ref.as_non_null
      (global.get $global116)
     )
     (block (result (ref $type14))
      (if
       (i32.eqz
        (global.get $ready109)
       )
       (then
        (unreachable)
       )
      )
      (local.set $7
       (call $function33
        (struct.get $type25 0
         (global.get $global109)
        )
        (block (result i64)
         (if
          (i32.eqz
           (global.get $ready109)
          )
          (then
           (unreachable)
          )
         )
         (local.set $12
          (i64.sub
           (i64.extend_i32_u
            (array.len
             (struct.get $type25 0
              (global.get $global109)
             )
            )
           )
           (i64.const 1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready81)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global81)
          )
         )
         (i64.const 0)
        )
        (i64.add
         (i64.div_s
          (local.get $12)
          (i64.const 2)
         )
         (i64.const 1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready112)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global112)
       )
      )
      (local.get $7)
     )
    )
    (if
     (i32.eqz
      (global.get $ready90)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global90)
     )
    )
    (call $function35
     (struct.new $type21
      (local.get $4)
      (struct.new $type21
       (local.get $7)
       (ref.null none)
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready109)
   )
   (then
    (unreachable)
   )
  )
  (local.set $3
   (struct.get $type25 0
    (global.get $global109)
   )
  )
  (if
   (i32.eqz
    (global.get $ready111)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (struct.get $type25 0
    (global.get $global111)
   )
  )
  (if
   (i32.eqz
    (global.get $ready115)
   )
   (then
    (unreachable)
   )
  )
  (local.set $8
   (struct.get $type25 0
    (global.get $global115)
   )
  )
  (if
   (i32.eqz
    (global.get $ready116)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready136)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global136)
   )
  )
  (if
   (i32.eqz
    (global.get $ready130)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global130)
   )
  )
  (local.set $2
   (call $function46
    (local.tee $11
     (struct.new $type21
      (local.get $6)
      (struct.new $type21
       (local.get $5)
       (struct.new $type21
        (local.get $8)
        (struct.new $type21
         (struct.get $type25 0
          (global.get $global116)
         )
         (struct.new $type21
          (local.get $3)
          (ref.null none)
         )
        )
       )
      )
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready141)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global141)
   )
  )
  (if
   (i32.ne
    (array.get $type14
     (local.tee $3
      (if (result (ref $type14))
       (i64.eqz
        (local.get $0)
       )
       (then
        (struct.get $type21 0
         (local.get $11)
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready141)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global141)
         )
        )
        (local.set $1
         (struct.get $type21 1
          (local.get $11)
         )
        )
        (if (result (ref $type14))
         (i64.eqz
          (local.tee $0
           (i64.sub
            (local.get $0)
            (i64.const 1)
           )
          )
         )
         (then
          (struct.get $type21 0
           (local.get $1)
          )
         )
         (else
          (local.set $1
           (struct.get $type21 1
            (local.get $1)
           )
          )
          (if
           (i32.eqz
            (global.get $ready141)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global141)
           )
          )
          (if (result (ref $type14))
           (i64.eqz
            (local.tee $0
             (i64.sub
              (local.get $0)
              (i64.const 1)
             )
            )
           )
           (then
            (struct.get $type21 0
             (local.get $1)
            )
           )
           (else
            (local.set $1
             (struct.get $type21 1
              (local.get $1)
             )
            )
            (if
             (i32.eqz
              (global.get $ready141)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global141)
             )
            )
            (if (result (ref $type14))
             (i64.eqz
              (local.tee $0
               (i64.sub
                (local.get $0)
                (i64.const 1)
               )
              )
             )
             (then
              (struct.get $type21 0
               (local.get $1)
              )
             )
             (else
              (local.set $1
               (struct.get $type21 1
                (local.get $1)
               )
              )
              (if
               (i32.eqz
                (global.get $ready141)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global141)
               )
              )
              (if (result (ref $type14))
               (i64.eqz
                (local.tee $0
                 (i64.sub
                  (local.get $0)
                  (i64.const 1)
                 )
                )
               )
               (then
                (struct.get $type21 0
                 (local.get $1)
                )
               )
               (else
                (local.set $1
                 (struct.get $type21 1
                  (local.get $1)
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready141)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global141)
                 )
                )
                (if (result (ref $type14))
                 (i64.eqz
                  (local.tee $0
                   (i64.sub
                    (local.get $0)
                    (i64.const 1)
                   )
                  )
                 )
                 (then
                  (struct.get $type21 0
                   (local.get $1)
                  )
                 )
                 (else
                  (local.set $1
                   (struct.get $type21 1
                    (local.get $1)
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready141)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global141)
                   )
                  )
                  (if (result (ref $type14))
                   (i64.eqz
                    (local.tee $0
                     (i64.sub
                      (local.get $0)
                      (i64.const 1)
                     )
                    )
                   )
                   (then
                    (struct.get $type21 0
                     (local.get $1)
                    )
                   )
                   (else
                    (local.set $1
                     (struct.get $type21 1
                      (local.get $1)
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready141)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global141)
                     )
                    )
                    (if (result (ref $type14))
                     (i64.eqz
                      (local.tee $0
                       (i64.sub
                        (local.get $0)
                        (i64.const 1)
                       )
                      )
                     )
                     (then
                      (struct.get $type21 0
                       (local.get $1)
                      )
                     )
                     (else
                      (local.set $1
                       (struct.get $type21 1
                        (local.get $1)
                       )
                      )
                      (if
                       (i32.eqz
                        (global.get $ready141)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global141)
                       )
                      )
                      (if (result (ref $type14))
                       (i64.eqz
                        (local.tee $0
                         (i64.sub
                          (local.get $0)
                          (i64.const 1)
                         )
                        )
                       )
                       (then
                        (struct.get $type21 0
                         (local.get $1)
                        )
                       )
                       (else
                        (call $function49
                         (struct.get $type21 1
                          (local.get $1)
                         )
                         (block (result i64)
                          (if
                           (i32.eqz
                            (global.get $ready141)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global141)
                           )
                          )
                          (i64.sub
                           (local.get $0)
                           (i64.const 1)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (i32.const 0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type14
   (local.get $3)
   (i32.const 1)
   (i32.const 81)
  )
  (if
   (i32.eqz
    (global.get $ready121)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global121)
   )
  )
  (i64.extend_i32_u
   (i32.ne
    (if (result i32)
     (call $function44
      (local.get $11)
     )
     (then
      (if (result i32)
       (i32.eq
        (array.get $type14
         (local.get $3)
         (i32.const 1)
        )
        (i32.const 81)
       )
       (then
        (if
         (i32.eqz
          (global.get $ready124)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global124)
         )
        )
        (call $function45
         (local.get $11)
         (local.get $2)
         (local.get $3)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function49 (type $call31) (param $0 (ref null $type21)) (param $1 i64) (result (ref $type14))
  (if (result (ref $type14))
   (i64.eqz
    (local.get $1)
   )
   (then
    (struct.get $type21 0
     (local.get $0)
    )
   )
   (else
    (return_call $function49
     (struct.get $type21 1
      (local.get $0)
     )
     (block (result i64)
      (if
       (i32.eqz
        (global.get $ready141)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global141)
       )
      )
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready132)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global132)
   )
  )
  (return_call $function47
   (local.get $0)
  )
 )
 (func $main
  (local $0 (ref $type14))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type13)
  )
  (global.set $ready61
   (i32.const 1)
  )
  (global.set $global81
   (struct.new_default $type18)
  )
  (global.set $ready81
   (i32.const 1)
  )
  (global.set $global88
   (struct.new_default $type19)
  )
  (global.set $ready88
   (i32.const 1)
  )
  (global.set $global90
   (struct.new_default $type20)
  )
  (global.set $ready90
   (i32.const 1)
  )
  (global.set $global93
   (struct.new_default $type22)
  )
  (global.set $ready93
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type23)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type24)
  )
  (global.set $ready103
   (i32.const 1)
  )
  (global.set $global109
   (struct.new $type25
    (global.get $string5)
   )
  )
  (global.set $ready109
   (i32.const 1)
  )
  (global.set $global110
   (struct.new_default $type26)
  )
  (global.set $ready110
   (i32.const 1)
  )
  (global.set $global111
   (struct.new $type25
    (local.tee $0
     (global.get $string4)
    )
   )
  )
  (global.set $ready111
   (i32.const 1)
  )
  (global.set $global115
   (struct.new $type25
    (local.get $0)
   )
  )
  (global.set $ready115
   (i32.const 1)
  )
  (global.set $global116
   (struct.new $type25
    (local.get $0)
   )
  )
  (global.set $ready116
   (i32.const 1)
  )
  (global.set $global112
   (struct.new_default $type27)
  )
  (global.set $ready112
   (i32.const 1)
  )
  (global.set $global117
   (struct.new_default $type28)
  )
  (global.set $ready117
   (i32.const 1)
  )
  (global.set $global121
   (struct.new_default $type29)
  )
  (global.set $ready121
   (i32.const 1)
  )
  (global.set $global124
   (struct.new_default $type30)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global141
   (struct.new_default $type31)
  )
  (global.set $ready141
   (i32.const 1)
  )
  (global.set $global130
   (struct.new_default $type32)
  )
  (global.set $ready130
   (i32.const 1)
  )
  (global.set $global136
   (struct.new_default $type33)
  )
  (global.set $ready136
   (i32.const 1)
  )
  (global.set $global132
   (struct.new_default $type34)
  )
  (global.set $ready132
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

