;;; STRING -- One of the Kernighan and Van Wyk benchmarks.


(define s (ref "abcdef"))

(define (grow)
  (ref-set! s (string-append "123" (ref-get s) "456" (ref-get s) "789"))
  (ref-set! s (string-append
           (substring (ref-get s) (quotient (string-length (ref-get s)) 2) (string-length (ref-get s)))
           (substring (ref-get s) 0 (+ 1 (quotient (string-length (ref-get s)) 2)))))
  (ref-get s))

(define (trial n)
  (do ((i 0 (+ i 1)))
      ((> (string-length (ref-get s)) n) (string-length (ref-get s)))
    (grow)))

(define (my-try n)
  (do ((i 0 (+ i 1)))
      ((>= i 10) (string-length (ref-get s)))
    (ref-set! s "abcdef")
    (trial n)))

