(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-puzzle-preparation-20261014-r3/puzzle/same-source-chez/program.scm" "/tmp/snail-strict-puzzle-preparation-20261014-r3/puzzle/same-source-chez/program.so"))
