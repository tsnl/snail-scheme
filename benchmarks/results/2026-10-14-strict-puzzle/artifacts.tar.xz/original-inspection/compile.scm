(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-puzzle-original-inspection-20261014/program.scm" "/tmp/snail-puzzle-original-inspection-20261014/program.so"))
