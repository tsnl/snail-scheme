"""Count retained canonical array operations; this is never a timing artifact."""

from collections import Counter
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

SOURCE, OUTPUT = map(Path, sys.argv[1:])
OBSERVER = Path('/tmp/snail-strict-enumeration-profile-20261013/diagnostic-archive/diagnostics')
OUTPUT.mkdir(parents=True, exist_ok=False)
for name in ('observe-wat.py', 'profile-host.mjs'):
    shutil.copy2(OBSERVER / name, OUTPUT / name)
shutil.copy2(__file__, OUTPUT / 'inspect-puzzle.py')
shutil.copy2(SOURCE / 'strict.optimized.wat', OUTPUT / 'original.wat')
spec = importlib.util.spec_from_file_location('observe', OUTPUT / 'observe-wat.py')
observe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(observe)
F = observe.Form


class PuzzleObservers(observe.Observers):
    def rewrite(self, node):
        if not isinstance(node, F):
            return node
        original = F(node, line=node.line)
        rewritten = F([self.rewrite(child) for child in node], line=node.line)
        if node[0].startswith(('array.new', 'struct.new')) or node[0] == 'array.get':
            category = 'array read completed' if node[0] == 'array.get' else 'constructor completed'
            number = self.record(original, category, original[1])
            return self.passthrough(rewritten, self.types.expression_type(original, self.locals), number)
        if node[0] in ('array.set', 'struct.set'):
            category = 'array store completed' if node[0] == 'array.set' else 'Ref store completed'
            number = self.record(original, category, original[1])
            return F(['block', rewritten, observe.bump(number)], line=node.line)
        return rewritten


base_erase = observe.erase_observers


def erase(node):
    if (isinstance(node, F) and len(node) == 3 and node[0] == 'block'
            and isinstance(node[1], F) and node[1][0] in ('array.set', 'struct.set')
            and isinstance(node[2], F) and node[2][0] == 'global.set'
            and node[2][1].startswith('$__profile_')):
        return erase(node[1])
    return base_erase(node)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def invoke(command, path):
    environment = os.environ.copy()
    environment.pop('NODE_OPTIONS', None)
    run = subprocess.run(list(map(str, command)), capture_output=True, text=True, env=environment, timeout=300)
    record = dict(command=list(map(str, command)), returncode=run.returncode, stdout=run.stdout,
                  stderr=run.stderr, diagnostic_only=True, performance_sample=False)
    save(path, record)
    assert run.returncode == 0, record


observe.Observers = PuzzleObservers
observe.erase_observers = erase
observe.observe(OUTPUT / 'original.wat', OUTPUT / 'counted.wat')
invoke([os.environ['WASM_AS'], OUTPUT / 'counted.wat', '--enable-gc', '--enable-reference-types',
        '--enable-tail-call', '-o', OUTPUT / 'counted.wasm'], OUTPUT / 'assemble.json')
sites = json.loads((OUTPUT / 'counted.json').read_text())['counters']
specification = json.loads((SOURCE / 'spec.json').read_text())
full = json.loads((SOURCE / 'complete-state-oracles.json').read_text())[0]['expected'][0]
events = Counter(event[0] for event in full[4])
summaries = []
for count in (1, 2, 1000):
    target = OUTPUT / str(count)
    target.mkdir()
    save(target / 'spec.json', dict(specification, count=count))
    invoke([os.environ['NODE'], OUTPUT / 'profile-host.mjs', OUTPUT / 'counted.wasm', target / 'spec.json',
            '--validate', target, 'counters'], target / 'run.json')
    setup = json.loads((target / 'setup.counters.json').read_text())
    bench = json.loads((target / 'bench.counters.json').read_text())
    totals, by_site = Counter(), []
    for site in sites:
        key = 'counter' + str(site['id'])
        completed = int(bench[key]) - int(setup[key])
        totals[site['category'] + ':' + str(site['target'])] += completed
        by_site.append(dict(site, completed=completed))
    assert totals['array store completed:$type36'] == count * (events[1] + events[2]), totals
    assert totals['array store completed:$type35'] == count * (events[3] + events[4] + events[5]), totals
    summaries.append(dict(count=count, totals=totals, sites=by_site, setup_subtracted=True,
                          source_event_counts=events, physical_allocator_events=False))
save(OUTPUT / 'counts-summary.json', summaries)
print('Puzzle retained-operation counts agree with the independent source oracle; no timings.', flush=True)
