"""Preserve the puzzle search, local early return, and both setup regions."""

import re

from data_ports import form, replace
from string_port import exact_json_integer, expected_value, i64


# ---- Scalar inputs and the original false-or-count result ----

STRICT_TYPES = '''(define-data PuzzleResult (puzzle-failed) (puzzle-count (value I64)))
(define puzzle-failure (puzzle-failed))
(define (zero? value) (= value 0))
(define-extern puzzle-print "benchmark" "print_text" (-> I64 Unit))
(define (puzzle-error) (puzzle-print 0) (puzzle-print 1))
'''
COMMON = '''(define (puzzle-for-each procedure values)
  (unless (null? values)
    (procedure (car values)) (puzzle-for-each procedure (cdr values))))
'''
CHEZ_RESULTS = '''(define (puzzle-failed) (vector 0))
(define (puzzle-count value) (vector 1 value))
(define puzzle-failure (puzzle-failed))
(define (puzzle-original-value result)
  (if (= (vector-ref result 0) 0) #f (vector-ref result 1)))
(define (puzzle-error) (newline) (display "Error."))
'''
WORKER = '''(let loop ((i 0) (result puzzle-failure))
  (if (< i count)
      (loop (+ i 1) (start (hide count input0)))
      (if (match result
            ((puzzle-failed) (= input1 0))
            ((puzzle-count value) (and (= input1 2) (= value input2))))
          1 0)))'''


def specification(data):
    tokens = re.sub(r';[^\n]*', '', data.decode()).split()
    if len(tokens) != 3:
        raise ValueError('puzzle requires count, size and expected result')
    count, size = map(i64, tokens[:2])
    expected, kind, value = expected_value(tokens[2])
    return dict(name='puzzle', count=exact_json_integer(count),
                inputs=list(map(exact_json_integer, (size, kind, value))),
                original_expected=expected, expected=1, barriers_per_iteration=1,
                setup_barriers=0, diagnostic_text=['\n', 'Error.'])


# ---- Counted source edits keep the inclusive mask scans and all stores ----

TRIAL = '''(define (trial j)
  (let candidates ((i 0))
    (if (> i typemax)
        (begin (set! *kount* (+ *kount* 1)) #f)
        (if (and (not (zero? (vector-ref *piececount* (vector-ref *class* i))))
                 (fit i j))
            (let ((k (place i j)))
              (if (or (trial k) (zero? k))
                  (begin (set! *kount* (+ *kount* 1)) #t)
                  (begin (puzzle-remove i j) (candidates (+ i 1)))))
            (candidates (+ i 1))))))'''


def parts(source):
    source = re.sub(r'^\(import [^\n]*\)\s*$', '', source, flags=re.M)
    harness = form(source, '(define (run-benchmark)')
    before, after = source.split(harness)
    return before, harness, after


def explicit_ref(source, name, initial, stores, global_binding=False):
    # The local index and n are adapted only inside their own function forms.
    source = re.sub(r'"(?:[^"\\]|\\.)*"|;[^\n]*|[^\s()]+',
                    lambda token: '(ref-get ' + name + ')' if token[0] == name else token[0], source)
    prefix = '(define ' if global_binding else '('
    source = replace(source, prefix + '(ref-get ' + name + ') ' + initial + ')',
                     prefix + name + ' (ref ' + initial + '))')
    return replace(source, '(set! (ref-get ' + name + ')', '(ref-set! ' + name, stores)


def placement_guards(source):
    for value in ('#t', '#f'):
        old = '''(cond ((vector-ref (vector-ref *p* i) k)
             (vector-set! *puzzle* (+ j k) VALUE)
             VALUE))'''.replace('VALUE', value)
        new = '''(when (vector-ref (vector-ref *p* i) k)
        (vector-set! *puzzle* (+ j k) VALUE))'''.replace('VALUE', value)
        source = replace(source, old, new)
    return source


def kernel_body(source):
    source = placement_guards(replace(source, form(source, '(define (trial j)'), TRIAL))
    piece = form(source, '(define (definePiece ')
    adapted = explicit_ref(piece, 'index', '0', 1)
    adapted = replace(adapted, '(cond ((not (= *iii* typemax))\n           (set! *iii* (+ *iii* 1))))',
                      '(when (not (= *iii* typemax))\n      (set! *iii* (+ *iii* 1)))')
    source = replace(source, piece, adapted)
    start = form(source, '(define (start size)')
    adapted = explicit_ref(start, 'n', '0', 1)
    adapted = replace(adapted, '(begin (newline) (display "Error."))', '(puzzle-error)')
    adapted = replace(adapted, '        *kount*\n        #f)',
                      '        (puzzle-count *kount*)\n        puzzle-failure)')
    return replace(source, start, adapted)


def adapt_region(source):
    source = replace(source, '(make-vector (+ *size* 1))', '(make-vector (+ *size* 1) #t)')
    if '(define (trial j)' not in source:
        return replace(source, '(for-each ', '(puzzle-for-each ')
    source = replace(source, '(make-vector (+ typemax 1))', '(make-vector (+ typemax 1) (make-vector 0 #t))')
    source = kernel_body(source)
    source = explicit_ref(source, '*iii*', '0', 2, True)
    return explicit_ref(source, '*kount*', '0', 3, True)


def kernel(source):
    before, _, after = parts(source)
    return adapt_region(before) + adapt_region(after)


def control_prelude(source):
    return replace(source, '(define-syntax do\n  (syntax-rules ()\n',
                   '(define-syntax do\n  (syntax-rules ()\n'
                   '    ((_ bindings (test) body ...) (do bindings (test (unit)) body ...))\n')


def adapt_harness(source, reverse=False):
    edits = (('(result #f)', '(result puzzle-failure)'),
             ('(ok? result)', '(ok? (puzzle-original-value result))'),
             ('(write result)', '(write (puzzle-original-value result))'))
    for before, after in edits:
        source = replace(source, after if reverse else before, before if reverse else after)
    return source


def matched_source(upstream, original, strict, helpers):
    before, harness, after = parts(upstream)
    first, last = adapt_region(before), adapt_region(after)
    if strict.count(first + last) != 1:
        raise ValueError('strict puzzle must contain both adapted setup regions')
    adapted = replace(original, before + harness + after, helpers + first + harness + last)
    adapted = adapt_harness(adapted)
    restored = replace(adapt_harness(adapted, True), helpers + first + harness + last,
                       before + harness + after)
    if restored != original:
        raise ValueError('puzzle full-source reversal failed')
    return adapted, before + after, first + last
