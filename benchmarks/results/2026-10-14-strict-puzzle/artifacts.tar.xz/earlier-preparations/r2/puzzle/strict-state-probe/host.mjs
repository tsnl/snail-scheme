import fs from 'node:fs';
import assert from 'node:assert/strict';
const [artifact, specification] = process.argv.slice(2);
const config = JSON.parse(fs.readFileSync(specification, 'utf8'));
let events = [], output = [], tracing = false;
const imports = {benchmark: {
  input_i64: () => 0n, input_f64: () => 0, barrier: () => 1,
  hide_i64: x => x, hide_f64: x => x,
  print_text: code => output.push(...[...['\n', 'Error.'][Number(code)]].map(c => c.codePointAt(0))),
}, probe: {
  record: (...values) => { if (tracing) events.push(values.map(Number)); },
  fail_initial: () => Number(config.fail_initial),
}};
const {instance} = await WebAssembly.instantiate(fs.readFileSync(artifact), imports);
instance.exports.main();
const actual = config.commands.map((command, index) => {
  events = []; output = []; tracing = index >= config.trace_from;
  let trapped = 0, result = 0;
  try { result = Number(instance.exports['probe-command'](...command.map(BigInt))); }
  catch (error) { if (!(error instanceof WebAssembly.RuntimeError)) throw error; trapped = 1; }
  const state = Array.from({length: 7202}, (_, i) => Number(instance.exports['probe-state'](BigInt(i))));
  return [trapped, result, output, state, events];
});
fs.writeFileSync(specification + '.actual.json', JSON.stringify(actual) + '\n');
assert.deepEqual(actual, config.expected);
console.log(JSON.stringify({valid: true, steps: actual.length, diagnostic_only: true}));
