(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-puzzle-preparation-20261014-r2/puzzle/program.scm" "/tmp/snail-strict-puzzle-preparation-20261014-r2/puzzle/program.so"))
