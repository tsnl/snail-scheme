(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-strict-puzzle-preparation-20261014-r2/puzzle/same-source-chez/returned-size/program.scm" "/tmp/snail-strict-puzzle-preparation-20261014-r2/puzzle/same-source-chez/returned-size/program.so"))
