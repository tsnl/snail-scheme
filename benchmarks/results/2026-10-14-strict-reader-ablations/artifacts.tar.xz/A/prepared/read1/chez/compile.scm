(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-reader-delimiter-ablation-20261014/build/reader-ablation-prepared/read1/chez/program.scm" "/tmp/snail-reader-delimiter-ablation-20261014/build/reader-ablation-prepared/read1/chez/program.so"))
