(module
 (rec
  (type $type13 (sub (struct (field i32))))
  (type $type173 (sub (struct)))
  (type $type179 (sub (struct (field i32))))
  (type $type161 (sub (struct (field i32))))
  (type $type68 (sub (struct)))
  (type $type140 (sub (struct (field i32))))
  (type $type121 (sub (struct (field i32))))
  (type $type24 (sub (struct (field i32))))
  (type $type28 (sub (struct)))
  (type $9 (func (param (ref $type36) i32 i32 i64) (result i32)))
  (type $10 (func (param (ref $type34) i32 i32 i64) (result i32)))
  (type $call204 (func (param (ref $type13)) (result i32)))
  (type $12 (func (param (ref $type18) i32 i32 i64) (result i32)))
  (type $13 (func (param (ref $type58) i32 i32 (ref $type140) (ref $type13) i64) (result (ref $type13))))
  (type $call145 (func (param (ref $type58)) (result (ref $type140))))
  (type $type35 (sub $type13 (struct (field i32) (field (ref $type36)))))
  (type $call197 (func (param (ref null $type12) (ref $type36) i64) (result (ref $type140))))
  (type $17 (func (param (ref $type34) i32 i32 (ref null $type12) i64) (result (ref $type34))))
  (type $18 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $19 (func (param i32 i32 (ref null $type12) (ref $type12)) (result (ref null $type12))))
  (type $20 (func (param (ref null $type12) (ref $type31)) (result (ref $type13))))
  (type $type36 (struct (field (ref $type37))))
  (type $type37 (array (mut i8)))
  (type $type33 (sub $type13 (struct (field i32) (field (ref $type34)))))
  (type $type34 (array (mut (ref $type13))))
  (type $type12 (struct (field (ref $type13)) (field (ref null $type12))))
  (type $26 (func (param (ref $type58) i64 (ref null $type12)) (result (ref $type140))))
  (type $type31 (sub $type13 (struct (field i32) (field (ref $type32)) (field (ref $type32)))))
  (type $type32 (struct (field (ref $type13))))
  (type $call188 (func (param (ref $type58) (ref $type161)) (result (ref $type140))))
  (type $30 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type179))))
  (type $31 (func (param (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $32 (func (param (ref $type58) (ref $type152) i32 i32) (result (ref $type18))))
  (type $call150 (func (param i64) (result i32)))
  (type $call159 (func (param (ref $type58) i64) (result i32)))
  (type $35 (func (param (ref $type152) i32)))
  (type $call184 (func (param (ref $type58) i64) (result (ref $type179))))
  (type $call186 (func (param (ref $type58) i64 i64) (result (ref $type179))))
  (type $call176 (func (param (ref $type58) i32 (ref $type152)) (result (ref $type173))))
  (type $type175 (sub $type173 (struct (field (ref $type18)))))
  (type $type17 (sub $type13 (struct (field i32) (field (ref $type18)))))
  (type $type174 (sub $type173 (struct (field (ref $type18)))))
  (type $call171 (func (param (ref $type58) i32 i32) (result (ref $type161))))
  (type $call60 (func (param (ref $type58)) (result i32)))
  (type $call147 (func (param (ref $type58)) (result i64)))
  (type $type21 (sub $type13 (struct (field i32) (field (ref $type22)))))
  (type $type22 (struct (field i32)))
  (type $type23 (sub $type13 (struct (field i32) (field (ref $type24)))))
  (type $type15 (sub $type13 (struct (field i32) (field i32))))
  (type $type182 (sub $type179 (struct (field i32) (field (ref $type18)))))
  (type $type180 (sub $type179 (struct (field i32) (field i32))))
  (type $type154 (struct (field (mut i64))))
  (type $type153 (struct (field (mut (ref $type18)))))
  (type $type162 (sub $type161 (struct (field i32) (field (ref $type13)))))
  (type $type16 (sub $type13 (struct (field i32) (field i32))))
  (type $type168 (sub $type161 (struct (field i32) (field (ref $type18)))))
  (type $type167 (sub $type161 (struct (field i32) (field (ref $type18)))))
  (type $type166 (sub $type161 (struct (field i32) (field i64))))
  (type $type70 (sub $type68 (struct (field i32))))
  (type $type56 (struct (field (mut i32))))
  (type $type58 (struct (field (ref $type56))))
  (type $type152 (struct (field (ref $type153)) (field (ref $type154))))
  (type $call160 (func (param (ref $type58)) (result (ref $type161))))
  (type $type143 (sub $type140 (struct (field i32) (field (ref $type18)))))
  (type $type142 (sub $type140 (struct (field i32) (field (ref $type13)))))
  (type $call144 (func (param (ref $type140)) (result (ref $type13))))
  (type $type124 (sub $type121 (struct (field i32) (field (ref $type18)))))
  (type $type27 (sub $type24 (struct (field i32) (field (ref $type28)) (field (ref $type28)))))
  (type $type30 (sub $type28 (struct (field f64))))
  (type $type29 (sub $type28 (struct (field i64))))
  (type $type26 (sub $type24 (struct (field i32) (field f64))))
  (type $type123 (sub $type121 (struct (field i32) (field (ref $type24)))))
  (type $type25 (sub $type24 (struct (field i32) (field i64))))
  (type $call120 (func (param i32 i32) (result (ref $type121))))
  (type $74 (func (param i32 i64 (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $75 (func (param (ref $type18) i32 i64 i32 i32 i64) (result i32)))
  (type $call111 (func (param (ref $type18)) (result i32)))
  (type $77 (func (param (ref $type18) i64 i32 i32 i64) (result i32)))
  (type $call52 (func (param (ref $type18)) (result i32)))
  (type $79 (func (param (ref $type18) (ref $type18) i32 i32 i64) (result i32)))
  (type $call50 (func (param (ref $type18) (ref null $type48) i64) (result i32)))
  (type $81 (func (param i32 i32 (ref null $type48) i64) (result i64)))
  (type $type48 (struct (field (ref $type18)) (field (ref null $type48))))
  (type $83 (func (param (ref $type48)) (result (ref $type18))))
  (type $84 (func (param (ref $type18) i64 (ref $type18) i64)))
  (type $85 (func (param (ref $type18) i32) (result (ref $type19))))
  (type $type20 (array (mut (ref null $type19))))
  (type $87 (func (param i32) (result (ref $type18))))
  (type $type206 (struct))
  (type $type205 (struct))
  (type $type203 (struct))
  (type $type201 (struct))
  (type $type5 (struct))
  (type $type65 (struct))
  (type $type200 (struct))
  (type $type196 (struct))
  (type $type195 (struct))
  (type $type194 (struct))
  (type $type192 (struct))
  (type $type191 (struct))
  (type $type189 (struct))
  (type $type187 (struct))
  (type $type183 (struct))
  (type $type178 (struct))
  (type $type177 (struct))
  (type $type172 (struct))
  (type $type170 (struct))
  (type $type169 (struct))
  (type $type156 (struct))
  (type $type133 (struct))
  (type $type132 (struct))
  (type $type119 (struct))
  (type $type115 (struct))
  (type $type53 (struct))
  (type $type84 (struct))
  (type $type64 (struct))
  (type $type62 (struct))
  (type $type49 (struct))
  (type $type40 (struct))
  (type $type11 (struct))
  (type $type202 (struct))
  (type $type197 (struct))
  (type $type186 (struct))
  (type $type185 (struct))
  (type $type97 (struct))
  (type $type184 (struct))
  (type $type176 (struct))
  (type $type171 (struct))
  (type $type157 (struct))
  (type $type150 (struct))
  (type $type139 (struct))
  (type $type125 (struct))
  (type $type120 (struct))
  (type $type118 (struct))
  (type $type61 (struct))
  (type $type60 (struct))
  (type $type57 (struct))
  (type $type52 (struct))
  (type $type46 (struct))
  (type $type66 (struct (field i64) (field (ref $type18)) (field (ref $type13))))
  (type $type190 (struct))
  (type $type158 (struct))
  (type $type113 (struct))
  (type $type47 (struct))
  (type $type159 (struct))
  (type $type151 (struct))
  (type $type45 (struct))
  (type $type188 (struct))
  (type $type144 (struct))
  (type $type112 (struct))
  (type $type145 (struct))
  (type $type155 (struct))
  (type $type149 (struct))
  (type $type50 (struct))
  (type $type204 (struct))
  (type $type160 (struct))
  (type $type147 (struct))
  (type $type129 (struct))
  (type $type193 (struct))
  (type $type111 (struct))
  (type $type41 (struct))
  (type $type51 (struct))
  (type $type72 (struct))
  (type $type146 (struct))
  (type $type71 (struct))
  (type $type148 (struct))
  (type $type181 (sub $type179 (struct (field i32))))
  (type $type165 (sub $type161 (struct (field i32))))
  (type $type164 (sub $type161 (struct (field i32))))
  (type $type163 (sub $type161 (struct (field i32))))
  (type $type141 (sub $type140 (struct (field i32))))
  (type $type122 (sub $type121 (struct (field i32))))
  (type $type14 (sub $type13 (struct (field i32))))
  (type $type18 (struct (field i32) (field i32) (field (ref $type19)) (field (ref null $type20))))
  (type $type19 (array (mut i32)))
  (type $type69 (sub $type68 (struct)))
 )
 (type $176 (func (param i32) (result i32)))
 (type $177 (func (param i32)))
 (type $178 (func (result i32)))
 (type $179 (func (param i32 i32) (result i32)))
 (type $180 (func))
 (type $181 (func (result i64)))
 (type $182 (func (param i32 i32)))
 (type $183 (func (param i32) (result i64)))
 (type $184 (func (param i32 i32) (result f64)))
 (type $185 (func (param i32 i32) (result i64)))
 (type $186 (func (param i64)))
 (type $187 (func (param f64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign5 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign7 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign8 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-open" (func $foreign10 (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign11 (param i32 i32)))
 (import "snail.library" "snail:datum/fail" (func $foreign12 (param i32)))
 (import "snail.library" "snail:datum/token-identifier" (func $foreign13 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign14 (param i32)))
 (import "snail.library" "snail:datum/token-intern" (func $foreign15 (param i32) (result i32)))
 (import "snail.library" "snail:datum/symbol-length" (func $foreign16 (param i32) (result i64)))
 (import "snail.library" "snail:datum/symbol-character" (func $foreign17 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign18 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign19 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign20 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/error-length" (func $foreign21 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign22 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse" (func $foreign23 (param i32) (result i32)))
 (import "snail.library" "snail:datum/whitespace" (func $foreign25 (param i32) (result i32)))
 (import "benchmark" "barrier" (func $foreign26 (result i32)))
 (import "reader.test" "emit_i64" (func $foreign27 (param i64)))
 (import "reader.test" "emit_char" (func $foreign28 (param i32)))
 (import "reader.test" "emit_f64" (func $foreign29 (param f64)))
 (global $global527 (mut (ref null $type148)) (ref.null none))
 (global $global133 (mut (ref null $type71)) (ref.null none))
 (global $empty69 (ref $type69) (struct.new_default $type69))
 (global $global521 (mut (ref null $type146)) (ref.null none))
 (global $global135 (mut (ref null $type72)) (ref.null none))
 (global $global103 (mut (ref null $type51)) (ref.null none))
 (global $global61 (mut (ref null $type41)) (ref.null none))
 (global $global317 (mut (ref null $type111)) (ref.null none))
 (global $global707 (mut (ref null $type193)) (ref.null none))
 (global $global137 (mut (ref null $type72)) (ref.null none))
 (global $global411 (mut (ref null $type129)) (ref.null none))
 (global $global541 (mut (ref null $type147)) (ref.null none))
 (global $global519 (mut (ref null $type147)) (ref.null none))
 (global $ready707 (mut i32) (i32.const 0))
 (global $global516 (mut (ref null $type160)) (ref.null none))
 (global $global837 (mut (ref null $type204)) (ref.null none))
 (global $global98 (mut (ref null $type50)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global538 (mut (ref null $type149)) (ref.null none))
 (global $global600 (mut (ref null $type155)) (ref.null none))
 (global $global777 (mut (ref null $type145)) (ref.null none))
 (global $global323 (mut (ref null $type112)) (ref.null none))
 (global $global509 (mut (ref null $type144)) (ref.null none))
 (global $ready516 (mut i32) (i32.const 0))
 (global $global691 (mut (ref null $type188)) (ref.null none))
 (global $execution (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type45)) (ref.null none))
 (global $global514 (mut (ref null $type145)) (ref.null none))
 (global $global551 (mut (ref null $type151)) (ref.null none))
 (global $global624 (mut (ref null $type159)) (ref.null none))
 (global $ready691 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type47)) (ref.null none))
 (global $global329 (mut (ref null $type113)) (ref.null none))
 (global $global647 (mut (ref null $type158)) (ref.null none))
 (global $ready624 (mut i32) (i32.const 0))
 (global $global698 (mut (ref null $type190)) (ref.null none))
 (global $global809 (mut (ref null $type66)) (ref.null none))
 (global $global88 (mut (ref null $type46)) (ref.null none))
 (global $global109 (mut (ref null $type52)) (ref.null none))
 (global $global120 (mut (ref null $type57)) (ref.null none))
 (global $global127 (mut (ref null $type60)) (ref.null none))
 (global $global124 (mut (ref null $type61)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global367 (mut (ref null $type118)) (ref.null none))
 (global $global376 (mut (ref null $type120)) (ref.null none))
 (global $global379 (mut (ref null $type125)) (ref.null none))
 (global $global504 (mut (ref null $type139)) (ref.null none))
 (global $global525 (mut (ref null $type150)) (ref.null none))
 (global $global632 (mut (ref null $type150)) (ref.null none))
 (global $global557 (mut (ref null $type157)) (ref.null none))
 (global $global655 (mut (ref null $type46)) (ref.null none))
 (global $global530 (mut (ref null $type60)) (ref.null none))
 (global $global543 (mut (ref null $type171)) (ref.null none))
 (global $ready543 (mut i32) (i32.const 0))
 (global $global552 (mut (ref null $type176)) (ref.null none))
 (global $ready552 (mut i32) (i32.const 0))
 (global $global590 (mut (ref null $type60)) (ref.null none))
 (global $global585 (mut (ref null $type184)) (ref.null none))
 (global $ready585 (mut i32) (i32.const 0))
 (global $global577 (mut (ref null $type97)) (ref.null none))
 (global $global573 (mut (ref null $type150)) (ref.null none))
 (global $global570 (mut (ref null $type185)) (ref.null none))
 (global $global565 (mut (ref null $type186)) (ref.null none))
 (global $ready565 (mut i32) (i32.const 0))
 (global $ready698 (mut i32) (i32.const 0))
 (global $global732 (mut (ref null $type197)) (ref.null none))
 (global $ready732 (mut i32) (i32.const 0))
 (global $global821 (mut (ref null $type52)) (ref.null none))
 (global $global825 (mut (ref null $type202)) (ref.null none))
 (global $ready837 (mut i32) (i32.const 0))
 (global $string1 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string11 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 85)
   (i32.const 110)
   (i32.const 105)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $empty14 (ref $type14) (struct.new $type14
  (i32.const 0)
 ))
 (global $global715 (mut (ref null $type11)) (ref.null none))
 (global $global718 (mut (ref null $type40)) (ref.null none))
 (global $ready718 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type49)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global799 (mut (ref null $type62)) (ref.null none))
 (global $global810 (mut (ref null $type64)) (ref.null none))
 (global $global180 (mut (ref null $type84)) (ref.null none))
 (global $global325 (mut (ref null $type53)) (ref.null none))
 (global $global334 (mut (ref null $type115)) (ref.null none))
 (global $global370 (mut (ref null $type119)) (ref.null none))
 (global $global424 (mut (ref null $type132)) (ref.null none))
 (global $global436 (mut (ref null $type133)) (ref.null none))
 (global $global604 (mut (ref null $type156)) (ref.null none))
 (global $ready604 (mut i32) (i32.const 0))
 (global $ready530 (mut i32) (i32.const 0))
 (global $global619 (mut (ref null $type160)) (ref.null none))
 (global $global535 (mut (ref null $type169)) (ref.null none))
 (global $ready535 (mut i32) (i32.const 0))
 (global $global616 (mut (ref null $type160)) (ref.null none))
 (global $ready616 (mut i32) (i32.const 0))
 (global $global673 (mut (ref null $type160)) (ref.null none))
 (global $ready673 (mut i32) (i32.const 0))
 (global $global675 (mut (ref null $type170)) (ref.null none))
 (global $ready675 (mut i32) (i32.const 0))
 (global $global686 (mut (ref null $type170)) (ref.null none))
 (global $ready686 (mut i32) (i32.const 0))
 (global $global548 (mut (ref null $type172)) (ref.null none))
 (global $ready548 (mut i32) (i32.const 0))
 (global $global610 (mut (ref null $type177)) (ref.null none))
 (global $ready610 (mut i32) (i32.const 0))
 (global $global593 (mut (ref null $type178)) (ref.null none))
 (global $ready593 (mut i32) (i32.const 0))
 (global $global559 (mut (ref null $type183)) (ref.null none))
 (global $ready559 (mut i32) (i32.const 0))
 (global $global580 (mut (ref null $type150)) (ref.null none))
 (global $ready580 (mut i32) (i32.const 0))
 (global $ready590 (mut i32) (i32.const 0))
 (global $global663 (mut (ref null $type187)) (ref.null none))
 (global $global629 (mut (ref null $type160)) (ref.null none))
 (global $ready629 (mut i32) (i32.const 0))
 (global $global652 (mut (ref null $type170)) (ref.null none))
 (global $ready652 (mut i32) (i32.const 0))
 (global $global661 (mut (ref null $type187)) (ref.null none))
 (global $ready661 (mut i32) (i32.const 0))
 (global $global769 (mut (ref null $type189)) (ref.null none))
 (global $ready769 (mut i32) (i32.const 0))
 (global $global759 (mut (ref null $type191)) (ref.null none))
 (global $ready759 (mut i32) (i32.const 0))
 (global $global745 (mut (ref null $type192)) (ref.null none))
 (global $ready745 (mut i32) (i32.const 0))
 (global $global710 (mut (ref null $type194)) (ref.null none))
 (global $global704 (mut (ref null $type195)) (ref.null none))
 (global $ready704 (mut i32) (i32.const 0))
 (global $global726 (mut (ref null $type196)) (ref.null none))
 (global $ready726 (mut i32) (i32.const 0))
 (global $global737 (mut (ref null $type132)) (ref.null none))
 (global $global785 (mut (ref null $type132)) (ref.null none))
 (global $global792 (mut (ref null $type200)) (ref.null none))
 (global $global804 (mut (ref null $type65)) (ref.null none))
 (global $global815 (mut (ref null $type18)) (ref.null none))
 (global $global817 (mut (ref null $type5)) (ref.null none))
 (global $ready817 (mut i32) (i32.const 0))
 (global $global818 (mut (ref null $type201)) (ref.null none))
 (global $global830 (mut (ref null $type203)) (ref.null none))
 (global $global848 (mut (ref null $type205)) (ref.null none))
 (global $ready848 (mut i32) (i32.const 0))
 (global $global853 (mut (ref null $type206)) (ref.null none))
 (global $ready853 (mut i32) (i32.const 0))
 (global $global857 (mut (ref null $type5)) (ref.null none))
 (global $ready857 (mut i32) (i32.const 0))
 (global $string2 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 44)
  (array.new_fixed $type19 44
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 44)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 102)
   (i32.const 105)
   (i32.const 108)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 105)
   (i32.const 109)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string4 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string5 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 16)
  (array.new_fixed $type19 16
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 45)
   (i32.const 115)
   (i32.const 112)
   (i32.const 108)
   (i32.const 105)
   (i32.const 99)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
  )
  (ref.null none)
 ))
 (global $string6 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 10)
  (array.new_fixed $type19 10
   (i32.const 113)
   (i32.const 117)
   (i32.const 97)
   (i32.const 115)
   (i32.const 105)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string7 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string8 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 109)
   (i32.const 98)
   (i32.const 111)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string9 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string10 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 104)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 99)
   (i32.const 105)
   (i32.const 109)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string12 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 110)
   (i32.const 117)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string13 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 99)
   (i32.const 101)
   (i32.const 101)
   (i32.const 100)
   (i32.const 115)
   (i32.const 32)
   (i32.const 83)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
  )
  (ref.null none)
 ))
 (global $string14 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 35)
  )
  (ref.null none)
 ))
 (global $string15 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 108)
   (i32.const 97)
   (i32.const 98)
   (i32.const 101)
   (i32.const 108)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string16 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 115)
   (i32.const 101)
   (i32.const 32)
   (i32.const 100)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string17 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 98)
   (i32.const 108)
   (i32.const 111)
   (i32.const 99)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string18 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string19 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string20 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string21 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 25)
  (array.new_fixed $type19 25
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string22 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 116)
   (i32.const 97)
   (i32.const 98)
  )
  (ref.null none)
 ))
 (global $string23 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string24 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 116)
   (i32.const 117)
   (i32.const 114)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string25 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 110)
   (i32.const 117)
   (i32.const 108)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string26 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string27 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string28 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string29 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 98)
   (i32.const 97)
   (i32.const 99)
   (i32.const 107)
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string30 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string31 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 22)
  (array.new_fixed $type19 22
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string32 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type19 31
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 117)
   (i32.const 56)
   (i32.const 40)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string33 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string34 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 102)
  )
  (ref.null none)
 ))
 (global $string35 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 35)
   (i32.const 102)
   (i32.const 97)
   (i32.const 108)
   (i32.const 115)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string36 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string37 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 35)
   (i32.const 116)
   (i32.const 114)
   (i32.const 117)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string38 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 71)
  (array.new_fixed $type19 71
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 102)
   (i32.const 105)
   (i32.const 101)
   (i32.const 114)
   (i32.const 59)
   (i32.const 32)
   (i32.const 114)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string39 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 46)
  )
  (ref.null none)
 ))
 (global $string40 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 14)
  (array.new_fixed $type19 14
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string41 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 112)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 104)
   (i32.const 101)
   (i32.const 115)
   (i32.const 105)
   (i32.const 115)
  )
  (ref.null none)
 ))
 (global $string42 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 112)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 100)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string43 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 115)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string44 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 42)
  (array.new_fixed $type19 42
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 91)
   (i32.const 48)
   (i32.const 44)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
   (i32.const 93)
  )
  (ref.null none)
 ))
 (global $string45 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 109)
   (i32.const 105)
   (i32.const 115)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string46 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 36)
  (array.new_fixed $type19 36
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string47 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 33)
  (array.new_fixed $type19 33
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string48 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string49 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 117)
   (i32.const 110)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string50 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string51 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string53 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 98)
   (i32.const 101)
   (i32.const 110)
   (i32.const 99)
   (i32.const 104)
   (i32.const 109)
   (i32.const 97)
   (i32.const 114)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 109)
   (i32.const 117)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string54 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $empty122 (ref $type122) (struct.new $type122
  (i32.const 0)
 ))
 (global $empty141 (ref $type141) (struct.new $type141
  (i32.const 0)
 ))
 (global $empty163 (ref $type163) (struct.new $type163
  (i32.const 1)
 ))
 (global $empty164 (ref $type164) (struct.new $type164
  (i32.const 2)
 ))
 (global $empty165 (ref $type165) (struct.new $type165
  (i32.const 3)
 ))
 (global $empty181 (ref $type181) (struct.new $type181
  (i32.const 1)
 ))
 (export "observe-once" (func $export0))
 (export "configured-count" (func $export1))
 (export "main" (func $main))
 (func $string-new (type $87) (param $0 i32) (result (ref $type18))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type20))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type20
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type20
      (local.get $5)
      (local.get $2)
      (array.new_default $type19
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type18
   (i32.const 1)
   (local.get $0)
   (array.new_default $type19
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-block (type $85) (param $0 (ref $type18)) (param $1 i32) (result (ref $type19))
  (if (result (ref $type19))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type18 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type20
      (struct.get $type18 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy (type $84) (param $0 (ref $type18)) (param $1 i64) (param $2 (ref $type18)) (param $3 i64)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ne
     (local.get $1)
     (i64.const 0)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (local.get $3)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $4
     (local.get $7)
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $6
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $4)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $6)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $4
           (i32.sub
            (local.get $4)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $4)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $4)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $8
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $9
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (loop $label1
     (if
      (local.get $9)
      (then
       (local.set $4
        (select
         (local.get $9)
         (local.tee $4
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $5
              (i32.and
               (local.get $8)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $4
            (i32.sub
             (i32.const 8192)
             (local.tee $7
              (i32.and
               (local.get $10)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.gt_u
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i32.gt_u
          (local.get $4)
          (local.get $9)
         )
        )
       )
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $8)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $5)
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $10)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $10)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $7)
        (local.get $4)
       )
       (local.set $8
        (i32.add
         (local.get $4)
         (local.get $8)
        )
       )
       (local.set $10
        (i32.add
         (local.get $4)
         (local.get $10)
        )
       )
       (local.set $9
        (i32.sub
         (local.get $9)
         (local.get $4)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function35 (type $83) (param $0 (ref $type48)) (result (ref $type18))
  (local $1 (ref null $type48))
  (local $2 (ref null $type48))
  (local $3 (ref null $type48))
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 i64)
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $6
   (if (result i64)
    (i64.gt_u
     (local.tee $6
      (i64.extend_i32_u
       (struct.get $type18 1
        (struct.get $type48 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type48 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $6)
      )
      (else
       (local.set $3
        (struct.get $type48 1
         (local.get $1)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $6
          (i64.add
           (i64.extend_i32_u
            (struct.get $type18 1
             (struct.get $type48 0
              (local.get $1)
             )
            )
           )
           (local.get $6)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (local.get $6)
          )
          (else
           (local.set $2
            (struct.get $type48 1
             (local.get $3)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $6
              (i64.add
               (i64.extend_i32_u
                (struct.get $type18 1
                 (struct.get $type48 0
                  (local.get $3)
                 )
                )
               )
               (local.get $6)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $1
                (struct.get $type48 1
                 (local.get $2)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $6
                  (i64.add
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (struct.get $type48 0
                      (local.get $2)
                     )
                    )
                   )
                   (local.get $6)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $2
                    (struct.get $type48 1
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.tee $6
                      (i64.add
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (struct.get $type48 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.get $6)
                      )
                     )
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $1
                        (struct.get $type48 1
                         (local.get $2)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.tee $6
                          (i64.add
                           (i64.extend_i32_u
                            (struct.get $type18 1
                             (struct.get $type48 0
                              (local.get $2)
                             )
                            )
                           )
                           (local.get $6)
                          )
                         )
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $2
                            (struct.get $type48 1
                             (local.get $1)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.tee $6
                              (i64.add
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (struct.get $type48 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (local.get $6)
                              )
                             )
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (local.get $6)
                              )
                              (else
                               (local.set $1
                                (struct.get $type48 1
                                 (local.get $2)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.tee $6
                                  (i64.add
                                   (i64.extend_i32_u
                                    (struct.get $type18 1
                                     (struct.get $type48 0
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (local.get $6)
                                  )
                                 )
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (local.get $6)
                                  )
                                  (else
                                   (local.set $2
                                    (struct.get $type48 1
                                     (local.get $1)
                                    )
                                   )
                                   (if (result i64)
                                    (i64.gt_s
                                     (local.tee $6
                                      (i64.add
                                       (i64.extend_i32_u
                                        (struct.get $type18 1
                                         (struct.get $type48 0
                                          (local.get $1)
                                         )
                                        )
                                       )
                                       (local.get $6)
                                      )
                                     )
                                     (i64.const 4294967294)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.get $2)
                                      )
                                      (then
                                       (local.get $6)
                                      )
                                      (else
                                       (local.set $1
                                        (struct.get $type48 1
                                         (local.get $2)
                                        )
                                       )
                                       (if (result i64)
                                        (i64.gt_s
                                         (local.tee $6
                                          (i64.add
                                           (i64.extend_i32_u
                                            (struct.get $type18 1
                                             (struct.get $type48 0
                                              (local.get $2)
                                             )
                                            )
                                           )
                                           (local.get $6)
                                          )
                                         )
                                         (i64.const 4294967294)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                        (else
                                         (if (result i64)
                                          (ref.is_null
                                           (local.get $1)
                                          )
                                          (then
                                           (local.get $6)
                                          )
                                          (else
                                           (local.set $2
                                            (struct.get $type48 1
                                             (local.get $1)
                                            )
                                           )
                                           (if (result i64)
                                            (i64.gt_s
                                             (local.tee $6
                                              (i64.add
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (struct.get $type48 0
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                               (local.get $6)
                                              )
                                             )
                                             (i64.const 4294967294)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                            (else
                                             (if (result i64)
                                              (ref.is_null
                                               (local.get $2)
                                              )
                                              (then
                                               (local.get $6)
                                              )
                                              (else
                                               (local.set $1
                                                (struct.get $type48 1
                                                 (local.get $2)
                                                )
                                               )
                                               (if (result i64)
                                                (i64.gt_s
                                                 (local.tee $6
                                                  (i64.add
                                                   (i64.extend_i32_u
                                                    (struct.get $type18 1
                                                     (struct.get $type48 0
                                                      (local.get $2)
                                                     )
                                                    )
                                                   )
                                                   (local.get $6)
                                                  )
                                                 )
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                                (else
                                                 (if (result i64)
                                                  (ref.is_null
                                                   (local.get $1)
                                                  )
                                                  (then
                                                   (local.get $6)
                                                  )
                                                  (else
                                                   (local.set $2
                                                    (struct.get $type48 1
                                                     (local.get $1)
                                                    )
                                                   )
                                                   (if (result i64)
                                                    (i64.gt_s
                                                     (local.tee $6
                                                      (i64.add
                                                       (i64.extend_i32_u
                                                        (struct.get $type18 1
                                                         (struct.get $type48 0
                                                          (local.get $1)
                                                         )
                                                        )
                                                       )
                                                       (local.get $6)
                                                      )
                                                     )
                                                     (i64.const 4294967294)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                    (else
                                                     (if (result i64)
                                                      (ref.is_null
                                                       (local.get $2)
                                                      )
                                                      (then
                                                       (local.get $6)
                                                      )
                                                      (else
                                                       (local.set $1
                                                        (struct.get $type48 1
                                                         (local.get $2)
                                                        )
                                                       )
                                                       (if (result i64)
                                                        (i64.gt_s
                                                         (local.tee $6
                                                          (i64.add
                                                           (i64.extend_i32_u
                                                            (struct.get $type18 1
                                                             (struct.get $type48 0
                                                              (local.get $2)
                                                             )
                                                            )
                                                           )
                                                           (local.get $6)
                                                          )
                                                         )
                                                         (i64.const 4294967294)
                                                        )
                                                        (then
                                                         (unreachable)
                                                        )
                                                        (else
                                                         (if (result i64)
                                                          (ref.is_null
                                                           (local.get $1)
                                                          )
                                                          (then
                                                           (local.get $6)
                                                          )
                                                          (else
                                                           (local.set $2
                                                            (struct.get $type48 1
                                                             (local.get $1)
                                                            )
                                                           )
                                                           (if (result i64)
                                                            (i64.gt_s
                                                             (local.tee $6
                                                              (i64.add
                                                               (i64.extend_i32_u
                                                                (struct.get $type18 1
                                                                 (struct.get $type48 0
                                                                  (local.get $1)
                                                                 )
                                                                )
                                                               )
                                                               (local.get $6)
                                                              )
                                                             )
                                                             (i64.const 4294967294)
                                                            )
                                                            (then
                                                             (unreachable)
                                                            )
                                                            (else
                                                             (if (result i64)
                                                              (ref.is_null
                                                               (local.get $2)
                                                              )
                                                              (then
                                                               (local.get $6)
                                                              )
                                                              (else
                                                               (local.set $1
                                                                (struct.get $type48 1
                                                                 (local.get $2)
                                                                )
                                                               )
                                                               (if (result i64)
                                                                (i64.gt_s
                                                                 (local.tee $6
                                                                  (i64.add
                                                                   (i64.extend_i32_u
                                                                    (struct.get $type18 1
                                                                     (struct.get $type48 0
                                                                      (local.get $2)
                                                                     )
                                                                    )
                                                                   )
                                                                   (local.get $6)
                                                                  )
                                                                 )
                                                                 (i64.const 4294967294)
                                                                )
                                                                (then
                                                                 (unreachable)
                                                                )
                                                                (else
                                                                 (if (result i64)
                                                                  (ref.is_null
                                                                   (local.get $1)
                                                                  )
                                                                  (then
                                                                   (local.get $6)
                                                                  )
                                                                  (else
                                                                   (local.set $2
                                                                    (struct.get $type48 1
                                                                     (local.get $1)
                                                                    )
                                                                   )
                                                                   (if (result i64)
                                                                    (i64.gt_s
                                                                     (local.tee $6
                                                                      (i64.add
                                                                       (i64.extend_i32_u
                                                                        (struct.get $type18 1
                                                                         (struct.get $type48 0
                                                                          (local.get $1)
                                                                         )
                                                                        )
                                                                       )
                                                                       (local.get $6)
                                                                      )
                                                                     )
                                                                     (i64.const 4294967294)
                                                                    )
                                                                    (then
                                                                     (unreachable)
                                                                    )
                                                                    (else
                                                                     (if (result i64)
                                                                      (ref.is_null
                                                                       (local.get $2)
                                                                      )
                                                                      (then
                                                                       (local.get $6)
                                                                      )
                                                                      (else
                                                                       (local.set $1
                                                                        (struct.get $type48 1
                                                                         (local.get $2)
                                                                        )
                                                                       )
                                                                       (if (result i64)
                                                                        (i64.gt_s
                                                                         (local.tee $6
                                                                          (i64.add
                                                                           (i64.extend_i32_u
                                                                            (struct.get $type18 1
                                                                             (struct.get $type48 0
                                                                              (local.get $2)
                                                                             )
                                                                            )
                                                                           )
                                                                           (local.get $6)
                                                                          )
                                                                         )
                                                                         (i64.const 4294967294)
                                                                        )
                                                                        (then
                                                                         (unreachable)
                                                                        )
                                                                        (else
                                                                         (if (result i64)
                                                                          (ref.is_null
                                                                           (local.get $1)
                                                                          )
                                                                          (then
                                                                           (local.get $6)
                                                                          )
                                                                          (else
                                                                           (call $function37
                                                                            (i32.const 0)
                                                                            (i32.const 1)
                                                                            (struct.get $type48 1
                                                                             (local.get $1)
                                                                            )
                                                                            (i64.add
                                                                             (i64.extend_i32_u
                                                                              (struct.get $type18 1
                                                                               (struct.get $type48 0
                                                                                (local.get $1)
                                                                               )
                                                                              )
                                                                             )
                                                                             (local.get $6)
                                                                            )
                                                                           )
                                                                          )
                                                                         )
                                                                        )
                                                                       )
                                                                      )
                                                                     )
                                                                    )
                                                                   )
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call $string-new
    (i32.wrap_i64
     (local.get $6)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (call $string-copy
   (local.get $5)
   (i64.const 0)
   (local.tee $4
    (struct.get $type48 0
     (local.get $0)
    )
   )
   (local.tee $7
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $4)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.tee $1
      (struct.get $type48 1
       (local.get $0)
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (call $string-copy
      (local.get $5)
      (local.get $7)
      (local.tee $4
       (struct.get $type48 0
        (local.get $1)
       )
      )
      (local.tee $6
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $4)
        )
       )
      )
     )
     (local.set $1
      (struct.get $type48 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready98)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global98)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $string-copy
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $6)
          (local.get $7)
         )
        )
        (local.tee $4
         (struct.get $type48 0
          (local.get $1)
         )
        )
        (local.tee $6
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $4)
          )
         )
        )
       )
       (local.set $1
        (struct.get $type48 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready98)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global98)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $string-copy
          (local.get $5)
          (local.tee $7
           (i64.add
            (local.get $6)
            (local.get $7)
           )
          )
          (local.tee $4
           (struct.get $type48 0
            (local.get $1)
           )
          )
          (local.tee $6
           (i64.extend_i32_u
            (struct.get $type18 1
             (local.get $4)
            )
           )
          )
         )
         (local.set $1
          (struct.get $type48 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready98)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global98)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $string-copy
            (local.get $5)
            (local.tee $7
             (i64.add
              (local.get $6)
              (local.get $7)
             )
            )
            (local.tee $4
             (struct.get $type48 0
              (local.get $1)
             )
            )
            (local.tee $6
             (i64.extend_i32_u
              (struct.get $type18 1
               (local.get $4)
              )
             )
            )
           )
           (local.set $1
            (struct.get $type48 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready98)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global98)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $string-copy
              (local.get $5)
              (local.tee $7
               (i64.add
                (local.get $6)
                (local.get $7)
               )
              )
              (local.tee $4
               (struct.get $type48 0
                (local.get $1)
               )
              )
              (local.tee $6
               (i64.extend_i32_u
                (struct.get $type18 1
                 (local.get $4)
                )
               )
              )
             )
             (local.set $1
              (struct.get $type48 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready98)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global98)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $string-copy
                (local.get $5)
                (local.tee $7
                 (i64.add
                  (local.get $6)
                  (local.get $7)
                 )
                )
                (local.tee $4
                 (struct.get $type48 0
                  (local.get $1)
                 )
                )
                (local.tee $6
                 (i64.extend_i32_u
                  (struct.get $type18 1
                   (local.get $4)
                  )
                 )
                )
               )
               (local.set $1
                (struct.get $type48 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready98)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global98)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $string-copy
                  (local.get $5)
                  (local.tee $7
                   (i64.add
                    (local.get $6)
                    (local.get $7)
                   )
                  )
                  (local.tee $4
                   (struct.get $type48 0
                    (local.get $1)
                   )
                  )
                  (local.tee $6
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (local.set $1
                  (struct.get $type48 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready98)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global98)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $string-copy
                    (local.get $5)
                    (local.tee $7
                     (i64.add
                      (local.get $6)
                      (local.get $7)
                     )
                    )
                    (local.tee $4
                     (struct.get $type48 0
                      (local.get $1)
                     )
                    )
                    (local.tee $6
                     (i64.extend_i32_u
                      (struct.get $type18 1
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (local.set $1
                    (struct.get $type48 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready98)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global98)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $string-copy
                      (local.get $5)
                      (local.tee $7
                       (i64.add
                        (local.get $6)
                        (local.get $7)
                       )
                      )
                      (local.tee $4
                       (struct.get $type48 0
                        (local.get $1)
                       )
                      )
                      (local.tee $6
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.set $1
                      (struct.get $type48 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready98)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global98)
                      )
                     )
                     (if (result i32)
                      (ref.is_null
                       (local.get $1)
                      )
                      (then
                       (i32.const 0)
                      )
                      (else
                       (call $string-copy
                        (local.get $5)
                        (local.tee $7
                         (i64.add
                          (local.get $6)
                          (local.get $7)
                         )
                        )
                        (local.tee $4
                         (struct.get $type48 0
                          (local.get $1)
                         )
                        )
                        (local.tee $6
                         (i64.extend_i32_u
                          (struct.get $type18 1
                           (local.get $4)
                          )
                         )
                        )
                       )
                       (local.set $1
                        (struct.get $type48 1
                         (local.get $1)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready98)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global98)
                        )
                       )
                       (if (result i32)
                        (ref.is_null
                         (local.get $1)
                        )
                        (then
                         (i32.const 0)
                        )
                        (else
                         (call $string-copy
                          (local.get $5)
                          (local.tee $7
                           (i64.add
                            (local.get $6)
                            (local.get $7)
                           )
                          )
                          (local.tee $4
                           (struct.get $type48 0
                            (local.get $1)
                           )
                          )
                          (local.tee $6
                           (i64.extend_i32_u
                            (struct.get $type18 1
                             (local.get $4)
                            )
                           )
                          )
                         )
                         (local.set $1
                          (struct.get $type48 1
                           (local.get $1)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready98)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global98)
                          )
                         )
                         (if (result i32)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (i32.const 0)
                          )
                          (else
                           (call $string-copy
                            (local.get $5)
                            (local.tee $7
                             (i64.add
                              (local.get $6)
                              (local.get $7)
                             )
                            )
                            (local.tee $4
                             (struct.get $type48 0
                              (local.get $1)
                             )
                            )
                            (local.tee $6
                             (i64.extend_i32_u
                              (struct.get $type18 1
                               (local.get $4)
                              )
                             )
                            )
                           )
                           (local.set $1
                            (struct.get $type48 1
                             (local.get $1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready98)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global98)
                            )
                           )
                           (if (result i32)
                            (ref.is_null
                             (local.get $1)
                            )
                            (then
                             (i32.const 0)
                            )
                            (else
                             (call $string-copy
                              (local.get $5)
                              (local.tee $7
                               (i64.add
                                (local.get $6)
                                (local.get $7)
                               )
                              )
                              (local.tee $4
                               (struct.get $type48 0
                                (local.get $1)
                               )
                              )
                              (local.tee $6
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (local.get $4)
                                )
                               )
                              )
                             )
                             (local.set $1
                              (struct.get $type48 1
                               (local.get $1)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready98)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global98)
                              )
                             )
                             (if (result i32)
                              (ref.is_null
                               (local.get $1)
                              )
                              (then
                               (i32.const 0)
                              )
                              (else
                               (call $string-copy
                                (local.get $5)
                                (local.tee $7
                                 (i64.add
                                  (local.get $6)
                                  (local.get $7)
                                 )
                                )
                                (local.tee $4
                                 (struct.get $type48 0
                                  (local.get $1)
                                 )
                                )
                                (local.tee $6
                                 (i64.extend_i32_u
                                  (struct.get $type18 1
                                   (local.get $4)
                                  )
                                 )
                                )
                               )
                               (local.set $1
                                (struct.get $type48 1
                                 (local.get $1)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready98)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global98)
                                )
                               )
                               (if (result i32)
                                (ref.is_null
                                 (local.get $1)
                                )
                                (then
                                 (i32.const 0)
                                )
                                (else
                                 (call $string-copy
                                  (local.get $5)
                                  (local.tee $7
                                   (i64.add
                                    (local.get $6)
                                    (local.get $7)
                                   )
                                  )
                                  (local.tee $4
                                   (struct.get $type48 0
                                    (local.get $1)
                                   )
                                  )
                                  (local.tee $6
                                   (i64.extend_i32_u
                                    (struct.get $type18 1
                                     (local.get $4)
                                    )
                                   )
                                  )
                                 )
                                 (local.set $1
                                  (struct.get $type48 1
                                   (local.get $1)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready98)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global98)
                                  )
                                 )
                                 (if (result i32)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (i32.const 0)
                                  )
                                  (else
                                   (call $string-copy
                                    (local.get $5)
                                    (local.tee $7
                                     (i64.add
                                      (local.get $6)
                                      (local.get $7)
                                     )
                                    )
                                    (local.tee $4
                                     (struct.get $type48 0
                                      (local.get $1)
                                     )
                                    )
                                    (local.tee $6
                                     (i64.extend_i32_u
                                      (struct.get $type18 1
                                       (local.get $4)
                                      )
                                     )
                                    )
                                   )
                                   (local.set $1
                                    (struct.get $type48 1
                                     (local.get $1)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready98)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global98)
                                    )
                                   )
                                   (if (result i32)
                                    (ref.is_null
                                     (local.get $1)
                                    )
                                    (then
                                     (i32.const 0)
                                    )
                                    (else
                                     (call $string-copy
                                      (local.get $5)
                                      (local.tee $7
                                       (i64.add
                                        (local.get $6)
                                        (local.get $7)
                                       )
                                      )
                                      (local.tee $4
                                       (struct.get $type48 0
                                        (local.get $1)
                                       )
                                      )
                                      (local.tee $6
                                       (i64.extend_i32_u
                                        (struct.get $type18 1
                                         (local.get $4)
                                        )
                                       )
                                      )
                                     )
                                     (local.set $1
                                      (struct.get $type48 1
                                       (local.get $1)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready98)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global98)
                                      )
                                     )
                                     (if (result i32)
                                      (ref.is_null
                                       (local.get $1)
                                      )
                                      (then
                                       (i32.const 0)
                                      )
                                      (else
                                       (call $string-copy
                                        (local.get $5)
                                        (local.tee $7
                                         (i64.add
                                          (local.get $6)
                                          (local.get $7)
                                         )
                                        )
                                        (local.tee $4
                                         (struct.get $type48 0
                                          (local.get $1)
                                         )
                                        )
                                        (local.tee $6
                                         (i64.extend_i32_u
                                          (struct.get $type18 1
                                           (local.get $4)
                                          )
                                         )
                                        )
                                       )
                                       (local.set $1
                                        (struct.get $type48 1
                                         (local.get $1)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready98)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global98)
                                        )
                                       )
                                       (if (result i32)
                                        (ref.is_null
                                         (local.get $1)
                                        )
                                        (then
                                         (i32.const 0)
                                        )
                                        (else
                                         (call $string-copy
                                          (local.get $5)
                                          (local.tee $7
                                           (i64.add
                                            (local.get $6)
                                            (local.get $7)
                                           )
                                          )
                                          (local.tee $4
                                           (struct.get $type48 0
                                            (local.get $1)
                                           )
                                          )
                                          (local.tee $6
                                           (i64.extend_i32_u
                                            (struct.get $type18 1
                                             (local.get $4)
                                            )
                                           )
                                          )
                                         )
                                         (local.set $1
                                          (struct.get $type48 1
                                           (local.get $1)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready98)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global98)
                                          )
                                         )
                                         (call $function38
                                          (local.get $5)
                                          (local.get $1)
                                          (i64.add
                                           (local.get $6)
                                           (local.get $7)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $5)
 )
 (func $function37 (type $81) (param $0 i32) (param $1 i32) (param $2 (ref null $type48)) (param $3 i64) (result i64)
  (local $4 (ref null $type48))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $4
       (struct.get $type48 1
        (local.get $2)
       )
      )
      (local.set $5
       (i64.extend_i32_u
        (struct.get $type18 1
         (struct.get $type48 0
          (local.get $2)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (i64.add
        (local.get $3)
        (local.get $5)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call50) (param $0 (ref $type18)) (param $1 (ref null $type48)) (param $2 i64) (result i32)
  (local $3 (ref $type18))
  (local $4 i64)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $3
      (struct.get $type48 0
       (local.get $1)
      )
     )
     (local.tee $4
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $3)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type48 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function40 (type $79) (param $0 (ref $type18)) (param $1 (ref $type18)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $1)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $1)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call52) (param $0 (ref $type18)) (result i32)
  (local $1 i64)
  (call $foreign0)
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (array.get $type19
                        (struct.get $type18 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $1)
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign1
                         (array.get $type19
                          (struct.get $type18 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $1)
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type18 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign1
                           (array.get $type19
                            (struct.get $type18 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $1)
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign1
                             (array.get $type19
                              (struct.get $type18 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $1)
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type18 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign1
                               (array.get $type19
                                (struct.get $type18 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $1)
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign1
                                 (array.get $type19
                                  (struct.get $type18 2
                                   (local.get $0)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 15)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type18 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $foreign1
                                   (array.get $type19
                                    (struct.get $type18 2
                                     (local.get $0)
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 16)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (call $foreign1
                                     (array.get $type19
                                      (struct.get $type18 2
                                       (local.get $0)
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $1)
                                      (i64.const 17)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type18 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call $foreign1
                                       (array.get $type19
                                        (struct.get $type18 2
                                         (local.get $0)
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 18)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (call $foreign1
                                         (array.get $type19
                                          (struct.get $type18 2
                                           (local.get $0)
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $1)
                                          (i64.const 19)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $0)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $foreign1
                                           (array.get $type19
                                            (call $string-block
                                             (local.get $0)
                                             (i32.const 19)
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (return_call $function42
                                           (local.get $0)
                                           (local.get $1)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $77) (param $0 (ref $type18)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i32.and
       (local.get $5)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function104 (type $call111) (param $0 (ref $type18)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local.set $1
   (call $foreign10)
  )
  (if (result i32)
   (i64.eqz
    (local.tee $2
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign11
     (local.get $1)
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 1)
     )
     (then
      (local.get $1)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign11
       (local.get $1)
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $2)
        (i64.const 2)
       )
       (then
        (local.get $1)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign11
         (local.get $1)
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $2)
          (i64.const 3)
         )
         (then
          (local.get $1)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign11
           (local.get $1)
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $2)
            (i64.const 4)
           )
           (then
            (local.get $1)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign11
             (local.get $1)
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $2)
              (i64.const 5)
             )
             (then
              (local.get $1)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign11
               (local.get $1)
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $2)
                (i64.const 6)
               )
               (then
                (local.get $1)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign11
                 (local.get $1)
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $2)
                  (i64.const 7)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign11
                   (local.get $1)
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $2)
                    (i64.const 8)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign11
                     (local.get $1)
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $2)
                      (i64.const 9)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign11
                       (local.get $1)
                       (array.get $type19
                        (struct.get $type18 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $2)
                        (i64.const 10)
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign11
                         (local.get $1)
                         (array.get $type19
                          (struct.get $type18 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $2)
                          (i64.const 11)
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type18 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign11
                           (local.get $1)
                           (array.get $type19
                            (struct.get $type18 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $2)
                            (i64.const 12)
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign11
                             (local.get $1)
                             (array.get $type19
                              (struct.get $type18 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $2)
                              (i64.const 13)
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type18 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign11
                               (local.get $1)
                               (array.get $type19
                                (struct.get $type18 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $2)
                                (i64.const 14)
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign11
                                 (local.get $1)
                                 (array.get $type19
                                  (struct.get $type18 2
                                   (local.get $0)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $2)
                                  (i64.const 15)
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type18 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $foreign11
                                   (local.get $1)
                                   (array.get $type19
                                    (struct.get $type18 2
                                     (local.get $0)
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $2)
                                    (i64.const 16)
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (call $foreign11
                                     (local.get $1)
                                     (array.get $type19
                                      (struct.get $type18 2
                                       (local.get $0)
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $2)
                                      (i64.const 17)
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type18 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call $foreign11
                                       (local.get $1)
                                       (array.get $type19
                                        (struct.get $type18 2
                                         (local.get $0)
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $2)
                                        (i64.const 18)
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (call $foreign11
                                         (local.get $1)
                                         (array.get $type19
                                          (struct.get $type18 2
                                           (local.get $0)
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $2)
                                          (i64.const 19)
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $0)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $foreign11
                                           (local.get $1)
                                           (array.get $type19
                                            (call $string-block
                                             (local.get $0)
                                             (i32.const 19)
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (return_call $function105
                                           (local.get $0)
                                           (local.get $1)
                                           (local.get $2)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function105 (type $75) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign11
     (local.get $1)
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function105
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function111 (type $74) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign17
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function111
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function120 (type $74) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign22
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function120
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function121 (type $call120) (param $0 i32) (param $1 i32) (result (ref $type121))
  (local $2 i64)
  (if (result (ref $type121))
   (local.get $1)
   (then
    (if (result (ref $type121))
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (struct.new $type123
       (i32.const 1)
       (struct.new $type25
        (i32.const 0)
        (call $foreign19
         (local.get $0)
         (i32.const 0)
        )
       )
      )
     )
     (else
      (if (result (ref $type121))
       (i32.eq
        (local.get $1)
        (i32.const 2)
       )
       (then
        (struct.new $type123
         (i32.const 1)
         (struct.new $type26
          (i32.const 1)
          (call $foreign18
           (local.get $0)
           (i32.const 0)
          )
         )
        )
       )
       (else
        (if (result (ref $type121))
         (i32.eq
          (local.get $1)
          (i32.const 3)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global367)
           )
          )
          (struct.new $type123
           (i32.const 1)
           (struct.new $type27
            (i32.const 2)
            (if (result (ref $type28))
             (i32.eq
              (call $foreign20
               (local.get $0)
               (i32.const 0)
              )
              (i32.const 1)
             )
             (then
              (struct.new $type29
               (call $foreign19
                (local.get $0)
                (i32.const 0)
               )
              )
             )
             (else
              (struct.new $type30
               (call $foreign18
                (local.get $0)
                (i32.const 0)
               )
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global367)
              )
             )
             (if (result (ref $type28))
              (i32.eq
               (call $foreign20
                (local.get $0)
                (i32.const 1)
               )
               (i32.const 1)
              )
              (then
               (struct.new $type29
                (call $foreign19
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
              (else
               (struct.new $type30
                (call $foreign18
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
             )
            )
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global370)
           )
          )
          (struct.new $type124
           (i32.const 2)
           (call $function120
            (local.get $0)
            (local.tee $2
             (i64.extend_i32_s
              (call $foreign21
               (local.get $0)
              )
             )
            )
            (block (result (ref $type18))
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (if
              (i64.gt_u
               (local.get $2)
               (i64.const 4294967294)
              )
              (then
               (unreachable)
              )
             )
             (call $string-new
              (i32.wrap_i64
               (local.get $2)
              )
             )
            )
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (global.get $empty122)
   )
  )
 )
 (func $function150 (type $call144) (param $0 (ref $type140)) (result (ref $type13))
  (local $1 (ref $type18))
  (local $scratch (ref $type18))
  (if (result (ref $type13))
   (i32.eq
    (struct.get $type140 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (struct.get $type142 1
     (ref.cast (ref $type142)
      (local.get $0)
     )
    )
   )
   (else
    (if
     (struct.get $type140 0
      (local.get $0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global90)
       )
      )
      (call $foreign12
       (call $function104
        (block (result (ref $type18))
         (local.set $scratch
          (call $function35
           (struct.new $type48
            (global.get $string1)
            (struct.new $type48
             (struct.get $type143 1
              (ref.cast (ref $type143)
               (local.get $0)
              )
             )
             (ref.null none)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global323)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global317)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global323)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global317)
       )
      )
      (call $foreign12
       (call $function104
        (global.get $string2)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function152 (type $call160) (param $0 (ref $type58)) (result (ref $type161))
  (local $1 i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type68))
  (local $8 (ref $type121))
  (local $9 (ref $type152))
  (local $10 (ref $type140))
  (local $11 (ref $type179))
  (local $12 (ref $type161))
  (drop
   (ref.as_non_null
    (global.get $global519)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $2
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global521)
   )
  )
  (block $block
   (return
    (if (result (ref $type163))
     (i64.lt_s
      (local.tee $1
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $7
          (if (result (ref $type68))
           (i32.eq
            (local.get $2)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $1
               (i64.extend_i32_s
                (local.get $2)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $1)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $1)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $7)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (global.get $empty163)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global525)
       )
      )
      (br_if $block
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $1)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $1)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (i32.eq
          (call $foreign25
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 1)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global527)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 59)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global530)
         )
        )
        (drop
         (call $function157
          (local.get $0)
         )
        )
        (br $block)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready535)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global535)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global527)
         )
        )
        (return
         (if (result (ref $type161))
          (i64.eq
           (local.get $1)
           (i64.const 40)
          )
          (then
           (struct.new $type166
            (i32.const 4)
            (i64.const 0)
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global527)
            )
           )
           (if (result (ref $type161))
            (i64.eq
             (local.get $1)
             (i64.const 41)
            )
            (then
             (global.get $empty164)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global527)
              )
             )
             (if (result (ref $type161))
              (i64.eq
               (local.get $1)
               (i64.const 39)
              )
              (then
               (struct.new $type167
                (i32.const 5)
                (global.get $string7)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global527)
                )
               )
               (if (result (ref $type161))
                (i64.eq
                 (local.get $1)
                 (i64.const 96)
                )
                (then
                 (struct.new $type167
                  (i32.const 5)
                  (global.get $string6)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global527)
                  )
                 )
                 (if (result (ref $type161))
                  (i64.eq
                   (local.get $1)
                   (i64.const 44)
                  )
                  (then
                   (drop
                    (ref.as_non_null
                     (global.get $global538)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global541)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global137)
                    )
                   )
                   (local.set $2
                    (call $foreign8
                     (struct.get $type56 0
                      (struct.get $type58 0
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global133)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global521)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global527)
                    )
                   )
                   (struct.new $type167
                    (i32.const 5)
                    (select (result (ref $type18))
                     (global.get $string5)
                     (global.get $string4)
                     (if (result i32)
                      (i64.eq
                       (if (result i64)
                        (ref.test (ref $type69)
                         (local.tee $7
                          (if (result (ref $type68))
                           (i32.eq
                            (local.get $2)
                            (i32.const -1)
                           )
                           (then
                            (global.get $empty69)
                           )
                           (else
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (i64.extend_i32_s
                                (local.get $2)
                               )
                              )
                              (i64.const 1114111)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (if
                             (i32.and
                              (i64.le_u
                               (local.get $1)
                               (i64.const 57343)
                              )
                              (i64.ge_u
                               (local.get $1)
                               (i64.const 55296)
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (struct.new $type70
                             (i32.wrap_i64
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i64.const -1)
                        )
                        (else
                         (i64.extend_i32_u
                          (struct.get $type70 0
                           (ref.cast (ref $type70)
                            (local.get $7)
                           )
                          )
                         )
                        )
                       )
                       (i64.const 64)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global135)
                        )
                       )
                       (local.set $2
                        (call $foreign7
                         (struct.get $type56 0
                          (struct.get $type58 0
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global133)
                        )
                       )
                       (drop
                        (if (result (ref $type68))
                         (i32.eq
                          (local.get $2)
                          (i32.const -1)
                         )
                         (then
                          (global.get $empty69)
                         )
                         (else
                          (if
                           (i64.gt_u
                            (local.tee $1
                             (i64.extend_i32_s
                              (local.get $2)
                             )
                            )
                            (i64.const 1114111)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.and
                            (i64.le_u
                             (local.get $1)
                             (i64.const 57343)
                            )
                            (i64.ge_u
                             (local.get $1)
                             (i64.const 55296)
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.new $type70
                           (i32.wrap_i64
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (i32.const 1)
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global527)
                    )
                   )
                   (if (result (ref $type168))
                    (i64.eq
                     (local.get $1)
                     (i64.const 34)
                    )
                    (then
                     (if
                      (i32.eqz
                       (global.get $ready543)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global543)
                      )
                     )
                     (return_call $function161
                      (local.get $0)
                      (i32.const 34)
                      (i32.const 0)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global527)
                      )
                     )
                     (if (result (ref $type168))
                      (i64.eq
                       (local.get $1)
                       (i64.const 124)
                      )
                      (then
                       (if
                        (i32.eqz
                         (global.get $ready543)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global543)
                        )
                       )
                       (return_call $function161
                        (local.get $0)
                        (i32.const 124)
                        (i32.const 1)
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global527)
                        )
                       )
                       (if (result (ref $type168))
                        (i64.eq
                         (local.get $1)
                         (i64.const 35)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready616)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global616)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global519)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global135)
                          )
                         )
                         (local.set $2
                          (call $foreign7
                           (struct.get $type56 0
                            (struct.get $type58 0
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global133)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global521)
                          )
                         )
                         (return
                          (if (result (ref $type161))
                           (i64.lt_s
                            (local.tee $1
                             (if (result i64)
                              (ref.test (ref $type69)
                               (local.tee $7
                                (if (result (ref $type68))
                                 (i32.eq
                                  (local.get $2)
                                  (i32.const -1)
                                 )
                                 (then
                                  (global.get $empty69)
                                 )
                                 (else
                                  (if
                                   (i64.gt_u
                                    (local.tee $1
                                     (i64.extend_i32_s
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 1114111)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.and
                                    (i64.le_u
                                     (local.get $1)
                                     (i64.const 57343)
                                    )
                                    (i64.ge_u
                                     (local.get $1)
                                     (i64.const 55296)
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.new $type70
                                   (i32.wrap_i64
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i64.const -1)
                              )
                              (else
                               (i64.extend_i32_u
                                (struct.get $type70 0
                                 (ref.cast (ref $type70)
                                  (local.get $7)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (struct.new $type168
                             (i32.const 6)
                             (global.get $string18)
                            )
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global527)
                             )
                            )
                            (if (result (ref $type161))
                             (i64.eq
                              (local.get $1)
                              (i64.const 40)
                             )
                             (then
                              (struct.new $type166
                               (i32.const 4)
                               (i64.const 1)
                              )
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global527)
                               )
                              )
                              (if (result (ref $type161))
                               (i64.eq
                                (local.get $1)
                                (i64.const 59)
                               )
                               (then
                                (drop
                                 (ref.as_non_null
                                  (global.get $global619)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global514)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready516)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global516)
                                 )
                                )
                                (local.set $12
                                 (call $function152
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready691)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global691)
                                 )
                                )
                                (if (result (ref $type168))
                                 (i32.eq
                                  (struct.get $type140 0
                                   (local.tee $10
                                    (call $function194
                                     (local.get $0)
                                     (local.get $12)
                                    )
                                   )
                                  )
                                  (i32.const 1)
                                 )
                                 (then
                                  (drop
                                   (ref.cast (ref $type142)
                                    (local.get $10)
                                   )
                                  )
                                  (br $block)
                                 )
                                 (else
                                  (if (result (ref $type168))
                                   (struct.get $type140 0
                                    (local.get $10)
                                   )
                                   (then
                                    (struct.new $type168
                                     (i32.const 6)
                                     (struct.get $type143 1
                                      (ref.cast (ref $type143)
                                       (local.get $10)
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (struct.new $type168
                                     (i32.const 6)
                                     (global.get $string19)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global527)
                                 )
                                )
                                (if (result (ref $type161))
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 124)
                                 )
                                 (then
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global624)
                                   )
                                  )
                                  (if (result (ref $type168))
                                   (call $function180
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global516)
                                     )
                                    )
                                    (return_call $function152
                                     (local.get $0)
                                    )
                                   )
                                   (else
                                    (struct.new $type168
                                     (i32.const 6)
                                     (global.get $string17)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global527)
                                   )
                                  )
                                  (if (result (ref $type161))
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 92)
                                   )
                                   (then
                                    (if
                                     (i32.eqz
                                      (global.get $ready629)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global629)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global519)
                                     )
                                    )
                                    (if (result (ref $type161))
                                     (i64.lt_s
                                      (local.tee $1
                                       (call $function153
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                     (then
                                      (struct.new $type168
                                       (i32.const 6)
                                       (global.get $string20)
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global632)
                                       )
                                      )
                                      (if (result (ref $type162))
                                       (call $function182
                                        (local.get $1)
                                       )
                                       (then
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (struct.new $type162
                                         (i32.const 0)
                                         (struct.new $type16
                                          (i32.const 2)
                                          (i32.wrap_i64
                                           (local.get $1)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global647)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global551)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global61)
                                         )
                                        )
                                        (local.set $9
                                         (struct.new $type152
                                          (struct.new $type153
                                           (call $string-new
                                            (i32.const 32)
                                           )
                                          )
                                          (struct.new_default $type154)
                                         )
                                        )
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global600)
                                         )
                                        )
                                        (call $function175
                                         (local.get $9)
                                         (i32.wrap_i64
                                          (local.get $1)
                                         )
                                        )
                                        (local.set $4
                                         (call $function184
                                          (local.get $0)
                                          (local.get $9)
                                          (i32.const 0)
                                          (i32.const 1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready652)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global652)
                                         )
                                        )
                                        (return
                                         (if (result (ref $type161))
                                          (i64.eq
                                           (local.tee $1
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $4)
                                             )
                                            )
                                           )
                                           (i64.const 1)
                                          )
                                          (then
                                           (if
                                            (i64.eqz
                                             (local.get $1)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (struct.new $type162
                                            (i32.const 0)
                                            (struct.new $type16
                                             (i32.const 2)
                                             (array.get $type19
                                              (struct.get $type18 2
                                               (local.get $4)
                                              )
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global655)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global88)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global81)
                                            )
                                           )
                                           (local.set $4
                                            (call $function187
                                             (if (result (ref $type18))
                                              (i64.lt_s
                                               (local.tee $1
                                                (i64.extend_i32_u
                                                 (struct.get $type18 1
                                                  (local.get $4)
                                                 )
                                                )
                                               )
                                               (local.get $1)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global61)
                                                )
                                               )
                                               (if
                                                (i64.gt_u
                                                 (local.get $1)
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (call $string-copy
                                                (local.tee $5
                                                 (call $string-new
                                                  (i32.wrap_i64
                                                   (local.get $1)
                                                  )
                                                 )
                                                )
                                                (i64.const 0)
                                                (local.get $4)
                                                (local.get $1)
                                               )
                                               (local.get $5)
                                              )
                                             )
                                             (i32.const 0)
                                             (i32.const 1)
                                             (i64.const 0)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready661)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global661)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global103)
                                            )
                                           )
                                           (if (result (ref $type161))
                                            (struct.get $type179 0
                                             (local.tee $11
                                              (if (result (ref $type179))
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 5)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string30)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                               (then
                                                (struct.new $type180
                                                 (i32.const 0)
                                                 (i32.const 7)
                                                )
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global103)
                                                 )
                                                )
                                                (if (result (ref $type179))
                                                 (if (result i32)
                                                  (i64.eq
                                                   (i64.extend_i32_u
                                                    (struct.get $type18 1
                                                     (local.get $4)
                                                    )
                                                   )
                                                   (i64.const 9)
                                                  )
                                                  (then
                                                   (call $function40
                                                    (local.get $4)
                                                    (global.get $string29)
                                                    (i32.const 0)
                                                    (i32.const 1)
                                                    (i64.const 0)
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                 (then
                                                  (struct.new $type180
                                                   (i32.const 0)
                                                   (i32.const 8)
                                                  )
                                                 )
                                                 (else
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global103)
                                                   )
                                                  )
                                                  (if (result (ref $type179))
                                                   (if (result i32)
                                                    (i64.eq
                                                     (i64.extend_i32_u
                                                      (struct.get $type18 1
                                                       (local.get $4)
                                                      )
                                                     )
                                                     (i64.const 6)
                                                    )
                                                    (then
                                                     (call $function40
                                                      (local.get $4)
                                                      (global.get $string28)
                                                      (i32.const 0)
                                                      (i32.const 1)
                                                      (i64.const 0)
                                                     )
                                                    )
                                                    (else
                                                     (i32.const 0)
                                                    )
                                                   )
                                                   (then
                                                    (struct.new $type180
                                                     (i32.const 0)
                                                     (i32.const 127)
                                                    )
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global103)
                                                     )
                                                    )
                                                    (if (result (ref $type179))
                                                     (if (result i32)
                                                      (i64.eq
                                                       (i64.extend_i32_u
                                                        (struct.get $type18 1
                                                         (local.get $4)
                                                        )
                                                       )
                                                       (i64.const 6)
                                                      )
                                                      (then
                                                       (call $function40
                                                        (local.get $4)
                                                        (global.get $string27)
                                                        (i32.const 0)
                                                        (i32.const 1)
                                                        (i64.const 0)
                                                       )
                                                      )
                                                      (else
                                                       (i32.const 0)
                                                      )
                                                     )
                                                     (then
                                                      (struct.new $type180
                                                       (i32.const 0)
                                                       (i32.const 27)
                                                      )
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global103)
                                                       )
                                                      )
                                                      (if (result (ref $type179))
                                                       (if (result i32)
                                                        (i64.eq
                                                         (i64.extend_i32_u
                                                          (struct.get $type18 1
                                                           (local.get $4)
                                                          )
                                                         )
                                                         (i64.const 7)
                                                        )
                                                        (then
                                                         (call $function40
                                                          (local.get $4)
                                                          (global.get $string26)
                                                          (i32.const 0)
                                                          (i32.const 1)
                                                          (i64.const 0)
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                       (then
                                                        (struct.new $type180
                                                         (i32.const 0)
                                                         (i32.const 10)
                                                        )
                                                       )
                                                       (else
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global103)
                                                         )
                                                        )
                                                        (if (result (ref $type179))
                                                         (if (result i32)
                                                          (i64.eq
                                                           (i64.extend_i32_u
                                                            (struct.get $type18 1
                                                             (local.get $4)
                                                            )
                                                           )
                                                           (i64.const 4)
                                                          )
                                                          (then
                                                           (call $function40
                                                            (local.get $4)
                                                            (global.get $string25)
                                                            (i32.const 0)
                                                            (i32.const 1)
                                                            (i64.const 0)
                                                           )
                                                          )
                                                          (else
                                                           (i32.const 0)
                                                          )
                                                         )
                                                         (then
                                                          (struct.new_default $type180)
                                                         )
                                                         (else
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global103)
                                                           )
                                                          )
                                                          (if (result (ref $type179))
                                                           (if (result i32)
                                                            (i64.eq
                                                             (i64.extend_i32_u
                                                              (struct.get $type18 1
                                                               (local.get $4)
                                                              )
                                                             )
                                                             (i64.const 6)
                                                            )
                                                            (then
                                                             (call $function40
                                                              (local.get $4)
                                                              (global.get $string24)
                                                              (i32.const 0)
                                                              (i32.const 1)
                                                              (i64.const 0)
                                                             )
                                                            )
                                                            (else
                                                             (i32.const 0)
                                                            )
                                                           )
                                                           (then
                                                            (struct.new $type180
                                                             (i32.const 0)
                                                             (i32.const 13)
                                                            )
                                                           )
                                                           (else
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global103)
                                                             )
                                                            )
                                                            (if (result (ref $type179))
                                                             (if (result i32)
                                                              (i64.eq
                                                               (i64.extend_i32_u
                                                                (struct.get $type18 1
                                                                 (local.get $4)
                                                                )
                                                               )
                                                               (i64.const 5)
                                                              )
                                                              (then
                                                               (call $function40
                                                                (local.get $4)
                                                                (global.get $string23)
                                                                (i32.const 0)
                                                                (i32.const 1)
                                                                (i64.const 0)
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                             (then
                                                              (struct.new $type180
                                                               (i32.const 0)
                                                               (i32.const 32)
                                                              )
                                                             )
                                                             (else
                                                              (drop
                                                               (ref.as_non_null
                                                                (global.get $global103)
                                                               )
                                                              )
                                                              (if (result (ref $type179))
                                                               (if (result i32)
                                                                (i64.eq
                                                                 (i64.extend_i32_u
                                                                  (struct.get $type18 1
                                                                   (local.get $4)
                                                                  )
                                                                 )
                                                                 (i64.const 3)
                                                                )
                                                                (then
                                                                 (call $function40
                                                                  (local.get $4)
                                                                  (global.get $string22)
                                                                  (i32.const 0)
                                                                  (i32.const 1)
                                                                  (i64.const 0)
                                                                 )
                                                                )
                                                                (else
                                                                 (i32.const 0)
                                                                )
                                                               )
                                                               (then
                                                                (struct.new $type180
                                                                 (i32.const 0)
                                                                 (i32.const 9)
                                                                )
                                                               )
                                                               (else
                                                                (if
                                                                 (i64.eqz
                                                                  (i64.extend_i32_u
                                                                   (struct.get $type18 1
                                                                    (local.get $4)
                                                                   )
                                                                  )
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (if (result (ref $type179))
                                                                 (i32.eq
                                                                  (array.get $type19
                                                                   (struct.get $type18 2
                                                                    (local.get $4)
                                                                   )
                                                                   (i32.const 0)
                                                                  )
                                                                  (i32.const 120)
                                                                 )
                                                                 (then
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global663)
                                                                   )
                                                                  )
                                                                  (call $function190
                                                                   (local.get $4)
                                                                   (i32.const 0)
                                                                   (i32.const 1)
                                                                   (i64.const 1)
                                                                   (i64.const 0)
                                                                  )
                                                                 )
                                                                 (else
                                                                  (struct.new $type182
                                                                   (i32.const 2)
                                                                   (global.get $string21)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (if (result (ref $type168))
                                              (i32.eq
                                               (struct.get $type179 0
                                                (local.get $11)
                                               )
                                               (i32.const 2)
                                              )
                                              (then
                                               (struct.new $type168
                                                (i32.const 6)
                                                (struct.get $type182 1
                                                 (ref.cast (ref $type182)
                                                  (local.get $11)
                                                 )
                                                )
                                               )
                                              )
                                              (else
                                               (unreachable)
                                              )
                                             )
                                            )
                                            (else
                                             (struct.new $type162
                                              (i32.const 0)
                                              (struct.new $type16
                                               (i32.const 2)
                                               (struct.get $type180 1
                                                (ref.cast (ref $type180)
                                                 (local.get $11)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global527)
                                     )
                                    )
                                    (if (result (ref $type161))
                                     (if (result i32)
                                      (local.tee $2
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 117)
                                       )
                                      )
                                      (then
                                       (local.get $2)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global527)
                                        )
                                       )
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 85)
                                       )
                                      )
                                     )
                                     (then
                                      (if
                                       (i32.eqz
                                        (global.get $ready673)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global673)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global538)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global541)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global137)
                                       )
                                      )
                                      (local.set $2
                                       (call $foreign8
                                        (struct.get $type56 0
                                         (struct.get $type58 0
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global133)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global521)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global527)
                                       )
                                      )
                                      (if (result (ref $type161))
                                       (if (result i32)
                                        (if (result i32)
                                         (i64.eq
                                          (if (result i64)
                                           (ref.test (ref $type69)
                                            (local.tee $7
                                             (if (result (ref $type68))
                                              (i32.eq
                                               (local.get $2)
                                               (i32.const -1)
                                              )
                                              (then
                                               (global.get $empty69)
                                              )
                                              (else
                                               (if
                                                (i64.gt_u
                                                 (local.tee $1
                                                  (i64.extend_i32_s
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (i64.const 1114111)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (if
                                                (i32.and
                                                 (i64.le_u
                                                  (local.get $1)
                                                  (i64.const 57343)
                                                 )
                                                 (i64.ge_u
                                                  (local.get $1)
                                                  (i64.const 55296)
                                                 )
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (struct.new $type70
                                                (i32.wrap_i64
                                                 (local.get $1)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (i64.const -1)
                                           )
                                           (else
                                            (i64.extend_i32_u
                                             (struct.get $type70 0
                                              (ref.cast (ref $type70)
                                               (local.get $7)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i64.const 56)
                                         )
                                         (then
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global135)
                                           )
                                          )
                                          (local.set $2
                                           (call $foreign7
                                            (struct.get $type56 0
                                             (struct.get $type58 0
                                              (local.get $0)
                                             )
                                            )
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global133)
                                           )
                                          )
                                          (drop
                                           (if (result (ref $type68))
                                            (i32.eq
                                             (local.get $2)
                                             (i32.const -1)
                                            )
                                            (then
                                             (global.get $empty69)
                                            )
                                            (else
                                             (if
                                              (i64.gt_u
                                               (local.tee $1
                                                (i64.extend_i32_s
                                                 (local.get $2)
                                                )
                                               )
                                               (i64.const 1114111)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (if
                                              (i32.and
                                               (i64.le_u
                                                (local.get $1)
                                                (i64.const 57343)
                                               )
                                               (i64.ge_u
                                                (local.get $1)
                                                (i64.const 55296)
                                               )
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (struct.new $type70
                                              (i32.wrap_i64
                                               (local.get $1)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i32.const 1)
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                        (then
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global538)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global541)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global137)
                                          )
                                         )
                                         (local.set $2
                                          (call $foreign8
                                           (struct.get $type56 0
                                            (struct.get $type58 0
                                             (local.get $0)
                                            )
                                           )
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global133)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global521)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global527)
                                          )
                                         )
                                         (if (result i32)
                                          (i64.eq
                                           (if (result i64)
                                            (ref.test (ref $type69)
                                             (local.tee $7
                                              (if (result (ref $type68))
                                               (i32.eq
                                                (local.get $2)
                                                (i32.const -1)
                                               )
                                               (then
                                                (global.get $empty69)
                                               )
                                               (else
                                                (if
                                                 (i64.gt_u
                                                  (local.tee $1
                                                   (i64.extend_i32_s
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (i64.const 1114111)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (if
                                                 (i32.and
                                                  (i64.le_u
                                                   (local.get $1)
                                                   (i64.const 57343)
                                                  )
                                                  (i64.ge_u
                                                   (local.get $1)
                                                   (i64.const 55296)
                                                  )
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (struct.new $type70
                                                 (i32.wrap_i64
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (i64.const -1)
                                            )
                                            (else
                                             (i64.extend_i32_u
                                              (struct.get $type70 0
                                               (ref.cast (ref $type70)
                                                (local.get $7)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i64.const 40)
                                          )
                                          (then
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global135)
                                            )
                                           )
                                           (local.set $2
                                            (call $foreign7
                                             (struct.get $type56 0
                                              (struct.get $type58 0
                                               (local.get $0)
                                              )
                                             )
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global133)
                                            )
                                           )
                                           (drop
                                            (if (result (ref $type68))
                                             (i32.eq
                                              (local.get $2)
                                              (i32.const -1)
                                             )
                                             (then
                                              (global.get $empty69)
                                             )
                                             (else
                                              (if
                                               (i64.gt_u
                                                (local.tee $1
                                                 (i64.extend_i32_s
                                                  (local.get $2)
                                                 )
                                                )
                                                (i64.const 1114111)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (if
                                               (i32.and
                                                (i64.le_u
                                                 (local.get $1)
                                                 (i64.const 57343)
                                                )
                                                (i64.ge_u
                                                 (local.get $1)
                                                 (i64.const 55296)
                                                )
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (struct.new $type70
                                               (i32.wrap_i64
                                                (local.get $1)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i32.const 1)
                                          )
                                          (else
                                           (i32.const 0)
                                          )
                                         )
                                        )
                                        (else
                                         (i32.const 0)
                                        )
                                       )
                                       (then
                                        (struct.new $type166
                                         (i32.const 4)
                                         (i64.const 2)
                                        )
                                       )
                                       (else
                                        (struct.new $type168
                                         (i32.const 6)
                                         (global.get $string32)
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global527)
                                       )
                                      )
                                      (if (result (ref $type161))
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 33)
                                       )
                                       (then
                                        (struct.new $type168
                                         (i32.const 6)
                                         (global.get $string16)
                                        )
                                       )
                                       (else
                                        (if (result (ref $type161))
                                         (i32.and
                                          (i64.le_s
                                           (local.get $1)
                                           (i64.const 57)
                                          )
                                          (i64.ge_s
                                           (local.get $1)
                                           (i64.const 48)
                                          )
                                         )
                                         (then
                                          (struct.new $type168
                                           (i32.const 6)
                                           (global.get $string15)
                                          )
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global647)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global551)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global61)
                                           )
                                          )
                                          (local.set $9
                                           (struct.new $type152
                                            (struct.new $type153
                                             (call $string-new
                                              (i32.const 32)
                                             )
                                            )
                                            (struct.new_default $type154)
                                           )
                                          )
                                          (if
                                           (i64.gt_u
                                            (local.get $1)
                                            (i64.const 1114111)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (if
                                           (i32.and
                                            (i64.le_u
                                             (local.get $1)
                                             (i64.const 57343)
                                            )
                                            (i64.ge_u
                                             (local.get $1)
                                             (i64.const 55296)
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global600)
                                           )
                                          )
                                          (call $function175
                                           (local.get $9)
                                           (i32.wrap_i64
                                            (local.get $1)
                                           )
                                          )
                                          (local.set $4
                                           (call $function184
                                            (local.get $0)
                                            (local.get $9)
                                            (i32.const 0)
                                            (i32.const 1)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global90)
                                           )
                                          )
                                          (local.set $5
                                           (call $function35
                                            (struct.new $type48
                                             (global.get $string14)
                                             (struct.new $type48
                                              (local.get $4)
                                              (ref.null none)
                                             )
                                            )
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready675)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global675)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global655)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global88)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global81)
                                           )
                                          )
                                          (local.set $4
                                           (call $function187
                                            (if (result (ref $type18))
                                             (i64.lt_s
                                              (local.tee $1
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $5)
                                                )
                                               )
                                              )
                                              (local.get $1)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global61)
                                               )
                                              )
                                              (if
                                               (i64.gt_u
                                                (local.get $1)
                                                (i64.const 4294967294)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (call $string-copy
                                               (local.tee $6
                                                (call $string-new
                                                 (i32.wrap_i64
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                               (i64.const 0)
                                               (local.get $5)
                                               (local.get $1)
                                              )
                                              (local.get $6)
                                             )
                                            )
                                            (i32.const 0)
                                            (i32.const 1)
                                            (i64.const 0)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global103)
                                           )
                                          )
                                          (if (result (ref $type161))
                                           (if (result i32)
                                            (local.tee $2
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $4)
                                                )
                                               )
                                               (i64.const 2)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $4)
                                                (global.get $string36)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                            (then
                                             (local.get $2)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global103)
                                              )
                                             )
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $4)
                                                )
                                               )
                                               (i64.const 5)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $4)
                                                (global.get $string37)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (struct.new $type162
                                             (i32.const 0)
                                             (struct.new $type15
                                              (i32.const 1)
                                              (i32.const 1)
                                             )
                                            )
                                           )
                                           (else
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global103)
                                             )
                                            )
                                            (if (result (ref $type161))
                                             (if (result i32)
                                              (local.tee $2
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 2)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string34)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                              (then
                                               (local.get $2)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global103)
                                                )
                                               )
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 6)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string35)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                             )
                                             (then
                                              (struct.new $type162
                                               (i32.const 0)
                                               (struct.new $type15
                                                (i32.const 1)
                                                (i32.const 0)
                                               )
                                              )
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global379)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global317)
                                               )
                                              )
                                              (local.set $3
                                               (call $foreign23
                                                (local.tee $2
                                                 (call $function104
                                                  (local.get $5)
                                                 )
                                                )
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global376)
                                               )
                                              )
                                              (local.set $8
                                               (call $function121
                                                (local.get $2)
                                                (local.get $3)
                                               )
                                              )
                                              (call $foreign14
                                               (local.get $2)
                                              )
                                              (if (result (ref $type161))
                                               (i32.eq
                                                (struct.get $type121 0
                                                 (local.get $8)
                                                )
                                                (i32.const 1)
                                               )
                                               (then
                                                (struct.new $type162
                                                 (i32.const 0)
                                                 (struct.new $type23
                                                  (i32.const 5)
                                                  (struct.get $type123 1
                                                   (ref.cast (ref $type123)
                                                    (local.get $8)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (else
                                                (if (result (ref $type168))
                                                 (i32.eq
                                                  (struct.get $type121 0
                                                   (local.get $8)
                                                  )
                                                  (i32.const 2)
                                                 )
                                                 (then
                                                  (struct.new $type168
                                                   (i32.const 6)
                                                   (struct.get $type124 1
                                                    (ref.cast (ref $type124)
                                                     (local.get $8)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (struct.new $type168
                                                   (i32.const 6)
                                                   (global.get $string33)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global527)
                          )
                         )
                         (if (result (ref $type168))
                          (if (result i32)
                           (local.tee $2
                            (i64.eq
                             (local.get $1)
                             (i64.const 91)
                            )
                           )
                           (then
                            (local.get $2)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global527)
                             )
                            )
                            (if (result i32)
                             (local.tee $2
                              (i64.eq
                               (local.get $1)
                               (i64.const 93)
                              )
                             )
                             (then
                              (local.get $2)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global527)
                               )
                              )
                              (if (result i32)
                               (local.tee $2
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 123)
                                )
                               )
                               (then
                                (local.get $2)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global527)
                                 )
                                )
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 125)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (struct.new $type168
                            (i32.const 6)
                            (global.get $string3)
                           )
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global647)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global551)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global61)
                            )
                           )
                           (local.set $9
                            (struct.new $type152
                             (struct.new $type153
                              (call $string-new
                               (i32.const 32)
                              )
                             )
                             (struct.new_default $type154)
                            )
                           )
                           (if
                            (i64.gt_u
                             (local.get $1)
                             (i64.const 1114111)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if
                            (i32.and
                             (i64.le_u
                              (local.get $1)
                              (i64.const 57343)
                             )
                             (i64.ge_u
                              (local.get $1)
                              (i64.const 55296)
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global600)
                            )
                           )
                           (call $function175
                            (local.get $9)
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                           (local.set $4
                            (call $function184
                             (local.get $0)
                             (local.get $9)
                             (i32.const 0)
                             (i32.const 1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready686)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global686)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global103)
                            )
                           )
                           (return
                            (if (result (ref $type161))
                             (if (result i32)
                              (i64.eq
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (local.get $4)
                                )
                               )
                               (i64.const 1)
                              )
                              (then
                               (call $function40
                                (local.get $4)
                                (global.get $string39)
                                (i32.const 0)
                                (i32.const 1)
                                (i64.const 0)
                               )
                              )
                              (else
                               (i32.const 0)
                              )
                             )
                             (then
                              (global.get $empty165)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global379)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global317)
                               )
                              )
                              (local.set $3
                               (call $foreign23
                                (local.tee $2
                                 (call $function104
                                  (local.get $4)
                                 )
                                )
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global376)
                               )
                              )
                              (local.set $8
                               (call $function121
                                (local.get $2)
                                (local.get $3)
                               )
                              )
                              (call $foreign14
                               (local.get $2)
                              )
                              (if (result (ref $type161))
                               (i32.eq
                                (struct.get $type121 0
                                 (local.get $8)
                                )
                                (i32.const 1)
                               )
                               (then
                                (struct.new $type162
                                 (i32.const 0)
                                 (struct.new $type23
                                  (i32.const 5)
                                  (struct.get $type123 1
                                   (ref.cast (ref $type123)
                                    (local.get $8)
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (if (result (ref $type161))
                                 (i32.eq
                                  (struct.get $type121 0
                                   (local.get $8)
                                  )
                                  (i32.const 2)
                                 )
                                 (then
                                  (struct.new $type168
                                   (i32.const 6)
                                   (struct.get $type124 1
                                    (ref.cast (ref $type124)
                                     (local.get $8)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global325)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global317)
                                   )
                                  )
                                  (if (result (ref $type161))
                                   (i32.eq
                                    (call $foreign13
                                     (local.tee $2
                                      (call $function104
                                       (local.get $4)
                                      )
                                     )
                                    )
                                    (block (result i32)
                                     (call $foreign14
                                      (local.get $2)
                                     )
                                     (i32.const 1)
                                    )
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global329)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global317)
                                     )
                                    )
                                    (struct.new $type162
                                     (i32.const 0)
                                     (struct.new $type21
                                      (i32.const 4)
                                      (struct.new $type22
                                       (call $foreign15
                                        (call $function104
                                         (local.get $4)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (struct.new $type168
                                     (i32.const 6)
                                     (global.get $string38)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (unreachable)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready516)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global516)
   )
  )
  (return_call $function152
   (local.get $0)
  )
 )
 (func $function153 (type $call147) (param $0 (ref $type58)) (result i64)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $2
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global521)
   )
  )
  (if (result i64)
   (ref.test (ref $type69)
    (local.tee $3
     (if (result (ref $type68))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty69)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type70
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (i64.const -1)
   )
   (else
    (i64.extend_i32_u
     (struct.get $type70 0
      (ref.cast (ref $type70)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function157 (type $call60) (param $0 (ref $type58)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local $3 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global519)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $1
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global521)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $1
     (i64.lt_s
      (local.tee $2
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $3
          (if (result (ref $type68))
           (i32.eq
            (local.get $1)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $1)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
    )
    (then
     (local.get $1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global527)
      )
     )
     (if (result i32)
      (local.tee $1
       (i64.eq
        (local.get $2)
        (i64.const 10)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global527)
        )
       )
       (i64.eq
        (local.get $2)
        (i64.const 13)
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready530)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global530)
     )
    )
    (return_call $function157
     (local.get $0)
    )
   )
  )
 )
 (func $function161 (type $call171) (param $0 (ref $type58)) (param $1 i32) (param $2 i32) (result (ref $type161))
  (local $3 (ref $type173))
  (local $4 (ref $type18))
  (local $5 (ref $type152))
  (if
   (i32.eqz
    (global.get $ready548)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global548)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global551)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $5
   (struct.new $type152
    (struct.new $type153
     (call $string-new
      (i32.const 32)
     )
    )
    (struct.new_default $type154)
   )
  )
  (if
   (i32.eqz
    (global.get $ready552)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global552)
   )
  )
  (if (result (ref $type161))
   (ref.test (ref $type174)
    (local.tee $3
     (call $function164
      (local.get $0)
      (local.get $1)
      (local.get $5)
     )
    )
   )
   (then
    (local.set $4
     (struct.get $type174 0
      (ref.cast (ref $type174)
       (local.get $3)
      )
     )
    )
    (struct.new $type162
     (i32.const 0)
     (if (result (ref $type13))
      (local.get $2)
      (then
       (drop
        (ref.as_non_null
         (global.get $global329)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global317)
        )
       )
       (struct.new $type21
        (i32.const 4)
        (struct.new $type22
         (call $foreign15
          (call $function104
           (local.get $4)
          )
         )
        )
       )
      )
      (else
       (struct.new $type17
        (i32.const 3)
        (local.get $4)
       )
      )
     )
    )
   )
   (else
    (struct.new $type168
     (i32.const 6)
     (struct.get $type175 0
      (ref.cast (ref $type175)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function164 (type $call176) (param $0 (ref $type58)) (param $1 i32) (param $2 (ref $type152)) (result (ref $type173))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type68))
  (local $6 (ref $type179))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global519)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $4
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global521)
   )
  )
  (block $block
   (return
    (if (result (ref $type173))
     (i64.lt_s
      (local.tee $3
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $5
          (if (result (ref $type68))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $3
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $3)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $3)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $5)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (struct.new $type175
       (global.get $string8)
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global527)
       )
      )
      (if (result (ref $type173))
       (i64.eq
        (i64.extend_i32_u
         (local.get $1)
        )
        (local.get $3)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global557)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global81)
         )
        )
        (local.set $7
         (struct.get $type153 0
          (struct.get $type152 0
           (local.get $2)
          )
         )
        )
        (struct.new $type174
         (if (result (ref $type18))
          (if (result i32)
           (local.tee $1
            (i64.lt_s
             (local.tee $3
              (struct.get $type154 0
               (struct.get $type152 1
                (local.get $2)
               )
              )
             )
             (i64.const 0)
            )
           )
           (then
            (local.get $1)
           )
           (else
            (i64.lt_s
             (i64.extend_i32_u
              (struct.get $type18 1
               (local.get $7)
              )
             )
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global61)
            )
           )
           (if
            (i64.gt_u
             (local.get $3)
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
           )
           (call $string-copy
            (local.tee $8
             (call $string-new
              (i32.wrap_i64
               (local.get $3)
              )
             )
            )
            (i64.const 0)
            (local.get $7)
            (local.get $3)
           )
           (local.get $8)
          )
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global527)
         )
        )
        (if (result (ref $type175))
         (i64.eq
          (local.get $3)
          (i64.const 92)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready559)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global559)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global519)
           )
          )
          (local.set $3
           (call $function153
            (local.get $0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global527)
           )
          )
          (local.set $6
           (if (result (ref $type179))
            (i64.eq
             (local.get $3)
             (i64.const 97)
            )
            (then
             (struct.new $type180
              (i32.const 0)
              (i32.const 7)
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global527)
              )
             )
             (if (result (ref $type179))
              (i64.eq
               (local.get $3)
               (i64.const 98)
              )
              (then
               (struct.new $type180
                (i32.const 0)
                (i32.const 8)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global527)
                )
               )
               (if (result (ref $type179))
                (i64.eq
                 (local.get $3)
                 (i64.const 116)
                )
                (then
                 (struct.new $type180
                  (i32.const 0)
                  (i32.const 9)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global527)
                  )
                 )
                 (if (result (ref $type179))
                  (i64.eq
                   (local.get $3)
                   (i64.const 110)
                  )
                  (then
                   (struct.new $type180
                    (i32.const 0)
                    (i32.const 10)
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global527)
                    )
                   )
                   (if (result (ref $type179))
                    (i64.eq
                     (local.get $3)
                     (i64.const 114)
                    )
                    (then
                     (struct.new $type180
                      (i32.const 0)
                      (i32.const 13)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global527)
                      )
                     )
                     (if (result (ref $type179))
                      (if (result i32)
                       (local.tee $4
                        (i64.eq
                         (local.get $3)
                         (i64.const 34)
                        )
                       )
                       (then
                        (local.get $4)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global527)
                         )
                        )
                        (if (result i32)
                         (local.tee $4
                          (i64.eq
                           (local.get $3)
                           (i64.const 124)
                          )
                         )
                         (then
                          (local.get $4)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global527)
                           )
                          )
                          (i64.eq
                           (local.get $3)
                           (i64.const 92)
                          )
                         )
                        )
                       )
                      )
                      (then
                       (if
                        (i64.gt_u
                         (local.get $3)
                         (i64.const 1114111)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.and
                         (i64.le_u
                          (local.get $3)
                          (i64.const 57343)
                         )
                         (i64.ge_u
                          (local.get $3)
                          (i64.const 55296)
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (struct.new $type180
                        (i32.const 0)
                        (i32.wrap_i64
                         (local.get $3)
                        )
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global527)
                        )
                       )
                       (if (result (ref $type179))
                        (i64.eq
                         (local.get $3)
                         (i64.const 120)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready565)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global565)
                          )
                         )
                         (call $function167
                          (local.get $0)
                          (i64.const 0)
                          (i64.const 0)
                         )
                        )
                        (else
                         (if (result (ref $type179))
                          (if (result i32)
                           (i32.eq
                            (local.get $1)
                            (i32.const 34)
                           )
                           (then
                            (if
                             (i32.eqz
                              (global.get $ready580)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global580)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global527)
                             )
                            )
                            (if (result i32)
                             (local.tee $4
                              (i64.eq
                               (local.get $3)
                               (i64.const 32)
                              )
                             )
                             (then
                              (local.get $4)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global527)
                               )
                              )
                              (if (result i32)
                               (local.tee $4
                                (i64.eq
                                 (local.get $3)
                                 (i64.const 9)
                                )
                               )
                               (then
                                (local.get $4)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global527)
                                 )
                                )
                                (if (result i32)
                                 (local.tee $4
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 10)
                                  )
                                 )
                                 (then
                                  (local.get $4)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global527)
                                   )
                                  )
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 13)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                          (then
                           (if
                            (i32.eqz
                             (global.get $ready585)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global585)
                            )
                           )
                           (call $function172
                            (local.get $0)
                            (local.get $3)
                           )
                          )
                          (else
                           (struct.new $type182
                            (i32.const 2)
                            (global.get $string9)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready593)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global593)
           )
          )
          (if (result (ref $type175))
           (local.tee $4
            (struct.get $type179 0
             (local.get $6)
            )
           )
           (then
            (if (result (ref $type175))
             (i32.eq
              (local.get $4)
              (i32.const 1)
             )
             (then
              (br $block)
             )
             (else
              (struct.new $type175
               (struct.get $type182 1
                (ref.cast (ref $type182)
                 (local.get $6)
                )
               )
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global600)
             )
            )
            (call $function175
             (local.get $2)
             (struct.get $type180 1
              (ref.cast (ref $type180)
               (local.get $6)
              )
             )
            )
            (br $block)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready610)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global610)
           )
          )
          (local.set $4
           (if (result i32)
            (if (result i32)
             (i32.eq
              (local.get $1)
              (i32.const 34)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global527)
               )
              )
              (i64.eq
               (local.get $3)
               (i64.const 13)
              )
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global538)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global541)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global137)
              )
             )
             (local.set $4
              (call $foreign8
               (struct.get $type56 0
                (struct.get $type58 0
                 (local.get $0)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global133)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global521)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global527)
              )
             )
             (if
              (i64.eq
               (if (result i64)
                (ref.test (ref $type69)
                 (local.tee $5
                  (if (result (ref $type68))
                   (i32.eq
                    (local.get $4)
                    (i32.const -1)
                   )
                   (then
                    (global.get $empty69)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $3
                       (i64.extend_i32_s
                        (local.get $4)
                       )
                      )
                      (i64.const 1114111)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.and
                      (i64.le_u
                       (local.get $3)
                       (i64.const 57343)
                      )
                      (i64.ge_u
                       (local.get $3)
                       (i64.const 55296)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (struct.new $type70
                     (i32.wrap_i64
                      (local.get $3)
                     )
                    )
                   )
                  )
                 )
                )
                (then
                 (i64.const -1)
                )
                (else
                 (i64.extend_i32_u
                  (struct.get $type70 0
                   (ref.cast (ref $type70)
                    (local.get $5)
                   )
                  )
                 )
                )
               )
               (i64.const 10)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global135)
                )
               )
               (local.set $4
                (call $foreign7
                 (struct.get $type56 0
                  (struct.get $type58 0
                   (local.get $0)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global133)
                )
               )
               (drop
                (if (result (ref $type68))
                 (i32.eq
                  (local.get $4)
                  (i32.const -1)
                 )
                 (then
                  (global.get $empty69)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $3
                     (i64.extend_i32_s
                      (local.get $4)
                     )
                    )
                    (i64.const 1114111)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.and
                    (i64.le_u
                     (local.get $3)
                     (i64.const 57343)
                    )
                    (i64.ge_u
                     (local.get $3)
                     (i64.const 55296)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.new $type70
                   (i32.wrap_i64
                    (local.get $3)
                   )
                  )
                 )
                )
               )
              )
             )
             (i32.const 10)
            )
            (else
             (if
              (i64.gt_u
               (local.get $3)
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $3)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $3)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global600)
           )
          )
          (call $function175
           (local.get $2)
           (local.get $4)
          )
          (if
           (i32.eqz
            (global.get $ready552)
           )
           (then
            (unreachable)
           )
          )
          (br $block)
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global552)
   )
  )
  (return_call $function164
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $function167 (type $call186) (param $0 (ref $type58)) (param $1 i64) (param $2 i64) (result (ref $type179))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global519)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $4
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global521)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (if (result (ref $type179))
   (i64.eq
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type69)
       (local.tee $5
        (if (result (ref $type68))
         (i32.eq
          (local.get $4)
          (i32.const -1)
         )
         (then
          (global.get $empty69)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $3
             (i64.extend_i32_s
              (local.get $4)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $3)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $3)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type70
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type70 0
         (ref.cast (ref $type70)
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (i64.const 59)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global570)
     )
    )
    (if (result (ref $type179))
     (if (result i32)
      (i64.gt_s
       (local.get $2)
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global573)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (if (result i32)
            (local.tee $4
             (i64.lt_s
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (local.get $4)
            )
            (else
             (i64.gt_s
              (local.get $1)
              (i64.const 57343)
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $1)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $1)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type180
       (i32.const 0)
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (else
      (struct.new $type182
       (i32.const 2)
       (global.get $string11)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global577)
     )
    )
    (if (result (ref $type182))
     (if (result i32)
      (local.tee $4
       (i64.lt_s
        (local.tee $3
         (if (result i64)
          (i32.and
           (i64.le_s
            (local.get $3)
            (i64.const 57)
           )
           (i64.ge_s
            (local.get $3)
            (i64.const 48)
           )
          )
          (then
           (i64.sub
            (local.get $3)
            (i64.const 48)
           )
          )
          (else
           (if (result i64)
            (i32.and
             (i64.le_s
              (local.get $3)
              (i64.const 70)
             )
             (i64.ge_s
              (local.get $3)
              (i64.const 65)
             )
            )
            (then
             (i64.sub
              (local.get $3)
              (i64.const 55)
             )
            )
            (else
             (select
              (i64.sub
               (local.get $3)
               (i64.const 87)
              )
              (i64.const -1)
              (i32.and
               (i64.le_s
                (local.get $3)
                (i64.const 102)
               )
               (i64.ge_s
                (local.get $3)
                (i64.const 97)
               )
              )
             )
            )
           )
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.gt_s
        (local.get $1)
        (i64.const 69631)
       )
      )
     )
     (then
      (struct.new $type182
       (i32.const 2)
       (global.get $string10)
      )
     )
     (else
      (if
       (i32.eqz
        (global.get $ready565)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global565)
       )
      )
      (return_call $function167
       (local.get $0)
       (i64.add
        (local.get $3)
        (i64.shl
         (local.get $1)
         (i64.const 4)
        )
       )
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function172 (type $call184) (param $0 (ref $type58)) (param $1 i64) (result (ref $type179))
  (local $2 i32)
  (local $3 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (if (result (ref $type179))
   (if (result i32)
    (local.tee $2
     (i64.eq
      (local.get $1)
      (i64.const 32)
     )
    )
    (then
     (local.get $2)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global527)
      )
     )
     (i64.eq
      (local.get $1)
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global519)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (local.set $2
     (call $foreign7
      (struct.get $type56 0
       (struct.get $type58 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global521)
     )
    )
    (local.set $1
     (if (result i64)
      (ref.test (ref $type69)
       (local.tee $3
        (if (result (ref $type68))
         (i32.eq
          (local.get $2)
          (i32.const -1)
         )
         (then
          (global.get $empty69)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $1
             (i64.extend_i32_s
              (local.get $2)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $1)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $1)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type70
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type70 0
         (ref.cast (ref $type70)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready585)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global585)
     )
    )
    (return_call $function172
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global527)
     )
    )
    (if (result (ref $type179))
     (if (result i32)
      (local.tee $2
       (i64.eq
        (local.get $1)
        (i64.const 10)
       )
      )
      (then
       (local.get $2)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global527)
        )
       )
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global527)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global541)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global137)
         )
        )
        (local.set $2
         (call $foreign8
          (struct.get $type56 0
           (struct.get $type58 0
            (local.get $0)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global133)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global521)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global527)
         )
        )
        (if
         (i64.eq
          (if (result i64)
           (ref.test (ref $type69)
            (local.tee $3
             (if (result (ref $type68))
              (i32.eq
               (local.get $2)
               (i32.const -1)
              )
              (then
               (global.get $empty69)
              )
              (else
               (if
                (i64.gt_u
                 (local.tee $1
                  (i64.extend_i32_s
                   (local.get $2)
                  )
                 )
                 (i64.const 1114111)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.and
                 (i64.le_u
                  (local.get $1)
                  (i64.const 57343)
                 )
                 (i64.ge_u
                  (local.get $1)
                  (i64.const 55296)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (struct.new $type70
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
            )
           )
           (then
            (i64.const -1)
           )
           (else
            (i64.extend_i32_u
             (struct.get $type70 0
              (ref.cast (ref $type70)
               (local.get $3)
              )
             )
            )
           )
          )
          (i64.const 10)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global135)
           )
          )
          (local.set $2
           (call $foreign7
            (struct.get $type56 0
             (struct.get $type58 0
              (local.get $0)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global133)
           )
          )
          (drop
           (if (result (ref $type68))
            (i32.eq
             (local.get $2)
             (i32.const -1)
            )
            (then
             (global.get $empty69)
            )
            (else
             (if
              (i64.gt_u
               (local.tee $1
                (i64.extend_i32_s
                 (local.get $2)
                )
               )
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $1)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $1)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (struct.new $type70
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global590)
       )
      )
      (drop
       (call $function173
        (local.get $0)
       )
      )
      (global.get $empty181)
     )
     (else
      (struct.new $type182
       (i32.const 2)
       (global.get $string12)
      )
     )
    )
   )
  )
 )
 (func $function173 (type $call60) (param $0 (ref $type58)) (result i32)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global541)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (local.set $2
   (call $foreign8
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global521)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $2
     (i64.eq
      (if (result i64)
       (ref.test (ref $type69)
        (local.tee $3
         (if (result (ref $type68))
          (i32.eq
           (local.get $2)
           (i32.const -1)
          )
          (then
           (global.get $empty69)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $1
              (i64.extend_i32_s
               (local.get $2)
              )
             )
             (i64.const 1114111)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.and
             (i64.le_u
              (local.get $1)
              (i64.const 57343)
             )
             (i64.ge_u
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.new $type70
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type70 0
          (ref.cast (ref $type70)
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 32)
     )
    )
    (then
     (local.get $2)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global541)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (local.set $2
      (call $foreign8
       (struct.get $type56 0
        (struct.get $type58 0
         (local.get $0)
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global133)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global521)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global527)
      )
     )
     (i64.eq
      (if (result i64)
       (ref.test (ref $type69)
        (local.tee $3
         (if (result (ref $type68))
          (i32.eq
           (local.get $2)
           (i32.const -1)
          )
          (then
           (global.get $empty69)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $1
              (i64.extend_i32_s
               (local.get $2)
              )
             )
             (i64.const 1114111)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.and
             (i64.le_u
              (local.get $1)
              (i64.const 57343)
             )
             (i64.ge_u
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.new $type70
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type70 0
          (ref.cast (ref $type70)
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (local.set $2
     (call $foreign7
      (struct.get $type56 0
       (struct.get $type58 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (drop
     (if (result (ref $type68))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty69)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type70
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready590)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global590)
     )
    )
    (return_call $function173
     (local.get $0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function175 (type $35) (param $0 (ref $type152)) (param $1 i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type153))
  (if
   (i64.eq
    (local.tee $2
     (struct.get $type154 0
      (struct.get $type152 1
       (local.get $0)
      )
     )
    )
    (i64.extend_i32_u
     (struct.get $type18 1
      (struct.get $type153 0
       (struct.get $type152 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready604)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global604)
     )
    )
    (if
     (i64.ge_s
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global323)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global317)
       )
      )
      (call $foreign12
       (call $function104
        (global.get $string13)
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (select
          (i64.const 4294967294)
          (i64.shl
           (local.get $2)
           (i64.const 1)
          )
          (i64.gt_s
           (local.get $2)
           (i64.const 2147483647)
          )
         )
        )
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $6
        (call $string-new
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i64.const 0)
       (struct.get $type153 0
        (local.tee $7
         (struct.get $type152 0
          (local.get $0)
         )
        )
       )
       (local.get $2)
      )
      (struct.set $type153 0
       (local.get $7)
       (local.get $6)
      )
     )
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (local.tee $5
      (struct.get $type153 0
       (struct.get $type152 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $2)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $5)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type19
   (if (result (ref $type19))
    (i32.lt_u
     (local.tee $4
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type18 2
      (local.get $5)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type20
       (struct.get $type18 3
        (local.get $5)
       )
       (i32.sub
        (i32.shr_u
         (local.get $4)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $4)
    (i32.const 8191)
   )
   (local.get $1)
  )
  (struct.set $type154 0
   (struct.get $type152 1
    (local.get $0)
   )
   (i64.add
    (local.get $2)
    (i64.const 1)
   )
  )
 )
 (func $function180 (type $call159) (param $0 (ref $type58)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global519)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $4
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global521)
   )
  )
  (if (result i32)
   (i64.lt_s
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type69)
       (local.tee $5
        (if (result (ref $type68))
         (i32.eq
          (local.get $4)
          (i32.const -1)
         )
         (then
          (global.get $empty69)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $2
             (i64.extend_i32_s
              (local.get $4)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $2)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $2)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type70
           (i32.wrap_i64
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type70 0
         (ref.cast (ref $type70)
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global527)
     )
    )
    (if (result i32)
     (if (result i32)
      (i64.eq
       (local.get $3)
       (i64.const 35)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global538)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global541)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global137)
        )
       )
       (local.set $4
        (call $foreign8
         (struct.get $type56 0
          (struct.get $type58 0
           (local.get $0)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global133)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global521)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global527)
        )
       )
       (if (result i32)
        (i64.eq
         (if (result i64)
          (ref.test (ref $type69)
           (local.tee $5
            (if (result (ref $type68))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty69)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type70
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
          )
          (then
           (i64.const -1)
          )
          (else
           (i64.extend_i32_u
            (struct.get $type70 0
             (ref.cast (ref $type70)
              (local.get $5)
             )
            )
           )
          )
         )
         (i64.const 124)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global135)
          )
         )
         (local.set $4
          (call $foreign7
           (struct.get $type56 0
            (struct.get $type58 0
             (local.get $0)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global133)
          )
         )
         (drop
          (if (result (ref $type68))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
         (i32.const 1)
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready624)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global624)
       )
      )
      (return_call $function180
       (local.get $0)
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global527)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (local.get $3)
         (i64.const 124)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global538)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global541)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global137)
          )
         )
         (local.set $4
          (call $foreign8
           (struct.get $type56 0
            (struct.get $type58 0
             (local.get $0)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global133)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global521)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global527)
          )
         )
         (if (result i32)
          (i64.eq
           (if (result i64)
            (ref.test (ref $type69)
             (local.tee $5
              (if (result (ref $type68))
               (i32.eq
                (local.get $4)
                (i32.const -1)
               )
               (then
                (global.get $empty69)
               )
               (else
                (if
                 (i64.gt_u
                  (local.tee $2
                   (i64.extend_i32_s
                    (local.get $4)
                   )
                  )
                  (i64.const 1114111)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i64.le_u
                   (local.get $2)
                   (i64.const 57343)
                  )
                  (i64.ge_u
                   (local.get $2)
                   (i64.const 55296)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (struct.new $type70
                 (i32.wrap_i64
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
            (then
             (i64.const -1)
            )
            (else
             (i64.extend_i32_u
              (struct.get $type70 0
               (ref.cast (ref $type70)
                (local.get $5)
               )
              )
             )
            )
           )
           (i64.const 35)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global135)
            )
           )
           (local.set $4
            (call $foreign7
             (struct.get $type56 0
              (struct.get $type58 0
               (local.get $0)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global133)
            )
           )
           (drop
            (if (result (ref $type68))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty69)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type70
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
           (i32.const 1)
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (if (result i32)
         (local.tee $4
          (i64.eq
           (local.get $1)
           (i64.const 1)
          )
         )
         (then
          (local.get $4)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready624)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global624)
           )
          )
          (return_call $function180
           (local.get $0)
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready624)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global624)
         )
        )
        (return_call $function180
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function182 (type $call150) (param $0 i64) (result i32)
  (local $1 i32)
  (if (result i32)
   (local.tee $1
    (i64.lt_s
     (local.get $0)
     (i64.const 0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global525)
     )
    )
    (if (result i32)
     (local.tee $1
      (if (result i32)
       (i64.ge_s
        (local.get $0)
        (i64.const 0)
       )
       (then
        (if
         (i64.gt_u
          (local.get $0)
          (i64.const 1114111)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.and
          (i64.le_u
           (local.get $0)
           (i64.const 57343)
          )
          (i64.ge_u
           (local.get $0)
           (i64.const 55296)
          )
         )
         (then
          (unreachable)
         )
        )
        (i32.eq
         (call $foreign25
          (i32.wrap_i64
           (local.get $0)
          )
         )
         (i32.const 1)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global527)
       )
      )
      (if (result i32)
       (local.tee $1
        (i64.eq
         (local.get $0)
         (i64.const 40)
        )
       )
       (then
        (local.get $1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global527)
         )
        )
        (if (result i32)
         (local.tee $1
          (i64.eq
           (local.get $0)
           (i64.const 41)
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global527)
           )
          )
          (if (result i32)
           (local.tee $1
            (i64.eq
             (local.get $0)
             (i64.const 34)
            )
           )
           (then
            (local.get $1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global527)
             )
            )
            (if (result i32)
             (local.tee $1
              (i64.eq
               (local.get $0)
               (i64.const 59)
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global527)
               )
              )
              (if (result i32)
               (local.tee $1
                (i64.eq
                 (local.get $0)
                 (i64.const 124)
                )
               )
               (then
                (local.get $1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global527)
                 )
                )
                (if (result i32)
                 (local.tee $1
                  (i64.eq
                   (local.get $0)
                   (i64.const 39)
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global527)
                   )
                  )
                  (if (result i32)
                   (local.tee $1
                    (i64.eq
                     (local.get $0)
                     (i64.const 96)
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global527)
                     )
                    )
                    (if (result i32)
                     (local.tee $1
                      (i64.eq
                       (local.get $0)
                       (i64.const 44)
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global527)
                       )
                      )
                      (if (result i32)
                       (local.tee $1
                        (i64.eq
                         (local.get $0)
                         (i64.const 91)
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global527)
                         )
                        )
                        (if (result i32)
                         (local.tee $1
                          (i64.eq
                           (local.get $0)
                           (i64.const 93)
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global527)
                           )
                          )
                          (if (result i32)
                           (local.tee $1
                            (i64.eq
                             (local.get $0)
                             (i64.const 123)
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global527)
                             )
                            )
                            (i64.eq
                             (local.get $0)
                             (i64.const 125)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function184 (type $32) (param $0 (ref $type58)) (param $1 (ref $type152)) (param $2 i32) (param $3 i32) (result (ref $type18))
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type68))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global541)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (local.set $5
   (call $foreign8
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global521)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global632)
   )
  )
  (if (result (ref $type18))
   (call $function182
    (if (result i64)
     (ref.test (ref $type69)
      (local.tee $6
       (if (result (ref $type68))
        (i32.eq
         (local.get $5)
         (i32.const -1)
        )
        (then
         (global.get $empty69)
        )
        (else
         (if
          (i64.gt_u
           (local.tee $4
            (i64.extend_i32_s
             (local.get $5)
            )
           )
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $4)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $4)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.new $type70
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (then
      (i64.const -1)
     )
     (else
      (i64.extend_i32_u
       (struct.get $type70 0
        (ref.cast (ref $type70)
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global557)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global81)
     )
    )
    (local.set $7
     (struct.get $type153 0
      (struct.get $type152 0
       (local.get $1)
      )
     )
    )
    (if (result (ref $type18))
     (if (result i32)
      (local.tee $2
       (i64.lt_s
        (local.tee $4
         (struct.get $type154 0
          (struct.get $type152 1
           (local.get $1)
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $2)
      )
      (else
       (i64.lt_s
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $7)
         )
        )
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $8
        (call $string-new
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (i64.const 0)
       (local.get $7)
       (local.get $4)
      )
      (local.get $8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global519)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (local.set $5
     (call $foreign7
      (struct.get $type56 0
       (struct.get $type58 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global521)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $6
          (if (result (ref $type68))
           (i32.eq
            (local.get $5)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $4
               (i64.extend_i32_s
                (local.get $5)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $4)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $4)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $4)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $6)
           )
          )
         )
        )
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $4)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $4)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global600)
     )
    )
    (call $function175
     (local.get $1)
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function184
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
 (func $function187 (type $31) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (result (ref $type18))
  (local $4 i64)
  (local $5 i32)
  (if (result (ref $type18))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.ge_u
       (local.tee $4
        (i64.extend_i32_u
         (array.get $type19
          (if (result (ref $type19))
           (i32.lt_u
            (local.tee $5
             (i32.wrap_i64
              (local.get $3)
             )
            )
            (i32.const 8192)
           )
           (then
            (struct.get $type18 2
             (local.get $0)
            )
           )
           (else
            (ref.as_non_null
             (array.get $type20
              (struct.get $type18 3
               (local.get $0)
              )
              (i32.sub
               (i32.shr_u
                (local.get $5)
                (i32.const 13)
               )
               (i32.const 1)
              )
             )
            )
           )
          )
          (i32.and
           (local.get $5)
           (i32.const 8191)
          )
         )
        )
       )
       (i64.const 65)
      )
      (then
       (i64.le_u
        (local.get $4)
        (i64.const 90)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.tee $4
         (i64.add
          (local.get $4)
          (i64.const 32)
         )
        )
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (struct.get $type18 0
         (local.get $0)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ge_u
        (local.get $3)
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function187
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function190 (type $30) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result (ref $type179))
  (local $5 i64)
  (local $6 i32)
  (if (result (ref $type179))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global570)
     )
    )
    (if (result (ref $type179))
     (if (result i32)
      (i64.gt_s
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global573)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $4)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $4)
           (i64.const 1114111)
          )
          (then
           (if (result i32)
            (local.tee $1
             (i64.lt_s
              (local.get $4)
              (i64.const 55296)
             )
            )
            (then
             (local.get $1)
            )
            (else
             (i64.gt_s
              (local.get $4)
              (i64.const 57343)
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type180
       (i32.const 0)
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (else
      (struct.new $type182
       (i32.const 2)
       (global.get $string11)
      )
     )
    )
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global577)
     )
    )
    (if (result (ref $type182))
     (if (result i32)
      (local.tee $6
       (i64.lt_s
        (local.tee $5
         (if (result i64)
          (i32.and
           (i64.le_u
            (local.tee $5
             (i64.extend_i32_u
              (array.get $type19
               (if (result (ref $type19))
                (i32.lt_u
                 (local.tee $6
                  (i32.wrap_i64
                   (local.get $3)
                  )
                 )
                 (i32.const 8192)
                )
                (then
                 (struct.get $type18 2
                  (local.get $0)
                 )
                )
                (else
                 (ref.as_non_null
                  (array.get $type20
                   (struct.get $type18 3
                    (local.get $0)
                   )
                   (i32.sub
                    (i32.shr_u
                     (local.get $6)
                     (i32.const 13)
                    )
                    (i32.const 1)
                   )
                  )
                 )
                )
               )
               (i32.and
                (local.get $6)
                (i32.const 8191)
               )
              )
             )
            )
            (i64.const 57)
           )
           (i64.ge_u
            (local.get $5)
            (i64.const 48)
           )
          )
          (then
           (i64.sub
            (local.get $5)
            (i64.const 48)
           )
          )
          (else
           (if (result i64)
            (i32.and
             (i64.le_u
              (local.get $5)
              (i64.const 70)
             )
             (i64.ge_u
              (local.get $5)
              (i64.const 65)
             )
            )
            (then
             (i64.sub
              (local.get $5)
              (i64.const 55)
             )
            )
            (else
             (select
              (i64.sub
               (local.get $5)
               (i64.const 87)
              )
              (i64.const -1)
              (i32.and
               (i64.le_u
                (local.get $5)
                (i64.const 102)
               )
               (i64.ge_u
                (local.get $5)
                (i64.const 97)
               )
              )
             )
            )
           )
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $6)
      )
      (else
       (i64.gt_s
        (local.get $4)
        (i64.const 69631)
       )
      )
     )
     (then
      (struct.new $type182
       (i32.const 2)
       (global.get $string31)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function190
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
       (i64.add
        (local.get $5)
        (i64.shl
         (local.get $4)
         (i64.const 4)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function194 (type $call188) (param $0 (ref $type58)) (param $1 (ref $type161)) (result (ref $type140))
  (local $2 (ref $type140))
  (local $3 (ref $type18))
  (local $4 (ref $type13))
  (local $5 (ref $type21))
  (local $6 i32)
  (local $7 i64)
  (if (result (ref $type140))
   (local.tee $6
    (struct.get $type161 0
     (local.get $1)
    )
   )
   (then
    (if (result (ref $type140))
     (i32.eq
      (local.get $6)
      (i32.const 1)
     )
     (then
      (global.get $empty141)
     )
     (else
      (if (result (ref $type140))
       (i32.eq
        (struct.get $type161 0
         (local.get $1)
        )
        (i32.const 6)
       )
       (then
        (struct.new $type143
         (i32.const 2)
         (struct.get $type168 1
          (ref.cast (ref $type168)
           (local.get $1)
          )
         )
        )
       )
       (else
        (if (result (ref $type140))
         (i32.eq
          (struct.get $type161 0
           (local.get $1)
          )
          (i32.const 4)
         )
         (then
          (local.set $7
           (struct.get $type166 1
            (ref.cast (ref $type166)
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready698)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global698)
           )
          )
          (return_call $function195
           (local.get $0)
           (local.get $7)
           (ref.null none)
          )
         )
         (else
          (if (result (ref $type140))
           (i32.eq
            (struct.get $type161 0
             (local.get $1)
            )
            (i32.const 5)
           )
           (then
            (local.set $3
             (struct.get $type167 1
              (ref.cast (ref $type167)
               (local.get $1)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready769)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global769)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global514)
             )
            )
            (if
             (i32.eqz
              (global.get $ready516)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global516)
             )
            )
            (local.set $1
             (call $function152
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready691)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global691)
             )
            )
            (if (result (ref $type140))
             (i32.eq
              (struct.get $type140 0
               (local.tee $2
                (call $function194
                 (local.get $0)
                 (local.get $1)
                )
               )
              )
              (i32.const 1)
             )
             (then
              (local.set $4
               (struct.get $type142 1
                (ref.cast (ref $type142)
                 (local.get $2)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global329)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global317)
               )
              )
              (local.set $5
               (struct.new $type21
                (i32.const 4)
                (struct.new $type22
                 (call $foreign15
                  (call $function104
                   (local.get $3)
                  )
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global411)
               )
              )
              (struct.new $type142
               (i32.const 1)
               (struct.new $type31
                (i32.const 6)
                (struct.new $type32
                 (local.get $5)
                )
                (struct.new $type32
                 (struct.new $type31
                  (i32.const 6)
                  (struct.new $type32
                   (local.get $4)
                  )
                  (struct.new $type32
                   (global.get $empty14)
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type143))
               (struct.get $type140 0
                (local.get $2)
               )
               (then
                (struct.new $type143
                 (i32.const 2)
                 (struct.get $type143 1
                  (ref.cast (ref $type143)
                   (local.get $2)
                  )
                 )
                )
               )
               (else
                (struct.new $type143
                 (i32.const 2)
                 (global.get $string51)
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type143))
             (i32.eq
              (struct.get $type161 0
               (local.get $1)
              )
              (i32.const 2)
             )
             (then
              (struct.new $type143
               (i32.const 2)
               (global.get $string41)
              )
             )
             (else
              (struct.new $type143
               (i32.const 2)
               (global.get $string40)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (struct.new $type142
     (i32.const 1)
     (struct.get $type162 1
      (ref.cast (ref $type162)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function195 (type $26) (param $0 (ref $type58)) (param $1 i64) (param $2 (ref null $type12)) (result (ref $type140))
  (local $3 (ref null $type12))
  (local $4 (ref null $type12))
  (local $5 (ref $type31))
  (local $6 (ref $type12))
  (local $7 (ref $type34))
  (local $8 (ref $type161))
  (local $9 (ref $type140))
  (local $10 (ref $type14))
  (local $11 (ref $type13))
  (local $12 i32)
  (drop
   (ref.as_non_null
    (global.get $global516)
   )
  )
  (if (result (ref $type140))
   (i32.eq
    (struct.get $type161 0
     (local.tee $8
      (call $function152
       (local.get $0)
      )
     )
    )
    (i32.const 2)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready704)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global704)
     )
    )
    (if (result (ref $type142))
     (i64.eqz
      (local.get $1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global707)
       )
      )
      (local.set $10
       (global.get $empty14)
      )
      (struct.new $type142
       (i32.const 1)
       (if (result (ref $type13))
        (ref.is_null
         (local.get $2)
        )
        (then
         (local.get $10)
        )
        (else
         (local.set $4
          (struct.get $type12 1
           (local.get $2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global411)
          )
         )
         (if
          (i32.eqz
           (global.get $ready707)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global707)
          )
         )
         (local.set $5
          (struct.new $type31
           (i32.const 6)
           (struct.new $type32
            (struct.get $type12 0
             (local.get $2)
            )
           )
           (struct.new $type32
            (local.get $10)
           )
          )
         )
         (if (result (ref $type13))
          (ref.is_null
           (local.get $4)
          )
          (then
           (local.get $5)
          )
          (else
           (local.set $3
            (struct.get $type12 1
             (local.get $4)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global411)
            )
           )
           (if
            (i32.eqz
             (global.get $ready707)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global707)
            )
           )
           (local.set $5
            (struct.new $type31
             (i32.const 6)
             (struct.new $type32
              (struct.get $type12 0
               (local.get $4)
              )
             )
             (struct.new $type32
              (local.get $5)
             )
            )
           )
           (if (result (ref $type13))
            (ref.is_null
             (local.get $3)
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $4
              (struct.get $type12 1
               (local.get $3)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global411)
              )
             )
             (if
              (i32.eqz
               (global.get $ready707)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global707)
              )
             )
             (local.set $5
              (struct.new $type31
               (i32.const 6)
               (struct.new $type32
                (struct.get $type12 0
                 (local.get $3)
                )
               )
               (struct.new $type32
                (local.get $5)
               )
              )
             )
             (if (result (ref $type13))
              (ref.is_null
               (local.get $4)
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $3
                (struct.get $type12 1
                 (local.get $4)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global411)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready707)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global707)
                )
               )
               (local.set $5
                (struct.new $type31
                 (i32.const 6)
                 (struct.new $type32
                  (struct.get $type12 0
                   (local.get $4)
                  )
                 )
                 (struct.new $type32
                  (local.get $5)
                 )
                )
               )
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $4
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global411)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready707)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global707)
                  )
                 )
                 (local.set $5
                  (struct.new $type31
                   (i32.const 6)
                   (struct.new $type32
                    (struct.get $type12 0
                     (local.get $3)
                    )
                   )
                   (struct.new $type32
                    (local.get $5)
                   )
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type12 1
                     (local.get $4)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global411)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready707)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global707)
                    )
                   )
                   (local.set $5
                    (struct.new $type31
                     (i32.const 6)
                     (struct.new $type32
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (struct.new $type32
                      (local.get $5)
                     )
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $4
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global411)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready707)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global707)
                      )
                     )
                     (local.set $5
                      (struct.new $type31
                       (i32.const 6)
                       (struct.new $type32
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (struct.new $type32
                        (local.get $5)
                       )
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type12 1
                         (local.get $4)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global411)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready707)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global707)
                        )
                       )
                       (local.set $5
                        (struct.new $type31
                         (i32.const 6)
                         (struct.new $type32
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (struct.new $type32
                          (local.get $5)
                         )
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global411)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready707)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global707)
                          )
                         )
                         (local.set $5
                          (struct.new $type31
                           (i32.const 6)
                           (struct.new $type32
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (struct.new $type32
                            (local.get $5)
                           )
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global411)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready707)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global707)
                            )
                           )
                           (local.set $5
                            (struct.new $type31
                             (i32.const 6)
                             (struct.new $type32
                              (struct.get $type12 0
                               (local.get $3)
                              )
                             )
                             (struct.new $type32
                              (local.get $5)
                             )
                            )
                           )
                           (if (result (ref $type13))
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (drop
                              (ref.as_non_null
                               (global.get $global411)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready707)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global707)
                              )
                             )
                             (local.set $5
                              (struct.new $type31
                               (i32.const 6)
                               (struct.new $type32
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (struct.new $type32
                                (local.get $5)
                               )
                              )
                             )
                             (if (result (ref $type13))
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (drop
                                (ref.as_non_null
                                 (global.get $global411)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready707)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global707)
                                )
                               )
                               (local.set $5
                                (struct.new $type31
                                 (i32.const 6)
                                 (struct.new $type32
                                  (struct.get $type12 0
                                   (local.get $3)
                                  )
                                 )
                                 (struct.new $type32
                                  (local.get $5)
                                 )
                                )
                               )
                               (if (result (ref $type13))
                                (ref.is_null
                                 (local.tee $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (local.get $5)
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global411)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready707)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global707)
                                  )
                                 )
                                 (local.set $5
                                  (struct.new $type31
                                   (i32.const 6)
                                   (struct.new $type32
                                    (struct.get $type12 0
                                     (local.get $3)
                                    )
                                   )
                                   (struct.new $type32
                                    (local.get $5)
                                   )
                                  )
                                 )
                                 (if (result (ref $type13))
                                  (ref.is_null
                                   (local.tee $3
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (local.get $5)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global411)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready707)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global707)
                                    )
                                   )
                                   (local.set $5
                                    (struct.new $type31
                                     (i32.const 6)
                                     (struct.new $type32
                                      (struct.get $type12 0
                                       (local.get $3)
                                      )
                                     )
                                     (struct.new $type32
                                      (local.get $5)
                                     )
                                    )
                                   )
                                   (if (result (ref $type13))
                                    (ref.is_null
                                     (local.tee $3
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (local.get $5)
                                    )
                                    (else
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global411)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready707)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global707)
                                      )
                                     )
                                     (local.set $5
                                      (struct.new $type31
                                       (i32.const 6)
                                       (struct.new $type32
                                        (struct.get $type12 0
                                         (local.get $3)
                                        )
                                       )
                                       (struct.new $type32
                                        (local.get $5)
                                       )
                                      )
                                     )
                                     (if (result (ref $type13))
                                      (ref.is_null
                                       (local.tee $3
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                      )
                                      (then
                                       (local.get $5)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global411)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready707)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global707)
                                        )
                                       )
                                       (local.set $5
                                        (struct.new $type31
                                         (i32.const 6)
                                         (struct.new $type32
                                          (struct.get $type12 0
                                           (local.get $3)
                                          )
                                         )
                                         (struct.new $type32
                                          (local.get $5)
                                         )
                                        )
                                       )
                                       (if (result (ref $type13))
                                        (ref.is_null
                                         (local.tee $3
                                          (struct.get $type12 1
                                           (local.get $3)
                                          )
                                         )
                                        )
                                        (then
                                         (local.get $5)
                                        )
                                        (else
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global411)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready707)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global707)
                                          )
                                         )
                                         (local.set $5
                                          (struct.new $type31
                                           (i32.const 6)
                                           (struct.new $type32
                                            (struct.get $type12 0
                                             (local.get $3)
                                            )
                                           )
                                           (struct.new $type32
                                            (local.get $5)
                                           )
                                          )
                                         )
                                         (if (result (ref $type13))
                                          (ref.is_null
                                           (local.tee $3
                                            (struct.get $type12 1
                                             (local.get $3)
                                            )
                                           )
                                          )
                                          (then
                                           (local.get $5)
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global411)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready707)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global707)
                                            )
                                           )
                                           (local.set $5
                                            (struct.new $type31
                                             (i32.const 6)
                                             (struct.new $type32
                                              (struct.get $type12 0
                                               (local.get $3)
                                              )
                                             )
                                             (struct.new $type32
                                              (local.get $5)
                                             )
                                            )
                                           )
                                           (if (result (ref $type13))
                                            (ref.is_null
                                             (local.tee $3
                                              (struct.get $type12 1
                                               (local.get $3)
                                              )
                                             )
                                            )
                                            (then
                                             (local.get $5)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global411)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready707)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global707)
                                              )
                                             )
                                             (call $function197
                                              (struct.get $type12 1
                                               (local.get $3)
                                              )
                                              (struct.new $type31
                                               (i32.const 6)
                                               (struct.new $type32
                                                (struct.get $type12 0
                                                 (local.get $3)
                                                )
                                               )
                                               (struct.new $type32
                                                (local.get $5)
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (if (result (ref $type142))
       (i64.eq
        (local.get $1)
        (i64.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global710)
         )
        )
        (local.set $4
         (if (result (ref null $type12))
          (ref.is_null
           (local.get $2)
          )
          (then
           (ref.null none)
          )
          (else
           (local.set $6
            (struct.new $type12
             (struct.get $type12 0
              (local.get $2)
             )
             (ref.null none)
            )
           )
           (if (result (ref null $type12))
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (local.get $6)
            )
            (else
             (local.set $6
              (struct.new $type12
               (struct.get $type12 0
                (local.get $3)
               )
               (local.get $6)
              )
             )
             (if (result (ref null $type12))
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $6
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $3)
                 )
                 (local.get $6)
                )
               )
               (if (result (ref null $type12))
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (local.get $6)
                )
                (else
                 (local.set $6
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $3)
                   )
                   (local.get $6)
                  )
                 )
                 (if (result (ref null $type12))
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $6
                    (struct.new $type12
                     (struct.get $type12 0
                      (local.get $3)
                     )
                     (local.get $6)
                    )
                   )
                   (if (result (ref null $type12))
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (local.get $6)
                    )
                    (else
                     (local.set $6
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $3)
                       )
                       (local.get $6)
                      )
                     )
                     (if (result (ref null $type12))
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $6
                        (struct.new $type12
                         (struct.get $type12 0
                          (local.get $3)
                         )
                         (local.get $6)
                        )
                       )
                       (if (result (ref null $type12))
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (local.get $6)
                        )
                        (else
                         (local.set $6
                          (struct.new $type12
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (local.get $6)
                          )
                         )
                         (if (result (ref null $type12))
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $6
                            (struct.new $type12
                             (struct.get $type12 0
                              (local.get $3)
                             )
                             (local.get $6)
                            )
                           )
                           (if (result (ref null $type12))
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (local.get $6)
                            )
                            (else
                             (local.set $6
                              (struct.new $type12
                               (struct.get $type12 0
                                (local.get $3)
                               )
                               (local.get $6)
                              )
                             )
                             (if (result (ref null $type12))
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (local.get $6)
                              )
                              (else
                               (local.set $6
                                (struct.new $type12
                                 (struct.get $type12 0
                                  (local.get $3)
                                 )
                                 (local.get $6)
                                )
                               )
                               (if (result (ref null $type12))
                                (ref.is_null
                                 (local.tee $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (local.get $6)
                                )
                                (else
                                 (local.set $6
                                  (struct.new $type12
                                   (struct.get $type12 0
                                    (local.get $3)
                                   )
                                   (local.get $6)
                                  )
                                 )
                                 (if (result (ref null $type12))
                                  (ref.is_null
                                   (local.tee $3
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (local.get $6)
                                  )
                                  (else
                                   (local.set $6
                                    (struct.new $type12
                                     (struct.get $type12 0
                                      (local.get $3)
                                     )
                                     (local.get $6)
                                    )
                                   )
                                   (if (result (ref null $type12))
                                    (ref.is_null
                                     (local.tee $3
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (local.get $6)
                                    )
                                    (else
                                     (local.set $6
                                      (struct.new $type12
                                       (struct.get $type12 0
                                        (local.get $3)
                                       )
                                       (local.get $6)
                                      )
                                     )
                                     (if (result (ref null $type12))
                                      (ref.is_null
                                       (local.tee $3
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                      )
                                      (then
                                       (local.get $6)
                                      )
                                      (else
                                       (local.set $6
                                        (struct.new $type12
                                         (struct.get $type12 0
                                          (local.get $3)
                                         )
                                         (local.get $6)
                                        )
                                       )
                                       (if (result (ref null $type12))
                                        (ref.is_null
                                         (local.tee $3
                                          (struct.get $type12 1
                                           (local.get $3)
                                          )
                                         )
                                        )
                                        (then
                                         (local.get $6)
                                        )
                                        (else
                                         (local.set $6
                                          (struct.new $type12
                                           (struct.get $type12 0
                                            (local.get $3)
                                           )
                                           (local.get $6)
                                          )
                                         )
                                         (if (result (ref null $type12))
                                          (ref.is_null
                                           (local.tee $3
                                            (struct.get $type12 1
                                             (local.get $3)
                                            )
                                           )
                                          )
                                          (then
                                           (local.get $6)
                                          )
                                          (else
                                           (local.set $6
                                            (struct.new $type12
                                             (struct.get $type12 0
                                              (local.get $3)
                                             )
                                             (local.get $6)
                                            )
                                           )
                                           (if (result (ref null $type12))
                                            (ref.is_null
                                             (local.tee $3
                                              (struct.get $type12 1
                                               (local.get $3)
                                              )
                                             )
                                            )
                                            (then
                                             (local.get $6)
                                            )
                                            (else
                                             (local.set $6
                                              (struct.new $type12
                                               (struct.get $type12 0
                                                (local.get $3)
                                               )
                                               (local.get $6)
                                              )
                                             )
                                             (if (result (ref null $type12))
                                              (ref.is_null
                                               (local.tee $3
                                                (struct.get $type12 1
                                                 (local.get $3)
                                                )
                                               )
                                              )
                                              (then
                                               (local.get $6)
                                              )
                                              (else
                                               (call $function199
                                                (i32.const 0)
                                                (i32.const 1)
                                                (struct.get $type12 1
                                                 (local.get $3)
                                                )
                                                (struct.new $type12
                                                 (struct.get $type12 0
                                                  (local.get $3)
                                                 )
                                                 (local.get $6)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global715)
         )
        )
        (struct.new $type142
         (i32.const 1)
         (struct.new $type33
          (i32.const 7)
          (if (result (ref $type34))
           (ref.is_null
            (local.get $4)
           )
           (then
            (array.new_fixed $type34 0)
           )
           (else
            (if
             (i32.eqz
              (global.get $ready718)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global718)
             )
            )
            (if
             (i64.gt_u
              (local.tee $1
               (if (result i64)
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (i64.const 0)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (i64.const 1)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 2)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 3)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 4)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 5)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 6)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (i64.const 7)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 8)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $3
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 9)
                                  )
                                  (else
                                   (if (result i64)
                                    (ref.is_null
                                     (local.tee $3
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const 10)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.tee $3
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                      )
                                      (then
                                       (i64.const 11)
                                      )
                                      (else
                                       (if (result i64)
                                        (ref.is_null
                                         (local.tee $3
                                          (struct.get $type12 1
                                           (local.get $3)
                                          )
                                         )
                                        )
                                        (then
                                         (i64.const 12)
                                        )
                                        (else
                                         (if (result i64)
                                          (ref.is_null
                                           (local.tee $3
                                            (struct.get $type12 1
                                             (local.get $3)
                                            )
                                           )
                                          )
                                          (then
                                           (i64.const 13)
                                          )
                                          (else
                                           (if (result i64)
                                            (ref.is_null
                                             (local.tee $3
                                              (struct.get $type12 1
                                               (local.get $3)
                                              )
                                             )
                                            )
                                            (then
                                             (i64.const 14)
                                            )
                                            (else
                                             (if (result i64)
                                              (ref.is_null
                                               (local.tee $3
                                                (struct.get $type12 1
                                                 (local.get $3)
                                                )
                                               )
                                              )
                                              (then
                                               (i64.const 15)
                                              )
                                              (else
                                               (if (result i64)
                                                (ref.is_null
                                                 (local.tee $3
                                                  (struct.get $type12 1
                                                   (local.get $3)
                                                  )
                                                 )
                                                )
                                                (then
                                                 (i64.const 16)
                                                )
                                                (else
                                                 (if (result i64)
                                                  (ref.is_null
                                                   (local.tee $3
                                                    (struct.get $type12 1
                                                     (local.get $3)
                                                    )
                                                   )
                                                  )
                                                  (then
                                                   (i64.const 17)
                                                  )
                                                  (else
                                                   (call $function202
                                                    (i32.const 0)
                                                    (i32.const 1)
                                                    (struct.get $type12 1
                                                     (local.get $3)
                                                    )
                                                    (i64.const 18)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (local.set $7
             (array.new $type34
              (struct.get $type12 0
               (local.get $4)
              )
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
            (if (result (ref $type34))
             (ref.is_null
              (local.get $4)
             )
             (then
              (local.get $7)
             )
             (else
              (array.set $type34
               (local.get $7)
               (i32.const 0)
               (struct.get $type12 0
                (local.get $4)
               )
              )
              (if (result (ref $type34))
               (ref.is_null
                (local.tee $3
                 (struct.get $type12 1
                  (local.get $4)
                 )
                )
               )
               (then
                (local.get $7)
               )
               (else
                (array.set $type34
                 (local.get $7)
                 (i32.const 1)
                 (struct.get $type12 0
                  (local.get $3)
                 )
                )
                (if (result (ref $type34))
                 (ref.is_null
                  (local.tee $3
                   (struct.get $type12 1
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (local.get $7)
                 )
                 (else
                  (array.set $type34
                   (local.get $7)
                   (i32.const 2)
                   (struct.get $type12 0
                    (local.get $3)
                   )
                  )
                  (if (result (ref $type34))
                   (ref.is_null
                    (local.tee $3
                     (struct.get $type12 1
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (local.get $7)
                   )
                   (else
                    (array.set $type34
                     (local.get $7)
                     (i32.const 3)
                     (struct.get $type12 0
                      (local.get $3)
                     )
                    )
                    (if (result (ref $type34))
                     (ref.is_null
                      (local.tee $3
                       (struct.get $type12 1
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (local.get $7)
                     )
                     (else
                      (array.set $type34
                       (local.get $7)
                       (i32.const 4)
                       (struct.get $type12 0
                        (local.get $3)
                       )
                      )
                      (if (result (ref $type34))
                       (ref.is_null
                        (local.tee $3
                         (struct.get $type12 1
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (local.get $7)
                       )
                       (else
                        (array.set $type34
                         (local.get $7)
                         (i32.const 5)
                         (struct.get $type12 0
                          (local.get $3)
                         )
                        )
                        (if (result (ref $type34))
                         (ref.is_null
                          (local.tee $3
                           (struct.get $type12 1
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (local.get $7)
                         )
                         (else
                          (array.set $type34
                           (local.get $7)
                           (i32.const 6)
                           (struct.get $type12 0
                            (local.get $3)
                           )
                          )
                          (if (result (ref $type34))
                           (ref.is_null
                            (local.tee $3
                             (struct.get $type12 1
                              (local.get $3)
                             )
                            )
                           )
                           (then
                            (local.get $7)
                           )
                           (else
                            (array.set $type34
                             (local.get $7)
                             (i32.const 7)
                             (struct.get $type12 0
                              (local.get $3)
                             )
                            )
                            (if (result (ref $type34))
                             (ref.is_null
                              (local.tee $3
                               (struct.get $type12 1
                                (local.get $3)
                               )
                              )
                             )
                             (then
                              (local.get $7)
                             )
                             (else
                              (array.set $type34
                               (local.get $7)
                               (i32.const 8)
                               (struct.get $type12 0
                                (local.get $3)
                               )
                              )
                              (if (result (ref $type34))
                               (ref.is_null
                                (local.tee $3
                                 (struct.get $type12 1
                                  (local.get $3)
                                 )
                                )
                               )
                               (then
                                (local.get $7)
                               )
                               (else
                                (array.set $type34
                                 (local.get $7)
                                 (i32.const 9)
                                 (struct.get $type12 0
                                  (local.get $3)
                                 )
                                )
                                (if (result (ref $type34))
                                 (ref.is_null
                                  (local.tee $3
                                   (struct.get $type12 1
                                    (local.get $3)
                                   )
                                  )
                                 )
                                 (then
                                  (local.get $7)
                                 )
                                 (else
                                  (array.set $type34
                                   (local.get $7)
                                   (i32.const 10)
                                   (struct.get $type12 0
                                    (local.get $3)
                                   )
                                  )
                                  (if (result (ref $type34))
                                   (ref.is_null
                                    (local.tee $3
                                     (struct.get $type12 1
                                      (local.get $3)
                                     )
                                    )
                                   )
                                   (then
                                    (local.get $7)
                                   )
                                   (else
                                    (array.set $type34
                                     (local.get $7)
                                     (i32.const 11)
                                     (struct.get $type12 0
                                      (local.get $3)
                                     )
                                    )
                                    (if (result (ref $type34))
                                     (ref.is_null
                                      (local.tee $3
                                       (struct.get $type12 1
                                        (local.get $3)
                                       )
                                      )
                                     )
                                     (then
                                      (local.get $7)
                                     )
                                     (else
                                      (array.set $type34
                                       (local.get $7)
                                       (i32.const 12)
                                       (struct.get $type12 0
                                        (local.get $3)
                                       )
                                      )
                                      (if (result (ref $type34))
                                       (ref.is_null
                                        (local.tee $3
                                         (struct.get $type12 1
                                          (local.get $3)
                                         )
                                        )
                                       )
                                       (then
                                        (local.get $7)
                                       )
                                       (else
                                        (array.set $type34
                                         (local.get $7)
                                         (i32.const 13)
                                         (struct.get $type12 0
                                          (local.get $3)
                                         )
                                        )
                                        (if (result (ref $type34))
                                         (ref.is_null
                                          (local.tee $3
                                           (struct.get $type12 1
                                            (local.get $3)
                                           )
                                          )
                                         )
                                         (then
                                          (local.get $7)
                                         )
                                         (else
                                          (array.set $type34
                                           (local.get $7)
                                           (i32.const 14)
                                           (struct.get $type12 0
                                            (local.get $3)
                                           )
                                          )
                                          (if (result (ref $type34))
                                           (ref.is_null
                                            (local.tee $3
                                             (struct.get $type12 1
                                              (local.get $3)
                                             )
                                            )
                                           )
                                           (then
                                            (local.get $7)
                                           )
                                           (else
                                            (array.set $type34
                                             (local.get $7)
                                             (i32.const 15)
                                             (struct.get $type12 0
                                              (local.get $3)
                                             )
                                            )
                                            (if (result (ref $type34))
                                             (ref.is_null
                                              (local.tee $3
                                               (struct.get $type12 1
                                                (local.get $3)
                                               )
                                              )
                                             )
                                             (then
                                              (local.get $7)
                                             )
                                             (else
                                              (array.set $type34
                                               (local.get $7)
                                               (i32.const 16)
                                               (struct.get $type12 0
                                                (local.get $3)
                                               )
                                              )
                                              (if (result (ref $type34))
                                               (ref.is_null
                                                (local.tee $3
                                                 (struct.get $type12 1
                                                  (local.get $3)
                                                 )
                                                )
                                               )
                                               (then
                                                (local.get $7)
                                               )
                                               (else
                                                (array.set $type34
                                                 (local.get $7)
                                                 (i32.const 17)
                                                 (struct.get $type12 0
                                                  (local.get $3)
                                                 )
                                                )
                                                (if (result (ref $type34))
                                                 (ref.is_null
                                                  (local.tee $3
                                                   (struct.get $type12 1
                                                    (local.get $3)
                                                   )
                                                  )
                                                 )
                                                 (then
                                                  (local.get $7)
                                                 )
                                                 (else
                                                  (array.set $type34
                                                   (local.get $7)
                                                   (i32.const 18)
                                                   (struct.get $type12 0
                                                    (local.get $3)
                                                   )
                                                  )
                                                  (call $function203
                                                   (local.get $7)
                                                   (i32.const 0)
                                                   (i32.const 1)
                                                   (struct.get $type12 1
                                                    (local.get $3)
                                                   )
                                                   (i64.const 19)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready726)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global726)
         )
        )
        (local.set $1
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i64.const 0)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 1)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (i64.const 2)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 3)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 4)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 5)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 6)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 7)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 8)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 9)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (i64.const 10)
                              )
                              (else
                               (if (result i64)
                                (ref.is_null
                                 (local.tee $3
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                 )
                                )
                                (then
                                 (i64.const 11)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.tee $3
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (i64.const 12)
                                  )
                                  (else
                                   (if (result i64)
                                    (ref.is_null
                                     (local.tee $3
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (i64.const 13)
                                    )
                                    (else
                                     (if (result i64)
                                      (ref.is_null
                                       (local.tee $3
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                      )
                                      (then
                                       (i64.const 14)
                                      )
                                      (else
                                       (if (result i64)
                                        (ref.is_null
                                         (local.tee $3
                                          (struct.get $type12 1
                                           (local.get $3)
                                          )
                                         )
                                        )
                                        (then
                                         (i64.const 15)
                                        )
                                        (else
                                         (if (result i64)
                                          (ref.is_null
                                           (local.tee $3
                                            (struct.get $type12 1
                                             (local.get $3)
                                            )
                                           )
                                          )
                                          (then
                                           (i64.const 16)
                                          )
                                          (else
                                           (if (result i64)
                                            (ref.is_null
                                             (local.tee $3
                                              (struct.get $type12 1
                                               (local.get $3)
                                              )
                                             )
                                            )
                                            (then
                                             (i64.const 17)
                                            )
                                            (else
                                             (if (result i64)
                                              (ref.is_null
                                               (local.tee $3
                                                (struct.get $type12 1
                                                 (local.get $3)
                                                )
                                               )
                                              )
                                              (then
                                               (i64.const 18)
                                              )
                                              (else
                                               (call $function205
                                                (i32.const 0)
                                                (i32.const 1)
                                                (struct.get $type12 1
                                                 (local.get $3)
                                                )
                                                (i64.const 19)
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global180)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready732)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global732)
         )
        )
        (return_call $function206
         (local.get $2)
         (struct.new $type36
          (array.new_default $type37
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (else
    (if (result (ref $type140))
     (i32.eq
      (struct.get $type161 0
       (local.get $8)
      )
      (i32.const 1)
     )
     (then
      (struct.new $type143
       (i32.const 2)
       (global.get $string43)
      )
     )
     (else
      (if (result (ref $type140))
       (i32.eq
        (struct.get $type161 0
         (local.get $8)
        )
        (i32.const 3)
       )
       (then
        (if (result (ref $type140))
         (i32.and
          (i32.eqz
           (ref.is_null
            (local.get $2)
           )
          )
          (i64.eqz
           (local.get $1)
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready745)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global745)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global514)
           )
          )
          (if
           (i32.eqz
            (global.get $ready516)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global516)
           )
          )
          (local.set $8
           (call $function152
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (global.get $ready691)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global691)
           )
          )
          (if (result (ref $type140))
           (i32.eq
            (struct.get $type140 0
             (local.tee $9
              (call $function194
               (local.get $0)
               (local.get $8)
              )
             )
            )
            (i32.const 1)
           )
           (then
            (local.set $11
             (struct.get $type142 1
              (ref.cast (ref $type142)
               (local.get $9)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global516)
             )
            )
            (if (result (ref $type140))
             (i32.eq
              (struct.get $type161 0
               (local.tee $8
                (call $function152
                 (local.get $0)
                )
               )
              )
              (i32.const 2)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready707)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global707)
               )
              )
              (struct.new $type142
               (i32.const 1)
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (local.get $11)
                )
                (else
                 (local.set $4
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global411)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready707)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global707)
                  )
                 )
                 (local.set $5
                  (struct.new $type31
                   (i32.const 6)
                   (struct.new $type32
                    (struct.get $type12 0
                     (local.get $2)
                    )
                   )
                   (struct.new $type32
                    (local.get $11)
                   )
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type12 1
                     (local.get $4)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global411)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready707)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global707)
                    )
                   )
                   (local.set $5
                    (struct.new $type31
                     (i32.const 6)
                     (struct.new $type32
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (struct.new $type32
                      (local.get $5)
                     )
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $4
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global411)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready707)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global707)
                      )
                     )
                     (local.set $5
                      (struct.new $type31
                       (i32.const 6)
                       (struct.new $type32
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (struct.new $type32
                        (local.get $5)
                       )
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type12 1
                         (local.get $4)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global411)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready707)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global707)
                        )
                       )
                       (local.set $5
                        (struct.new $type31
                         (i32.const 6)
                         (struct.new $type32
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (struct.new $type32
                          (local.get $5)
                         )
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $4
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global411)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready707)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global707)
                          )
                         )
                         (local.set $5
                          (struct.new $type31
                           (i32.const 6)
                           (struct.new $type32
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (struct.new $type32
                            (local.get $5)
                           )
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.get $4)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (local.set $3
                            (struct.get $type12 1
                             (local.get $4)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global411)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready707)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global707)
                            )
                           )
                           (local.set $5
                            (struct.new $type31
                             (i32.const 6)
                             (struct.new $type32
                              (struct.get $type12 0
                               (local.get $4)
                              )
                             )
                             (struct.new $type32
                              (local.get $5)
                             )
                            )
                           )
                           (if (result (ref $type13))
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (local.set $4
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global411)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready707)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global707)
                              )
                             )
                             (local.set $5
                              (struct.new $type31
                               (i32.const 6)
                               (struct.new $type32
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (struct.new $type32
                                (local.get $5)
                               )
                              )
                             )
                             (if (result (ref $type13))
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (local.set $3
                                (struct.get $type12 1
                                 (local.get $4)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global411)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready707)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global707)
                                )
                               )
                               (local.set $5
                                (struct.new $type31
                                 (i32.const 6)
                                 (struct.new $type32
                                  (struct.get $type12 0
                                   (local.get $4)
                                  )
                                 )
                                 (struct.new $type32
                                  (local.get $5)
                                 )
                                )
                               )
                               (if (result (ref $type13))
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (local.get $5)
                                )
                                (else
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global411)
                                  )
                                 )
                                 (if
                                  (i32.eqz
                                   (global.get $ready707)
                                  )
                                  (then
                                   (unreachable)
                                  )
                                 )
                                 (drop
                                  (ref.as_non_null
                                   (global.get $global707)
                                  )
                                 )
                                 (local.set $5
                                  (struct.new $type31
                                   (i32.const 6)
                                   (struct.new $type32
                                    (struct.get $type12 0
                                     (local.get $3)
                                    )
                                   )
                                   (struct.new $type32
                                    (local.get $5)
                                   )
                                  )
                                 )
                                 (if (result (ref $type13))
                                  (ref.is_null
                                   (local.tee $3
                                    (struct.get $type12 1
                                     (local.get $3)
                                    )
                                   )
                                  )
                                  (then
                                   (local.get $5)
                                  )
                                  (else
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global411)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready707)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global707)
                                    )
                                   )
                                   (local.set $5
                                    (struct.new $type31
                                     (i32.const 6)
                                     (struct.new $type32
                                      (struct.get $type12 0
                                       (local.get $3)
                                      )
                                     )
                                     (struct.new $type32
                                      (local.get $5)
                                     )
                                    )
                                   )
                                   (if (result (ref $type13))
                                    (ref.is_null
                                     (local.tee $3
                                      (struct.get $type12 1
                                       (local.get $3)
                                      )
                                     )
                                    )
                                    (then
                                     (local.get $5)
                                    )
                                    (else
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global411)
                                      )
                                     )
                                     (if
                                      (i32.eqz
                                       (global.get $ready707)
                                      )
                                      (then
                                       (unreachable)
                                      )
                                     )
                                     (drop
                                      (ref.as_non_null
                                       (global.get $global707)
                                      )
                                     )
                                     (local.set $5
                                      (struct.new $type31
                                       (i32.const 6)
                                       (struct.new $type32
                                        (struct.get $type12 0
                                         (local.get $3)
                                        )
                                       )
                                       (struct.new $type32
                                        (local.get $5)
                                       )
                                      )
                                     )
                                     (if (result (ref $type13))
                                      (ref.is_null
                                       (local.tee $3
                                        (struct.get $type12 1
                                         (local.get $3)
                                        )
                                       )
                                      )
                                      (then
                                       (local.get $5)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global411)
                                        )
                                       )
                                       (if
                                        (i32.eqz
                                         (global.get $ready707)
                                        )
                                        (then
                                         (unreachable)
                                        )
                                       )
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global707)
                                        )
                                       )
                                       (local.set $5
                                        (struct.new $type31
                                         (i32.const 6)
                                         (struct.new $type32
                                          (struct.get $type12 0
                                           (local.get $3)
                                          )
                                         )
                                         (struct.new $type32
                                          (local.get $5)
                                         )
                                        )
                                       )
                                       (if (result (ref $type13))
                                        (ref.is_null
                                         (local.tee $3
                                          (struct.get $type12 1
                                           (local.get $3)
                                          )
                                         )
                                        )
                                        (then
                                         (local.get $5)
                                        )
                                        (else
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global411)
                                          )
                                         )
                                         (if
                                          (i32.eqz
                                           (global.get $ready707)
                                          )
                                          (then
                                           (unreachable)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global707)
                                          )
                                         )
                                         (local.set $5
                                          (struct.new $type31
                                           (i32.const 6)
                                           (struct.new $type32
                                            (struct.get $type12 0
                                             (local.get $3)
                                            )
                                           )
                                           (struct.new $type32
                                            (local.get $5)
                                           )
                                          )
                                         )
                                         (if (result (ref $type13))
                                          (ref.is_null
                                           (local.tee $3
                                            (struct.get $type12 1
                                             (local.get $3)
                                            )
                                           )
                                          )
                                          (then
                                           (local.get $5)
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global411)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready707)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global707)
                                            )
                                           )
                                           (local.set $5
                                            (struct.new $type31
                                             (i32.const 6)
                                             (struct.new $type32
                                              (struct.get $type12 0
                                               (local.get $3)
                                              )
                                             )
                                             (struct.new $type32
                                              (local.get $5)
                                             )
                                            )
                                           )
                                           (if (result (ref $type13))
                                            (ref.is_null
                                             (local.tee $3
                                              (struct.get $type12 1
                                               (local.get $3)
                                              )
                                             )
                                            )
                                            (then
                                             (local.get $5)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global411)
                                              )
                                             )
                                             (if
                                              (i32.eqz
                                               (global.get $ready707)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global707)
                                              )
                                             )
                                             (local.set $5
                                              (struct.new $type31
                                               (i32.const 6)
                                               (struct.new $type32
                                                (struct.get $type12 0
                                                 (local.get $3)
                                                )
                                               )
                                               (struct.new $type32
                                                (local.get $5)
                                               )
                                              )
                                             )
                                             (if (result (ref $type13))
                                              (ref.is_null
                                               (local.tee $3
                                                (struct.get $type12 1
                                                 (local.get $3)
                                                )
                                               )
                                              )
                                              (then
                                               (local.get $5)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global411)
                                                )
                                               )
                                               (if
                                                (i32.eqz
                                                 (global.get $ready707)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global707)
                                                )
                                               )
                                               (local.set $5
                                                (struct.new $type31
                                                 (i32.const 6)
                                                 (struct.new $type32
                                                  (struct.get $type12 0
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (struct.new $type32
                                                  (local.get $5)
                                                 )
                                                )
                                               )
                                               (if (result (ref $type13))
                                                (ref.is_null
                                                 (local.tee $3
                                                  (struct.get $type12 1
                                                   (local.get $3)
                                                  )
                                                 )
                                                )
                                                (then
                                                 (local.get $5)
                                                )
                                                (else
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global411)
                                                  )
                                                 )
                                                 (if
                                                  (i32.eqz
                                                   (global.get $ready707)
                                                  )
                                                  (then
                                                   (unreachable)
                                                  )
                                                 )
                                                 (drop
                                                  (ref.as_non_null
                                                   (global.get $global707)
                                                  )
                                                 )
                                                 (local.set $5
                                                  (struct.new $type31
                                                   (i32.const 6)
                                                   (struct.new $type32
                                                    (struct.get $type12 0
                                                     (local.get $3)
                                                    )
                                                   )
                                                   (struct.new $type32
                                                    (local.get $5)
                                                   )
                                                  )
                                                 )
                                                 (if (result (ref $type13))
                                                  (ref.is_null
                                                   (local.tee $3
                                                    (struct.get $type12 1
                                                     (local.get $3)
                                                    )
                                                   )
                                                  )
                                                  (then
                                                   (local.get $5)
                                                  )
                                                  (else
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global411)
                                                    )
                                                   )
                                                   (if
                                                    (i32.eqz
                                                     (global.get $ready707)
                                                    )
                                                    (then
                                                     (unreachable)
                                                    )
                                                   )
                                                   (drop
                                                    (ref.as_non_null
                                                     (global.get $global707)
                                                    )
                                                   )
                                                   (local.set $5
                                                    (struct.new $type31
                                                     (i32.const 6)
                                                     (struct.new $type32
                                                      (struct.get $type12 0
                                                       (local.get $3)
                                                      )
                                                     )
                                                     (struct.new $type32
                                                      (local.get $5)
                                                     )
                                                    )
                                                   )
                                                   (if (result (ref $type13))
                                                    (ref.is_null
                                                     (local.tee $3
                                                      (struct.get $type12 1
                                                       (local.get $3)
                                                      )
                                                     )
                                                    )
                                                    (then
                                                     (local.get $5)
                                                    )
                                                    (else
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global411)
                                                      )
                                                     )
                                                     (if
                                                      (i32.eqz
                                                       (global.get $ready707)
                                                      )
                                                      (then
                                                       (unreachable)
                                                      )
                                                     )
                                                     (drop
                                                      (ref.as_non_null
                                                       (global.get $global707)
                                                      )
                                                     )
                                                     (call $function197
                                                      (struct.get $type12 1
                                                       (local.get $3)
                                                      )
                                                      (struct.new $type31
                                                       (i32.const 6)
                                                       (struct.new $type32
                                                        (struct.get $type12 0
                                                         (local.get $3)
                                                        )
                                                       )
                                                       (struct.new $type32
                                                        (local.get $5)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type143))
               (i32.eq
                (struct.get $type161 0
                 (local.get $8)
                )
                (i32.const 6)
               )
               (then
                (struct.new $type143
                 (i32.const 2)
                 (struct.get $type168 1
                  (ref.cast (ref $type168)
                   (local.get $8)
                  )
                 )
                )
               )
               (else
                (if (result (ref $type143))
                 (local.tee $12
                  (struct.get $type161 0
                   (local.get $8)
                  )
                 )
                 (then
                  (if (result (ref $type143))
                   (i32.eq
                    (local.get $12)
                    (i32.const 1)
                   )
                   (then
                    (struct.new $type143
                     (i32.const 2)
                     (global.get $string49)
                    )
                   )
                   (else
                    (if (result (ref $type143))
                     (i32.eq
                      (struct.get $type161 0
                       (local.get $8)
                      )
                      (i32.const 3)
                     )
                     (then
                      (struct.new $type143
                       (i32.const 2)
                       (global.get $string48)
                      )
                     )
                     (else
                      (if (result (ref $type143))
                       (i32.eq
                        (struct.get $type161 0
                         (local.get $8)
                        )
                        (i32.const 4)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type166)
                          (local.get $8)
                         )
                        )
                        (struct.new $type143
                         (i32.const 2)
                         (global.get $string47)
                        )
                       )
                       (else
                        (drop
                         (ref.cast (ref $type167)
                          (local.get $8)
                         )
                        )
                        (struct.new $type143
                         (i32.const 2)
                         (global.get $string46)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.cast (ref $type162)
                    (local.get $8)
                   )
                  )
                  (struct.new $type143
                   (i32.const 2)
                   (global.get $string50)
                  )
                 )
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type143))
             (struct.get $type140 0
              (local.get $9)
             )
             (then
              (struct.new $type143
               (i32.const 2)
               (struct.get $type143 1
                (ref.cast (ref $type143)
                 (local.get $9)
                )
               )
              )
             )
             (else
              (struct.new $type143
               (i32.const 2)
               (global.get $string45)
              )
             )
            )
           )
          )
         )
         (else
          (struct.new $type143
           (i32.const 2)
           (global.get $string42)
          )
         )
        )
       )
       (else
        (if (result (ref $type143))
         (i32.eq
          (struct.get $type161 0
           (local.get $8)
          )
          (i32.const 6)
         )
         (then
          (struct.new $type143
           (i32.const 2)
           (struct.get $type168 1
            (ref.cast (ref $type168)
             (local.get $8)
            )
           )
          )
         )
         (else
          (if (result (ref $type143))
           (local.tee $12
            (struct.get $type161 0
             (local.get $8)
            )
           )
           (then
            (if
             (i32.eq
              (local.get $12)
              (i32.const 4)
             )
             (then
              (drop
               (ref.cast (ref $type166)
                (local.get $8)
               )
              )
             )
             (else
              (drop
               (ref.cast (ref $type167)
                (local.get $8)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global691)
             )
            )
            (local.set $9
             (call $function194
              (local.get $0)
              (local.get $8)
             )
            )
            (if
             (i32.eqz
              (global.get $ready759)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global759)
             )
            )
            (if (result (ref $type143))
             (i32.eq
              (struct.get $type140 0
               (local.get $9)
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global698)
               )
              )
              (return_call $function195
               (local.get $0)
               (local.get $1)
               (struct.new $type12
                (struct.get $type142 1
                 (ref.cast (ref $type142)
                  (local.get $9)
                 )
                )
                (local.get $2)
               )
              )
             )
             (else
              (if (result (ref $type143))
               (i32.eq
                (struct.get $type140 0
                 (local.get $9)
                )
                (i32.const 2)
               )
               (then
                (struct.new $type143
                 (i32.const 2)
                 (struct.get $type143 1
                  (ref.cast (ref $type143)
                   (local.get $9)
                  )
                 )
                )
               )
               (else
                (unreachable)
               )
              )
             )
            )
           )
           (else
            (local.set $6
             (struct.new $type12
              (struct.get $type162 1
               (ref.cast (ref $type162)
                (local.get $8)
               )
              )
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready698)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global698)
             )
            )
            (return_call $function195
             (local.get $0)
             (local.get $1)
             (local.get $6)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function197 (type $20) (param $0 (ref null $type12)) (param $1 (ref $type31)) (result (ref $type13))
  (if (result (ref $type31))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global411)
     )
    )
    (if
     (i32.eqz
      (global.get $ready707)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global707)
     )
    )
    (return_call $function197
     (struct.get $type12 1
      (local.get $0)
     )
     (struct.new $type31
      (i32.const 6)
      (struct.new $type32
       (struct.get $type12 0
        (local.get $0)
       )
      )
      (struct.new $type32
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function199 (type $19) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 (ref $type12)) (result (ref null $type12))
  (local $4 (ref null $type12))
  (if (result (ref $type12))
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (local.set $3
     (struct.new $type12
      (struct.get $type12 0
       (local.get $2)
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function199
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $3)
    )
   )
  )
 )
 (func $function202 (type $18) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function202
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function203 (type $17) (param $0 (ref $type34)) (param $1 i32) (param $2 i32) (param $3 (ref null $type12)) (param $4 i64) (result (ref $type34))
  (local $5 (ref $type13))
  (if (result (ref $type34))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (local.set $5
     (struct.get $type12 0
      (local.get $3)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type34
     (local.get $0)
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $5)
    )
    (local.set $3
     (struct.get $type12 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function203
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function205 (type $18) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function205
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function206 (type $call197) (param $0 (ref null $type12)) (param $1 (ref $type36)) (param $2 i64) (result (ref $type140))
  (local $3 (ref $type13))
  (local $4 (ref $type24))
  (local $5 i32)
  (local $6 i64)
  (local $7 i64)
  (if (result (ref $type140))
   (ref.is_null
    (local.get $0)
   )
   (then
    (struct.new $type142
     (i32.const 1)
     (struct.new $type35
      (i32.const 8)
      (local.get $1)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global737)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global436)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global424)
     )
    )
    (if (result (ref $type143))
     (if (result i32)
      (local.tee $5
       (i64.lt_s
        (local.tee $6
         (if (result i64)
          (i64.eq
           (if (result i64)
            (local.tee $5
             (struct.get $type13 0
              (local.tee $3
               (struct.get $type12 0
                (local.get $0)
               )
              )
             )
            )
            (then
             (if (result i64)
              (i32.eq
               (local.get $5)
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type15)
                 (local.get $3)
                )
               )
               (i64.const 1)
              )
              (else
               (if (result i64)
                (i32.eq
                 (struct.get $type13 0
                  (local.get $3)
                 )
                 (i32.const 2)
                )
                (then
                 (drop
                  (ref.cast (ref $type16)
                   (local.get $3)
                  )
                 )
                 (i64.const 2)
                )
                (else
                 (if (result i64)
                  (i32.eq
                   (struct.get $type13 0
                    (local.get $3)
                   )
                   (i32.const 3)
                  )
                  (then
                   (drop
                    (ref.cast (ref $type17)
                     (local.get $3)
                    )
                   )
                   (i64.const 3)
                  )
                  (else
                   (if (result i64)
                    (i32.eq
                     (struct.get $type13 0
                      (local.get $3)
                     )
                     (i32.const 4)
                    )
                    (then
                     (drop
                      (ref.cast (ref $type21)
                       (local.get $3)
                      )
                     )
                     (i64.const 4)
                    )
                    (else
                     (if (result i64)
                      (i32.eq
                       (struct.get $type13 0
                        (local.get $3)
                       )
                       (i32.const 5)
                      )
                      (then
                       (drop
                        (ref.cast (ref $type23)
                         (local.get $3)
                        )
                       )
                       (i64.const 5)
                      )
                      (else
                       (if (result i64)
                        (i32.eq
                         (struct.get $type13 0
                          (local.get $3)
                         )
                         (i32.const 6)
                        )
                        (then
                         (drop
                          (ref.cast (ref $type31)
                           (local.get $3)
                          )
                         )
                         (i64.const 6)
                        )
                        (else
                         (if (result i64)
                          (i32.eq
                           (struct.get $type13 0
                            (local.get $3)
                           )
                           (i32.const 7)
                          )
                          (then
                           (drop
                            (ref.cast (ref $type33)
                             (local.get $3)
                            )
                           )
                           (i64.const 7)
                          )
                          (else
                           (drop
                            (ref.cast (ref $type35)
                             (local.get $3)
                            )
                           )
                           (i64.const 8)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (i64.const 0)
            )
           )
           (i64.const 5)
          )
          (then
           (if
            (i32.ne
             (struct.get $type13 0
              (local.get $3)
             )
             (i32.const 5)
            )
            (then
             (unreachable)
            )
           )
           (if (result i64)
            (struct.get $type24 0
             (local.tee $4
              (struct.get $type23 1
               (ref.cast (ref $type23)
                (local.get $3)
               )
              )
             )
            )
            (then
             (if
              (i32.eq
               (struct.get $type24 0
                (local.get $4)
               )
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type26)
                 (local.get $4)
                )
               )
              )
              (else
               (drop
                (ref.cast (ref $type27)
                 (local.get $4)
                )
               )
              )
             )
             (i64.const -1)
            )
            (else
             (struct.get $type25 1
              (ref.cast (ref $type25)
               (local.get $4)
              )
             )
            )
           )
          )
          (else
           (i64.const -1)
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $5)
      )
      (else
       (i64.gt_s
        (local.get $6)
        (i64.const 255)
       )
      )
     )
     (then
      (struct.new $type143
       (i32.const 2)
       (global.get $string44)
      )
     )
     (else
      (if
       (i64.gt_u
        (local.tee $7
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type37
       (struct.get $type36 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $7)
       )
       (i32.wrap_i64
        (local.get $6)
       )
      )
      (if
       (i32.eqz
        (global.get $ready732)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global732)
       )
      )
      (return_call $function206
       (struct.get $type12 1
        (local.get $0)
       )
       (local.get $1)
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function212 (type $call145) (param $0 (ref $type58)) (result (ref $type140))
  (local $1 (ref $type140))
  (local $2 (ref $type161))
  (local $3 (ref $type18))
  (local $scratch (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global514)
   )
  )
  (if
   (i32.eqz
    (global.get $ready516)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global516)
   )
  )
  (local.set $2
   (call $function152
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready691)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global691)
   )
  )
  (if (result (ref $type140))
   (i32.eq
    (struct.get $type140 0
     (local.tee $1
      (call $function194
       (local.get $0)
       (local.get $2)
      )
     )
    )
    (i32.const 2)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global90)
     )
    )
    (call $foreign12
     (call $function104
      (block (result (ref $type18))
       (local.set $scratch
        (call $function35
         (struct.new $type48
          (global.get $string1)
          (struct.new $type48
           (struct.get $type143 1
            (ref.cast (ref $type143)
             (local.get $1)
            )
           )
           (ref.null none)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global323)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global317)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (unreachable)
   )
   (else
    (if
     (i32.eq
      (struct.get $type140 0
       (local.get $1)
      )
      (i32.const 1)
     )
     (then
      (drop
       (ref.cast (ref $type142)
        (local.get $1)
       )
      )
     )
    )
    (local.get $1)
   )
  )
 )
 (func $function217 (type $13) (param $0 (ref $type58)) (param $1 i32) (param $2 i32) (param $3 (ref $type140)) (param $4 (ref $type13)) (param $5 i64) (result (ref $type13))
  (local $6 i32)
  (local $7 (ref $type140))
  (drop
   (ref.as_non_null
    (global.get $global504)
   )
  )
  (if (result (ref $type13))
   (if (result i32)
    (local.tee $6
     (struct.get $type140 0
      (local.get $3)
     )
    )
    (then
     (if
      (i32.eq
       (local.get $6)
       (i32.const 1)
      )
      (then
       (drop
        (ref.cast (ref $type142)
         (local.get $3)
        )
       )
      )
      (else
       (drop
        (ref.cast (ref $type143)
         (local.get $3)
        )
       )
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global777)
     )
    )
    (local.set $7
     (call $function212
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global509)
     )
    )
    (local.set $4
     (call $function150
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function217
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $7)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function223 (type $call52) (param $0 (ref $type18)) (result i32)
  (local $1 i64)
  (call $foreign27
   (local.tee $1
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign28
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign28
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign28
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign28
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign28
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign28
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign28
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign28
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign28
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign28
                       (array.get $type19
                        (struct.get $type18 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 10)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign28
                         (array.get $type19
                          (struct.get $type18 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (local.get $0)
                           )
                          )
                          (i64.const 11)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type18 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign28
                           (array.get $type19
                            (struct.get $type18 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (struct.get $type18 1
                              (local.get $0)
                             )
                            )
                            (i64.const 12)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign28
                             (array.get $type19
                              (struct.get $type18 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.get $0)
                               )
                              )
                              (i64.const 13)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type18 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign28
                               (array.get $type19
                                (struct.get $type18 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (struct.get $type18 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 14)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign28
                                 (array.get $type19
                                  (struct.get $type18 2
                                   (local.get $0)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 15)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type18 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $foreign28
                                   (array.get $type19
                                    (struct.get $type18 2
                                     (local.get $0)
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (struct.get $type18 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 16)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (call $foreign28
                                     (array.get $type19
                                      (struct.get $type18 2
                                       (local.get $0)
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 17)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type18 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call $foreign28
                                       (array.get $type19
                                        (struct.get $type18 2
                                         (local.get $0)
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (i64.extend_i32_u
                                         (struct.get $type18 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 18)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (call $foreign28
                                         (array.get $type19
                                          (struct.get $type18 2
                                           (local.get $0)
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 19)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $0)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $foreign28
                                           (array.get $type19
                                            (call $string-block
                                             (local.get $0)
                                             (i32.const 19)
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (return_call $function224
                                           (local.get $0)
                                           (i32.const 0)
                                           (i32.const 1)
                                           (i64.const 20)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function224 (type $12) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign28
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $4
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (i32.and
       (local.get $4)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function224
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function227 (type $call204) (param $0 (ref $type13)) (result i32)
  (local $1 (ref $type34))
  (local $2 (ref $type37))
  (local $3 (ref $type36))
  (local $4 (ref $type28))
  (local $5 (ref $type24))
  (local $6 (ref $type18))
  (local $7 (ref $type22))
  (local $8 (ref $type27))
  (local $9 (ref $type31))
  (local $10 (ref $type32))
  (local $11 i64)
  (local $12 i32)
  (local $13 f64)
  (local $scratch i32)
  (local $scratch_15 (ref $type18))
  (local $scratch_16 (ref $type22))
  (local $scratch_17 (ref $type18))
  (local $scratch_18 f64)
  (local $scratch_19 i64)
  (local $scratch_20 f64)
  (local $scratch_21 i64)
  (local $scratch_22 f64)
  (local $scratch_23 i64)
  (local $scratch_24 (ref $type32))
  (if (result i32)
   (local.tee $12
    (struct.get $type13 0
     (local.get $0)
    )
   )
   (then
    (if (result i32)
     (i32.eq
      (local.get $12)
      (i32.const 1)
     )
     (then
      (call $foreign27
       (i64.extend_i32_u
        (i32.ne
         (struct.get $type15 1
          (ref.cast (ref $type15)
           (local.get $0)
          )
         )
         (block (result i32)
          (call $foreign27
           (i64.const 1)
          )
          (i32.const 0)
         )
        )
       )
      )
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i32.eq
        (struct.get $type13 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (call $foreign28
         (block (result i32)
          (local.set $scratch
           (struct.get $type16 1
            (ref.cast (ref $type16)
             (local.get $0)
            )
           )
          )
          (call $foreign27
           (i64.const 2)
          )
          (local.get $scratch)
         )
        )
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i32.eq
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 3)
         )
         (then
          (return_call $function223
           (block (result (ref $type18))
            (local.set $scratch_15
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (local.get $0)
              )
             )
            )
            (call $foreign27
             (i64.const 3)
            )
            (drop
             (ref.as_non_null
              (global.get $global821)
             )
            )
            (local.get $scratch_15)
           )
          )
         )
         (else
          (if (result i32)
           (i32.eq
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 4)
           )
           (then
            (local.set $11
             (call $foreign16
              (local.tee $12
               (struct.get $type22 0
                (block (result (ref $type22))
                 (local.set $scratch_16
                  (struct.get $type21 1
                   (ref.cast (ref $type21)
                    (local.get $0)
                   )
                  )
                 )
                 (call $foreign27
                  (i64.const 4)
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global334)
                  )
                 )
                 (local.get $scratch_16)
                )
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global61)
             )
            )
            (if
             (i64.gt_u
              (local.get $11)
              (i64.const 4294967294)
             )
             (then
              (unreachable)
             )
            )
            (return_call $function223
             (block (result (ref $type18))
              (local.set $scratch_17
               (call $function111
                (local.get $12)
                (local.get $11)
                (call $string-new
                 (i32.wrap_i64
                  (local.get $11)
                 )
                )
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global821)
               )
              )
              (local.get $scratch_17)
             )
            )
           )
           (else
            (if (result i32)
             (i32.eq
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 5)
             )
             (then
              (local.set $5
               (struct.get $type23 1
                (ref.cast (ref $type23)
                 (local.get $0)
                )
               )
              )
              (call $foreign27
               (i64.const 5)
              )
              (drop
               (ref.as_non_null
                (global.get $global830)
               )
              )
              (if
               (local.tee $12
                (struct.get $type24 0
                 (local.get $5)
                )
               )
               (then
                (if
                 (i32.eq
                  (local.get $12)
                  (i32.const 1)
                 )
                 (then
                  (call $foreign29
                   (block (result f64)
                    (local.set $scratch_18
                     (struct.get $type26 1
                      (ref.cast (ref $type26)
                       (local.get $5)
                      )
                     )
                    )
                    (call $foreign27
                     (i64.const 1)
                    )
                    (local.get $scratch_18)
                   )
                  )
                 )
                 (else
                  (local.set $4
                   (struct.get $type27 1
                    (local.tee $8
                     (ref.cast (ref $type27)
                      (local.get $5)
                     )
                    )
                   )
                  )
                  (call $foreign27
                   (i64.const 2)
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global825)
                   )
                  )
                  (if
                   (ref.test (ref $type29)
                    (local.get $4)
                   )
                   (then
                    (call $foreign27
                     (block (result i64)
                      (local.set $scratch_19
                       (struct.get $type29 0
                        (ref.cast (ref $type29)
                         (local.get $4)
                        )
                       )
                      )
                      (call $foreign27
                       (i64.const 0)
                      )
                      (local.get $scratch_19)
                     )
                    )
                   )
                   (else
                    (call $foreign29
                     (block (result f64)
                      (local.set $scratch_20
                       (struct.get $type30 0
                        (ref.cast (ref $type30)
                         (local.get $4)
                        )
                       )
                      )
                      (call $foreign27
                       (i64.const 1)
                      )
                      (local.get $scratch_20)
                     )
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global825)
                   )
                  )
                  (if
                   (ref.test (ref $type29)
                    (local.tee $4
                     (struct.get $type27 2
                      (local.get $8)
                     )
                    )
                   )
                   (then
                    (call $foreign27
                     (block (result i64)
                      (local.set $scratch_21
                       (struct.get $type29 0
                        (ref.cast (ref $type29)
                         (local.get $4)
                        )
                       )
                      )
                      (call $foreign27
                       (i64.const 0)
                      )
                      (local.get $scratch_21)
                     )
                    )
                   )
                   (else
                    (call $foreign29
                     (block (result f64)
                      (local.set $scratch_22
                       (struct.get $type30 0
                        (ref.cast (ref $type30)
                         (local.get $4)
                        )
                       )
                      )
                      (call $foreign27
                       (i64.const 1)
                      )
                      (local.get $scratch_22)
                     )
                    )
                   )
                  )
                 )
                )
               )
               (else
                (call $foreign27
                 (block (result i64)
                  (local.set $scratch_23
                   (struct.get $type25 1
                    (ref.cast (ref $type25)
                     (local.get $5)
                    )
                   )
                  )
                  (call $foreign27
                   (i64.const 0)
                  )
                  (local.get $scratch_23)
                 )
                )
               )
              )
              (i32.const 0)
             )
             (else
              (if (result i32)
               (i32.eq
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 6)
               )
               (then
                (drop
                 (call $function227
                  (struct.get $type32 0
                   (block (result (ref $type32))
                    (local.set $scratch_24
                     (struct.get $type31 1
                      (local.tee $9
                       (ref.cast (ref $type31)
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (call $foreign27
                     (i64.const 6)
                    )
                    (if
                     (i32.eqz
                      (global.get $ready837)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global837)
                     )
                    )
                    (local.get $scratch_24)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready837)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global837)
                 )
                )
                (return_call $function227
                 (struct.get $type32 0
                  (struct.get $type31 2
                   (local.get $9)
                  )
                 )
                )
               )
               (else
                (if (result i32)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 7)
                 )
                 (then
                  (local.set $1
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (local.get $0)
                    )
                   )
                  )
                  (call $foreign27
                   (i64.const 7)
                  )
                  (if
                   (i32.eqz
                    (global.get $ready848)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global848)
                   )
                  )
                  (call $foreign27
                   (local.tee $11
                    (i64.extend_i32_u
                     (array.len
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eqz
                    (local.get $11)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global837)
                     )
                    )
                    (drop
                     (call $function227
                      (array.get $type34
                       (local.get $1)
                       (i32.const 0)
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $1)
                       )
                      )
                      (i64.const 1)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global837)
                       )
                      )
                      (drop
                       (call $function227
                        (array.get $type34
                         (local.get $1)
                         (i32.const 1)
                        )
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (array.len
                          (local.get $1)
                         )
                        )
                        (i64.const 2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global837)
                         )
                        )
                        (drop
                         (call $function227
                          (array.get $type34
                           (local.get $1)
                           (i32.const 2)
                          )
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (array.len
                            (local.get $1)
                           )
                          )
                          (i64.const 3)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global837)
                           )
                          )
                          (drop
                           (call $function227
                            (array.get $type34
                             (local.get $1)
                             (i32.const 3)
                            )
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (array.len
                              (local.get $1)
                             )
                            )
                            (i64.const 4)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global837)
                             )
                            )
                            (drop
                             (call $function227
                              (array.get $type34
                               (local.get $1)
                               (i32.const 4)
                              )
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (array.len
                                (local.get $1)
                               )
                              )
                              (i64.const 5)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global837)
                               )
                              )
                              (drop
                               (call $function227
                                (array.get $type34
                                 (local.get $1)
                                 (i32.const 5)
                                )
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $1)
                                 )
                                )
                                (i64.const 6)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global837)
                                 )
                                )
                                (drop
                                 (call $function227
                                  (array.get $type34
                                   (local.get $1)
                                   (i32.const 6)
                                  )
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $1)
                                   )
                                  )
                                  (i64.const 7)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global837)
                                   )
                                  )
                                  (drop
                                   (call $function227
                                    (array.get $type34
                                     (local.get $1)
                                     (i32.const 7)
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $1)
                                     )
                                    )
                                    (i64.const 8)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global837)
                                     )
                                    )
                                    (drop
                                     (call $function227
                                      (array.get $type34
                                       (local.get $1)
                                       (i32.const 8)
                                      )
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.get $1)
                                       )
                                      )
                                      (i64.const 9)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global837)
                                       )
                                      )
                                      (drop
                                       (call $function227
                                        (array.get $type34
                                         (local.get $1)
                                         (i32.const 9)
                                        )
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.get $1)
                                         )
                                        )
                                        (i64.const 10)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global837)
                                         )
                                        )
                                        (drop
                                         (call $function227
                                          (array.get $type34
                                           (local.get $1)
                                           (i32.const 10)
                                          )
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.get $1)
                                           )
                                          )
                                          (i64.const 11)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global837)
                                           )
                                          )
                                          (drop
                                           (call $function227
                                            (array.get $type34
                                             (local.get $1)
                                             (i32.const 11)
                                            )
                                           )
                                          )
                                          (if (result i32)
                                           (i64.eq
                                            (i64.extend_i32_u
                                             (array.len
                                              (local.get $1)
                                             )
                                            )
                                            (i64.const 12)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global837)
                                             )
                                            )
                                            (drop
                                             (call $function227
                                              (array.get $type34
                                               (local.get $1)
                                               (i32.const 12)
                                              )
                                             )
                                            )
                                            (if (result i32)
                                             (i64.eq
                                              (i64.extend_i32_u
                                               (array.len
                                                (local.get $1)
                                               )
                                              )
                                              (i64.const 13)
                                             )
                                             (then
                                              (i32.const 0)
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global837)
                                               )
                                              )
                                              (drop
                                               (call $function227
                                                (array.get $type34
                                                 (local.get $1)
                                                 (i32.const 13)
                                                )
                                               )
                                              )
                                              (if (result i32)
                                               (i64.eq
                                                (i64.extend_i32_u
                                                 (array.len
                                                  (local.get $1)
                                                 )
                                                )
                                                (i64.const 14)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global837)
                                                 )
                                                )
                                                (drop
                                                 (call $function227
                                                  (array.get $type34
                                                   (local.get $1)
                                                   (i32.const 14)
                                                  )
                                                 )
                                                )
                                                (if (result i32)
                                                 (i64.eq
                                                  (i64.extend_i32_u
                                                   (array.len
                                                    (local.get $1)
                                                   )
                                                  )
                                                  (i64.const 15)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global837)
                                                   )
                                                  )
                                                  (drop
                                                   (call $function227
                                                    (array.get $type34
                                                     (local.get $1)
                                                     (i32.const 15)
                                                    )
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (i64.eq
                                                    (i64.extend_i32_u
                                                     (array.len
                                                      (local.get $1)
                                                     )
                                                    )
                                                    (i64.const 16)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global837)
                                                     )
                                                    )
                                                    (drop
                                                     (call $function227
                                                      (array.get $type34
                                                       (local.get $1)
                                                       (i32.const 16)
                                                      )
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (i64.eq
                                                      (i64.extend_i32_u
                                                       (array.len
                                                        (local.get $1)
                                                       )
                                                      )
                                                      (i64.const 17)
                                                     )
                                                     (then
                                                      (i32.const 0)
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global837)
                                                       )
                                                      )
                                                      (drop
                                                       (call $function227
                                                        (array.get $type34
                                                         (local.get $1)
                                                         (i32.const 17)
                                                        )
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (i64.eq
                                                        (i64.extend_i32_u
                                                         (array.len
                                                          (local.get $1)
                                                         )
                                                        )
                                                        (i64.const 18)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global837)
                                                         )
                                                        )
                                                        (drop
                                                         (call $function227
                                                          (array.get $type34
                                                           (local.get $1)
                                                           (i32.const 18)
                                                          )
                                                         )
                                                        )
                                                        (return_call $function229
                                                         (local.get $1)
                                                         (i32.const 0)
                                                         (i32.const 1)
                                                         (i64.const 19)
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (local.set $3
                   (struct.get $type35 1
                    (ref.cast (ref $type35)
                     (local.get $0)
                    )
                   )
                  )
                  (call $foreign27
                   (i64.const 8)
                  )
                  (if
                   (i32.eqz
                    (global.get $ready853)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global853)
                   )
                  )
                  (call $foreign27
                   (local.tee $11
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type36 0
                       (local.get $3)
                      )
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eqz
                    (local.get $11)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign27
                     (i64.extend_i32_u
                      (array.get_u $type37
                       (local.tee $2
                        (struct.get $type36 0
                         (local.get $3)
                        )
                       )
                       (i32.const 0)
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $2)
                       )
                      )
                      (i64.const 1)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign27
                       (i64.extend_i32_u
                        (array.get_u $type37
                         (local.tee $2
                          (struct.get $type36 0
                           (local.get $3)
                          )
                         )
                         (i32.const 1)
                        )
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (array.len
                          (local.get $2)
                         )
                        )
                        (i64.const 2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (call $foreign27
                         (i64.extend_i32_u
                          (array.get_u $type37
                           (local.tee $2
                            (struct.get $type36 0
                             (local.get $3)
                            )
                           )
                           (i32.const 2)
                          )
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (array.len
                            (local.get $2)
                           )
                          )
                          (i64.const 3)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (call $foreign27
                           (i64.extend_i32_u
                            (array.get_u $type37
                             (local.tee $2
                              (struct.get $type36 0
                               (local.get $3)
                              )
                             )
                             (i32.const 3)
                            )
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (array.len
                              (local.get $2)
                             )
                            )
                            (i64.const 4)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (call $foreign27
                             (i64.extend_i32_u
                              (array.get_u $type37
                               (local.tee $2
                                (struct.get $type36 0
                                 (local.get $3)
                                )
                               )
                               (i32.const 4)
                              )
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (array.len
                                (local.get $2)
                               )
                              )
                              (i64.const 5)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (call $foreign27
                               (i64.extend_i32_u
                                (array.get_u $type37
                                 (local.tee $2
                                  (struct.get $type36 0
                                   (local.get $3)
                                  )
                                 )
                                 (i32.const 5)
                                )
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $2)
                                 )
                                )
                                (i64.const 6)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (call $foreign27
                                 (i64.extend_i32_u
                                  (array.get_u $type37
                                   (local.tee $2
                                    (struct.get $type36 0
                                     (local.get $3)
                                    )
                                   )
                                   (i32.const 6)
                                  )
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $2)
                                   )
                                  )
                                  (i64.const 7)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (call $foreign27
                                   (i64.extend_i32_u
                                    (array.get_u $type37
                                     (local.tee $2
                                      (struct.get $type36 0
                                       (local.get $3)
                                      )
                                     )
                                     (i32.const 7)
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 8)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (call $foreign27
                                     (i64.extend_i32_u
                                      (array.get_u $type37
                                       (local.tee $2
                                        (struct.get $type36 0
                                         (local.get $3)
                                        )
                                       )
                                       (i32.const 8)
                                      )
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (i64.extend_i32_u
                                       (array.len
                                        (local.get $2)
                                       )
                                      )
                                      (i64.const 9)
                                     )
                                     (then
                                      (i32.const 0)
                                     )
                                     (else
                                      (call $foreign27
                                       (i64.extend_i32_u
                                        (array.get_u $type37
                                         (local.tee $2
                                          (struct.get $type36 0
                                           (local.get $3)
                                          )
                                         )
                                         (i32.const 9)
                                        )
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (i64.extend_i32_u
                                         (array.len
                                          (local.get $2)
                                         )
                                        )
                                        (i64.const 10)
                                       )
                                       (then
                                        (i32.const 0)
                                       )
                                       (else
                                        (call $foreign27
                                         (i64.extend_i32_u
                                          (array.get_u $type37
                                           (local.tee $2
                                            (struct.get $type36 0
                                             (local.get $3)
                                            )
                                           )
                                           (i32.const 10)
                                          )
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (i64.extend_i32_u
                                           (array.len
                                            (local.get $2)
                                           )
                                          )
                                          (i64.const 11)
                                         )
                                         (then
                                          (i32.const 0)
                                         )
                                         (else
                                          (call $foreign27
                                           (i64.extend_i32_u
                                            (array.get_u $type37
                                             (local.tee $2
                                              (struct.get $type36 0
                                               (local.get $3)
                                              )
                                             )
                                             (i32.const 11)
                                            )
                                           )
                                          )
                                          (if (result i32)
                                           (i64.eq
                                            (i64.extend_i32_u
                                             (array.len
                                              (local.get $2)
                                             )
                                            )
                                            (i64.const 12)
                                           )
                                           (then
                                            (i32.const 0)
                                           )
                                           (else
                                            (call $foreign27
                                             (i64.extend_i32_u
                                              (array.get_u $type37
                                               (local.tee $2
                                                (struct.get $type36 0
                                                 (local.get $3)
                                                )
                                               )
                                               (i32.const 12)
                                              )
                                             )
                                            )
                                            (if (result i32)
                                             (i64.eq
                                              (i64.extend_i32_u
                                               (array.len
                                                (local.get $2)
                                               )
                                              )
                                              (i64.const 13)
                                             )
                                             (then
                                              (i32.const 0)
                                             )
                                             (else
                                              (call $foreign27
                                               (i64.extend_i32_u
                                                (array.get_u $type37
                                                 (local.tee $2
                                                  (struct.get $type36 0
                                                   (local.get $3)
                                                  )
                                                 )
                                                 (i32.const 13)
                                                )
                                               )
                                              )
                                              (if (result i32)
                                               (i64.eq
                                                (i64.extend_i32_u
                                                 (array.len
                                                  (local.get $2)
                                                 )
                                                )
                                                (i64.const 14)
                                               )
                                               (then
                                                (i32.const 0)
                                               )
                                               (else
                                                (call $foreign27
                                                 (i64.extend_i32_u
                                                  (array.get_u $type37
                                                   (local.tee $2
                                                    (struct.get $type36 0
                                                     (local.get $3)
                                                    )
                                                   )
                                                   (i32.const 14)
                                                  )
                                                 )
                                                )
                                                (if (result i32)
                                                 (i64.eq
                                                  (i64.extend_i32_u
                                                   (array.len
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (i64.const 15)
                                                 )
                                                 (then
                                                  (i32.const 0)
                                                 )
                                                 (else
                                                  (call $foreign27
                                                   (i64.extend_i32_u
                                                    (array.get_u $type37
                                                     (local.tee $2
                                                      (struct.get $type36 0
                                                       (local.get $3)
                                                      )
                                                     )
                                                     (i32.const 15)
                                                    )
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (i64.eq
                                                    (i64.extend_i32_u
                                                     (array.len
                                                      (local.get $2)
                                                     )
                                                    )
                                                    (i64.const 16)
                                                   )
                                                   (then
                                                    (i32.const 0)
                                                   )
                                                   (else
                                                    (call $foreign27
                                                     (i64.extend_i32_u
                                                      (array.get_u $type37
                                                       (local.tee $2
                                                        (struct.get $type36 0
                                                         (local.get $3)
                                                        )
                                                       )
                                                       (i32.const 16)
                                                      )
                                                     )
                                                    )
                                                    (if (result i32)
                                                     (i64.eq
                                                      (i64.extend_i32_u
                                                       (array.len
                                                        (local.get $2)
                                                       )
                                                      )
                                                      (i64.const 17)
                                                     )
                                                     (then
                                                      (i32.const 0)
                                                     )
                                                     (else
                                                      (call $foreign27
                                                       (i64.extend_i32_u
                                                        (array.get_u $type37
                                                         (local.tee $2
                                                          (struct.get $type36 0
                                                           (local.get $3)
                                                          )
                                                         )
                                                         (i32.const 17)
                                                        )
                                                       )
                                                      )
                                                      (if (result i32)
                                                       (i64.eq
                                                        (i64.extend_i32_u
                                                         (array.len
                                                          (local.get $2)
                                                         )
                                                        )
                                                        (i64.const 18)
                                                       )
                                                       (then
                                                        (i32.const 0)
                                                       )
                                                       (else
                                                        (call $foreign27
                                                         (i64.extend_i32_u
                                                          (array.get_u $type37
                                                           (struct.get $type36 0
                                                            (local.get $3)
                                                           )
                                                           (i32.const 18)
                                                          )
                                                         )
                                                        )
                                                        (return_call $function231
                                                         (local.get $3)
                                                         (i32.const 0)
                                                         (i32.const 1)
                                                         (i64.const 19)
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (call $foreign27
     (i64.const 0)
    )
    (i32.const 0)
   )
  )
 )
 (func $function229 (type $10) (param $0 (ref $type34)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global837)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function227
      (array.get $type34
       (local.get $0)
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function229
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function231 (type $9) (param $0 (ref $type36)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (struct.get $type36 0
       (local.get $0)
      )
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign27
     (i64.extend_i32_u
      (array.get_u $type37
       (struct.get $type36 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function231
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (result i64)
  (local $0 (ref $type58))
  (local $1 (ref $type140))
  (local $2 (ref $type140))
  (local $3 (ref $type18))
  (local $4 (ref $type13))
  (local $5 (ref $type56))
  (local $6 i32)
  (local $scratch (ref $type18))
  (local $scratch_8 (ref $type13))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready857)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global857)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global818)
   )
  )
  (drop
   (call $function41
    (block (result (ref $type18))
     (local.set $scratch
      (ref.as_non_null
       (global.get $global815)
      )
     )
     (if
      (i32.eqz
       (call $foreign26)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global792)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global799)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global120)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (local.set $0
   (struct.new $type58
    (struct.new $type56
     (call $foreign5)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global777)
   )
  )
  (local.set $1
   (call $function212
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global504)
   )
  )
  (drop
   (call $function227
    (block (result (ref $type13))
     (local.set $scratch_8
      (if (result (ref $type13))
       (if (result i32)
        (local.tee $6
         (struct.get $type140 0
          (local.get $1)
         )
        )
        (then
         (if
          (i32.eq
           (local.get $6)
           (i32.const 1)
          )
          (then
           (drop
            (ref.cast (ref $type142)
             (local.get $1)
            )
           )
          )
          (else
           (drop
            (ref.cast (ref $type143)
             (local.get $1)
            )
           )
          )
         )
         (i32.const 0)
        )
        (else
         (i32.const 1)
        )
       )
       (then
        (struct.new $type15
         (i32.const 1)
         (i32.const 0)
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global777)
         )
        )
        (local.set $2
         (call $function212
          (local.get $0)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global509)
         )
        )
        (call $function217
         (local.get $0)
         (i32.const 0)
         (i32.const 1)
         (local.get $2)
         (call $function150
          (local.get $1)
         )
         (i64.const 1)
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global127)
      )
     )
     (if
      (i32.eqz
       (global.get $ready124)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global124)
      )
     )
     (if
      (i32.ne
       (local.tee $6
        (struct.get $type56 0
         (local.tee $5
          (struct.get $type58 0
           (local.get $0)
          )
         )
        )
       )
       (i32.const -1)
      )
      (then
       (struct.set $type56 0
        (local.get $5)
        (i32.const -1)
       )
       (call $foreign6
        (local.get $6)
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global837)
      )
     )
     (local.get $scratch_8)
    )
   )
  )
  (i64.const 1)
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready817)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global817)
   )
  )
  (struct.get $type66 0
   (global.get $global809)
  )
 )
 (func $main
  (local $0 (ref $type140))
  (local $1 (ref $type58))
  (local $2 (ref $type13))
  (local $3 (ref $type24))
  (local $4 (ref $type66))
  (local $5 (ref $type56))
  (local $6 i32)
  (local $scratch (ref $type140))
  (local $scratch_8 (ref $type140))
  (local $scratch_9 (ref $type140))
  (local $scratch_10 (ref (exact $type66)))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global715
   (struct.new_default $type11)
  )
  (global.set $global718
   (struct.new_default $type40)
  )
  (global.set $ready718
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type41)
  )
  (global.set $global81
   (struct.new_default $type45)
  )
  (global.set $global88
   (struct.new_default $type46)
  )
  (global.set $global90
   (struct.new_default $type47)
  )
  (global.set $global93
   (struct.new_default $type49)
  )
  (global.set $ready93
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type50)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type51)
  )
  (global.set $global109
   (struct.new_default $type52)
  )
  (global.set $global120
   (struct.new_default $type57)
  )
  (global.set $global127
   (struct.new_default $type60)
  )
  (global.set $global124
   (struct.new_default $type61)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global799
   (struct.new_default $type62)
  )
  (global.set $global810
   (struct.new_default $type64)
  )
  (global.set $global133
   (struct.new_default $type71)
  )
  (global.set $global135
   (struct.new_default $type72)
  )
  (global.set $global137
   (struct.new_default $type72)
  )
  (global.set $global180
   (struct.new_default $type84)
  )
  (global.set $global317
   (struct.new_default $type111)
  )
  (global.set $global323
   (struct.new_default $type112)
  )
  (global.set $global325
   (struct.new_default $type53)
  )
  (global.set $global329
   (struct.new_default $type113)
  )
  (global.set $global334
   (struct.new_default $type115)
  )
  (global.set $global367
   (struct.new_default $type118)
  )
  (global.set $global370
   (struct.new_default $type119)
  )
  (global.set $global376
   (struct.new_default $type120)
  )
  (global.set $global379
   (struct.new_default $type125)
  )
  (global.set $global411
   (struct.new_default $type129)
  )
  (global.set $global424
   (struct.new_default $type132)
  )
  (global.set $global436
   (struct.new_default $type133)
  )
  (global.set $global504
   (struct.new_default $type139)
  )
  (global.set $global509
   (struct.new_default $type144)
  )
  (global.set $global514
   (struct.new_default $type145)
  )
  (global.set $global521
   (struct.new_default $type146)
  )
  (global.set $global541
   (struct.new_default $type147)
  )
  (global.set $global519
   (struct.new_default $type147)
  )
  (global.set $global527
   (struct.new_default $type148)
  )
  (global.set $global538
   (struct.new_default $type149)
  )
  (global.set $global525
   (struct.new_default $type150)
  )
  (global.set $global632
   (struct.new_default $type150)
  )
  (global.set $global551
   (struct.new_default $type151)
  )
  (global.set $global600
   (struct.new_default $type155)
  )
  (global.set $global604
   (struct.new_default $type156)
  )
  (global.set $ready604
   (i32.const 1)
  )
  (global.set $global557
   (struct.new_default $type157)
  )
  (global.set $global647
   (struct.new_default $type158)
  )
  (global.set $global655
   (struct.new_default $type46)
  )
  (global.set $global530
   (struct.new_default $type60)
  )
  (global.set $ready530
   (i32.const 1)
  )
  (global.set $global624
   (struct.new_default $type159)
  )
  (global.set $ready624
   (i32.const 1)
  )
  (global.set $global619
   (struct.new_default $type160)
  )
  (global.set $global516
   (struct.new_default $type160)
  )
  (global.set $ready516
   (i32.const 1)
  )
  (global.set $global535
   (struct.new_default $type169)
  )
  (global.set $ready535
   (i32.const 1)
  )
  (global.set $global616
   (struct.new_default $type160)
  )
  (global.set $ready616
   (i32.const 1)
  )
  (global.set $global673
   (struct.new_default $type160)
  )
  (global.set $ready673
   (i32.const 1)
  )
  (global.set $global675
   (struct.new_default $type170)
  )
  (global.set $ready675
   (i32.const 1)
  )
  (global.set $global686
   (struct.new_default $type170)
  )
  (global.set $ready686
   (i32.const 1)
  )
  (global.set $global543
   (struct.new_default $type171)
  )
  (global.set $ready543
   (i32.const 1)
  )
  (global.set $global548
   (struct.new_default $type172)
  )
  (global.set $ready548
   (i32.const 1)
  )
  (global.set $global552
   (struct.new_default $type176)
  )
  (global.set $ready552
   (i32.const 1)
  )
  (global.set $global610
   (struct.new_default $type177)
  )
  (global.set $ready610
   (i32.const 1)
  )
  (global.set $global593
   (struct.new_default $type178)
  )
  (global.set $ready593
   (i32.const 1)
  )
  (global.set $global559
   (struct.new_default $type183)
  )
  (global.set $ready559
   (i32.const 1)
  )
  (global.set $global580
   (struct.new_default $type150)
  )
  (global.set $ready580
   (i32.const 1)
  )
  (global.set $global590
   (struct.new_default $type60)
  )
  (global.set $ready590
   (i32.const 1)
  )
  (global.set $global585
   (struct.new_default $type184)
  )
  (global.set $ready585
   (i32.const 1)
  )
  (global.set $global577
   (struct.new_default $type97)
  )
  (global.set $global573
   (struct.new_default $type150)
  )
  (global.set $global570
   (struct.new_default $type185)
  )
  (global.set $global565
   (struct.new_default $type186)
  )
  (global.set $ready565
   (i32.const 1)
  )
  (global.set $global663
   (struct.new_default $type187)
  )
  (global.set $global629
   (struct.new_default $type160)
  )
  (global.set $ready629
   (i32.const 1)
  )
  (global.set $global652
   (struct.new_default $type170)
  )
  (global.set $ready652
   (i32.const 1)
  )
  (global.set $global661
   (struct.new_default $type187)
  )
  (global.set $ready661
   (i32.const 1)
  )
  (global.set $global691
   (struct.new_default $type188)
  )
  (global.set $ready691
   (i32.const 1)
  )
  (global.set $global769
   (struct.new_default $type189)
  )
  (global.set $ready769
   (i32.const 1)
  )
  (global.set $global698
   (struct.new_default $type190)
  )
  (global.set $ready698
   (i32.const 1)
  )
  (global.set $global759
   (struct.new_default $type191)
  )
  (global.set $ready759
   (i32.const 1)
  )
  (global.set $global745
   (struct.new_default $type192)
  )
  (global.set $ready745
   (i32.const 1)
  )
  (global.set $global707
   (struct.new_default $type193)
  )
  (global.set $ready707
   (i32.const 1)
  )
  (global.set $global710
   (struct.new_default $type194)
  )
  (global.set $global704
   (struct.new_default $type195)
  )
  (global.set $ready704
   (i32.const 1)
  )
  (global.set $global726
   (struct.new_default $type196)
  )
  (global.set $ready726
   (i32.const 1)
  )
  (global.set $global737
   (struct.new_default $type132)
  )
  (global.set $global732
   (struct.new_default $type197)
  )
  (global.set $ready732
   (i32.const 1)
  )
  (global.set $global777
   (struct.new_default $type145)
  )
  (global.set $global785
   (struct.new_default $type132)
  )
  (global.set $global792
   (struct.new_default $type200)
  )
  (global.set $global804
   (struct.new_default $type65)
  )
  (drop
   (ref.as_non_null
    (global.get $global804)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global810)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string54)
   )
  )
  (local.set $1
   (struct.new $type58
    (struct.new $type56
     (call $foreign5)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global777)
   )
  )
  (local.set $2
   (call $function150
    (block (result (ref $type140))
     (local.set $scratch
      (call $function212
       (local.get $1)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global509)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global785)
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (local.get $2)
    )
    (i32.const 5)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global809
   (block (result (ref (exact $type66)))
    (local.set $scratch_10
     (struct.new $type66
      (if (result i64)
       (struct.get $type24 0
        (local.tee $3
         (struct.get $type23 1
          (ref.cast (ref $type23)
           (local.get $2)
          )
         )
        )
       )
       (then
        (if
         (i32.eq
          (struct.get $type24 0
           (local.get $3)
          )
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type26)
            (local.get $3)
           )
          )
         )
         (else
          (drop
           (ref.cast (ref $type27)
            (local.get $3)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global323)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global317)
         )
        )
        (call $foreign12
         (call $function104
          (global.get $string53)
         )
        )
        (unreachable)
       )
       (else
        (struct.get $type25 1
         (ref.cast (ref $type25)
          (local.get $3)
         )
        )
       )
      )
      (block (result (ref $type18))
       (drop
        (ref.as_non_null
         (global.get $global777)
        )
       )
       (if
        (i32.ne
         (struct.get $type13 0
          (local.tee $2
           (call $function150
            (block (result (ref $type140))
             (local.set $scratch_8
              (call $function212
               (local.get $1)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global509)
              )
             )
             (local.get $scratch_8)
            )
           )
          )
         )
         (i32.const 3)
        )
        (then
         (unreachable)
        )
       )
       (struct.get $type17 1
        (ref.cast (ref $type17)
         (local.get $2)
        )
       )
      )
      (block (result (ref $type13))
       (drop
        (ref.as_non_null
         (global.get $global777)
        )
       )
       (call $function150
        (block (result (ref $type140))
         (local.set $scratch_9
          (call $function212
           (local.get $1)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global509)
          )
         )
         (local.get $scratch_9)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.ne
      (local.tee $6
       (struct.get $type56 0
        (local.tee $5
         (struct.get $type58 0
          (local.get $1)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (struct.set $type56 0
       (local.get $5)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $6)
      )
     )
    )
    (local.get $scratch_10)
   )
  )
  (global.set $global815
   (struct.get $type66 1
    (global.get $global809)
   )
  )
  (drop
   (struct.get $type66 2
    (global.get $global809)
   )
  )
  (global.set $global817
   (struct.new_default $type5)
  )
  (global.set $ready817
   (i32.const 1)
  )
  (global.set $global818
   (struct.new_default $type201)
  )
  (global.set $global821
   (struct.new_default $type52)
  )
  (global.set $global825
   (struct.new_default $type202)
  )
  (global.set $global830
   (struct.new_default $type203)
  )
  (global.set $global837
   (struct.new_default $type204)
  )
  (global.set $ready837
   (i32.const 1)
  )
  (global.set $global848
   (struct.new_default $type205)
  )
  (global.set $ready848
   (i32.const 1)
  )
  (global.set $global853
   (struct.new_default $type206)
  )
  (global.set $ready853
   (i32.const 1)
  )
  (global.set $global857
   (struct.new_default $type5)
  )
  (global.set $ready857
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

