(import (chezscheme))
(parameterize ((optimize-level 2))
  (compile-program "/tmp/snail-reader-combined-ablation-20261014/build/reader-combined-prepared/sum1/chez-adapted/program.scm" "/tmp/snail-reader-combined-ablation-20261014/build/reader-combined-prepared/sum1/chez-adapted/program.so"))
