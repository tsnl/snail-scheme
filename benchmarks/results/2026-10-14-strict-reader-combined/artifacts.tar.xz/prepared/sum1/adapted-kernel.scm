(: sumport (-> InputPort F64 F64))
(: sum (-> InputPort F64))
(: go (-> String F64))
;;; SUM1 -- One of the Kernighan and Van Wyk benchmarks.


(define (sumport port sum-so-far)
  (let ((x (workload-read port)))
    (if (read-end? x)
        sum-so-far
        (sumport port (+ (real-datum (read-value! x)) sum-so-far)))))

(define (sum port)
  (sumport port 0.0))

(define (go input)
  (call-with-input-file input sum))

