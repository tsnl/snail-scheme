#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include "native-provider.h"
extern void native_host_init(int, char **);
extern void native_module_init(void);
extern int native_finish(int);
extern uint64_t native_resource_release_count(void);
extern void guest_main(void) __asm__("wasm.main");
extern int64_t observe_once(void) __asm__("wasm.observe-once");
int main(int argc, char **argv) {
    native_host_init(argc, argv); native_module_init(); guest_main();
    uint64_t setup = native_resource_release_count();
    puts("call:0");
    if (observe_once() != 1) return native_finish(2);
    if (argc == 3) {
        FILE *input = fopen(argv[1], "rb"), *output = fopen(argv[2], "wb");
        if (!input || !output) {
            if (input) fclose(input);
            if (output) fclose(output);
            return native_finish(3);
        }
        int byte, failed = 0;
        while ((byte = fgetc(input)) != EOF) {
            if (fputc(byte, output) == EOF) { failed = 1; break; }
        }
        failed |= ferror(input);
        failed |= fclose(input) != 0;
        failed |= fclose(output) != 0;
        if (failed) return native_finish(5);
        puts("call:1");
        if (observe_once() != 1) return native_finish(6);
    }
    uint64_t worker = native_resource_release_count() - setup;
    int status = native_finish(0);
    printf("{\"result\":1,\"barriers\":%" PRIu64 ",\"setup_closed\":%" PRIu64
           ",\"worker_closed\":%" PRIu64 "}\n", reader_barriers(), setup, worker);
    return status;
}
