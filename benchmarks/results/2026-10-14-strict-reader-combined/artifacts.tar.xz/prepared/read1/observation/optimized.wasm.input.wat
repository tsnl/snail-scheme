(module
 (rec
  (type $type13 (sub (struct (field i32))))
  (type $type175 (sub (struct)))
  (type $type181 (sub (struct (field i32))))
  (type $type163 (sub (struct (field i32))))
  (type $type68 (sub (struct)))
  (type $type130 (sub (struct (field i32))))
  (type $type121 (sub (struct (field i32))))
  (type $type24 (sub (struct (field i32))))
  (type $type28 (sub (struct)))
  (type $9 (func (param (ref $type36) i32 i32 i64) (result i32)))
  (type $10 (func (param (ref $type34) i32 i32 i64) (result i32)))
  (type $call206 (func (param (ref $type13)) (result i32)))
  (type $12 (func (param (ref $type18) i32 i32 i64) (result i32)))
  (type $call65 (func (param (ref $type58)) (result (ref $type66))))
  (type $14 (func (param (ref $type58) i32 i32 (ref $type130) (ref $type13) i64) (result (ref $type13))))
  (type $call147 (func (param (ref $type58)) (result (ref $type130))))
  (type $type35 (sub $type13 (struct (field i32) (field (ref $type36)))))
  (type $call199 (func (param (ref null $type12) (ref $type36) i64) (result (ref $type130))))
  (type $18 (func (param (ref $type34) i32 i32 (ref null $type12) i64) (result (ref $type34))))
  (type $19 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $20 (func (param i32 i32 (ref null $type12) (ref $type12)) (result (ref null $type12))))
  (type $call195 (func (param (ref null $type12) (ref $type31)) (result (ref $type13))))
  (type $type36 (struct (field (ref $type37))))
  (type $type37 (array (mut i8)))
  (type $type33 (sub $type13 (struct (field i32) (field (ref $type34)))))
  (type $type34 (array (mut (ref $type13))))
  (type $type12 (struct (field (ref $type13)) (field (ref null $type12))))
  (type $27 (func (param (ref $type58) i64 (ref null $type12)) (result (ref $type130))))
  (type $type31 (sub $type13 (struct (field i32) (field (ref $type32)) (field (ref $type32)))))
  (type $type32 (struct (field (ref $type13))))
  (type $call190 (func (param (ref $type58) (ref $type163)) (result (ref $type130))))
  (type $31 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type181))))
  (type $32 (func (param (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $33 (func (param (ref $type58) (ref $type154) i32 i32) (result (ref $type18))))
  (type $call152 (func (param i64) (result i32)))
  (type $call161 (func (param (ref $type58) i64) (result i32)))
  (type $36 (func (param (ref $type154) i32)))
  (type $call186 (func (param (ref $type58) i64) (result (ref $type181))))
  (type $call188 (func (param (ref $type58) i64 i64) (result (ref $type181))))
  (type $call178 (func (param (ref $type58) i32 (ref $type154)) (result (ref $type175))))
  (type $type177 (sub $type175 (struct (field (ref $type18)))))
  (type $type17 (sub $type13 (struct (field i32) (field (ref $type18)))))
  (type $type176 (sub $type175 (struct (field (ref $type18)))))
  (type $call173 (func (param (ref $type58) i32 i32) (result (ref $type163))))
  (type $call60 (func (param (ref $type58)) (result i32)))
  (type $call149 (func (param (ref $type58)) (result i64)))
  (type $type21 (sub $type13 (struct (field i32) (field (ref $type22)))))
  (type $type22 (struct (field i32)))
  (type $type23 (sub $type13 (struct (field i32) (field (ref $type24)))))
  (type $type15 (sub $type13 (struct (field i32) (field i32))))
  (type $type184 (sub $type181 (struct (field i32) (field (ref $type18)))))
  (type $type182 (sub $type181 (struct (field i32) (field i32))))
  (type $type156 (struct (field (mut i64))))
  (type $type155 (struct (field (mut (ref $type18)))))
  (type $type164 (sub $type163 (struct (field i32) (field (ref $type13)))))
  (type $type16 (sub $type13 (struct (field i32) (field i32))))
  (type $type170 (sub $type163 (struct (field i32) (field (ref $type18)))))
  (type $type169 (sub $type163 (struct (field i32) (field (ref $type18)))))
  (type $type168 (sub $type163 (struct (field i32) (field i64))))
  (type $type70 (sub $type68 (struct (field i32))))
  (type $type56 (struct (field (mut i32))))
  (type $type58 (struct (field (ref $type56))))
  (type $type154 (struct (field (ref $type155)) (field (ref $type156))))
  (type $call162 (func (param (ref $type58)) (result (ref $type163))))
  (type $type133 (sub $type130 (struct (field i32) (field (ref $type18)))))
  (type $type132 (sub $type130 (struct (field i32) (field (ref $type13)))))
  (type $call146 (func (param (ref $type130)) (result (ref $type13))))
  (type $type124 (sub $type121 (struct (field i32) (field (ref $type18)))))
  (type $type27 (sub $type24 (struct (field i32) (field (ref $type28)) (field (ref $type28)))))
  (type $type30 (sub $type28 (struct (field f64))))
  (type $type29 (sub $type28 (struct (field i64))))
  (type $type26 (sub $type24 (struct (field i32) (field f64))))
  (type $type123 (sub $type121 (struct (field i32) (field (ref $type24)))))
  (type $type25 (sub $type24 (struct (field i32) (field i64))))
  (type $call120 (func (param i32 i32) (result (ref $type121))))
  (type $75 (func (param i32 i64 (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $76 (func (param (ref $type18) i32 i64 i32 i32 i64) (result i32)))
  (type $call111 (func (param (ref $type18)) (result i32)))
  (type $78 (func (param (ref $type18) i64 i32 i32 i64) (result i32)))
  (type $call52 (func (param (ref $type18)) (result i32)))
  (type $80 (func (param (ref $type18) (ref $type18) i32 i32 i64) (result i32)))
  (type $call50 (func (param (ref $type18) (ref null $type48) i64) (result i32)))
  (type $82 (func (param i32 i32 (ref null $type48) i64) (result i64)))
  (type $type48 (struct (field (ref $type18)) (field (ref null $type48))))
  (type $call47 (func (param (ref $type48)) (result (ref $type18))))
  (type $85 (func (param (ref $type18) i64 (ref $type18) i64)))
  (type $86 (func (param (ref $type18) i32) (result (ref $type19))))
  (type $type20 (array (mut (ref null $type19))))
  (type $88 (func (param i32) (result (ref $type18))))
  (type $type208 (struct))
  (type $type207 (struct))
  (type $type205 (struct))
  (type $type203 (struct))
  (type $type5 (struct))
  (type $type65 (struct))
  (type $type202 (struct))
  (type $type198 (struct))
  (type $type197 (struct))
  (type $type196 (struct))
  (type $type194 (struct))
  (type $type193 (struct))
  (type $type191 (struct))
  (type $type189 (struct))
  (type $type185 (struct))
  (type $type180 (struct))
  (type $type179 (struct))
  (type $type174 (struct))
  (type $type172 (struct))
  (type $type171 (struct))
  (type $type158 (struct))
  (type $type139 (struct))
  (type $type138 (struct))
  (type $type134 (struct))
  (type $type129 (struct))
  (type $type125 (struct))
  (type $type119 (struct))
  (type $type115 (struct))
  (type $type84 (struct))
  (type $type64 (struct))
  (type $type62 (struct))
  (type $type49 (struct))
  (type $type40 (struct))
  (type $type11 (struct))
  (type $type204 (struct))
  (type $type199 (struct))
  (type $type188 (struct))
  (type $type187 (struct))
  (type $type97 (struct))
  (type $type186 (struct))
  (type $type178 (struct))
  (type $type173 (struct))
  (type $type159 (struct))
  (type $type152 (struct))
  (type $type145 (struct))
  (type $type120 (struct))
  (type $type118 (struct))
  (type $type113 (struct))
  (type $type61 (struct))
  (type $type60 (struct))
  (type $type57 (struct))
  (type $type52 (struct))
  (type $type46 (struct))
  (type $type66 (struct (field i64) (field (ref $type18)) (field (ref $type13))))
  (type $type192 (struct))
  (type $type160 (struct))
  (type $type47 (struct))
  (type $type161 (struct))
  (type $type153 (struct))
  (type $type45 (struct))
  (type $type190 (struct))
  (type $type146 (struct))
  (type $type112 (struct))
  (type $type147 (struct))
  (type $type157 (struct))
  (type $type151 (struct))
  (type $type50 (struct))
  (type $type206 (struct))
  (type $type162 (struct))
  (type $type111 (struct))
  (type $type149 (struct))
  (type $type135 (struct))
  (type $type195 (struct))
  (type $type41 (struct))
  (type $type51 (struct))
  (type $type72 (struct))
  (type $type148 (struct))
  (type $type71 (struct))
  (type $type150 (struct))
  (type $type183 (sub $type181 (struct (field i32))))
  (type $type167 (sub $type163 (struct (field i32))))
  (type $type166 (sub $type163 (struct (field i32))))
  (type $type165 (sub $type163 (struct (field i32))))
  (type $type131 (sub $type130 (struct (field i32))))
  (type $type122 (sub $type121 (struct (field i32))))
  (type $type14 (sub $type13 (struct (field i32))))
  (type $type18 (struct (field i32) (field i32) (field (ref $type19)) (field (ref null $type20))))
  (type $type19 (array (mut i32)))
  (type $type69 (sub $type68 (struct)))
 )
 (type $178 (func (param i32) (result i32)))
 (type $179 (func (param i32)))
 (type $180 (func (result i32)))
 (type $181 (func (param i32 i32) (result i32)))
 (type $182 (func))
 (type $183 (func (result i64)))
 (type $184 (func (param i32 i32)))
 (type $185 (func (param i32) (result i64)))
 (type $186 (func (param i32 i32) (result f64)))
 (type $187 (func (param i32 i32) (result i64)))
 (type $188 (func (param i64)))
 (type $189 (func (param f64)))
 (import "snail.library" "snail:io/path-begin" (func $foreign0))
 (import "snail.library" "snail:io/path-character" (func $foreign1 (param i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign5 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign6 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign7 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign8 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-open" (func $foreign10 (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign11 (param i32 i32)))
 (import "snail.library" "snail:datum/fail" (func $foreign12 (param i32)))
 (import "snail.library" "snail:datum/token-identifier" (func $foreign13 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign14 (param i32)))
 (import "snail.library" "snail:datum/token-intern" (func $foreign15 (param i32) (result i32)))
 (import "snail.library" "snail:datum/symbol-length" (func $foreign16 (param i32) (result i64)))
 (import "snail.library" "snail:datum/symbol-character" (func $foreign17 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign18 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign19 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign20 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/error-length" (func $foreign21 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign22 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse" (func $foreign23 (param i32) (result i32)))
 (import "snail.library" "snail:datum/whitespace" (func $foreign25 (param i32) (result i32)))
 (import "benchmark" "barrier" (func $foreign26 (result i32)))
 (import "reader.test" "emit_i64" (func $foreign27 (param i64)))
 (import "reader.test" "emit_char" (func $foreign28 (param i32)))
 (import "reader.test" "emit_f64" (func $foreign29 (param f64)))
 (global $global538 (mut (ref null $type150)) (ref.null none))
 (global $global133 (mut (ref null $type71)) (ref.null none))
 (global $empty69 (ref $type69) (struct.new_default $type69))
 (global $global532 (mut (ref null $type148)) (ref.null none))
 (global $global135 (mut (ref null $type72)) (ref.null none))
 (global $global103 (mut (ref null $type51)) (ref.null none))
 (global $global61 (mut (ref null $type41)) (ref.null none))
 (global $global718 (mut (ref null $type195)) (ref.null none))
 (global $global137 (mut (ref null $type72)) (ref.null none))
 (global $global422 (mut (ref null $type135)) (ref.null none))
 (global $global552 (mut (ref null $type149)) (ref.null none))
 (global $global530 (mut (ref null $type149)) (ref.null none))
 (global $ready718 (mut i32) (i32.const 0))
 (global $global317 (mut (ref null $type111)) (ref.null none))
 (global $global527 (mut (ref null $type162)) (ref.null none))
 (global $global848 (mut (ref null $type206)) (ref.null none))
 (global $global98 (mut (ref null $type50)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global549 (mut (ref null $type151)) (ref.null none))
 (global $global611 (mut (ref null $type157)) (ref.null none))
 (global $global788 (mut (ref null $type147)) (ref.null none))
 (global $global323 (mut (ref null $type112)) (ref.null none))
 (global $global520 (mut (ref null $type146)) (ref.null none))
 (global $ready527 (mut i32) (i32.const 0))
 (global $global702 (mut (ref null $type190)) (ref.null none))
 (global $execution (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type45)) (ref.null none))
 (global $global525 (mut (ref null $type147)) (ref.null none))
 (global $global562 (mut (ref null $type153)) (ref.null none))
 (global $global635 (mut (ref null $type161)) (ref.null none))
 (global $ready702 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type47)) (ref.null none))
 (global $global658 (mut (ref null $type160)) (ref.null none))
 (global $ready635 (mut i32) (i32.const 0))
 (global $global709 (mut (ref null $type192)) (ref.null none))
 (global $global820 (mut (ref null $type66)) (ref.null none))
 (global $global88 (mut (ref null $type46)) (ref.null none))
 (global $global109 (mut (ref null $type52)) (ref.null none))
 (global $global120 (mut (ref null $type57)) (ref.null none))
 (global $global127 (mut (ref null $type60)) (ref.null none))
 (global $global124 (mut (ref null $type61)) (ref.null none))
 (global $ready124 (mut i32) (i32.const 0))
 (global $global329 (mut (ref null $type113)) (ref.null none))
 (global $global367 (mut (ref null $type118)) (ref.null none))
 (global $global376 (mut (ref null $type120)) (ref.null none))
 (global $global515 (mut (ref null $type145)) (ref.null none))
 (global $global536 (mut (ref null $type152)) (ref.null none))
 (global $global643 (mut (ref null $type152)) (ref.null none))
 (global $global568 (mut (ref null $type159)) (ref.null none))
 (global $global666 (mut (ref null $type46)) (ref.null none))
 (global $global541 (mut (ref null $type60)) (ref.null none))
 (global $global554 (mut (ref null $type173)) (ref.null none))
 (global $ready554 (mut i32) (i32.const 0))
 (global $global563 (mut (ref null $type178)) (ref.null none))
 (global $ready563 (mut i32) (i32.const 0))
 (global $global601 (mut (ref null $type60)) (ref.null none))
 (global $global596 (mut (ref null $type186)) (ref.null none))
 (global $ready596 (mut i32) (i32.const 0))
 (global $global588 (mut (ref null $type97)) (ref.null none))
 (global $global584 (mut (ref null $type152)) (ref.null none))
 (global $global581 (mut (ref null $type187)) (ref.null none))
 (global $global576 (mut (ref null $type188)) (ref.null none))
 (global $ready576 (mut i32) (i32.const 0))
 (global $ready709 (mut i32) (i32.const 0))
 (global $global743 (mut (ref null $type199)) (ref.null none))
 (global $ready743 (mut i32) (i32.const 0))
 (global $global832 (mut (ref null $type52)) (ref.null none))
 (global $global836 (mut (ref null $type204)) (ref.null none))
 (global $ready848 (mut i32) (i32.const 0))
 (global $string2 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string12 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 85)
   (i32.const 110)
   (i32.const 105)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $empty14 (ref $type14) (struct.new $type14
  (i32.const 0)
 ))
 (global $global726 (mut (ref null $type11)) (ref.null none))
 (global $global729 (mut (ref null $type40)) (ref.null none))
 (global $ready729 (mut i32) (i32.const 0))
 (global $global93 (mut (ref null $type49)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global810 (mut (ref null $type62)) (ref.null none))
 (global $global821 (mut (ref null $type64)) (ref.null none))
 (global $global180 (mut (ref null $type84)) (ref.null none))
 (global $global334 (mut (ref null $type115)) (ref.null none))
 (global $global370 (mut (ref null $type119)) (ref.null none))
 (global $global379 (mut (ref null $type125)) (ref.null none))
 (global $global411 (mut (ref null $type129)) (ref.null none))
 (global $global418 (mut (ref null $type134)) (ref.null none))
 (global $global435 (mut (ref null $type138)) (ref.null none))
 (global $global447 (mut (ref null $type139)) (ref.null none))
 (global $global615 (mut (ref null $type158)) (ref.null none))
 (global $ready615 (mut i32) (i32.const 0))
 (global $ready541 (mut i32) (i32.const 0))
 (global $global630 (mut (ref null $type162)) (ref.null none))
 (global $global546 (mut (ref null $type171)) (ref.null none))
 (global $ready546 (mut i32) (i32.const 0))
 (global $global627 (mut (ref null $type162)) (ref.null none))
 (global $ready627 (mut i32) (i32.const 0))
 (global $global684 (mut (ref null $type162)) (ref.null none))
 (global $ready684 (mut i32) (i32.const 0))
 (global $global686 (mut (ref null $type172)) (ref.null none))
 (global $ready686 (mut i32) (i32.const 0))
 (global $global697 (mut (ref null $type172)) (ref.null none))
 (global $ready697 (mut i32) (i32.const 0))
 (global $global559 (mut (ref null $type174)) (ref.null none))
 (global $ready559 (mut i32) (i32.const 0))
 (global $global621 (mut (ref null $type179)) (ref.null none))
 (global $ready621 (mut i32) (i32.const 0))
 (global $global604 (mut (ref null $type180)) (ref.null none))
 (global $ready604 (mut i32) (i32.const 0))
 (global $global570 (mut (ref null $type185)) (ref.null none))
 (global $ready570 (mut i32) (i32.const 0))
 (global $global591 (mut (ref null $type152)) (ref.null none))
 (global $ready591 (mut i32) (i32.const 0))
 (global $ready601 (mut i32) (i32.const 0))
 (global $global674 (mut (ref null $type189)) (ref.null none))
 (global $global640 (mut (ref null $type162)) (ref.null none))
 (global $ready640 (mut i32) (i32.const 0))
 (global $global663 (mut (ref null $type172)) (ref.null none))
 (global $ready663 (mut i32) (i32.const 0))
 (global $global672 (mut (ref null $type189)) (ref.null none))
 (global $ready672 (mut i32) (i32.const 0))
 (global $global780 (mut (ref null $type191)) (ref.null none))
 (global $ready780 (mut i32) (i32.const 0))
 (global $global770 (mut (ref null $type193)) (ref.null none))
 (global $ready770 (mut i32) (i32.const 0))
 (global $global756 (mut (ref null $type194)) (ref.null none))
 (global $ready756 (mut i32) (i32.const 0))
 (global $global721 (mut (ref null $type196)) (ref.null none))
 (global $global715 (mut (ref null $type197)) (ref.null none))
 (global $ready715 (mut i32) (i32.const 0))
 (global $global737 (mut (ref null $type198)) (ref.null none))
 (global $ready737 (mut i32) (i32.const 0))
 (global $global748 (mut (ref null $type138)) (ref.null none))
 (global $global796 (mut (ref null $type138)) (ref.null none))
 (global $global803 (mut (ref null $type202)) (ref.null none))
 (global $global815 (mut (ref null $type65)) (ref.null none))
 (global $global826 (mut (ref null $type18)) (ref.null none))
 (global $global828 (mut (ref null $type5)) (ref.null none))
 (global $ready828 (mut i32) (i32.const 0))
 (global $global829 (mut (ref null $type203)) (ref.null none))
 (global $global841 (mut (ref null $type205)) (ref.null none))
 (global $global859 (mut (ref null $type207)) (ref.null none))
 (global $ready859 (mut i32) (i32.const 0))
 (global $global864 (mut (ref null $type208)) (ref.null none))
 (global $ready864 (mut i32) (i32.const 0))
 (global $global868 (mut (ref null $type5)) (ref.null none))
 (global $ready868 (mut i32) (i32.const 0))
 (global $string1 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 71)
  (array.new_fixed $type19 71
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 102)
   (i32.const 105)
   (i32.const 101)
   (i32.const 114)
   (i32.const 59)
   (i32.const 32)
   (i32.const 114)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 44)
  (array.new_fixed $type19 44
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 44)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 102)
   (i32.const 105)
   (i32.const 108)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string4 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 105)
   (i32.const 109)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string5 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string6 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 16)
  (array.new_fixed $type19 16
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 45)
   (i32.const 115)
   (i32.const 112)
   (i32.const 108)
   (i32.const 105)
   (i32.const 99)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
  )
  (ref.null none)
 ))
 (global $string7 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 10)
  (array.new_fixed $type19 10
   (i32.const 113)
   (i32.const 117)
   (i32.const 97)
   (i32.const 115)
   (i32.const 105)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string8 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string9 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 109)
   (i32.const 98)
   (i32.const 111)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string10 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string11 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 104)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 99)
   (i32.const 105)
   (i32.const 109)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string13 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 110)
   (i32.const 117)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string14 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 99)
   (i32.const 101)
   (i32.const 101)
   (i32.const 100)
   (i32.const 115)
   (i32.const 32)
   (i32.const 83)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
  )
  (ref.null none)
 ))
 (global $string15 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 35)
  )
  (ref.null none)
 ))
 (global $string16 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 108)
   (i32.const 97)
   (i32.const 98)
   (i32.const 101)
   (i32.const 108)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string17 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 115)
   (i32.const 101)
   (i32.const 32)
   (i32.const 100)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string18 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 98)
   (i32.const 108)
   (i32.const 111)
   (i32.const 99)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string19 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string20 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string21 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string22 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 25)
  (array.new_fixed $type19 25
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string23 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 116)
   (i32.const 97)
   (i32.const 98)
  )
  (ref.null none)
 ))
 (global $string24 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string25 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 116)
   (i32.const 117)
   (i32.const 114)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string26 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 110)
   (i32.const 117)
   (i32.const 108)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string27 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string28 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string29 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string30 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 98)
   (i32.const 97)
   (i32.const 99)
   (i32.const 107)
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string31 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string32 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 22)
  (array.new_fixed $type19 22
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string33 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type19 31
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 117)
   (i32.const 56)
   (i32.const 40)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string34 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string35 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 102)
  )
  (ref.null none)
 ))
 (global $string36 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 35)
   (i32.const 102)
   (i32.const 97)
   (i32.const 108)
   (i32.const 115)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string37 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string38 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 35)
   (i32.const 116)
   (i32.const 114)
   (i32.const 117)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string39 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 46)
  )
  (ref.null none)
 ))
 (global $string40 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 14)
  (array.new_fixed $type19 14
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string41 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 112)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 104)
   (i32.const 101)
   (i32.const 115)
   (i32.const 105)
   (i32.const 115)
  )
  (ref.null none)
 ))
 (global $string42 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 112)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 100)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string43 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 115)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string44 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 42)
  (array.new_fixed $type19 42
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 91)
   (i32.const 48)
   (i32.const 44)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
   (i32.const 93)
  )
  (ref.null none)
 ))
 (global $string45 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 109)
   (i32.const 105)
   (i32.const 115)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string46 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 36)
  (array.new_fixed $type19 36
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string47 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 33)
  (array.new_fixed $type19 33
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string48 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string49 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 117)
   (i32.const 110)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string50 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string51 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string53 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 98)
   (i32.const 101)
   (i32.const 110)
   (i32.const 99)
   (i32.const 104)
   (i32.const 109)
   (i32.const 97)
   (i32.const 114)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 109)
   (i32.const 117)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string54 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 46)
   (i32.const 116)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $empty122 (ref $type122) (struct.new $type122
  (i32.const 0)
 ))
 (global $empty131 (ref $type131) (struct.new $type131
  (i32.const 0)
 ))
 (global $empty165 (ref $type165) (struct.new $type165
  (i32.const 1)
 ))
 (global $empty166 (ref $type166) (struct.new $type166
  (i32.const 2)
 ))
 (global $empty167 (ref $type167) (struct.new $type167
  (i32.const 3)
 ))
 (global $empty183 (ref $type183) (struct.new $type183
  (i32.const 1)
 ))
 (export "observe-once" (func $export0))
 (export "configured-count" (func $export1))
 (export "main" (func $main))
 (func $string-new (type $88) (param $0 i32) (result (ref $type18))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type20))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type20
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type20
      (local.get $5)
      (local.get $2)
      (array.new_default $type19
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type18
   (i32.const 1)
   (local.get $0)
   (array.new_default $type19
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-block (type $86) (param $0 (ref $type18)) (param $1 i32) (result (ref $type19))
  (if (result (ref $type19))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type18 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type20
      (struct.get $type18 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy (type $85) (param $0 (ref $type18)) (param $1 i64) (param $2 (ref $type18)) (param $3 i64)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ne
     (local.get $1)
     (i64.const 0)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (local.get $3)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $4
     (local.get $7)
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $6
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $4)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $6)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $4
           (i32.sub
            (local.get $4)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $4)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $4)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $8
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $9
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (loop $label1
     (if
      (local.get $9)
      (then
       (local.set $4
        (select
         (local.get $9)
         (local.tee $4
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $5
              (i32.and
               (local.get $8)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $4
            (i32.sub
             (i32.const 8192)
             (local.tee $7
              (i32.and
               (local.get $10)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.gt_u
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i32.gt_u
          (local.get $4)
          (local.get $9)
         )
        )
       )
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $8)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $5)
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $10)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $10)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $7)
        (local.get $4)
       )
       (local.set $8
        (i32.add
         (local.get $4)
         (local.get $8)
        )
       )
       (local.set $10
        (i32.add
         (local.get $4)
         (local.get $10)
        )
       )
       (local.set $9
        (i32.sub
         (local.get $9)
         (local.get $4)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function35 (type $call47) (param $0 (ref $type48)) (result (ref $type18))
  (local $1 (ref null $type48))
  (local $2 (ref null $type48))
  (local $3 (ref null $type48))
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 i64)
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $6
   (if (result i64)
    (i64.gt_u
     (local.tee $6
      (i64.extend_i32_u
       (struct.get $type18 1
        (struct.get $type48 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type48 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $6)
      )
      (else
       (local.set $3
        (struct.get $type48 1
         (local.get $1)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $6
          (i64.add
           (i64.extend_i32_u
            (struct.get $type18 1
             (struct.get $type48 0
              (local.get $1)
             )
            )
           )
           (local.get $6)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (local.get $6)
          )
          (else
           (local.set $2
            (struct.get $type48 1
             (local.get $3)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $6
              (i64.add
               (i64.extend_i32_u
                (struct.get $type18 1
                 (struct.get $type48 0
                  (local.get $3)
                 )
                )
               )
               (local.get $6)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $1
                (struct.get $type48 1
                 (local.get $2)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $6
                  (i64.add
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (struct.get $type48 0
                      (local.get $2)
                     )
                    )
                   )
                   (local.get $6)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $2
                    (struct.get $type48 1
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.tee $6
                      (i64.add
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (struct.get $type48 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.get $6)
                      )
                     )
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $1
                        (struct.get $type48 1
                         (local.get $2)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.tee $6
                          (i64.add
                           (i64.extend_i32_u
                            (struct.get $type18 1
                             (struct.get $type48 0
                              (local.get $2)
                             )
                            )
                           )
                           (local.get $6)
                          )
                         )
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $2
                            (struct.get $type48 1
                             (local.get $1)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.tee $6
                              (i64.add
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (struct.get $type48 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (local.get $6)
                              )
                             )
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (local.get $6)
                              )
                              (else
                               (local.set $1
                                (struct.get $type48 1
                                 (local.get $2)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.tee $6
                                  (i64.add
                                   (i64.extend_i32_u
                                    (struct.get $type18 1
                                     (struct.get $type48 0
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (local.get $6)
                                  )
                                 )
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (local.get $6)
                                  )
                                  (else
                                   (call $function37
                                    (i32.const 0)
                                    (i32.const 1)
                                    (struct.get $type48 1
                                     (local.get $1)
                                    )
                                    (i64.add
                                     (i64.extend_i32_u
                                      (struct.get $type18 1
                                       (struct.get $type48 0
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (local.get $6)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call $string-new
    (i32.wrap_i64
     (local.get $6)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (call $string-copy
   (local.get $5)
   (i64.const 0)
   (local.tee $4
    (struct.get $type48 0
     (local.get $0)
    )
   )
   (local.tee $7
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $4)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.tee $1
      (struct.get $type48 1
       (local.get $0)
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (call $string-copy
      (local.get $5)
      (local.get $7)
      (local.tee $4
       (struct.get $type48 0
        (local.get $1)
       )
      )
      (local.tee $6
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $4)
        )
       )
      )
     )
     (local.set $1
      (struct.get $type48 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready98)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global98)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $string-copy
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $6)
          (local.get $7)
         )
        )
        (local.tee $4
         (struct.get $type48 0
          (local.get $1)
         )
        )
        (local.tee $6
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $4)
          )
         )
        )
       )
       (local.set $1
        (struct.get $type48 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready98)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global98)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $string-copy
          (local.get $5)
          (local.tee $7
           (i64.add
            (local.get $6)
            (local.get $7)
           )
          )
          (local.tee $4
           (struct.get $type48 0
            (local.get $1)
           )
          )
          (local.tee $6
           (i64.extend_i32_u
            (struct.get $type18 1
             (local.get $4)
            )
           )
          )
         )
         (local.set $1
          (struct.get $type48 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready98)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global98)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $string-copy
            (local.get $5)
            (local.tee $7
             (i64.add
              (local.get $6)
              (local.get $7)
             )
            )
            (local.tee $4
             (struct.get $type48 0
              (local.get $1)
             )
            )
            (local.tee $6
             (i64.extend_i32_u
              (struct.get $type18 1
               (local.get $4)
              )
             )
            )
           )
           (local.set $1
            (struct.get $type48 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready98)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global98)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $string-copy
              (local.get $5)
              (local.tee $7
               (i64.add
                (local.get $6)
                (local.get $7)
               )
              )
              (local.tee $4
               (struct.get $type48 0
                (local.get $1)
               )
              )
              (local.tee $6
               (i64.extend_i32_u
                (struct.get $type18 1
                 (local.get $4)
                )
               )
              )
             )
             (local.set $1
              (struct.get $type48 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready98)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global98)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $string-copy
                (local.get $5)
                (local.tee $7
                 (i64.add
                  (local.get $6)
                  (local.get $7)
                 )
                )
                (local.tee $4
                 (struct.get $type48 0
                  (local.get $1)
                 )
                )
                (local.tee $6
                 (i64.extend_i32_u
                  (struct.get $type18 1
                   (local.get $4)
                  )
                 )
                )
               )
               (local.set $1
                (struct.get $type48 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready98)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global98)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $string-copy
                  (local.get $5)
                  (local.tee $7
                   (i64.add
                    (local.get $6)
                    (local.get $7)
                   )
                  )
                  (local.tee $4
                   (struct.get $type48 0
                    (local.get $1)
                   )
                  )
                  (local.tee $6
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (local.set $1
                  (struct.get $type48 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready98)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global98)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $string-copy
                    (local.get $5)
                    (local.tee $7
                     (i64.add
                      (local.get $6)
                      (local.get $7)
                     )
                    )
                    (local.tee $4
                     (struct.get $type48 0
                      (local.get $1)
                     )
                    )
                    (local.tee $6
                     (i64.extend_i32_u
                      (struct.get $type18 1
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (local.set $1
                    (struct.get $type48 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready98)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global98)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $string-copy
                      (local.get $5)
                      (local.tee $7
                       (i64.add
                        (local.get $6)
                        (local.get $7)
                       )
                      )
                      (local.tee $4
                       (struct.get $type48 0
                        (local.get $1)
                       )
                      )
                      (local.tee $6
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.set $1
                      (struct.get $type48 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready98)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global98)
                      )
                     )
                     (call $function38
                      (local.get $5)
                      (local.get $1)
                      (i64.add
                       (local.get $6)
                       (local.get $7)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $5)
 )
 (func $function37 (type $82) (param $0 i32) (param $1 i32) (param $2 (ref null $type48)) (param $3 i64) (result i64)
  (local $4 (ref null $type48))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $4
       (struct.get $type48 1
        (local.get $2)
       )
      )
      (local.set $5
       (i64.extend_i32_u
        (struct.get $type18 1
         (struct.get $type48 0
          (local.get $2)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (i64.add
        (local.get $3)
        (local.get $5)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call50) (param $0 (ref $type18)) (param $1 (ref null $type48)) (param $2 i64) (result i32)
  (local $3 (ref $type18))
  (local $4 i64)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $3
      (struct.get $type48 0
       (local.get $1)
      )
     )
     (local.tee $4
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $3)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type48 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function40 (type $80) (param $0 (ref $type18)) (param $1 (ref $type18)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function41 (type $call52) (param $0 (ref $type18)) (result i32)
  (local $1 i64)
  (call $foreign0)
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (array.get $type19
                        (call $string-block
                         (local.get $0)
                         (i32.const 9)
                        )
                        (i32.const 9)
                       )
                      )
                      (return_call $function42
                       (local.get $0)
                       (local.get $1)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function42 (type $78) (param $0 (ref $type18)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i32.and
       (local.get $5)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function42
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function104 (type $call111) (param $0 (ref $type18)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local.set $1
   (call $foreign10)
  )
  (if (result i32)
   (i64.eqz
    (local.tee $2
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign11
     (local.get $1)
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 1)
     )
     (then
      (local.get $1)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign11
       (local.get $1)
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $2)
        (i64.const 2)
       )
       (then
        (local.get $1)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign11
         (local.get $1)
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $2)
          (i64.const 3)
         )
         (then
          (local.get $1)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign11
           (local.get $1)
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $2)
            (i64.const 4)
           )
           (then
            (local.get $1)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign11
             (local.get $1)
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $2)
              (i64.const 5)
             )
             (then
              (local.get $1)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign11
               (local.get $1)
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $2)
                (i64.const 6)
               )
               (then
                (local.get $1)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign11
                 (local.get $1)
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $2)
                  (i64.const 7)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign11
                   (local.get $1)
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $2)
                    (i64.const 8)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign11
                     (local.get $1)
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $2)
                      (i64.const 9)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign11
                       (local.get $1)
                       (array.get $type19
                        (call $string-block
                         (local.get $0)
                         (i32.const 9)
                        )
                        (i32.const 9)
                       )
                      )
                      (return_call $function105
                       (local.get $0)
                       (local.get $1)
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function105 (type $76) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign11
     (local.get $1)
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function105
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function111 (type $75) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign17
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function111
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function120 (type $75) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign22
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function120
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function121 (type $call120) (param $0 i32) (param $1 i32) (result (ref $type121))
  (local $2 i64)
  (if (result (ref $type121))
   (local.get $1)
   (then
    (if (result (ref $type121))
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (struct.new $type123
       (i32.const 1)
       (struct.new $type25
        (i32.const 0)
        (call $foreign19
         (local.get $0)
         (i32.const 0)
        )
       )
      )
     )
     (else
      (if (result (ref $type121))
       (i32.eq
        (local.get $1)
        (i32.const 2)
       )
       (then
        (struct.new $type123
         (i32.const 1)
         (struct.new $type26
          (i32.const 1)
          (call $foreign18
           (local.get $0)
           (i32.const 0)
          )
         )
        )
       )
       (else
        (if (result (ref $type121))
         (i32.eq
          (local.get $1)
          (i32.const 3)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global367)
           )
          )
          (struct.new $type123
           (i32.const 1)
           (struct.new $type27
            (i32.const 2)
            (if (result (ref $type28))
             (i32.eq
              (call $foreign20
               (local.get $0)
               (i32.const 0)
              )
              (i32.const 1)
             )
             (then
              (struct.new $type29
               (call $foreign19
                (local.get $0)
                (i32.const 0)
               )
              )
             )
             (else
              (struct.new $type30
               (call $foreign18
                (local.get $0)
                (i32.const 0)
               )
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global367)
              )
             )
             (if (result (ref $type28))
              (i32.eq
               (call $foreign20
                (local.get $0)
                (i32.const 1)
               )
               (i32.const 1)
              )
              (then
               (struct.new $type29
                (call $foreign19
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
              (else
               (struct.new $type30
                (call $foreign18
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
             )
            )
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global370)
           )
          )
          (struct.new $type124
           (i32.const 2)
           (call $function120
            (local.get $0)
            (local.tee $2
             (i64.extend_i32_s
              (call $foreign21
               (local.get $0)
              )
             )
            )
            (block (result (ref $type18))
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (if
              (i64.gt_u
               (local.get $2)
               (i64.const 4294967294)
              )
              (then
               (unreachable)
              )
             )
             (call $string-new
              (i32.wrap_i64
               (local.get $2)
              )
             )
            )
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (global.get $empty122)
   )
  )
 )
 (func $function152 (type $call146) (param $0 (ref $type130)) (result (ref $type13))
  (local $1 (ref $type18))
  (local $scratch (ref $type18))
  (if (result (ref $type13))
   (i32.eq
    (struct.get $type130 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (struct.get $type132 1
     (ref.cast (ref $type132)
      (local.get $0)
     )
    )
   )
   (else
    (if
     (struct.get $type130 0
      (local.get $0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global90)
       )
      )
      (call $foreign12
       (call $function104
        (block (result (ref $type18))
         (local.set $scratch
          (call $function35
           (struct.new $type48
            (global.get $string2)
            (struct.new $type48
             (struct.get $type133 1
              (ref.cast (ref $type133)
               (local.get $0)
              )
             )
             (ref.null none)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global323)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global317)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global323)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global317)
       )
      )
      (call $foreign12
       (call $function104
        (global.get $string3)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function154 (type $call162) (param $0 (ref $type58)) (result (ref $type163))
  (local $1 i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type68))
  (local $8 (ref $type121))
  (local $9 (ref $type154))
  (local $10 (ref $type130))
  (local $11 (ref $type181))
  (local $12 (ref $type163))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $2
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (block $block
   (return
    (if (result (ref $type165))
     (i64.lt_s
      (local.tee $1
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $7
          (if (result (ref $type68))
           (i32.eq
            (local.get $2)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $1
               (i64.extend_i32_s
                (local.get $2)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $1)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $1)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $7)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (global.get $empty165)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global536)
       )
      )
      (br_if $block
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $1)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $1)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (i32.eq
          (call $foreign25
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 1)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 59)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global541)
         )
        )
        (drop
         (call $function159
          (local.get $0)
         )
        )
        (br $block)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready546)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global546)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (return
         (if (result (ref $type163))
          (i64.eq
           (local.get $1)
           (i64.const 40)
          )
          (then
           (struct.new $type168
            (i32.const 4)
            (i64.const 0)
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global538)
            )
           )
           (if (result (ref $type163))
            (i64.eq
             (local.get $1)
             (i64.const 41)
            )
            (then
             (global.get $empty166)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global538)
              )
             )
             (if (result (ref $type163))
              (i64.eq
               (local.get $1)
               (i64.const 39)
              )
              (then
               (struct.new $type169
                (i32.const 5)
                (global.get $string8)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global538)
                )
               )
               (if (result (ref $type163))
                (i64.eq
                 (local.get $1)
                 (i64.const 96)
                )
                (then
                 (struct.new $type169
                  (i32.const 5)
                  (global.get $string7)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global538)
                  )
                 )
                 (if (result (ref $type163))
                  (i64.eq
                   (local.get $1)
                   (i64.const 44)
                  )
                  (then
                   (drop
                    (ref.as_non_null
                     (global.get $global549)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global552)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global137)
                    )
                   )
                   (local.set $2
                    (call $foreign8
                     (struct.get $type56 0
                      (struct.get $type58 0
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global133)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global532)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global538)
                    )
                   )
                   (struct.new $type169
                    (i32.const 5)
                    (select (result (ref $type18))
                     (global.get $string6)
                     (global.get $string5)
                     (if (result i32)
                      (i64.eq
                       (if (result i64)
                        (ref.test (ref $type69)
                         (local.tee $7
                          (if (result (ref $type68))
                           (i32.eq
                            (local.get $2)
                            (i32.const -1)
                           )
                           (then
                            (global.get $empty69)
                           )
                           (else
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (i64.extend_i32_s
                                (local.get $2)
                               )
                              )
                              (i64.const 1114111)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (if
                             (i32.and
                              (i64.le_u
                               (local.get $1)
                               (i64.const 57343)
                              )
                              (i64.ge_u
                               (local.get $1)
                               (i64.const 55296)
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (struct.new $type70
                             (i32.wrap_i64
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i64.const -1)
                        )
                        (else
                         (i64.extend_i32_u
                          (struct.get $type70 0
                           (ref.cast (ref $type70)
                            (local.get $7)
                           )
                          )
                         )
                        )
                       )
                       (i64.const 64)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global135)
                        )
                       )
                       (local.set $2
                        (call $foreign7
                         (struct.get $type56 0
                          (struct.get $type58 0
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global133)
                        )
                       )
                       (drop
                        (if (result (ref $type68))
                         (i32.eq
                          (local.get $2)
                          (i32.const -1)
                         )
                         (then
                          (global.get $empty69)
                         )
                         (else
                          (if
                           (i64.gt_u
                            (local.tee $1
                             (i64.extend_i32_s
                              (local.get $2)
                             )
                            )
                            (i64.const 1114111)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.and
                            (i64.le_u
                             (local.get $1)
                             (i64.const 57343)
                            )
                            (i64.ge_u
                             (local.get $1)
                             (i64.const 55296)
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.new $type70
                           (i32.wrap_i64
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (i32.const 1)
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global538)
                    )
                   )
                   (if (result (ref $type170))
                    (i64.eq
                     (local.get $1)
                     (i64.const 34)
                    )
                    (then
                     (if
                      (i32.eqz
                       (global.get $ready554)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global554)
                      )
                     )
                     (return_call $function163
                      (local.get $0)
                      (i32.const 34)
                      (i32.const 0)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global538)
                      )
                     )
                     (if (result (ref $type170))
                      (i64.eq
                       (local.get $1)
                       (i64.const 124)
                      )
                      (then
                       (if
                        (i32.eqz
                         (global.get $ready554)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global554)
                        )
                       )
                       (return_call $function163
                        (local.get $0)
                        (i32.const 124)
                        (i32.const 1)
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global538)
                        )
                       )
                       (if (result (ref $type170))
                        (i64.eq
                         (local.get $1)
                         (i64.const 35)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready627)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global627)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global530)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global135)
                          )
                         )
                         (local.set $2
                          (call $foreign7
                           (struct.get $type56 0
                            (struct.get $type58 0
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global133)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global532)
                          )
                         )
                         (return
                          (if (result (ref $type163))
                           (i64.lt_s
                            (local.tee $1
                             (if (result i64)
                              (ref.test (ref $type69)
                               (local.tee $7
                                (if (result (ref $type68))
                                 (i32.eq
                                  (local.get $2)
                                  (i32.const -1)
                                 )
                                 (then
                                  (global.get $empty69)
                                 )
                                 (else
                                  (if
                                   (i64.gt_u
                                    (local.tee $1
                                     (i64.extend_i32_s
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 1114111)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.and
                                    (i64.le_u
                                     (local.get $1)
                                     (i64.const 57343)
                                    )
                                    (i64.ge_u
                                     (local.get $1)
                                     (i64.const 55296)
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.new $type70
                                   (i32.wrap_i64
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i64.const -1)
                              )
                              (else
                               (i64.extend_i32_u
                                (struct.get $type70 0
                                 (ref.cast (ref $type70)
                                  (local.get $7)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (struct.new $type170
                             (i32.const 6)
                             (global.get $string19)
                            )
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global538)
                             )
                            )
                            (if (result (ref $type163))
                             (i64.eq
                              (local.get $1)
                              (i64.const 40)
                             )
                             (then
                              (struct.new $type168
                               (i32.const 4)
                               (i64.const 1)
                              )
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global538)
                               )
                              )
                              (if (result (ref $type163))
                               (i64.eq
                                (local.get $1)
                                (i64.const 59)
                               )
                               (then
                                (drop
                                 (ref.as_non_null
                                  (global.get $global630)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global525)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready527)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global527)
                                 )
                                )
                                (local.set $12
                                 (call $function154
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready702)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global702)
                                 )
                                )
                                (if (result (ref $type170))
                                 (i32.eq
                                  (struct.get $type130 0
                                   (local.tee $10
                                    (call $function196
                                     (local.get $0)
                                     (local.get $12)
                                    )
                                   )
                                  )
                                  (i32.const 1)
                                 )
                                 (then
                                  (drop
                                   (ref.cast (ref $type132)
                                    (local.get $10)
                                   )
                                  )
                                  (br $block)
                                 )
                                 (else
                                  (if (result (ref $type170))
                                   (struct.get $type130 0
                                    (local.get $10)
                                   )
                                   (then
                                    (struct.new $type170
                                     (i32.const 6)
                                     (struct.get $type133 1
                                      (ref.cast (ref $type133)
                                       (local.get $10)
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (struct.new $type170
                                     (i32.const 6)
                                     (global.get $string20)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global538)
                                 )
                                )
                                (if (result (ref $type163))
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 124)
                                 )
                                 (then
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global635)
                                   )
                                  )
                                  (if (result (ref $type170))
                                   (call $function182
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global527)
                                     )
                                    )
                                    (return_call $function154
                                     (local.get $0)
                                    )
                                   )
                                   (else
                                    (struct.new $type170
                                     (i32.const 6)
                                     (global.get $string18)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global538)
                                   )
                                  )
                                  (if (result (ref $type163))
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 92)
                                   )
                                   (then
                                    (if
                                     (i32.eqz
                                      (global.get $ready640)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global640)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global530)
                                     )
                                    )
                                    (if (result (ref $type163))
                                     (i64.lt_s
                                      (local.tee $1
                                       (call $function155
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                     (then
                                      (struct.new $type170
                                       (i32.const 6)
                                       (global.get $string21)
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global643)
                                       )
                                      )
                                      (if (result (ref $type164))
                                       (call $function184
                                        (local.get $1)
                                       )
                                       (then
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (struct.new $type164
                                         (i32.const 0)
                                         (struct.new $type16
                                          (i32.const 2)
                                          (i32.wrap_i64
                                           (local.get $1)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global658)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global562)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global61)
                                         )
                                        )
                                        (local.set $9
                                         (struct.new $type154
                                          (struct.new $type155
                                           (call $string-new
                                            (i32.const 32)
                                           )
                                          )
                                          (struct.new_default $type156)
                                         )
                                        )
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global611)
                                         )
                                        )
                                        (call $function177
                                         (local.get $9)
                                         (i32.wrap_i64
                                          (local.get $1)
                                         )
                                        )
                                        (local.set $4
                                         (call $function186
                                          (local.get $0)
                                          (local.get $9)
                                          (i32.const 0)
                                          (i32.const 1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready663)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global663)
                                         )
                                        )
                                        (return
                                         (if (result (ref $type163))
                                          (i64.eq
                                           (local.tee $1
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $4)
                                             )
                                            )
                                           )
                                           (i64.const 1)
                                          )
                                          (then
                                           (if
                                            (i64.eqz
                                             (local.get $1)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (struct.new $type164
                                            (i32.const 0)
                                            (struct.new $type16
                                             (i32.const 2)
                                             (array.get $type19
                                              (struct.get $type18 2
                                               (local.get $4)
                                              )
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global666)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global88)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global81)
                                            )
                                           )
                                           (local.set $4
                                            (call $function189
                                             (if (result (ref $type18))
                                              (i64.lt_s
                                               (local.tee $1
                                                (i64.extend_i32_u
                                                 (struct.get $type18 1
                                                  (local.get $4)
                                                 )
                                                )
                                               )
                                               (local.get $1)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global61)
                                                )
                                               )
                                               (if
                                                (i64.gt_u
                                                 (local.get $1)
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (call $string-copy
                                                (local.tee $5
                                                 (call $string-new
                                                  (i32.wrap_i64
                                                   (local.get $1)
                                                  )
                                                 )
                                                )
                                                (i64.const 0)
                                                (local.get $4)
                                                (local.get $1)
                                               )
                                               (local.get $5)
                                              )
                                             )
                                             (i32.const 0)
                                             (i32.const 1)
                                             (i64.const 0)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready672)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global672)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global103)
                                            )
                                           )
                                           (if (result (ref $type163))
                                            (struct.get $type181 0
                                             (local.tee $11
                                              (if (result (ref $type181))
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 5)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string31)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                               (then
                                                (struct.new $type182
                                                 (i32.const 0)
                                                 (i32.const 7)
                                                )
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global103)
                                                 )
                                                )
                                                (if (result (ref $type181))
                                                 (if (result i32)
                                                  (i64.eq
                                                   (i64.extend_i32_u
                                                    (struct.get $type18 1
                                                     (local.get $4)
                                                    )
                                                   )
                                                   (i64.const 9)
                                                  )
                                                  (then
                                                   (call $function40
                                                    (local.get $4)
                                                    (global.get $string30)
                                                    (i32.const 0)
                                                    (i32.const 1)
                                                    (i64.const 0)
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                 (then
                                                  (struct.new $type182
                                                   (i32.const 0)
                                                   (i32.const 8)
                                                  )
                                                 )
                                                 (else
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global103)
                                                   )
                                                  )
                                                  (if (result (ref $type181))
                                                   (if (result i32)
                                                    (i64.eq
                                                     (i64.extend_i32_u
                                                      (struct.get $type18 1
                                                       (local.get $4)
                                                      )
                                                     )
                                                     (i64.const 6)
                                                    )
                                                    (then
                                                     (call $function40
                                                      (local.get $4)
                                                      (global.get $string29)
                                                      (i32.const 0)
                                                      (i32.const 1)
                                                      (i64.const 0)
                                                     )
                                                    )
                                                    (else
                                                     (i32.const 0)
                                                    )
                                                   )
                                                   (then
                                                    (struct.new $type182
                                                     (i32.const 0)
                                                     (i32.const 127)
                                                    )
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global103)
                                                     )
                                                    )
                                                    (if (result (ref $type181))
                                                     (if (result i32)
                                                      (i64.eq
                                                       (i64.extend_i32_u
                                                        (struct.get $type18 1
                                                         (local.get $4)
                                                        )
                                                       )
                                                       (i64.const 6)
                                                      )
                                                      (then
                                                       (call $function40
                                                        (local.get $4)
                                                        (global.get $string28)
                                                        (i32.const 0)
                                                        (i32.const 1)
                                                        (i64.const 0)
                                                       )
                                                      )
                                                      (else
                                                       (i32.const 0)
                                                      )
                                                     )
                                                     (then
                                                      (struct.new $type182
                                                       (i32.const 0)
                                                       (i32.const 27)
                                                      )
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global103)
                                                       )
                                                      )
                                                      (if (result (ref $type181))
                                                       (if (result i32)
                                                        (i64.eq
                                                         (i64.extend_i32_u
                                                          (struct.get $type18 1
                                                           (local.get $4)
                                                          )
                                                         )
                                                         (i64.const 7)
                                                        )
                                                        (then
                                                         (call $function40
                                                          (local.get $4)
                                                          (global.get $string27)
                                                          (i32.const 0)
                                                          (i32.const 1)
                                                          (i64.const 0)
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                       (then
                                                        (struct.new $type182
                                                         (i32.const 0)
                                                         (i32.const 10)
                                                        )
                                                       )
                                                       (else
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global103)
                                                         )
                                                        )
                                                        (if (result (ref $type181))
                                                         (if (result i32)
                                                          (i64.eq
                                                           (i64.extend_i32_u
                                                            (struct.get $type18 1
                                                             (local.get $4)
                                                            )
                                                           )
                                                           (i64.const 4)
                                                          )
                                                          (then
                                                           (call $function40
                                                            (local.get $4)
                                                            (global.get $string26)
                                                            (i32.const 0)
                                                            (i32.const 1)
                                                            (i64.const 0)
                                                           )
                                                          )
                                                          (else
                                                           (i32.const 0)
                                                          )
                                                         )
                                                         (then
                                                          (struct.new_default $type182)
                                                         )
                                                         (else
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global103)
                                                           )
                                                          )
                                                          (if (result (ref $type181))
                                                           (if (result i32)
                                                            (i64.eq
                                                             (i64.extend_i32_u
                                                              (struct.get $type18 1
                                                               (local.get $4)
                                                              )
                                                             )
                                                             (i64.const 6)
                                                            )
                                                            (then
                                                             (call $function40
                                                              (local.get $4)
                                                              (global.get $string25)
                                                              (i32.const 0)
                                                              (i32.const 1)
                                                              (i64.const 0)
                                                             )
                                                            )
                                                            (else
                                                             (i32.const 0)
                                                            )
                                                           )
                                                           (then
                                                            (struct.new $type182
                                                             (i32.const 0)
                                                             (i32.const 13)
                                                            )
                                                           )
                                                           (else
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global103)
                                                             )
                                                            )
                                                            (if (result (ref $type181))
                                                             (if (result i32)
                                                              (i64.eq
                                                               (i64.extend_i32_u
                                                                (struct.get $type18 1
                                                                 (local.get $4)
                                                                )
                                                               )
                                                               (i64.const 5)
                                                              )
                                                              (then
                                                               (call $function40
                                                                (local.get $4)
                                                                (global.get $string24)
                                                                (i32.const 0)
                                                                (i32.const 1)
                                                                (i64.const 0)
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                             (then
                                                              (struct.new $type182
                                                               (i32.const 0)
                                                               (i32.const 32)
                                                              )
                                                             )
                                                             (else
                                                              (drop
                                                               (ref.as_non_null
                                                                (global.get $global103)
                                                               )
                                                              )
                                                              (if (result (ref $type181))
                                                               (if (result i32)
                                                                (i64.eq
                                                                 (i64.extend_i32_u
                                                                  (struct.get $type18 1
                                                                   (local.get $4)
                                                                  )
                                                                 )
                                                                 (i64.const 3)
                                                                )
                                                                (then
                                                                 (call $function40
                                                                  (local.get $4)
                                                                  (global.get $string23)
                                                                  (i32.const 0)
                                                                  (i32.const 1)
                                                                  (i64.const 0)
                                                                 )
                                                                )
                                                                (else
                                                                 (i32.const 0)
                                                                )
                                                               )
                                                               (then
                                                                (struct.new $type182
                                                                 (i32.const 0)
                                                                 (i32.const 9)
                                                                )
                                                               )
                                                               (else
                                                                (if
                                                                 (i64.eqz
                                                                  (i64.extend_i32_u
                                                                   (struct.get $type18 1
                                                                    (local.get $4)
                                                                   )
                                                                  )
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (if (result (ref $type181))
                                                                 (i32.eq
                                                                  (array.get $type19
                                                                   (struct.get $type18 2
                                                                    (local.get $4)
                                                                   )
                                                                   (i32.const 0)
                                                                  )
                                                                  (i32.const 120)
                                                                 )
                                                                 (then
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global674)
                                                                   )
                                                                  )
                                                                  (call $function192
                                                                   (local.get $4)
                                                                   (i32.const 0)
                                                                   (i32.const 1)
                                                                   (i64.const 1)
                                                                   (i64.const 0)
                                                                  )
                                                                 )
                                                                 (else
                                                                  (struct.new $type184
                                                                   (i32.const 2)
                                                                   (global.get $string22)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (if (result (ref $type170))
                                              (i32.eq
                                               (struct.get $type181 0
                                                (local.get $11)
                                               )
                                               (i32.const 2)
                                              )
                                              (then
                                               (struct.new $type170
                                                (i32.const 6)
                                                (struct.get $type184 1
                                                 (ref.cast (ref $type184)
                                                  (local.get $11)
                                                 )
                                                )
                                               )
                                              )
                                              (else
                                               (unreachable)
                                              )
                                             )
                                            )
                                            (else
                                             (struct.new $type164
                                              (i32.const 0)
                                              (struct.new $type16
                                               (i32.const 2)
                                               (struct.get $type182 1
                                                (ref.cast (ref $type182)
                                                 (local.get $11)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global538)
                                     )
                                    )
                                    (if (result (ref $type163))
                                     (if (result i32)
                                      (local.tee $2
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 117)
                                       )
                                      )
                                      (then
                                       (local.get $2)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global538)
                                        )
                                       )
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 85)
                                       )
                                      )
                                     )
                                     (then
                                      (if
                                       (i32.eqz
                                        (global.get $ready684)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global684)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global549)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global552)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global137)
                                       )
                                      )
                                      (local.set $2
                                       (call $foreign8
                                        (struct.get $type56 0
                                         (struct.get $type58 0
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global133)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global532)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global538)
                                       )
                                      )
                                      (if (result (ref $type163))
                                       (if (result i32)
                                        (if (result i32)
                                         (i64.eq
                                          (if (result i64)
                                           (ref.test (ref $type69)
                                            (local.tee $7
                                             (if (result (ref $type68))
                                              (i32.eq
                                               (local.get $2)
                                               (i32.const -1)
                                              )
                                              (then
                                               (global.get $empty69)
                                              )
                                              (else
                                               (if
                                                (i64.gt_u
                                                 (local.tee $1
                                                  (i64.extend_i32_s
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (i64.const 1114111)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (if
                                                (i32.and
                                                 (i64.le_u
                                                  (local.get $1)
                                                  (i64.const 57343)
                                                 )
                                                 (i64.ge_u
                                                  (local.get $1)
                                                  (i64.const 55296)
                                                 )
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (struct.new $type70
                                                (i32.wrap_i64
                                                 (local.get $1)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (i64.const -1)
                                           )
                                           (else
                                            (i64.extend_i32_u
                                             (struct.get $type70 0
                                              (ref.cast (ref $type70)
                                               (local.get $7)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i64.const 56)
                                         )
                                         (then
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global135)
                                           )
                                          )
                                          (local.set $2
                                           (call $foreign7
                                            (struct.get $type56 0
                                             (struct.get $type58 0
                                              (local.get $0)
                                             )
                                            )
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global133)
                                           )
                                          )
                                          (drop
                                           (if (result (ref $type68))
                                            (i32.eq
                                             (local.get $2)
                                             (i32.const -1)
                                            )
                                            (then
                                             (global.get $empty69)
                                            )
                                            (else
                                             (if
                                              (i64.gt_u
                                               (local.tee $1
                                                (i64.extend_i32_s
                                                 (local.get $2)
                                                )
                                               )
                                               (i64.const 1114111)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (if
                                              (i32.and
                                               (i64.le_u
                                                (local.get $1)
                                                (i64.const 57343)
                                               )
                                               (i64.ge_u
                                                (local.get $1)
                                                (i64.const 55296)
                                               )
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (struct.new $type70
                                              (i32.wrap_i64
                                               (local.get $1)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i32.const 1)
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                        (then
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global549)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global552)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global137)
                                          )
                                         )
                                         (local.set $2
                                          (call $foreign8
                                           (struct.get $type56 0
                                            (struct.get $type58 0
                                             (local.get $0)
                                            )
                                           )
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global133)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global532)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global538)
                                          )
                                         )
                                         (if (result i32)
                                          (i64.eq
                                           (if (result i64)
                                            (ref.test (ref $type69)
                                             (local.tee $7
                                              (if (result (ref $type68))
                                               (i32.eq
                                                (local.get $2)
                                                (i32.const -1)
                                               )
                                               (then
                                                (global.get $empty69)
                                               )
                                               (else
                                                (if
                                                 (i64.gt_u
                                                  (local.tee $1
                                                   (i64.extend_i32_s
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (i64.const 1114111)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (if
                                                 (i32.and
                                                  (i64.le_u
                                                   (local.get $1)
                                                   (i64.const 57343)
                                                  )
                                                  (i64.ge_u
                                                   (local.get $1)
                                                   (i64.const 55296)
                                                  )
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (struct.new $type70
                                                 (i32.wrap_i64
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (i64.const -1)
                                            )
                                            (else
                                             (i64.extend_i32_u
                                              (struct.get $type70 0
                                               (ref.cast (ref $type70)
                                                (local.get $7)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i64.const 40)
                                          )
                                          (then
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global135)
                                            )
                                           )
                                           (local.set $2
                                            (call $foreign7
                                             (struct.get $type56 0
                                              (struct.get $type58 0
                                               (local.get $0)
                                              )
                                             )
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global133)
                                            )
                                           )
                                           (drop
                                            (if (result (ref $type68))
                                             (i32.eq
                                              (local.get $2)
                                              (i32.const -1)
                                             )
                                             (then
                                              (global.get $empty69)
                                             )
                                             (else
                                              (if
                                               (i64.gt_u
                                                (local.tee $1
                                                 (i64.extend_i32_s
                                                  (local.get $2)
                                                 )
                                                )
                                                (i64.const 1114111)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (if
                                               (i32.and
                                                (i64.le_u
                                                 (local.get $1)
                                                 (i64.const 57343)
                                                )
                                                (i64.ge_u
                                                 (local.get $1)
                                                 (i64.const 55296)
                                                )
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (struct.new $type70
                                               (i32.wrap_i64
                                                (local.get $1)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i32.const 1)
                                          )
                                          (else
                                           (i32.const 0)
                                          )
                                         )
                                        )
                                        (else
                                         (i32.const 0)
                                        )
                                       )
                                       (then
                                        (struct.new $type168
                                         (i32.const 4)
                                         (i64.const 2)
                                        )
                                       )
                                       (else
                                        (struct.new $type170
                                         (i32.const 6)
                                         (global.get $string33)
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global538)
                                       )
                                      )
                                      (if (result (ref $type163))
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 33)
                                       )
                                       (then
                                        (struct.new $type170
                                         (i32.const 6)
                                         (global.get $string17)
                                        )
                                       )
                                       (else
                                        (if (result (ref $type163))
                                         (i32.and
                                          (i64.le_s
                                           (local.get $1)
                                           (i64.const 57)
                                          )
                                          (i64.ge_s
                                           (local.get $1)
                                           (i64.const 48)
                                          )
                                         )
                                         (then
                                          (struct.new $type170
                                           (i32.const 6)
                                           (global.get $string16)
                                          )
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global658)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global562)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global61)
                                           )
                                          )
                                          (local.set $9
                                           (struct.new $type154
                                            (struct.new $type155
                                             (call $string-new
                                              (i32.const 32)
                                             )
                                            )
                                            (struct.new_default $type156)
                                           )
                                          )
                                          (if
                                           (i64.gt_u
                                            (local.get $1)
                                            (i64.const 1114111)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (if
                                           (i32.and
                                            (i64.le_u
                                             (local.get $1)
                                             (i64.const 57343)
                                            )
                                            (i64.ge_u
                                             (local.get $1)
                                             (i64.const 55296)
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global611)
                                           )
                                          )
                                          (call $function177
                                           (local.get $9)
                                           (i32.wrap_i64
                                            (local.get $1)
                                           )
                                          )
                                          (local.set $4
                                           (call $function186
                                            (local.get $0)
                                            (local.get $9)
                                            (i32.const 0)
                                            (i32.const 1)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global90)
                                           )
                                          )
                                          (local.set $5
                                           (call $function35
                                            (struct.new $type48
                                             (global.get $string15)
                                             (struct.new $type48
                                              (local.get $4)
                                              (ref.null none)
                                             )
                                            )
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready686)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global686)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global666)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global88)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global81)
                                           )
                                          )
                                          (local.set $4
                                           (call $function189
                                            (if (result (ref $type18))
                                             (i64.lt_s
                                              (local.tee $1
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $5)
                                                )
                                               )
                                              )
                                              (local.get $1)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global61)
                                               )
                                              )
                                              (if
                                               (i64.gt_u
                                                (local.get $1)
                                                (i64.const 4294967294)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (call $string-copy
                                               (local.tee $6
                                                (call $string-new
                                                 (i32.wrap_i64
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                               (i64.const 0)
                                               (local.get $5)
                                               (local.get $1)
                                              )
                                              (local.get $6)
                                             )
                                            )
                                            (i32.const 0)
                                            (i32.const 1)
                                            (i64.const 0)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global103)
                                           )
                                          )
                                          (if (result (ref $type163))
                                           (if (result i32)
                                            (local.tee $2
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $4)
                                                )
                                               )
                                               (i64.const 2)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $4)
                                                (global.get $string37)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                            (then
                                             (local.get $2)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global103)
                                              )
                                             )
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $4)
                                                )
                                               )
                                               (i64.const 5)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $4)
                                                (global.get $string38)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (struct.new $type164
                                             (i32.const 0)
                                             (struct.new $type15
                                              (i32.const 1)
                                              (i32.const 1)
                                             )
                                            )
                                           )
                                           (else
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global103)
                                             )
                                            )
                                            (if (result (ref $type163))
                                             (if (result i32)
                                              (local.tee $2
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 2)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string35)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                              (then
                                               (local.get $2)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global103)
                                                )
                                               )
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 6)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string36)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                             )
                                             (then
                                              (struct.new $type164
                                               (i32.const 0)
                                               (struct.new $type15
                                                (i32.const 1)
                                                (i32.const 0)
                                               )
                                              )
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global379)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global317)
                                               )
                                              )
                                              (local.set $3
                                               (call $foreign23
                                                (local.tee $2
                                                 (call $function104
                                                  (local.get $5)
                                                 )
                                                )
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global376)
                                               )
                                              )
                                              (local.set $8
                                               (call $function121
                                                (local.get $2)
                                                (local.get $3)
                                               )
                                              )
                                              (call $foreign14
                                               (local.get $2)
                                              )
                                              (if (result (ref $type163))
                                               (i32.eq
                                                (struct.get $type121 0
                                                 (local.get $8)
                                                )
                                                (i32.const 1)
                                               )
                                               (then
                                                (struct.new $type164
                                                 (i32.const 0)
                                                 (struct.new $type23
                                                  (i32.const 5)
                                                  (struct.get $type123 1
                                                   (ref.cast (ref $type123)
                                                    (local.get $8)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (else
                                                (if (result (ref $type170))
                                                 (i32.eq
                                                  (struct.get $type121 0
                                                   (local.get $8)
                                                  )
                                                  (i32.const 2)
                                                 )
                                                 (then
                                                  (struct.new $type170
                                                   (i32.const 6)
                                                   (struct.get $type124 1
                                                    (ref.cast (ref $type124)
                                                     (local.get $8)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (struct.new $type170
                                                   (i32.const 6)
                                                   (global.get $string34)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global538)
                          )
                         )
                         (if (result (ref $type170))
                          (if (result i32)
                           (local.tee $2
                            (i64.eq
                             (local.get $1)
                             (i64.const 91)
                            )
                           )
                           (then
                            (local.get $2)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global538)
                             )
                            )
                            (if (result i32)
                             (local.tee $2
                              (i64.eq
                               (local.get $1)
                               (i64.const 93)
                              )
                             )
                             (then
                              (local.get $2)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global538)
                               )
                              )
                              (if (result i32)
                               (local.tee $2
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 123)
                                )
                               )
                               (then
                                (local.get $2)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global538)
                                 )
                                )
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 125)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (struct.new $type170
                            (i32.const 6)
                            (global.get $string4)
                           )
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global658)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global562)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global61)
                            )
                           )
                           (local.set $9
                            (struct.new $type154
                             (struct.new $type155
                              (call $string-new
                               (i32.const 32)
                              )
                             )
                             (struct.new_default $type156)
                            )
                           )
                           (if
                            (i64.gt_u
                             (local.get $1)
                             (i64.const 1114111)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if
                            (i32.and
                             (i64.le_u
                              (local.get $1)
                              (i64.const 57343)
                             )
                             (i64.ge_u
                              (local.get $1)
                              (i64.const 55296)
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global611)
                            )
                           )
                           (call $function177
                            (local.get $9)
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                           (local.set $4
                            (call $function186
                             (local.get $0)
                             (local.get $9)
                             (i32.const 0)
                             (i32.const 1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready697)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global697)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global103)
                            )
                           )
                           (return
                            (if (result (ref $type163))
                             (if (result i32)
                              (i64.eq
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (local.get $4)
                                )
                               )
                               (i64.const 1)
                              )
                              (then
                               (call $function40
                                (local.get $4)
                                (global.get $string39)
                                (i32.const 0)
                                (i32.const 1)
                                (i64.const 0)
                               )
                              )
                              (else
                               (i32.const 0)
                              )
                             )
                             (then
                              (global.get $empty167)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global418)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global317)
                               )
                              )
                              (if (result (ref $type163))
                               (i32.eq
                                (struct.get $type130 0
                                 (local.tee $10
                                  (if (result (ref $type130))
                                   (local.tee $3
                                    (call $foreign23
                                     (local.tee $2
                                      (call $function104
                                       (local.get $4)
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global411)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global376)
                                     )
                                    )
                                    (local.set $8
                                     (call $function121
                                      (local.get $2)
                                      (local.get $3)
                                     )
                                    )
                                    (call $foreign14
                                     (local.get $2)
                                    )
                                    (if (result (ref $type130))
                                     (i32.eq
                                      (struct.get $type121 0
                                       (local.get $8)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (struct.new $type132
                                       (i32.const 1)
                                       (struct.new $type23
                                        (i32.const 5)
                                        (struct.get $type123 1
                                         (ref.cast (ref $type123)
                                          (local.get $8)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (if (result (ref $type133))
                                       (i32.eq
                                        (struct.get $type121 0
                                         (local.get $8)
                                        )
                                        (i32.const 2)
                                       )
                                       (then
                                        (struct.new $type133
                                         (i32.const 2)
                                         (struct.get $type124 1
                                          (ref.cast (ref $type124)
                                           (local.get $8)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (unreachable)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (if (result (ref $type130))
                                     (i32.eq
                                      (call $foreign13
                                       (local.get $2)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (struct.new $type132
                                       (i32.const 1)
                                       (struct.new $type21
                                        (i32.const 4)
                                        (struct.new $type22
                                         (call $foreign15
                                          (local.get $2)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (call $foreign14
                                       (local.get $2)
                                      )
                                      (struct.new $type133
                                       (i32.const 2)
                                       (global.get $string1)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (i32.const 1)
                               )
                               (then
                                (struct.new $type164
                                 (i32.const 0)
                                 (struct.get $type132 1
                                  (ref.cast (ref $type132)
                                   (local.get $10)
                                  )
                                 )
                                )
                               )
                               (else
                                (if (result (ref $type170))
                                 (i32.eq
                                  (struct.get $type130 0
                                   (local.get $10)
                                  )
                                  (i32.const 2)
                                 )
                                 (then
                                  (struct.new $type170
                                   (i32.const 6)
                                   (struct.get $type133 1
                                    (ref.cast (ref $type133)
                                     (local.get $10)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (unreachable)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (unreachable)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready527)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (return_call $function154
   (local.get $0)
  )
 )
 (func $function155 (type $call149) (param $0 (ref $type58)) (result i64)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $2
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (if (result i64)
   (ref.test (ref $type69)
    (local.tee $3
     (if (result (ref $type68))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty69)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type70
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (i64.const -1)
   )
   (else
    (i64.extend_i32_u
     (struct.get $type70 0
      (ref.cast (ref $type70)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function159 (type $call60) (param $0 (ref $type58)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local $3 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $1
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $1
     (i64.lt_s
      (local.tee $2
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $3
          (if (result (ref $type68))
           (i32.eq
            (local.get $1)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $1)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
    )
    (then
     (local.get $1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (if (result i32)
      (local.tee $1
       (i64.eq
        (local.get $2)
        (i64.const 10)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global538)
        )
       )
       (i64.eq
        (local.get $2)
        (i64.const 13)
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready541)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global541)
     )
    )
    (return_call $function159
     (local.get $0)
    )
   )
  )
 )
 (func $function163 (type $call173) (param $0 (ref $type58)) (param $1 i32) (param $2 i32) (result (ref $type163))
  (local $3 (ref $type175))
  (local $4 (ref $type18))
  (local $5 (ref $type154))
  (if
   (i32.eqz
    (global.get $ready559)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global559)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global562)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $5
   (struct.new $type154
    (struct.new $type155
     (call $string-new
      (i32.const 32)
     )
    )
    (struct.new_default $type156)
   )
  )
  (if
   (i32.eqz
    (global.get $ready563)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global563)
   )
  )
  (if (result (ref $type163))
   (ref.test (ref $type176)
    (local.tee $3
     (call $function166
      (local.get $0)
      (local.get $1)
      (local.get $5)
     )
    )
   )
   (then
    (local.set $4
     (struct.get $type176 0
      (ref.cast (ref $type176)
       (local.get $3)
      )
     )
    )
    (struct.new $type164
     (i32.const 0)
     (if (result (ref $type13))
      (local.get $2)
      (then
       (drop
        (ref.as_non_null
         (global.get $global329)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global317)
        )
       )
       (struct.new $type21
        (i32.const 4)
        (struct.new $type22
         (call $foreign15
          (call $function104
           (local.get $4)
          )
         )
        )
       )
      )
      (else
       (struct.new $type17
        (i32.const 3)
        (local.get $4)
       )
      )
     )
    )
   )
   (else
    (struct.new $type170
     (i32.const 6)
     (struct.get $type177 0
      (ref.cast (ref $type177)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function166 (type $call178) (param $0 (ref $type58)) (param $1 i32) (param $2 (ref $type154)) (result (ref $type175))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type68))
  (local $6 (ref $type181))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $4
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (block $block
   (return
    (if (result (ref $type175))
     (i64.lt_s
      (local.tee $3
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $5
          (if (result (ref $type68))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $3
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $3)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $3)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $5)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (struct.new $type177
       (global.get $string9)
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result (ref $type175))
       (i64.eq
        (i64.extend_i32_u
         (local.get $1)
        )
        (local.get $3)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global568)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global81)
         )
        )
        (local.set $7
         (struct.get $type155 0
          (struct.get $type154 0
           (local.get $2)
          )
         )
        )
        (struct.new $type176
         (if (result (ref $type18))
          (if (result i32)
           (local.tee $1
            (i64.lt_s
             (local.tee $3
              (struct.get $type156 0
               (struct.get $type154 1
                (local.get $2)
               )
              )
             )
             (i64.const 0)
            )
           )
           (then
            (local.get $1)
           )
           (else
            (i64.lt_s
             (i64.extend_i32_u
              (struct.get $type18 1
               (local.get $7)
              )
             )
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global61)
            )
           )
           (if
            (i64.gt_u
             (local.get $3)
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
           )
           (call $string-copy
            (local.tee $8
             (call $string-new
              (i32.wrap_i64
               (local.get $3)
              )
             )
            )
            (i64.const 0)
            (local.get $7)
            (local.get $3)
           )
           (local.get $8)
          )
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (if (result (ref $type177))
         (i64.eq
          (local.get $3)
          (i64.const 92)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready570)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global570)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global530)
           )
          )
          (local.set $3
           (call $function155
            (local.get $0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global538)
           )
          )
          (local.set $6
           (if (result (ref $type181))
            (i64.eq
             (local.get $3)
             (i64.const 97)
            )
            (then
             (struct.new $type182
              (i32.const 0)
              (i32.const 7)
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global538)
              )
             )
             (if (result (ref $type181))
              (i64.eq
               (local.get $3)
               (i64.const 98)
              )
              (then
               (struct.new $type182
                (i32.const 0)
                (i32.const 8)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global538)
                )
               )
               (if (result (ref $type181))
                (i64.eq
                 (local.get $3)
                 (i64.const 116)
                )
                (then
                 (struct.new $type182
                  (i32.const 0)
                  (i32.const 9)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global538)
                  )
                 )
                 (if (result (ref $type181))
                  (i64.eq
                   (local.get $3)
                   (i64.const 110)
                  )
                  (then
                   (struct.new $type182
                    (i32.const 0)
                    (i32.const 10)
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global538)
                    )
                   )
                   (if (result (ref $type181))
                    (i64.eq
                     (local.get $3)
                     (i64.const 114)
                    )
                    (then
                     (struct.new $type182
                      (i32.const 0)
                      (i32.const 13)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global538)
                      )
                     )
                     (if (result (ref $type181))
                      (if (result i32)
                       (local.tee $4
                        (i64.eq
                         (local.get $3)
                         (i64.const 34)
                        )
                       )
                       (then
                        (local.get $4)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global538)
                         )
                        )
                        (if (result i32)
                         (local.tee $4
                          (i64.eq
                           (local.get $3)
                           (i64.const 124)
                          )
                         )
                         (then
                          (local.get $4)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global538)
                           )
                          )
                          (i64.eq
                           (local.get $3)
                           (i64.const 92)
                          )
                         )
                        )
                       )
                      )
                      (then
                       (if
                        (i64.gt_u
                         (local.get $3)
                         (i64.const 1114111)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.and
                         (i64.le_u
                          (local.get $3)
                          (i64.const 57343)
                         )
                         (i64.ge_u
                          (local.get $3)
                          (i64.const 55296)
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (struct.new $type182
                        (i32.const 0)
                        (i32.wrap_i64
                         (local.get $3)
                        )
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global538)
                        )
                       )
                       (if (result (ref $type181))
                        (i64.eq
                         (local.get $3)
                         (i64.const 120)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready576)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global576)
                          )
                         )
                         (call $function169
                          (local.get $0)
                          (i64.const 0)
                          (i64.const 0)
                         )
                        )
                        (else
                         (if (result (ref $type181))
                          (if (result i32)
                           (i32.eq
                            (local.get $1)
                            (i32.const 34)
                           )
                           (then
                            (if
                             (i32.eqz
                              (global.get $ready591)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global591)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global538)
                             )
                            )
                            (if (result i32)
                             (local.tee $4
                              (i64.eq
                               (local.get $3)
                               (i64.const 32)
                              )
                             )
                             (then
                              (local.get $4)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global538)
                               )
                              )
                              (if (result i32)
                               (local.tee $4
                                (i64.eq
                                 (local.get $3)
                                 (i64.const 9)
                                )
                               )
                               (then
                                (local.get $4)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global538)
                                 )
                                )
                                (if (result i32)
                                 (local.tee $4
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 10)
                                  )
                                 )
                                 (then
                                  (local.get $4)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global538)
                                   )
                                  )
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 13)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                          (then
                           (if
                            (i32.eqz
                             (global.get $ready596)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global596)
                            )
                           )
                           (call $function174
                            (local.get $0)
                            (local.get $3)
                           )
                          )
                          (else
                           (struct.new $type184
                            (i32.const 2)
                            (global.get $string10)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready604)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global604)
           )
          )
          (if (result (ref $type177))
           (local.tee $4
            (struct.get $type181 0
             (local.get $6)
            )
           )
           (then
            (if (result (ref $type177))
             (i32.eq
              (local.get $4)
              (i32.const 1)
             )
             (then
              (br $block)
             )
             (else
              (struct.new $type177
               (struct.get $type184 1
                (ref.cast (ref $type184)
                 (local.get $6)
                )
               )
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global611)
             )
            )
            (call $function177
             (local.get $2)
             (struct.get $type182 1
              (ref.cast (ref $type182)
               (local.get $6)
              )
             )
            )
            (br $block)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready621)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global621)
           )
          )
          (local.set $4
           (if (result i32)
            (if (result i32)
             (i32.eq
              (local.get $1)
              (i32.const 34)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global538)
               )
              )
              (i64.eq
               (local.get $3)
               (i64.const 13)
              )
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global549)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global552)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global137)
              )
             )
             (local.set $4
              (call $foreign8
               (struct.get $type56 0
                (struct.get $type58 0
                 (local.get $0)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global133)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global532)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global538)
              )
             )
             (if
              (i64.eq
               (if (result i64)
                (ref.test (ref $type69)
                 (local.tee $5
                  (if (result (ref $type68))
                   (i32.eq
                    (local.get $4)
                    (i32.const -1)
                   )
                   (then
                    (global.get $empty69)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $3
                       (i64.extend_i32_s
                        (local.get $4)
                       )
                      )
                      (i64.const 1114111)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.and
                      (i64.le_u
                       (local.get $3)
                       (i64.const 57343)
                      )
                      (i64.ge_u
                       (local.get $3)
                       (i64.const 55296)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (struct.new $type70
                     (i32.wrap_i64
                      (local.get $3)
                     )
                    )
                   )
                  )
                 )
                )
                (then
                 (i64.const -1)
                )
                (else
                 (i64.extend_i32_u
                  (struct.get $type70 0
                   (ref.cast (ref $type70)
                    (local.get $5)
                   )
                  )
                 )
                )
               )
               (i64.const 10)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global135)
                )
               )
               (local.set $4
                (call $foreign7
                 (struct.get $type56 0
                  (struct.get $type58 0
                   (local.get $0)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global133)
                )
               )
               (drop
                (if (result (ref $type68))
                 (i32.eq
                  (local.get $4)
                  (i32.const -1)
                 )
                 (then
                  (global.get $empty69)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $3
                     (i64.extend_i32_s
                      (local.get $4)
                     )
                    )
                    (i64.const 1114111)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.and
                    (i64.le_u
                     (local.get $3)
                     (i64.const 57343)
                    )
                    (i64.ge_u
                     (local.get $3)
                     (i64.const 55296)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.new $type70
                   (i32.wrap_i64
                    (local.get $3)
                   )
                  )
                 )
                )
               )
              )
             )
             (i32.const 10)
            )
            (else
             (if
              (i64.gt_u
               (local.get $3)
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $3)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $3)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global611)
           )
          )
          (call $function177
           (local.get $2)
           (local.get $4)
          )
          (if
           (i32.eqz
            (global.get $ready563)
           )
           (then
            (unreachable)
           )
          )
          (br $block)
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global563)
   )
  )
  (return_call $function166
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $function169 (type $call188) (param $0 (ref $type58)) (param $1 i64) (param $2 i64) (result (ref $type181))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $4
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result (ref $type181))
   (i64.eq
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type69)
       (local.tee $5
        (if (result (ref $type68))
         (i32.eq
          (local.get $4)
          (i32.const -1)
         )
         (then
          (global.get $empty69)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $3
             (i64.extend_i32_s
              (local.get $4)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $3)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $3)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type70
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type70 0
         (ref.cast (ref $type70)
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (i64.const 59)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global581)
     )
    )
    (if (result (ref $type181))
     (if (result i32)
      (i64.gt_s
       (local.get $2)
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global584)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (if (result i32)
            (local.tee $4
             (i64.lt_s
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (local.get $4)
            )
            (else
             (i64.gt_s
              (local.get $1)
              (i64.const 57343)
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $1)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $1)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type182
       (i32.const 0)
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (else
      (struct.new $type184
       (i32.const 2)
       (global.get $string12)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global588)
     )
    )
    (if (result (ref $type184))
     (if (result i32)
      (local.tee $4
       (i64.lt_s
        (local.tee $3
         (if (result i64)
          (i32.and
           (i64.le_s
            (local.get $3)
            (i64.const 57)
           )
           (i64.ge_s
            (local.get $3)
            (i64.const 48)
           )
          )
          (then
           (i64.sub
            (local.get $3)
            (i64.const 48)
           )
          )
          (else
           (if (result i64)
            (i32.and
             (i64.le_s
              (local.get $3)
              (i64.const 70)
             )
             (i64.ge_s
              (local.get $3)
              (i64.const 65)
             )
            )
            (then
             (i64.sub
              (local.get $3)
              (i64.const 55)
             )
            )
            (else
             (select
              (i64.sub
               (local.get $3)
               (i64.const 87)
              )
              (i64.const -1)
              (i32.and
               (i64.le_s
                (local.get $3)
                (i64.const 102)
               )
               (i64.ge_s
                (local.get $3)
                (i64.const 97)
               )
              )
             )
            )
           )
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.gt_s
        (local.get $1)
        (i64.const 69631)
       )
      )
     )
     (then
      (struct.new $type184
       (i32.const 2)
       (global.get $string11)
      )
     )
     (else
      (if
       (i32.eqz
        (global.get $ready576)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global576)
       )
      )
      (return_call $function169
       (local.get $0)
       (i64.add
        (local.get $3)
        (i64.shl
         (local.get $1)
         (i64.const 4)
        )
       )
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function174 (type $call186) (param $0 (ref $type58)) (param $1 i64) (result (ref $type181))
  (local $2 i32)
  (local $3 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result (ref $type181))
   (if (result i32)
    (local.tee $2
     (i64.eq
      (local.get $1)
      (i64.const 32)
     )
    )
    (then
     (local.get $2)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (i64.eq
      (local.get $1)
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global530)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (local.set $2
     (call $foreign7
      (struct.get $type56 0
       (struct.get $type58 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global532)
     )
    )
    (local.set $1
     (if (result i64)
      (ref.test (ref $type69)
       (local.tee $3
        (if (result (ref $type68))
         (i32.eq
          (local.get $2)
          (i32.const -1)
         )
         (then
          (global.get $empty69)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $1
             (i64.extend_i32_s
              (local.get $2)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $1)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $1)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type70
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type70 0
         (ref.cast (ref $type70)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready596)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global596)
     )
    )
    (return_call $function174
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (if (result (ref $type181))
     (if (result i32)
      (local.tee $2
       (i64.eq
        (local.get $1)
        (i64.const 10)
       )
      )
      (then
       (local.get $2)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global538)
        )
       )
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global549)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global552)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global137)
         )
        )
        (local.set $2
         (call $foreign8
          (struct.get $type56 0
           (struct.get $type58 0
            (local.get $0)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global133)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global532)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (if
         (i64.eq
          (if (result i64)
           (ref.test (ref $type69)
            (local.tee $3
             (if (result (ref $type68))
              (i32.eq
               (local.get $2)
               (i32.const -1)
              )
              (then
               (global.get $empty69)
              )
              (else
               (if
                (i64.gt_u
                 (local.tee $1
                  (i64.extend_i32_s
                   (local.get $2)
                  )
                 )
                 (i64.const 1114111)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.and
                 (i64.le_u
                  (local.get $1)
                  (i64.const 57343)
                 )
                 (i64.ge_u
                  (local.get $1)
                  (i64.const 55296)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (struct.new $type70
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
            )
           )
           (then
            (i64.const -1)
           )
           (else
            (i64.extend_i32_u
             (struct.get $type70 0
              (ref.cast (ref $type70)
               (local.get $3)
              )
             )
            )
           )
          )
          (i64.const 10)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global135)
           )
          )
          (local.set $2
           (call $foreign7
            (struct.get $type56 0
             (struct.get $type58 0
              (local.get $0)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global133)
           )
          )
          (drop
           (if (result (ref $type68))
            (i32.eq
             (local.get $2)
             (i32.const -1)
            )
            (then
             (global.get $empty69)
            )
            (else
             (if
              (i64.gt_u
               (local.tee $1
                (i64.extend_i32_s
                 (local.get $2)
                )
               )
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $1)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $1)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (struct.new $type70
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global601)
       )
      )
      (drop
       (call $function175
        (local.get $0)
       )
      )
      (global.get $empty183)
     )
     (else
      (struct.new $type184
       (i32.const 2)
       (global.get $string13)
      )
     )
    )
   )
  )
 )
 (func $function175 (type $call60) (param $0 (ref $type58)) (result i32)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global552)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (local.set $2
   (call $foreign8
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $2
     (i64.eq
      (if (result i64)
       (ref.test (ref $type69)
        (local.tee $3
         (if (result (ref $type68))
          (i32.eq
           (local.get $2)
           (i32.const -1)
          )
          (then
           (global.get $empty69)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $1
              (i64.extend_i32_s
               (local.get $2)
              )
             )
             (i64.const 1114111)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.and
             (i64.le_u
              (local.get $1)
              (i64.const 57343)
             )
             (i64.ge_u
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.new $type70
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type70 0
          (ref.cast (ref $type70)
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 32)
     )
    )
    (then
     (local.get $2)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global552)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global137)
      )
     )
     (local.set $2
      (call $foreign8
       (struct.get $type56 0
        (struct.get $type58 0
         (local.get $0)
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global133)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global532)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (i64.eq
      (if (result i64)
       (ref.test (ref $type69)
        (local.tee $3
         (if (result (ref $type68))
          (i32.eq
           (local.get $2)
           (i32.const -1)
          )
          (then
           (global.get $empty69)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $1
              (i64.extend_i32_s
               (local.get $2)
              )
             )
             (i64.const 1114111)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.and
             (i64.le_u
              (local.get $1)
              (i64.const 57343)
             )
             (i64.ge_u
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.new $type70
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type70 0
          (ref.cast (ref $type70)
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (local.set $2
     (call $foreign7
      (struct.get $type56 0
       (struct.get $type58 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (drop
     (if (result (ref $type68))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty69)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type70
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready601)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global601)
     )
    )
    (return_call $function175
     (local.get $0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function177 (type $36) (param $0 (ref $type154)) (param $1 i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type155))
  (if
   (i64.eq
    (local.tee $2
     (struct.get $type156 0
      (struct.get $type154 1
       (local.get $0)
      )
     )
    )
    (i64.extend_i32_u
     (struct.get $type18 1
      (struct.get $type155 0
       (struct.get $type154 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready615)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global615)
     )
    )
    (if
     (i64.ge_s
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global323)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global317)
       )
      )
      (call $foreign12
       (call $function104
        (global.get $string14)
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (select
          (i64.const 4294967294)
          (i64.shl
           (local.get $2)
           (i64.const 1)
          )
          (i64.gt_s
           (local.get $2)
           (i64.const 2147483647)
          )
         )
        )
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $6
        (call $string-new
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i64.const 0)
       (struct.get $type155 0
        (local.tee $7
         (struct.get $type154 0
          (local.get $0)
         )
        )
       )
       (local.get $2)
      )
      (struct.set $type155 0
       (local.get $7)
       (local.get $6)
      )
     )
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (local.tee $5
      (struct.get $type155 0
       (struct.get $type154 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $2)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $5)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type19
   (if (result (ref $type19))
    (i32.lt_u
     (local.tee $4
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type18 2
      (local.get $5)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type20
       (struct.get $type18 3
        (local.get $5)
       )
       (i32.sub
        (i32.shr_u
         (local.get $4)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $4)
    (i32.const 8191)
   )
   (local.get $1)
  )
  (struct.set $type156 0
   (struct.get $type154 1
    (local.get $0)
   )
   (i64.add
    (local.get $2)
    (i64.const 1)
   )
  )
 )
 (func $function182 (type $call161) (param $0 (ref $type58)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type68))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global135)
   )
  )
  (local.set $4
   (call $foreign7
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (if (result i32)
   (i64.lt_s
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type69)
       (local.tee $5
        (if (result (ref $type68))
         (i32.eq
          (local.get $4)
          (i32.const -1)
         )
         (then
          (global.get $empty69)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $2
             (i64.extend_i32_s
              (local.get $4)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $2)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $2)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type70
           (i32.wrap_i64
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type70 0
         (ref.cast (ref $type70)
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (if (result i32)
     (if (result i32)
      (i64.eq
       (local.get $3)
       (i64.const 35)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global549)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global552)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global137)
        )
       )
       (local.set $4
        (call $foreign8
         (struct.get $type56 0
          (struct.get $type58 0
           (local.get $0)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global133)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global532)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global538)
        )
       )
       (if (result i32)
        (i64.eq
         (if (result i64)
          (ref.test (ref $type69)
           (local.tee $5
            (if (result (ref $type68))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty69)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type70
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
          )
          (then
           (i64.const -1)
          )
          (else
           (i64.extend_i32_u
            (struct.get $type70 0
             (ref.cast (ref $type70)
              (local.get $5)
             )
            )
           )
          )
         )
         (i64.const 124)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global135)
          )
         )
         (local.set $4
          (call $foreign7
           (struct.get $type56 0
            (struct.get $type58 0
             (local.get $0)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global133)
          )
         )
         (drop
          (if (result (ref $type68))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
         (i32.const 1)
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready635)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global635)
       )
      )
      (return_call $function182
       (local.get $0)
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (local.get $3)
         (i64.const 124)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global549)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global552)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global137)
          )
         )
         (local.set $4
          (call $foreign8
           (struct.get $type56 0
            (struct.get $type58 0
             (local.get $0)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global133)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global532)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global538)
          )
         )
         (if (result i32)
          (i64.eq
           (if (result i64)
            (ref.test (ref $type69)
             (local.tee $5
              (if (result (ref $type68))
               (i32.eq
                (local.get $4)
                (i32.const -1)
               )
               (then
                (global.get $empty69)
               )
               (else
                (if
                 (i64.gt_u
                  (local.tee $2
                   (i64.extend_i32_s
                    (local.get $4)
                   )
                  )
                  (i64.const 1114111)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i64.le_u
                   (local.get $2)
                   (i64.const 57343)
                  )
                  (i64.ge_u
                   (local.get $2)
                   (i64.const 55296)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (struct.new $type70
                 (i32.wrap_i64
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
            (then
             (i64.const -1)
            )
            (else
             (i64.extend_i32_u
              (struct.get $type70 0
               (ref.cast (ref $type70)
                (local.get $5)
               )
              )
             )
            )
           )
           (i64.const 35)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global135)
            )
           )
           (local.set $4
            (call $foreign7
             (struct.get $type56 0
              (struct.get $type58 0
               (local.get $0)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global133)
            )
           )
           (drop
            (if (result (ref $type68))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty69)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type70
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
           (i32.const 1)
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (if (result i32)
         (local.tee $4
          (i64.eq
           (local.get $1)
           (i64.const 1)
          )
         )
         (then
          (local.get $4)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready635)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global635)
           )
          )
          (return_call $function182
           (local.get $0)
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready635)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global635)
         )
        )
        (return_call $function182
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function184 (type $call152) (param $0 i64) (result i32)
  (local $1 i32)
  (if (result i32)
   (local.tee $1
    (i64.lt_s
     (local.get $0)
     (i64.const 0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global536)
     )
    )
    (if (result i32)
     (local.tee $1
      (if (result i32)
       (i64.ge_s
        (local.get $0)
        (i64.const 0)
       )
       (then
        (if
         (i64.gt_u
          (local.get $0)
          (i64.const 1114111)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.and
          (i64.le_u
           (local.get $0)
           (i64.const 57343)
          )
          (i64.ge_u
           (local.get $0)
           (i64.const 55296)
          )
         )
         (then
          (unreachable)
         )
        )
        (i32.eq
         (call $foreign25
          (i32.wrap_i64
           (local.get $0)
          )
         )
         (i32.const 1)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result i32)
       (local.tee $1
        (i64.eq
         (local.get $0)
         (i64.const 40)
        )
       )
       (then
        (local.get $1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (if (result i32)
         (local.tee $1
          (i64.eq
           (local.get $0)
           (i64.const 41)
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global538)
           )
          )
          (if (result i32)
           (local.tee $1
            (i64.eq
             (local.get $0)
             (i64.const 34)
            )
           )
           (then
            (local.get $1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global538)
             )
            )
            (if (result i32)
             (local.tee $1
              (i64.eq
               (local.get $0)
               (i64.const 59)
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global538)
               )
              )
              (if (result i32)
               (local.tee $1
                (i64.eq
                 (local.get $0)
                 (i64.const 124)
                )
               )
               (then
                (local.get $1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global538)
                 )
                )
                (if (result i32)
                 (local.tee $1
                  (i64.eq
                   (local.get $0)
                   (i64.const 39)
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global538)
                   )
                  )
                  (if (result i32)
                   (local.tee $1
                    (i64.eq
                     (local.get $0)
                     (i64.const 96)
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global538)
                     )
                    )
                    (if (result i32)
                     (local.tee $1
                      (i64.eq
                       (local.get $0)
                       (i64.const 44)
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global538)
                       )
                      )
                      (if (result i32)
                       (local.tee $1
                        (i64.eq
                         (local.get $0)
                         (i64.const 91)
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global538)
                         )
                        )
                        (if (result i32)
                         (local.tee $1
                          (i64.eq
                           (local.get $0)
                           (i64.const 93)
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global538)
                           )
                          )
                          (if (result i32)
                           (local.tee $1
                            (i64.eq
                             (local.get $0)
                             (i64.const 123)
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global538)
                             )
                            )
                            (i64.eq
                             (local.get $0)
                             (i64.const 125)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function186 (type $33) (param $0 (ref $type58)) (param $1 (ref $type154)) (param $2 i32) (param $3 i32) (result (ref $type18))
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type68))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global552)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global137)
   )
  )
  (local.set $5
   (call $foreign8
    (struct.get $type56 0
     (struct.get $type58 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global133)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global643)
   )
  )
  (if (result (ref $type18))
   (call $function184
    (if (result i64)
     (ref.test (ref $type69)
      (local.tee $6
       (if (result (ref $type68))
        (i32.eq
         (local.get $5)
         (i32.const -1)
        )
        (then
         (global.get $empty69)
        )
        (else
         (if
          (i64.gt_u
           (local.tee $4
            (i64.extend_i32_s
             (local.get $5)
            )
           )
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $4)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $4)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.new $type70
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (then
      (i64.const -1)
     )
     (else
      (i64.extend_i32_u
       (struct.get $type70 0
        (ref.cast (ref $type70)
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global568)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global81)
     )
    )
    (local.set $7
     (struct.get $type155 0
      (struct.get $type154 0
       (local.get $1)
      )
     )
    )
    (if (result (ref $type18))
     (if (result i32)
      (local.tee $2
       (i64.lt_s
        (local.tee $4
         (struct.get $type156 0
          (struct.get $type154 1
           (local.get $1)
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $2)
      )
      (else
       (i64.lt_s
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $7)
         )
        )
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $8
        (call $string-new
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (i64.const 0)
       (local.get $7)
       (local.get $4)
      )
      (local.get $8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global530)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global135)
     )
    )
    (local.set $5
     (call $foreign7
      (struct.get $type56 0
       (struct.get $type58 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global133)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global532)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (if (result i64)
        (ref.test (ref $type69)
         (local.tee $6
          (if (result (ref $type68))
           (i32.eq
            (local.get $5)
            (i32.const -1)
           )
           (then
            (global.get $empty69)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $4
               (i64.extend_i32_s
                (local.get $5)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $4)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $4)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type70
             (i32.wrap_i64
              (local.get $4)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type70 0
           (ref.cast (ref $type70)
            (local.get $6)
           )
          )
         )
        )
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $4)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $4)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global611)
     )
    )
    (call $function177
     (local.get $1)
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function186
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
 (func $function189 (type $32) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (result (ref $type18))
  (local $4 i64)
  (local $5 i32)
  (if (result (ref $type18))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.ge_u
       (local.tee $4
        (i64.extend_i32_u
         (array.get $type19
          (if (result (ref $type19))
           (i32.lt_u
            (local.tee $5
             (i32.wrap_i64
              (local.get $3)
             )
            )
            (i32.const 8192)
           )
           (then
            (struct.get $type18 2
             (local.get $0)
            )
           )
           (else
            (ref.as_non_null
             (array.get $type20
              (struct.get $type18 3
               (local.get $0)
              )
              (i32.sub
               (i32.shr_u
                (local.get $5)
                (i32.const 13)
               )
               (i32.const 1)
              )
             )
            )
           )
          )
          (i32.and
           (local.get $5)
           (i32.const 8191)
          )
         )
        )
       )
       (i64.const 65)
      )
      (then
       (i64.le_u
        (local.get $4)
        (i64.const 90)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.tee $4
         (i64.add
          (local.get $4)
          (i64.const 32)
         )
        )
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (struct.get $type18 0
         (local.get $0)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ge_u
        (local.get $3)
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function189
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function192 (type $31) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result (ref $type181))
  (local $5 i64)
  (local $6 i32)
  (if (result (ref $type181))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global581)
     )
    )
    (if (result (ref $type181))
     (if (result i32)
      (i64.gt_s
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global584)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $4)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $4)
           (i64.const 1114111)
          )
          (then
           (if (result i32)
            (local.tee $1
             (i64.lt_s
              (local.get $4)
              (i64.const 55296)
             )
            )
            (then
             (local.get $1)
            )
            (else
             (i64.gt_s
              (local.get $4)
              (i64.const 57343)
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type182
       (i32.const 0)
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (else
      (struct.new $type184
       (i32.const 2)
       (global.get $string12)
      )
     )
    )
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global588)
     )
    )
    (if (result (ref $type184))
     (if (result i32)
      (local.tee $6
       (i64.lt_s
        (local.tee $5
         (if (result i64)
          (i32.and
           (i64.le_u
            (local.tee $5
             (i64.extend_i32_u
              (array.get $type19
               (if (result (ref $type19))
                (i32.lt_u
                 (local.tee $6
                  (i32.wrap_i64
                   (local.get $3)
                  )
                 )
                 (i32.const 8192)
                )
                (then
                 (struct.get $type18 2
                  (local.get $0)
                 )
                )
                (else
                 (ref.as_non_null
                  (array.get $type20
                   (struct.get $type18 3
                    (local.get $0)
                   )
                   (i32.sub
                    (i32.shr_u
                     (local.get $6)
                     (i32.const 13)
                    )
                    (i32.const 1)
                   )
                  )
                 )
                )
               )
               (i32.and
                (local.get $6)
                (i32.const 8191)
               )
              )
             )
            )
            (i64.const 57)
           )
           (i64.ge_u
            (local.get $5)
            (i64.const 48)
           )
          )
          (then
           (i64.sub
            (local.get $5)
            (i64.const 48)
           )
          )
          (else
           (if (result i64)
            (i32.and
             (i64.le_u
              (local.get $5)
              (i64.const 70)
             )
             (i64.ge_u
              (local.get $5)
              (i64.const 65)
             )
            )
            (then
             (i64.sub
              (local.get $5)
              (i64.const 55)
             )
            )
            (else
             (select
              (i64.sub
               (local.get $5)
               (i64.const 87)
              )
              (i64.const -1)
              (i32.and
               (i64.le_u
                (local.get $5)
                (i64.const 102)
               )
               (i64.ge_u
                (local.get $5)
                (i64.const 97)
               )
              )
             )
            )
           )
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $6)
      )
      (else
       (i64.gt_s
        (local.get $4)
        (i64.const 69631)
       )
      )
     )
     (then
      (struct.new $type184
       (i32.const 2)
       (global.get $string32)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function192
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
       (i64.add
        (local.get $5)
        (i64.shl
         (local.get $4)
         (i64.const 4)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function196 (type $call190) (param $0 (ref $type58)) (param $1 (ref $type163)) (result (ref $type130))
  (local $2 (ref $type130))
  (local $3 (ref $type18))
  (local $4 (ref $type13))
  (local $5 (ref $type21))
  (local $6 i32)
  (local $7 i64)
  (if (result (ref $type130))
   (local.tee $6
    (struct.get $type163 0
     (local.get $1)
    )
   )
   (then
    (if (result (ref $type130))
     (i32.eq
      (local.get $6)
      (i32.const 1)
     )
     (then
      (global.get $empty131)
     )
     (else
      (if (result (ref $type130))
       (i32.eq
        (struct.get $type163 0
         (local.get $1)
        )
        (i32.const 6)
       )
       (then
        (struct.new $type133
         (i32.const 2)
         (struct.get $type170 1
          (ref.cast (ref $type170)
           (local.get $1)
          )
         )
        )
       )
       (else
        (if (result (ref $type130))
         (i32.eq
          (struct.get $type163 0
           (local.get $1)
          )
          (i32.const 4)
         )
         (then
          (local.set $7
           (struct.get $type168 1
            (ref.cast (ref $type168)
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready709)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global709)
           )
          )
          (return_call $function197
           (local.get $0)
           (local.get $7)
           (ref.null none)
          )
         )
         (else
          (if (result (ref $type130))
           (i32.eq
            (struct.get $type163 0
             (local.get $1)
            )
            (i32.const 5)
           )
           (then
            (local.set $3
             (struct.get $type169 1
              (ref.cast (ref $type169)
               (local.get $1)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready780)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global780)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global525)
             )
            )
            (if
             (i32.eqz
              (global.get $ready527)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global527)
             )
            )
            (local.set $1
             (call $function154
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready702)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global702)
             )
            )
            (if (result (ref $type130))
             (i32.eq
              (struct.get $type130 0
               (local.tee $2
                (call $function196
                 (local.get $0)
                 (local.get $1)
                )
               )
              )
              (i32.const 1)
             )
             (then
              (local.set $4
               (struct.get $type132 1
                (ref.cast (ref $type132)
                 (local.get $2)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global329)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global317)
               )
              )
              (local.set $5
               (struct.new $type21
                (i32.const 4)
                (struct.new $type22
                 (call $foreign15
                  (call $function104
                   (local.get $3)
                  )
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global422)
               )
              )
              (struct.new $type132
               (i32.const 1)
               (struct.new $type31
                (i32.const 6)
                (struct.new $type32
                 (local.get $5)
                )
                (struct.new $type32
                 (struct.new $type31
                  (i32.const 6)
                  (struct.new $type32
                   (local.get $4)
                  )
                  (struct.new $type32
                   (global.get $empty14)
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type133))
               (struct.get $type130 0
                (local.get $2)
               )
               (then
                (struct.new $type133
                 (i32.const 2)
                 (struct.get $type133 1
                  (ref.cast (ref $type133)
                   (local.get $2)
                  )
                 )
                )
               )
               (else
                (struct.new $type133
                 (i32.const 2)
                 (global.get $string51)
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type133))
             (i32.eq
              (struct.get $type163 0
               (local.get $1)
              )
              (i32.const 2)
             )
             (then
              (struct.new $type133
               (i32.const 2)
               (global.get $string41)
              )
             )
             (else
              (struct.new $type133
               (i32.const 2)
               (global.get $string40)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (struct.new $type132
     (i32.const 1)
     (struct.get $type164 1
      (ref.cast (ref $type164)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function197 (type $27) (param $0 (ref $type58)) (param $1 i64) (param $2 (ref null $type12)) (result (ref $type130))
  (local $3 (ref null $type12))
  (local $4 (ref null $type12))
  (local $5 (ref $type31))
  (local $6 (ref $type12))
  (local $7 (ref $type163))
  (local $8 (ref $type34))
  (local $9 (ref $type130))
  (local $10 (ref $type14))
  (local $11 (ref $type13))
  (local $12 i32)
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (if (result (ref $type130))
   (i32.eq
    (struct.get $type163 0
     (local.tee $7
      (call $function154
       (local.get $0)
      )
     )
    )
    (i32.const 2)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready715)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global715)
     )
    )
    (if (result (ref $type132))
     (i64.eqz
      (local.get $1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global718)
       )
      )
      (local.set $10
       (global.get $empty14)
      )
      (struct.new $type132
       (i32.const 1)
       (if (result (ref $type13))
        (ref.is_null
         (local.get $2)
        )
        (then
         (local.get $10)
        )
        (else
         (local.set $4
          (struct.get $type12 1
           (local.get $2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global422)
          )
         )
         (if
          (i32.eqz
           (global.get $ready718)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global718)
          )
         )
         (local.set $5
          (struct.new $type31
           (i32.const 6)
           (struct.new $type32
            (struct.get $type12 0
             (local.get $2)
            )
           )
           (struct.new $type32
            (local.get $10)
           )
          )
         )
         (if (result (ref $type13))
          (ref.is_null
           (local.get $4)
          )
          (then
           (local.get $5)
          )
          (else
           (local.set $3
            (struct.get $type12 1
             (local.get $4)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global422)
            )
           )
           (if
            (i32.eqz
             (global.get $ready718)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global718)
            )
           )
           (local.set $5
            (struct.new $type31
             (i32.const 6)
             (struct.new $type32
              (struct.get $type12 0
               (local.get $4)
              )
             )
             (struct.new $type32
              (local.get $5)
             )
            )
           )
           (if (result (ref $type13))
            (ref.is_null
             (local.get $3)
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $4
              (struct.get $type12 1
               (local.get $3)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global422)
              )
             )
             (if
              (i32.eqz
               (global.get $ready718)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global718)
              )
             )
             (local.set $5
              (struct.new $type31
               (i32.const 6)
               (struct.new $type32
                (struct.get $type12 0
                 (local.get $3)
                )
               )
               (struct.new $type32
                (local.get $5)
               )
              )
             )
             (if (result (ref $type13))
              (ref.is_null
               (local.get $4)
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $3
                (struct.get $type12 1
                 (local.get $4)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global422)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready718)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global718)
                )
               )
               (local.set $5
                (struct.new $type31
                 (i32.const 6)
                 (struct.new $type32
                  (struct.get $type12 0
                   (local.get $4)
                  )
                 )
                 (struct.new $type32
                  (local.get $5)
                 )
                )
               )
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $4
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global422)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready718)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global718)
                  )
                 )
                 (local.set $5
                  (struct.new $type31
                   (i32.const 6)
                   (struct.new $type32
                    (struct.get $type12 0
                     (local.get $3)
                    )
                   )
                   (struct.new $type32
                    (local.get $5)
                   )
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type12 1
                     (local.get $4)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global422)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready718)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global718)
                    )
                   )
                   (local.set $5
                    (struct.new $type31
                     (i32.const 6)
                     (struct.new $type32
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (struct.new $type32
                      (local.get $5)
                     )
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $4
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global422)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready718)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global718)
                      )
                     )
                     (local.set $5
                      (struct.new $type31
                       (i32.const 6)
                       (struct.new $type32
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (struct.new $type32
                        (local.get $5)
                       )
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type12 1
                         (local.get $4)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global422)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready718)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global718)
                        )
                       )
                       (local.set $5
                        (struct.new $type31
                         (i32.const 6)
                         (struct.new $type32
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (struct.new $type32
                          (local.get $5)
                         )
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (call $function199
                          (struct.get $type12 1
                           (local.get $3)
                          )
                          (block (result (ref (exact $type31)))
                           (drop
                            (ref.as_non_null
                             (global.get $global422)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready718)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global718)
                            )
                           )
                           (struct.new $type31
                            (i32.const 6)
                            (struct.new $type32
                             (struct.get $type12 0
                              (local.get $3)
                             )
                            )
                            (struct.new $type32
                             (local.get $5)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (if (result (ref $type132))
       (i64.eq
        (local.get $1)
        (i64.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global721)
         )
        )
        (local.set $4
         (if (result (ref null $type12))
          (ref.is_null
           (local.get $2)
          )
          (then
           (ref.null none)
          )
          (else
           (local.set $6
            (struct.new $type12
             (struct.get $type12 0
              (local.get $2)
             )
             (ref.null none)
            )
           )
           (if (result (ref null $type12))
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (local.get $6)
            )
            (else
             (local.set $6
              (struct.new $type12
               (struct.get $type12 0
                (local.get $3)
               )
               (local.get $6)
              )
             )
             (if (result (ref null $type12))
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $6
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $3)
                 )
                 (local.get $6)
                )
               )
               (if (result (ref null $type12))
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (local.get $6)
                )
                (else
                 (local.set $6
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $3)
                   )
                   (local.get $6)
                  )
                 )
                 (if (result (ref null $type12))
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $6
                    (struct.new $type12
                     (struct.get $type12 0
                      (local.get $3)
                     )
                     (local.get $6)
                    )
                   )
                   (if (result (ref null $type12))
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (local.get $6)
                    )
                    (else
                     (local.set $6
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $3)
                       )
                       (local.get $6)
                      )
                     )
                     (if (result (ref null $type12))
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $6
                        (struct.new $type12
                         (struct.get $type12 0
                          (local.get $3)
                         )
                         (local.get $6)
                        )
                       )
                       (if (result (ref null $type12))
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (local.get $6)
                        )
                        (else
                         (local.set $6
                          (struct.new $type12
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (local.get $6)
                          )
                         )
                         (if (result (ref null $type12))
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (call $function201
                            (i32.const 0)
                            (i32.const 1)
                            (struct.get $type12 1
                             (local.get $3)
                            )
                            (struct.new $type12
                             (struct.get $type12 0
                              (local.get $3)
                             )
                             (local.get $6)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global726)
         )
        )
        (struct.new $type132
         (i32.const 1)
         (struct.new $type33
          (i32.const 7)
          (if (result (ref $type34))
           (ref.is_null
            (local.get $4)
           )
           (then
            (array.new_fixed $type34 0)
           )
           (else
            (if
             (i32.eqz
              (global.get $ready729)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global729)
             )
            )
            (if
             (i64.gt_u
              (local.tee $1
               (if (result i64)
                (ref.is_null
                 (local.get $4)
                )
                (then
                 (i64.const 0)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (i64.const 1)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 2)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 3)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 4)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 5)
                          )
                          (else
                           (if (result i64)
                            (ref.is_null
                             (local.tee $3
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                            )
                            (then
                             (i64.const 6)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.tee $3
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                               )
                              )
                              (then
                               (i64.const 7)
                              )
                              (else
                               (call $function204
                                (i32.const 0)
                                (i32.const 1)
                                (struct.get $type12 1
                                 (local.get $3)
                                )
                                (i64.const 8)
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
              (i64.const 4294967295)
             )
             (then
              (unreachable)
             )
            )
            (local.set $8
             (array.new $type34
              (struct.get $type12 0
               (local.get $4)
              )
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
            (if (result (ref $type34))
             (ref.is_null
              (local.get $4)
             )
             (then
              (local.get $8)
             )
             (else
              (array.set $type34
               (local.get $8)
               (i32.const 0)
               (struct.get $type12 0
                (local.get $4)
               )
              )
              (if (result (ref $type34))
               (ref.is_null
                (local.tee $3
                 (struct.get $type12 1
                  (local.get $4)
                 )
                )
               )
               (then
                (local.get $8)
               )
               (else
                (array.set $type34
                 (local.get $8)
                 (i32.const 1)
                 (struct.get $type12 0
                  (local.get $3)
                 )
                )
                (if (result (ref $type34))
                 (ref.is_null
                  (local.tee $3
                   (struct.get $type12 1
                    (local.get $3)
                   )
                  )
                 )
                 (then
                  (local.get $8)
                 )
                 (else
                  (array.set $type34
                   (local.get $8)
                   (i32.const 2)
                   (struct.get $type12 0
                    (local.get $3)
                   )
                  )
                  (if (result (ref $type34))
                   (ref.is_null
                    (local.tee $3
                     (struct.get $type12 1
                      (local.get $3)
                     )
                    )
                   )
                   (then
                    (local.get $8)
                   )
                   (else
                    (array.set $type34
                     (local.get $8)
                     (i32.const 3)
                     (struct.get $type12 0
                      (local.get $3)
                     )
                    )
                    (if (result (ref $type34))
                     (ref.is_null
                      (local.tee $3
                       (struct.get $type12 1
                        (local.get $3)
                       )
                      )
                     )
                     (then
                      (local.get $8)
                     )
                     (else
                      (array.set $type34
                       (local.get $8)
                       (i32.const 4)
                       (struct.get $type12 0
                        (local.get $3)
                       )
                      )
                      (if (result (ref $type34))
                       (ref.is_null
                        (local.tee $3
                         (struct.get $type12 1
                          (local.get $3)
                         )
                        )
                       )
                       (then
                        (local.get $8)
                       )
                       (else
                        (array.set $type34
                         (local.get $8)
                         (i32.const 5)
                         (struct.get $type12 0
                          (local.get $3)
                         )
                        )
                        (if (result (ref $type34))
                         (ref.is_null
                          (local.tee $3
                           (struct.get $type12 1
                            (local.get $3)
                           )
                          )
                         )
                         (then
                          (local.get $8)
                         )
                         (else
                          (array.set $type34
                           (local.get $8)
                           (i32.const 6)
                           (struct.get $type12 0
                            (local.get $3)
                           )
                          )
                          (if (result (ref $type34))
                           (ref.is_null
                            (local.tee $3
                             (struct.get $type12 1
                              (local.get $3)
                             )
                            )
                           )
                           (then
                            (local.get $8)
                           )
                           (else
                            (array.set $type34
                             (local.get $8)
                             (i32.const 7)
                             (struct.get $type12 0
                              (local.get $3)
                             )
                            )
                            (if (result (ref $type34))
                             (ref.is_null
                              (local.tee $3
                               (struct.get $type12 1
                                (local.get $3)
                               )
                              )
                             )
                             (then
                              (local.get $8)
                             )
                             (else
                              (array.set $type34
                               (local.get $8)
                               (i32.const 8)
                               (struct.get $type12 0
                                (local.get $3)
                               )
                              )
                              (call $function205
                               (local.get $8)
                               (i32.const 0)
                               (i32.const 1)
                               (struct.get $type12 1
                                (local.get $3)
                               )
                               (i64.const 9)
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready737)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global737)
         )
        )
        (local.set $1
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i64.const 0)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 1)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (i64.const 2)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 3)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 4)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 5)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 6)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 7)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 8)
                          )
                          (else
                           (call $function207
                            (i32.const 0)
                            (i32.const 1)
                            (struct.get $type12 1
                             (local.get $3)
                            )
                            (i64.const 9)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global180)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready743)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global743)
         )
        )
        (return_call $function208
         (local.get $2)
         (struct.new $type36
          (array.new_default $type37
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (else
    (if (result (ref $type130))
     (i32.eq
      (struct.get $type163 0
       (local.get $7)
      )
      (i32.const 1)
     )
     (then
      (struct.new $type133
       (i32.const 2)
       (global.get $string43)
      )
     )
     (else
      (if (result (ref $type130))
       (i32.eq
        (struct.get $type163 0
         (local.get $7)
        )
        (i32.const 3)
       )
       (then
        (if (result (ref $type130))
         (i32.and
          (i32.eqz
           (ref.is_null
            (local.get $2)
           )
          )
          (i64.eqz
           (local.get $1)
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready756)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global756)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global525)
           )
          )
          (if
           (i32.eqz
            (global.get $ready527)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global527)
           )
          )
          (local.set $7
           (call $function154
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (global.get $ready702)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global702)
           )
          )
          (if (result (ref $type130))
           (i32.eq
            (struct.get $type130 0
             (local.tee $9
              (call $function196
               (local.get $0)
               (local.get $7)
              )
             )
            )
            (i32.const 1)
           )
           (then
            (local.set $11
             (struct.get $type132 1
              (ref.cast (ref $type132)
               (local.get $9)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global527)
             )
            )
            (if (result (ref $type130))
             (i32.eq
              (struct.get $type163 0
               (local.tee $7
                (call $function154
                 (local.get $0)
                )
               )
              )
              (i32.const 2)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready718)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global718)
               )
              )
              (struct.new $type132
               (i32.const 1)
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (local.get $11)
                )
                (else
                 (local.set $4
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global422)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready718)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global718)
                  )
                 )
                 (local.set $5
                  (struct.new $type31
                   (i32.const 6)
                   (struct.new $type32
                    (struct.get $type12 0
                     (local.get $2)
                    )
                   )
                   (struct.new $type32
                    (local.get $11)
                   )
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type12 1
                     (local.get $4)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global422)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready718)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global718)
                    )
                   )
                   (local.set $5
                    (struct.new $type31
                     (i32.const 6)
                     (struct.new $type32
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (struct.new $type32
                      (local.get $5)
                     )
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $4
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global422)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready718)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global718)
                      )
                     )
                     (local.set $5
                      (struct.new $type31
                       (i32.const 6)
                       (struct.new $type32
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (struct.new $type32
                        (local.get $5)
                       )
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type12 1
                         (local.get $4)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global422)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready718)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global718)
                        )
                       )
                       (local.set $5
                        (struct.new $type31
                         (i32.const 6)
                         (struct.new $type32
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (struct.new $type32
                          (local.get $5)
                         )
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $4
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global422)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready718)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global718)
                          )
                         )
                         (local.set $5
                          (struct.new $type31
                           (i32.const 6)
                           (struct.new $type32
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (struct.new $type32
                            (local.get $5)
                           )
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.get $4)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (local.set $3
                            (struct.get $type12 1
                             (local.get $4)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global422)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready718)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global718)
                            )
                           )
                           (local.set $5
                            (struct.new $type31
                             (i32.const 6)
                             (struct.new $type32
                              (struct.get $type12 0
                               (local.get $4)
                              )
                             )
                             (struct.new $type32
                              (local.get $5)
                             )
                            )
                           )
                           (if (result (ref $type13))
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (local.set $4
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global422)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready718)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global718)
                              )
                             )
                             (local.set $5
                              (struct.new $type31
                               (i32.const 6)
                               (struct.new $type32
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (struct.new $type32
                                (local.get $5)
                               )
                              )
                             )
                             (if (result (ref $type13))
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (local.set $3
                                (struct.get $type12 1
                                 (local.get $4)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global422)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready718)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global718)
                                )
                               )
                               (local.set $5
                                (struct.new $type31
                                 (i32.const 6)
                                 (struct.new $type32
                                  (struct.get $type12 0
                                   (local.get $4)
                                  )
                                 )
                                 (struct.new $type32
                                  (local.get $5)
                                 )
                                )
                               )
                               (if (result (ref $type13))
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (local.get $5)
                                )
                                (else
                                 (call $function199
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                  (block (result (ref (exact $type31)))
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global422)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready718)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global718)
                                    )
                                   )
                                   (struct.new $type31
                                    (i32.const 6)
                                    (struct.new $type32
                                     (struct.get $type12 0
                                      (local.get $3)
                                     )
                                    )
                                    (struct.new $type32
                                     (local.get $5)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type133))
               (i32.eq
                (struct.get $type163 0
                 (local.get $7)
                )
                (i32.const 6)
               )
               (then
                (struct.new $type133
                 (i32.const 2)
                 (struct.get $type170 1
                  (ref.cast (ref $type170)
                   (local.get $7)
                  )
                 )
                )
               )
               (else
                (if (result (ref $type133))
                 (local.tee $12
                  (struct.get $type163 0
                   (local.get $7)
                  )
                 )
                 (then
                  (if (result (ref $type133))
                   (i32.eq
                    (local.get $12)
                    (i32.const 1)
                   )
                   (then
                    (struct.new $type133
                     (i32.const 2)
                     (global.get $string49)
                    )
                   )
                   (else
                    (if (result (ref $type133))
                     (i32.eq
                      (struct.get $type163 0
                       (local.get $7)
                      )
                      (i32.const 3)
                     )
                     (then
                      (struct.new $type133
                       (i32.const 2)
                       (global.get $string48)
                      )
                     )
                     (else
                      (if (result (ref $type133))
                       (i32.eq
                        (struct.get $type163 0
                         (local.get $7)
                        )
                        (i32.const 4)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type168)
                          (local.get $7)
                         )
                        )
                        (struct.new $type133
                         (i32.const 2)
                         (global.get $string47)
                        )
                       )
                       (else
                        (drop
                         (ref.cast (ref $type169)
                          (local.get $7)
                         )
                        )
                        (struct.new $type133
                         (i32.const 2)
                         (global.get $string46)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.cast (ref $type164)
                    (local.get $7)
                   )
                  )
                  (struct.new $type133
                   (i32.const 2)
                   (global.get $string50)
                  )
                 )
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type133))
             (struct.get $type130 0
              (local.get $9)
             )
             (then
              (struct.new $type133
               (i32.const 2)
               (struct.get $type133 1
                (ref.cast (ref $type133)
                 (local.get $9)
                )
               )
              )
             )
             (else
              (struct.new $type133
               (i32.const 2)
               (global.get $string45)
              )
             )
            )
           )
          )
         )
         (else
          (struct.new $type133
           (i32.const 2)
           (global.get $string42)
          )
         )
        )
       )
       (else
        (if (result (ref $type133))
         (i32.eq
          (struct.get $type163 0
           (local.get $7)
          )
          (i32.const 6)
         )
         (then
          (struct.new $type133
           (i32.const 2)
           (struct.get $type170 1
            (ref.cast (ref $type170)
             (local.get $7)
            )
           )
          )
         )
         (else
          (if (result (ref $type133))
           (local.tee $12
            (struct.get $type163 0
             (local.get $7)
            )
           )
           (then
            (if
             (i32.eq
              (local.get $12)
              (i32.const 4)
             )
             (then
              (drop
               (ref.cast (ref $type168)
                (local.get $7)
               )
              )
             )
             (else
              (drop
               (ref.cast (ref $type169)
                (local.get $7)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global702)
             )
            )
            (local.set $9
             (call $function196
              (local.get $0)
              (local.get $7)
             )
            )
            (if
             (i32.eqz
              (global.get $ready770)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global770)
             )
            )
            (if (result (ref $type133))
             (i32.eq
              (struct.get $type130 0
               (local.get $9)
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global709)
               )
              )
              (return_call $function197
               (local.get $0)
               (local.get $1)
               (struct.new $type12
                (struct.get $type132 1
                 (ref.cast (ref $type132)
                  (local.get $9)
                 )
                )
                (local.get $2)
               )
              )
             )
             (else
              (if (result (ref $type133))
               (i32.eq
                (struct.get $type130 0
                 (local.get $9)
                )
                (i32.const 2)
               )
               (then
                (struct.new $type133
                 (i32.const 2)
                 (struct.get $type133 1
                  (ref.cast (ref $type133)
                   (local.get $9)
                  )
                 )
                )
               )
               (else
                (unreachable)
               )
              )
             )
            )
           )
           (else
            (local.set $6
             (struct.new $type12
              (struct.get $type164 1
               (ref.cast (ref $type164)
                (local.get $7)
               )
              )
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready709)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global709)
             )
            )
            (return_call $function197
             (local.get $0)
             (local.get $1)
             (local.get $6)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function199 (type $call195) (param $0 (ref null $type12)) (param $1 (ref $type31)) (result (ref $type13))
  (local $2 (ref null $type12))
  (local $scratch (ref (exact $type31)))
  (if (result (ref $type31))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function199
     (struct.get $type12 1
      (local.get $0)
     )
     (block (result (ref (exact $type31)))
      (drop
       (ref.as_non_null
        (global.get $global422)
       )
      )
      (local.set $scratch
       (struct.new $type31
        (i32.const 6)
        (struct.new $type32
         (struct.get $type12 0
          (local.get $0)
         )
        )
        (struct.new $type32
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready718)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global718)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function201 (type $20) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 (ref $type12)) (result (ref null $type12))
  (local $4 (ref null $type12))
  (if (result (ref $type12))
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (local.set $3
     (struct.new $type12
      (struct.get $type12 0
       (local.get $2)
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function201
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $3)
    )
   )
  )
 )
 (func $function204 (type $19) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function204
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function205 (type $18) (param $0 (ref $type34)) (param $1 i32) (param $2 i32) (param $3 (ref null $type12)) (param $4 i64) (result (ref $type34))
  (local $5 (ref $type13))
  (if (result (ref $type34))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (local.set $5
     (struct.get $type12 0
      (local.get $3)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type34
     (local.get $0)
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $5)
    )
    (local.set $3
     (struct.get $type12 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function205
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function207 (type $19) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function207
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function208 (type $call199) (param $0 (ref null $type12)) (param $1 (ref $type36)) (param $2 i64) (result (ref $type130))
  (local $3 (ref $type13))
  (local $4 (ref $type24))
  (local $5 i32)
  (local $6 i64)
  (local $7 i64)
  (if (result (ref $type130))
   (ref.is_null
    (local.get $0)
   )
   (then
    (struct.new $type132
     (i32.const 1)
     (struct.new $type35
      (i32.const 8)
      (local.get $1)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global748)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global447)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global435)
     )
    )
    (if (result (ref $type133))
     (if (result i32)
      (local.tee $5
       (i64.lt_s
        (local.tee $6
         (if (result i64)
          (i64.eq
           (if (result i64)
            (local.tee $5
             (struct.get $type13 0
              (local.tee $3
               (struct.get $type12 0
                (local.get $0)
               )
              )
             )
            )
            (then
             (if (result i64)
              (i32.eq
               (local.get $5)
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type15)
                 (local.get $3)
                )
               )
               (i64.const 1)
              )
              (else
               (if (result i64)
                (i32.eq
                 (struct.get $type13 0
                  (local.get $3)
                 )
                 (i32.const 2)
                )
                (then
                 (drop
                  (ref.cast (ref $type16)
                   (local.get $3)
                  )
                 )
                 (i64.const 2)
                )
                (else
                 (if (result i64)
                  (i32.eq
                   (struct.get $type13 0
                    (local.get $3)
                   )
                   (i32.const 3)
                  )
                  (then
                   (drop
                    (ref.cast (ref $type17)
                     (local.get $3)
                    )
                   )
                   (i64.const 3)
                  )
                  (else
                   (if (result i64)
                    (i32.eq
                     (struct.get $type13 0
                      (local.get $3)
                     )
                     (i32.const 4)
                    )
                    (then
                     (drop
                      (ref.cast (ref $type21)
                       (local.get $3)
                      )
                     )
                     (i64.const 4)
                    )
                    (else
                     (if (result i64)
                      (i32.eq
                       (struct.get $type13 0
                        (local.get $3)
                       )
                       (i32.const 5)
                      )
                      (then
                       (drop
                        (ref.cast (ref $type23)
                         (local.get $3)
                        )
                       )
                       (i64.const 5)
                      )
                      (else
                       (if (result i64)
                        (i32.eq
                         (struct.get $type13 0
                          (local.get $3)
                         )
                         (i32.const 6)
                        )
                        (then
                         (drop
                          (ref.cast (ref $type31)
                           (local.get $3)
                          )
                         )
                         (i64.const 6)
                        )
                        (else
                         (if (result i64)
                          (i32.eq
                           (struct.get $type13 0
                            (local.get $3)
                           )
                           (i32.const 7)
                          )
                          (then
                           (drop
                            (ref.cast (ref $type33)
                             (local.get $3)
                            )
                           )
                           (i64.const 7)
                          )
                          (else
                           (drop
                            (ref.cast (ref $type35)
                             (local.get $3)
                            )
                           )
                           (i64.const 8)
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
            (else
             (i64.const 0)
            )
           )
           (i64.const 5)
          )
          (then
           (if
            (i32.ne
             (struct.get $type13 0
              (local.get $3)
             )
             (i32.const 5)
            )
            (then
             (unreachable)
            )
           )
           (if (result i64)
            (struct.get $type24 0
             (local.tee $4
              (struct.get $type23 1
               (ref.cast (ref $type23)
                (local.get $3)
               )
              )
             )
            )
            (then
             (if
              (i32.eq
               (struct.get $type24 0
                (local.get $4)
               )
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type26)
                 (local.get $4)
                )
               )
              )
              (else
               (drop
                (ref.cast (ref $type27)
                 (local.get $4)
                )
               )
              )
             )
             (i64.const -1)
            )
            (else
             (struct.get $type25 1
              (ref.cast (ref $type25)
               (local.get $4)
              )
             )
            )
           )
          )
          (else
           (i64.const -1)
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $5)
      )
      (else
       (i64.gt_s
        (local.get $6)
        (i64.const 255)
       )
      )
     )
     (then
      (struct.new $type133
       (i32.const 2)
       (global.get $string44)
      )
     )
     (else
      (if
       (i64.gt_u
        (local.tee $7
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $6)
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type37
       (struct.get $type36 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $7)
       )
       (i32.wrap_i64
        (local.get $6)
       )
      )
      (return_call $function208
       (struct.get $type12 1
        (local.get $0)
       )
       (block (result (ref $type36))
        (if
         (i32.eqz
          (global.get $ready743)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global743)
         )
        )
        (local.get $1)
       )
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function214 (type $call147) (param $0 (ref $type58)) (result (ref $type130))
  (local $1 (ref $type130))
  (local $2 (ref $type163))
  (local $3 (ref $type18))
  (local $scratch (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (if
   (i32.eqz
    (global.get $ready527)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (local.set $2
   (call $function154
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready702)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global702)
   )
  )
  (if (result (ref $type130))
   (i32.eq
    (struct.get $type130 0
     (local.tee $1
      (call $function196
       (local.get $0)
       (local.get $2)
      )
     )
    )
    (i32.const 2)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global90)
     )
    )
    (call $foreign12
     (call $function104
      (block (result (ref $type18))
       (local.set $scratch
        (call $function35
         (struct.new $type48
          (global.get $string2)
          (struct.new $type48
           (struct.get $type133 1
            (ref.cast (ref $type133)
             (local.get $1)
            )
           )
           (ref.null none)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global323)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global317)
        )
       )
       (local.get $scratch)
      )
     )
    )
    (unreachable)
   )
   (else
    (if
     (i32.eq
      (struct.get $type130 0
       (local.get $1)
      )
      (i32.const 1)
     )
     (then
      (drop
       (ref.cast (ref $type132)
        (local.get $1)
       )
      )
     )
    )
    (local.get $1)
   )
  )
 )
 (func $function219 (type $14) (param $0 (ref $type58)) (param $1 i32) (param $2 i32) (param $3 (ref $type130)) (param $4 (ref $type13)) (param $5 i64) (result (ref $type13))
  (local $6 i32)
  (local $7 (ref $type130))
  (drop
   (ref.as_non_null
    (global.get $global515)
   )
  )
  (if (result (ref $type13))
   (if (result i32)
    (local.tee $6
     (struct.get $type130 0
      (local.get $3)
     )
    )
    (then
     (if
      (i32.eq
       (local.get $6)
       (i32.const 1)
      )
      (then
       (drop
        (ref.cast (ref $type132)
         (local.get $3)
        )
       )
      )
      (else
       (drop
        (ref.cast (ref $type133)
         (local.get $3)
        )
       )
      )
     )
     (i32.const 0)
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (local.get $4)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global788)
     )
    )
    (local.set $7
     (call $function214
      (local.get $0)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global520)
     )
    )
    (local.set $4
     (call $function152
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function219
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $7)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function225 (type $call52) (param $0 (ref $type18)) (result i32)
  (local $1 i64)
  (call $foreign27
   (local.tee $1
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign28
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign28
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign28
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign28
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign28
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign28
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign28
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign28
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign28
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign28
                       (array.get $type19
                        (call $string-block
                         (local.get $0)
                         (i32.const 9)
                        )
                        (i32.const 9)
                       )
                      )
                      (return_call $function226
                       (local.get $0)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function226 (type $12) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign28
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $4
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (i32.and
       (local.get $4)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function226
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function229 (type $call206) (param $0 (ref $type13)) (result i32)
  (local $1 (ref $type34))
  (local $2 (ref $type37))
  (local $3 (ref $type36))
  (local $4 (ref $type28))
  (local $5 (ref $type24))
  (local $6 (ref $type18))
  (local $7 (ref $type22))
  (local $8 (ref $type27))
  (local $9 (ref $type31))
  (local $10 (ref $type32))
  (local $11 i64)
  (local $12 i32)
  (local $13 f64)
  (local $scratch i32)
  (local $scratch_15 (ref $type18))
  (local $scratch_16 (ref $type22))
  (local $scratch_17 (ref $type18))
  (local $scratch_18 f64)
  (local $scratch_19 i64)
  (local $scratch_20 f64)
  (local $scratch_21 i64)
  (local $scratch_22 f64)
  (local $scratch_23 i64)
  (local $scratch_24 (ref $type32))
  (if (result i32)
   (local.tee $12
    (struct.get $type13 0
     (local.get $0)
    )
   )
   (then
    (if (result i32)
     (i32.eq
      (local.get $12)
      (i32.const 1)
     )
     (then
      (call $foreign27
       (i64.extend_i32_u
        (i32.ne
         (struct.get $type15 1
          (ref.cast (ref $type15)
           (local.get $0)
          )
         )
         (block (result i32)
          (call $foreign27
           (i64.const 1)
          )
          (i32.const 0)
         )
        )
       )
      )
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i32.eq
        (struct.get $type13 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (call $foreign28
         (block (result i32)
          (local.set $scratch
           (struct.get $type16 1
            (ref.cast (ref $type16)
             (local.get $0)
            )
           )
          )
          (call $foreign27
           (i64.const 2)
          )
          (local.get $scratch)
         )
        )
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i32.eq
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 3)
         )
         (then
          (return_call $function225
           (block (result (ref $type18))
            (local.set $scratch_15
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (local.get $0)
              )
             )
            )
            (call $foreign27
             (i64.const 3)
            )
            (drop
             (ref.as_non_null
              (global.get $global832)
             )
            )
            (local.get $scratch_15)
           )
          )
         )
         (else
          (if (result i32)
           (i32.eq
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 4)
           )
           (then
            (local.set $11
             (call $foreign16
              (local.tee $12
               (struct.get $type22 0
                (block (result (ref $type22))
                 (local.set $scratch_16
                  (struct.get $type21 1
                   (ref.cast (ref $type21)
                    (local.get $0)
                   )
                  )
                 )
                 (call $foreign27
                  (i64.const 4)
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global334)
                  )
                 )
                 (local.get $scratch_16)
                )
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global61)
             )
            )
            (if
             (i64.gt_u
              (local.get $11)
              (i64.const 4294967294)
             )
             (then
              (unreachable)
             )
            )
            (return_call $function225
             (block (result (ref $type18))
              (local.set $scratch_17
               (call $function111
                (local.get $12)
                (local.get $11)
                (call $string-new
                 (i32.wrap_i64
                  (local.get $11)
                 )
                )
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global832)
               )
              )
              (local.get $scratch_17)
             )
            )
           )
           (else
            (if (result i32)
             (i32.eq
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 5)
             )
             (then
              (local.set $5
               (struct.get $type23 1
                (ref.cast (ref $type23)
                 (local.get $0)
                )
               )
              )
              (call $foreign27
               (i64.const 5)
              )
              (drop
               (ref.as_non_null
                (global.get $global841)
               )
              )
              (if (result i32)
               (local.tee $12
                (struct.get $type24 0
                 (local.get $5)
                )
               )
               (then
                (if (result i32)
                 (i32.eq
                  (local.get $12)
                  (i32.const 1)
                 )
                 (then
                  (call $foreign29
                   (block (result f64)
                    (local.set $scratch_18
                     (struct.get $type26 1
                      (ref.cast (ref $type26)
                       (local.get $5)
                      )
                     )
                    )
                    (call $foreign27
                     (i64.const 1)
                    )
                    (local.get $scratch_18)
                   )
                  )
                  (i32.const 0)
                 )
                 (else
                  (local.set $4
                   (struct.get $type27 1
                    (local.tee $8
                     (ref.cast (ref $type27)
                      (local.get $5)
                     )
                    )
                   )
                  )
                  (call $foreign27
                   (i64.const 2)
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global836)
                   )
                  )
                  (drop
                   (if (result i32)
                    (ref.test (ref $type29)
                     (local.get $4)
                    )
                    (then
                     (call $foreign27
                      (block (result i64)
                       (local.set $scratch_19
                        (struct.get $type29 0
                         (ref.cast (ref $type29)
                          (local.get $4)
                         )
                        )
                       )
                       (call $foreign27
                        (i64.const 0)
                       )
                       (local.get $scratch_19)
                      )
                     )
                     (i32.const 0)
                    )
                    (else
                     (call $foreign29
                      (block (result f64)
                       (local.set $scratch_20
                        (struct.get $type30 0
                         (ref.cast (ref $type30)
                          (local.get $4)
                         )
                        )
                       )
                       (call $foreign27
                        (i64.const 1)
                       )
                       (local.get $scratch_20)
                      )
                     )
                     (i32.const 0)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global836)
                   )
                  )
                  (if
                   (ref.test (ref $type29)
                    (local.tee $4
                     (struct.get $type27 2
                      (local.get $8)
                     )
                    )
                   )
                   (then
                    (call $foreign27
                     (block (result i64)
                      (local.set $scratch_21
                       (struct.get $type29 0
                        (ref.cast (ref $type29)
                         (local.get $4)
                        )
                       )
                      )
                      (call $foreign27
                       (i64.const 0)
                      )
                      (local.get $scratch_21)
                     )
                    )
                   )
                   (else
                    (call $foreign29
                     (block (result f64)
                      (local.set $scratch_22
                       (struct.get $type30 0
                        (ref.cast (ref $type30)
                         (local.get $4)
                        )
                       )
                      )
                      (call $foreign27
                       (i64.const 1)
                      )
                      (local.get $scratch_22)
                     )
                    )
                   )
                  )
                  (i32.const 0)
                 )
                )
               )
               (else
                (call $foreign27
                 (block (result i64)
                  (local.set $scratch_23
                   (struct.get $type25 1
                    (ref.cast (ref $type25)
                     (local.get $5)
                    )
                   )
                  )
                  (call $foreign27
                   (i64.const 0)
                  )
                  (local.get $scratch_23)
                 )
                )
                (i32.const 0)
               )
              )
             )
             (else
              (if (result i32)
               (i32.eq
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 6)
               )
               (then
                (drop
                 (call $function229
                  (struct.get $type32 0
                   (block (result (ref $type32))
                    (local.set $scratch_24
                     (struct.get $type31 1
                      (local.tee $9
                       (ref.cast (ref $type31)
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (call $foreign27
                     (i64.const 6)
                    )
                    (if
                     (i32.eqz
                      (global.get $ready848)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global848)
                     )
                    )
                    (local.get $scratch_24)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready848)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global848)
                 )
                )
                (return_call $function229
                 (struct.get $type32 0
                  (struct.get $type31 2
                   (local.get $9)
                  )
                 )
                )
               )
               (else
                (if (result i32)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 7)
                 )
                 (then
                  (local.set $1
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (local.get $0)
                    )
                   )
                  )
                  (call $foreign27
                   (i64.const 7)
                  )
                  (if
                   (i32.eqz
                    (global.get $ready859)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global859)
                   )
                  )
                  (call $foreign27
                   (local.tee $11
                    (i64.extend_i32_u
                     (array.len
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eqz
                    (local.get $11)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global848)
                     )
                    )
                    (drop
                     (call $function229
                      (array.get $type34
                       (local.get $1)
                       (i32.const 0)
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $1)
                       )
                      )
                      (i64.const 1)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global848)
                       )
                      )
                      (drop
                       (call $function229
                        (array.get $type34
                         (local.get $1)
                         (i32.const 1)
                        )
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (array.len
                          (local.get $1)
                         )
                        )
                        (i64.const 2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global848)
                         )
                        )
                        (drop
                         (call $function229
                          (array.get $type34
                           (local.get $1)
                           (i32.const 2)
                          )
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (array.len
                            (local.get $1)
                           )
                          )
                          (i64.const 3)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global848)
                           )
                          )
                          (drop
                           (call $function229
                            (array.get $type34
                             (local.get $1)
                             (i32.const 3)
                            )
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (array.len
                              (local.get $1)
                             )
                            )
                            (i64.const 4)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global848)
                             )
                            )
                            (drop
                             (call $function229
                              (array.get $type34
                               (local.get $1)
                               (i32.const 4)
                              )
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (array.len
                                (local.get $1)
                               )
                              )
                              (i64.const 5)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global848)
                               )
                              )
                              (drop
                               (call $function229
                                (array.get $type34
                                 (local.get $1)
                                 (i32.const 5)
                                )
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $1)
                                 )
                                )
                                (i64.const 6)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global848)
                                 )
                                )
                                (drop
                                 (call $function229
                                  (array.get $type34
                                   (local.get $1)
                                   (i32.const 6)
                                  )
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $1)
                                   )
                                  )
                                  (i64.const 7)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global848)
                                   )
                                  )
                                  (drop
                                   (call $function229
                                    (array.get $type34
                                     (local.get $1)
                                     (i32.const 7)
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $1)
                                     )
                                    )
                                    (i64.const 8)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global848)
                                     )
                                    )
                                    (drop
                                     (call $function229
                                      (array.get $type34
                                       (local.get $1)
                                       (i32.const 8)
                                      )
                                     )
                                    )
                                    (return_call $function231
                                     (local.get $1)
                                     (i32.const 0)
                                     (i32.const 1)
                                     (i64.const 9)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (local.set $3
                   (struct.get $type35 1
                    (ref.cast (ref $type35)
                     (local.get $0)
                    )
                   )
                  )
                  (call $foreign27
                   (i64.const 8)
                  )
                  (if
                   (i32.eqz
                    (global.get $ready864)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global864)
                   )
                  )
                  (call $foreign27
                   (local.tee $11
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type36 0
                       (local.get $3)
                      )
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eqz
                    (local.get $11)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign27
                     (i64.extend_i32_u
                      (array.get_u $type37
                       (local.tee $2
                        (struct.get $type36 0
                         (local.get $3)
                        )
                       )
                       (i32.const 0)
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $2)
                       )
                      )
                      (i64.const 1)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign27
                       (i64.extend_i32_u
                        (array.get_u $type37
                         (local.tee $2
                          (struct.get $type36 0
                           (local.get $3)
                          )
                         )
                         (i32.const 1)
                        )
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (array.len
                          (local.get $2)
                         )
                        )
                        (i64.const 2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (call $foreign27
                         (i64.extend_i32_u
                          (array.get_u $type37
                           (local.tee $2
                            (struct.get $type36 0
                             (local.get $3)
                            )
                           )
                           (i32.const 2)
                          )
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (array.len
                            (local.get $2)
                           )
                          )
                          (i64.const 3)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (call $foreign27
                           (i64.extend_i32_u
                            (array.get_u $type37
                             (local.tee $2
                              (struct.get $type36 0
                               (local.get $3)
                              )
                             )
                             (i32.const 3)
                            )
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (array.len
                              (local.get $2)
                             )
                            )
                            (i64.const 4)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (call $foreign27
                             (i64.extend_i32_u
                              (array.get_u $type37
                               (local.tee $2
                                (struct.get $type36 0
                                 (local.get $3)
                                )
                               )
                               (i32.const 4)
                              )
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (array.len
                                (local.get $2)
                               )
                              )
                              (i64.const 5)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (call $foreign27
                               (i64.extend_i32_u
                                (array.get_u $type37
                                 (local.tee $2
                                  (struct.get $type36 0
                                   (local.get $3)
                                  )
                                 )
                                 (i32.const 5)
                                )
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $2)
                                 )
                                )
                                (i64.const 6)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (call $foreign27
                                 (i64.extend_i32_u
                                  (array.get_u $type37
                                   (local.tee $2
                                    (struct.get $type36 0
                                     (local.get $3)
                                    )
                                   )
                                   (i32.const 6)
                                  )
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $2)
                                   )
                                  )
                                  (i64.const 7)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (call $foreign27
                                   (i64.extend_i32_u
                                    (array.get_u $type37
                                     (local.tee $2
                                      (struct.get $type36 0
                                       (local.get $3)
                                      )
                                     )
                                     (i32.const 7)
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 8)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (call $foreign27
                                     (i64.extend_i32_u
                                      (array.get_u $type37
                                       (struct.get $type36 0
                                        (local.get $3)
                                       )
                                       (i32.const 8)
                                      )
                                     )
                                    )
                                    (return_call $function233
                                     (local.get $3)
                                     (i32.const 0)
                                     (i32.const 1)
                                     (i64.const 9)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (call $foreign27
     (i64.const 0)
    )
    (i32.const 0)
   )
  )
 )
 (func $function231 (type $10) (param $0 (ref $type34)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global848)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function229
      (array.get $type34
       (local.get $0)
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function231
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function233 (type $9) (param $0 (ref $type36)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (struct.get $type36 0
       (local.get $0)
      )
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign27
     (i64.extend_i32_u
      (array.get_u $type37
       (struct.get $type36 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function233
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $export0 (result i64)
  (local $0 (ref $type58))
  (local $1 (ref $type130))
  (local $2 (ref $type130))
  (local $3 (ref $type18))
  (local $4 (ref $type13))
  (local $5 (ref $type56))
  (local $6 i32)
  (local $scratch (ref $type18))
  (local $scratch_8 (ref $type13))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready868)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global868)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global829)
   )
  )
  (drop
   (call $function41
    (block (result (ref $type18))
     (local.set $scratch
      (ref.as_non_null
       (global.get $global826)
      )
     )
     (if
      (i32.eqz
       (call $foreign26)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global803)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global810)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global120)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global109)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (local.set $0
   (struct.new $type58
    (struct.new $type56
     (call $foreign5)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global788)
   )
  )
  (local.set $1
   (call $function214
    (local.get $0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global515)
   )
  )
  (drop
   (call $function229
    (block (result (ref $type13))
     (local.set $scratch_8
      (if (result (ref $type13))
       (if (result i32)
        (local.tee $6
         (struct.get $type130 0
          (local.get $1)
         )
        )
        (then
         (if
          (i32.eq
           (local.get $6)
           (i32.const 1)
          )
          (then
           (drop
            (ref.cast (ref $type132)
             (local.get $1)
            )
           )
          )
          (else
           (drop
            (ref.cast (ref $type133)
             (local.get $1)
            )
           )
          )
         )
         (i32.const 0)
        )
        (else
         (i32.const 1)
        )
       )
       (then
        (struct.new $type15
         (i32.const 1)
         (i32.const 0)
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global788)
         )
        )
        (local.set $2
         (call $function214
          (local.get $0)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global520)
         )
        )
        (call $function219
         (local.get $0)
         (i32.const 0)
         (i32.const 1)
         (local.get $2)
         (call $function152
          (local.get $1)
         )
         (i64.const 1)
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global127)
      )
     )
     (if
      (i32.eqz
       (global.get $ready124)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global124)
      )
     )
     (if
      (i32.ne
       (local.tee $6
        (struct.get $type56 0
         (local.tee $5
          (struct.get $type58 0
           (local.get $0)
          )
         )
        )
       )
       (i32.const -1)
      )
      (then
       (struct.set $type56 0
        (local.get $5)
        (i32.const -1)
       )
       (call $foreign6
        (local.get $6)
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global848)
      )
     )
     (local.get $scratch_8)
    )
   )
  )
  (i64.const 1)
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready828)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global828)
   )
  )
  (struct.get $type66 0
   (global.get $global820)
  )
 )
 (func $main
  (local $0 (ref $type130))
  (local $1 (ref $type13))
  (local $2 (ref $type24))
  (local $3 (ref $type58))
  (local $4 (ref $type58))
  (local $5 (ref $type18))
  (local $6 (ref $type66))
  (local $7 (ref $type56))
  (local $8 i64)
  (local $9 i32)
  (local $scratch (ref $type130))
  (local $scratch_11 (ref $type130))
  (local $scratch_12 (ref $type130))
  (local $scratch_13 (ref (exact $type66)))
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global726
   (struct.new_default $type11)
  )
  (global.set $global729
   (struct.new_default $type40)
  )
  (global.set $ready729
   (i32.const 1)
  )
  (global.set $global61
   (struct.new_default $type41)
  )
  (global.set $global81
   (struct.new_default $type45)
  )
  (global.set $global88
   (struct.new_default $type46)
  )
  (global.set $global90
   (struct.new_default $type47)
  )
  (global.set $global93
   (struct.new_default $type49)
  )
  (global.set $ready93
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type50)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type51)
  )
  (global.set $global109
   (struct.new_default $type52)
  )
  (global.set $global120
   (struct.new_default $type57)
  )
  (global.set $global127
   (struct.new_default $type60)
  )
  (global.set $global124
   (struct.new_default $type61)
  )
  (global.set $ready124
   (i32.const 1)
  )
  (global.set $global810
   (struct.new_default $type62)
  )
  (global.set $global821
   (struct.new_default $type64)
  )
  (global.set $global133
   (struct.new_default $type71)
  )
  (global.set $global135
   (struct.new_default $type72)
  )
  (global.set $global137
   (struct.new_default $type72)
  )
  (global.set $global180
   (struct.new_default $type84)
  )
  (global.set $global317
   (struct.new_default $type111)
  )
  (global.set $global323
   (struct.new_default $type112)
  )
  (global.set $global329
   (struct.new_default $type113)
  )
  (global.set $global334
   (struct.new_default $type115)
  )
  (global.set $global367
   (struct.new_default $type118)
  )
  (global.set $global370
   (struct.new_default $type119)
  )
  (global.set $global376
   (struct.new_default $type120)
  )
  (global.set $global379
   (struct.new_default $type125)
  )
  (global.set $global411
   (struct.new_default $type129)
  )
  (global.set $global418
   (struct.new_default $type134)
  )
  (global.set $global422
   (struct.new_default $type135)
  )
  (global.set $global435
   (struct.new_default $type138)
  )
  (global.set $global447
   (struct.new_default $type139)
  )
  (global.set $global515
   (struct.new_default $type145)
  )
  (global.set $global520
   (struct.new_default $type146)
  )
  (global.set $global525
   (struct.new_default $type147)
  )
  (global.set $global532
   (struct.new_default $type148)
  )
  (global.set $global552
   (struct.new_default $type149)
  )
  (global.set $global530
   (struct.new_default $type149)
  )
  (global.set $global538
   (struct.new_default $type150)
  )
  (global.set $global549
   (struct.new_default $type151)
  )
  (global.set $global536
   (struct.new_default $type152)
  )
  (global.set $global643
   (struct.new_default $type152)
  )
  (global.set $global562
   (struct.new_default $type153)
  )
  (global.set $global611
   (struct.new_default $type157)
  )
  (global.set $global615
   (struct.new_default $type158)
  )
  (global.set $ready615
   (i32.const 1)
  )
  (global.set $global568
   (struct.new_default $type159)
  )
  (global.set $global658
   (struct.new_default $type160)
  )
  (global.set $global666
   (struct.new_default $type46)
  )
  (global.set $global541
   (struct.new_default $type60)
  )
  (global.set $ready541
   (i32.const 1)
  )
  (global.set $global635
   (struct.new_default $type161)
  )
  (global.set $ready635
   (i32.const 1)
  )
  (global.set $global630
   (struct.new_default $type162)
  )
  (global.set $global527
   (struct.new_default $type162)
  )
  (global.set $ready527
   (i32.const 1)
  )
  (global.set $global546
   (struct.new_default $type171)
  )
  (global.set $ready546
   (i32.const 1)
  )
  (global.set $global627
   (struct.new_default $type162)
  )
  (global.set $ready627
   (i32.const 1)
  )
  (global.set $global684
   (struct.new_default $type162)
  )
  (global.set $ready684
   (i32.const 1)
  )
  (global.set $global686
   (struct.new_default $type172)
  )
  (global.set $ready686
   (i32.const 1)
  )
  (global.set $global697
   (struct.new_default $type172)
  )
  (global.set $ready697
   (i32.const 1)
  )
  (global.set $global554
   (struct.new_default $type173)
  )
  (global.set $ready554
   (i32.const 1)
  )
  (global.set $global559
   (struct.new_default $type174)
  )
  (global.set $ready559
   (i32.const 1)
  )
  (global.set $global563
   (struct.new_default $type178)
  )
  (global.set $ready563
   (i32.const 1)
  )
  (global.set $global621
   (struct.new_default $type179)
  )
  (global.set $ready621
   (i32.const 1)
  )
  (global.set $global604
   (struct.new_default $type180)
  )
  (global.set $ready604
   (i32.const 1)
  )
  (global.set $global570
   (struct.new_default $type185)
  )
  (global.set $ready570
   (i32.const 1)
  )
  (global.set $global591
   (struct.new_default $type152)
  )
  (global.set $ready591
   (i32.const 1)
  )
  (global.set $global601
   (struct.new_default $type60)
  )
  (global.set $ready601
   (i32.const 1)
  )
  (global.set $global596
   (struct.new_default $type186)
  )
  (global.set $ready596
   (i32.const 1)
  )
  (global.set $global588
   (struct.new_default $type97)
  )
  (global.set $global584
   (struct.new_default $type152)
  )
  (global.set $global581
   (struct.new_default $type187)
  )
  (global.set $global576
   (struct.new_default $type188)
  )
  (global.set $ready576
   (i32.const 1)
  )
  (global.set $global674
   (struct.new_default $type189)
  )
  (global.set $global640
   (struct.new_default $type162)
  )
  (global.set $ready640
   (i32.const 1)
  )
  (global.set $global663
   (struct.new_default $type172)
  )
  (global.set $ready663
   (i32.const 1)
  )
  (global.set $global672
   (struct.new_default $type189)
  )
  (global.set $ready672
   (i32.const 1)
  )
  (global.set $global702
   (struct.new_default $type190)
  )
  (global.set $ready702
   (i32.const 1)
  )
  (global.set $global780
   (struct.new_default $type191)
  )
  (global.set $ready780
   (i32.const 1)
  )
  (global.set $global709
   (struct.new_default $type192)
  )
  (global.set $ready709
   (i32.const 1)
  )
  (global.set $global770
   (struct.new_default $type193)
  )
  (global.set $ready770
   (i32.const 1)
  )
  (global.set $global756
   (struct.new_default $type194)
  )
  (global.set $ready756
   (i32.const 1)
  )
  (global.set $global718
   (struct.new_default $type195)
  )
  (global.set $ready718
   (i32.const 1)
  )
  (global.set $global721
   (struct.new_default $type196)
  )
  (global.set $global715
   (struct.new_default $type197)
  )
  (global.set $ready715
   (i32.const 1)
  )
  (global.set $global737
   (struct.new_default $type198)
  )
  (global.set $ready737
   (i32.const 1)
  )
  (global.set $global748
   (struct.new_default $type138)
  )
  (global.set $global743
   (struct.new_default $type199)
  )
  (global.set $ready743
   (i32.const 1)
  )
  (global.set $global788
   (struct.new_default $type147)
  )
  (global.set $global796
   (struct.new_default $type138)
  )
  (global.set $global803
   (struct.new_default $type202)
  )
  (global.set $global815
   (struct.new_default $type65)
  )
  (drop
   (ref.as_non_null
    (global.get $global815)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global821)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global120)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (drop
   (call $function41
    (global.get $string54)
   )
  )
  (local.set $3
   (local.tee $4
    (struct.new $type58
     (struct.new $type56
      (call $foreign5)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global788)
   )
  )
  (local.set $1
   (call $function152
    (block (result (ref $type130))
     (local.set $scratch
      (call $function214
       (local.get $3)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global520)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global796)
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (local.get $1)
    )
    (i32.const 5)
   )
   (then
    (unreachable)
   )
  )
  (global.set $global820
   (block (result (ref (exact $type66)))
    (local.set $scratch_13
     (struct.new $type66
      (if (result i64)
       (struct.get $type24 0
        (local.tee $2
         (struct.get $type23 1
          (ref.cast (ref $type23)
           (local.get $1)
          )
         )
        )
       )
       (then
        (if
         (i32.eq
          (struct.get $type24 0
           (local.get $2)
          )
          (i32.const 1)
         )
         (then
          (drop
           (ref.cast (ref $type26)
            (local.get $2)
           )
          )
         )
         (else
          (drop
           (ref.cast (ref $type27)
            (local.get $2)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global323)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global317)
         )
        )
        (call $foreign12
         (call $function104
          (global.get $string53)
         )
        )
        (unreachable)
       )
       (else
        (struct.get $type25 1
         (ref.cast (ref $type25)
          (local.get $2)
         )
        )
       )
      )
      (block (result (ref $type18))
       (drop
        (ref.as_non_null
         (global.get $global788)
        )
       )
       (if
        (i32.ne
         (struct.get $type13 0
          (local.tee $1
           (call $function152
            (block (result (ref $type130))
             (local.set $scratch_11
              (call $function214
               (local.get $3)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global520)
              )
             )
             (local.get $scratch_11)
            )
           )
          )
         )
         (i32.const 3)
        )
        (then
         (unreachable)
        )
       )
       (struct.get $type17 1
        (ref.cast (ref $type17)
         (local.get $1)
        )
       )
      )
      (block (result (ref $type13))
       (drop
        (ref.as_non_null
         (global.get $global788)
        )
       )
       (call $function152
        (block (result (ref $type130))
         (local.set $scratch_12
          (call $function214
           (local.get $3)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global520)
          )
         )
         (local.get $scratch_12)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global127)
     )
    )
    (if
     (i32.eqz
      (global.get $ready124)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global124)
     )
    )
    (if
     (i32.ne
      (local.tee $9
       (struct.get $type56 0
        (local.tee $7
         (struct.get $type58 0
          (local.get $4)
         )
        )
       )
      )
      (i32.const -1)
     )
     (then
      (struct.set $type56 0
       (local.get $7)
       (i32.const -1)
      )
      (call $foreign6
       (local.get $9)
      )
     )
    )
    (local.get $scratch_13)
   )
  )
  (global.set $global826
   (struct.get $type66 1
    (global.get $global820)
   )
  )
  (drop
   (struct.get $type66 2
    (global.get $global820)
   )
  )
  (global.set $global828
   (struct.new_default $type5)
  )
  (global.set $ready828
   (i32.const 1)
  )
  (global.set $global829
   (struct.new_default $type203)
  )
  (global.set $global832
   (struct.new_default $type52)
  )
  (global.set $global836
   (struct.new_default $type204)
  )
  (global.set $global841
   (struct.new_default $type205)
  )
  (global.set $global848
   (struct.new_default $type206)
  )
  (global.set $ready848
   (i32.const 1)
  )
  (global.set $global859
   (struct.new_default $type207)
  )
  (global.set $ready859
   (i32.const 1)
  )
  (global.set $global864
   (struct.new_default $type208)
  )
  (global.set $ready864
   (i32.const 1)
  )
  (global.set $global868
   (struct.new_default $type5)
  )
  (global.set $ready868
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

