(import (snail strict) (snail io) (snail datum) (snail read) (snail bytes))
(define-syntax cond
  (syntax-rules (else)
    ((_ (else body ...)) (begin body ...))
    ((_ (test body ...) rest ...) (if test (begin body ...) (cond rest ...)))))
(define-syntax do
  (syntax-rules ()
    ((_ ((var init step) ...) (test result) body ...)
     (let loop ((var init) ...)
       (if test result (begin body ... (loop step ...)))))))
(define (cddr xs) (cdr (cdr xs)))
(define (length xs)
  (let loop ((xs xs) (n 0)) (if (null? xs) n (loop (cdr xs) (+ n 1)))))
(define-extern native-input-i64 "benchmark" "input_i64" (-> I32 I64))
(define-extern native-input-f64 "benchmark" "input_f64" (-> I32 F64))
(define-extern barrier "benchmark" "barrier" (-> Bool))
(define-extern hide-i64 "benchmark" "hide_i64" (-> I64 I64))
(define-extern hide-f64 "benchmark" "hide_f64" (-> F64 F64))
(: abs (-> F64 F64))
(define (abs value) (if (< value 0.0) (- 0.0 value) value))
(: workload-read (-> InputPort ReadResult))
(define (workload-read port)
  (let ((result (read port)))
    (match result
      ((read-error message) (datum-fail (string-append "read: " message)))
      ((read-value value) result) ((read-end) result))))
(: real-datum (-> Datum F64))
(define (real-datum value)
  (if (datum-number? value) (number->f64 (datum-number-value value))
      (datum-fail "sum1: expected a real number")))
(: exact-datum (-> Datum I64))
(define (exact-datum value)
  (match (datum-number-value value)
    ((exact-number value) value)
    ((inexact-number value) (datum-fail "benchmark count must be exact"))
    ((complex-number real imaginary) (datum-fail "benchmark count must be exact"))))
(: read-from-file-benchmark (-> String Datum))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;
;;; Test of R6RS get-datum, comparable to the parsing benchmark.
;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; get-datum benchmark comparable to the parsing benchmark.
;;
;; Reads nboyer.sch into a string before timing begins.
;;
;; The timed portion of the benchmark parses the string
;; representation of nboyer.sch 1000 times.
;;
;; The output of that parse is checked by comparing it
;; the the value returned by the read procedure.
;;
;; Usage:
;;     (read-benchmark n input)
;;     (read-from-string-port-benchmark n input)
;;
;;
;; n defaults to 1000, and input defaults to "nboyer.sch".
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(define (read-from-file-benchmark input)
  (call-with-input-file
      input
    (lambda (in)
      (do ((x (workload-read in) (workload-read in))
           (y (datum-boolean #f) (read-value! x))
           (i 0 (+ i 1)))
          ((read-end? x) y)))))

(define-data Specification
  (specification (count I64 specification-count) (path String specification-path)
                 (expected Datum specification-expected)))
(: read-specification (-> InputPort Specification))
(define (read-specification port)
  (let* ((count (exact-datum (read-value! (workload-read port))))
         (path (datum-string-value (read-value! (workload-read port))))
         (expected (read-value! (workload-read port))))
    (specification count path expected)))
(define configured (call-with-input-file "input.txt" read-specification))
(define input0 (specification-path configured))
(define expected (specification-expected configured))
(: configured-count (-> I64))
(define (configured-count) (specification-count configured))
(: hide-path (-> I64 String String))
(define (hide-path count path) (if (barrier) path (unreachable)))
(define-extern emit-i64 "reader.test" "emit_i64" (-> I64 Unit))
(define-extern emit-f64 "reader.test" "emit_f64" (-> F64 Unit))
(define-extern emit-char "reader.test" "emit_char" (-> Char Unit))
(: observe-string (-> String Unit))
(define (observe-string text)
  (emit-i64 (string-length text))
  (let loop ((index 0))
    (unless (= index (string-length text))
      (emit-char (string-ref text index)) (loop (+ index 1)))))
(: observe-scalar (-> Scalar Unit))
(define (observe-scalar value)
  (match value
    ((exact-scalar value) (emit-i64 0) (emit-i64 value))
    ((inexact-scalar value) (emit-i64 1) (emit-f64 value))))
(: observe-number (-> Number Unit))
(define (observe-number value)
  (match value
    ((exact-number value) (emit-i64 0) (emit-i64 value))
    ((inexact-number value) (emit-i64 1) (emit-f64 value))
    ((complex-number real imaginary) (emit-i64 2) (observe-scalar real) (observe-scalar imaginary))))
(: observe (-> Datum Unit))
(define (observe datum)
  (match datum
    ((datum-null) (emit-i64 0))
    ((datum-boolean value) (emit-i64 1) (emit-i64 (if value 1 0)))
    ((datum-character value) (emit-i64 2) (emit-char value))
    ((datum-string value) (emit-i64 3) (observe-string value))
    ((datum-symbol value) (emit-i64 4) (observe-string (symbol->string value)))
    ((datum-number value) (emit-i64 5) (observe-number value))
    ((datum-pair first rest) (emit-i64 6) (observe (ref-get first)) (observe (ref-get rest)))
    ((datum-vector values) (emit-i64 7) (observe-vector values))
    ((datum-bytevector values) (emit-i64 8) (observe-bytes values))))
(: observe-vector (-> (Vector Datum) Unit))
(define (observe-vector values)
  (emit-i64 (vector-length values))
  (let loop ((index 0))
    (unless (= index (vector-length values))
      (observe (vector-ref values index)) (loop (+ index 1)))))
(: observe-bytes (-> Bytevector Unit))
(define (observe-bytes values)
  (emit-i64 (bytevector-length values))
  (let loop ((index 0))
    (unless (= index (bytevector-length values))
      (emit-i64 (bytevector-u8-ref values index)) (loop (+ index 1)))))
(: observe-once (-> I64))
(define (observe-once) (observe (read-from-file-benchmark (hide-path 1 input0))) 1)
(unit)
