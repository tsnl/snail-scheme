(import (chezscheme))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;
;;; Test of R6RS get-datum, comparable to the parsing benchmark.
;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; get-datum benchmark comparable to the parsing benchmark.
;;
;; Reads nboyer.sch into a string before timing begins.
;;
;; The timed portion of the benchmark parses the string
;; representation of nboyer.sch 1000 times.
;;
;; The output of that parse is checked by comparing it
;; the the value returned by the read procedure.
;;
;; Usage:
;;     (read-benchmark n input)
;;     (read-from-string-port-benchmark n input)
;;
;;
;; n defaults to 1000, and input defaults to "nboyer.sch".
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(define (read-from-file-benchmark input)
  (call-with-input-file
      input
    (lambda (in)
      (do ((x (read in) (read in))
           (y #f x)
           (i 0 (+ i 1)))
          ((eof-object? x) y)))))

(define (emit-i64 value) (display "i:") (display value) (newline))
(define (emit-char value) (display "c:") (display (char->integer value)) (newline))
(define (emit-f64 value)
  (display "f:")
  (if (nan? value) (display "nan")
      (let ((bytes (make-bytevector 8)))
        (bytevector-ieee-double-native-set! bytes 0 value)
        (display (bytevector-u64-native-ref bytes 0))))
  (newline))
(define (observe-string value)
  (emit-i64 (string-length value)) (string-for-each emit-char value))
(define (observe-scalar value)
  (if (exact? value) (begin (emit-i64 0) (emit-i64 value))
      (begin (emit-i64 1) (emit-f64 value))))
(define (observe-number value)
  (if (and (not (flonum? value)) (or (cflonum? value) (not (real? value))))
      (begin (emit-i64 2) (observe-scalar (real-part value)) (observe-scalar (imag-part value)))
      (observe-scalar value)))
(define (observe value)
  (cond
   ((null? value) (emit-i64 0))
   ((boolean? value) (emit-i64 1) (emit-i64 (if value 1 0)))
   ((char? value) (emit-i64 2) (emit-char value))
   ((string? value) (emit-i64 3) (observe-string value))
   ((symbol? value) (emit-i64 4) (observe-string (symbol->string value)))
   ((number? value) (emit-i64 5) (observe-number value))
   ((pair? value) (emit-i64 6) (observe (car value)) (observe (cdr value)))
   ((vector? value) (emit-i64 7) (emit-i64 (vector-length value)) (vector-for-each observe value))
   ((bytevector? value) (emit-i64 8) (emit-i64 (bytevector-length value))
    (do ((index 0 (+ index 1))) ((= index (bytevector-length value)))
      (emit-i64 (bytevector-u8-ref value index))))
   (else (error 'observe "unsupported oracle value" value))))
(define probe-path
  (call-with-input-file "input.txt"
    (lambda (port)
      (let* ((count (read port)) (path (read port)) (expected (read port))) path))))
(define (observe-once) (observe (read-from-file-benchmark probe-path)))
(display "call:0") (newline) (observe-once)
(when (file-exists? "replacement.data")
  (delete-file probe-path)
  (call-with-input-file "replacement.data"
    (lambda (input)
      (call-with-output-file probe-path
        (lambda (output)
          (let loop ((character (read-char input)))
            (unless (eof-object? character)
              (write-char character output) (loop (read-char input))))))))
  (display "call:1") (newline) (observe-once))
