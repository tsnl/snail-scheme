#include <stdint.h>
int32_t barrier(void);
uint64_t reader_barriers(void);
