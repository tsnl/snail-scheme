(module
 (rec
  (type $type13 (sub (struct (field i32))))
  (type $type101 (sub (struct)))
  (type $type92 (sub (struct (field i32))))
  (type $type24 (sub (struct (field i32))))
  (type $type28 (sub (struct)))
  (type $5 (func (param (ref $type18)) (result i32)))
  (type $type37 (array (mut i8)))
  (type $7 (func (param (ref $type36) (ref $type36) i64 i32 i32 i64) (result i32)))
  (type $8 (func (param (ref $type34) (ref $type34) i64 i32 i32 i64) (result i32)))
  (type $type36 (struct (field (ref $type37))))
  (type $type34 (array (mut (ref $type13))))
  (type $call113 (func (param (ref $type107) (ref $type13)) (result (ref $type13))))
  (type $call106 (func (param (ref $type13) (ref $type13)) (result (ref $type13))))
  (type $13 (func (param i32 i32 (ref $type13) i64) (result i64)))
  (type $call111 (func (param (ref $type13) (ref $type13)) (result i32)))
  (type $call110 (func (param (ref $type13)) (result i32)))
  (type $type35 (sub $type13 (struct (field i32) (field (ref $type36)))))
  (type $type33 (sub $type13 (struct (field i32) (field (ref $type34)))))
  (type $type17 (sub $type13 (struct (field i32) (field (ref $type18)))))
  (type $type15 (sub $type13 (struct (field i32))))
  (type $call109 (func (param (ref $type13)) (result i64)))
  (type $type32 (struct (field (mut (ref $type13)))))
  (type $type31 (sub $type13 (struct (field i32) (field (ref $type32)) (field (ref $type32)))))
  (type $call107 (func (param (ref $type13)) (result (ref $type13))))
  (type $type21 (sub $type13 (struct (field i32) (field (ref $type22)))))
  (type $type22 (struct (field i32)))
  (type $type104 (sub $type101 (struct (field (ref $type18)))))
  (type $type103 (sub $type101 (struct (field (ref $type13)))))
  (type $type23 (sub $type13 (struct (field i32) (field (ref $type24)))))
  (type $call105 (func (param (ref $type18)) (result (ref $type101))))
  (type $call99 (func (param (ref $type24) (ref $type24)) (result i32)))
  (type $call97 (func (param (ref $type28) (ref $type28)) (result i32)))
  (type $type95 (sub $type92 (struct (field i32) (field (ref $type18)))))
  (type $type27 (sub $type24 (struct (field i32) (field (ref $type28)) (field (ref $type28)))))
  (type $type30 (sub $type28 (struct (field f64))))
  (type $type29 (sub $type28 (struct (field i64))))
  (type $type26 (sub $type24 (struct (field i32) (field f64))))
  (type $type94 (sub $type92 (struct (field i32) (field (ref $type24)))))
  (type $type25 (sub $type24 (struct (field i32) (field i64))))
  (type $call91 (func (param i32 i32) (result (ref $type92))))
  (type $40 (func (param i32 i64 (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $41 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type18))))
  (type $42 (func (param i32 i32 i64 i64) (result i64)))
  (type $call67 (func (param i64) (result i64)))
  (type $44 (func (param (ref $type18) i32 i64 i32 i32 i64) (result i32)))
  (type $45 (func (param (ref $type18)) (result i32)))
  (type $46 (func (param (ref $type18) (ref $type18) i32 i32 i64) (result i32)))
  (type $47 (func (param (ref $type18) i64) (result (ref $type18))))
  (type $48 (func (param (ref $type18) i32) (result (ref $type19))))
  (type $type20 (array (mut (ref null $type19))))
  (type $50 (func (param i32) (result (ref $type18))))
  (type $type5 (struct))
  (type $type83 (struct))
  (type $type8 (struct))
  (type $type115 (struct))
  (type $type114 (struct))
  (type $type113 (struct))
  (type $type112 (struct))
  (type $type111 (struct))
  (type $type110 (struct))
  (type $type109 (struct))
  (type $type108 (struct))
  (type $type107 (struct (field (ref $call107))))
  (type $type106 (struct))
  (type $type105 (struct))
  (type $type100 (struct))
  (type $type99 (struct))
  (type $type98 (struct))
  (type $type97 (struct))
  (type $type96 (struct))
  (type $type91 (struct))
  (type $type90 (struct))
  (type $type89 (struct))
  (type $type67 (struct))
  (type $type85 (struct))
  (type $type84 (struct))
  (type $type81 (struct))
  (type $type63 (struct))
  (type $type61 (struct))
  (type $type58 (struct))
  (type $type57 (struct))
  (type $type55 (struct))
  (type $type54 (struct))
  (type $type53 (struct))
  (type $type48 (struct))
  (type $type47 (struct))
  (type $type43 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type38 (struct))
  (type $type11 (struct))
  (type $type93 (sub $type92 (struct (field i32))))
  (type $type14 (sub $type13 (struct (field i32))))
  (type $type18 (struct (field i32) (field i32) (field (ref $type19)) (field (ref null $type20))))
  (type $type19 (array (mut i32)))
 )
 (type $95 (func (param i32) (result i32)))
 (type $96 (func (param i32 i32) (result i32)))
 (type $97 (func (result i32)))
 (type $98 (func (param i32 i32)))
 (type $99 (func (param i32)))
 (type $100 (func (param i32 i32) (result f64)))
 (type $101 (func (param i32 i32) (result i64)))
 (type $102 (func (param f64 f64) (result i32)))
 (type $103 (func (param (ref $type18) i64) (result (ref $type18))))
 (type $104 (func (param (ref $type18)) (result i32)))
 (type $105 (func (param (ref $type18)) (result (ref $type101))))
 (type $106 (func (param i64) (result i64)))
 (type $107 (func (result i64)))
 (type $108 (func))
 (import "snail.library" "snail:datum/token-open" (func $foreign0 (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign1 (param i32 i32)))
 (import "snail.library" "snail:datum/token-identifier" (func $foreign3 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign4 (param i32)))
 (import "snail.library" "snail:datum/token-intern" (func $foreign5 (param i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign8 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign9 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign10 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/error-length" (func $foreign11 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign12 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse" (func $foreign13 (param i32) (result i32)))
 (import "snail.library" "snail:datum/real-equivalent" (func $foreign14 (param f64 f64) (result i32)))
 (global $execution (mut i32) (i32.const 0))
 (global $string1 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 71)
  (array.new_fixed $type19 71
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 102)
   (i32.const 105)
   (i32.const 101)
   (i32.const 114)
   (i32.const 59)
   (i32.const 32)
   (i32.const 114)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 97)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 98)
  )
  (ref.null none)
 ))
 (global $string4 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 115)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string5 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 0)
  (array.new_fixed $type19 0)
  (ref.null none)
 ))
 (global $string6 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 49)
   (i32.const 50)
   (i32.const 51)
   (i32.const 97)
   (i32.const 98)
   (i32.const 99)
  )
  (ref.null none)
 ))
 (global $string7 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 57)
   (i32.const 50)
   (i32.const 50)
   (i32.const 51)
   (i32.const 51)
   (i32.const 55)
   (i32.const 50)
   (i32.const 48)
   (i32.const 51)
   (i32.const 54)
   (i32.const 56)
   (i32.const 53)
   (i32.const 52)
   (i32.const 55)
   (i32.const 55)
   (i32.const 53)
   (i32.const 56)
   (i32.const 48)
   (i32.const 56)
  )
  (ref.null none)
 ))
 (global $string8 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 35)
   (i32.const 101)
   (i32.const 49)
   (i32.const 46)
   (i32.const 53)
  )
  (ref.null none)
 ))
 (global $string9 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 49)
   (i32.const 47)
   (i32.const 50)
  )
  (ref.null none)
 ))
 (global $string10 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 49)
   (i32.const 43)
   (i32.const 50)
   (i32.const 105)
  )
  (ref.null none)
 ))
 (global $string11 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 49)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string12 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 52)
   (i32.const 50)
  )
  (ref.null none)
 ))
 (global $string13 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 57)
   (i32.const 50)
   (i32.const 50)
   (i32.const 51)
   (i32.const 51)
   (i32.const 55)
   (i32.const 50)
   (i32.const 48)
   (i32.const 51)
   (i32.const 54)
   (i32.const 56)
   (i32.const 53)
   (i32.const 52)
   (i32.const 55)
   (i32.const 55)
   (i32.const 53)
   (i32.const 56)
   (i32.const 48)
   (i32.const 55)
  )
  (ref.null none)
 ))
 (global $string14 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 45)
   (i32.const 57)
   (i32.const 50)
   (i32.const 50)
   (i32.const 51)
   (i32.const 51)
   (i32.const 55)
   (i32.const 50)
   (i32.const 48)
   (i32.const 51)
   (i32.const 54)
   (i32.const 56)
   (i32.const 53)
   (i32.const 52)
   (i32.const 55)
   (i32.const 55)
   (i32.const 53)
   (i32.const 56)
   (i32.const 48)
   (i32.const 56)
  )
  (ref.null none)
 ))
 (global $string15 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 45)
   (i32.const 52)
   (i32.const 50)
  )
  (ref.null none)
 ))
 (global $string16 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $empty14 (ref $type14) (struct.new $type14
  (i32.const 0)
 ))
 (global $empty93 (ref $type93) (struct.new $type93
  (i32.const 0)
 ))
 (global $global461 (mut (ref null $type11)) (ref.null none))
 (global $global463 (mut (ref null $type38)) (ref.null none))
 (global $ready463 (mut i32) (i32.const 0))
 (global $global466 (mut (ref null $type41)) (ref.null none))
 (global $ready466 (mut i32) (i32.const 0))
 (global $global474 (mut (ref null $type42)) (ref.null none))
 (global $global61 (mut (ref null $type43)) (ref.null none))
 (global $global81 (mut (ref null $type47)) (ref.null none))
 (global $global88 (mut (ref null $type48)) (ref.null none))
 (global $global103 (mut (ref null $type53)) (ref.null none))
 (global $global109 (mut (ref null $type54)) (ref.null none))
 (global $global111 (mut (ref null $type55)) (ref.null none))
 (global $global114 (mut (ref null $type57)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global135 (mut (ref null $type58)) (ref.null none))
 (global $global131 (mut (ref null $type61)) (ref.null none))
 (global $global145 (mut (ref null $type63)) (ref.null none))
 (global $global246 (mut (ref null $type81)) (ref.null none))
 (global $global258 (mut (ref null $type84)) (ref.null none))
 (global $global260 (mut (ref null $type85)) (ref.null none))
 (global $global270 (mut (ref null $type67)) (ref.null none))
 (global $global275 (mut (ref null $type43)) (ref.null none))
 (global $global296 (mut (ref null $type89)) (ref.null none))
 (global $global299 (mut (ref null $type90)) (ref.null none))
 (global $global305 (mut (ref null $type91)) (ref.null none))
 (global $global308 (mut (ref null $type96)) (ref.null none))
 (global $global313 (mut (ref null $type97)) (ref.null none))
 (global $global325 (mut (ref null $type98)) (ref.null none))
 (global $global332 (mut (ref null $type99)) (ref.null none))
 (global $global340 (mut (ref null $type100)) (ref.null none))
 (global $global347 (mut (ref null $type105)) (ref.null none))
 (global $global351 (mut (ref null $type106)) (ref.null none))
 (global $global354 (mut (ref null $type107)) (ref.null none))
 (global $global356 (mut (ref null $type107)) (ref.null none))
 (global $global361 (mut (ref null $type108)) (ref.null none))
 (global $global364 (mut (ref null $type109)) (ref.null none))
 (global $global378 (mut (ref null $type110)) (ref.null none))
 (global $global380 (mut (ref null $type110)) (ref.null none))
 (global $global382 (mut (ref null $type110)) (ref.null none))
 (global $global384 (mut (ref null $type111)) (ref.null none))
 (global $global397 (mut (ref null $type112)) (ref.null none))
 (global $global401 (mut (ref null $type109)) (ref.null none))
 (global $global406 (mut (ref null $type106)) (ref.null none))
 (global $ready406 (mut i32) (i32.const 0))
 (global $global409 (mut (ref null $type106)) (ref.null none))
 (global $ready409 (mut i32) (i32.const 0))
 (global $global413 (mut (ref null $type113)) (ref.null none))
 (global $ready413 (mut i32) (i32.const 0))
 (global $global417 (mut (ref null $type111)) (ref.null none))
 (global $ready417 (mut i32) (i32.const 0))
 (global $global429 (mut (ref null $type114)) (ref.null none))
 (global $ready429 (mut i32) (i32.const 0))
 (global $global437 (mut (ref null $type115)) (ref.null none))
 (global $ready437 (mut i32) (i32.const 0))
 (global $global444 (mut (ref null $type8)) (ref.null none))
 (global $global449 (mut (ref null $type8)) (ref.null none))
 (global $global457 (mut (ref null $type8)) (ref.null none))
 (global $global478 (mut (ref null $type83)) (ref.null none))
 (global $global486 (mut (ref null $type83)) (ref.null none))
 (global $global491 (mut (ref null $type83)) (ref.null none))
 (global $global499 (mut (ref null $type83)) (ref.null none))
 (global $global504 (mut (ref null $type8)) (ref.null none))
 (global $global507 (mut (ref null $type5)) (ref.null none))
 (global $global508 (mut (ref null $type5)) (ref.null none))
 (global $ready508 (mut i32) (i32.const 0))
 (global $global509 (mut (ref null $type67)) (ref.null none))
 (global $ready509 (mut i32) (i32.const 0))
 (export "bench" (func $export0))
 (export "configured-count" (func $export1))
 (export "main" (func $main))
 (func $string-new (type $50) (param $0 i32) (result (ref $type18))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type20))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type20
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type20
      (local.get $5)
      (local.get $2)
      (array.new_default $type19
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type18
   (i32.const 1)
   (local.get $0)
   (array.new_default $type19
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-block (type $48) (param $0 (ref $type18)) (param $1 i32) (result (ref $type19))
  (if (result (ref $type19))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type18 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type20
      (struct.get $type18 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function33 (param $0 (ref $type18)) (param $1 i64) (result (ref $type18))
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 (ref $type18))
  (if (result (ref $type18))
   (if (result i32)
    (local.tee $3
     (i64.lt_s
      (local.get $1)
      (i64.const 0)
     )
    )
    (then
     (local.get $3)
    )
    (else
     (i64.lt_s
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
      (local.get $1)
     )
    )
   )
   (then
    (unreachable)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.tee $9
        (call $string-new
         (i32.wrap_i64
          (local.get $1)
         )
        )
       )
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.lt_u
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $9)
       )
      )
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (local.set $3
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (loop $label
     (if
      (local.get $3)
      (then
       (local.set $2
        (select
         (local.get $3)
         (local.tee $2
          (select
           (local.tee $2
            (i32.sub
             (i32.const 8192)
             (local.tee $6
              (i32.and
               (local.get $4)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $8
            (i32.sub
             (i32.const 8192)
             (local.tee $7
              (i32.and
               (local.get $5)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.lt_u
            (local.get $2)
            (local.get $8)
           )
          )
         )
         (i32.gt_u
          (local.get $2)
          (local.get $3)
         )
        )
       )
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $4)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $9)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $9)
            )
            (i32.sub
             (i32.shr_u
              (local.get $4)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $6)
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $5)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $7)
        (local.get $2)
       )
       (local.set $4
        (i32.add
         (local.get $2)
         (local.get $4)
        )
       )
       (local.set $5
        (i32.add
         (local.get $2)
         (local.get $5)
        )
       )
       (local.set $3
        (i32.sub
         (local.get $3)
         (local.get $2)
        )
       )
       (br $label)
      )
     )
    )
    (local.get $9)
   )
  )
 )
 (func $function40 (type $46) (param $0 (ref $type18)) (param $1 (ref $type18)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $1)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $1)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $1)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function80 (param $0 (ref $type18)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local.set $1
   (call $foreign0)
  )
  (if (result i32)
   (i64.eqz
    (local.tee $2
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (local.get $1)
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 1)
     )
     (then
      (local.get $1)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (local.get $1)
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $2)
        (i64.const 2)
       )
       (then
        (local.get $1)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (local.get $1)
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $2)
          (i64.const 3)
         )
         (then
          (local.get $1)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (local.get $1)
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $2)
            (i64.const 4)
           )
           (then
            (local.get $1)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (local.get $1)
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $2)
              (i64.const 5)
             )
             (then
              (local.get $1)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (local.get $1)
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $2)
                (i64.const 6)
               )
               (then
                (local.get $1)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (local.get $1)
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $2)
                  (i64.const 7)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (local.get $1)
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $2)
                    (i64.const 8)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (local.get $1)
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $2)
                      (i64.const 9)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (local.get $1)
                       (array.get $type19
                        (struct.get $type18 2
                         (local.get $0)
                        )
                        (i32.const 9)
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (local.get $2)
                        (i64.const 10)
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (if
                         (i64.le_u
                          (i64.extend_i32_u
                           (struct.get $type18 1
                            (local.get $0)
                           )
                          )
                          (i64.const 10)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (call $foreign1
                         (local.get $1)
                         (array.get $type19
                          (struct.get $type18 2
                           (local.get $0)
                          )
                          (i32.const 10)
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (local.get $2)
                          (i64.const 11)
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (if
                           (i64.le_u
                            (i64.extend_i32_u
                             (struct.get $type18 1
                              (local.get $0)
                             )
                            )
                            (i64.const 11)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (call $foreign1
                           (local.get $1)
                           (array.get $type19
                            (struct.get $type18 2
                             (local.get $0)
                            )
                            (i32.const 11)
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (local.get $2)
                            (i64.const 12)
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (if
                             (i64.le_u
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.get $0)
                               )
                              )
                              (i64.const 12)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (call $foreign1
                             (local.get $1)
                             (array.get $type19
                              (struct.get $type18 2
                               (local.get $0)
                              )
                              (i32.const 12)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (local.get $2)
                              (i64.const 13)
                             )
                             (then
                              (local.get $1)
                             )
                             (else
                              (if
                               (i64.le_u
                                (i64.extend_i32_u
                                 (struct.get $type18 1
                                  (local.get $0)
                                 )
                                )
                                (i64.const 13)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (call $foreign1
                               (local.get $1)
                               (array.get $type19
                                (struct.get $type18 2
                                 (local.get $0)
                                )
                                (i32.const 13)
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (local.get $2)
                                (i64.const 14)
                               )
                               (then
                                (local.get $1)
                               )
                               (else
                                (if
                                 (i64.le_u
                                  (i64.extend_i32_u
                                   (struct.get $type18 1
                                    (local.get $0)
                                   )
                                  )
                                  (i64.const 14)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (call $foreign1
                                 (local.get $1)
                                 (array.get $type19
                                  (struct.get $type18 2
                                   (local.get $0)
                                  )
                                  (i32.const 14)
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (local.get $2)
                                  (i64.const 15)
                                 )
                                 (then
                                  (local.get $1)
                                 )
                                 (else
                                  (if
                                   (i64.le_u
                                    (i64.extend_i32_u
                                     (struct.get $type18 1
                                      (local.get $0)
                                     )
                                    )
                                    (i64.const 15)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (call $foreign1
                                   (local.get $1)
                                   (array.get $type19
                                    (struct.get $type18 2
                                     (local.get $0)
                                    )
                                    (i32.const 15)
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (local.get $2)
                                    (i64.const 16)
                                   )
                                   (then
                                    (local.get $1)
                                   )
                                   (else
                                    (if
                                     (i64.le_u
                                      (i64.extend_i32_u
                                       (struct.get $type18 1
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 16)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (call $foreign1
                                     (local.get $1)
                                     (array.get $type19
                                      (struct.get $type18 2
                                       (local.get $0)
                                      )
                                      (i32.const 16)
                                     )
                                    )
                                    (if (result i32)
                                     (i64.eq
                                      (local.get $2)
                                      (i64.const 17)
                                     )
                                     (then
                                      (local.get $1)
                                     )
                                     (else
                                      (if
                                       (i64.le_u
                                        (i64.extend_i32_u
                                         (struct.get $type18 1
                                          (local.get $0)
                                         )
                                        )
                                        (i64.const 17)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (call $foreign1
                                       (local.get $1)
                                       (array.get $type19
                                        (struct.get $type18 2
                                         (local.get $0)
                                        )
                                        (i32.const 17)
                                       )
                                      )
                                      (if (result i32)
                                       (i64.eq
                                        (local.get $2)
                                        (i64.const 18)
                                       )
                                       (then
                                        (local.get $1)
                                       )
                                       (else
                                        (if
                                         (i64.le_u
                                          (i64.extend_i32_u
                                           (struct.get $type18 1
                                            (local.get $0)
                                           )
                                          )
                                          (i64.const 18)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (call $foreign1
                                         (local.get $1)
                                         (array.get $type19
                                          (struct.get $type18 2
                                           (local.get $0)
                                          )
                                          (i32.const 18)
                                         )
                                        )
                                        (if (result i32)
                                         (i64.eq
                                          (local.get $2)
                                          (i64.const 19)
                                         )
                                         (then
                                          (local.get $1)
                                         )
                                         (else
                                          (if
                                           (i64.le_u
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $0)
                                             )
                                            )
                                            (i64.const 19)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (call $foreign1
                                           (local.get $1)
                                           (array.get $type19
                                            (struct.get $type18 2
                                             (local.get $0)
                                            )
                                            (i32.const 19)
                                           )
                                          )
                                          (if (result i32)
                                           (i64.eq
                                            (local.get $2)
                                            (i64.const 20)
                                           )
                                           (then
                                            (local.get $1)
                                           )
                                           (else
                                            (if
                                             (i64.le_u
                                              (i64.extend_i32_u
                                               (struct.get $type18 1
                                                (local.get $0)
                                               )
                                              )
                                              (i64.const 20)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (call $foreign1
                                             (local.get $1)
                                             (array.get $type19
                                              (struct.get $type18 2
                                               (local.get $0)
                                              )
                                              (i32.const 20)
                                             )
                                            )
                                            (if (result i32)
                                             (i64.eq
                                              (local.get $2)
                                              (i64.const 21)
                                             )
                                             (then
                                              (local.get $1)
                                             )
                                             (else
                                              (if
                                               (i64.le_u
                                                (i64.extend_i32_u
                                                 (struct.get $type18 1
                                                  (local.get $0)
                                                 )
                                                )
                                                (i64.const 21)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (call $foreign1
                                               (local.get $1)
                                               (array.get $type19
                                                (struct.get $type18 2
                                                 (local.get $0)
                                                )
                                                (i32.const 21)
                                               )
                                              )
                                              (if (result i32)
                                               (i64.eq
                                                (local.get $2)
                                                (i64.const 22)
                                               )
                                               (then
                                                (local.get $1)
                                               )
                                               (else
                                                (if
                                                 (i64.le_u
                                                  (i64.extend_i32_u
                                                   (struct.get $type18 1
                                                    (local.get $0)
                                                   )
                                                  )
                                                  (i64.const 22)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (call $foreign1
                                                 (local.get $1)
                                                 (array.get $type19
                                                  (struct.get $type18 2
                                                   (local.get $0)
                                                  )
                                                  (i32.const 22)
                                                 )
                                                )
                                                (if (result i32)
                                                 (i64.eq
                                                  (local.get $2)
                                                  (i64.const 23)
                                                 )
                                                 (then
                                                  (local.get $1)
                                                 )
                                                 (else
                                                  (if
                                                   (i64.le_u
                                                    (i64.extend_i32_u
                                                     (struct.get $type18 1
                                                      (local.get $0)
                                                     )
                                                    )
                                                    (i64.const 23)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (call $foreign1
                                                   (local.get $1)
                                                   (array.get $type19
                                                    (struct.get $type18 2
                                                     (local.get $0)
                                                    )
                                                    (i32.const 23)
                                                   )
                                                  )
                                                  (if (result i32)
                                                   (i64.eq
                                                    (local.get $2)
                                                    (i64.const 24)
                                                   )
                                                   (then
                                                    (local.get $1)
                                                   )
                                                   (else
                                                    (if
                                                     (i64.le_u
                                                      (i64.extend_i32_u
                                                       (struct.get $type18 1
                                                        (local.get $0)
                                                       )
                                                      )
                                                      (i64.const 24)
                                                     )
                                                     (then
                                                      (unreachable)
                                                     )
                                                    )
                                                    (call $foreign1
                                                     (local.get $1)
                                                     (array.get $type19
                                                      (call $string-block
                                                       (local.get $0)
                                                       (i32.const 24)
                                                      )
                                                      (i32.const 24)
                                                     )
                                                    )
                                                    (return_call $function81
                                                     (local.get $0)
                                                     (local.get $1)
                                                     (local.get $2)
                                                     (i32.const 0)
                                                     (i32.const 1)
                                                     (i64.const 25)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function81 (type $44) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (local.get $1)
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function88 (type $call67) (param $0 i64) (result i64)
  (if (result i64)
   (i64.gt_s
    (local.get $0)
    (i64.const -10)
   )
   (then
    (i64.const 1)
   )
   (else
    (if (result i64)
     (i64.gt_s
      (local.tee $0
       (i64.div_s
        (local.get $0)
        (i64.const 10)
       )
      )
      (i64.const -10)
     )
     (then
      (i64.const 2)
     )
     (else
      (if (result i64)
       (i64.gt_s
        (local.tee $0
         (i64.div_s
          (local.get $0)
          (i64.const 10)
         )
        )
        (i64.const -10)
       )
       (then
        (i64.const 3)
       )
       (else
        (if (result i64)
         (i64.gt_s
          (local.tee $0
           (i64.div_s
            (local.get $0)
            (i64.const 10)
           )
          )
          (i64.const -10)
         )
         (then
          (i64.const 4)
         )
         (else
          (if (result i64)
           (i64.gt_s
            (local.tee $0
             (i64.div_s
              (local.get $0)
              (i64.const 10)
             )
            )
            (i64.const -10)
           )
           (then
            (i64.const 5)
           )
           (else
            (if (result i64)
             (i64.gt_s
              (local.tee $0
               (i64.div_s
                (local.get $0)
                (i64.const 10)
               )
              )
              (i64.const -10)
             )
             (then
              (i64.const 6)
             )
             (else
              (if (result i64)
               (i64.gt_s
                (local.tee $0
                 (i64.div_s
                  (local.get $0)
                  (i64.const 10)
                 )
                )
                (i64.const -10)
               )
               (then
                (i64.const 7)
               )
               (else
                (if (result i64)
                 (i64.gt_s
                  (local.tee $0
                   (i64.div_s
                    (local.get $0)
                    (i64.const 10)
                   )
                  )
                  (i64.const -10)
                 )
                 (then
                  (i64.const 8)
                 )
                 (else
                  (if (result i64)
                   (i64.gt_s
                    (local.tee $0
                     (i64.div_s
                      (local.get $0)
                      (i64.const 10)
                     )
                    )
                    (i64.const -10)
                   )
                   (then
                    (i64.const 9)
                   )
                   (else
                    (if (result i64)
                     (i64.gt_s
                      (local.tee $0
                       (i64.div_s
                        (local.get $0)
                        (i64.const 10)
                       )
                      )
                      (i64.const -10)
                     )
                     (then
                      (i64.const 10)
                     )
                     (else
                      (if (result i64)
                       (i64.gt_s
                        (local.tee $0
                         (i64.div_s
                          (local.get $0)
                          (i64.const 10)
                         )
                        )
                        (i64.const -10)
                       )
                       (then
                        (i64.const 11)
                       )
                       (else
                        (if (result i64)
                         (i64.gt_s
                          (local.tee $0
                           (i64.div_s
                            (local.get $0)
                            (i64.const 10)
                           )
                          )
                          (i64.const -10)
                         )
                         (then
                          (i64.const 12)
                         )
                         (else
                          (if (result i64)
                           (i64.gt_s
                            (local.tee $0
                             (i64.div_s
                              (local.get $0)
                              (i64.const 10)
                             )
                            )
                            (i64.const -10)
                           )
                           (then
                            (i64.const 13)
                           )
                           (else
                            (if (result i64)
                             (i64.gt_s
                              (local.tee $0
                               (i64.div_s
                                (local.get $0)
                                (i64.const 10)
                               )
                              )
                              (i64.const -10)
                             )
                             (then
                              (i64.const 14)
                             )
                             (else
                              (if (result i64)
                               (i64.gt_s
                                (local.tee $0
                                 (i64.div_s
                                  (local.get $0)
                                  (i64.const 10)
                                 )
                                )
                                (i64.const -10)
                               )
                               (then
                                (i64.const 15)
                               )
                               (else
                                (if (result i64)
                                 (i64.gt_s
                                  (local.tee $0
                                   (i64.div_s
                                    (local.get $0)
                                    (i64.const 10)
                                   )
                                  )
                                  (i64.const -10)
                                 )
                                 (then
                                  (i64.const 16)
                                 )
                                 (else
                                  (if (result i64)
                                   (i64.gt_s
                                    (local.tee $0
                                     (i64.div_s
                                      (local.get $0)
                                      (i64.const 10)
                                     )
                                    )
                                    (i64.const -10)
                                   )
                                   (then
                                    (i64.const 17)
                                   )
                                   (else
                                    (if (result i64)
                                     (i64.gt_s
                                      (local.tee $0
                                       (i64.div_s
                                        (local.get $0)
                                        (i64.const 10)
                                       )
                                      )
                                      (i64.const -10)
                                     )
                                     (then
                                      (i64.const 18)
                                     )
                                     (else
                                      (if (result i64)
                                       (i64.gt_s
                                        (local.tee $0
                                         (i64.div_s
                                          (local.get $0)
                                          (i64.const 10)
                                         )
                                        )
                                        (i64.const -10)
                                       )
                                       (then
                                        (i64.const 19)
                                       )
                                       (else
                                        (if (result i64)
                                         (i64.gt_s
                                          (local.tee $0
                                           (i64.div_s
                                            (local.get $0)
                                            (i64.const 10)
                                           )
                                          )
                                          (i64.const -10)
                                         )
                                         (then
                                          (i64.const 20)
                                         )
                                         (else
                                          (if (result i64)
                                           (i64.gt_s
                                            (local.tee $0
                                             (i64.div_s
                                              (local.get $0)
                                              (i64.const 10)
                                             )
                                            )
                                            (i64.const -10)
                                           )
                                           (then
                                            (i64.const 21)
                                           )
                                           (else
                                            (if (result i64)
                                             (i64.gt_s
                                              (local.tee $0
                                               (i64.div_s
                                                (local.get $0)
                                                (i64.const 10)
                                               )
                                              )
                                              (i64.const -10)
                                             )
                                             (then
                                              (i64.const 22)
                                             )
                                             (else
                                              (if (result i64)
                                               (i64.gt_s
                                                (local.tee $0
                                                 (i64.div_s
                                                  (local.get $0)
                                                  (i64.const 10)
                                                 )
                                                )
                                                (i64.const -10)
                                               )
                                               (then
                                                (i64.const 23)
                                               )
                                               (else
                                                (if (result i64)
                                                 (i64.gt_s
                                                  (local.tee $0
                                                   (i64.div_s
                                                    (local.get $0)
                                                    (i64.const 10)
                                                   )
                                                  )
                                                  (i64.const -10)
                                                 )
                                                 (then
                                                  (i64.const 24)
                                                 )
                                                 (else
                                                  (if (result i64)
                                                   (i64.gt_s
                                                    (local.tee $0
                                                     (i64.div_s
                                                      (local.get $0)
                                                      (i64.const 10)
                                                     )
                                                    )
                                                    (i64.const -10)
                                                   )
                                                   (then
                                                    (i64.const 25)
                                                   )
                                                   (else
                                                    (return_call $function89
                                                     (i32.const 0)
                                                     (i32.const 1)
                                                     (i64.div_s
                                                      (local.get $0)
                                                      (i64.const 10)
                                                     )
                                                     (i64.const 26)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function89 (type $42) (param $0 i32) (param $1 i32) (param $2 i64) (param $3 i64) (result i64)
  (if (result i64)
   (i64.gt_s
    (local.get $2)
    (i64.const -10)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function89
     (local.get $0)
     (local.get $1)
     (i64.div_s
      (local.get $2)
      (i64.const 10)
     )
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function91 (type $41) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result (ref $type18))
  (local $5 i64)
  (local $6 i32)
  (if
   (i64.gt_u
    (local.tee $5
     (i64.sub
      (i64.const 48)
      (i64.rem_s
       (local.get $3)
       (i64.const 10)
      )
     )
    )
    (i64.const 1114111)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.le_u
     (local.get $5)
     (i64.const 57343)
    )
    (i64.ge_u
     (local.get $5)
     (i64.const 55296)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $4)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type19
   (if (result (ref $type19))
    (i32.lt_u
     (local.tee $6
      (i32.wrap_i64
       (local.get $4)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type18 2
      (local.get $0)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type20
       (struct.get $type18 3
        (local.get $0)
       )
       (i32.sub
        (i32.shr_u
         (local.get $6)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $6)
    (i32.const 8191)
   )
   (i32.wrap_i64
    (local.get $5)
   )
  )
  (if (result (ref $type18))
   (i64.gt_s
    (local.get $3)
    (i64.const -10)
   )
   (then
    (local.get $0)
   )
   (else
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function91
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.div_s
      (local.get $3)
      (i64.const 10)
     )
     (i64.sub
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function96 (type $40) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign12
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function96
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function97 (type $call91) (param $0 i32) (param $1 i32) (result (ref $type92))
  (local $2 i64)
  (if (result (ref $type92))
   (local.get $1)
   (then
    (if (result (ref $type92))
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (struct.new $type94
       (i32.const 1)
       (struct.new $type25
        (i32.const 0)
        (call $foreign9
         (local.get $0)
         (i32.const 0)
        )
       )
      )
     )
     (else
      (if (result (ref $type92))
       (i32.eq
        (local.get $1)
        (i32.const 2)
       )
       (then
        (struct.new $type94
         (i32.const 1)
         (struct.new $type26
          (i32.const 1)
          (call $foreign8
           (local.get $0)
           (i32.const 0)
          )
         )
        )
       )
       (else
        (if (result (ref $type92))
         (i32.eq
          (local.get $1)
          (i32.const 3)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global296)
           )
          )
          (struct.new $type94
           (i32.const 1)
           (struct.new $type27
            (i32.const 2)
            (if (result (ref $type28))
             (i32.eq
              (call $foreign10
               (local.get $0)
               (i32.const 0)
              )
              (i32.const 1)
             )
             (then
              (struct.new $type29
               (call $foreign9
                (local.get $0)
                (i32.const 0)
               )
              )
             )
             (else
              (struct.new $type30
               (call $foreign8
                (local.get $0)
                (i32.const 0)
               )
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global296)
              )
             )
             (if (result (ref $type28))
              (i32.eq
               (call $foreign10
                (local.get $0)
                (i32.const 1)
               )
               (i32.const 1)
              )
              (then
               (struct.new $type29
                (call $foreign9
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
              (else
               (struct.new $type30
                (call $foreign8
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
             )
            )
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global299)
           )
          )
          (struct.new $type95
           (i32.const 2)
           (call $function96
            (local.get $0)
            (local.tee $2
             (i64.extend_i32_s
              (call $foreign11
               (local.get $0)
              )
             )
            )
            (block (result (ref $type18))
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (if
              (i64.gt_u
               (local.get $2)
               (i64.const 4294967294)
              )
              (then
               (unreachable)
              )
             )
             (call $string-new
              (i32.wrap_i64
               (local.get $2)
              )
             )
            )
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (global.get $empty93)
   )
  )
 )
 (func $function99 (type $call97) (param $0 (ref $type28)) (param $1 (ref $type28)) (result i32)
  (local $2 i64)
  (local $3 f64)
  (if (result i32)
   (ref.test (ref $type29)
    (local.get $0)
   )
   (then
    (local.set $2
     (struct.get $type29 0
      (ref.cast (ref $type29)
       (local.get $0)
      )
     )
    )
    (if (result i32)
     (ref.test (ref $type29)
      (local.get $1)
     )
     (then
      (i64.eq
       (struct.get $type29 0
        (ref.cast (ref $type29)
         (local.get $1)
        )
       )
       (local.get $2)
      )
     )
     (else
      (drop
       (ref.cast (ref $type30)
        (local.get $1)
       )
      )
      (i32.const 0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type30 0
      (ref.cast (ref $type30)
       (local.get $0)
      )
     )
    )
    (if (result i32)
     (ref.test (ref $type29)
      (local.get $1)
     )
     (then
      (drop
       (ref.cast (ref $type29)
        (local.get $1)
       )
      )
      (i32.const 0)
     )
     (else
      (i32.eq
       (call $foreign14
        (local.get $3)
        (struct.get $type30 0
         (ref.cast (ref $type30)
          (local.get $1)
         )
        )
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function101 (type $call99) (param $0 (ref $type24)) (param $1 (ref $type24)) (result i32)
  (local $2 i32)
  (local $3 i64)
  (local $4 (ref $type27))
  (local $5 (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if (result i32)
   (i64.eq
    (if (result i64)
     (local.tee $2
      (struct.get $type24 0
       (local.get $0)
      )
     )
     (then
      (if (result i64)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type26)
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type27)
          (local.get $0)
         )
        )
        (i64.const 2)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type25)
        (local.get $0)
       )
      )
      (i64.const 0)
     )
    )
    (if (result i64)
     (local.tee $2
      (struct.get $type24 0
       (local.get $1)
      )
     )
     (then
      (if (result i64)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type26)
          (local.get $1)
         )
        )
        (i64.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type27)
          (local.get $1)
         )
        )
        (i64.const 2)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type25)
        (local.get $1)
       )
      )
      (i64.const 0)
     )
    )
   )
   (then
    (if (result i32)
     (local.tee $2
      (struct.get $type24 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (if
         (i32.ne
          (struct.get $type24 0
           (local.get $1)
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (i32.eq
         (call $foreign14
          (struct.get $type26 1
           (ref.cast (ref $type26)
            (local.get $0)
           )
          )
          (struct.get $type26 1
           (ref.cast (ref $type26)
            (local.get $1)
           )
          )
         )
         (i32.const 1)
        )
       )
       (else
        (local.set $5
         (struct.get $type27 2
          (local.tee $4
           (ref.cast (ref $type27)
            (local.get $0)
           )
          )
         )
        )
        (if
         (i32.ne
          (struct.get $type24 0
           (local.get $1)
          )
          (i32.const 2)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global313)
         )
        )
        (if (result i32)
         (call $function99
          (struct.get $type27 1
           (local.get $4)
          )
          (struct.get $type27 1
           (local.tee $4
            (ref.cast (ref $type27)
             (local.get $1)
            )
           )
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global313)
           )
          )
          (return_call $function99
           (local.get $5)
           (struct.get $type27 2
            (local.get $4)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
     (else
      (local.set $3
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $0)
        )
       )
      )
      (if
       (struct.get $type24 0
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (i64.eq
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $1)
        )
       )
       (local.get $3)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function103 (param $0 (ref $type18)) (result (ref $type101))
  (local $1 i32)
  (local $2 i32)
  (local $3 (ref $type92))
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (if (result (ref $type101))
   (local.tee $2
    (call $foreign13
     (local.tee $1
      (call $function80
       (local.get $0)
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global340)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global305)
     )
    )
    (local.set $3
     (call $function97
      (local.get $1)
      (local.get $2)
     )
    )
    (call $foreign4
     (local.get $1)
    )
    (if (result (ref $type101))
     (i32.eq
      (struct.get $type92 0
       (local.get $3)
      )
      (i32.const 1)
     )
     (then
      (struct.new $type103
       (struct.new $type23
        (i32.const 5)
        (struct.get $type94 1
         (ref.cast (ref $type94)
          (local.get $3)
         )
        )
       )
      )
     )
     (else
      (if (result (ref $type104))
       (i32.eq
        (struct.get $type92 0
         (local.get $3)
        )
        (i32.const 2)
       )
       (then
        (struct.new $type104
         (struct.get $type95 1
          (ref.cast (ref $type95)
           (local.get $3)
          )
         )
        )
       )
       (else
        (unreachable)
       )
      )
     )
    )
   )
   (else
    (if (result (ref $type101))
     (i32.eq
      (call $foreign3
       (local.get $1)
      )
      (i32.const 1)
     )
     (then
      (struct.new $type103
       (struct.new $type21
        (i32.const 4)
        (struct.new $type22
         (call $foreign5
          (local.get $1)
         )
        )
       )
      )
     )
     (else
      (call $foreign4
       (local.get $1)
      )
      (struct.new $type104
       (global.get $string1)
      )
     )
    )
   )
  )
 )
 (func $function105 (type $call107) (param $0 (ref $type13)) (result (ref $type13))
  (if
   (i32.ne
    (struct.get $type13 0
     (local.get $0)
    )
    (i32.const 6)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type32 0
   (struct.get $type31 1
    (ref.cast (ref $type31)
     (local.get $0)
    )
   )
  )
 )
 (func $function106 (type $call107) (param $0 (ref $type13)) (result (ref $type13))
  (if
   (i32.ne
    (struct.get $type13 0
     (local.get $0)
    )
    (i32.const 6)
   )
   (then
    (unreachable)
   )
  )
  (struct.get $type32 0
   (struct.get $type31 2
    (ref.cast (ref $type31)
     (local.get $0)
    )
   )
  )
 )
 (func $function109 (type $call109) (param $0 (ref $type13)) (result i64)
  (local $1 i32)
  (if (result i64)
   (local.tee $1
    (struct.get $type13 0
     (local.get $0)
    )
   )
   (then
    (if (result i64)
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (drop
       (ref.cast (ref $type15)
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i32.eq
        (struct.get $type13 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (unreachable)
       )
       (else
        (if (result i64)
         (i32.eq
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 3)
         )
         (then
          (drop
           (ref.cast (ref $type17)
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i32.eq
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 4)
           )
           (then
            (drop
             (ref.cast (ref $type21)
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i32.eq
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 5)
             )
             (then
              (drop
               (ref.cast (ref $type23)
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i32.eq
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 6)
               )
               (then
                (drop
                 (ref.cast (ref $type31)
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 7)
                 )
                 (then
                  (drop
                   (ref.cast (ref $type33)
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (else
                  (drop
                   (ref.cast (ref $type35)
                    (local.get $0)
                   )
                  )
                  (i64.const 8)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function111 (type $call110) (param $0 (ref $type13)) (result i32)
  (drop
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (i64.eqz
   (call $function109
    (local.get $0)
   )
  )
 )
 (func $function114 (type $call111) (param $0 (ref $type13)) (param $1 (ref $type13)) (result i32)
  (local $2 (ref $type31))
  (local $3 (ref $type22))
  (local $4 (ref $type32))
  (local $5 i32)
  (local $scratch (ref $type22))
  (drop
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (if (result i32)
   (i64.eq
    (call $function109
     (local.get $0)
    )
    (block (result i64)
     (drop
      (ref.as_non_null
       (global.get $global364)
      )
     )
     (call $function109
      (local.get $1)
     )
    )
   )
   (then
    (if (result i32)
     (local.tee $5
      (struct.get $type13 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $5)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type15)
          (local.get $0)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.get $1)
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.cast (ref $type15)
          (local.get $1)
         )
        )
        (i32.const 1)
       )
       (else
        (if (result i32)
         (i32.eq
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (unreachable)
         )
         (else
          (if (result i32)
           (i32.eq
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 3)
           )
           (then
            (if
             (i32.ne
              (struct.get $type13 0
               (local.get $1)
              )
              (i32.const 3)
             )
             (then
              (unreachable)
             )
            )
            (ref.eq
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (local.get $0)
              )
             )
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (local.get $1)
              )
             )
            )
           )
           (else
            (if (result i32)
             (i32.eq
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 4)
             )
             (then
              (i32.eq
               (struct.get $type22 0
                (block (result (ref $type22))
                 (local.set $scratch
                  (struct.get $type21 1
                   (ref.cast (ref $type21)
                    (local.get $0)
                   )
                  )
                 )
                 (if
                  (i32.ne
                   (struct.get $type13 0
                    (local.get $1)
                   )
                   (i32.const 4)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global260)
                  )
                 )
                 (local.get $scratch)
                )
               )
               (struct.get $type22 0
                (struct.get $type21 1
                 (ref.cast (ref $type21)
                  (local.get $1)
                 )
                )
               )
              )
             )
             (else
              (if (result i32)
               (i32.eq
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 5)
               )
               (then
                (if
                 (i32.ne
                  (struct.get $type13 0
                   (local.get $1)
                  )
                  (i32.const 5)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global332)
                 )
                )
                (return_call $function101
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (local.get $0)
                  )
                 )
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (local.get $1)
                  )
                 )
                )
               )
               (else
                (if (result i32)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                 (then
                  (local.set $4
                   (struct.get $type31 2
                    (local.tee $2
                     (ref.cast (ref $type31)
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (if
                   (i32.ne
                    (struct.get $type13 0
                     (local.get $1)
                    )
                    (i32.const 6)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if (result i32)
                   (ref.eq
                    (struct.get $type31 1
                     (local.get $2)
                    )
                    (struct.get $type31 1
                     (local.tee $2
                      (ref.cast (ref $type31)
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (then
                    (ref.eq
                     (local.get $4)
                     (struct.get $type31 2
                      (local.get $2)
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (if (result i32)
                   (i32.eq
                    (struct.get $type13 0
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                   (then
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $1)
                      )
                      (i32.const 7)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (ref.eq
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $0)
                      )
                     )
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $1)
                      )
                     )
                    )
                   )
                   (else
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $1)
                      )
                      (i32.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (ref.eq
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (local.get $0)
                      )
                     )
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (local.get $1)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (i32.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function117 (type $call109) (param $0 (ref $type13)) (result i64)
  (drop
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (if (result i64)
   (i64.eqz
    (call $function109
     (local.get $0)
    )
   )
   (then
    (i64.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global356)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global378)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $0)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global364)
     )
    )
    (if (result i64)
     (i64.eqz
      (call $function109
       (local.tee $0
        (struct.get $type32 0
         (struct.get $type31 2
          (ref.cast (ref $type31)
           (local.get $0)
          )
         )
        )
       )
      )
     )
     (then
      (i64.const 1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global356)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global378)
       )
      )
      (if
       (i32.ne
        (struct.get $type13 0
         (local.get $0)
        )
        (i32.const 6)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global364)
       )
      )
      (if (result i64)
       (i64.eqz
        (call $function109
         (local.tee $0
          (struct.get $type32 0
           (struct.get $type31 2
            (ref.cast (ref $type31)
             (local.get $0)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const 2)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global356)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global378)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 6)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global364)
         )
        )
        (if (result i64)
         (i64.eqz
          (call $function109
           (local.tee $0
            (struct.get $type32 0
             (struct.get $type31 2
              (ref.cast (ref $type31)
               (local.get $0)
              )
             )
            )
           )
          )
         )
         (then
          (i64.const 3)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global356)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global378)
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 6)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global364)
           )
          )
          (if (result i64)
           (i64.eqz
            (call $function109
             (local.tee $0
              (struct.get $type32 0
               (struct.get $type31 2
                (ref.cast (ref $type31)
                 (local.get $0)
                )
               )
              )
             )
            )
           )
           (then
            (i64.const 4)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global356)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global378)
             )
            )
            (if
             (i32.ne
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 6)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global364)
             )
            )
            (if (result i64)
             (i64.eqz
              (call $function109
               (local.tee $0
                (struct.get $type32 0
                 (struct.get $type31 2
                  (ref.cast (ref $type31)
                   (local.get $0)
                  )
                 )
                )
               )
              )
             )
             (then
              (i64.const 5)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global356)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global378)
               )
              )
              (if
               (i32.ne
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 6)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global364)
               )
              )
              (if (result i64)
               (i64.eqz
                (call $function109
                 (local.tee $0
                  (struct.get $type32 0
                   (struct.get $type31 2
                    (ref.cast (ref $type31)
                     (local.get $0)
                    )
                   )
                  )
                 )
                )
               )
               (then
                (i64.const 6)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global356)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global378)
                 )
                )
                (if
                 (i32.ne
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global364)
                 )
                )
                (if (result i64)
                 (i64.eqz
                  (call $function109
                   (local.tee $0
                    (struct.get $type32 0
                     (struct.get $type31 2
                      (ref.cast (ref $type31)
                       (local.get $0)
                      )
                     )
                    )
                   )
                  )
                 )
                 (then
                  (i64.const 7)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global356)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global378)
                   )
                  )
                  (if
                   (i32.ne
                    (struct.get $type13 0
                     (local.get $0)
                    )
                    (i32.const 6)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global364)
                   )
                  )
                  (if (result i64)
                   (i64.eqz
                    (call $function109
                     (local.tee $0
                      (struct.get $type32 0
                       (struct.get $type31 2
                        (ref.cast (ref $type31)
                         (local.get $0)
                        )
                       )
                      )
                     )
                    )
                   )
                   (then
                    (i64.const 8)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global356)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global378)
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $0)
                      )
                      (i32.const 6)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global364)
                     )
                    )
                    (if (result i64)
                     (i64.eqz
                      (call $function109
                       (local.tee $0
                        (struct.get $type32 0
                         (struct.get $type31 2
                          (ref.cast (ref $type31)
                           (local.get $0)
                          )
                         )
                        )
                       )
                      )
                     )
                     (then
                      (i64.const 9)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global356)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global378)
                       )
                      )
                      (if
                       (i32.ne
                        (struct.get $type13 0
                         (local.get $0)
                        )
                        (i32.const 6)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global364)
                       )
                      )
                      (if (result i64)
                       (i64.eqz
                        (call $function109
                         (local.tee $0
                          (struct.get $type32 0
                           (struct.get $type31 2
                            (ref.cast (ref $type31)
                             (local.get $0)
                            )
                           )
                          )
                         )
                        )
                       )
                       (then
                        (i64.const 10)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global356)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global378)
                         )
                        )
                        (if
                         (i32.ne
                          (struct.get $type13 0
                           (local.get $0)
                          )
                          (i32.const 6)
                         )
                         (then
                          (unreachable)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global364)
                         )
                        )
                        (if (result i64)
                         (i64.eqz
                          (call $function109
                           (local.tee $0
                            (struct.get $type32 0
                             (struct.get $type31 2
                              (ref.cast (ref $type31)
                               (local.get $0)
                              )
                             )
                            )
                           )
                          )
                         )
                         (then
                          (i64.const 11)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global356)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global378)
                           )
                          )
                          (if
                           (i32.ne
                            (struct.get $type13 0
                             (local.get $0)
                            )
                            (i32.const 6)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global364)
                           )
                          )
                          (if (result i64)
                           (i64.eqz
                            (call $function109
                             (local.tee $0
                              (struct.get $type32 0
                               (struct.get $type31 2
                                (ref.cast (ref $type31)
                                 (local.get $0)
                                )
                               )
                              )
                             )
                            )
                           )
                           (then
                            (i64.const 12)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global356)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global378)
                             )
                            )
                            (if
                             (i32.ne
                              (struct.get $type13 0
                               (local.get $0)
                              )
                              (i32.const 6)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global364)
                             )
                            )
                            (if (result i64)
                             (i64.eqz
                              (call $function109
                               (local.tee $0
                                (struct.get $type32 0
                                 (struct.get $type31 2
                                  (ref.cast (ref $type31)
                                   (local.get $0)
                                  )
                                 )
                                )
                               )
                              )
                             )
                             (then
                              (i64.const 13)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global356)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global378)
                               )
                              )
                              (if
                               (i32.ne
                                (struct.get $type13 0
                                 (local.get $0)
                                )
                                (i32.const 6)
                               )
                               (then
                                (unreachable)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global364)
                               )
                              )
                              (if (result i64)
                               (i64.eqz
                                (call $function109
                                 (local.tee $0
                                  (struct.get $type32 0
                                   (struct.get $type31 2
                                    (ref.cast (ref $type31)
                                     (local.get $0)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (then
                                (i64.const 14)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global356)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global378)
                                 )
                                )
                                (if
                                 (i32.ne
                                  (struct.get $type13 0
                                   (local.get $0)
                                  )
                                  (i32.const 6)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global364)
                                 )
                                )
                                (if (result i64)
                                 (i64.eqz
                                  (call $function109
                                   (local.tee $0
                                    (struct.get $type32 0
                                     (struct.get $type31 2
                                      (ref.cast (ref $type31)
                                       (local.get $0)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                 (then
                                  (i64.const 15)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global356)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global378)
                                   )
                                  )
                                  (if
                                   (i32.ne
                                    (struct.get $type13 0
                                     (local.get $0)
                                    )
                                    (i32.const 6)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global364)
                                   )
                                  )
                                  (if (result i64)
                                   (i64.eqz
                                    (call $function109
                                     (local.tee $0
                                      (struct.get $type32 0
                                       (struct.get $type31 2
                                        (ref.cast (ref $type31)
                                         (local.get $0)
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (i64.const 16)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global356)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global378)
                                     )
                                    )
                                    (if
                                     (i32.ne
                                      (struct.get $type13 0
                                       (local.get $0)
                                      )
                                      (i32.const 6)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global364)
                                     )
                                    )
                                    (if (result i64)
                                     (i64.eqz
                                      (call $function109
                                       (local.tee $0
                                        (struct.get $type32 0
                                         (struct.get $type31 2
                                          (ref.cast (ref $type31)
                                           (local.get $0)
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (then
                                      (i64.const 17)
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global356)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global378)
                                       )
                                      )
                                      (if
                                       (i32.ne
                                        (struct.get $type13 0
                                         (local.get $0)
                                        )
                                        (i32.const 6)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global364)
                                       )
                                      )
                                      (if (result i64)
                                       (i64.eqz
                                        (call $function109
                                         (local.tee $0
                                          (struct.get $type32 0
                                           (struct.get $type31 2
                                            (ref.cast (ref $type31)
                                             (local.get $0)
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                       (then
                                        (i64.const 18)
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global356)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global378)
                                         )
                                        )
                                        (if
                                         (i32.ne
                                          (struct.get $type13 0
                                           (local.get $0)
                                          )
                                          (i32.const 6)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global364)
                                         )
                                        )
                                        (if (result i64)
                                         (i64.eqz
                                          (call $function109
                                           (local.tee $0
                                            (struct.get $type32 0
                                             (struct.get $type31 2
                                              (ref.cast (ref $type31)
                                               (local.get $0)
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                         (then
                                          (i64.const 19)
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global356)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global378)
                                           )
                                          )
                                          (if
                                           (i32.ne
                                            (struct.get $type13 0
                                             (local.get $0)
                                            )
                                            (i32.const 6)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global364)
                                           )
                                          )
                                          (if (result i64)
                                           (i64.eqz
                                            (call $function109
                                             (local.tee $0
                                              (struct.get $type32 0
                                               (struct.get $type31 2
                                                (ref.cast (ref $type31)
                                                 (local.get $0)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (i64.const 20)
                                           )
                                           (else
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global356)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global378)
                                             )
                                            )
                                            (if
                                             (i32.ne
                                              (struct.get $type13 0
                                               (local.get $0)
                                              )
                                              (i32.const 6)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                            )
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global364)
                                             )
                                            )
                                            (if (result i64)
                                             (i64.eqz
                                              (call $function109
                                               (local.tee $0
                                                (struct.get $type32 0
                                                 (struct.get $type31 2
                                                  (ref.cast (ref $type31)
                                                   (local.get $0)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                             (then
                                              (i64.const 21)
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global356)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global378)
                                               )
                                              )
                                              (if
                                               (i32.ne
                                                (struct.get $type13 0
                                                 (local.get $0)
                                                )
                                                (i32.const 6)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global364)
                                               )
                                              )
                                              (if (result i64)
                                               (i64.eqz
                                                (call $function109
                                                 (local.tee $0
                                                  (struct.get $type32 0
                                                   (struct.get $type31 2
                                                    (ref.cast (ref $type31)
                                                     (local.get $0)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (then
                                                (i64.const 22)
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global356)
                                                 )
                                                )
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global378)
                                                 )
                                                )
                                                (if
                                                 (i32.ne
                                                  (struct.get $type13 0
                                                   (local.get $0)
                                                  )
                                                  (i32.const 6)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global364)
                                                 )
                                                )
                                                (if (result i64)
                                                 (i64.eqz
                                                  (call $function109
                                                   (local.tee $0
                                                    (struct.get $type32 0
                                                     (struct.get $type31 2
                                                      (ref.cast (ref $type31)
                                                       (local.get $0)
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (then
                                                  (i64.const 23)
                                                 )
                                                 (else
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global356)
                                                   )
                                                  )
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global378)
                                                   )
                                                  )
                                                  (if
                                                   (i32.ne
                                                    (struct.get $type13 0
                                                     (local.get $0)
                                                    )
                                                    (i32.const 6)
                                                   )
                                                   (then
                                                    (unreachable)
                                                   )
                                                  )
                                                  (if (result i64)
                                                   (call $function111
                                                    (local.tee $0
                                                     (struct.get $type32 0
                                                      (struct.get $type31 2
                                                       (ref.cast (ref $type31)
                                                        (local.get $0)
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                   (then
                                                    (i64.const 24)
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global356)
                                                     )
                                                    )
                                                    (return_call $function118
                                                     (i32.const 0)
                                                     (i32.const 1)
                                                     (call $function106
                                                      (local.get $0)
                                                     )
                                                     (i64.const 25)
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function118 (type $13) (param $0 i32) (param $1 i32) (param $2 (ref $type13)) (param $3 i64) (result i64)
  (drop
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (if (result i64)
   (call $function111
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global356)
     )
    )
    (local.set $2
     (call $function106
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function118
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function119 (type $call106) (param $0 (ref $type13)) (param $1 (ref $type13)) (result (ref $type13))
  (local $2 (ref $type31))
  (drop
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (if (result (ref $type13))
   (i64.eqz
    (call $function109
     (local.get $0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global354)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $0)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $0
     (struct.get $type32 0
      (struct.get $type31 1
       (local.tee $2
        (ref.cast (ref $type31)
         (local.get $0)
        )
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global356)
     )
    )
    (if
     (i32.eqz
      (global.get $ready406)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global406)
     )
    )
    (local.set $1
     (call $function119
      (struct.get $type32 0
       (struct.get $type31 2
        (local.get $2)
       )
      )
      (local.get $1)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (struct.new $type31
     (i32.const 6)
     (struct.new $type32
      (local.get $0)
     )
     (struct.new $type32
      (local.get $1)
     )
    )
   )
  )
 )
 (func $function120 (type $call106) (param $0 (ref $type13)) (param $1 (ref $type13)) (result (ref $type13))
  (local $2 (ref $type13))
  (local $3 (ref $type31))
  (drop
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (if (result (ref $type13))
   (i64.eqz
    (call $function109
     (local.get $1)
    )
   )
   (then
    (struct.new $type15
     (i32.const 1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global354)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global384)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $1)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.tee $2
        (struct.get $type32 0
         (struct.get $type31 1
          (ref.cast (ref $type31)
           (local.get $1)
          )
         )
        )
       )
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (if (result (ref $type31))
     (call $function114
      (local.get $0)
      (struct.get $type32 0
       (struct.get $type31 1
        (local.tee $3
         (ref.cast (ref $type31)
          (local.get $2)
         )
        )
       )
      )
     )
     (then
      (local.get $3)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global356)
       )
      )
      (if
       (i32.ne
        (struct.get $type13 0
         (local.get $1)
        )
        (i32.const 6)
       )
       (then
        (unreachable)
       )
      )
      (local.set $1
       (struct.get $type32 0
        (struct.get $type31 2
         (ref.cast (ref $type31)
          (local.get $1)
         )
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready409)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global409)
       )
      )
      (return_call $function120
       (local.get $0)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function121 (type $call113) (param $0 (ref $type107)) (param $1 (ref $type13)) (result (ref $type13))
  (local $2 (ref $type31))
  (local $3 (ref $type13))
  (drop
   (ref.as_non_null
    (global.get $global378)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (if (result (ref $type13))
   (i64.eqz
    (call $function109
     (local.get $1)
    )
   )
   (then
    (global.get $empty14)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global354)
     )
    )
    (if
     (i32.ne
      (struct.get $type13 0
       (local.get $1)
      )
      (i32.const 6)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (call_ref $call107
      (struct.get $type32 0
       (struct.get $type31 1
        (local.tee $2
         (ref.cast (ref $type31)
          (local.get $1)
         )
        )
       )
      )
      (struct.get $type107 0
       (local.get $0)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global356)
     )
    )
    (if
     (i32.eqz
      (global.get $ready413)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global413)
     )
    )
    (local.set $3
     (call $function121
      (local.get $0)
      (struct.get $type32 0
       (struct.get $type31 2
        (local.get $2)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global351)
     )
    )
    (struct.new $type31
     (i32.const 6)
     (struct.new $type32
      (local.get $1)
     )
     (struct.new $type32
      (local.get $3)
     )
    )
   )
  )
 )
 (func $function122 (type $call111) (param $0 (ref $type13)) (param $1 (ref $type13)) (result i32)
  (local $2 i64)
  (local $3 i32)
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type34))
  (local $7 (ref $type34))
  (local $8 (ref $type36))
  (local $9 (ref $type36))
  (local $10 (ref $type22))
  (local $11 (ref $type31))
  (local $12 (ref $type32))
  (local $scratch (ref $type22))
  (drop
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (if (result i32)
   (i64.eq
    (call $function109
     (local.get $0)
    )
    (block (result i64)
     (drop
      (ref.as_non_null
       (global.get $global364)
      )
     )
     (call $function109
      (local.get $1)
     )
    )
   )
   (then
    (if (result i32)
     (local.tee $3
      (struct.get $type13 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $3)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type15)
          (local.get $0)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.get $1)
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.cast (ref $type15)
          (local.get $1)
         )
        )
        (i32.const 1)
       )
       (else
        (if (result i32)
         (i32.eq
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (unreachable)
         )
         (else
          (if (result i32)
           (i32.eq
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 3)
           )
           (then
            (local.set $4
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (local.get $0)
              )
             )
            )
            (if
             (i32.ne
              (struct.get $type13 0
               (local.get $1)
              )
              (i32.const 3)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global103)
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $4)
               )
              )
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.tee $5
                 (struct.get $type17 1
                  (ref.cast (ref $type17)
                   (local.get $1)
                  )
                 )
                )
               )
              )
             )
             (then
              (return_call $function40
               (local.get $4)
               (local.get $5)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
           (else
            (if (result i32)
             (i32.eq
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 4)
             )
             (then
              (i32.eq
               (struct.get $type22 0
                (block (result (ref $type22))
                 (local.set $scratch
                  (struct.get $type21 1
                   (ref.cast (ref $type21)
                    (local.get $0)
                   )
                  )
                 )
                 (if
                  (i32.ne
                   (struct.get $type13 0
                    (local.get $1)
                   )
                   (i32.const 4)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global260)
                  )
                 )
                 (local.get $scratch)
                )
               )
               (struct.get $type22 0
                (struct.get $type21 1
                 (ref.cast (ref $type21)
                  (local.get $1)
                 )
                )
               )
              )
             )
             (else
              (if (result i32)
               (i32.eq
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 5)
               )
               (then
                (if
                 (i32.ne
                  (struct.get $type13 0
                   (local.get $1)
                  )
                  (i32.const 5)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global332)
                 )
                )
                (return_call $function101
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (local.get $0)
                  )
                 )
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (local.get $1)
                  )
                 )
                )
               )
               (else
                (if (result i32)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                 (then
                  (local.set $12
                   (struct.get $type31 2
                    (local.tee $11
                     (ref.cast (ref $type31)
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global354)
                   )
                  )
                  (if
                   (i32.ne
                    (struct.get $type13 0
                     (local.get $1)
                    )
                    (i32.const 6)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $0
                   (struct.get $type32 0
                    (struct.get $type31 1
                     (ref.cast (ref $type31)
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready417)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global417)
                   )
                  )
                  (if (result i32)
                   (call $function122
                    (struct.get $type32 0
                     (struct.get $type31 1
                      (local.get $11)
                     )
                    )
                    (local.get $0)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global356)
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $1)
                      )
                      (i32.const 6)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $0
                     (struct.get $type32 0
                      (struct.get $type31 2
                       (ref.cast (ref $type31)
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready417)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global417)
                     )
                    )
                    (return_call $function122
                     (struct.get $type32 0
                      (local.get $12)
                     )
                     (local.get $0)
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (if (result i32)
                   (i32.eq
                    (struct.get $type13 0
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                   (then
                    (local.set $6
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $0)
                      )
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $1)
                      )
                      (i32.const 7)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $7
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $1)
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready429)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global429)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.tee $2
                       (i64.extend_i32_u
                        (array.len
                         (local.get $6)
                        )
                       )
                      )
                      (i64.extend_i32_u
                       (array.len
                        (local.get $7)
                       )
                      )
                     )
                     (then
                      (return_call $function124
                       (local.get $6)
                       (local.get $7)
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 0)
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                   (else
                    (local.set $8
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (local.get $0)
                      )
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $1)
                      )
                      (i32.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $9
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (local.get $1)
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready437)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global437)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.tee $2
                       (i64.extend_i32_u
                        (array.len
                         (struct.get $type36 0
                          (local.get $8)
                         )
                        )
                       )
                      )
                      (i64.extend_i32_u
                       (array.len
                        (struct.get $type36 0
                         (local.get $9)
                        )
                       )
                      )
                     )
                     (then
                      (return_call $function126
                       (local.get $8)
                       (local.get $9)
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 0)
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (i32.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function124 (type $8) (param $0 (ref $type34)) (param $1 (ref $type34)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $6
    (i64.eq
     (local.get $2)
     (local.get $5)
    )
   )
   (then
    (local.get $6)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global417)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call $function122
      (array.get $type34
       (local.get $0)
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (array.get $type34
       (local.get $1)
       (local.get $6)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function124
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i64.add
        (local.get $5)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function126 (type $7) (param $0 (ref $type36)) (param $1 (ref $type36)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $6
    (i64.eq
     (local.get $2)
     (local.get $5)
    )
   )
   (then
    (local.get $6)
   )
   (else
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (array.get_u $type37
        (struct.get $type36 0
         (local.get $0)
        )
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
       )
      )
      (i64.extend_i32_u
       (array.get_u $type37
        (struct.get $type36 0
         (local.get $1)
        )
        (local.get $6)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function126
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i64.add
        (local.get $5)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function129 (type $call107) (param $0 (ref $type13)) (result (ref $type13))
  (local.get $0)
 )
 (func $function137 (type $5) (param $0 (ref $type18)) (result i32)
  (local $1 i64)
  (local $2 i64)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref $type24))
  (local $6 (ref $type18))
  (local $7 (ref $type18))
  (local $8 (ref $type92))
  (drop
   (ref.as_non_null
    (global.get $global308)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $4
   (call $foreign13
    (local.tee $3
     (call $function80
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global305)
   )
  )
  (local.set $8
   (call $function97
    (local.get $3)
    (local.get $4)
   )
  )
  (call $foreign4
   (local.get $3)
  )
  (if
   (i32.ne
    (struct.get $type92 0
     (local.get $8)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if (result i32)
   (struct.get $type24 0
    (local.tee $5
     (struct.get $type94 1
      (ref.cast (ref $type94)
       (local.get $8)
      )
     )
    )
   )
   (then
    (if
     (i32.eq
      (struct.get $type24 0
       (local.get $5)
      )
      (i32.const 1)
     )
     (then
      (drop
       (ref.cast (ref $type26)
        (local.get $5)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type27)
        (local.get $5)
       )
      )
     )
    )
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global275)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global270)
     )
    )
    (local.set $1
     (i64.add
      (call $function88
       (local.tee $2
        (select
         (local.tee $1
          (struct.get $type25 1
           (ref.cast (ref $type25)
            (local.get $5)
           )
          )
         )
         (i64.sub
          (i64.const 0)
          (local.get $1)
         )
         (local.tee $3
          (i64.lt_s
           (local.get $1)
           (i64.const 0)
          )
         )
        )
       )
      )
      (i64.extend_i32_u
       (local.get $3)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global61)
     )
    )
    (if
     (i64.gt_u
      (local.get $1)
      (i64.const 4294967294)
     )
     (then
      (unreachable)
     )
    )
    (local.set $6
     (call $string-new
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (if
     (local.get $3)
     (then
      (if
       (i32.ne
        (struct.get $type18 0
         (local.get $6)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.eqz
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $6)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type19
       (struct.get $type18 2
        (local.get $6)
       )
       (i32.const 0)
       (i32.const 45)
      )
     )
    )
    (local.set $7
     (call $function91
      (local.get $6)
      (i32.const 0)
      (i32.const 1)
      (local.get $2)
      (i64.sub
       (local.get $1)
       (i64.const 1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global103)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $7)
       )
      )
     )
     (then
      (return_call $function40
       (local.get $0)
       (local.get $7)
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function138 (type $5) (param $0 (ref $type18)) (result i32)
  (local $1 (ref $type101))
  (local $2 (ref $type92))
  (local $3 i32)
  (local $4 i32)
  (drop
   (ref.as_non_null
    (global.get $global347)
   )
  )
  (if (result i32)
   (ref.test (ref $type103)
    (local.tee $1
     (call $function103
      (local.get $0)
     )
    )
   )
   (then
    (return_call $function122
     (struct.get $type103 0
      (ref.cast (ref $type103)
       (local.get $1)
      )
     )
     (block (result (ref (exact $type23)))
      (drop
       (ref.as_non_null
        (global.get $global308)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global246)
       )
      )
      (local.set $4
       (call $foreign13
        (local.tee $3
         (call $function80
          (local.get $0)
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global305)
       )
      )
      (local.set $2
       (call $function97
        (local.get $3)
        (local.get $4)
       )
      )
      (call $foreign4
       (local.get $3)
      )
      (if
       (i32.ne
        (struct.get $type92 0
         (local.get $2)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global417)
       )
      )
      (struct.new $type23
       (i32.const 5)
       (struct.get $type94 1
        (ref.cast (ref $type94)
         (local.get $2)
        )
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eqz
      (ref.test (ref $type103)
       (local.get $1)
      )
     )
     (then
      (drop
       (ref.cast (ref $type104)
        (local.get $1)
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $function139 (type $5) (param $0 (ref $type18)) (result i32)
  (local $1 (ref $type92))
  (local $2 (ref $type101))
  (local $3 (ref $type18))
  (local $4 (ref $type18))
  (local $5 i32)
  (local $6 i32)
  (drop
   (ref.as_non_null
    (global.get $global308)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $6
   (call $foreign13
    (local.tee $5
     (call $function80
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global305)
   )
  )
  (local.set $1
   (call $function97
    (local.get $5)
    (local.get $6)
   )
  )
  (call $foreign4
   (local.get $5)
  )
  (if (result i32)
   (i32.eq
    (struct.get $type92 0
     (local.get $1)
    )
    (i32.const 2)
   )
   (then
    (local.set $3
     (struct.get $type95 1
      (ref.cast (ref $type95)
       (local.get $1)
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global347)
     )
    )
    (if (result i32)
     (ref.test (ref $type103)
      (local.tee $2
       (call $function103
        (local.get $0)
       )
      )
     )
     (then
      (if
       (ref.test (ref $type103)
        (local.get $2)
       )
       (then
        (drop
         (ref.cast (ref $type103)
          (local.get $2)
         )
        )
       )
      )
      (i32.const 0)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global103)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $3)
         )
        )
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.tee $4
           (struct.get $type104 0
            (ref.cast (ref $type104)
             (local.get $2)
            )
           )
          )
         )
        )
       )
       (then
        (return_call $function40
         (local.get $3)
         (local.get $4)
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
    )
   )
   (else
    (if
     (i32.eq
      (struct.get $type92 0
       (local.get $1)
      )
      (i32.const 1)
     )
     (then
      (drop
       (ref.cast (ref $type94)
        (local.get $1)
       )
      )
     )
    )
    (i32.const 0)
   )
  )
 )
 (func $export0 (param $0 i64) (result i64)
  (local $1 (ref $type31))
  (local $2 (ref $type31))
  (local $3 (ref $type31))
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type101))
  (local $8 (ref $type13))
  (local $9 (ref $type14))
  (local $10 (ref $type34))
  (local $11 (ref $type34))
  (local $12 (ref $type21))
  (local $13 (ref $type21))
  (local $14 (ref $type36))
  (local $15 (ref $type36))
  (local $16 (ref $type32))
  (local $17 (ref $type32))
  (local $18 (ref $type22))
  (local $scratch (ref $type18))
  (local $scratch_20 (ref $type18))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready509)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global509)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global507)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global444)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global361)
   )
  )
  (struct.set $type32 0
   (struct.get $type31 2
    (local.tee $1
     (struct.new $type31
      (i32.const 6)
      (local.tee $16
       (struct.new $type32
        (local.tee $9
         (global.get $empty14)
        )
       )
      )
      (local.tee $17
       (struct.new $type32
        (local.get $9)
       )
      )
     )
    )
   )
   (local.get $1)
  )
  (drop
   (ref.as_non_null
    (global.get $global384)
   )
  )
  (select
   (i64.const 42)
   (i64.const 0)
   (if (result i32)
    (if (result i32)
     (call $function114
      (local.get $1)
      (local.tee $3
       (struct.new $type31
        (i32.const 6)
        (local.get $16)
        (local.get $17)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global356)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global384)
       )
      )
      (if (result i32)
       (call $function114
        (struct.get $type32 0
         (struct.get $type31 2
          (local.get $3)
         )
        )
        (local.get $1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global384)
         )
        )
        (if (result i32)
         (call $function114
          (local.get $1)
          (struct.new $type31
           (i32.const 6)
           (local.get $16)
           (struct.new $type32
            (local.get $1)
           )
          )
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global384)
           )
          )
          (if (result i32)
           (call $function114
            (local.get $1)
            (struct.new $type31
             (i32.const 6)
             (struct.new $type32
              (global.get $empty14)
             )
             (local.get $17)
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global351)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global384)
             )
            )
            (i32.eqz
             (call $function114
              (local.get $1)
              (struct.new $type31
               (i32.const 6)
               (struct.new $type32
                (global.get $empty14)
               )
               (struct.new $type32
                (local.get $1)
               )
              )
             )
            )
           )
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global449)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global258)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global246)
      )
     )
     (local.set $12
      (struct.new $type21
       (i32.const 4)
       (struct.new $type22
        (call $foreign5
         (call $function80
          (global.get $string2)
         )
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global258)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global246)
      )
     )
     (local.set $13
      (struct.new $type21
       (i32.const 4)
       (struct.new $type22
        (call $foreign5
         (call $function80
          (global.get $string3)
         )
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global397)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global406)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global351)
      )
     )
     (local.set $8
      (call $function119
       (local.tee $1
        (struct.new $type31
         (i32.const 6)
         (struct.new $type32
          (local.get $12)
         )
         (struct.new $type32
          (global.get $empty14)
         )
        )
       )
       (local.tee $3
        (struct.new $type31
         (i32.const 6)
         (struct.new $type32
          (local.get $13)
         )
         (struct.new $type32
          (global.get $empty14)
         )
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global401)
      )
     )
     (if (result i32)
      (if (result i32)
       (i64.eq
        (call $function117
         (local.get $8)
        )
        (i64.const 2)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global356)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global384)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.get $8)
          )
          (i32.const 6)
         )
         (then
          (unreachable)
         )
        )
        (if (result i32)
         (call $function114
          (struct.get $type32 0
           (struct.get $type31 2
            (local.tee $2
             (ref.cast (ref $type31)
              (local.get $8)
             )
            )
           )
          )
          (local.get $3)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global384)
           )
          )
          (if (result i32)
           (call $function114
            (local.get $1)
            (local.get $2)
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global354)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global384)
             )
            )
            (if (result i32)
             (call $function114
              (struct.get $type32 0
               (struct.get $type31 1
                (local.get $2)
               )
              )
              (local.get $12)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global397)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global409)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global351)
               )
              )
              (if (result i32)
               (call $function114
                (call $function120
                 (local.get $12)
                 (struct.new $type31
                  (i32.const 6)
                  (struct.new $type32
                   (local.tee $1
                    (struct.new $type31
                     (i32.const 6)
                     (struct.new $type32
                      (local.get $12)
                     )
                     (struct.new $type32
                      (local.get $13)
                     )
                    )
                   )
                  )
                  (struct.new $type32
                   (global.get $empty14)
                  )
                 )
                )
                (block (result (ref $type31))
                 (drop
                  (ref.as_non_null
                   (global.get $global384)
                  )
                 )
                 (local.get $1)
                )
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global397)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global409)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global351)
                 )
                )
                (local.set $8
                 (call $function120
                  (local.get $13)
                  (struct.new $type31
                   (i32.const 6)
                   (struct.new $type32
                    (local.get $1)
                   )
                   (struct.new $type32
                    (global.get $empty14)
                   )
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global382)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global364)
                 )
                )
                (if (result i32)
                 (if (result i32)
                  (i64.eq
                   (call $function109
                    (local.get $8)
                   )
                   (i64.const 1)
                  )
                  (then
                   (if
                    (i32.ne
                     (struct.get $type13 0
                      (local.get $8)
                     )
                     (i32.const 1)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.cast (ref $type15)
                     (local.get $8)
                    )
                   )
                   (i32.const 0)
                  )
                  (else
                   (i32.const 1)
                  )
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global413)
                   )
                  )
                  (call $function122
                   (call $function121
                    (struct.new $type107
                     (ref.func $function129)
                    )
                    (local.get $2)
                   )
                   (block (result (ref $type31))
                    (drop
                     (ref.as_non_null
                      (global.get $global417)
                     )
                    )
                    (local.get $2)
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global457)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global88)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global81)
        )
       )
       (local.set $4
        (call $function33
         (global.get $string2)
         (i64.const 1)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global111)
        )
       )
       (if
        (i32.eqz
         (global.get $ready114)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global114)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global109)
        )
       )
       (array.set $type37
        (struct.get $type36 0
         (local.tee $14
          (struct.new $type36
           (array.new_default $type37
            (i32.const 1)
           )
          )
         )
        )
        (i32.const 0)
        (i32.const 1)
       )
       (drop
        (ref.as_non_null
         (global.get $global461)
        )
       )
       (if
        (i32.eqz
         (global.get $ready463)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global463)
        )
       )
       (if
        (i32.eqz
         (global.get $ready466)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global466)
        )
       )
       (array.set $type34
        (local.tee $10
         (array.new_fixed $type34 1
          (local.tee $9
           (global.get $empty14)
          )
         )
        )
        (i32.const 0)
        (local.get $9)
       )
       (drop
        (ref.as_non_null
         (global.get $global384)
        )
       )
       (if (result i32)
        (if (result i32)
         (call $function114
          (struct.new $type17
           (i32.const 3)
           (local.get $4)
          )
          (struct.new $type17
           (i32.const 3)
           (local.get $4)
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global88)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global81)
           )
          )
          (local.set $6
           (call $function33
            (local.get $4)
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $4)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global384)
           )
          )
          (if (result i32)
           (call $function114
            (struct.new $type17
             (i32.const 3)
             (local.get $4)
            )
            (struct.new $type17
             (i32.const 3)
             (local.get $6)
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global384)
             )
            )
            (if (result i32)
             (call $function114
              (struct.new $type33
               (i32.const 7)
               (local.get $10)
              )
              (struct.new $type33
               (i32.const 7)
               (local.get $10)
              )
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global474)
               )
              )
              (array.copy $type34 $type34
               (local.tee $11
                (array.new_fixed $type34 1
                 (array.get $type34
                  (local.get $10)
                  (i32.const 0)
                 )
                )
               )
               (i32.const 0)
               (local.get $10)
               (i32.const 0)
               (i32.const 1)
              )
              (drop
               (ref.as_non_null
                (global.get $global384)
               )
              )
              (if (result i32)
               (call $function114
                (struct.new $type33
                 (i32.const 7)
                 (local.get $10)
                )
                (struct.new $type33
                 (i32.const 7)
                 (local.get $11)
                )
               )
               (then
                (i32.const 0)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global384)
                 )
                )
                (if (result i32)
                 (call $function114
                  (struct.new $type35
                   (i32.const 8)
                   (local.get $14)
                  )
                  (struct.new $type35
                   (i32.const 8)
                   (local.get $14)
                  )
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global145)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global131)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global135)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global109)
                   )
                  )
                  (array.copy $type37 $type37
                   (struct.get $type36 0
                    (local.tee $15
                     (struct.new $type36
                      (array.new_default $type37
                       (i32.const 1)
                      )
                     )
                    )
                   )
                   (i32.const 0)
                   (struct.get $type36 0
                    (local.get $14)
                   )
                   (i32.const 0)
                   (i32.const 1)
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global384)
                   )
                  )
                  (i32.eqz
                   (call $function114
                    (struct.new $type35
                     (i32.const 8)
                     (local.get $14)
                    )
                    (struct.new $type35
                     (i32.const 8)
                     (local.get $15)
                    )
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global504)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global347)
          )
         )
         (if
          (i32.eqz
           (ref.test (ref $type103)
            (local.tee $7
             (call $function103
              (global.get $string4)
             )
            )
           )
          )
          (then
           (unreachable)
          )
         )
         (if (result i32)
          (if (result i32)
           (call $function114
            (struct.get $type103 0
             (ref.cast (ref $type103)
              (local.get $7)
             )
            )
            (block (result (ref $type13))
             (drop
              (ref.as_non_null
               (global.get $global88)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global81)
              )
             )
             (if
              (i32.eqz
               (ref.test (ref $type103)
                (local.tee $7
                 (call $function103
                  (block (result (ref $type18))
                   (local.set $scratch
                    (call $function33
                     (global.get $string4)
                     (i64.const 4)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global347)
                    )
                   )
                   (local.get $scratch)
                  )
                 )
                )
               )
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global384)
              )
             )
             (struct.get $type103 0
              (ref.cast (ref $type103)
               (local.get $7)
              )
             )
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global486)
             )
            )
            (if (result i32)
             (call $function138
              (global.get $string12)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global486)
               )
              )
              (if (result i32)
               (call $function138
                (global.get $string11)
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global486)
                 )
                )
                (if (result i32)
                 (call $function138
                  (global.get $string10)
                 )
                 (then
                  (drop
                   (ref.as_non_null
                    (global.get $global491)
                   )
                  )
                  (if (result i32)
                   (call $function139
                    (global.get $string9)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global491)
                     )
                    )
                    (if (result i32)
                     (call $function139
                      (global.get $string8)
                     )
                     (then
                      (drop
                       (ref.as_non_null
                        (global.get $global491)
                       )
                      )
                      (if (result i32)
                       (call $function139
                        (global.get $string7)
                       )
                       (then
                        (drop
                         (ref.as_non_null
                          (global.get $global499)
                         )
                        )
                        (drop
                         (ref.as_non_null
                          (global.get $global347)
                         )
                        )
                        (if (result i32)
                         (if (result i32)
                          (ref.test (ref $type103)
                           (local.tee $7
                            (call $function103
                             (global.get $string6)
                            )
                           )
                          )
                          (then
                           (if
                            (ref.test (ref $type103)
                             (local.get $7)
                            )
                            (then
                             (drop
                              (ref.cast (ref $type103)
                               (local.get $7)
                              )
                             )
                            )
                           )
                           (i32.const 0)
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global103)
                            )
                           )
                           (if (result i32)
                            (i64.eq
                             (i64.extend_i32_u
                              (struct.get $type18 1
                               (local.tee $5
                                (struct.get $type104 0
                                 (ref.cast (ref $type104)
                                  (local.get $7)
                                 )
                                )
                               )
                              )
                             )
                             (i64.const 71)
                            )
                            (then
                             (call $function40
                              (local.get $5)
                              (global.get $string1)
                              (i32.const 0)
                              (i32.const 1)
                              (i64.const 0)
                             )
                            )
                            (else
                             (i32.const 0)
                            )
                           )
                          )
                         )
                         (then
                          (drop
                           (ref.as_non_null
                            (global.get $global499)
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global347)
                           )
                          )
                          (if (result i32)
                           (ref.test (ref $type103)
                            (local.tee $7
                             (call $function103
                              (global.get $string5)
                             )
                            )
                           )
                           (then
                            (if
                             (ref.test (ref $type103)
                              (local.get $7)
                             )
                             (then
                              (drop
                               (ref.cast (ref $type103)
                                (local.get $7)
                               )
                              )
                             )
                            )
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global103)
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (struct.get $type18 1
                                (local.tee $5
                                 (struct.get $type104 0
                                  (ref.cast (ref $type104)
                                   (local.get $7)
                                  )
                                 )
                                )
                               )
                              )
                              (i64.const 71)
                             )
                             (then
                              (call $function40
                               (local.get $5)
                               (global.get $string1)
                               (i32.const 0)
                               (i32.const 1)
                               (i64.const 0)
                              )
                             )
                             (else
                              (i32.const 0)
                             )
                            )
                           )
                          )
                         )
                         (else
                          (i32.const 0)
                         )
                        )
                       )
                       (else
                        (i32.const 0)
                       )
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (i32.const 0)
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global378)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global364)
            )
           )
           (if (result i32)
            (i64.eqz
             (call $function109
              (local.tee $9
               (global.get $empty14)
              )
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global397)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global380)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global364)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global351)
              )
             )
             (if (result i32)
              (i64.eq
               (call $function109
                (struct.new $type31
                 (i32.const 6)
                 (struct.new $type32
                  (local.get $9)
                 )
                 (struct.new $type32
                  (global.get $empty14)
                 )
                )
               )
               (i64.const 6)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global382)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global364)
                )
               )
               (if (result i32)
                (if (result i32)
                 (i64.eq
                  (call $function109
                   (local.get $9)
                  )
                  (i64.const 1)
                 )
                 (then
                  (unreachable)
                 )
                 (else
                  (i32.const 1)
                 )
                )
                (then
                 (drop
                  (ref.as_non_null
                   (global.get $global382)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global364)
                  )
                 )
                 (if (result i32)
                  (i64.ne
                   (call $function109
                    (struct.new $type15
                     (i32.const 1)
                    )
                   )
                   (i64.const 1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global258)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global246)
                    )
                   )
                   (if (result i32)
                    (call $function114
                     (struct.new $type21
                      (i32.const 4)
                      (struct.new $type22
                       (call $foreign5
                        (call $function80
                         (local.tee $4
                          (global.get $string4)
                         )
                        )
                       )
                      )
                     )
                     (block (result (ref (exact $type21)))
                      (drop
                       (ref.as_non_null
                        (global.get $global88)
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global81)
                       )
                      )
                      (local.set $18
                       (struct.new $type22
                        (call $foreign5
                         (call $function80
                          (block (result (ref $type18))
                           (local.set $scratch_20
                            (call $function33
                             (local.get $4)
                             (i64.const 4)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global258)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global246)
                            )
                           )
                           (local.get $scratch_20)
                          )
                         )
                        )
                       )
                      )
                      (drop
                       (ref.as_non_null
                        (global.get $global384)
                       )
                      )
                      (struct.new $type21
                       (i32.const 4)
                       (local.get $18)
                      )
                     )
                    )
                    (then
                     (drop
                      (ref.as_non_null
                       (global.get $global478)
                      )
                     )
                     (if (result i32)
                      (call $function137
                       (global.get $string16)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global478)
                        )
                       )
                       (if (result i32)
                        (call $function137
                         (global.get $string12)
                        )
                        (then
                         (drop
                          (ref.as_non_null
                           (global.get $global478)
                          )
                         )
                         (if (result i32)
                          (call $function137
                           (global.get $string15)
                          )
                          (then
                           (drop
                            (ref.as_non_null
                             (global.get $global478)
                            )
                           )
                           (if (result i32)
                            (call $function137
                             (global.get $string14)
                            )
                            (then
                             (drop
                              (ref.as_non_null
                               (global.get $global478)
                              )
                             )
                             (call $function137
                              (global.get $string13)
                             )
                            )
                            (else
                             (i32.const 0)
                            )
                           )
                          )
                          (else
                           (i32.const 0)
                          )
                         )
                        )
                        (else
                         (i32.const 0)
                        )
                       )
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
              (else
               (i32.const 0)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
 )
 (func $export1 (result i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready508)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global508)
   )
  )
  (i64.const 1)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global461
   (struct.new_default $type11)
  )
  (global.set $global463
   (struct.new_default $type38)
  )
  (global.set $ready463
   (i32.const 1)
  )
  (global.set $global466
   (struct.new_default $type41)
  )
  (global.set $ready466
   (i32.const 1)
  )
  (global.set $global474
   (struct.new_default $type42)
  )
  (global.set $global61
   (struct.new_default $type43)
  )
  (global.set $global81
   (struct.new_default $type47)
  )
  (global.set $global88
   (struct.new_default $type48)
  )
  (global.set $global103
   (struct.new_default $type53)
  )
  (global.set $global109
   (struct.new_default $type54)
  )
  (global.set $global111
   (struct.new_default $type55)
  )
  (global.set $global114
   (struct.new_default $type57)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global135
   (struct.new_default $type58)
  )
  (global.set $global131
   (struct.new_default $type61)
  )
  (global.set $global145
   (struct.new_default $type63)
  )
  (global.set $global246
   (struct.new_default $type81)
  )
  (global.set $global258
   (struct.new_default $type84)
  )
  (global.set $global260
   (struct.new_default $type85)
  )
  (global.set $global270
   (struct.new_default $type67)
  )
  (global.set $global275
   (struct.new_default $type43)
  )
  (global.set $global296
   (struct.new_default $type89)
  )
  (global.set $global299
   (struct.new_default $type90)
  )
  (global.set $global305
   (struct.new_default $type91)
  )
  (global.set $global308
   (struct.new_default $type96)
  )
  (global.set $global313
   (struct.new_default $type97)
  )
  (global.set $global325
   (struct.new_default $type98)
  )
  (global.set $global332
   (struct.new_default $type99)
  )
  (global.set $global340
   (struct.new_default $type100)
  )
  (global.set $global347
   (struct.new_default $type105)
  )
  (global.set $global351
   (struct.new_default $type106)
  )
  (global.set $global354
   (struct.new $type107
    (ref.func $function105)
   )
  )
  (global.set $global356
   (struct.new $type107
    (ref.func $function106)
   )
  )
  (global.set $global361
   (struct.new_default $type108)
  )
  (global.set $global364
   (struct.new_default $type109)
  )
  (global.set $global378
   (struct.new_default $type110)
  )
  (global.set $global380
   (struct.new_default $type110)
  )
  (global.set $global382
   (struct.new_default $type110)
  )
  (global.set $global384
   (struct.new_default $type111)
  )
  (global.set $global397
   (struct.new_default $type112)
  )
  (global.set $global401
   (struct.new_default $type109)
  )
  (global.set $global406
   (struct.new_default $type106)
  )
  (global.set $ready406
   (i32.const 1)
  )
  (global.set $global409
   (struct.new_default $type106)
  )
  (global.set $ready409
   (i32.const 1)
  )
  (global.set $global413
   (struct.new_default $type113)
  )
  (global.set $ready413
   (i32.const 1)
  )
  (global.set $global417
   (struct.new_default $type111)
  )
  (global.set $ready417
   (i32.const 1)
  )
  (global.set $global429
   (struct.new_default $type114)
  )
  (global.set $ready429
   (i32.const 1)
  )
  (global.set $global437
   (struct.new_default $type115)
  )
  (global.set $ready437
   (i32.const 1)
  )
  (global.set $global444
   (struct.new_default $type8)
  )
  (global.set $global449
   (struct.new_default $type8)
  )
  (global.set $global457
   (struct.new_default $type8)
  )
  (global.set $global478
   (struct.new_default $type83)
  )
  (global.set $global486
   (struct.new_default $type83)
  )
  (global.set $global491
   (struct.new_default $type83)
  )
  (global.set $global499
   (struct.new_default $type83)
  )
  (global.set $global504
   (struct.new_default $type8)
  )
  (global.set $global507
   (struct.new_default $type5)
  )
  (global.set $global508
   (struct.new_default $type5)
  )
  (global.set $ready508
   (i32.const 1)
  )
  (global.set $global509
   (struct.new_default $type67)
  )
  (global.set $ready509
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

