(module
 (rec
  (type $type175 (sub (struct)))
  (type $type181 (sub (struct (field i32))))
  (type $type163 (sub (struct (field i32))))
  (type $type130 (sub (struct)))
  (type $type101 (sub (struct (field i32))))
  (type $type13 (sub (struct (field i32))))
  (type $type92 (sub (struct (field i32))))
  (type $type24 (sub (struct (field i32))))
  (type $type28 (sub (struct)))
  (type $9 (func (param (ref $type121) i32 i32 i64) (result i64)))
  (type $10 (func (param (ref $type36) i32 i32 i64) (result i32)))
  (type $11 (func (param (ref $type34) i32 i32 i64) (result i32)))
  (type $call203 (func (param (ref $type13)) (result i32)))
  (type $13 (func (param (ref $type18) i32 i32 i64) (result i32)))
  (type $call116 (func (param (ref $type18)) (result i32)))
  (type $call199 (func (param (ref null $type12) (ref $type36) i64) (result (ref $type101))))
  (type $16 (func (param (ref $type34) i32 i32 (ref null $type12) i64) (result (ref $type34))))
  (type $17 (func (param i32 i32 (ref null $type12) i64) (result i64)))
  (type $call38 (func (param (ref null $type12)) (result (ref $type34))))
  (type $19 (func (param i32 i32 (ref null $type12) (ref $type12)) (result (ref null $type12))))
  (type $call195 (func (param (ref null $type12) (ref $type31)) (result (ref $type13))))
  (type $type12 (struct (field (ref $type13)) (field (ref null $type12))))
  (type $22 (func (param (ref $type121) i64 (ref null $type12)) (result (ref $type101))))
  (type $call190 (func (param (ref $type121) (ref $type163)) (result (ref $type101))))
  (type $24 (func (param (ref $type18) i32 i32 i64 i64) (result (ref $type181))))
  (type $25 (func (param (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $26 (func (param (ref $type121) (ref $type154) i32 i32) (result (ref $type18))))
  (type $call152 (func (param i64) (result i32)))
  (type $call161 (func (param (ref $type121) i64) (result i32)))
  (type $29 (func (param (ref $type154) i32)))
  (type $call186 (func (param (ref $type121) i64) (result (ref $type181))))
  (type $call188 (func (param (ref $type121) i64 i64) (result (ref $type181))))
  (type $call178 (func (param (ref $type121) i32 (ref $type154)) (result (ref $type175))))
  (type $type177 (sub $type175 (struct (field (ref $type18)))))
  (type $type176 (sub $type175 (struct (field (ref $type18)))))
  (type $call173 (func (param (ref $type121) i32 i32) (result (ref $type163))))
  (type $call123 (func (param (ref $type121)) (result i32)))
  (type $call128 (func (param (ref $type121)) (result i64)))
  (type $type184 (sub $type181 (struct (field i32) (field (ref $type18)))))
  (type $type182 (sub $type181 (struct (field i32) (field i32))))
  (type $type156 (struct (field (mut i64))))
  (type $type155 (struct (field (mut (ref $type18)))))
  (type $type164 (sub $type163 (struct (field i32) (field (ref $type13)))))
  (type $type170 (sub $type163 (struct (field i32) (field (ref $type18)))))
  (type $type169 (sub $type163 (struct (field i32) (field (ref $type18)))))
  (type $type168 (sub $type163 (struct (field i32) (field i64))))
  (type $type132 (sub $type130 (struct (field i32))))
  (type $type119 (struct (field (mut i32))))
  (type $type121 (struct (field (ref $type119))))
  (type $type154 (struct (field (ref $type155)) (field (ref $type156))))
  (type $call162 (func (param (ref $type121)) (result (ref $type163))))
  (type $type104 (sub $type101 (struct (field i32) (field (ref $type18)))))
  (type $type103 (sub $type101 (struct (field i32) (field (ref $type13)))))
  (type $call147 (func (param (ref $type101)) (result (ref $type13))))
  (type $54 (func (param (ref $type18) i64 i32 i32 i64) (result i32)))
  (type $55 (func (param (ref $type18)) (result i32)))
  (type $56 (func (param (ref $type36) (ref $type36) i64 i32 i32 i64) (result i32)))
  (type $57 (func (param (ref $type34) (ref $type34) i64 i32 i32 i64) (result i32)))
  (type $type32 (struct (field (mut (ref $type13)))))
  (type $type22 (struct (field i32)))
  (type $type34 (array (mut (ref $type13))))
  (type $call111 (func (param (ref $type13) (ref $type13)) (result i32)))
  (type $type35 (sub $type13 (struct (field i32) (field (ref $type36)))))
  (type $type33 (sub $type13 (struct (field i32) (field (ref $type34)))))
  (type $type31 (sub $type13 (struct (field i32) (field (ref $type32)) (field (ref $type32)))))
  (type $type23 (sub $type13 (struct (field i32) (field (ref $type24)))))
  (type $type21 (sub $type13 (struct (field i32) (field (ref $type22)))))
  (type $type17 (sub $type13 (struct (field i32) (field (ref $type18)))))
  (type $type16 (sub $type13 (struct (field i32) (field i32))))
  (type $type15 (sub $type13 (struct (field i32) (field i32))))
  (type $call109 (func (param (ref $type13)) (result i64)))
  (type $call99 (func (param (ref $type24) (ref $type24)) (result i32)))
  (type $call97 (func (param (ref $type28) (ref $type28)) (result i32)))
  (type $type95 (sub $type92 (struct (field i32) (field (ref $type18)))))
  (type $type27 (sub $type24 (struct (field i32) (field (ref $type28)) (field (ref $type28)))))
  (type $type30 (sub $type28 (struct (field f64))))
  (type $type29 (sub $type28 (struct (field i64))))
  (type $type26 (sub $type24 (struct (field i32) (field f64))))
  (type $type94 (sub $type92 (struct (field i32) (field (ref $type24)))))
  (type $type25 (sub $type24 (struct (field i32) (field i64))))
  (type $call91 (func (param i32 i32) (result (ref $type92))))
  (type $81 (func (param i32 i64 (ref $type18) i32 i32 i64) (result (ref $type18))))
  (type $82 (func (param (ref $type18) i32 i64 i32 i32 i64) (result i32)))
  (type $call81 (func (param (ref $type18)) (result i32)))
  (type $84 (func (param (ref $type36) i32 i32 (ref null $type56) i64) (result (ref $type36))))
  (type $85 (func (param i32 i32 (ref null $type56) i64) (result i64)))
  (type $type37 (array (mut i8)))
  (type $type36 (struct (field (ref $type37))))
  (type $type56 (struct (field i64) (field (ref null $type56))))
  (type $call55 (func (param (ref $type56)) (result (ref $type36))))
  (type $90 (func (param (ref $type18) (ref $type18) i32 i32 i64) (result i32)))
  (type $call52 (func (param (ref $type18) (ref null $type50) i64) (result i32)))
  (type $92 (func (param i32 i32 (ref null $type50) i64) (result i64)))
  (type $type50 (struct (field (ref $type18)) (field (ref null $type50))))
  (type $call49 (func (param (ref $type50)) (result (ref $type18))))
  (type $95 (func (param (ref $type18) i64 (ref $type18) i64)))
  (type $96 (func (param (ref $type18) i32) (result (ref $type19))))
  (type $type20 (array (mut (ref null $type19))))
  (type $98 (func (param i32) (result (ref $type18))))
  (type $type205 (struct))
  (type $type204 (struct))
  (type $type202 (struct))
  (type $type5 (struct))
  (type $type8 (struct))
  (type $type198 (struct))
  (type $type197 (struct))
  (type $type196 (struct))
  (type $type194 (struct))
  (type $type193 (struct))
  (type $type191 (struct))
  (type $type189 (struct))
  (type $type185 (struct))
  (type $type180 (struct))
  (type $type179 (struct))
  (type $type174 (struct))
  (type $type172 (struct))
  (type $type171 (struct))
  (type $type158 (struct))
  (type $type127 (struct))
  (type $type125 (struct))
  (type $type115 (struct))
  (type $type114 (struct))
  (type $type110 (struct))
  (type $type108 (struct))
  (type $type105 (struct))
  (type $type100 (struct))
  (type $type90 (struct))
  (type $type88 (struct))
  (type $type57 (struct))
  (type $type51 (struct))
  (type $type42 (struct))
  (type $type41 (struct))
  (type $type201 (struct))
  (type $type199 (struct))
  (type $type188 (struct))
  (type $type187 (struct))
  (type $type67 (struct))
  (type $type186 (struct))
  (type $type178 (struct))
  (type $type173 (struct))
  (type $type159 (struct))
  (type $type152 (struct))
  (type $type146 (struct))
  (type $type124 (struct))
  (type $type123 (struct))
  (type $type120 (struct))
  (type $type98 (struct))
  (type $type97 (struct))
  (type $type89 (struct))
  (type $type87 (struct))
  (type $type54 (struct))
  (type $type49 (struct))
  (type $type11 (struct))
  (type $type116 (struct))
  (type $type192 (struct))
  (type $type160 (struct))
  (type $type109 (struct))
  (type $type107 (struct))
  (type $type85 (struct))
  (type $type55 (struct))
  (type $type48 (struct))
  (type $type38 (struct))
  (type $type161 (struct))
  (type $type153 (struct))
  (type $type147 (struct))
  (type $type86 (struct))
  (type $type84 (struct))
  (type $type82 (struct))
  (type $type47 (struct))
  (type $type157 (struct))
  (type $type99 (struct))
  (type $type151 (struct))
  (type $type52 (struct))
  (type $type203 (struct))
  (type $type128 (struct))
  (type $type148 (struct))
  (type $type200 (struct))
  (type $type195 (struct))
  (type $type190 (struct))
  (type $type96 (struct))
  (type $type111 (struct))
  (type $type91 (struct))
  (type $type162 (struct))
  (type $type106 (struct))
  (type $type43 (struct))
  (type $type134 (struct))
  (type $type149 (struct))
  (type $type53 (struct))
  (type $type81 (struct))
  (type $type133 (struct))
  (type $type150 (struct))
  (type $type183 (sub $type181 (struct (field i32))))
  (type $type167 (sub $type163 (struct (field i32))))
  (type $type166 (sub $type163 (struct (field i32))))
  (type $type165 (sub $type163 (struct (field i32))))
  (type $type102 (sub $type101 (struct (field i32))))
  (type $type93 (sub $type92 (struct (field i32))))
  (type $type14 (sub $type13 (struct (field i32))))
  (type $type18 (struct (field i32) (field i32) (field (ref $type19)) (field (ref null $type20))))
  (type $type19 (array (mut i32)))
  (type $type131 (sub $type130 (struct)))
 )
 (type $201 (func (param i32) (result i32)))
 (type $202 (func (param i32)))
 (type $203 (func (result i32)))
 (type $204 (func (param i32 i32) (result i32)))
 (type $205 (func))
 (type $206 (func (result i64)))
 (type $207 (func (param i32 i32)))
 (type $208 (func (param i32) (result i64)))
 (type $209 (func (param i32 i32) (result f64)))
 (type $210 (func (param i32 i32) (result i64)))
 (type $211 (func (param f64 f64) (result i32)))
 (type $212 (func (param i64)))
 (type $213 (func (param f64)))
 (import "snail.library" "snail:datum/token-open" (func $foreign0 (result i32)))
 (import "snail.library" "snail:datum/token-character" (func $foreign1 (param i32 i32)))
 (import "snail.library" "snail:datum/fail" (func $foreign2 (param i32)))
 (import "snail.library" "snail:datum/token-identifier" (func $foreign3 (param i32) (result i32)))
 (import "snail.library" "snail:datum/token-close" (func $foreign4 (param i32)))
 (import "snail.library" "snail:datum/token-intern" (func $foreign5 (param i32) (result i32)))
 (import "snail.library" "snail:datum/symbol-length" (func $foreign6 (param i32) (result i64)))
 (import "snail.library" "snail:datum/symbol-character" (func $foreign7 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/number-real" (func $foreign8 (param i32 i32) (result f64)))
 (import "snail.library" "snail:datum/number-integer" (func $foreign9 (param i32 i32) (result i64)))
 (import "snail.library" "snail:datum/number-kind" (func $foreign10 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/error-length" (func $foreign11 (param i32) (result i32)))
 (import "snail.library" "snail:datum/error-character" (func $foreign12 (param i32 i32) (result i32)))
 (import "snail.library" "snail:datum/token-parse" (func $foreign13 (param i32) (result i32)))
 (import "snail.library" "snail:datum/real-equivalent" (func $foreign14 (param f64 f64) (result i32)))
 (import "snail.library" "snail:io/path-begin" (func $foreign15))
 (import "snail.library" "snail:io/path-character" (func $foreign16 (param i32)))
 (import "snail.library" "snail:io/open-input-file" (func $foreign20 (result i32)))
 (import "snail.library" "snail:io/close" (func $foreign21 (param i32)))
 (import "snail.library" "snail:io/read-character" (func $foreign22 (param i32) (result i32)))
 (import "snail.library" "snail:io/peek-character" (func $foreign23 (param i32) (result i32)))
 (import "snail.library" "snail:datum/whitespace" (func $foreign25 (param i32) (result i32)))
 (import "reader.test" "emit_i64" (func $foreign26 (param i64)))
 (import "reader.test" "emit_char" (func $foreign27 (param i32)))
 (import "reader.test" "emit_f64" (func $foreign28 (param f64)))
 (global $global538 (mut (ref null $type150)) (ref.null none))
 (global $global468 (mut (ref null $type133)) (ref.null none))
 (global $empty131 (ref $type131) (struct.new_default $type131))
 (global $global246 (mut (ref null $type81)) (ref.null none))
 (global $global103 (mut (ref null $type53)) (ref.null none))
 (global $global532 (mut (ref null $type149)) (ref.null none))
 (global $global470 (mut (ref null $type134)) (ref.null none))
 (global $global61 (mut (ref null $type43)) (ref.null none))
 (global $global351 (mut (ref null $type106)) (ref.null none))
 (global $global527 (mut (ref null $type162)) (ref.null none))
 (global $global305 (mut (ref null $type91)) (ref.null none))
 (global $global417 (mut (ref null $type111)) (ref.null none))
 (global $global308 (mut (ref null $type96)) (ref.null none))
 (global $ready527 (mut i32) (i32.const 0))
 (global $global702 (mut (ref null $type190)) (ref.null none))
 (global $global718 (mut (ref null $type195)) (ref.null none))
 (global $global786 (mut (ref null $type200)) (ref.null none))
 (global $global472 (mut (ref null $type134)) (ref.null none))
 (global $global525 (mut (ref null $type148)) (ref.null none))
 (global $global552 (mut (ref null $type128)) (ref.null none))
 (global $global530 (mut (ref null $type128)) (ref.null none))
 (global $ready702 (mut i32) (i32.const 0))
 (global $ready718 (mut i32) (i32.const 0))
 (global $global835 (mut (ref null $type203)) (ref.null none))
 (global $global98 (mut (ref null $type52)) (ref.null none))
 (global $ready98 (mut i32) (i32.const 0))
 (global $global549 (mut (ref null $type151)) (ref.null none))
 (global $global332 (mut (ref null $type99)) (ref.null none))
 (global $global611 (mut (ref null $type157)) (ref.null none))
 (global $execution (mut i32) (i32.const 0))
 (global $global81 (mut (ref null $type47)) (ref.null none))
 (global $global252 (mut (ref null $type82)) (ref.null none))
 (global $global258 (mut (ref null $type84)) (ref.null none))
 (global $global263 (mut (ref null $type86)) (ref.null none))
 (global $global520 (mut (ref null $type147)) (ref.null none))
 (global $global562 (mut (ref null $type153)) (ref.null none))
 (global $global635 (mut (ref null $type161)) (ref.null none))
 (global $global726 (mut (ref null $type38)) (ref.null none))
 (global $global88 (mut (ref null $type48)) (ref.null none))
 (global $global111 (mut (ref null $type55)) (ref.null none))
 (global $global260 (mut (ref null $type85)) (ref.null none))
 (global $global354 (mut (ref null $type107)) (ref.null none))
 (global $global364 (mut (ref null $type109)) (ref.null none))
 (global $global658 (mut (ref null $type160)) (ref.null none))
 (global $ready635 (mut i32) (i32.const 0))
 (global $global709 (mut (ref null $type192)) (ref.null none))
 (global $global819 (mut (ref null $type116)) (ref.null none))
 (global $string52 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 49)
  )
  (ref.null none)
 ))
 (global $empty14 (ref $type14) (struct.new $type14
  (i32.const 0)
 ))
 (global $global795 (mut (ref null $type11)) (ref.null none))
 (global $ready726 (mut i32) (i32.const 0))
 (global $global90 (mut (ref null $type49)) (ref.null none))
 (global $global109 (mut (ref null $type54)) (ref.null none))
 (global $global284 (mut (ref null $type87)) (ref.null none))
 (global $global296 (mut (ref null $type89)) (ref.null none))
 (global $global313 (mut (ref null $type97)) (ref.null none))
 (global $global325 (mut (ref null $type98)) (ref.null none))
 (global $global356 (mut (ref null $type107)) (ref.null none))
 (global $ready417 (mut i32) (i32.const 0))
 (global $global444 (mut (ref null $type116)) (ref.null none))
 (global $global455 (mut (ref null $type120)) (ref.null none))
 (global $global462 (mut (ref null $type123)) (ref.null none))
 (global $global459 (mut (ref null $type124)) (ref.null none))
 (global $ready459 (mut i32) (i32.const 0))
 (global $global515 (mut (ref null $type146)) (ref.null none))
 (global $global536 (mut (ref null $type152)) (ref.null none))
 (global $global643 (mut (ref null $type152)) (ref.null none))
 (global $global568 (mut (ref null $type159)) (ref.null none))
 (global $global666 (mut (ref null $type48)) (ref.null none))
 (global $global541 (mut (ref null $type123)) (ref.null none))
 (global $global554 (mut (ref null $type173)) (ref.null none))
 (global $ready554 (mut i32) (i32.const 0))
 (global $global563 (mut (ref null $type178)) (ref.null none))
 (global $ready563 (mut i32) (i32.const 0))
 (global $global601 (mut (ref null $type123)) (ref.null none))
 (global $global596 (mut (ref null $type186)) (ref.null none))
 (global $ready596 (mut i32) (i32.const 0))
 (global $global588 (mut (ref null $type67)) (ref.null none))
 (global $global584 (mut (ref null $type152)) (ref.null none))
 (global $global581 (mut (ref null $type187)) (ref.null none))
 (global $global576 (mut (ref null $type188)) (ref.null none))
 (global $ready576 (mut i32) (i32.const 0))
 (global $ready709 (mut i32) (i32.const 0))
 (global $global743 (mut (ref null $type199)) (ref.null none))
 (global $ready743 (mut i32) (i32.const 0))
 (global $global823 (mut (ref null $type201)) (ref.null none))
 (global $ready835 (mut i32) (i32.const 0))
 (global $string12 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 85)
   (i32.const 110)
   (i32.const 105)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $global729 (mut (ref null $type41)) (ref.null none))
 (global $ready729 (mut i32) (i32.const 0))
 (global $global797 (mut (ref null $type42)) (ref.null none))
 (global $global93 (mut (ref null $type51)) (ref.null none))
 (global $ready93 (mut i32) (i32.const 0))
 (global $global114 (mut (ref null $type57)) (ref.null none))
 (global $ready114 (mut i32) (i32.const 0))
 (global $global289 (mut (ref null $type88)) (ref.null none))
 (global $global299 (mut (ref null $type90)) (ref.null none))
 (global $global340 (mut (ref null $type100)) (ref.null none))
 (global $global347 (mut (ref null $type105)) (ref.null none))
 (global $global358 (mut (ref null $type108)) (ref.null none))
 (global $global361 (mut (ref null $type108)) (ref.null none))
 (global $global376 (mut (ref null $type110)) (ref.null none))
 (global $global429 (mut (ref null $type114)) (ref.null none))
 (global $ready429 (mut i32) (i32.const 0))
 (global $global437 (mut (ref null $type115)) (ref.null none))
 (global $ready437 (mut i32) (i32.const 0))
 (global $global814 (mut (ref null $type125)) (ref.null none))
 (global $global862 (mut (ref null $type127)) (ref.null none))
 (global $global615 (mut (ref null $type158)) (ref.null none))
 (global $ready615 (mut i32) (i32.const 0))
 (global $ready541 (mut i32) (i32.const 0))
 (global $global630 (mut (ref null $type162)) (ref.null none))
 (global $global546 (mut (ref null $type171)) (ref.null none))
 (global $ready546 (mut i32) (i32.const 0))
 (global $global627 (mut (ref null $type162)) (ref.null none))
 (global $ready627 (mut i32) (i32.const 0))
 (global $global684 (mut (ref null $type162)) (ref.null none))
 (global $ready684 (mut i32) (i32.const 0))
 (global $global686 (mut (ref null $type172)) (ref.null none))
 (global $ready686 (mut i32) (i32.const 0))
 (global $global697 (mut (ref null $type172)) (ref.null none))
 (global $ready697 (mut i32) (i32.const 0))
 (global $global559 (mut (ref null $type174)) (ref.null none))
 (global $ready559 (mut i32) (i32.const 0))
 (global $global621 (mut (ref null $type179)) (ref.null none))
 (global $ready621 (mut i32) (i32.const 0))
 (global $global604 (mut (ref null $type180)) (ref.null none))
 (global $ready604 (mut i32) (i32.const 0))
 (global $global570 (mut (ref null $type185)) (ref.null none))
 (global $ready570 (mut i32) (i32.const 0))
 (global $global591 (mut (ref null $type152)) (ref.null none))
 (global $ready591 (mut i32) (i32.const 0))
 (global $ready601 (mut i32) (i32.const 0))
 (global $global674 (mut (ref null $type189)) (ref.null none))
 (global $global640 (mut (ref null $type162)) (ref.null none))
 (global $ready640 (mut i32) (i32.const 0))
 (global $global663 (mut (ref null $type172)) (ref.null none))
 (global $ready663 (mut i32) (i32.const 0))
 (global $global672 (mut (ref null $type189)) (ref.null none))
 (global $ready672 (mut i32) (i32.const 0))
 (global $global780 (mut (ref null $type191)) (ref.null none))
 (global $ready780 (mut i32) (i32.const 0))
 (global $global770 (mut (ref null $type193)) (ref.null none))
 (global $ready770 (mut i32) (i32.const 0))
 (global $global756 (mut (ref null $type194)) (ref.null none))
 (global $ready756 (mut i32) (i32.const 0))
 (global $global721 (mut (ref null $type196)) (ref.null none))
 (global $global715 (mut (ref null $type197)) (ref.null none))
 (global $ready715 (mut i32) (i32.const 0))
 (global $global737 (mut (ref null $type198)) (ref.null none))
 (global $ready737 (mut i32) (i32.const 0))
 (global $global748 (mut (ref null $type109)) (ref.null none))
 (global $global788 (mut (ref null $type8)) (ref.null none))
 (global $global801 (mut (ref null $type5)) (ref.null none))
 (global $ready801 (mut i32) (i32.const 0))
 (global $global805 (mut (ref null $type8)) (ref.null none))
 (global $ready805 (mut i32) (i32.const 0))
 (global $global828 (mut (ref null $type202)) (ref.null none))
 (global $global846 (mut (ref null $type204)) (ref.null none))
 (global $ready846 (mut i32) (i32.const 0))
 (global $global851 (mut (ref null $type205)) (ref.null none))
 (global $ready851 (mut i32) (i32.const 0))
 (global $global855 (mut (ref null $type5)) (ref.null none))
 (global $ready855 (mut i32) (i32.const 0))
 (global $string0 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 42)
  (array.new_fixed $type19 42
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 45)
   (i32.const 62)
   (i32.const 102)
   (i32.const 54)
   (i32.const 52)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 108)
   (i32.const 45)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 117)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string1 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 71)
  (array.new_fixed $type19 71
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 102)
   (i32.const 105)
   (i32.const 101)
   (i32.const 114)
   (i32.const 59)
   (i32.const 32)
   (i32.const 114)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 98)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string2 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
  )
  (ref.null none)
 ))
 (global $string3 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 44)
  (array.new_fixed $type19 44
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 44)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 102)
   (i32.const 105)
   (i32.const 108)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string4 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 105)
   (i32.const 109)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string5 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string6 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 16)
  (array.new_fixed $type19 16
   (i32.const 117)
   (i32.const 110)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 45)
   (i32.const 115)
   (i32.const 112)
   (i32.const 108)
   (i32.const 105)
   (i32.const 99)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
  )
  (ref.null none)
 ))
 (global $string7 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 10)
  (array.new_fixed $type19 10
   (i32.const 113)
   (i32.const 117)
   (i32.const 97)
   (i32.const 115)
   (i32.const 105)
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string8 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string9 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 109)
   (i32.const 98)
   (i32.const 111)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string10 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string11 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 104)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 99)
   (i32.const 105)
   (i32.const 109)
   (i32.const 97)
   (i32.const 108)
   (i32.const 32)
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string13 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 115)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 105)
   (i32.const 110)
   (i32.const 117)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string14 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 58)
   (i32.const 32)
   (i32.const 116)
   (i32.const 111)
   (i32.const 107)
   (i32.const 101)
   (i32.const 110)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 99)
   (i32.const 101)
   (i32.const 101)
   (i32.const 100)
   (i32.const 115)
   (i32.const 32)
   (i32.const 83)
   (i32.const 116)
   (i32.const 114)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 105)
   (i32.const 116)
   (i32.const 121)
  )
  (ref.null none)
 ))
 (global $string15 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 35)
  )
  (ref.null none)
 ))
 (global $string16 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 108)
   (i32.const 97)
   (i32.const 98)
   (i32.const 101)
   (i32.const 108)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string17 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 114)
   (i32.const 101)
   (i32.const 97)
   (i32.const 100)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 97)
   (i32.const 115)
   (i32.const 101)
   (i32.const 32)
   (i32.const 100)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 105)
   (i32.const 118)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 32)
   (i32.const 110)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
  )
  (ref.null none)
 ))
 (global $string18 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 26)
  (array.new_fixed $type19 26
   (i32.const 117)
   (i32.const 110)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 109)
   (i32.const 105)
   (i32.const 110)
   (i32.const 97)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 98)
   (i32.const 108)
   (i32.const 111)
   (i32.const 99)
   (i32.const 107)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string19 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string20 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string21 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 28)
  (array.new_fixed $type19 28
   (i32.const 105)
   (i32.const 110)
   (i32.const 99)
   (i32.const 111)
   (i32.const 109)
   (i32.const 112)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string22 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 25)
  (array.new_fixed $type19 25
   (i32.const 117)
   (i32.const 110)
   (i32.const 107)
   (i32.const 110)
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 97)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string23 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 116)
   (i32.const 97)
   (i32.const 98)
  )
  (ref.null none)
 ))
 (global $string24 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string25 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 114)
   (i32.const 101)
   (i32.const 116)
   (i32.const 117)
   (i32.const 114)
   (i32.const 110)
  )
  (ref.null none)
 ))
 (global $string26 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 110)
   (i32.const 117)
   (i32.const 108)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string27 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 7)
  (array.new_fixed $type19 7
   (i32.const 110)
   (i32.const 101)
   (i32.const 119)
   (i32.const 108)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string28 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 101)
   (i32.const 115)
   (i32.const 99)
   (i32.const 97)
   (i32.const 112)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string29 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 100)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 116)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string30 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 98)
   (i32.const 97)
   (i32.const 99)
   (i32.const 107)
   (i32.const 115)
   (i32.const 112)
   (i32.const 97)
   (i32.const 99)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string31 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 97)
   (i32.const 108)
   (i32.const 97)
   (i32.const 114)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string32 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 22)
  (array.new_fixed $type19 22
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 104)
   (i32.const 97)
   (i32.const 114)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 100)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string33 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 31)
  (array.new_fixed $type19 31
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 117)
   (i32.const 56)
   (i32.const 40)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string34 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 39)
  (array.new_fixed $type19 39
   (i32.const 105)
   (i32.const 110)
   (i32.const 118)
   (i32.const 97)
   (i32.const 108)
   (i32.const 105)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 117)
   (i32.const 110)
   (i32.const 115)
   (i32.const 117)
   (i32.const 112)
   (i32.const 112)
   (i32.const 111)
   (i32.const 114)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 35)
   (i32.const 32)
   (i32.const 110)
   (i32.const 117)
   (i32.const 109)
   (i32.const 101)
   (i32.const 114)
   (i32.const 105)
   (i32.const 99)
   (i32.const 32)
   (i32.const 115)
   (i32.const 121)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 120)
  )
  (ref.null none)
 ))
 (global $string35 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 102)
  )
  (ref.null none)
 ))
 (global $string36 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 35)
   (i32.const 102)
   (i32.const 97)
   (i32.const 108)
   (i32.const 115)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string37 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 35)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string38 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 5)
  (array.new_fixed $type19 5
   (i32.const 35)
   (i32.const 116)
   (i32.const 114)
   (i32.const 117)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string39 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 1)
  (array.new_fixed $type19 1
   (i32.const 46)
  )
  (ref.null none)
 ))
 (global $string40 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 14)
  (array.new_fixed $type19 14
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string41 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 30)
  (array.new_fixed $type19 30
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 112)
   (i32.const 97)
   (i32.const 114)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
   (i32.const 104)
   (i32.const 101)
   (i32.const 115)
   (i32.const 105)
   (i32.const 115)
  )
  (ref.null none)
 ))
 (global $string42 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 37)
  (array.new_fixed $type19 37
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 112)
   (i32.const 114)
   (i32.const 101)
   (i32.const 99)
   (i32.const 101)
   (i32.const 100)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
   (i32.const 32)
   (i32.const 101)
   (i32.const 108)
   (i32.const 101)
   (i32.const 109)
   (i32.const 101)
   (i32.const 110)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string43 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 40)
  (array.new_fixed $type19 40
   (i32.const 117)
   (i32.const 110)
   (i32.const 101)
   (i32.const 120)
   (i32.const 112)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 101)
   (i32.const 110)
   (i32.const 100)
   (i32.const 32)
   (i32.const 111)
   (i32.const 102)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 115)
   (i32.const 105)
   (i32.const 100)
   (i32.const 101)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
  )
  (ref.null none)
 ))
 (global $string44 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 42)
  (array.new_fixed $type19 42
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 118)
   (i32.const 101)
   (i32.const 99)
   (i32.const 116)
   (i32.const 111)
   (i32.const 114)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 101)
   (i32.const 120)
   (i32.const 97)
   (i32.const 99)
   (i32.const 116)
   (i32.const 32)
   (i32.const 98)
   (i32.const 121)
   (i32.const 116)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 105)
   (i32.const 110)
   (i32.const 32)
   (i32.const 91)
   (i32.const 48)
   (i32.const 44)
   (i32.const 50)
   (i32.const 53)
   (i32.const 53)
   (i32.const 93)
  )
  (ref.null none)
 ))
 (global $string45 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 109)
   (i32.const 105)
   (i32.const 115)
   (i32.const 115)
   (i32.const 105)
   (i32.const 110)
   (i32.const 103)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string46 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 36)
  (array.new_fixed $type19 36
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string47 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 33)
  (array.new_fixed $type19 33
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 99)
   (i32.const 111)
   (i32.const 110)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string48 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 27)
  (array.new_fixed $type19 27
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string49 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 117)
   (i32.const 110)
   (i32.const 99)
   (i32.const 108)
   (i32.const 111)
   (i32.const 115)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 108)
   (i32.const 105)
   (i32.const 115)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string50 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 29)
  (array.new_fixed $type19 29
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
   (i32.const 114)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
   (i32.const 32)
   (i32.const 97)
   (i32.const 102)
   (i32.const 116)
   (i32.const 101)
   (i32.const 114)
   (i32.const 32)
   (i32.const 100)
   (i32.const 111)
   (i32.const 116)
   (i32.const 116)
   (i32.const 101)
   (i32.const 100)
   (i32.const 32)
   (i32.const 116)
   (i32.const 97)
   (i32.const 105)
   (i32.const 108)
  )
  (ref.null none)
 ))
 (global $string51 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 35)
  (array.new_fixed $type19 35
   (i32.const 113)
   (i32.const 117)
   (i32.const 111)
   (i32.const 116)
   (i32.const 101)
   (i32.const 32)
   (i32.const 97)
   (i32.const 98)
   (i32.const 98)
   (i32.const 114)
   (i32.const 101)
   (i32.const 118)
   (i32.const 105)
   (i32.const 97)
   (i32.const 116)
   (i32.const 105)
   (i32.const 111)
   (i32.const 110)
   (i32.const 32)
   (i32.const 114)
   (i32.const 101)
   (i32.const 113)
   (i32.const 117)
   (i32.const 105)
   (i32.const 114)
   (i32.const 101)
   (i32.const 115)
   (i32.const 32)
   (i32.const 97)
   (i32.const 32)
   (i32.const 100)
   (i32.const 97)
   (i32.const 116)
   (i32.const 117)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string53 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 2)
  (array.new_fixed $type19 2
   (i32.const 955)
   (i32.const 128512)
  )
  (ref.null none)
 ))
 (global $string54 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 49)
   (i32.const 50)
   (i32.const 46)
   (i32.const 53)
  )
  (ref.null none)
 ))
 (global $string55 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 49)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string56 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 43)
   (i32.const 110)
   (i32.const 97)
   (i32.const 110)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string57 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 6)
  (array.new_fixed $type19 6
   (i32.const 45)
   (i32.const 110)
   (i32.const 97)
   (i32.const 110)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string58 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 3)
  (array.new_fixed $type19 3
   (i32.const 48)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string59 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 45)
   (i32.const 48)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string60 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 49)
   (i32.const 43)
   (i32.const 48)
   (i32.const 105)
  )
  (ref.null none)
 ))
 (global $string61 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 19)
  (array.new_fixed $type19 19
   (i32.const 35)
   (i32.const 120)
   (i32.const 45)
   (i32.const 56)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string62 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 20)
  (array.new_fixed $type19 20
   (i32.const 35)
   (i32.const 101)
   (i32.const 57)
   (i32.const 48)
   (i32.const 48)
   (i32.const 55)
   (i32.const 49)
   (i32.const 57)
   (i32.const 57)
   (i32.const 50)
   (i32.const 53)
   (i32.const 52)
   (i32.const 55)
   (i32.const 52)
   (i32.const 48)
   (i32.const 57)
   (i32.const 57)
   (i32.const 51)
   (i32.const 46)
   (i32.const 48)
  )
  (ref.null none)
 ))
 (global $string63 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 13)
  (array.new_fixed $type19 13
   (i32.const 111)
   (i32.const 119)
   (i32.const 110)
   (i32.const 101)
   (i32.const 114)
   (i32.const 115)
   (i32.const 104)
   (i32.const 105)
   (i32.const 112)
   (i32.const 46)
   (i32.const 115)
   (i32.const 99)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $string64 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 116)
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string65 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 88)
   (i32.const 101)
   (i32.const 120)
   (i32.const 116)
  )
  (ref.null none)
 ))
 (global $string66 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 4)
  (array.new_fixed $type19 4
   (i32.const 115)
   (i32.const 97)
   (i32.const 109)
   (i32.const 101)
  )
  (ref.null none)
 ))
 (global $string67 (ref $type18) (struct.new $type18
  (i32.const 0)
  (i32.const 9)
  (array.new_fixed $type19 9
   (i32.const 105)
   (i32.const 110)
   (i32.const 112)
   (i32.const 117)
   (i32.const 116)
   (i32.const 46)
   (i32.const 115)
   (i32.const 99)
   (i32.const 109)
  )
  (ref.null none)
 ))
 (global $empty93 (ref $type93) (struct.new $type93
  (i32.const 0)
 ))
 (global $empty102 (ref $type102) (struct.new $type102
  (i32.const 0)
 ))
 (global $empty165 (ref $type165) (struct.new $type165
  (i32.const 1)
 ))
 (global $empty166 (ref $type166) (struct.new $type166
  (i32.const 2)
 ))
 (global $empty167 (ref $type167) (struct.new $type167
  (i32.const 3)
 ))
 (global $empty183 (ref $type183) (struct.new $type183
  (i32.const 1)
 ))
 (export "check" (func $export0))
 (export "scan" (func $export1))
 (export "storage" (func $export2))
 (export "main" (func $main))
 (func $string-new (type $98) (param $0 i32) (result (ref $type18))
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 (ref null $type20))
  (if
   (local.tee $1
    (i32.sub
     (local.get $0)
     (local.tee $3
      (select
       (i32.const 8192)
       (local.get $0)
       (i32.ge_u
        (local.get $0)
        (i32.const 8192)
       )
      )
     )
    )
   )
   (then
    (local.set $5
     (array.new_default $type20
      (i32.shr_u
       (i32.sub
        (local.get $0)
        (i32.const 1)
       )
       (i32.const 13)
      )
     )
    )
    (loop $label
     (array.set $type20
      (local.get $5)
      (local.get $2)
      (array.new_default $type19
       (local.tee $4
        (select
         (i32.const 8192)
         (local.get $1)
         (i32.ge_u
          (local.get $1)
          (i32.const 8192)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label
      (local.tee $1
       (i32.sub
        (local.get $1)
        (local.get $4)
       )
      )
     )
    )
   )
  )
  (struct.new $type18
   (i32.const 1)
   (local.get $0)
   (array.new_default $type19
    (local.get $3)
   )
   (local.get $5)
  )
 )
 (func $string-block (type $96) (param $0 (ref $type18)) (param $1 i32) (result (ref $type19))
  (if (result (ref $type19))
   (i32.lt_u
    (local.get $1)
    (i32.const 8192)
   )
   (then
    (struct.get $type18 2
     (local.get $0)
    )
   )
   (else
    (ref.as_non_null
     (array.get $type20
      (struct.get $type18 3
       (local.get $0)
      )
      (i32.sub
       (i32.shr_u
        (local.get $1)
        (i32.const 13)
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $string-copy (type $95) (param $0 (ref $type18)) (param $1 i64) (param $2 (ref $type18)) (param $3 i64)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (if
   (i32.ne
    (struct.get $type18 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $1)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $2)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.get $3)
    (i64.sub
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $1)
    )
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.and
    (i64.ne
     (local.get $1)
     (i64.const 0)
    )
    (ref.eq
     (local.get $0)
     (local.get $2)
    )
   )
   (then
    (local.set $5
     (i32.add
      (local.tee $7
       (i32.wrap_i64
        (local.get $3)
       )
      )
      (i32.wrap_i64
       (local.get $1)
      )
     )
    )
    (local.set $4
     (local.get $7)
    )
    (loop $label
     (if
      (local.get $7)
      (then
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.sub
            (local.get $5)
            (local.tee $6
             (select
              (local.get $7)
              (local.tee $6
               (select
                (local.tee $5
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $5)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (local.tee $6
                 (i32.add
                  (i32.and
                   (i32.sub
                    (local.get $4)
                    (i32.const 1)
                   )
                   (i32.const 8191)
                  )
                  (i32.const 1)
                 )
                )
                (i32.lt_u
                 (local.get $5)
                 (local.get $6)
                )
               )
              )
              (i32.gt_u
               (local.get $6)
               (local.get $7)
              )
             )
            )
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $4
           (i32.sub
            (local.get $4)
            (local.get $6)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $4)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $4)
         (i32.const 8191)
        )
        (local.get $6)
       )
       (local.set $7
        (i32.sub
         (local.get $7)
         (local.get $6)
        )
       )
       (br $label)
      )
     )
    )
   )
   (else
    (local.set $8
     (i32.wrap_i64
      (local.get $1)
     )
    )
    (local.set $9
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (loop $label1
     (if
      (local.get $9)
      (then
       (local.set $4
        (select
         (local.get $9)
         (local.tee $4
          (select
           (local.tee $6
            (i32.sub
             (i32.const 8192)
             (local.tee $5
              (i32.and
               (local.get $8)
               (i32.const 8191)
              )
             )
            )
           )
           (local.tee $4
            (i32.sub
             (i32.const 8192)
             (local.tee $7
              (i32.and
               (local.get $10)
               (i32.const 8191)
              )
             )
            )
           )
           (i32.gt_u
            (local.get $4)
            (local.get $6)
           )
          )
         )
         (i32.gt_u
          (local.get $4)
          (local.get $9)
         )
        )
       )
       (array.copy $type19 $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $8)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $0)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $0)
            )
            (i32.sub
             (i32.shr_u
              (local.get $8)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $5)
        (if (result (ref $type19))
         (i32.lt_u
          (local.get $10)
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $2)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $2)
            )
            (i32.sub
             (i32.shr_u
              (local.get $10)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (local.get $7)
        (local.get $4)
       )
       (local.set $8
        (i32.add
         (local.get $4)
         (local.get $8)
        )
       )
       (local.set $10
        (i32.add
         (local.get $4)
         (local.get $10)
        )
       )
       (local.set $9
        (i32.sub
         (local.get $9)
         (local.get $4)
        )
       )
       (br $label1)
      )
     )
    )
   )
  )
 )
 (func $function35 (type $call49) (param $0 (ref $type50)) (result (ref $type18))
  (local $1 (ref null $type50))
  (local $2 (ref null $type50))
  (local $3 (ref null $type50))
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 i64)
  (local $7 i64)
  (if
   (i32.eqz
    (global.get $ready93)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global93)
   )
  )
  (local.set $6
   (if (result i64)
    (i64.gt_u
     (local.tee $6
      (i64.extend_i32_u
       (struct.get $type18 1
        (struct.get $type50 0
         (local.get $0)
        )
       )
      )
     )
     (i64.const 4294967294)
    )
    (then
     (unreachable)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type50 1
         (local.get $0)
        )
       )
      )
      (then
       (local.get $6)
      )
      (else
       (local.set $3
        (struct.get $type50 1
         (local.get $1)
        )
       )
       (if (result i64)
        (i64.gt_u
         (local.tee $6
          (i64.add
           (i64.extend_i32_u
            (struct.get $type18 1
             (struct.get $type50 0
              (local.get $1)
             )
            )
           )
           (local.get $6)
          )
         )
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.get $3)
          )
          (then
           (local.get $6)
          )
          (else
           (local.set $2
            (struct.get $type50 1
             (local.get $3)
            )
           )
           (if (result i64)
            (i64.gt_s
             (local.tee $6
              (i64.add
               (i64.extend_i32_u
                (struct.get $type18 1
                 (struct.get $type50 0
                  (local.get $3)
                 )
                )
               )
               (local.get $6)
              )
             )
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.get $2)
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $1
                (struct.get $type50 1
                 (local.get $2)
                )
               )
               (if (result i64)
                (i64.gt_s
                 (local.tee $6
                  (i64.add
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (struct.get $type50 0
                      (local.get $2)
                     )
                    )
                   )
                   (local.get $6)
                  )
                 )
                 (i64.const 4294967294)
                )
                (then
                 (unreachable)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $2
                    (struct.get $type50 1
                     (local.get $1)
                    )
                   )
                   (if (result i64)
                    (i64.gt_s
                     (local.tee $6
                      (i64.add
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (struct.get $type50 0
                          (local.get $1)
                         )
                        )
                       )
                       (local.get $6)
                      )
                     )
                     (i64.const 4294967294)
                    )
                    (then
                     (unreachable)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.get $2)
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $1
                        (struct.get $type50 1
                         (local.get $2)
                        )
                       )
                       (if (result i64)
                        (i64.gt_s
                         (local.tee $6
                          (i64.add
                           (i64.extend_i32_u
                            (struct.get $type18 1
                             (struct.get $type50 0
                              (local.get $2)
                             )
                            )
                           )
                           (local.get $6)
                          )
                         )
                         (i64.const 4294967294)
                        )
                        (then
                         (unreachable)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.get $1)
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (local.set $2
                            (struct.get $type50 1
                             (local.get $1)
                            )
                           )
                           (if (result i64)
                            (i64.gt_s
                             (local.tee $6
                              (i64.add
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (struct.get $type50 0
                                  (local.get $1)
                                 )
                                )
                               )
                               (local.get $6)
                              )
                             )
                             (i64.const 4294967294)
                            )
                            (then
                             (unreachable)
                            )
                            (else
                             (if (result i64)
                              (ref.is_null
                               (local.get $2)
                              )
                              (then
                               (local.get $6)
                              )
                              (else
                               (local.set $1
                                (struct.get $type50 1
                                 (local.get $2)
                                )
                               )
                               (if (result i64)
                                (i64.gt_s
                                 (local.tee $6
                                  (i64.add
                                   (i64.extend_i32_u
                                    (struct.get $type18 1
                                     (struct.get $type50 0
                                      (local.get $2)
                                     )
                                    )
                                   )
                                   (local.get $6)
                                  )
                                 )
                                 (i64.const 4294967294)
                                )
                                (then
                                 (unreachable)
                                )
                                (else
                                 (if (result i64)
                                  (ref.is_null
                                   (local.get $1)
                                  )
                                  (then
                                   (local.get $6)
                                  )
                                  (else
                                   (call $function37
                                    (i32.const 0)
                                    (i32.const 1)
                                    (struct.get $type50 1
                                     (local.get $1)
                                    )
                                    (i64.add
                                     (i64.extend_i32_u
                                      (struct.get $type18 1
                                       (struct.get $type50 0
                                        (local.get $1)
                                       )
                                      )
                                     )
                                     (local.get $6)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (if
   (i64.gt_u
    (local.get $6)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
  )
  (local.set $5
   (call $string-new
    (i32.wrap_i64
     (local.get $6)
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (call $string-copy
   (local.get $5)
   (i64.const 0)
   (local.tee $4
    (struct.get $type50 0
     (local.get $0)
    )
   )
   (local.tee $7
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $4)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready98)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global98)
   )
  )
  (drop
   (if (result i32)
    (ref.is_null
     (local.tee $1
      (struct.get $type50 1
       (local.get $0)
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (call $string-copy
      (local.get $5)
      (local.get $7)
      (local.tee $4
       (struct.get $type50 0
        (local.get $1)
       )
      )
      (local.tee $6
       (i64.extend_i32_u
        (struct.get $type18 1
         (local.get $4)
        )
       )
      )
     )
     (local.set $1
      (struct.get $type50 1
       (local.get $1)
      )
     )
     (if
      (i32.eqz
       (global.get $ready98)
      )
      (then
       (unreachable)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global98)
      )
     )
     (if (result i32)
      (ref.is_null
       (local.get $1)
      )
      (then
       (i32.const 0)
      )
      (else
       (call $string-copy
        (local.get $5)
        (local.tee $7
         (i64.add
          (local.get $6)
          (local.get $7)
         )
        )
        (local.tee $4
         (struct.get $type50 0
          (local.get $1)
         )
        )
        (local.tee $6
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $4)
          )
         )
        )
       )
       (local.set $1
        (struct.get $type50 1
         (local.get $1)
        )
       )
       (if
        (i32.eqz
         (global.get $ready98)
        )
        (then
         (unreachable)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global98)
        )
       )
       (if (result i32)
        (ref.is_null
         (local.get $1)
        )
        (then
         (i32.const 0)
        )
        (else
         (call $string-copy
          (local.get $5)
          (local.tee $7
           (i64.add
            (local.get $6)
            (local.get $7)
           )
          )
          (local.tee $4
           (struct.get $type50 0
            (local.get $1)
           )
          )
          (local.tee $6
           (i64.extend_i32_u
            (struct.get $type18 1
             (local.get $4)
            )
           )
          )
         )
         (local.set $1
          (struct.get $type50 1
           (local.get $1)
          )
         )
         (if
          (i32.eqz
           (global.get $ready98)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global98)
          )
         )
         (if (result i32)
          (ref.is_null
           (local.get $1)
          )
          (then
           (i32.const 0)
          )
          (else
           (call $string-copy
            (local.get $5)
            (local.tee $7
             (i64.add
              (local.get $6)
              (local.get $7)
             )
            )
            (local.tee $4
             (struct.get $type50 0
              (local.get $1)
             )
            )
            (local.tee $6
             (i64.extend_i32_u
              (struct.get $type18 1
               (local.get $4)
              )
             )
            )
           )
           (local.set $1
            (struct.get $type50 1
             (local.get $1)
            )
           )
           (if
            (i32.eqz
             (global.get $ready98)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global98)
            )
           )
           (if (result i32)
            (ref.is_null
             (local.get $1)
            )
            (then
             (i32.const 0)
            )
            (else
             (call $string-copy
              (local.get $5)
              (local.tee $7
               (i64.add
                (local.get $6)
                (local.get $7)
               )
              )
              (local.tee $4
               (struct.get $type50 0
                (local.get $1)
               )
              )
              (local.tee $6
               (i64.extend_i32_u
                (struct.get $type18 1
                 (local.get $4)
                )
               )
              )
             )
             (local.set $1
              (struct.get $type50 1
               (local.get $1)
              )
             )
             (if
              (i32.eqz
               (global.get $ready98)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global98)
              )
             )
             (if (result i32)
              (ref.is_null
               (local.get $1)
              )
              (then
               (i32.const 0)
              )
              (else
               (call $string-copy
                (local.get $5)
                (local.tee $7
                 (i64.add
                  (local.get $6)
                  (local.get $7)
                 )
                )
                (local.tee $4
                 (struct.get $type50 0
                  (local.get $1)
                 )
                )
                (local.tee $6
                 (i64.extend_i32_u
                  (struct.get $type18 1
                   (local.get $4)
                  )
                 )
                )
               )
               (local.set $1
                (struct.get $type50 1
                 (local.get $1)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready98)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global98)
                )
               )
               (if (result i32)
                (ref.is_null
                 (local.get $1)
                )
                (then
                 (i32.const 0)
                )
                (else
                 (call $string-copy
                  (local.get $5)
                  (local.tee $7
                   (i64.add
                    (local.get $6)
                    (local.get $7)
                   )
                  )
                  (local.tee $4
                   (struct.get $type50 0
                    (local.get $1)
                   )
                  )
                  (local.tee $6
                   (i64.extend_i32_u
                    (struct.get $type18 1
                     (local.get $4)
                    )
                   )
                  )
                 )
                 (local.set $1
                  (struct.get $type50 1
                   (local.get $1)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready98)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global98)
                  )
                 )
                 (if (result i32)
                  (ref.is_null
                   (local.get $1)
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (call $string-copy
                    (local.get $5)
                    (local.tee $7
                     (i64.add
                      (local.get $6)
                      (local.get $7)
                     )
                    )
                    (local.tee $4
                     (struct.get $type50 0
                      (local.get $1)
                     )
                    )
                    (local.tee $6
                     (i64.extend_i32_u
                      (struct.get $type18 1
                       (local.get $4)
                      )
                     )
                    )
                   )
                   (local.set $1
                    (struct.get $type50 1
                     (local.get $1)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready98)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global98)
                    )
                   )
                   (if (result i32)
                    (ref.is_null
                     (local.get $1)
                    )
                    (then
                     (i32.const 0)
                    )
                    (else
                     (call $string-copy
                      (local.get $5)
                      (local.tee $7
                       (i64.add
                        (local.get $6)
                        (local.get $7)
                       )
                      )
                      (local.tee $4
                       (struct.get $type50 0
                        (local.get $1)
                       )
                      )
                      (local.tee $6
                       (i64.extend_i32_u
                        (struct.get $type18 1
                         (local.get $4)
                        )
                       )
                      )
                     )
                     (local.set $1
                      (struct.get $type50 1
                       (local.get $1)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready98)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global98)
                      )
                     )
                     (call $function38
                      (local.get $5)
                      (local.get $1)
                      (i64.add
                       (local.get $6)
                       (local.get $7)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (local.get $5)
 )
 (func $function37 (type $92) (param $0 i32) (param $1 i32) (param $2 (ref null $type50)) (param $3 i64) (result i64)
  (local $4 (ref null $type50))
  (local $5 i64)
  (if (result i64)
   (i64.gt_s
    (local.get $3)
    (i64.const 4294967294)
   )
   (then
    (unreachable)
   )
   (else
    (if (result i64)
     (ref.is_null
      (local.get $2)
     )
     (then
      (local.get $3)
     )
     (else
      (local.set $4
       (struct.get $type50 1
        (local.get $2)
       )
      )
      (local.set $5
       (i64.extend_i32_u
        (struct.get $type18 1
         (struct.get $type50 0
          (local.get $2)
         )
        )
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function37
       (local.get $0)
       (local.get $1)
       (local.get $4)
       (i64.add
        (local.get $3)
        (local.get $5)
       )
      )
     )
    )
   )
  )
 )
 (func $function38 (type $call52) (param $0 (ref $type18)) (param $1 (ref null $type50)) (param $2 i64) (result i32)
  (local $3 (ref $type18))
  (local $4 i64)
  (if (result i32)
   (ref.is_null
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (call $string-copy
     (local.get $0)
     (local.get $2)
     (local.tee $3
      (struct.get $type50 0
       (local.get $1)
      )
     )
     (local.tee $4
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $3)
       )
      )
     )
    )
    (local.set $1
     (struct.get $type50 1
      (local.get $1)
     )
    )
    (if
     (i32.eqz
      (global.get $ready98)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global98)
     )
    )
    (return_call $function38
     (local.get $0)
     (local.get $1)
     (i64.add
      (local.get $2)
      (local.get $4)
     )
    )
   )
  )
 )
 (func $function40 (type $90) (param $0 (ref $type18)) (param $1 (ref $type18)) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $5
    (i64.eq
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
     (local.get $4)
    )
   )
   (then
    (local.get $5)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i32.eq
      (array.get $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
      )
      (block (result i32)
       (if
        (i64.ge_u
         (local.get $4)
         (i64.extend_i32_u
          (struct.get $type18 1
           (local.get $1)
          )
         )
        )
        (then
         (unreachable)
        )
       )
       (array.get $type19
        (if (result (ref $type19))
         (i32.lt_u
          (local.tee $5
           (i32.wrap_i64
            (local.get $4)
           )
          )
          (i32.const 8192)
         )
         (then
          (struct.get $type18 2
           (local.get $1)
          )
         )
         (else
          (ref.as_non_null
           (array.get $type20
            (struct.get $type18 3
             (local.get $1)
            )
            (i32.sub
             (i32.shr_u
              (local.get $5)
              (i32.const 13)
             )
             (i32.const 1)
            )
           )
          )
         )
        )
        (i32.and
         (local.get $5)
         (i32.const 8191)
        )
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $3)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function40
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (i64.add
        (local.get $4)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function42 (type $call55) (param $0 (ref $type56)) (result (ref $type36))
  (local $1 (ref null $type56))
  (local $2 (ref $type36))
  (local $3 i64)
  (local $4 i64)
  (if
   (i32.eqz
    (global.get $ready114)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global114)
   )
  )
  (local.set $4
   (if (result i64)
    (ref.is_null
     (local.tee $1
      (struct.get $type56 1
       (local.get $0)
      )
     )
    )
    (then
     (i64.const 1)
    )
    (else
     (if (result i64)
      (ref.is_null
       (local.tee $1
        (struct.get $type56 1
         (local.get $1)
        )
       )
      )
      (then
       (i64.const 2)
      )
      (else
       (if (result i64)
        (ref.is_null
         (local.tee $1
          (struct.get $type56 1
           (local.get $1)
          )
         )
        )
        (then
         (i64.const 3)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $1
            (struct.get $type56 1
             (local.get $1)
            )
           )
          )
          (then
           (i64.const 4)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $1
              (struct.get $type56 1
               (local.get $1)
              )
             )
            )
            (then
             (i64.const 5)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $1
                (struct.get $type56 1
                 (local.get $1)
                )
               )
              )
              (then
               (i64.const 6)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $1
                  (struct.get $type56 1
                   (local.get $1)
                  )
                 )
                )
                (then
                 (i64.const 7)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $1
                    (struct.get $type56 1
                     (local.get $1)
                    )
                   )
                  )
                  (then
                   (i64.const 8)
                  )
                  (else
                   (call $function44
                    (i32.const 0)
                    (i32.const 1)
                    (struct.get $type56 1
                     (local.get $1)
                    )
                    (i64.const 9)
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global109)
   )
  )
  (if
   (i64.gt_u
    (local.get $4)
    (i64.const 4294967295)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.gt_u
    (local.tee $3
     (struct.get $type56 0
      (local.get $0)
     )
    )
    (i64.const 255)
   )
   (then
    (unreachable)
   )
  )
  (array.set $type37
   (struct.get $type36 0
    (local.tee $2
     (struct.new $type36
      (array.new_default $type37
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
   )
   (i32.const 0)
   (i32.wrap_i64
    (local.get $3)
   )
  )
  (if (result (ref $type36))
   (ref.is_null
    (local.tee $1
     (struct.get $type56 1
      (local.get $0)
     )
    )
   )
   (then
    (local.get $2)
   )
   (else
    (if
     (i64.gt_u
      (local.tee $3
       (struct.get $type56 0
        (local.get $1)
       )
      )
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type37
     (struct.get $type36 0
      (local.get $2)
     )
     (i32.const 1)
     (i32.wrap_i64
      (local.get $3)
     )
    )
    (if (result (ref $type36))
     (ref.is_null
      (local.tee $1
       (struct.get $type56 1
        (local.get $1)
       )
      )
     )
     (then
      (local.get $2)
     )
     (else
      (if
       (i64.gt_u
        (local.tee $3
         (struct.get $type56 0
          (local.get $1)
         )
        )
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type37
       (struct.get $type36 0
        (local.get $2)
       )
       (i32.const 2)
       (i32.wrap_i64
        (local.get $3)
       )
      )
      (if (result (ref $type36))
       (ref.is_null
        (local.tee $1
         (struct.get $type56 1
          (local.get $1)
         )
        )
       )
       (then
        (local.get $2)
       )
       (else
        (if
         (i64.gt_u
          (local.tee $3
           (struct.get $type56 0
            (local.get $1)
           )
          )
          (i64.const 255)
         )
         (then
          (unreachable)
         )
        )
        (array.set $type37
         (struct.get $type36 0
          (local.get $2)
         )
         (i32.const 3)
         (i32.wrap_i64
          (local.get $3)
         )
        )
        (if (result (ref $type36))
         (ref.is_null
          (local.tee $1
           (struct.get $type56 1
            (local.get $1)
           )
          )
         )
         (then
          (local.get $2)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $3
             (struct.get $type56 0
              (local.get $1)
             )
            )
            (i64.const 255)
           )
           (then
            (unreachable)
           )
          )
          (array.set $type37
           (struct.get $type36 0
            (local.get $2)
           )
           (i32.const 4)
           (i32.wrap_i64
            (local.get $3)
           )
          )
          (if (result (ref $type36))
           (ref.is_null
            (local.tee $1
             (struct.get $type56 1
              (local.get $1)
             )
            )
           )
           (then
            (local.get $2)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $3
               (struct.get $type56 0
                (local.get $1)
               )
              )
              (i64.const 255)
             )
             (then
              (unreachable)
             )
            )
            (array.set $type37
             (struct.get $type36 0
              (local.get $2)
             )
             (i32.const 5)
             (i32.wrap_i64
              (local.get $3)
             )
            )
            (if (result (ref $type36))
             (ref.is_null
              (local.tee $1
               (struct.get $type56 1
                (local.get $1)
               )
              )
             )
             (then
              (local.get $2)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $3
                 (struct.get $type56 0
                  (local.get $1)
                 )
                )
                (i64.const 255)
               )
               (then
                (unreachable)
               )
              )
              (array.set $type37
               (struct.get $type36 0
                (local.get $2)
               )
               (i32.const 6)
               (i32.wrap_i64
                (local.get $3)
               )
              )
              (if (result (ref $type36))
               (ref.is_null
                (local.tee $1
                 (struct.get $type56 1
                  (local.get $1)
                 )
                )
               )
               (then
                (local.get $2)
               )
               (else
                (if
                 (i64.gt_u
                  (local.tee $3
                   (struct.get $type56 0
                    (local.get $1)
                   )
                  )
                  (i64.const 255)
                 )
                 (then
                  (unreachable)
                 )
                )
                (array.set $type37
                 (struct.get $type36 0
                  (local.get $2)
                 )
                 (i32.const 7)
                 (i32.wrap_i64
                  (local.get $3)
                 )
                )
                (if (result (ref $type36))
                 (ref.is_null
                  (local.tee $1
                   (struct.get $type56 1
                    (local.get $1)
                   )
                  )
                 )
                 (then
                  (local.get $2)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $3
                     (struct.get $type56 0
                      (local.get $1)
                     )
                    )
                    (i64.const 255)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (array.set $type37
                   (struct.get $type36 0
                    (local.get $2)
                   )
                   (i32.const 8)
                   (i32.wrap_i64
                    (local.get $3)
                   )
                  )
                  (if (result (ref $type36))
                   (ref.is_null
                    (local.tee $1
                     (struct.get $type56 1
                      (local.get $1)
                     )
                    )
                   )
                   (then
                    (local.get $2)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $3
                       (struct.get $type56 0
                        (local.get $1)
                       )
                      )
                      (i64.const 255)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (array.set $type37
                     (struct.get $type36 0
                      (local.get $2)
                     )
                     (i32.const 9)
                     (i32.wrap_i64
                      (local.get $3)
                     )
                    )
                    (return_call $function45
                     (local.get $2)
                     (i32.const 0)
                     (i32.const 1)
                     (struct.get $type56 1
                      (local.get $1)
                     )
                     (i64.const 10)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function44 (type $85) (param $0 i32) (param $1 i32) (param $2 (ref null $type56)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type56 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function44
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function45 (type $84) (param $0 (ref $type36)) (param $1 i32) (param $2 i32) (param $3 (ref null $type56)) (param $4 i64) (result (ref $type36))
  (local $5 i64)
  (if (result (ref $type36))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (local.set $5
     (struct.get $type56 0
      (local.get $3)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 255)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type37
     (struct.get $type36 0
      (local.get $0)
     )
     (i32.wrap_i64
      (local.get $4)
     )
     (i32.wrap_i64
      (local.get $5)
     )
    )
    (local.set $3
     (struct.get $type56 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function45
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function80 (type $call81) (param $0 (ref $type18)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local.set $1
   (call $foreign0)
  )
  (if (result i32)
   (i64.eqz
    (local.tee $2
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (local.get $1)
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $2)
      (i64.const 1)
     )
     (then
      (local.get $1)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign1
       (local.get $1)
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $2)
        (i64.const 2)
       )
       (then
        (local.get $1)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign1
         (local.get $1)
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $2)
          (i64.const 3)
         )
         (then
          (local.get $1)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign1
           (local.get $1)
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $2)
            (i64.const 4)
           )
           (then
            (local.get $1)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign1
             (local.get $1)
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $2)
              (i64.const 5)
             )
             (then
              (local.get $1)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign1
               (local.get $1)
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $2)
                (i64.const 6)
               )
               (then
                (local.get $1)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign1
                 (local.get $1)
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $2)
                  (i64.const 7)
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign1
                   (local.get $1)
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $2)
                    (i64.const 8)
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign1
                     (local.get $1)
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $2)
                      (i64.const 9)
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign1
                       (local.get $1)
                       (array.get $type19
                        (call $string-block
                         (local.get $0)
                         (i32.const 9)
                        )
                        (i32.const 9)
                       )
                      )
                      (return_call $function81
                       (local.get $0)
                       (local.get $1)
                       (local.get $2)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function81 (type $82) (param $0 (ref $type18)) (param $1 i32) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (i64.eq
    (local.get $2)
    (local.get $5)
   )
   (then
    (local.get $1)
   )
   (else
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign1
     (local.get $1)
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (i32.and
       (local.get $6)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function81
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function87 (type $81) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign7
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function87
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function96 (type $81) (param $0 i32) (param $1 i64) (param $2 (ref $type18)) (param $3 i32) (param $4 i32) (param $5 i64) (result (ref $type18))
  (local $6 i32)
  (local $7 i32)
  (if (result (ref $type18))
   (i64.eq
    (local.get $1)
    (local.get $5)
   )
   (then
    (local.get $2)
   )
   (else
    (local.set $7
     (call $foreign12
      (local.get $0)
      (i32.wrap_i64
       (local.get $5)
      )
     )
    )
    (if
     (i32.ne
      (struct.get $type18 0
       (local.get $2)
      )
      (i32.const 1)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.ge_u
      (local.get $5)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $2)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (array.set $type19
     (if (result (ref $type19))
      (i32.lt_u
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
       (i32.const 8192)
      )
      (then
       (struct.get $type18 2
        (local.get $2)
       )
      )
      (else
       (ref.as_non_null
        (array.get $type20
         (struct.get $type18 3
          (local.get $2)
         )
         (i32.sub
          (i32.shr_u
           (local.get $6)
           (i32.const 13)
          )
          (i32.const 1)
         )
        )
       )
      )
     )
     (i32.and
      (local.get $6)
      (i32.const 8191)
     )
     (local.get $7)
    )
    (if
     (i32.eqz
      (local.get $4)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function96
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (local.get $4)
     (i64.add
      (local.get $5)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function97 (type $call91) (param $0 i32) (param $1 i32) (result (ref $type92))
  (local $2 i64)
  (if (result (ref $type92))
   (local.get $1)
   (then
    (if (result (ref $type92))
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (struct.new $type94
       (i32.const 1)
       (struct.new $type25
        (i32.const 0)
        (call $foreign9
         (local.get $0)
         (i32.const 0)
        )
       )
      )
     )
     (else
      (if (result (ref $type92))
       (i32.eq
        (local.get $1)
        (i32.const 2)
       )
       (then
        (struct.new $type94
         (i32.const 1)
         (struct.new $type26
          (i32.const 1)
          (call $foreign8
           (local.get $0)
           (i32.const 0)
          )
         )
        )
       )
       (else
        (if (result (ref $type92))
         (i32.eq
          (local.get $1)
          (i32.const 3)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global296)
           )
          )
          (struct.new $type94
           (i32.const 1)
           (struct.new $type27
            (i32.const 2)
            (if (result (ref $type28))
             (i32.eq
              (call $foreign10
               (local.get $0)
               (i32.const 0)
              )
              (i32.const 1)
             )
             (then
              (struct.new $type29
               (call $foreign9
                (local.get $0)
                (i32.const 0)
               )
              )
             )
             (else
              (struct.new $type30
               (call $foreign8
                (local.get $0)
                (i32.const 0)
               )
              )
             )
            )
            (block (result (ref $type28))
             (drop
              (ref.as_non_null
               (global.get $global296)
              )
             )
             (if (result (ref $type28))
              (i32.eq
               (call $foreign10
                (local.get $0)
                (i32.const 1)
               )
               (i32.const 1)
              )
              (then
               (struct.new $type29
                (call $foreign9
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
              (else
               (struct.new $type30
                (call $foreign8
                 (local.get $0)
                 (i32.const 1)
                )
               )
              )
             )
            )
           )
          )
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global299)
           )
          )
          (struct.new $type95
           (i32.const 2)
           (call $function96
            (local.get $0)
            (local.tee $2
             (i64.extend_i32_s
              (call $foreign11
               (local.get $0)
              )
             )
            )
            (block (result (ref $type18))
             (drop
              (ref.as_non_null
               (global.get $global61)
              )
             )
             (if
              (i64.gt_u
               (local.get $2)
               (i64.const 4294967294)
              )
              (then
               (unreachable)
              )
             )
             (call $string-new
              (i32.wrap_i64
               (local.get $2)
              )
             )
            )
            (i32.const 0)
            (i32.const 1)
            (i64.const 0)
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (global.get $empty93)
   )
  )
 )
 (func $function99 (type $call97) (param $0 (ref $type28)) (param $1 (ref $type28)) (result i32)
  (local $2 i64)
  (local $3 f64)
  (if (result i32)
   (ref.test (ref $type29)
    (local.get $0)
   )
   (then
    (local.set $2
     (struct.get $type29 0
      (ref.cast (ref $type29)
       (local.get $0)
      )
     )
    )
    (if (result i32)
     (ref.test (ref $type29)
      (local.get $1)
     )
     (then
      (i64.eq
       (struct.get $type29 0
        (ref.cast (ref $type29)
         (local.get $1)
        )
       )
       (local.get $2)
      )
     )
     (else
      (drop
       (ref.cast (ref $type30)
        (local.get $1)
       )
      )
      (i32.const 0)
     )
    )
   )
   (else
    (local.set $3
     (struct.get $type30 0
      (ref.cast (ref $type30)
       (local.get $0)
      )
     )
    )
    (if (result i32)
     (ref.test (ref $type29)
      (local.get $1)
     )
     (then
      (drop
       (ref.cast (ref $type29)
        (local.get $1)
       )
      )
      (i32.const 0)
     )
     (else
      (i32.eq
       (call $foreign14
        (local.get $3)
        (struct.get $type30 0
         (ref.cast (ref $type30)
          (local.get $1)
         )
        )
       )
       (i32.const 1)
      )
     )
    )
   )
  )
 )
 (func $function101 (type $call99) (param $0 (ref $type24)) (param $1 (ref $type24)) (result i32)
  (local $2 i32)
  (local $3 f64)
  (local $4 i64)
  (local $5 (ref $type27))
  (local $6 (ref $type28))
  (drop
   (ref.as_non_null
    (global.get $global325)
   )
  )
  (if (result i32)
   (i64.eq
    (if (result i64)
     (local.tee $2
      (struct.get $type24 0
       (local.get $0)
      )
     )
     (then
      (if (result i64)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type26)
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type27)
          (local.get $0)
         )
        )
        (i64.const 2)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type25)
        (local.get $0)
       )
      )
      (i64.const 0)
     )
    )
    (if (result i64)
     (local.tee $2
      (struct.get $type24 0
       (local.get $1)
      )
     )
     (then
      (if (result i64)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (drop
         (ref.cast (ref $type26)
          (local.get $1)
         )
        )
        (i64.const 1)
       )
       (else
        (drop
         (ref.cast (ref $type27)
          (local.get $1)
         )
        )
        (i64.const 2)
       )
      )
     )
     (else
      (drop
       (ref.cast (ref $type25)
        (local.get $1)
       )
      )
      (i64.const 0)
     )
    )
   )
   (then
    (if (result i32)
     (local.tee $2
      (struct.get $type24 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (i32.eq
         (call $foreign14
          (struct.get $type26 1
           (ref.cast (ref $type26)
            (local.get $0)
           )
          )
          (block (result f64)
           (if
            (i32.ne
             (struct.get $type24 0
              (local.get $1)
             )
             (i32.const 1)
            )
            (then
             (unreachable)
            )
           )
           (struct.get $type26 1
            (ref.cast (ref $type26)
             (local.get $1)
            )
           )
          )
         )
         (i32.const 1)
        )
       )
       (else
        (local.set $6
         (struct.get $type27 2
          (local.tee $5
           (ref.cast (ref $type27)
            (local.get $0)
           )
          )
         )
        )
        (if
         (i32.ne
          (struct.get $type24 0
           (local.get $1)
          )
          (i32.const 2)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global313)
         )
        )
        (if (result i32)
         (call $function99
          (struct.get $type27 1
           (local.get $5)
          )
          (struct.get $type27 1
           (local.tee $5
            (ref.cast (ref $type27)
             (local.get $1)
            )
           )
          )
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global313)
           )
          )
          (return_call $function99
           (local.get $6)
           (struct.get $type27 2
            (local.get $5)
           )
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
      )
     )
     (else
      (local.set $4
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $0)
        )
       )
      )
      (if
       (struct.get $type24 0
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (i64.eq
       (struct.get $type25 1
        (ref.cast (ref $type25)
         (local.get $1)
        )
       )
       (local.get $4)
      )
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function109 (type $call109) (param $0 (ref $type13)) (result i64)
  (local $1 i32)
  (if (result i64)
   (local.tee $1
    (struct.get $type13 0
     (local.get $0)
    )
   )
   (then
    (if (result i64)
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (then
      (drop
       (ref.cast (ref $type15)
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (else
      (if (result i64)
       (i32.eq
        (struct.get $type13 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (drop
         (ref.cast (ref $type16)
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (else
        (if (result i64)
         (i32.eq
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 3)
         )
         (then
          (drop
           (ref.cast (ref $type17)
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (else
          (if (result i64)
           (i32.eq
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 4)
           )
           (then
            (drop
             (ref.cast (ref $type21)
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (else
            (if (result i64)
             (i32.eq
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 5)
             )
             (then
              (drop
               (ref.cast (ref $type23)
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (else
              (if (result i64)
               (i32.eq
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 6)
               )
               (then
                (drop
                 (ref.cast (ref $type31)
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (else
                (if (result i64)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 7)
                 )
                 (then
                  (drop
                   (ref.cast (ref $type33)
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (else
                  (drop
                   (ref.cast (ref $type35)
                    (local.get $0)
                   )
                  )
                  (i64.const 8)
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (i64.const 0)
   )
  )
 )
 (func $function122 (type $call111) (param $0 (ref $type13)) (param $1 (ref $type13)) (result i32)
  (local $2 i32)
  (local $3 i64)
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type34))
  (local $7 (ref $type34))
  (local $8 (ref $type36))
  (local $9 (ref $type36))
  (local $10 (ref $type22))
  (local $11 (ref $type24))
  (local $12 (ref $type31))
  (local $13 (ref $type32))
  (local $scratch (ref $type22))
  (drop
   (ref.as_non_null
    (global.get $global364)
   )
  )
  (if (result i32)
   (i64.eq
    (call $function109
     (local.get $0)
    )
    (block (result i64)
     (drop
      (ref.as_non_null
       (global.get $global364)
      )
     )
     (call $function109
      (local.get $1)
     )
    )
   )
   (then
    (if (result i32)
     (local.tee $2
      (struct.get $type13 0
       (local.get $0)
      )
     )
     (then
      (if (result i32)
       (i32.eq
        (local.get $2)
        (i32.const 1)
       )
       (then
        (if (result i32)
         (struct.get $type15 1
          (ref.cast (ref $type15)
           (local.get $0)
          )
         )
         (then
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $1)
            )
            (i32.const 1)
           )
           (then
            (unreachable)
           )
          )
          (struct.get $type15 1
           (ref.cast (ref $type15)
            (local.get $1)
           )
          )
         )
         (else
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $1)
            )
            (i32.const 1)
           )
           (then
            (unreachable)
           )
          )
          (i32.eqz
           (struct.get $type15 1
            (ref.cast (ref $type15)
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (else
        (if (result i32)
         (i32.eq
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 2)
         )
         (then
          (local.set $2
           (struct.get $type16 1
            (ref.cast (ref $type16)
             (local.get $0)
            )
           )
          )
          (if
           (i32.ne
            (struct.get $type13 0
             (local.get $1)
            )
            (i32.const 2)
           )
           (then
            (unreachable)
           )
          )
          (i32.eq
           (struct.get $type16 1
            (ref.cast (ref $type16)
             (local.get $1)
            )
           )
           (local.get $2)
          )
         )
         (else
          (if (result i32)
           (i32.eq
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 3)
           )
           (then
            (local.set $4
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (local.get $0)
              )
             )
            )
            (if
             (i32.ne
              (struct.get $type13 0
               (local.get $1)
              )
              (i32.const 3)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global103)
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $4)
               )
              )
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.tee $5
                 (struct.get $type17 1
                  (ref.cast (ref $type17)
                   (local.get $1)
                  )
                 )
                )
               )
              )
             )
             (then
              (return_call $function40
               (local.get $4)
               (local.get $5)
               (i32.const 0)
               (i32.const 1)
               (i64.const 0)
              )
             )
             (else
              (i32.const 0)
             )
            )
           )
           (else
            (if (result i32)
             (i32.eq
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 4)
             )
             (then
              (i32.eq
               (struct.get $type22 0
                (block (result (ref $type22))
                 (local.set $scratch
                  (struct.get $type21 1
                   (ref.cast (ref $type21)
                    (local.get $0)
                   )
                  )
                 )
                 (if
                  (i32.ne
                   (struct.get $type13 0
                    (local.get $1)
                   )
                   (i32.const 4)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global260)
                  )
                 )
                 (local.get $scratch)
                )
               )
               (struct.get $type22 0
                (struct.get $type21 1
                 (ref.cast (ref $type21)
                  (local.get $1)
                 )
                )
               )
              )
             )
             (else
              (if (result i32)
               (i32.eq
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 5)
               )
               (then
                (return_call $function101
                 (struct.get $type23 1
                  (ref.cast (ref $type23)
                   (local.get $0)
                  )
                 )
                 (block (result (ref $type24))
                  (if
                   (i32.ne
                    (struct.get $type13 0
                     (local.get $1)
                    )
                    (i32.const 5)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global332)
                   )
                  )
                  (struct.get $type23 1
                   (ref.cast (ref $type23)
                    (local.get $1)
                   )
                  )
                 )
                )
               )
               (else
                (if (result i32)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                 (then
                  (local.set $13
                   (struct.get $type31 2
                    (local.tee $12
                     (ref.cast (ref $type31)
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global354)
                   )
                  )
                  (if
                   (i32.ne
                    (struct.get $type13 0
                     (local.get $1)
                    )
                    (i32.const 6)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (local.set $0
                   (struct.get $type32 0
                    (struct.get $type31 1
                     (ref.cast (ref $type31)
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if
                   (i32.eqz
                    (global.get $ready417)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global417)
                   )
                  )
                  (if (result i32)
                   (call $function122
                    (struct.get $type32 0
                     (struct.get $type31 1
                      (local.get $12)
                     )
                    )
                    (local.get $0)
                   )
                   (then
                    (drop
                     (ref.as_non_null
                      (global.get $global356)
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $1)
                      )
                      (i32.const 6)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $0
                     (struct.get $type32 0
                      (struct.get $type31 2
                       (ref.cast (ref $type31)
                        (local.get $1)
                       )
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready417)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global417)
                     )
                    )
                    (return_call $function122
                     (struct.get $type32 0
                      (local.get $13)
                     )
                     (local.get $0)
                    )
                   )
                   (else
                    (i32.const 0)
                   )
                  )
                 )
                 (else
                  (if (result i32)
                   (i32.eq
                    (struct.get $type13 0
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                   (then
                    (local.set $6
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $0)
                      )
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $1)
                      )
                      (i32.const 7)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $7
                     (struct.get $type33 1
                      (ref.cast (ref $type33)
                       (local.get $1)
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready429)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global429)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.tee $3
                       (i64.extend_i32_u
                        (array.len
                         (local.get $6)
                        )
                       )
                      )
                      (i64.extend_i32_u
                       (array.len
                        (local.get $7)
                       )
                      )
                     )
                     (then
                      (return_call $function124
                       (local.get $6)
                       (local.get $7)
                       (local.get $3)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 0)
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                   (else
                    (local.set $8
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (local.get $0)
                      )
                     )
                    )
                    (if
                     (i32.ne
                      (struct.get $type13 0
                       (local.get $1)
                      )
                      (i32.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (local.set $9
                     (struct.get $type35 1
                      (ref.cast (ref $type35)
                       (local.get $1)
                      )
                     )
                    )
                    (if
                     (i32.eqz
                      (global.get $ready437)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global437)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.tee $3
                       (i64.extend_i32_u
                        (array.len
                         (struct.get $type36 0
                          (local.get $8)
                         )
                        )
                       )
                      )
                      (i64.extend_i32_u
                       (array.len
                        (struct.get $type36 0
                         (local.get $9)
                        )
                       )
                      )
                     )
                     (then
                      (return_call $function126
                       (local.get $8)
                       (local.get $9)
                       (local.get $3)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 0)
                      )
                     )
                     (else
                      (i32.const 0)
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (i32.const 1)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function124 (type $57) (param $0 (ref $type34)) (param $1 (ref $type34)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $6
    (i64.eq
     (local.get $2)
     (local.get $5)
    )
   )
   (then
    (local.get $6)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global417)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (call $function122
      (array.get $type34
       (local.get $0)
       (local.tee $6
        (i32.wrap_i64
         (local.get $5)
        )
       )
      )
      (array.get $type34
       (local.get $1)
       (local.get $6)
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function124
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i64.add
        (local.get $5)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function126 (type $56) (param $0 (ref $type36)) (param $1 (ref $type36)) (param $2 i64) (param $3 i32) (param $4 i32) (param $5 i64) (result i32)
  (local $6 i32)
  (if (result i32)
   (local.tee $6
    (i64.eq
     (local.get $2)
     (local.get $5)
    )
   )
   (then
    (local.get $6)
   )
   (else
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i64.gt_u
      (local.get $5)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (array.get_u $type37
        (struct.get $type36 0
         (local.get $0)
        )
        (local.tee $6
         (i32.wrap_i64
          (local.get $5)
         )
        )
       )
      )
      (i64.extend_i32_u
       (array.get_u $type37
        (struct.get $type36 0
         (local.get $1)
        )
        (local.get $6)
       )
      )
     )
     (then
      (if
       (i32.eqz
        (local.get $4)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function126
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (local.get $3)
       (local.get $4)
       (i64.add
        (local.get $5)
        (i64.const 1)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
   )
  )
 )
 (func $function127 (type $55) (param $0 (ref $type18)) (result i32)
  (local $1 i64)
  (call $foreign15)
  (if (result i32)
   (i64.eqz
    (local.tee $1
     (i64.extend_i32_u
      (struct.get $type18 1
       (local.get $0)
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign16
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (local.get $1)
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign16
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (local.get $1)
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign16
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (local.get $1)
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign16
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (local.get $1)
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign16
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (local.get $1)
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign16
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (local.get $1)
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign16
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (local.get $1)
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign16
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (local.get $1)
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign16
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (local.get $1)
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign16
                       (array.get $type19
                        (call $string-block
                         (local.get $0)
                         (i32.const 9)
                        )
                        (i32.const 9)
                       )
                      )
                      (return_call $function128
                       (local.get $0)
                       (local.get $1)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function128 (type $54) (param $0 (ref $type18)) (param $1 i64) (param $2 i32) (param $3 i32) (param $4 i64) (result i32)
  (local $5 i32)
  (if (result i32)
   (i64.eq
    (local.get $1)
    (local.get $4)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $4)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign16
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $5
        (i32.wrap_i64
         (local.get $4)
        )
       )
      )
      (i32.and
       (local.get $5)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function128
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function152 (type $call147) (param $0 (ref $type101)) (result (ref $type13))
  (local $1 (ref $type18))
  (local $scratch (ref $type18))
  (if (result (ref $type13))
   (i32.eq
    (struct.get $type101 0
     (local.get $0)
    )
    (i32.const 1)
   )
   (then
    (struct.get $type103 1
     (ref.cast (ref $type103)
      (local.get $0)
     )
    )
   )
   (else
    (if
     (struct.get $type101 0
      (local.get $0)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global90)
       )
      )
      (call $foreign2
       (call $function80
        (block (result (ref $type18))
         (local.set $scratch
          (call $function35
           (struct.new $type50
            (global.get $string2)
            (struct.new $type50
             (struct.get $type104 1
              (ref.cast (ref $type104)
               (local.get $0)
              )
             )
             (ref.null none)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global252)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global246)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global252)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global246)
       )
      )
      (call $foreign2
       (call $function80
        (global.get $string3)
       )
      )
      (unreachable)
     )
    )
    (unreachable)
   )
  )
 )
 (func $function154 (type $call162) (param $0 (ref $type121)) (result (ref $type163))
  (local $1 i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 (ref $type18))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type130))
  (local $8 (ref $type92))
  (local $9 (ref $type154))
  (local $10 (ref $type101))
  (local $11 (ref $type181))
  (local $12 (ref $type163))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global470)
   )
  )
  (local.set $2
   (call $foreign22
    (struct.get $type119 0
     (struct.get $type121 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (block $block
   (return
    (if (result (ref $type165))
     (i64.lt_s
      (local.tee $1
       (if (result i64)
        (ref.test (ref $type131)
         (local.tee $7
          (if (result (ref $type130))
           (i32.eq
            (local.get $2)
            (i32.const -1)
           )
           (then
            (global.get $empty131)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $1
               (i64.extend_i32_s
                (local.get $2)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $1)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $1)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type132
             (i32.wrap_i64
              (local.get $1)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type132 0
           (ref.cast (ref $type132)
            (local.get $7)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (global.get $empty165)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global536)
       )
      )
      (br_if $block
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if
          (i64.gt_u
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $1)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $1)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (i32.eq
          (call $foreign25
           (i32.wrap_i64
            (local.get $1)
           )
          )
          (i32.const 1)
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 59)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global541)
         )
        )
        (drop
         (call $function159
          (local.get $0)
         )
        )
        (br $block)
       )
       (else
        (if
         (i32.eqz
          (global.get $ready546)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global546)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (return
         (if (result (ref $type163))
          (i64.eq
           (local.get $1)
           (i64.const 40)
          )
          (then
           (struct.new $type168
            (i32.const 4)
            (i64.const 0)
           )
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global538)
            )
           )
           (if (result (ref $type163))
            (i64.eq
             (local.get $1)
             (i64.const 41)
            )
            (then
             (global.get $empty166)
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global538)
              )
             )
             (if (result (ref $type163))
              (i64.eq
               (local.get $1)
               (i64.const 39)
              )
              (then
               (struct.new $type169
                (i32.const 5)
                (global.get $string8)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global538)
                )
               )
               (if (result (ref $type163))
                (i64.eq
                 (local.get $1)
                 (i64.const 96)
                )
                (then
                 (struct.new $type169
                  (i32.const 5)
                  (global.get $string7)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global538)
                  )
                 )
                 (if (result (ref $type163))
                  (i64.eq
                   (local.get $1)
                   (i64.const 44)
                  )
                  (then
                   (drop
                    (ref.as_non_null
                     (global.get $global549)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global552)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global472)
                    )
                   )
                   (local.set $2
                    (call $foreign23
                     (struct.get $type119 0
                      (struct.get $type121 0
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global468)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global532)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global538)
                    )
                   )
                   (struct.new $type169
                    (i32.const 5)
                    (select (result (ref $type18))
                     (global.get $string6)
                     (global.get $string5)
                     (if (result i32)
                      (i64.eq
                       (if (result i64)
                        (ref.test (ref $type131)
                         (local.tee $7
                          (if (result (ref $type130))
                           (i32.eq
                            (local.get $2)
                            (i32.const -1)
                           )
                           (then
                            (global.get $empty131)
                           )
                           (else
                            (if
                             (i64.gt_u
                              (local.tee $1
                               (i64.extend_i32_s
                                (local.get $2)
                               )
                              )
                              (i64.const 1114111)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (if
                             (i32.and
                              (i64.le_u
                               (local.get $1)
                               (i64.const 57343)
                              )
                              (i64.ge_u
                               (local.get $1)
                               (i64.const 55296)
                              )
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (struct.new $type132
                             (i32.wrap_i64
                              (local.get $1)
                             )
                            )
                           )
                          )
                         )
                        )
                        (then
                         (i64.const -1)
                        )
                        (else
                         (i64.extend_i32_u
                          (struct.get $type132 0
                           (ref.cast (ref $type132)
                            (local.get $7)
                           )
                          )
                         )
                        )
                       )
                       (i64.const 64)
                      )
                      (then
                       (drop
                        (ref.as_non_null
                         (global.get $global470)
                        )
                       )
                       (local.set $2
                        (call $foreign22
                         (struct.get $type119 0
                          (struct.get $type121 0
                           (local.get $0)
                          )
                         )
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global468)
                        )
                       )
                       (drop
                        (if (result (ref $type130))
                         (i32.eq
                          (local.get $2)
                          (i32.const -1)
                         )
                         (then
                          (global.get $empty131)
                         )
                         (else
                          (if
                           (i64.gt_u
                            (local.tee $1
                             (i64.extend_i32_s
                              (local.get $2)
                             )
                            )
                            (i64.const 1114111)
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (if
                           (i32.and
                            (i64.le_u
                             (local.get $1)
                             (i64.const 57343)
                            )
                            (i64.ge_u
                             (local.get $1)
                             (i64.const 55296)
                            )
                           )
                           (then
                            (unreachable)
                           )
                          )
                          (struct.new $type132
                           (i32.wrap_i64
                            (local.get $1)
                           )
                          )
                         )
                        )
                       )
                       (i32.const 1)
                      )
                      (else
                       (i32.const 0)
                      )
                     )
                    )
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global538)
                    )
                   )
                   (if (result (ref $type170))
                    (i64.eq
                     (local.get $1)
                     (i64.const 34)
                    )
                    (then
                     (if
                      (i32.eqz
                       (global.get $ready554)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global554)
                      )
                     )
                     (return_call $function163
                      (local.get $0)
                      (i32.const 34)
                      (i32.const 0)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global538)
                      )
                     )
                     (if (result (ref $type170))
                      (i64.eq
                       (local.get $1)
                       (i64.const 124)
                      )
                      (then
                       (if
                        (i32.eqz
                         (global.get $ready554)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global554)
                        )
                       )
                       (return_call $function163
                        (local.get $0)
                        (i32.const 124)
                        (i32.const 1)
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global538)
                        )
                       )
                       (if (result (ref $type170))
                        (i64.eq
                         (local.get $1)
                         (i64.const 35)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready627)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global627)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global530)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global470)
                          )
                         )
                         (local.set $2
                          (call $foreign22
                           (struct.get $type119 0
                            (struct.get $type121 0
                             (local.get $0)
                            )
                           )
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global468)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global532)
                          )
                         )
                         (return
                          (if (result (ref $type163))
                           (i64.lt_s
                            (local.tee $1
                             (if (result i64)
                              (ref.test (ref $type131)
                               (local.tee $7
                                (if (result (ref $type130))
                                 (i32.eq
                                  (local.get $2)
                                  (i32.const -1)
                                 )
                                 (then
                                  (global.get $empty131)
                                 )
                                 (else
                                  (if
                                   (i64.gt_u
                                    (local.tee $1
                                     (i64.extend_i32_s
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 1114111)
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (if
                                   (i32.and
                                    (i64.le_u
                                     (local.get $1)
                                     (i64.const 57343)
                                    )
                                    (i64.ge_u
                                     (local.get $1)
                                     (i64.const 55296)
                                    )
                                   )
                                   (then
                                    (unreachable)
                                   )
                                  )
                                  (struct.new $type132
                                   (i32.wrap_i64
                                    (local.get $1)
                                   )
                                  )
                                 )
                                )
                               )
                              )
                              (then
                               (i64.const -1)
                              )
                              (else
                               (i64.extend_i32_u
                                (struct.get $type132 0
                                 (ref.cast (ref $type132)
                                  (local.get $7)
                                 )
                                )
                               )
                              )
                             )
                            )
                            (i64.const 0)
                           )
                           (then
                            (struct.new $type170
                             (i32.const 6)
                             (global.get $string19)
                            )
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global538)
                             )
                            )
                            (if (result (ref $type163))
                             (i64.eq
                              (local.get $1)
                              (i64.const 40)
                             )
                             (then
                              (struct.new $type168
                               (i32.const 4)
                               (i64.const 1)
                              )
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global538)
                               )
                              )
                              (if (result (ref $type163))
                               (i64.eq
                                (local.get $1)
                                (i64.const 59)
                               )
                               (then
                                (drop
                                 (ref.as_non_null
                                  (global.get $global630)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global525)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready527)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global527)
                                 )
                                )
                                (local.set $12
                                 (call $function154
                                  (local.get $0)
                                 )
                                )
                                (if
                                 (i32.eqz
                                  (global.get $ready702)
                                 )
                                 (then
                                  (unreachable)
                                 )
                                )
                                (drop
                                 (ref.as_non_null
                                  (global.get $global702)
                                 )
                                )
                                (if (result (ref $type170))
                                 (i32.eq
                                  (struct.get $type101 0
                                   (local.tee $10
                                    (call $function196
                                     (local.get $0)
                                     (local.get $12)
                                    )
                                   )
                                  )
                                  (i32.const 1)
                                 )
                                 (then
                                  (drop
                                   (ref.cast (ref $type103)
                                    (local.get $10)
                                   )
                                  )
                                  (br $block)
                                 )
                                 (else
                                  (if (result (ref $type170))
                                   (struct.get $type101 0
                                    (local.get $10)
                                   )
                                   (then
                                    (struct.new $type170
                                     (i32.const 6)
                                     (struct.get $type104 1
                                      (ref.cast (ref $type104)
                                       (local.get $10)
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (struct.new $type170
                                     (i32.const 6)
                                     (global.get $string20)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global538)
                                 )
                                )
                                (if (result (ref $type163))
                                 (i64.eq
                                  (local.get $1)
                                  (i64.const 124)
                                 )
                                 (then
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global635)
                                   )
                                  )
                                  (if (result (ref $type170))
                                   (call $function182
                                    (local.get $0)
                                    (i64.const 1)
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global527)
                                     )
                                    )
                                    (return_call $function154
                                     (local.get $0)
                                    )
                                   )
                                   (else
                                    (struct.new $type170
                                     (i32.const 6)
                                     (global.get $string18)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global538)
                                   )
                                  )
                                  (if (result (ref $type163))
                                   (i64.eq
                                    (local.get $1)
                                    (i64.const 92)
                                   )
                                   (then
                                    (if
                                     (i32.eqz
                                      (global.get $ready640)
                                     )
                                     (then
                                      (unreachable)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global640)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global530)
                                     )
                                    )
                                    (if (result (ref $type163))
                                     (i64.lt_s
                                      (local.tee $1
                                       (call $function155
                                        (local.get $0)
                                       )
                                      )
                                      (i64.const 0)
                                     )
                                     (then
                                      (struct.new $type170
                                       (i32.const 6)
                                       (global.get $string21)
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global643)
                                       )
                                      )
                                      (if (result (ref $type164))
                                       (call $function184
                                        (local.get $1)
                                       )
                                       (then
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (struct.new $type164
                                         (i32.const 0)
                                         (struct.new $type16
                                          (i32.const 2)
                                          (i32.wrap_i64
                                           (local.get $1)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global658)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global562)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global61)
                                         )
                                        )
                                        (local.set $9
                                         (struct.new $type154
                                          (struct.new $type155
                                           (call $string-new
                                            (i32.const 32)
                                           )
                                          )
                                          (struct.new_default $type156)
                                         )
                                        )
                                        (if
                                         (i64.gt_u
                                          (local.get $1)
                                          (i64.const 1114111)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (if
                                         (i32.and
                                          (i64.le_u
                                           (local.get $1)
                                           (i64.const 57343)
                                          )
                                          (i64.ge_u
                                           (local.get $1)
                                           (i64.const 55296)
                                          )
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global611)
                                         )
                                        )
                                        (call $function177
                                         (local.get $9)
                                         (i32.wrap_i64
                                          (local.get $1)
                                         )
                                        )
                                        (local.set $4
                                         (call $function186
                                          (local.get $0)
                                          (local.get $9)
                                          (i32.const 0)
                                          (i32.const 1)
                                         )
                                        )
                                        (if
                                         (i32.eqz
                                          (global.get $ready663)
                                         )
                                         (then
                                          (unreachable)
                                         )
                                        )
                                        (drop
                                         (ref.as_non_null
                                          (global.get $global663)
                                         )
                                        )
                                        (return
                                         (if (result (ref $type163))
                                          (i64.eq
                                           (local.tee $1
                                            (i64.extend_i32_u
                                             (struct.get $type18 1
                                              (local.get $4)
                                             )
                                            )
                                           )
                                           (i64.const 1)
                                          )
                                          (then
                                           (if
                                            (i64.eqz
                                             (local.get $1)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (struct.new $type164
                                            (i32.const 0)
                                            (struct.new $type16
                                             (i32.const 2)
                                             (array.get $type19
                                              (struct.get $type18 2
                                               (local.get $4)
                                              )
                                              (i32.const 0)
                                             )
                                            )
                                           )
                                          )
                                          (else
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global666)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global88)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global81)
                                            )
                                           )
                                           (local.set $4
                                            (call $function189
                                             (if (result (ref $type18))
                                              (i64.lt_s
                                               (local.tee $1
                                                (i64.extend_i32_u
                                                 (struct.get $type18 1
                                                  (local.get $4)
                                                 )
                                                )
                                               )
                                               (local.get $1)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global61)
                                                )
                                               )
                                               (if
                                                (i64.gt_u
                                                 (local.get $1)
                                                 (i64.const 4294967294)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (call $string-copy
                                                (local.tee $5
                                                 (call $string-new
                                                  (i32.wrap_i64
                                                   (local.get $1)
                                                  )
                                                 )
                                                )
                                                (i64.const 0)
                                                (local.get $4)
                                                (local.get $1)
                                               )
                                               (local.get $5)
                                              )
                                             )
                                             (i32.const 0)
                                             (i32.const 1)
                                             (i64.const 0)
                                            )
                                           )
                                           (if
                                            (i32.eqz
                                             (global.get $ready672)
                                            )
                                            (then
                                             (unreachable)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global672)
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global103)
                                            )
                                           )
                                           (if (result (ref $type163))
                                            (struct.get $type181 0
                                             (local.tee $11
                                              (if (result (ref $type181))
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 5)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string31)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                               (then
                                                (struct.new $type182
                                                 (i32.const 0)
                                                 (i32.const 7)
                                                )
                                               )
                                               (else
                                                (drop
                                                 (ref.as_non_null
                                                  (global.get $global103)
                                                 )
                                                )
                                                (if (result (ref $type181))
                                                 (if (result i32)
                                                  (i64.eq
                                                   (i64.extend_i32_u
                                                    (struct.get $type18 1
                                                     (local.get $4)
                                                    )
                                                   )
                                                   (i64.const 9)
                                                  )
                                                  (then
                                                   (call $function40
                                                    (local.get $4)
                                                    (global.get $string30)
                                                    (i32.const 0)
                                                    (i32.const 1)
                                                    (i64.const 0)
                                                   )
                                                  )
                                                  (else
                                                   (i32.const 0)
                                                  )
                                                 )
                                                 (then
                                                  (struct.new $type182
                                                   (i32.const 0)
                                                   (i32.const 8)
                                                  )
                                                 )
                                                 (else
                                                  (drop
                                                   (ref.as_non_null
                                                    (global.get $global103)
                                                   )
                                                  )
                                                  (if (result (ref $type181))
                                                   (if (result i32)
                                                    (i64.eq
                                                     (i64.extend_i32_u
                                                      (struct.get $type18 1
                                                       (local.get $4)
                                                      )
                                                     )
                                                     (i64.const 6)
                                                    )
                                                    (then
                                                     (call $function40
                                                      (local.get $4)
                                                      (global.get $string29)
                                                      (i32.const 0)
                                                      (i32.const 1)
                                                      (i64.const 0)
                                                     )
                                                    )
                                                    (else
                                                     (i32.const 0)
                                                    )
                                                   )
                                                   (then
                                                    (struct.new $type182
                                                     (i32.const 0)
                                                     (i32.const 127)
                                                    )
                                                   )
                                                   (else
                                                    (drop
                                                     (ref.as_non_null
                                                      (global.get $global103)
                                                     )
                                                    )
                                                    (if (result (ref $type181))
                                                     (if (result i32)
                                                      (i64.eq
                                                       (i64.extend_i32_u
                                                        (struct.get $type18 1
                                                         (local.get $4)
                                                        )
                                                       )
                                                       (i64.const 6)
                                                      )
                                                      (then
                                                       (call $function40
                                                        (local.get $4)
                                                        (global.get $string28)
                                                        (i32.const 0)
                                                        (i32.const 1)
                                                        (i64.const 0)
                                                       )
                                                      )
                                                      (else
                                                       (i32.const 0)
                                                      )
                                                     )
                                                     (then
                                                      (struct.new $type182
                                                       (i32.const 0)
                                                       (i32.const 27)
                                                      )
                                                     )
                                                     (else
                                                      (drop
                                                       (ref.as_non_null
                                                        (global.get $global103)
                                                       )
                                                      )
                                                      (if (result (ref $type181))
                                                       (if (result i32)
                                                        (i64.eq
                                                         (i64.extend_i32_u
                                                          (struct.get $type18 1
                                                           (local.get $4)
                                                          )
                                                         )
                                                         (i64.const 7)
                                                        )
                                                        (then
                                                         (call $function40
                                                          (local.get $4)
                                                          (global.get $string27)
                                                          (i32.const 0)
                                                          (i32.const 1)
                                                          (i64.const 0)
                                                         )
                                                        )
                                                        (else
                                                         (i32.const 0)
                                                        )
                                                       )
                                                       (then
                                                        (struct.new $type182
                                                         (i32.const 0)
                                                         (i32.const 10)
                                                        )
                                                       )
                                                       (else
                                                        (drop
                                                         (ref.as_non_null
                                                          (global.get $global103)
                                                         )
                                                        )
                                                        (if (result (ref $type181))
                                                         (if (result i32)
                                                          (i64.eq
                                                           (i64.extend_i32_u
                                                            (struct.get $type18 1
                                                             (local.get $4)
                                                            )
                                                           )
                                                           (i64.const 4)
                                                          )
                                                          (then
                                                           (call $function40
                                                            (local.get $4)
                                                            (global.get $string26)
                                                            (i32.const 0)
                                                            (i32.const 1)
                                                            (i64.const 0)
                                                           )
                                                          )
                                                          (else
                                                           (i32.const 0)
                                                          )
                                                         )
                                                         (then
                                                          (struct.new_default $type182)
                                                         )
                                                         (else
                                                          (drop
                                                           (ref.as_non_null
                                                            (global.get $global103)
                                                           )
                                                          )
                                                          (if (result (ref $type181))
                                                           (if (result i32)
                                                            (i64.eq
                                                             (i64.extend_i32_u
                                                              (struct.get $type18 1
                                                               (local.get $4)
                                                              )
                                                             )
                                                             (i64.const 6)
                                                            )
                                                            (then
                                                             (call $function40
                                                              (local.get $4)
                                                              (global.get $string25)
                                                              (i32.const 0)
                                                              (i32.const 1)
                                                              (i64.const 0)
                                                             )
                                                            )
                                                            (else
                                                             (i32.const 0)
                                                            )
                                                           )
                                                           (then
                                                            (struct.new $type182
                                                             (i32.const 0)
                                                             (i32.const 13)
                                                            )
                                                           )
                                                           (else
                                                            (drop
                                                             (ref.as_non_null
                                                              (global.get $global103)
                                                             )
                                                            )
                                                            (if (result (ref $type181))
                                                             (if (result i32)
                                                              (i64.eq
                                                               (i64.extend_i32_u
                                                                (struct.get $type18 1
                                                                 (local.get $4)
                                                                )
                                                               )
                                                               (i64.const 5)
                                                              )
                                                              (then
                                                               (call $function40
                                                                (local.get $4)
                                                                (global.get $string24)
                                                                (i32.const 0)
                                                                (i32.const 1)
                                                                (i64.const 0)
                                                               )
                                                              )
                                                              (else
                                                               (i32.const 0)
                                                              )
                                                             )
                                                             (then
                                                              (struct.new $type182
                                                               (i32.const 0)
                                                               (i32.const 32)
                                                              )
                                                             )
                                                             (else
                                                              (drop
                                                               (ref.as_non_null
                                                                (global.get $global103)
                                                               )
                                                              )
                                                              (if (result (ref $type181))
                                                               (if (result i32)
                                                                (i64.eq
                                                                 (i64.extend_i32_u
                                                                  (struct.get $type18 1
                                                                   (local.get $4)
                                                                  )
                                                                 )
                                                                 (i64.const 3)
                                                                )
                                                                (then
                                                                 (call $function40
                                                                  (local.get $4)
                                                                  (global.get $string23)
                                                                  (i32.const 0)
                                                                  (i32.const 1)
                                                                  (i64.const 0)
                                                                 )
                                                                )
                                                                (else
                                                                 (i32.const 0)
                                                                )
                                                               )
                                                               (then
                                                                (struct.new $type182
                                                                 (i32.const 0)
                                                                 (i32.const 9)
                                                                )
                                                               )
                                                               (else
                                                                (if
                                                                 (i64.eqz
                                                                  (i64.extend_i32_u
                                                                   (struct.get $type18 1
                                                                    (local.get $4)
                                                                   )
                                                                  )
                                                                 )
                                                                 (then
                                                                  (unreachable)
                                                                 )
                                                                )
                                                                (if (result (ref $type181))
                                                                 (i32.eq
                                                                  (array.get $type19
                                                                   (struct.get $type18 2
                                                                    (local.get $4)
                                                                   )
                                                                   (i32.const 0)
                                                                  )
                                                                  (i32.const 120)
                                                                 )
                                                                 (then
                                                                  (drop
                                                                   (ref.as_non_null
                                                                    (global.get $global674)
                                                                   )
                                                                  )
                                                                  (call $function192
                                                                   (local.get $4)
                                                                   (i32.const 0)
                                                                   (i32.const 1)
                                                                   (i64.const 1)
                                                                   (i64.const 0)
                                                                  )
                                                                 )
                                                                 (else
                                                                  (struct.new $type184
                                                                   (i32.const 2)
                                                                   (global.get $string22)
                                                                  )
                                                                 )
                                                                )
                                                               )
                                                              )
                                                             )
                                                            )
                                                           )
                                                          )
                                                         )
                                                        )
                                                       )
                                                      )
                                                     )
                                                    )
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (if (result (ref $type170))
                                              (i32.eq
                                               (struct.get $type181 0
                                                (local.get $11)
                                               )
                                               (i32.const 2)
                                              )
                                              (then
                                               (struct.new $type170
                                                (i32.const 6)
                                                (struct.get $type184 1
                                                 (ref.cast (ref $type184)
                                                  (local.get $11)
                                                 )
                                                )
                                               )
                                              )
                                              (else
                                               (unreachable)
                                              )
                                             )
                                            )
                                            (else
                                             (struct.new $type164
                                              (i32.const 0)
                                              (struct.new $type16
                                               (i32.const 2)
                                               (struct.get $type182 1
                                                (ref.cast (ref $type182)
                                                 (local.get $11)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global538)
                                     )
                                    )
                                    (if (result (ref $type163))
                                     (if (result i32)
                                      (local.tee $2
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 117)
                                       )
                                      )
                                      (then
                                       (local.get $2)
                                      )
                                      (else
                                       (drop
                                        (ref.as_non_null
                                         (global.get $global538)
                                        )
                                       )
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 85)
                                       )
                                      )
                                     )
                                     (then
                                      (if
                                       (i32.eqz
                                        (global.get $ready684)
                                       )
                                       (then
                                        (unreachable)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global684)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global549)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global552)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global472)
                                       )
                                      )
                                      (local.set $2
                                       (call $foreign23
                                        (struct.get $type119 0
                                         (struct.get $type121 0
                                          (local.get $0)
                                         )
                                        )
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global468)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global532)
                                       )
                                      )
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global538)
                                       )
                                      )
                                      (if (result (ref $type163))
                                       (if (result i32)
                                        (if (result i32)
                                         (i64.eq
                                          (if (result i64)
                                           (ref.test (ref $type131)
                                            (local.tee $7
                                             (if (result (ref $type130))
                                              (i32.eq
                                               (local.get $2)
                                               (i32.const -1)
                                              )
                                              (then
                                               (global.get $empty131)
                                              )
                                              (else
                                               (if
                                                (i64.gt_u
                                                 (local.tee $1
                                                  (i64.extend_i32_s
                                                   (local.get $2)
                                                  )
                                                 )
                                                 (i64.const 1114111)
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (if
                                                (i32.and
                                                 (i64.le_u
                                                  (local.get $1)
                                                  (i64.const 57343)
                                                 )
                                                 (i64.ge_u
                                                  (local.get $1)
                                                  (i64.const 55296)
                                                 )
                                                )
                                                (then
                                                 (unreachable)
                                                )
                                               )
                                               (struct.new $type132
                                                (i32.wrap_i64
                                                 (local.get $1)
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (i64.const -1)
                                           )
                                           (else
                                            (i64.extend_i32_u
                                             (struct.get $type132 0
                                              (ref.cast (ref $type132)
                                               (local.get $7)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i64.const 56)
                                         )
                                         (then
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global470)
                                           )
                                          )
                                          (local.set $2
                                           (call $foreign22
                                            (struct.get $type119 0
                                             (struct.get $type121 0
                                              (local.get $0)
                                             )
                                            )
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global468)
                                           )
                                          )
                                          (drop
                                           (if (result (ref $type130))
                                            (i32.eq
                                             (local.get $2)
                                             (i32.const -1)
                                            )
                                            (then
                                             (global.get $empty131)
                                            )
                                            (else
                                             (if
                                              (i64.gt_u
                                               (local.tee $1
                                                (i64.extend_i32_s
                                                 (local.get $2)
                                                )
                                               )
                                               (i64.const 1114111)
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (if
                                              (i32.and
                                               (i64.le_u
                                                (local.get $1)
                                                (i64.const 57343)
                                               )
                                               (i64.ge_u
                                                (local.get $1)
                                                (i64.const 55296)
                                               )
                                              )
                                              (then
                                               (unreachable)
                                              )
                                             )
                                             (struct.new $type132
                                              (i32.wrap_i64
                                               (local.get $1)
                                              )
                                             )
                                            )
                                           )
                                          )
                                          (i32.const 1)
                                         )
                                         (else
                                          (i32.const 0)
                                         )
                                        )
                                        (then
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global549)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global552)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global472)
                                          )
                                         )
                                         (local.set $2
                                          (call $foreign23
                                           (struct.get $type119 0
                                            (struct.get $type121 0
                                             (local.get $0)
                                            )
                                           )
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global468)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global532)
                                          )
                                         )
                                         (drop
                                          (ref.as_non_null
                                           (global.get $global538)
                                          )
                                         )
                                         (if (result i32)
                                          (i64.eq
                                           (if (result i64)
                                            (ref.test (ref $type131)
                                             (local.tee $7
                                              (if (result (ref $type130))
                                               (i32.eq
                                                (local.get $2)
                                                (i32.const -1)
                                               )
                                               (then
                                                (global.get $empty131)
                                               )
                                               (else
                                                (if
                                                 (i64.gt_u
                                                  (local.tee $1
                                                   (i64.extend_i32_s
                                                    (local.get $2)
                                                   )
                                                  )
                                                  (i64.const 1114111)
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (if
                                                 (i32.and
                                                  (i64.le_u
                                                   (local.get $1)
                                                   (i64.const 57343)
                                                  )
                                                  (i64.ge_u
                                                   (local.get $1)
                                                   (i64.const 55296)
                                                  )
                                                 )
                                                 (then
                                                  (unreachable)
                                                 )
                                                )
                                                (struct.new $type132
                                                 (i32.wrap_i64
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                            (then
                                             (i64.const -1)
                                            )
                                            (else
                                             (i64.extend_i32_u
                                              (struct.get $type132 0
                                               (ref.cast (ref $type132)
                                                (local.get $7)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i64.const 40)
                                          )
                                          (then
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global470)
                                            )
                                           )
                                           (local.set $2
                                            (call $foreign22
                                             (struct.get $type119 0
                                              (struct.get $type121 0
                                               (local.get $0)
                                              )
                                             )
                                            )
                                           )
                                           (drop
                                            (ref.as_non_null
                                             (global.get $global468)
                                            )
                                           )
                                           (drop
                                            (if (result (ref $type130))
                                             (i32.eq
                                              (local.get $2)
                                              (i32.const -1)
                                             )
                                             (then
                                              (global.get $empty131)
                                             )
                                             (else
                                              (if
                                               (i64.gt_u
                                                (local.tee $1
                                                 (i64.extend_i32_s
                                                  (local.get $2)
                                                 )
                                                )
                                                (i64.const 1114111)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (if
                                               (i32.and
                                                (i64.le_u
                                                 (local.get $1)
                                                 (i64.const 57343)
                                                )
                                                (i64.ge_u
                                                 (local.get $1)
                                                 (i64.const 55296)
                                                )
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (struct.new $type132
                                               (i32.wrap_i64
                                                (local.get $1)
                                               )
                                              )
                                             )
                                            )
                                           )
                                           (i32.const 1)
                                          )
                                          (else
                                           (i32.const 0)
                                          )
                                         )
                                        )
                                        (else
                                         (i32.const 0)
                                        )
                                       )
                                       (then
                                        (struct.new $type168
                                         (i32.const 4)
                                         (i64.const 2)
                                        )
                                       )
                                       (else
                                        (struct.new $type170
                                         (i32.const 6)
                                         (global.get $string33)
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (drop
                                       (ref.as_non_null
                                        (global.get $global538)
                                       )
                                      )
                                      (if (result (ref $type163))
                                       (i64.eq
                                        (local.get $1)
                                        (i64.const 33)
                                       )
                                       (then
                                        (struct.new $type170
                                         (i32.const 6)
                                         (global.get $string17)
                                        )
                                       )
                                       (else
                                        (if (result (ref $type163))
                                         (i32.and
                                          (i64.le_s
                                           (local.get $1)
                                           (i64.const 57)
                                          )
                                          (i64.ge_s
                                           (local.get $1)
                                           (i64.const 48)
                                          )
                                         )
                                         (then
                                          (struct.new $type170
                                           (i32.const 6)
                                           (global.get $string16)
                                          )
                                         )
                                         (else
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global658)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global562)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global61)
                                           )
                                          )
                                          (local.set $9
                                           (struct.new $type154
                                            (struct.new $type155
                                             (call $string-new
                                              (i32.const 32)
                                             )
                                            )
                                            (struct.new_default $type156)
                                           )
                                          )
                                          (if
                                           (i64.gt_u
                                            (local.get $1)
                                            (i64.const 1114111)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (if
                                           (i32.and
                                            (i64.le_u
                                             (local.get $1)
                                             (i64.const 57343)
                                            )
                                            (i64.ge_u
                                             (local.get $1)
                                             (i64.const 55296)
                                            )
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global611)
                                           )
                                          )
                                          (call $function177
                                           (local.get $9)
                                           (i32.wrap_i64
                                            (local.get $1)
                                           )
                                          )
                                          (local.set $4
                                           (call $function186
                                            (local.get $0)
                                            (local.get $9)
                                            (i32.const 0)
                                            (i32.const 1)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global90)
                                           )
                                          )
                                          (local.set $5
                                           (call $function35
                                            (struct.new $type50
                                             (global.get $string15)
                                             (struct.new $type50
                                              (local.get $4)
                                              (ref.null none)
                                             )
                                            )
                                           )
                                          )
                                          (if
                                           (i32.eqz
                                            (global.get $ready686)
                                           )
                                           (then
                                            (unreachable)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global686)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global666)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global88)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global81)
                                           )
                                          )
                                          (local.set $4
                                           (call $function189
                                            (if (result (ref $type18))
                                             (i64.lt_s
                                              (local.tee $1
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $5)
                                                )
                                               )
                                              )
                                              (local.get $1)
                                             )
                                             (then
                                              (unreachable)
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global61)
                                               )
                                              )
                                              (if
                                               (i64.gt_u
                                                (local.get $1)
                                                (i64.const 4294967294)
                                               )
                                               (then
                                                (unreachable)
                                               )
                                              )
                                              (call $string-copy
                                               (local.tee $6
                                                (call $string-new
                                                 (i32.wrap_i64
                                                  (local.get $1)
                                                 )
                                                )
                                               )
                                               (i64.const 0)
                                               (local.get $5)
                                               (local.get $1)
                                              )
                                              (local.get $6)
                                             )
                                            )
                                            (i32.const 0)
                                            (i32.const 1)
                                            (i64.const 0)
                                           )
                                          )
                                          (drop
                                           (ref.as_non_null
                                            (global.get $global103)
                                           )
                                          )
                                          (if (result (ref $type163))
                                           (if (result i32)
                                            (local.tee $2
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $4)
                                                )
                                               )
                                               (i64.const 2)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $4)
                                                (global.get $string37)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                            (then
                                             (local.get $2)
                                            )
                                            (else
                                             (drop
                                              (ref.as_non_null
                                               (global.get $global103)
                                              )
                                             )
                                             (if (result i32)
                                              (i64.eq
                                               (i64.extend_i32_u
                                                (struct.get $type18 1
                                                 (local.get $4)
                                                )
                                               )
                                               (i64.const 5)
                                              )
                                              (then
                                               (call $function40
                                                (local.get $4)
                                                (global.get $string38)
                                                (i32.const 0)
                                                (i32.const 1)
                                                (i64.const 0)
                                               )
                                              )
                                              (else
                                               (i32.const 0)
                                              )
                                             )
                                            )
                                           )
                                           (then
                                            (struct.new $type164
                                             (i32.const 0)
                                             (struct.new $type15
                                              (i32.const 1)
                                              (i32.const 1)
                                             )
                                            )
                                           )
                                           (else
                                            (drop
                                             (ref.as_non_null
                                              (global.get $global103)
                                             )
                                            )
                                            (if (result (ref $type163))
                                             (if (result i32)
                                              (local.tee $2
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 2)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string35)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                              (then
                                               (local.get $2)
                                              )
                                              (else
                                               (drop
                                                (ref.as_non_null
                                                 (global.get $global103)
                                                )
                                               )
                                               (if (result i32)
                                                (i64.eq
                                                 (i64.extend_i32_u
                                                  (struct.get $type18 1
                                                   (local.get $4)
                                                  )
                                                 )
                                                 (i64.const 6)
                                                )
                                                (then
                                                 (call $function40
                                                  (local.get $4)
                                                  (global.get $string36)
                                                  (i32.const 0)
                                                  (i32.const 1)
                                                  (i64.const 0)
                                                 )
                                                )
                                                (else
                                                 (i32.const 0)
                                                )
                                               )
                                              )
                                             )
                                             (then
                                              (struct.new $type164
                                               (i32.const 0)
                                               (struct.new $type15
                                                (i32.const 1)
                                                (i32.const 0)
                                               )
                                              )
                                             )
                                             (else
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global308)
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global246)
                                               )
                                              )
                                              (local.set $3
                                               (call $foreign13
                                                (local.tee $2
                                                 (call $function80
                                                  (local.get $5)
                                                 )
                                                )
                                               )
                                              )
                                              (drop
                                               (ref.as_non_null
                                                (global.get $global305)
                                               )
                                              )
                                              (local.set $8
                                               (call $function97
                                                (local.get $2)
                                                (local.get $3)
                                               )
                                              )
                                              (call $foreign4
                                               (local.get $2)
                                              )
                                              (if (result (ref $type163))
                                               (i32.eq
                                                (struct.get $type92 0
                                                 (local.get $8)
                                                )
                                                (i32.const 1)
                                               )
                                               (then
                                                (struct.new $type164
                                                 (i32.const 0)
                                                 (struct.new $type23
                                                  (i32.const 5)
                                                  (struct.get $type94 1
                                                   (ref.cast (ref $type94)
                                                    (local.get $8)
                                                   )
                                                  )
                                                 )
                                                )
                                               )
                                               (else
                                                (if (result (ref $type170))
                                                 (i32.eq
                                                  (struct.get $type92 0
                                                   (local.get $8)
                                                  )
                                                  (i32.const 2)
                                                 )
                                                 (then
                                                  (struct.new $type170
                                                   (i32.const 6)
                                                   (struct.get $type95 1
                                                    (ref.cast (ref $type95)
                                                     (local.get $8)
                                                    )
                                                   )
                                                  )
                                                 )
                                                 (else
                                                  (struct.new $type170
                                                   (i32.const 6)
                                                   (global.get $string34)
                                                  )
                                                 )
                                                )
                                               )
                                              )
                                             )
                                            )
                                           )
                                          )
                                         )
                                        )
                                       )
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                        (else
                         (drop
                          (ref.as_non_null
                           (global.get $global538)
                          )
                         )
                         (if (result (ref $type170))
                          (if (result i32)
                           (local.tee $2
                            (i64.eq
                             (local.get $1)
                             (i64.const 91)
                            )
                           )
                           (then
                            (local.get $2)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global538)
                             )
                            )
                            (if (result i32)
                             (local.tee $2
                              (i64.eq
                               (local.get $1)
                               (i64.const 93)
                              )
                             )
                             (then
                              (local.get $2)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global538)
                               )
                              )
                              (if (result i32)
                               (local.tee $2
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 123)
                                )
                               )
                               (then
                                (local.get $2)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global538)
                                 )
                                )
                                (i64.eq
                                 (local.get $1)
                                 (i64.const 125)
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                          (then
                           (struct.new $type170
                            (i32.const 6)
                            (global.get $string4)
                           )
                          )
                          (else
                           (drop
                            (ref.as_non_null
                             (global.get $global658)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global562)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global61)
                            )
                           )
                           (local.set $9
                            (struct.new $type154
                             (struct.new $type155
                              (call $string-new
                               (i32.const 32)
                              )
                             )
                             (struct.new_default $type156)
                            )
                           )
                           (if
                            (i64.gt_u
                             (local.get $1)
                             (i64.const 1114111)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (if
                            (i32.and
                             (i64.le_u
                              (local.get $1)
                              (i64.const 57343)
                             )
                             (i64.ge_u
                              (local.get $1)
                              (i64.const 55296)
                             )
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global611)
                            )
                           )
                           (call $function177
                            (local.get $9)
                            (i32.wrap_i64
                             (local.get $1)
                            )
                           )
                           (local.set $4
                            (call $function186
                             (local.get $0)
                             (local.get $9)
                             (i32.const 0)
                             (i32.const 1)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready697)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global697)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global103)
                            )
                           )
                           (return
                            (if (result (ref $type163))
                             (if (result i32)
                              (i64.eq
                               (i64.extend_i32_u
                                (struct.get $type18 1
                                 (local.get $4)
                                )
                               )
                               (i64.const 1)
                              )
                              (then
                               (call $function40
                                (local.get $4)
                                (global.get $string39)
                                (i32.const 0)
                                (i32.const 1)
                                (i64.const 0)
                               )
                              )
                              (else
                               (i32.const 0)
                              )
                             )
                             (then
                              (global.get $empty167)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global347)
                               )
                              )
                              (drop
                               (ref.as_non_null
                                (global.get $global246)
                               )
                              )
                              (if (result (ref $type163))
                               (i32.eq
                                (struct.get $type101 0
                                 (local.tee $10
                                  (if (result (ref $type101))
                                   (local.tee $3
                                    (call $foreign13
                                     (local.tee $2
                                      (call $function80
                                       (local.get $4)
                                      )
                                     )
                                    )
                                   )
                                   (then
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global340)
                                     )
                                    )
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global305)
                                     )
                                    )
                                    (local.set $8
                                     (call $function97
                                      (local.get $2)
                                      (local.get $3)
                                     )
                                    )
                                    (call $foreign4
                                     (local.get $2)
                                    )
                                    (if (result (ref $type101))
                                     (i32.eq
                                      (struct.get $type92 0
                                       (local.get $8)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (struct.new $type103
                                       (i32.const 1)
                                       (struct.new $type23
                                        (i32.const 5)
                                        (struct.get $type94 1
                                         (ref.cast (ref $type94)
                                          (local.get $8)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (if (result (ref $type104))
                                       (i32.eq
                                        (struct.get $type92 0
                                         (local.get $8)
                                        )
                                        (i32.const 2)
                                       )
                                       (then
                                        (struct.new $type104
                                         (i32.const 2)
                                         (struct.get $type95 1
                                          (ref.cast (ref $type95)
                                           (local.get $8)
                                          )
                                         )
                                        )
                                       )
                                       (else
                                        (unreachable)
                                       )
                                      )
                                     )
                                    )
                                   )
                                   (else
                                    (if (result (ref $type101))
                                     (i32.eq
                                      (call $foreign3
                                       (local.get $2)
                                      )
                                      (i32.const 1)
                                     )
                                     (then
                                      (struct.new $type103
                                       (i32.const 1)
                                       (struct.new $type21
                                        (i32.const 4)
                                        (struct.new $type22
                                         (call $foreign5
                                          (local.get $2)
                                         )
                                        )
                                       )
                                      )
                                     )
                                     (else
                                      (call $foreign4
                                       (local.get $2)
                                      )
                                      (struct.new $type104
                                       (i32.const 2)
                                       (global.get $string1)
                                      )
                                     )
                                    )
                                   )
                                  )
                                 )
                                )
                                (i32.const 1)
                               )
                               (then
                                (struct.new $type164
                                 (i32.const 0)
                                 (struct.get $type103 1
                                  (ref.cast (ref $type103)
                                   (local.get $10)
                                  )
                                 )
                                )
                               )
                               (else
                                (if (result (ref $type170))
                                 (i32.eq
                                  (struct.get $type101 0
                                   (local.get $10)
                                  )
                                  (i32.const 2)
                                 )
                                 (then
                                  (struct.new $type170
                                   (i32.const 6)
                                   (struct.get $type104 1
                                    (ref.cast (ref $type104)
                                     (local.get $10)
                                    )
                                   )
                                  )
                                 )
                                 (else
                                  (unreachable)
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (unreachable)
     )
    )
   )
  )
  (if
   (i32.eqz
    (global.get $ready527)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (return_call $function154
   (local.get $0)
  )
 )
 (func $function155 (type $call128) (param $0 (ref $type121)) (result i64)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type130))
  (drop
   (ref.as_non_null
    (global.get $global470)
   )
  )
  (local.set $2
   (call $foreign22
    (struct.get $type119 0
     (struct.get $type121 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (if (result i64)
   (ref.test (ref $type131)
    (local.tee $3
     (if (result (ref $type130))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty131)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type132
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (then
    (i64.const -1)
   )
   (else
    (i64.extend_i32_u
     (struct.get $type132 0
      (ref.cast (ref $type132)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function159 (type $call123) (param $0 (ref $type121)) (result i32)
  (local $1 i32)
  (local $2 i64)
  (local $3 (ref $type130))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global470)
   )
  )
  (local.set $1
   (call $foreign22
    (struct.get $type119 0
     (struct.get $type121 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $1
     (i64.lt_s
      (local.tee $2
       (if (result i64)
        (ref.test (ref $type131)
         (local.tee $3
          (if (result (ref $type130))
           (i32.eq
            (local.get $1)
            (i32.const -1)
           )
           (then
            (global.get $empty131)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $1)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type132
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type132 0
           (ref.cast (ref $type132)
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
    )
    (then
     (local.get $1)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (if (result i32)
      (local.tee $1
       (i64.eq
        (local.get $2)
        (i64.const 10)
       )
      )
      (then
       (local.get $1)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global538)
        )
       )
       (i64.eq
        (local.get $2)
        (i64.const 13)
       )
      )
     )
    )
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready541)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global541)
     )
    )
    (return_call $function159
     (local.get $0)
    )
   )
  )
 )
 (func $function163 (type $call173) (param $0 (ref $type121)) (param $1 i32) (param $2 i32) (result (ref $type163))
  (local $3 (ref $type175))
  (local $4 (ref $type18))
  (local $5 (ref $type154))
  (if
   (i32.eqz
    (global.get $ready559)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global559)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global562)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (local.set $5
   (struct.new $type154
    (struct.new $type155
     (call $string-new
      (i32.const 32)
     )
    )
    (struct.new_default $type156)
   )
  )
  (if
   (i32.eqz
    (global.get $ready563)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global563)
   )
  )
  (if (result (ref $type163))
   (ref.test (ref $type176)
    (local.tee $3
     (call $function166
      (local.get $0)
      (local.get $1)
      (local.get $5)
     )
    )
   )
   (then
    (local.set $4
     (struct.get $type176 0
      (ref.cast (ref $type176)
       (local.get $3)
      )
     )
    )
    (struct.new $type164
     (i32.const 0)
     (if (result (ref $type13))
      (local.get $2)
      (then
       (drop
        (ref.as_non_null
         (global.get $global258)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global246)
        )
       )
       (struct.new $type21
        (i32.const 4)
        (struct.new $type22
         (call $foreign5
          (call $function80
           (local.get $4)
          )
         )
        )
       )
      )
      (else
       (struct.new $type17
        (i32.const 3)
        (local.get $4)
       )
      )
     )
    )
   )
   (else
    (struct.new $type170
     (i32.const 6)
     (struct.get $type177 0
      (ref.cast (ref $type177)
       (local.get $3)
      )
     )
    )
   )
  )
 )
 (func $function166 (type $call178) (param $0 (ref $type121)) (param $1 i32) (param $2 (ref $type154)) (result (ref $type175))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type130))
  (local $6 (ref $type181))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global470)
   )
  )
  (local.set $4
   (call $foreign22
    (struct.get $type119 0
     (struct.get $type121 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (block $block
   (return
    (if (result (ref $type175))
     (i64.lt_s
      (local.tee $3
       (if (result i64)
        (ref.test (ref $type131)
         (local.tee $5
          (if (result (ref $type130))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty131)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $3
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $3)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $3)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type132
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type132 0
           (ref.cast (ref $type132)
            (local.get $5)
           )
          )
         )
        )
       )
      )
      (i64.const 0)
     )
     (then
      (struct.new $type177
       (global.get $string9)
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result (ref $type175))
       (i64.eq
        (i64.extend_i32_u
         (local.get $1)
        )
        (local.get $3)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global568)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global81)
         )
        )
        (local.set $7
         (struct.get $type155 0
          (struct.get $type154 0
           (local.get $2)
          )
         )
        )
        (struct.new $type176
         (if (result (ref $type18))
          (if (result i32)
           (local.tee $1
            (i64.lt_s
             (local.tee $3
              (struct.get $type156 0
               (struct.get $type154 1
                (local.get $2)
               )
              )
             )
             (i64.const 0)
            )
           )
           (then
            (local.get $1)
           )
           (else
            (i64.lt_s
             (i64.extend_i32_u
              (struct.get $type18 1
               (local.get $7)
              )
             )
             (local.get $3)
            )
           )
          )
          (then
           (unreachable)
          )
          (else
           (drop
            (ref.as_non_null
             (global.get $global61)
            )
           )
           (if
            (i64.gt_u
             (local.get $3)
             (i64.const 4294967294)
            )
            (then
             (unreachable)
            )
           )
           (call $string-copy
            (local.tee $8
             (call $string-new
              (i32.wrap_i64
               (local.get $3)
              )
             )
            )
            (i64.const 0)
            (local.get $7)
            (local.get $3)
           )
           (local.get $8)
          )
         )
        )
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (if (result (ref $type177))
         (i64.eq
          (local.get $3)
          (i64.const 92)
         )
         (then
          (if
           (i32.eqz
            (global.get $ready570)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global570)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global530)
           )
          )
          (local.set $3
           (call $function155
            (local.get $0)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global538)
           )
          )
          (local.set $6
           (if (result (ref $type181))
            (i64.eq
             (local.get $3)
             (i64.const 97)
            )
            (then
             (struct.new $type182
              (i32.const 0)
              (i32.const 7)
             )
            )
            (else
             (drop
              (ref.as_non_null
               (global.get $global538)
              )
             )
             (if (result (ref $type181))
              (i64.eq
               (local.get $3)
               (i64.const 98)
              )
              (then
               (struct.new $type182
                (i32.const 0)
                (i32.const 8)
               )
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global538)
                )
               )
               (if (result (ref $type181))
                (i64.eq
                 (local.get $3)
                 (i64.const 116)
                )
                (then
                 (struct.new $type182
                  (i32.const 0)
                  (i32.const 9)
                 )
                )
                (else
                 (drop
                  (ref.as_non_null
                   (global.get $global538)
                  )
                 )
                 (if (result (ref $type181))
                  (i64.eq
                   (local.get $3)
                   (i64.const 110)
                  )
                  (then
                   (struct.new $type182
                    (i32.const 0)
                    (i32.const 10)
                   )
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global538)
                    )
                   )
                   (if (result (ref $type181))
                    (i64.eq
                     (local.get $3)
                     (i64.const 114)
                    )
                    (then
                     (struct.new $type182
                      (i32.const 0)
                      (i32.const 13)
                     )
                    )
                    (else
                     (drop
                      (ref.as_non_null
                       (global.get $global538)
                      )
                     )
                     (if (result (ref $type181))
                      (if (result i32)
                       (local.tee $4
                        (i64.eq
                         (local.get $3)
                         (i64.const 34)
                        )
                       )
                       (then
                        (local.get $4)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global538)
                         )
                        )
                        (if (result i32)
                         (local.tee $4
                          (i64.eq
                           (local.get $3)
                           (i64.const 124)
                          )
                         )
                         (then
                          (local.get $4)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global538)
                           )
                          )
                          (i64.eq
                           (local.get $3)
                           (i64.const 92)
                          )
                         )
                        )
                       )
                      )
                      (then
                       (if
                        (i64.gt_u
                         (local.get $3)
                         (i64.const 1114111)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (if
                        (i32.and
                         (i64.le_u
                          (local.get $3)
                          (i64.const 57343)
                         )
                         (i64.ge_u
                          (local.get $3)
                          (i64.const 55296)
                         )
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (struct.new $type182
                        (i32.const 0)
                        (i32.wrap_i64
                         (local.get $3)
                        )
                       )
                      )
                      (else
                       (drop
                        (ref.as_non_null
                         (global.get $global538)
                        )
                       )
                       (if (result (ref $type181))
                        (i64.eq
                         (local.get $3)
                         (i64.const 120)
                        )
                        (then
                         (if
                          (i32.eqz
                           (global.get $ready576)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global576)
                          )
                         )
                         (call $function169
                          (local.get $0)
                          (i64.const 0)
                          (i64.const 0)
                         )
                        )
                        (else
                         (if (result (ref $type181))
                          (if (result i32)
                           (i32.eq
                            (local.get $1)
                            (i32.const 34)
                           )
                           (then
                            (if
                             (i32.eqz
                              (global.get $ready591)
                             )
                             (then
                              (unreachable)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global591)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global538)
                             )
                            )
                            (if (result i32)
                             (local.tee $4
                              (i64.eq
                               (local.get $3)
                               (i64.const 32)
                              )
                             )
                             (then
                              (local.get $4)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global538)
                               )
                              )
                              (if (result i32)
                               (local.tee $4
                                (i64.eq
                                 (local.get $3)
                                 (i64.const 9)
                                )
                               )
                               (then
                                (local.get $4)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global538)
                                 )
                                )
                                (if (result i32)
                                 (local.tee $4
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 10)
                                  )
                                 )
                                 (then
                                  (local.get $4)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global538)
                                   )
                                  )
                                  (i64.eq
                                   (local.get $3)
                                   (i64.const 13)
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                           (else
                            (i32.const 0)
                           )
                          )
                          (then
                           (if
                            (i32.eqz
                             (global.get $ready596)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global596)
                            )
                           )
                           (call $function174
                            (local.get $0)
                            (local.get $3)
                           )
                          )
                          (else
                           (struct.new $type184
                            (i32.const 2)
                            (global.get $string10)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready604)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global604)
           )
          )
          (if (result (ref $type177))
           (local.tee $4
            (struct.get $type181 0
             (local.get $6)
            )
           )
           (then
            (if (result (ref $type177))
             (i32.eq
              (local.get $4)
              (i32.const 1)
             )
             (then
              (br $block)
             )
             (else
              (struct.new $type177
               (struct.get $type184 1
                (ref.cast (ref $type184)
                 (local.get $6)
                )
               )
              )
             )
            )
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global611)
             )
            )
            (call $function177
             (local.get $2)
             (struct.get $type182 1
              (ref.cast (ref $type182)
               (local.get $6)
              )
             )
            )
            (br $block)
           )
          )
         )
         (else
          (if
           (i32.eqz
            (global.get $ready621)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global621)
           )
          )
          (local.set $4
           (if (result i32)
            (if (result i32)
             (i32.eq
              (local.get $1)
              (i32.const 34)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global538)
               )
              )
              (i64.eq
               (local.get $3)
               (i64.const 13)
              )
             )
             (else
              (i32.const 0)
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global549)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global552)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global472)
              )
             )
             (local.set $4
              (call $foreign23
               (struct.get $type119 0
                (struct.get $type121 0
                 (local.get $0)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global468)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global532)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global538)
              )
             )
             (if
              (i64.eq
               (if (result i64)
                (ref.test (ref $type131)
                 (local.tee $5
                  (if (result (ref $type130))
                   (i32.eq
                    (local.get $4)
                    (i32.const -1)
                   )
                   (then
                    (global.get $empty131)
                   )
                   (else
                    (if
                     (i64.gt_u
                      (local.tee $3
                       (i64.extend_i32_s
                        (local.get $4)
                       )
                      )
                      (i64.const 1114111)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (if
                     (i32.and
                      (i64.le_u
                       (local.get $3)
                       (i64.const 57343)
                      )
                      (i64.ge_u
                       (local.get $3)
                       (i64.const 55296)
                      )
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (struct.new $type132
                     (i32.wrap_i64
                      (local.get $3)
                     )
                    )
                   )
                  )
                 )
                )
                (then
                 (i64.const -1)
                )
                (else
                 (i64.extend_i32_u
                  (struct.get $type132 0
                   (ref.cast (ref $type132)
                    (local.get $5)
                   )
                  )
                 )
                )
               )
               (i64.const 10)
              )
              (then
               (drop
                (ref.as_non_null
                 (global.get $global470)
                )
               )
               (local.set $4
                (call $foreign22
                 (struct.get $type119 0
                  (struct.get $type121 0
                   (local.get $0)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global468)
                )
               )
               (drop
                (if (result (ref $type130))
                 (i32.eq
                  (local.get $4)
                  (i32.const -1)
                 )
                 (then
                  (global.get $empty131)
                 )
                 (else
                  (if
                   (i64.gt_u
                    (local.tee $3
                     (i64.extend_i32_s
                      (local.get $4)
                     )
                    )
                    (i64.const 1114111)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (if
                   (i32.and
                    (i64.le_u
                     (local.get $3)
                     (i64.const 57343)
                    )
                    (i64.ge_u
                     (local.get $3)
                     (i64.const 55296)
                    )
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (struct.new $type132
                   (i32.wrap_i64
                    (local.get $3)
                   )
                  )
                 )
                )
               )
              )
             )
             (i32.const 10)
            )
            (else
             (if
              (i64.gt_u
               (local.get $3)
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $3)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $3)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (i32.wrap_i64
              (local.get $3)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global611)
           )
          )
          (call $function177
           (local.get $2)
           (local.get $4)
          )
          (if
           (i32.eqz
            (global.get $ready563)
           )
           (then
            (unreachable)
           )
          )
          (br $block)
         )
        )
       )
      )
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global563)
   )
  )
  (return_call $function166
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $function169 (type $call188) (param $0 (ref $type121)) (param $1 i64) (param $2 i64) (result (ref $type181))
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type130))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global470)
   )
  )
  (local.set $4
   (call $foreign22
    (struct.get $type119 0
     (struct.get $type121 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result (ref $type181))
   (i64.eq
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type131)
       (local.tee $5
        (if (result (ref $type130))
         (i32.eq
          (local.get $4)
          (i32.const -1)
         )
         (then
          (global.get $empty131)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $3
             (i64.extend_i32_s
              (local.get $4)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $3)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $3)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type132
           (i32.wrap_i64
            (local.get $3)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type132 0
         (ref.cast (ref $type132)
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (i64.const 59)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global581)
     )
    )
    (if (result (ref $type181))
     (if (result i32)
      (i64.gt_s
       (local.get $2)
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global584)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $1)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $1)
           (i64.const 1114111)
          )
          (then
           (if (result i32)
            (local.tee $4
             (i64.lt_s
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (local.get $4)
            )
            (else
             (i64.gt_s
              (local.get $1)
              (i64.const 57343)
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $1)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $1)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $1)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type182
       (i32.const 0)
       (i32.wrap_i64
        (local.get $1)
       )
      )
     )
     (else
      (struct.new $type184
       (i32.const 2)
       (global.get $string12)
      )
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global588)
     )
    )
    (if (result (ref $type184))
     (if (result i32)
      (local.tee $4
       (i64.lt_s
        (local.tee $3
         (if (result i64)
          (i32.and
           (i64.le_s
            (local.get $3)
            (i64.const 57)
           )
           (i64.ge_s
            (local.get $3)
            (i64.const 48)
           )
          )
          (then
           (i64.sub
            (local.get $3)
            (i64.const 48)
           )
          )
          (else
           (if (result i64)
            (i32.and
             (i64.le_s
              (local.get $3)
              (i64.const 70)
             )
             (i64.ge_s
              (local.get $3)
              (i64.const 65)
             )
            )
            (then
             (i64.sub
              (local.get $3)
              (i64.const 55)
             )
            )
            (else
             (select
              (i64.sub
               (local.get $3)
               (i64.const 87)
              )
              (i64.const -1)
              (i32.and
               (i64.le_s
                (local.get $3)
                (i64.const 102)
               )
               (i64.ge_s
                (local.get $3)
                (i64.const 97)
               )
              )
             )
            )
           )
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $4)
      )
      (else
       (i64.gt_s
        (local.get $1)
        (i64.const 69631)
       )
      )
     )
     (then
      (struct.new $type184
       (i32.const 2)
       (global.get $string11)
      )
     )
     (else
      (if
       (i32.eqz
        (global.get $ready576)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global576)
       )
      )
      (return_call $function169
       (local.get $0)
       (i64.add
        (local.get $3)
        (i64.shl
         (local.get $1)
         (i64.const 4)
        )
       )
       (i64.add
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function174 (type $call186) (param $0 (ref $type121)) (param $1 i64) (result (ref $type181))
  (local $2 i32)
  (local $3 (ref $type130))
  (drop
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result (ref $type181))
   (if (result i32)
    (local.tee $2
     (i64.eq
      (local.get $1)
      (i64.const 32)
     )
    )
    (then
     (local.get $2)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (i64.eq
      (local.get $1)
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global530)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global470)
     )
    )
    (local.set $2
     (call $foreign22
      (struct.get $type119 0
       (struct.get $type121 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global468)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global532)
     )
    )
    (local.set $1
     (if (result i64)
      (ref.test (ref $type131)
       (local.tee $3
        (if (result (ref $type130))
         (i32.eq
          (local.get $2)
          (i32.const -1)
         )
         (then
          (global.get $empty131)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $1
             (i64.extend_i32_s
              (local.get $2)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $1)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $1)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type132
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type132 0
         (ref.cast (ref $type132)
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready596)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global596)
     )
    )
    (return_call $function174
     (local.get $0)
     (local.get $1)
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (if (result (ref $type181))
     (if (result i32)
      (local.tee $2
       (i64.eq
        (local.get $1)
        (i64.const 10)
       )
      )
      (then
       (local.get $2)
      )
      (else
       (drop
        (ref.as_non_null
         (global.get $global538)
        )
       )
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if
       (i64.eq
        (local.get $1)
        (i64.const 13)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global549)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global552)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global472)
         )
        )
        (local.set $2
         (call $foreign23
          (struct.get $type119 0
           (struct.get $type121 0
            (local.get $0)
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global468)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global532)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (if
         (i64.eq
          (if (result i64)
           (ref.test (ref $type131)
            (local.tee $3
             (if (result (ref $type130))
              (i32.eq
               (local.get $2)
               (i32.const -1)
              )
              (then
               (global.get $empty131)
              )
              (else
               (if
                (i64.gt_u
                 (local.tee $1
                  (i64.extend_i32_s
                   (local.get $2)
                  )
                 )
                 (i64.const 1114111)
                )
                (then
                 (unreachable)
                )
               )
               (if
                (i32.and
                 (i64.le_u
                  (local.get $1)
                  (i64.const 57343)
                 )
                 (i64.ge_u
                  (local.get $1)
                  (i64.const 55296)
                 )
                )
                (then
                 (unreachable)
                )
               )
               (struct.new $type132
                (i32.wrap_i64
                 (local.get $1)
                )
               )
              )
             )
            )
           )
           (then
            (i64.const -1)
           )
           (else
            (i64.extend_i32_u
             (struct.get $type132 0
              (ref.cast (ref $type132)
               (local.get $3)
              )
             )
            )
           )
          )
          (i64.const 10)
         )
         (then
          (drop
           (ref.as_non_null
            (global.get $global470)
           )
          )
          (local.set $2
           (call $foreign22
            (struct.get $type119 0
             (struct.get $type121 0
              (local.get $0)
             )
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global468)
           )
          )
          (drop
           (if (result (ref $type130))
            (i32.eq
             (local.get $2)
             (i32.const -1)
            )
            (then
             (global.get $empty131)
            )
            (else
             (if
              (i64.gt_u
               (local.tee $1
                (i64.extend_i32_s
                 (local.get $2)
                )
               )
               (i64.const 1114111)
              )
              (then
               (unreachable)
              )
             )
             (if
              (i32.and
               (i64.le_u
                (local.get $1)
                (i64.const 57343)
               )
               (i64.ge_u
                (local.get $1)
                (i64.const 55296)
               )
              )
              (then
               (unreachable)
              )
             )
             (struct.new $type132
              (i32.wrap_i64
               (local.get $1)
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global601)
       )
      )
      (drop
       (call $function175
        (local.get $0)
       )
      )
      (global.get $empty183)
     )
     (else
      (struct.new $type184
       (i32.const 2)
       (global.get $string13)
      )
     )
    )
   )
  )
 )
 (func $function175 (type $call123) (param $0 (ref $type121)) (result i32)
  (local $1 i64)
  (local $2 i32)
  (local $3 (ref $type130))
  (drop
   (ref.as_non_null
    (global.get $global552)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global472)
   )
  )
  (local.set $2
   (call $foreign23
    (struct.get $type119 0
     (struct.get $type121 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global538)
   )
  )
  (if (result i32)
   (if (result i32)
    (local.tee $2
     (i64.eq
      (if (result i64)
       (ref.test (ref $type131)
        (local.tee $3
         (if (result (ref $type130))
          (i32.eq
           (local.get $2)
           (i32.const -1)
          )
          (then
           (global.get $empty131)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $1
              (i64.extend_i32_s
               (local.get $2)
              )
             )
             (i64.const 1114111)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.and
             (i64.le_u
              (local.get $1)
              (i64.const 57343)
             )
             (i64.ge_u
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.new $type132
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type132 0
          (ref.cast (ref $type132)
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 32)
     )
    )
    (then
     (local.get $2)
    )
    (else
     (drop
      (ref.as_non_null
       (global.get $global552)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global472)
      )
     )
     (local.set $2
      (call $foreign23
       (struct.get $type119 0
        (struct.get $type121 0
         (local.get $0)
        )
       )
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global468)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global532)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global538)
      )
     )
     (i64.eq
      (if (result i64)
       (ref.test (ref $type131)
        (local.tee $3
         (if (result (ref $type130))
          (i32.eq
           (local.get $2)
           (i32.const -1)
          )
          (then
           (global.get $empty131)
          )
          (else
           (if
            (i64.gt_u
             (local.tee $1
              (i64.extend_i32_s
               (local.get $2)
              )
             )
             (i64.const 1114111)
            )
            (then
             (unreachable)
            )
           )
           (if
            (i32.and
             (i64.le_u
              (local.get $1)
              (i64.const 57343)
             )
             (i64.ge_u
              (local.get $1)
              (i64.const 55296)
             )
            )
            (then
             (unreachable)
            )
           )
           (struct.new $type132
            (i32.wrap_i64
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (i64.const -1)
       )
       (else
        (i64.extend_i32_u
         (struct.get $type132 0
          (ref.cast (ref $type132)
           (local.get $3)
          )
         )
        )
       )
      )
      (i64.const 9)
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global470)
     )
    )
    (local.set $2
     (call $foreign22
      (struct.get $type119 0
       (struct.get $type121 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global468)
     )
    )
    (drop
     (if (result (ref $type130))
      (i32.eq
       (local.get $2)
       (i32.const -1)
      )
      (then
       (global.get $empty131)
      )
      (else
       (if
        (i64.gt_u
         (local.tee $1
          (i64.extend_i32_s
           (local.get $2)
          )
         )
         (i64.const 1114111)
        )
        (then
         (unreachable)
        )
       )
       (if
        (i32.and
         (i64.le_u
          (local.get $1)
          (i64.const 57343)
         )
         (i64.ge_u
          (local.get $1)
          (i64.const 55296)
         )
        )
        (then
         (unreachable)
        )
       )
       (struct.new $type132
        (i32.wrap_i64
         (local.get $1)
        )
       )
      )
     )
    )
    (if
     (i32.eqz
      (global.get $ready601)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global601)
     )
    )
    (return_call $function175
     (local.get $0)
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $function177 (type $29) (param $0 (ref $type154)) (param $1 i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type155))
  (if
   (i64.eq
    (local.tee $2
     (struct.get $type156 0
      (struct.get $type154 1
       (local.get $0)
      )
     )
    )
    (i64.extend_i32_u
     (struct.get $type18 1
      (struct.get $type155 0
       (struct.get $type154 0
        (local.get $0)
       )
      )
     )
    )
   )
   (then
    (if
     (i32.eqz
      (global.get $ready615)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global615)
     )
    )
    (if
     (i64.ge_s
      (local.get $2)
      (i64.const 4294967294)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global252)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global246)
       )
      )
      (call $foreign2
       (call $function80
        (global.get $string14)
       )
      )
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.tee $3
         (select
          (i64.const 4294967294)
          (i64.shl
           (local.get $2)
           (i64.const 1)
          )
          (i64.gt_s
           (local.get $2)
           (i64.const 2147483647)
          )
         )
        )
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $6
        (call $string-new
         (i32.wrap_i64
          (local.get $3)
         )
        )
       )
       (i64.const 0)
       (struct.get $type155 0
        (local.tee $7
         (struct.get $type154 0
          (local.get $0)
         )
        )
       )
       (local.get $2)
      )
      (struct.set $type155 0
       (local.get $7)
       (local.get $6)
      )
     )
    )
   )
  )
  (if
   (i32.ne
    (struct.get $type18 0
     (local.tee $5
      (struct.get $type155 0
       (struct.get $type154 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i64.ge_u
    (local.get $2)
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $5)
     )
    )
   )
   (then
    (unreachable)
   )
  )
  (array.set $type19
   (if (result (ref $type19))
    (i32.lt_u
     (local.tee $4
      (i32.wrap_i64
       (local.get $2)
      )
     )
     (i32.const 8192)
    )
    (then
     (struct.get $type18 2
      (local.get $5)
     )
    )
    (else
     (ref.as_non_null
      (array.get $type20
       (struct.get $type18 3
        (local.get $5)
       )
       (i32.sub
        (i32.shr_u
         (local.get $4)
         (i32.const 13)
        )
        (i32.const 1)
       )
      )
     )
    )
   )
   (i32.and
    (local.get $4)
    (i32.const 8191)
   )
   (local.get $1)
  )
  (struct.set $type156 0
   (struct.get $type154 1
    (local.get $0)
   )
   (i64.add
    (local.get $2)
    (i64.const 1)
   )
  )
 )
 (func $function182 (type $call161) (param $0 (ref $type121)) (param $1 i64) (result i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 i32)
  (local $5 (ref $type130))
  (drop
   (ref.as_non_null
    (global.get $global530)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global470)
   )
  )
  (local.set $4
   (call $foreign22
    (struct.get $type119 0
     (struct.get $type121 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (if (result i32)
   (i64.lt_s
    (local.tee $3
     (if (result i64)
      (ref.test (ref $type131)
       (local.tee $5
        (if (result (ref $type130))
         (i32.eq
          (local.get $4)
          (i32.const -1)
         )
         (then
          (global.get $empty131)
         )
         (else
          (if
           (i64.gt_u
            (local.tee $2
             (i64.extend_i32_s
              (local.get $4)
             )
            )
            (i64.const 1114111)
           )
           (then
            (unreachable)
           )
          )
          (if
           (i32.and
            (i64.le_u
             (local.get $2)
             (i64.const 57343)
            )
            (i64.ge_u
             (local.get $2)
             (i64.const 55296)
            )
           )
           (then
            (unreachable)
           )
          )
          (struct.new $type132
           (i32.wrap_i64
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (then
       (i64.const -1)
      )
      (else
       (i64.extend_i32_u
        (struct.get $type132 0
         (ref.cast (ref $type132)
          (local.get $5)
         )
        )
       )
      )
     )
    )
    (i64.const 0)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global538)
     )
    )
    (if (result i32)
     (if (result i32)
      (i64.eq
       (local.get $3)
       (i64.const 35)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global549)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global552)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global472)
        )
       )
       (local.set $4
        (call $foreign23
         (struct.get $type119 0
          (struct.get $type121 0
           (local.get $0)
          )
         )
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global468)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global532)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global538)
        )
       )
       (if (result i32)
        (i64.eq
         (if (result i64)
          (ref.test (ref $type131)
           (local.tee $5
            (if (result (ref $type130))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty131)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type132
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
          )
          (then
           (i64.const -1)
          )
          (else
           (i64.extend_i32_u
            (struct.get $type132 0
             (ref.cast (ref $type132)
              (local.get $5)
             )
            )
           )
          )
         )
         (i64.const 124)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global470)
          )
         )
         (local.set $4
          (call $foreign22
           (struct.get $type119 0
            (struct.get $type121 0
             (local.get $0)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global468)
          )
         )
         (drop
          (if (result (ref $type130))
           (i32.eq
            (local.get $4)
            (i32.const -1)
           )
           (then
            (global.get $empty131)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $2
               (i64.extend_i32_s
                (local.get $4)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $2)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $2)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type132
             (i32.wrap_i64
              (local.get $2)
             )
            )
           )
          )
         )
         (i32.const 1)
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i32.eqz
        (global.get $ready635)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global635)
       )
      )
      (return_call $function182
       (local.get $0)
       (i64.add
        (local.get $1)
        (i64.const 1)
       )
      )
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result i32)
       (if (result i32)
        (i64.eq
         (local.get $3)
         (i64.const 124)
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global549)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global552)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global472)
          )
         )
         (local.set $4
          (call $foreign23
           (struct.get $type119 0
            (struct.get $type121 0
             (local.get $0)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global468)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global532)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global538)
          )
         )
         (if (result i32)
          (i64.eq
           (if (result i64)
            (ref.test (ref $type131)
             (local.tee $5
              (if (result (ref $type130))
               (i32.eq
                (local.get $4)
                (i32.const -1)
               )
               (then
                (global.get $empty131)
               )
               (else
                (if
                 (i64.gt_u
                  (local.tee $2
                   (i64.extend_i32_s
                    (local.get $4)
                   )
                  )
                  (i64.const 1114111)
                 )
                 (then
                  (unreachable)
                 )
                )
                (if
                 (i32.and
                  (i64.le_u
                   (local.get $2)
                   (i64.const 57343)
                  )
                  (i64.ge_u
                   (local.get $2)
                   (i64.const 55296)
                  )
                 )
                 (then
                  (unreachable)
                 )
                )
                (struct.new $type132
                 (i32.wrap_i64
                  (local.get $2)
                 )
                )
               )
              )
             )
            )
            (then
             (i64.const -1)
            )
            (else
             (i64.extend_i32_u
              (struct.get $type132 0
               (ref.cast (ref $type132)
                (local.get $5)
               )
              )
             )
            )
           )
           (i64.const 35)
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global470)
            )
           )
           (local.set $4
            (call $foreign22
             (struct.get $type119 0
              (struct.get $type121 0
               (local.get $0)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global468)
            )
           )
           (drop
            (if (result (ref $type130))
             (i32.eq
              (local.get $4)
              (i32.const -1)
             )
             (then
              (global.get $empty131)
             )
             (else
              (if
               (i64.gt_u
                (local.tee $2
                 (i64.extend_i32_s
                  (local.get $4)
                 )
                )
                (i64.const 1114111)
               )
               (then
                (unreachable)
               )
              )
              (if
               (i32.and
                (i64.le_u
                 (local.get $2)
                 (i64.const 57343)
                )
                (i64.ge_u
                 (local.get $2)
                 (i64.const 55296)
                )
               )
               (then
                (unreachable)
               )
              )
              (struct.new $type132
               (i32.wrap_i64
                (local.get $2)
               )
              )
             )
            )
           )
           (i32.const 1)
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (if (result i32)
         (local.tee $4
          (i64.eq
           (local.get $1)
           (i64.const 1)
          )
         )
         (then
          (local.get $4)
         )
         (else
          (if
           (i32.eqz
            (global.get $ready635)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global635)
           )
          )
          (return_call $function182
           (local.get $0)
           (i64.sub
            (local.get $1)
            (i64.const 1)
           )
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready635)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global635)
         )
        )
        (return_call $function182
         (local.get $0)
         (local.get $1)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function184 (type $call152) (param $0 i64) (result i32)
  (local $1 i32)
  (if (result i32)
   (local.tee $1
    (i64.lt_s
     (local.get $0)
     (i64.const 0)
    )
   )
   (then
    (local.get $1)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global536)
     )
    )
    (if (result i32)
     (local.tee $1
      (if (result i32)
       (i64.ge_s
        (local.get $0)
        (i64.const 0)
       )
       (then
        (if
         (i64.gt_u
          (local.get $0)
          (i64.const 1114111)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.and
          (i64.le_u
           (local.get $0)
           (i64.const 57343)
          )
          (i64.ge_u
           (local.get $0)
           (i64.const 55296)
          )
         )
         (then
          (unreachable)
         )
        )
        (i32.eq
         (call $foreign25
          (i32.wrap_i64
           (local.get $0)
          )
         )
         (i32.const 1)
        )
       )
       (else
        (i32.const 0)
       )
      )
     )
     (then
      (local.get $1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global538)
       )
      )
      (if (result i32)
       (local.tee $1
        (i64.eq
         (local.get $0)
         (i64.const 40)
        )
       )
       (then
        (local.get $1)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global538)
         )
        )
        (if (result i32)
         (local.tee $1
          (i64.eq
           (local.get $0)
           (i64.const 41)
          )
         )
         (then
          (local.get $1)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global538)
           )
          )
          (if (result i32)
           (local.tee $1
            (i64.eq
             (local.get $0)
             (i64.const 34)
            )
           )
           (then
            (local.get $1)
           )
           (else
            (drop
             (ref.as_non_null
              (global.get $global538)
             )
            )
            (if (result i32)
             (local.tee $1
              (i64.eq
               (local.get $0)
               (i64.const 59)
              )
             )
             (then
              (local.get $1)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global538)
               )
              )
              (if (result i32)
               (local.tee $1
                (i64.eq
                 (local.get $0)
                 (i64.const 124)
                )
               )
               (then
                (local.get $1)
               )
               (else
                (drop
                 (ref.as_non_null
                  (global.get $global538)
                 )
                )
                (if (result i32)
                 (local.tee $1
                  (i64.eq
                   (local.get $0)
                   (i64.const 39)
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global538)
                   )
                  )
                  (if (result i32)
                   (local.tee $1
                    (i64.eq
                     (local.get $0)
                     (i64.const 96)
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global538)
                     )
                    )
                    (if (result i32)
                     (local.tee $1
                      (i64.eq
                       (local.get $0)
                       (i64.const 44)
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global538)
                       )
                      )
                      (if (result i32)
                       (local.tee $1
                        (i64.eq
                         (local.get $0)
                         (i64.const 91)
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global538)
                         )
                        )
                        (if (result i32)
                         (local.tee $1
                          (i64.eq
                           (local.get $0)
                           (i64.const 93)
                          )
                         )
                         (then
                          (local.get $1)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global538)
                           )
                          )
                          (if (result i32)
                           (local.tee $1
                            (i64.eq
                             (local.get $0)
                             (i64.const 123)
                            )
                           )
                           (then
                            (local.get $1)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global538)
                             )
                            )
                            (i64.eq
                             (local.get $0)
                             (i64.const 125)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function186 (type $26) (param $0 (ref $type121)) (param $1 (ref $type154)) (param $2 i32) (param $3 i32) (result (ref $type18))
  (local $4 i64)
  (local $5 i32)
  (local $6 (ref $type130))
  (local $7 (ref $type18))
  (local $8 (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global552)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global472)
   )
  )
  (local.set $5
   (call $foreign23
    (struct.get $type119 0
     (struct.get $type121 0
      (local.get $0)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global468)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global532)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global643)
   )
  )
  (if (result (ref $type18))
   (call $function184
    (if (result i64)
     (ref.test (ref $type131)
      (local.tee $6
       (if (result (ref $type130))
        (i32.eq
         (local.get $5)
         (i32.const -1)
        )
        (then
         (global.get $empty131)
        )
        (else
         (if
          (i64.gt_u
           (local.tee $4
            (i64.extend_i32_s
             (local.get $5)
            )
           )
           (i64.const 1114111)
          )
          (then
           (unreachable)
          )
         )
         (if
          (i32.and
           (i64.le_u
            (local.get $4)
            (i64.const 57343)
           )
           (i64.ge_u
            (local.get $4)
            (i64.const 55296)
           )
          )
          (then
           (unreachable)
          )
         )
         (struct.new $type132
          (i32.wrap_i64
           (local.get $4)
          )
         )
        )
       )
      )
     )
     (then
      (i64.const -1)
     )
     (else
      (i64.extend_i32_u
       (struct.get $type132 0
        (ref.cast (ref $type132)
         (local.get $6)
        )
       )
      )
     )
    )
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global568)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global81)
     )
    )
    (local.set $7
     (struct.get $type155 0
      (struct.get $type154 0
       (local.get $1)
      )
     )
    )
    (if (result (ref $type18))
     (if (result i32)
      (local.tee $2
       (i64.lt_s
        (local.tee $4
         (struct.get $type156 0
          (struct.get $type154 1
           (local.get $1)
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $2)
      )
      (else
       (i64.lt_s
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $7)
         )
        )
        (local.get $4)
       )
      )
     )
     (then
      (unreachable)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global61)
       )
      )
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 4294967294)
       )
       (then
        (unreachable)
       )
      )
      (call $string-copy
       (local.tee $8
        (call $string-new
         (i32.wrap_i64
          (local.get $4)
         )
        )
       )
       (i64.const 0)
       (local.get $7)
       (local.get $4)
      )
      (local.get $8)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global530)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global470)
     )
    )
    (local.set $5
     (call $foreign22
      (struct.get $type119 0
       (struct.get $type121 0
        (local.get $0)
       )
      )
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global468)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global532)
     )
    )
    (if
     (i64.gt_u
      (local.tee $4
       (if (result i64)
        (ref.test (ref $type131)
         (local.tee $6
          (if (result (ref $type130))
           (i32.eq
            (local.get $5)
            (i32.const -1)
           )
           (then
            (global.get $empty131)
           )
           (else
            (if
             (i64.gt_u
              (local.tee $4
               (i64.extend_i32_s
                (local.get $5)
               )
              )
              (i64.const 1114111)
             )
             (then
              (unreachable)
             )
            )
            (if
             (i32.and
              (i64.le_u
               (local.get $4)
               (i64.const 57343)
              )
              (i64.ge_u
               (local.get $4)
               (i64.const 55296)
              )
             )
             (then
              (unreachable)
             )
            )
            (struct.new $type132
             (i32.wrap_i64
              (local.get $4)
             )
            )
           )
          )
         )
        )
        (then
         (i64.const -1)
        )
        (else
         (i64.extend_i32_u
          (struct.get $type132 0
           (ref.cast (ref $type132)
            (local.get $6)
           )
          )
         )
        )
       )
      )
      (i64.const 1114111)
     )
     (then
      (unreachable)
     )
    )
    (if
     (i32.and
      (i64.le_u
       (local.get $4)
       (i64.const 57343)
      )
      (i64.ge_u
       (local.get $4)
       (i64.const 55296)
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global611)
     )
    )
    (call $function177
     (local.get $1)
     (i32.wrap_i64
      (local.get $4)
     )
    )
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function186
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
    )
   )
  )
 )
 (func $function189 (type $25) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (result (ref $type18))
  (local $4 i64)
  (local $5 i32)
  (if (result (ref $type18))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (if
     (if (result i32)
      (i64.ge_u
       (local.tee $4
        (i64.extend_i32_u
         (array.get $type19
          (if (result (ref $type19))
           (i32.lt_u
            (local.tee $5
             (i32.wrap_i64
              (local.get $3)
             )
            )
            (i32.const 8192)
           )
           (then
            (struct.get $type18 2
             (local.get $0)
            )
           )
           (else
            (ref.as_non_null
             (array.get $type20
              (struct.get $type18 3
               (local.get $0)
              )
              (i32.sub
               (i32.shr_u
                (local.get $5)
                (i32.const 13)
               )
               (i32.const 1)
              )
             )
            )
           )
          )
          (i32.and
           (local.get $5)
           (i32.const 8191)
          )
         )
        )
       )
       (i64.const 65)
      )
      (then
       (i64.le_u
        (local.get $4)
        (i64.const 90)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.tee $4
         (i64.add
          (local.get $4)
          (i64.const 32)
         )
        )
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.ne
        (struct.get $type18 0
         (local.get $0)
        )
        (i32.const 1)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.ge_u
        (local.get $3)
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
       )
       (then
        (unreachable)
       )
      )
      (array.set $type19
       (if (result (ref $type19))
        (i32.lt_u
         (local.tee $5
          (i32.wrap_i64
           (local.get $3)
          )
         )
         (i32.const 8192)
        )
        (then
         (struct.get $type18 2
          (local.get $0)
         )
        )
        (else
         (ref.as_non_null
          (array.get $type20
           (struct.get $type18 3
            (local.get $0)
           )
           (i32.sub
            (i32.shr_u
             (local.get $5)
             (i32.const 13)
            )
            (i32.const 1)
           )
          )
         )
        )
       )
       (i32.and
        (local.get $5)
        (i32.const 8191)
       )
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function189
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function192 (type $24) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (param $4 i64) (result (ref $type181))
  (local $5 i64)
  (local $6 i32)
  (if (result (ref $type181))
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global581)
     )
    )
    (if (result (ref $type181))
     (if (result i32)
      (i64.gt_s
       (i64.sub
        (local.get $3)
        (i64.const 1)
       )
       (i64.const 0)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global584)
        )
       )
       (if (result i32)
        (i64.ge_s
         (local.get $4)
         (i64.const 0)
        )
        (then
         (if (result i32)
          (i64.le_s
           (local.get $4)
           (i64.const 1114111)
          )
          (then
           (if (result i32)
            (local.tee $1
             (i64.lt_s
              (local.get $4)
              (i64.const 55296)
             )
            )
            (then
             (local.get $1)
            )
            (else
             (i64.gt_s
              (local.get $4)
              (i64.const 57343)
             )
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (if
       (i64.gt_u
        (local.get $4)
        (i64.const 1114111)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i32.and
        (i64.le_u
         (local.get $4)
         (i64.const 57343)
        )
        (i64.ge_u
         (local.get $4)
         (i64.const 55296)
        )
       )
       (then
        (unreachable)
       )
      )
      (struct.new $type182
       (i32.const 0)
       (i32.wrap_i64
        (local.get $4)
       )
      )
     )
     (else
      (struct.new $type184
       (i32.const 2)
       (global.get $string12)
      )
     )
    )
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global588)
     )
    )
    (if (result (ref $type184))
     (if (result i32)
      (local.tee $6
       (i64.lt_s
        (local.tee $5
         (if (result i64)
          (i32.and
           (i64.le_u
            (local.tee $5
             (i64.extend_i32_u
              (array.get $type19
               (if (result (ref $type19))
                (i32.lt_u
                 (local.tee $6
                  (i32.wrap_i64
                   (local.get $3)
                  )
                 )
                 (i32.const 8192)
                )
                (then
                 (struct.get $type18 2
                  (local.get $0)
                 )
                )
                (else
                 (ref.as_non_null
                  (array.get $type20
                   (struct.get $type18 3
                    (local.get $0)
                   )
                   (i32.sub
                    (i32.shr_u
                     (local.get $6)
                     (i32.const 13)
                    )
                    (i32.const 1)
                   )
                  )
                 )
                )
               )
               (i32.and
                (local.get $6)
                (i32.const 8191)
               )
              )
             )
            )
            (i64.const 57)
           )
           (i64.ge_u
            (local.get $5)
            (i64.const 48)
           )
          )
          (then
           (i64.sub
            (local.get $5)
            (i64.const 48)
           )
          )
          (else
           (if (result i64)
            (i32.and
             (i64.le_u
              (local.get $5)
              (i64.const 70)
             )
             (i64.ge_u
              (local.get $5)
              (i64.const 65)
             )
            )
            (then
             (i64.sub
              (local.get $5)
              (i64.const 55)
             )
            )
            (else
             (select
              (i64.sub
               (local.get $5)
               (i64.const 87)
              )
              (i64.const -1)
              (i32.and
               (i64.le_u
                (local.get $5)
                (i64.const 102)
               )
               (i64.ge_u
                (local.get $5)
                (i64.const 97)
               )
              )
             )
            )
           )
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $6)
      )
      (else
       (i64.gt_s
        (local.get $4)
        (i64.const 69631)
       )
      )
     )
     (then
      (struct.new $type184
       (i32.const 2)
       (global.get $string32)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $2)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function192
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
       (i64.add
        (local.get $5)
        (i64.shl
         (local.get $4)
         (i64.const 4)
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function196 (type $call190) (param $0 (ref $type121)) (param $1 (ref $type163)) (result (ref $type101))
  (local $2 (ref $type101))
  (local $3 (ref $type18))
  (local $4 (ref $type13))
  (local $5 (ref $type21))
  (local $6 i32)
  (local $7 i64)
  (if (result (ref $type101))
   (local.tee $6
    (struct.get $type163 0
     (local.get $1)
    )
   )
   (then
    (if (result (ref $type101))
     (i32.eq
      (local.get $6)
      (i32.const 1)
     )
     (then
      (global.get $empty102)
     )
     (else
      (if (result (ref $type101))
       (i32.eq
        (struct.get $type163 0
         (local.get $1)
        )
        (i32.const 6)
       )
       (then
        (struct.new $type104
         (i32.const 2)
         (struct.get $type170 1
          (ref.cast (ref $type170)
           (local.get $1)
          )
         )
        )
       )
       (else
        (if (result (ref $type101))
         (i32.eq
          (struct.get $type163 0
           (local.get $1)
          )
          (i32.const 4)
         )
         (then
          (local.set $7
           (struct.get $type168 1
            (ref.cast (ref $type168)
             (local.get $1)
            )
           )
          )
          (if
           (i32.eqz
            (global.get $ready709)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global709)
           )
          )
          (return_call $function197
           (local.get $0)
           (local.get $7)
           (ref.null none)
          )
         )
         (else
          (if (result (ref $type101))
           (i32.eq
            (struct.get $type163 0
             (local.get $1)
            )
            (i32.const 5)
           )
           (then
            (local.set $3
             (struct.get $type169 1
              (ref.cast (ref $type169)
               (local.get $1)
              )
             )
            )
            (if
             (i32.eqz
              (global.get $ready780)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global780)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global525)
             )
            )
            (if
             (i32.eqz
              (global.get $ready527)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global527)
             )
            )
            (local.set $1
             (call $function154
              (local.get $0)
             )
            )
            (if
             (i32.eqz
              (global.get $ready702)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global702)
             )
            )
            (if (result (ref $type101))
             (i32.eq
              (struct.get $type101 0
               (local.tee $2
                (call $function196
                 (local.get $0)
                 (local.get $1)
                )
               )
              )
              (i32.const 1)
             )
             (then
              (local.set $4
               (struct.get $type103 1
                (ref.cast (ref $type103)
                 (local.get $2)
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global258)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global246)
               )
              )
              (local.set $5
               (struct.new $type21
                (i32.const 4)
                (struct.new $type22
                 (call $foreign5
                  (call $function80
                   (local.get $3)
                  )
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global351)
               )
              )
              (struct.new $type103
               (i32.const 1)
               (struct.new $type31
                (i32.const 6)
                (struct.new $type32
                 (local.get $5)
                )
                (struct.new $type32
                 (struct.new $type31
                  (i32.const 6)
                  (struct.new $type32
                   (local.get $4)
                  )
                  (struct.new $type32
                   (global.get $empty14)
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type104))
               (struct.get $type101 0
                (local.get $2)
               )
               (then
                (struct.new $type104
                 (i32.const 2)
                 (struct.get $type104 1
                  (ref.cast (ref $type104)
                   (local.get $2)
                  )
                 )
                )
               )
               (else
                (struct.new $type104
                 (i32.const 2)
                 (global.get $string51)
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type104))
             (i32.eq
              (struct.get $type163 0
               (local.get $1)
              )
              (i32.const 2)
             )
             (then
              (struct.new $type104
               (i32.const 2)
               (global.get $string41)
              )
             )
             (else
              (struct.new $type104
               (i32.const 2)
               (global.get $string40)
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (struct.new $type103
     (i32.const 1)
     (struct.get $type164 1
      (ref.cast (ref $type164)
       (local.get $1)
      )
     )
    )
   )
  )
 )
 (func $function197 (type $22) (param $0 (ref $type121)) (param $1 i64) (param $2 (ref null $type12)) (result (ref $type101))
  (local $3 (ref null $type12))
  (local $4 (ref null $type12))
  (local $5 (ref $type31))
  (local $6 (ref $type12))
  (local $7 (ref $type163))
  (local $8 (ref $type101))
  (local $9 (ref $type14))
  (local $10 (ref $type13))
  (local $11 i32)
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (if (result (ref $type101))
   (i32.eq
    (struct.get $type163 0
     (local.tee $7
      (call $function154
       (local.get $0)
      )
     )
    )
    (i32.const 2)
   )
   (then
    (if
     (i32.eqz
      (global.get $ready715)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global715)
     )
    )
    (if (result (ref $type103))
     (i64.eqz
      (local.get $1)
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global718)
       )
      )
      (local.set $9
       (global.get $empty14)
      )
      (struct.new $type103
       (i32.const 1)
       (if (result (ref $type13))
        (ref.is_null
         (local.get $2)
        )
        (then
         (local.get $9)
        )
        (else
         (local.set $4
          (struct.get $type12 1
           (local.get $2)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global351)
          )
         )
         (if
          (i32.eqz
           (global.get $ready718)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global718)
          )
         )
         (local.set $5
          (struct.new $type31
           (i32.const 6)
           (struct.new $type32
            (struct.get $type12 0
             (local.get $2)
            )
           )
           (struct.new $type32
            (local.get $9)
           )
          )
         )
         (if (result (ref $type13))
          (ref.is_null
           (local.get $4)
          )
          (then
           (local.get $5)
          )
          (else
           (local.set $3
            (struct.get $type12 1
             (local.get $4)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global351)
            )
           )
           (if
            (i32.eqz
             (global.get $ready718)
            )
            (then
             (unreachable)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global718)
            )
           )
           (local.set $5
            (struct.new $type31
             (i32.const 6)
             (struct.new $type32
              (struct.get $type12 0
               (local.get $4)
              )
             )
             (struct.new $type32
              (local.get $5)
             )
            )
           )
           (if (result (ref $type13))
            (ref.is_null
             (local.get $3)
            )
            (then
             (local.get $5)
            )
            (else
             (local.set $4
              (struct.get $type12 1
               (local.get $3)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global351)
              )
             )
             (if
              (i32.eqz
               (global.get $ready718)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global718)
              )
             )
             (local.set $5
              (struct.new $type31
               (i32.const 6)
               (struct.new $type32
                (struct.get $type12 0
                 (local.get $3)
                )
               )
               (struct.new $type32
                (local.get $5)
               )
              )
             )
             (if (result (ref $type13))
              (ref.is_null
               (local.get $4)
              )
              (then
               (local.get $5)
              )
              (else
               (local.set $3
                (struct.get $type12 1
                 (local.get $4)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global351)
                )
               )
               (if
                (i32.eqz
                 (global.get $ready718)
                )
                (then
                 (unreachable)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global718)
                )
               )
               (local.set $5
                (struct.new $type31
                 (i32.const 6)
                 (struct.new $type32
                  (struct.get $type12 0
                   (local.get $4)
                  )
                 )
                 (struct.new $type32
                  (local.get $5)
                 )
                )
               )
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $3)
                )
                (then
                 (local.get $5)
                )
                (else
                 (local.set $4
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global351)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready718)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global718)
                  )
                 )
                 (local.set $5
                  (struct.new $type31
                   (i32.const 6)
                   (struct.new $type32
                    (struct.get $type12 0
                     (local.get $3)
                    )
                   )
                   (struct.new $type32
                    (local.get $5)
                   )
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type12 1
                     (local.get $4)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global351)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready718)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global718)
                    )
                   )
                   (local.set $5
                    (struct.new $type31
                     (i32.const 6)
                     (struct.new $type32
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (struct.new $type32
                      (local.get $5)
                     )
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $4
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global351)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready718)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global718)
                      )
                     )
                     (local.set $5
                      (struct.new $type31
                       (i32.const 6)
                       (struct.new $type32
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (struct.new $type32
                        (local.get $5)
                       )
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type12 1
                         (local.get $4)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global351)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready718)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global718)
                        )
                       )
                       (local.set $5
                        (struct.new $type31
                         (i32.const 6)
                         (struct.new $type32
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (struct.new $type32
                          (local.get $5)
                         )
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (call $function199
                          (struct.get $type12 1
                           (local.get $3)
                          )
                          (block (result (ref (exact $type31)))
                           (drop
                            (ref.as_non_null
                             (global.get $global351)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready718)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global718)
                            )
                           )
                           (struct.new $type31
                            (i32.const 6)
                            (struct.new $type32
                             (struct.get $type12 0
                              (local.get $3)
                             )
                            )
                            (struct.new $type32
                             (local.get $5)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
     (else
      (if (result (ref $type103))
       (i64.eq
        (local.get $1)
        (i64.const 1)
       )
       (then
        (drop
         (ref.as_non_null
          (global.get $global721)
         )
        )
        (local.set $3
         (if (result (ref null $type12))
          (ref.is_null
           (local.get $2)
          )
          (then
           (ref.null none)
          )
          (else
           (local.set $6
            (struct.new $type12
             (struct.get $type12 0
              (local.get $2)
             )
             (ref.null none)
            )
           )
           (if (result (ref null $type12))
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (local.get $6)
            )
            (else
             (local.set $6
              (struct.new $type12
               (struct.get $type12 0
                (local.get $3)
               )
               (local.get $6)
              )
             )
             (if (result (ref null $type12))
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (local.get $6)
              )
              (else
               (local.set $6
                (struct.new $type12
                 (struct.get $type12 0
                  (local.get $3)
                 )
                 (local.get $6)
                )
               )
               (if (result (ref null $type12))
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (local.get $6)
                )
                (else
                 (local.set $6
                  (struct.new $type12
                   (struct.get $type12 0
                    (local.get $3)
                   )
                   (local.get $6)
                  )
                 )
                 (if (result (ref null $type12))
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (local.get $6)
                  )
                  (else
                   (local.set $6
                    (struct.new $type12
                     (struct.get $type12 0
                      (local.get $3)
                     )
                     (local.get $6)
                    )
                   )
                   (if (result (ref null $type12))
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (local.get $6)
                    )
                    (else
                     (local.set $6
                      (struct.new $type12
                       (struct.get $type12 0
                        (local.get $3)
                       )
                       (local.get $6)
                      )
                     )
                     (if (result (ref null $type12))
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (local.get $6)
                      )
                      (else
                       (local.set $6
                        (struct.new $type12
                         (struct.get $type12 0
                          (local.get $3)
                         )
                         (local.get $6)
                        )
                       )
                       (if (result (ref null $type12))
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (local.get $6)
                        )
                        (else
                         (local.set $6
                          (struct.new $type12
                           (struct.get $type12 0
                            (local.get $3)
                           )
                           (local.get $6)
                          )
                         )
                         (if (result (ref null $type12))
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (local.get $6)
                          )
                          (else
                           (call $function201
                            (i32.const 0)
                            (i32.const 1)
                            (struct.get $type12 1
                             (local.get $3)
                            )
                            (struct.new $type12
                             (struct.get $type12 0
                              (local.get $3)
                             )
                             (local.get $6)
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global726)
         )
        )
        (struct.new $type103
         (i32.const 1)
         (struct.new $type33
          (i32.const 7)
          (call $function202
           (local.get $3)
          )
         )
        )
       )
       (else
        (if
         (i32.eqz
          (global.get $ready737)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global737)
         )
        )
        (local.set $1
         (if (result i64)
          (ref.is_null
           (local.get $2)
          )
          (then
           (i64.const 0)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $3
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 1)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $3
                (struct.get $type12 1
                 (local.get $3)
                )
               )
              )
              (then
               (i64.const 2)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $3
                  (struct.get $type12 1
                   (local.get $3)
                  )
                 )
                )
                (then
                 (i64.const 3)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $3
                    (struct.get $type12 1
                     (local.get $3)
                    )
                   )
                  )
                  (then
                   (i64.const 4)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $3
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                    )
                    (then
                     (i64.const 5)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $3
                        (struct.get $type12 1
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (i64.const 6)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $3
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                        )
                        (then
                         (i64.const 7)
                        )
                        (else
                         (if (result i64)
                          (ref.is_null
                           (local.tee $3
                            (struct.get $type12 1
                             (local.get $3)
                            )
                           )
                          )
                          (then
                           (i64.const 8)
                          )
                          (else
                           (call $function207
                            (i32.const 0)
                            (i32.const 1)
                            (struct.get $type12 1
                             (local.get $3)
                            )
                            (i64.const 9)
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global109)
         )
        )
        (if
         (i64.gt_u
          (local.get $1)
          (i64.const 4294967295)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i32.eqz
          (global.get $ready743)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global743)
         )
        )
        (return_call $function208
         (local.get $2)
         (struct.new $type36
          (array.new_default $type37
           (i32.wrap_i64
            (local.get $1)
           )
          )
         )
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (else
    (if (result (ref $type101))
     (i32.eq
      (struct.get $type163 0
       (local.get $7)
      )
      (i32.const 1)
     )
     (then
      (struct.new $type104
       (i32.const 2)
       (global.get $string43)
      )
     )
     (else
      (if (result (ref $type101))
       (i32.eq
        (struct.get $type163 0
         (local.get $7)
        )
        (i32.const 3)
       )
       (then
        (if (result (ref $type101))
         (i32.and
          (i32.eqz
           (ref.is_null
            (local.get $2)
           )
          )
          (i64.eqz
           (local.get $1)
          )
         )
         (then
          (if
           (i32.eqz
            (global.get $ready756)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global756)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global525)
           )
          )
          (if
           (i32.eqz
            (global.get $ready527)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global527)
           )
          )
          (local.set $7
           (call $function154
            (local.get $0)
           )
          )
          (if
           (i32.eqz
            (global.get $ready702)
           )
           (then
            (unreachable)
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global702)
           )
          )
          (if (result (ref $type101))
           (i32.eq
            (struct.get $type101 0
             (local.tee $8
              (call $function196
               (local.get $0)
               (local.get $7)
              )
             )
            )
            (i32.const 1)
           )
           (then
            (local.set $10
             (struct.get $type103 1
              (ref.cast (ref $type103)
               (local.get $8)
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global527)
             )
            )
            (if (result (ref $type101))
             (i32.eq
              (struct.get $type163 0
               (local.tee $7
                (call $function154
                 (local.get $0)
                )
               )
              )
              (i32.const 2)
             )
             (then
              (if
               (i32.eqz
                (global.get $ready718)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global718)
               )
              )
              (struct.new $type103
               (i32.const 1)
               (if (result (ref $type13))
                (ref.is_null
                 (local.get $2)
                )
                (then
                 (local.get $10)
                )
                (else
                 (local.set $4
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global351)
                  )
                 )
                 (if
                  (i32.eqz
                   (global.get $ready718)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global718)
                  )
                 )
                 (local.set $5
                  (struct.new $type31
                   (i32.const 6)
                   (struct.new $type32
                    (struct.get $type12 0
                     (local.get $2)
                    )
                   )
                   (struct.new $type32
                    (local.get $10)
                   )
                  )
                 )
                 (if (result (ref $type13))
                  (ref.is_null
                   (local.get $4)
                  )
                  (then
                   (local.get $5)
                  )
                  (else
                   (local.set $3
                    (struct.get $type12 1
                     (local.get $4)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global351)
                    )
                   )
                   (if
                    (i32.eqz
                     (global.get $ready718)
                    )
                    (then
                     (unreachable)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global718)
                    )
                   )
                   (local.set $5
                    (struct.new $type31
                     (i32.const 6)
                     (struct.new $type32
                      (struct.get $type12 0
                       (local.get $4)
                      )
                     )
                     (struct.new $type32
                      (local.get $5)
                     )
                    )
                   )
                   (if (result (ref $type13))
                    (ref.is_null
                     (local.get $3)
                    )
                    (then
                     (local.get $5)
                    )
                    (else
                     (local.set $4
                      (struct.get $type12 1
                       (local.get $3)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global351)
                      )
                     )
                     (if
                      (i32.eqz
                       (global.get $ready718)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global718)
                      )
                     )
                     (local.set $5
                      (struct.new $type31
                       (i32.const 6)
                       (struct.new $type32
                        (struct.get $type12 0
                         (local.get $3)
                        )
                       )
                       (struct.new $type32
                        (local.get $5)
                       )
                      )
                     )
                     (if (result (ref $type13))
                      (ref.is_null
                       (local.get $4)
                      )
                      (then
                       (local.get $5)
                      )
                      (else
                       (local.set $3
                        (struct.get $type12 1
                         (local.get $4)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global351)
                        )
                       )
                       (if
                        (i32.eqz
                         (global.get $ready718)
                        )
                        (then
                         (unreachable)
                        )
                       )
                       (drop
                        (ref.as_non_null
                         (global.get $global718)
                        )
                       )
                       (local.set $5
                        (struct.new $type31
                         (i32.const 6)
                         (struct.new $type32
                          (struct.get $type12 0
                           (local.get $4)
                          )
                         )
                         (struct.new $type32
                          (local.get $5)
                         )
                        )
                       )
                       (if (result (ref $type13))
                        (ref.is_null
                         (local.get $3)
                        )
                        (then
                         (local.get $5)
                        )
                        (else
                         (local.set $4
                          (struct.get $type12 1
                           (local.get $3)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global351)
                          )
                         )
                         (if
                          (i32.eqz
                           (global.get $ready718)
                          )
                          (then
                           (unreachable)
                          )
                         )
                         (drop
                          (ref.as_non_null
                           (global.get $global718)
                          )
                         )
                         (local.set $5
                          (struct.new $type31
                           (i32.const 6)
                           (struct.new $type32
                            (struct.get $type12 0
                             (local.get $3)
                            )
                           )
                           (struct.new $type32
                            (local.get $5)
                           )
                          )
                         )
                         (if (result (ref $type13))
                          (ref.is_null
                           (local.get $4)
                          )
                          (then
                           (local.get $5)
                          )
                          (else
                           (local.set $3
                            (struct.get $type12 1
                             (local.get $4)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global351)
                            )
                           )
                           (if
                            (i32.eqz
                             (global.get $ready718)
                            )
                            (then
                             (unreachable)
                            )
                           )
                           (drop
                            (ref.as_non_null
                             (global.get $global718)
                            )
                           )
                           (local.set $5
                            (struct.new $type31
                             (i32.const 6)
                             (struct.new $type32
                              (struct.get $type12 0
                               (local.get $4)
                              )
                             )
                             (struct.new $type32
                              (local.get $5)
                             )
                            )
                           )
                           (if (result (ref $type13))
                            (ref.is_null
                             (local.get $3)
                            )
                            (then
                             (local.get $5)
                            )
                            (else
                             (local.set $4
                              (struct.get $type12 1
                               (local.get $3)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global351)
                              )
                             )
                             (if
                              (i32.eqz
                               (global.get $ready718)
                              )
                              (then
                               (unreachable)
                              )
                             )
                             (drop
                              (ref.as_non_null
                               (global.get $global718)
                              )
                             )
                             (local.set $5
                              (struct.new $type31
                               (i32.const 6)
                               (struct.new $type32
                                (struct.get $type12 0
                                 (local.get $3)
                                )
                               )
                               (struct.new $type32
                                (local.get $5)
                               )
                              )
                             )
                             (if (result (ref $type13))
                              (ref.is_null
                               (local.get $4)
                              )
                              (then
                               (local.get $5)
                              )
                              (else
                               (local.set $3
                                (struct.get $type12 1
                                 (local.get $4)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global351)
                                )
                               )
                               (if
                                (i32.eqz
                                 (global.get $ready718)
                                )
                                (then
                                 (unreachable)
                                )
                               )
                               (drop
                                (ref.as_non_null
                                 (global.get $global718)
                                )
                               )
                               (local.set $5
                                (struct.new $type31
                                 (i32.const 6)
                                 (struct.new $type32
                                  (struct.get $type12 0
                                   (local.get $4)
                                  )
                                 )
                                 (struct.new $type32
                                  (local.get $5)
                                 )
                                )
                               )
                               (if (result (ref $type13))
                                (ref.is_null
                                 (local.get $3)
                                )
                                (then
                                 (local.get $5)
                                )
                                (else
                                 (call $function199
                                  (struct.get $type12 1
                                   (local.get $3)
                                  )
                                  (block (result (ref (exact $type31)))
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global351)
                                    )
                                   )
                                   (if
                                    (i32.eqz
                                     (global.get $ready718)
                                    )
                                    (then
                                     (unreachable)
                                    )
                                   )
                                   (drop
                                    (ref.as_non_null
                                     (global.get $global718)
                                    )
                                   )
                                   (struct.new $type31
                                    (i32.const 6)
                                    (struct.new $type32
                                     (struct.get $type12 0
                                      (local.get $3)
                                     )
                                    )
                                    (struct.new $type32
                                     (local.get $5)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
             (else
              (if (result (ref $type104))
               (i32.eq
                (struct.get $type163 0
                 (local.get $7)
                )
                (i32.const 6)
               )
               (then
                (struct.new $type104
                 (i32.const 2)
                 (struct.get $type170 1
                  (ref.cast (ref $type170)
                   (local.get $7)
                  )
                 )
                )
               )
               (else
                (if (result (ref $type104))
                 (local.tee $11
                  (struct.get $type163 0
                   (local.get $7)
                  )
                 )
                 (then
                  (if (result (ref $type104))
                   (i32.eq
                    (local.get $11)
                    (i32.const 1)
                   )
                   (then
                    (struct.new $type104
                     (i32.const 2)
                     (global.get $string49)
                    )
                   )
                   (else
                    (if (result (ref $type104))
                     (i32.eq
                      (struct.get $type163 0
                       (local.get $7)
                      )
                      (i32.const 3)
                     )
                     (then
                      (struct.new $type104
                       (i32.const 2)
                       (global.get $string48)
                      )
                     )
                     (else
                      (if (result (ref $type104))
                       (i32.eq
                        (struct.get $type163 0
                         (local.get $7)
                        )
                        (i32.const 4)
                       )
                       (then
                        (drop
                         (ref.cast (ref $type168)
                          (local.get $7)
                         )
                        )
                        (struct.new $type104
                         (i32.const 2)
                         (global.get $string47)
                        )
                       )
                       (else
                        (drop
                         (ref.cast (ref $type169)
                          (local.get $7)
                         )
                        )
                        (struct.new $type104
                         (i32.const 2)
                         (global.get $string46)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (drop
                   (ref.cast (ref $type164)
                    (local.get $7)
                   )
                  )
                  (struct.new $type104
                   (i32.const 2)
                   (global.get $string50)
                  )
                 )
                )
               )
              )
             )
            )
           )
           (else
            (if (result (ref $type104))
             (struct.get $type101 0
              (local.get $8)
             )
             (then
              (struct.new $type104
               (i32.const 2)
               (struct.get $type104 1
                (ref.cast (ref $type104)
                 (local.get $8)
                )
               )
              )
             )
             (else
              (struct.new $type104
               (i32.const 2)
               (global.get $string45)
              )
             )
            )
           )
          )
         )
         (else
          (struct.new $type104
           (i32.const 2)
           (global.get $string42)
          )
         )
        )
       )
       (else
        (if (result (ref $type104))
         (i32.eq
          (struct.get $type163 0
           (local.get $7)
          )
          (i32.const 6)
         )
         (then
          (struct.new $type104
           (i32.const 2)
           (struct.get $type170 1
            (ref.cast (ref $type170)
             (local.get $7)
            )
           )
          )
         )
         (else
          (if (result (ref $type104))
           (local.tee $11
            (struct.get $type163 0
             (local.get $7)
            )
           )
           (then
            (if
             (i32.eq
              (local.get $11)
              (i32.const 4)
             )
             (then
              (drop
               (ref.cast (ref $type168)
                (local.get $7)
               )
              )
             )
             (else
              (drop
               (ref.cast (ref $type169)
                (local.get $7)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global702)
             )
            )
            (local.set $8
             (call $function196
              (local.get $0)
              (local.get $7)
             )
            )
            (if
             (i32.eqz
              (global.get $ready770)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global770)
             )
            )
            (if (result (ref $type104))
             (i32.eq
              (struct.get $type101 0
               (local.get $8)
              )
              (i32.const 1)
             )
             (then
              (drop
               (ref.as_non_null
                (global.get $global709)
               )
              )
              (return_call $function197
               (local.get $0)
               (local.get $1)
               (struct.new $type12
                (struct.get $type103 1
                 (ref.cast (ref $type103)
                  (local.get $8)
                 )
                )
                (local.get $2)
               )
              )
             )
             (else
              (if (result (ref $type104))
               (i32.eq
                (struct.get $type101 0
                 (local.get $8)
                )
                (i32.const 2)
               )
               (then
                (struct.new $type104
                 (i32.const 2)
                 (struct.get $type104 1
                  (ref.cast (ref $type104)
                   (local.get $8)
                  )
                 )
                )
               )
               (else
                (unreachable)
               )
              )
             )
            )
           )
           (else
            (local.set $6
             (struct.new $type12
              (struct.get $type164 1
               (ref.cast (ref $type164)
                (local.get $7)
               )
              )
              (local.get $2)
             )
            )
            (if
             (i32.eqz
              (global.get $ready709)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global709)
             )
            )
            (return_call $function197
             (local.get $0)
             (local.get $1)
             (local.get $6)
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function199 (type $call195) (param $0 (ref null $type12)) (param $1 (ref $type31)) (result (ref $type13))
  (local $2 (ref null $type12))
  (local $scratch (ref (exact $type31)))
  (if (result (ref $type31))
   (ref.is_null
    (local.get $0)
   )
   (then
    (local.get $1)
   )
   (else
    (return_call $function199
     (struct.get $type12 1
      (local.get $0)
     )
     (block (result (ref (exact $type31)))
      (drop
       (ref.as_non_null
        (global.get $global351)
       )
      )
      (local.set $scratch
       (struct.new $type31
        (i32.const 6)
        (struct.new $type32
         (struct.get $type12 0
          (local.get $0)
         )
        )
        (struct.new $type32
         (local.get $1)
        )
       )
      )
      (if
       (i32.eqz
        (global.get $ready718)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global718)
       )
      )
      (local.get $scratch)
     )
    )
   )
  )
 )
 (func $function201 (type $19) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 (ref $type12)) (result (ref null $type12))
  (local $4 (ref null $type12))
  (if (result (ref $type12))
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $4
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (local.set $3
     (struct.new $type12
      (struct.get $type12 0
       (local.get $2)
      )
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function201
     (local.get $0)
     (local.get $1)
     (local.get $4)
     (local.get $3)
    )
   )
  )
 )
 (func $function202 (type $call38) (param $0 (ref null $type12)) (result (ref $type34))
  (local $1 (ref $type34))
  (local $2 (ref null $type12))
  (local $3 i64)
  (if (result (ref $type34))
   (ref.is_null
    (local.get $0)
   )
   (then
    (array.new_fixed $type34 0)
   )
   (else
    (if
     (i32.eqz
      (global.get $ready729)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global729)
     )
    )
    (if
     (i64.gt_u
      (local.tee $3
       (if (result i64)
        (ref.is_null
         (local.get $0)
        )
        (then
         (i64.const 0)
        )
        (else
         (if (result i64)
          (ref.is_null
           (local.tee $2
            (struct.get $type12 1
             (local.get $0)
            )
           )
          )
          (then
           (i64.const 1)
          )
          (else
           (if (result i64)
            (ref.is_null
             (local.tee $2
              (struct.get $type12 1
               (local.get $2)
              )
             )
            )
            (then
             (i64.const 2)
            )
            (else
             (if (result i64)
              (ref.is_null
               (local.tee $2
                (struct.get $type12 1
                 (local.get $2)
                )
               )
              )
              (then
               (i64.const 3)
              )
              (else
               (if (result i64)
                (ref.is_null
                 (local.tee $2
                  (struct.get $type12 1
                   (local.get $2)
                  )
                 )
                )
                (then
                 (i64.const 4)
                )
                (else
                 (if (result i64)
                  (ref.is_null
                   (local.tee $2
                    (struct.get $type12 1
                     (local.get $2)
                    )
                   )
                  )
                  (then
                   (i64.const 5)
                  )
                  (else
                   (if (result i64)
                    (ref.is_null
                     (local.tee $2
                      (struct.get $type12 1
                       (local.get $2)
                      )
                     )
                    )
                    (then
                     (i64.const 6)
                    )
                    (else
                     (if (result i64)
                      (ref.is_null
                       (local.tee $2
                        (struct.get $type12 1
                         (local.get $2)
                        )
                       )
                      )
                      (then
                       (i64.const 7)
                      )
                      (else
                       (if (result i64)
                        (ref.is_null
                         (local.tee $2
                          (struct.get $type12 1
                           (local.get $2)
                          )
                         )
                        )
                        (then
                         (i64.const 8)
                        )
                        (else
                         (call $function204
                          (i32.const 0)
                          (i32.const 1)
                          (struct.get $type12 1
                           (local.get $2)
                          )
                          (i64.const 9)
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (local.set $1
     (array.new $type34
      (struct.get $type12 0
       (local.get $0)
      )
      (i32.wrap_i64
       (local.get $3)
      )
     )
    )
    (if (result (ref $type34))
     (ref.is_null
      (local.get $0)
     )
     (then
      (local.get $1)
     )
     (else
      (array.set $type34
       (local.get $1)
       (i32.const 0)
       (struct.get $type12 0
        (local.get $0)
       )
      )
      (if (result (ref $type34))
       (ref.is_null
        (local.tee $0
         (struct.get $type12 1
          (local.get $0)
         )
        )
       )
       (then
        (local.get $1)
       )
       (else
        (array.set $type34
         (local.get $1)
         (i32.const 1)
         (struct.get $type12 0
          (local.get $0)
         )
        )
        (if (result (ref $type34))
         (ref.is_null
          (local.tee $0
           (struct.get $type12 1
            (local.get $0)
           )
          )
         )
         (then
          (local.get $1)
         )
         (else
          (array.set $type34
           (local.get $1)
           (i32.const 2)
           (struct.get $type12 0
            (local.get $0)
           )
          )
          (if (result (ref $type34))
           (ref.is_null
            (local.tee $0
             (struct.get $type12 1
              (local.get $0)
             )
            )
           )
           (then
            (local.get $1)
           )
           (else
            (array.set $type34
             (local.get $1)
             (i32.const 3)
             (struct.get $type12 0
              (local.get $0)
             )
            )
            (if (result (ref $type34))
             (ref.is_null
              (local.tee $0
               (struct.get $type12 1
                (local.get $0)
               )
              )
             )
             (then
              (local.get $1)
             )
             (else
              (array.set $type34
               (local.get $1)
               (i32.const 4)
               (struct.get $type12 0
                (local.get $0)
               )
              )
              (if (result (ref $type34))
               (ref.is_null
                (local.tee $0
                 (struct.get $type12 1
                  (local.get $0)
                 )
                )
               )
               (then
                (local.get $1)
               )
               (else
                (array.set $type34
                 (local.get $1)
                 (i32.const 5)
                 (struct.get $type12 0
                  (local.get $0)
                 )
                )
                (if (result (ref $type34))
                 (ref.is_null
                  (local.tee $0
                   (struct.get $type12 1
                    (local.get $0)
                   )
                  )
                 )
                 (then
                  (local.get $1)
                 )
                 (else
                  (array.set $type34
                   (local.get $1)
                   (i32.const 6)
                   (struct.get $type12 0
                    (local.get $0)
                   )
                  )
                  (if (result (ref $type34))
                   (ref.is_null
                    (local.tee $0
                     (struct.get $type12 1
                      (local.get $0)
                     )
                    )
                   )
                   (then
                    (local.get $1)
                   )
                   (else
                    (array.set $type34
                     (local.get $1)
                     (i32.const 7)
                     (struct.get $type12 0
                      (local.get $0)
                     )
                    )
                    (if (result (ref $type34))
                     (ref.is_null
                      (local.tee $0
                       (struct.get $type12 1
                        (local.get $0)
                       )
                      )
                     )
                     (then
                      (local.get $1)
                     )
                     (else
                      (array.set $type34
                       (local.get $1)
                       (i32.const 8)
                       (struct.get $type12 0
                        (local.get $0)
                       )
                      )
                      (if (result (ref $type34))
                       (ref.is_null
                        (local.tee $0
                         (struct.get $type12 1
                          (local.get $0)
                         )
                        )
                       )
                       (then
                        (local.get $1)
                       )
                       (else
                        (array.set $type34
                         (local.get $1)
                         (i32.const 9)
                         (struct.get $type12 0
                          (local.get $0)
                         )
                        )
                        (return_call $function205
                         (local.get $1)
                         (i32.const 0)
                         (i32.const 1)
                         (struct.get $type12 1
                          (local.get $0)
                         )
                         (i64.const 10)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function204 (type $17) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (if
     (i64.eq
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
     (else
      (local.set $2
       (struct.get $type12 1
        (local.get $2)
       )
      )
      (if
       (i32.eqz
        (local.get $1)
       )
       (then
        (unreachable)
       )
      )
      (return_call $function204
       (local.get $0)
       (local.get $1)
       (local.get $2)
       (i64.add
        (local.get $3)
        (i64.const 1)
       )
      )
     )
    )
    (unreachable)
   )
  )
 )
 (func $function205 (type $16) (param $0 (ref $type34)) (param $1 i32) (param $2 i32) (param $3 (ref null $type12)) (param $4 i64) (result (ref $type34))
  (local $5 (ref $type13))
  (if (result (ref $type34))
   (ref.is_null
    (local.get $3)
   )
   (then
    (local.get $0)
   )
   (else
    (local.set $5
     (struct.get $type12 0
      (local.get $3)
     )
    )
    (if
     (i64.gt_u
      (local.get $4)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (array.set $type34
     (local.get $0)
     (i32.wrap_i64
      (local.get $4)
     )
     (local.get $5)
    )
    (local.set $3
     (struct.get $type12 1
      (local.get $3)
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function205
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (local.get $3)
     (i64.add
      (local.get $4)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function207 (type $17) (param $0 i32) (param $1 i32) (param $2 (ref null $type12)) (param $3 i64) (result i64)
  (if (result i64)
   (ref.is_null
    (local.get $2)
   )
   (then
    (local.get $3)
   )
   (else
    (local.set $2
     (struct.get $type12 1
      (local.get $2)
     )
    )
    (if
     (i32.eqz
      (local.get $1)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function207
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function208 (type $call199) (param $0 (ref null $type12)) (param $1 (ref $type36)) (param $2 i64) (result (ref $type101))
  (local $3 (ref $type24))
  (local $4 (ref $type13))
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (if (result (ref $type101))
   (ref.is_null
    (local.get $0)
   )
   (then
    (struct.new $type103
     (i32.const 1)
     (struct.new $type35
      (i32.const 8)
      (local.get $1)
     )
    )
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global748)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global376)
     )
    )
    (drop
     (ref.as_non_null
      (global.get $global364)
     )
    )
    (if (result (ref $type104))
     (if (result i32)
      (local.tee $7
       (i64.lt_s
        (local.tee $5
         (if (result i64)
          (i64.eq
           (call $function109
            (local.tee $4
             (struct.get $type12 0
              (local.get $0)
             )
            )
           )
           (i64.const 5)
          )
          (then
           (if
            (i32.ne
             (struct.get $type13 0
              (local.get $4)
             )
             (i32.const 5)
            )
            (then
             (unreachable)
            )
           )
           (if (result i64)
            (struct.get $type24 0
             (local.tee $3
              (struct.get $type23 1
               (ref.cast (ref $type23)
                (local.get $4)
               )
              )
             )
            )
            (then
             (if
              (i32.eq
               (struct.get $type24 0
                (local.get $3)
               )
               (i32.const 1)
              )
              (then
               (drop
                (ref.cast (ref $type26)
                 (local.get $3)
                )
               )
              )
              (else
               (drop
                (ref.cast (ref $type27)
                 (local.get $3)
                )
               )
              )
             )
             (i64.const -1)
            )
            (else
             (struct.get $type25 1
              (ref.cast (ref $type25)
               (local.get $3)
              )
             )
            )
           )
          )
          (else
           (i64.const -1)
          )
         )
        )
        (i64.const 0)
       )
      )
      (then
       (local.get $7)
      )
      (else
       (i64.gt_s
        (local.get $5)
        (i64.const 255)
       )
      )
     )
     (then
      (struct.new $type104
       (i32.const 2)
       (global.get $string44)
      )
     )
     (else
      (if
       (i64.gt_u
        (local.tee $6
         (i64.sub
          (local.get $2)
          (i64.const 1)
         )
        )
        (i64.const 4294967295)
       )
       (then
        (unreachable)
       )
      )
      (if
       (i64.gt_u
        (local.get $5)
        (i64.const 255)
       )
       (then
        (unreachable)
       )
      )
      (array.set $type37
       (struct.get $type36 0
        (local.get $1)
       )
       (i32.wrap_i64
        (local.get $6)
       )
       (i32.wrap_i64
        (local.get $5)
       )
      )
      (return_call $function208
       (struct.get $type12 1
        (local.get $0)
       )
       (block (result (ref $type36))
        (if
         (i32.eqz
          (global.get $ready743)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global743)
         )
        )
        (local.get $1)
       )
       (i64.sub
        (local.get $2)
        (i64.const 1)
       )
      )
     )
    )
   )
  )
 )
 (func $function221 (type $call116) (param $0 (ref $type18)) (result i32)
  (local $1 i64)
  (call $foreign26
   (local.tee $1
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
   )
  )
  (if (result i32)
   (i64.eqz
    (local.get $1)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.eqz
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign27
     (array.get $type19
      (struct.get $type18 2
       (local.get $0)
      )
      (i32.const 0)
     )
    )
    (if (result i32)
     (i64.eq
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
      (i64.const 1)
     )
     (then
      (i32.const 0)
     )
     (else
      (if
       (i64.le_u
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 1)
       )
       (then
        (unreachable)
       )
      )
      (call $foreign27
       (array.get $type19
        (struct.get $type18 2
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $0)
         )
        )
        (i64.const 2)
       )
       (then
        (i32.const 0)
       )
       (else
        (if
         (i64.le_u
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 2)
         )
         (then
          (unreachable)
         )
        )
        (call $foreign27
         (array.get $type19
          (struct.get $type18 2
           (local.get $0)
          )
          (i32.const 2)
         )
        )
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $0)
           )
          )
          (i64.const 3)
         )
         (then
          (i32.const 0)
         )
         (else
          (if
           (i64.le_u
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 3)
           )
           (then
            (unreachable)
           )
          )
          (call $foreign27
           (array.get $type19
            (struct.get $type18 2
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $0)
             )
            )
            (i64.const 4)
           )
           (then
            (i32.const 0)
           )
           (else
            (if
             (i64.le_u
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 4)
             )
             (then
              (unreachable)
             )
            )
            (call $foreign27
             (array.get $type19
              (struct.get $type18 2
               (local.get $0)
              )
              (i32.const 4)
             )
            )
            (if (result i32)
             (i64.eq
              (i64.extend_i32_u
               (struct.get $type18 1
                (local.get $0)
               )
              )
              (i64.const 5)
             )
             (then
              (i32.const 0)
             )
             (else
              (if
               (i64.le_u
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 5)
               )
               (then
                (unreachable)
               )
              )
              (call $foreign27
               (array.get $type19
                (struct.get $type18 2
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (if (result i32)
               (i64.eq
                (i64.extend_i32_u
                 (struct.get $type18 1
                  (local.get $0)
                 )
                )
                (i64.const 6)
               )
               (then
                (i32.const 0)
               )
               (else
                (if
                 (i64.le_u
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 6)
                 )
                 (then
                  (unreachable)
                 )
                )
                (call $foreign27
                 (array.get $type19
                  (struct.get $type18 2
                   (local.get $0)
                  )
                  (i32.const 6)
                 )
                )
                (if (result i32)
                 (i64.eq
                  (i64.extend_i32_u
                   (struct.get $type18 1
                    (local.get $0)
                   )
                  )
                  (i64.const 7)
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (if
                   (i64.le_u
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 7)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (call $foreign27
                   (array.get $type19
                    (struct.get $type18 2
                     (local.get $0)
                    )
                    (i32.const 7)
                   )
                  )
                  (if (result i32)
                   (i64.eq
                    (i64.extend_i32_u
                     (struct.get $type18 1
                      (local.get $0)
                     )
                    )
                    (i64.const 8)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (if
                     (i64.le_u
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 8)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (call $foreign27
                     (array.get $type19
                      (struct.get $type18 2
                       (local.get $0)
                      )
                      (i32.const 8)
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (struct.get $type18 1
                        (local.get $0)
                       )
                      )
                      (i64.const 9)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (if
                       (i64.le_u
                        (i64.extend_i32_u
                         (struct.get $type18 1
                          (local.get $0)
                         )
                        )
                        (i64.const 9)
                       )
                       (then
                        (unreachable)
                       )
                      )
                      (call $foreign27
                       (array.get $type19
                        (call $string-block
                         (local.get $0)
                         (i32.const 9)
                        )
                        (i32.const 9)
                       )
                      )
                      (return_call $function222
                       (local.get $0)
                       (i32.const 0)
                       (i32.const 1)
                       (i64.const 10)
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
  )
 )
 (func $function222 (type $13) (param $0 (ref $type18)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (local $4 i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (struct.get $type18 1
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.ge_u
      (local.get $3)
      (i64.extend_i32_u
       (struct.get $type18 1
        (local.get $0)
       )
      )
     )
     (then
      (unreachable)
     )
    )
    (call $foreign27
     (array.get $type19
      (call $string-block
       (local.get $0)
       (local.tee $4
        (i32.wrap_i64
         (local.get $3)
        )
       )
      )
      (i32.and
       (local.get $4)
       (i32.const 8191)
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function222
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function225 (type $call203) (param $0 (ref $type13)) (result i32)
  (local $1 (ref $type34))
  (local $2 (ref $type37))
  (local $3 (ref $type36))
  (local $4 (ref $type28))
  (local $5 (ref $type24))
  (local $6 (ref $type18))
  (local $7 (ref $type22))
  (local $8 (ref $type27))
  (local $9 (ref $type31))
  (local $10 (ref $type32))
  (local $11 i64)
  (local $12 i32)
  (local $13 f64)
  (local $scratch i32)
  (local $scratch_15 (ref $type18))
  (local $scratch_16 (ref $type22))
  (local $scratch_17 (ref $type18))
  (local $scratch_18 f64)
  (local $scratch_19 i64)
  (local $scratch_20 f64)
  (local $scratch_21 i64)
  (local $scratch_22 f64)
  (local $scratch_23 i64)
  (local $scratch_24 (ref $type32))
  (if (result i32)
   (local.tee $12
    (struct.get $type13 0
     (local.get $0)
    )
   )
   (then
    (if (result i32)
     (i32.eq
      (local.get $12)
      (i32.const 1)
     )
     (then
      (call $foreign26
       (i64.extend_i32_u
        (i32.ne
         (struct.get $type15 1
          (ref.cast (ref $type15)
           (local.get $0)
          )
         )
         (block (result i32)
          (call $foreign26
           (i64.const 1)
          )
          (i32.const 0)
         )
        )
       )
      )
      (i32.const 0)
     )
     (else
      (if (result i32)
       (i32.eq
        (struct.get $type13 0
         (local.get $0)
        )
        (i32.const 2)
       )
       (then
        (call $foreign27
         (block (result i32)
          (local.set $scratch
           (struct.get $type16 1
            (ref.cast (ref $type16)
             (local.get $0)
            )
           )
          )
          (call $foreign26
           (i64.const 2)
          )
          (local.get $scratch)
         )
        )
        (i32.const 0)
       )
       (else
        (if (result i32)
         (i32.eq
          (struct.get $type13 0
           (local.get $0)
          )
          (i32.const 3)
         )
         (then
          (return_call $function221
           (block (result (ref $type18))
            (local.set $scratch_15
             (struct.get $type17 1
              (ref.cast (ref $type17)
               (local.get $0)
              )
             )
            )
            (call $foreign26
             (i64.const 3)
            )
            (drop
             (ref.as_non_null
              (global.get $global819)
             )
            )
            (local.get $scratch_15)
           )
          )
         )
         (else
          (if (result i32)
           (i32.eq
            (struct.get $type13 0
             (local.get $0)
            )
            (i32.const 4)
           )
           (then
            (local.set $11
             (call $foreign6
              (local.tee $12
               (struct.get $type22 0
                (block (result (ref $type22))
                 (local.set $scratch_16
                  (struct.get $type21 1
                   (ref.cast (ref $type21)
                    (local.get $0)
                   )
                  )
                 )
                 (call $foreign26
                  (i64.const 4)
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global263)
                  )
                 )
                 (local.get $scratch_16)
                )
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global61)
             )
            )
            (if
             (i64.gt_u
              (local.get $11)
              (i64.const 4294967294)
             )
             (then
              (unreachable)
             )
            )
            (return_call $function221
             (block (result (ref $type18))
              (local.set $scratch_17
               (call $function87
                (local.get $12)
                (local.get $11)
                (call $string-new
                 (i32.wrap_i64
                  (local.get $11)
                 )
                )
                (i32.const 0)
                (i32.const 1)
                (i64.const 0)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global819)
               )
              )
              (local.get $scratch_17)
             )
            )
           )
           (else
            (if (result i32)
             (i32.eq
              (struct.get $type13 0
               (local.get $0)
              )
              (i32.const 5)
             )
             (then
              (local.set $5
               (struct.get $type23 1
                (ref.cast (ref $type23)
                 (local.get $0)
                )
               )
              )
              (call $foreign26
               (i64.const 5)
              )
              (drop
               (ref.as_non_null
                (global.get $global828)
               )
              )
              (if (result i32)
               (local.tee $12
                (struct.get $type24 0
                 (local.get $5)
                )
               )
               (then
                (if (result i32)
                 (i32.eq
                  (local.get $12)
                  (i32.const 1)
                 )
                 (then
                  (call $foreign28
                   (block (result f64)
                    (local.set $scratch_18
                     (struct.get $type26 1
                      (ref.cast (ref $type26)
                       (local.get $5)
                      )
                     )
                    )
                    (call $foreign26
                     (i64.const 1)
                    )
                    (local.get $scratch_18)
                   )
                  )
                  (i32.const 0)
                 )
                 (else
                  (local.set $4
                   (struct.get $type27 1
                    (local.tee $8
                     (ref.cast (ref $type27)
                      (local.get $5)
                     )
                    )
                   )
                  )
                  (call $foreign26
                   (i64.const 2)
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global823)
                   )
                  )
                  (drop
                   (if (result i32)
                    (ref.test (ref $type29)
                     (local.get $4)
                    )
                    (then
                     (call $foreign26
                      (block (result i64)
                       (local.set $scratch_19
                        (struct.get $type29 0
                         (ref.cast (ref $type29)
                          (local.get $4)
                         )
                        )
                       )
                       (call $foreign26
                        (i64.const 0)
                       )
                       (local.get $scratch_19)
                      )
                     )
                     (i32.const 0)
                    )
                    (else
                     (call $foreign28
                      (block (result f64)
                       (local.set $scratch_20
                        (struct.get $type30 0
                         (ref.cast (ref $type30)
                          (local.get $4)
                         )
                        )
                       )
                       (call $foreign26
                        (i64.const 1)
                       )
                       (local.get $scratch_20)
                      )
                     )
                     (i32.const 0)
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global823)
                   )
                  )
                  (if
                   (ref.test (ref $type29)
                    (local.tee $4
                     (struct.get $type27 2
                      (local.get $8)
                     )
                    )
                   )
                   (then
                    (call $foreign26
                     (block (result i64)
                      (local.set $scratch_21
                       (struct.get $type29 0
                        (ref.cast (ref $type29)
                         (local.get $4)
                        )
                       )
                      )
                      (call $foreign26
                       (i64.const 0)
                      )
                      (local.get $scratch_21)
                     )
                    )
                   )
                   (else
                    (call $foreign28
                     (block (result f64)
                      (local.set $scratch_22
                       (struct.get $type30 0
                        (ref.cast (ref $type30)
                         (local.get $4)
                        )
                       )
                      )
                      (call $foreign26
                       (i64.const 1)
                      )
                      (local.get $scratch_22)
                     )
                    )
                   )
                  )
                  (i32.const 0)
                 )
                )
               )
               (else
                (call $foreign26
                 (block (result i64)
                  (local.set $scratch_23
                   (struct.get $type25 1
                    (ref.cast (ref $type25)
                     (local.get $5)
                    )
                   )
                  )
                  (call $foreign26
                   (i64.const 0)
                  )
                  (local.get $scratch_23)
                 )
                )
                (i32.const 0)
               )
              )
             )
             (else
              (if (result i32)
               (i32.eq
                (struct.get $type13 0
                 (local.get $0)
                )
                (i32.const 6)
               )
               (then
                (drop
                 (call $function225
                  (struct.get $type32 0
                   (block (result (ref $type32))
                    (local.set $scratch_24
                     (struct.get $type31 1
                      (local.tee $9
                       (ref.cast (ref $type31)
                        (local.get $0)
                       )
                      )
                     )
                    )
                    (call $foreign26
                     (i64.const 6)
                    )
                    (if
                     (i32.eqz
                      (global.get $ready835)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global835)
                     )
                    )
                    (local.get $scratch_24)
                   )
                  )
                 )
                )
                (if
                 (i32.eqz
                  (global.get $ready835)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global835)
                 )
                )
                (return_call $function225
                 (struct.get $type32 0
                  (struct.get $type31 2
                   (local.get $9)
                  )
                 )
                )
               )
               (else
                (if (result i32)
                 (i32.eq
                  (struct.get $type13 0
                   (local.get $0)
                  )
                  (i32.const 7)
                 )
                 (then
                  (local.set $1
                   (struct.get $type33 1
                    (ref.cast (ref $type33)
                     (local.get $0)
                    )
                   )
                  )
                  (call $foreign26
                   (i64.const 7)
                  )
                  (if
                   (i32.eqz
                    (global.get $ready846)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global846)
                   )
                  )
                  (call $foreign26
                   (local.tee $11
                    (i64.extend_i32_u
                     (array.len
                      (local.get $1)
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eqz
                    (local.get $11)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (drop
                     (ref.as_non_null
                      (global.get $global835)
                     )
                    )
                    (drop
                     (call $function225
                      (array.get $type34
                       (local.get $1)
                       (i32.const 0)
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $1)
                       )
                      )
                      (i64.const 1)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (drop
                       (ref.as_non_null
                        (global.get $global835)
                       )
                      )
                      (drop
                       (call $function225
                        (array.get $type34
                         (local.get $1)
                         (i32.const 1)
                        )
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (array.len
                          (local.get $1)
                         )
                        )
                        (i64.const 2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (drop
                         (ref.as_non_null
                          (global.get $global835)
                         )
                        )
                        (drop
                         (call $function225
                          (array.get $type34
                           (local.get $1)
                           (i32.const 2)
                          )
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (array.len
                            (local.get $1)
                           )
                          )
                          (i64.const 3)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (drop
                           (ref.as_non_null
                            (global.get $global835)
                           )
                          )
                          (drop
                           (call $function225
                            (array.get $type34
                             (local.get $1)
                             (i32.const 3)
                            )
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (array.len
                              (local.get $1)
                             )
                            )
                            (i64.const 4)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global835)
                             )
                            )
                            (drop
                             (call $function225
                              (array.get $type34
                               (local.get $1)
                               (i32.const 4)
                              )
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (array.len
                                (local.get $1)
                               )
                              )
                              (i64.const 5)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (drop
                               (ref.as_non_null
                                (global.get $global835)
                               )
                              )
                              (drop
                               (call $function225
                                (array.get $type34
                                 (local.get $1)
                                 (i32.const 5)
                                )
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $1)
                                 )
                                )
                                (i64.const 6)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (drop
                                 (ref.as_non_null
                                  (global.get $global835)
                                 )
                                )
                                (drop
                                 (call $function225
                                  (array.get $type34
                                   (local.get $1)
                                   (i32.const 6)
                                  )
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $1)
                                   )
                                  )
                                  (i64.const 7)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (drop
                                   (ref.as_non_null
                                    (global.get $global835)
                                   )
                                  )
                                  (drop
                                   (call $function225
                                    (array.get $type34
                                     (local.get $1)
                                     (i32.const 7)
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $1)
                                     )
                                    )
                                    (i64.const 8)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (drop
                                     (ref.as_non_null
                                      (global.get $global835)
                                     )
                                    )
                                    (drop
                                     (call $function225
                                      (array.get $type34
                                       (local.get $1)
                                       (i32.const 8)
                                      )
                                     )
                                    )
                                    (return_call $function227
                                     (local.get $1)
                                     (i32.const 0)
                                     (i32.const 1)
                                     (i64.const 9)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                 (else
                  (local.set $3
                   (struct.get $type35 1
                    (ref.cast (ref $type35)
                     (local.get $0)
                    )
                   )
                  )
                  (call $foreign26
                   (i64.const 8)
                  )
                  (if
                   (i32.eqz
                    (global.get $ready851)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global851)
                   )
                  )
                  (call $foreign26
                   (local.tee $11
                    (i64.extend_i32_u
                     (array.len
                      (struct.get $type36 0
                       (local.get $3)
                      )
                     )
                    )
                   )
                  )
                  (if (result i32)
                   (i64.eqz
                    (local.get $11)
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (call $foreign26
                     (i64.extend_i32_u
                      (array.get_u $type37
                       (local.tee $2
                        (struct.get $type36 0
                         (local.get $3)
                        )
                       )
                       (i32.const 0)
                      )
                     )
                    )
                    (if (result i32)
                     (i64.eq
                      (i64.extend_i32_u
                       (array.len
                        (local.get $2)
                       )
                      )
                      (i64.const 1)
                     )
                     (then
                      (i32.const 0)
                     )
                     (else
                      (call $foreign26
                       (i64.extend_i32_u
                        (array.get_u $type37
                         (local.tee $2
                          (struct.get $type36 0
                           (local.get $3)
                          )
                         )
                         (i32.const 1)
                        )
                       )
                      )
                      (if (result i32)
                       (i64.eq
                        (i64.extend_i32_u
                         (array.len
                          (local.get $2)
                         )
                        )
                        (i64.const 2)
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (call $foreign26
                         (i64.extend_i32_u
                          (array.get_u $type37
                           (local.tee $2
                            (struct.get $type36 0
                             (local.get $3)
                            )
                           )
                           (i32.const 2)
                          )
                         )
                        )
                        (if (result i32)
                         (i64.eq
                          (i64.extend_i32_u
                           (array.len
                            (local.get $2)
                           )
                          )
                          (i64.const 3)
                         )
                         (then
                          (i32.const 0)
                         )
                         (else
                          (call $foreign26
                           (i64.extend_i32_u
                            (array.get_u $type37
                             (local.tee $2
                              (struct.get $type36 0
                               (local.get $3)
                              )
                             )
                             (i32.const 3)
                            )
                           )
                          )
                          (if (result i32)
                           (i64.eq
                            (i64.extend_i32_u
                             (array.len
                              (local.get $2)
                             )
                            )
                            (i64.const 4)
                           )
                           (then
                            (i32.const 0)
                           )
                           (else
                            (call $foreign26
                             (i64.extend_i32_u
                              (array.get_u $type37
                               (local.tee $2
                                (struct.get $type36 0
                                 (local.get $3)
                                )
                               )
                               (i32.const 4)
                              )
                             )
                            )
                            (if (result i32)
                             (i64.eq
                              (i64.extend_i32_u
                               (array.len
                                (local.get $2)
                               )
                              )
                              (i64.const 5)
                             )
                             (then
                              (i32.const 0)
                             )
                             (else
                              (call $foreign26
                               (i64.extend_i32_u
                                (array.get_u $type37
                                 (local.tee $2
                                  (struct.get $type36 0
                                   (local.get $3)
                                  )
                                 )
                                 (i32.const 5)
                                )
                               )
                              )
                              (if (result i32)
                               (i64.eq
                                (i64.extend_i32_u
                                 (array.len
                                  (local.get $2)
                                 )
                                )
                                (i64.const 6)
                               )
                               (then
                                (i32.const 0)
                               )
                               (else
                                (call $foreign26
                                 (i64.extend_i32_u
                                  (array.get_u $type37
                                   (local.tee $2
                                    (struct.get $type36 0
                                     (local.get $3)
                                    )
                                   )
                                   (i32.const 6)
                                  )
                                 )
                                )
                                (if (result i32)
                                 (i64.eq
                                  (i64.extend_i32_u
                                   (array.len
                                    (local.get $2)
                                   )
                                  )
                                  (i64.const 7)
                                 )
                                 (then
                                  (i32.const 0)
                                 )
                                 (else
                                  (call $foreign26
                                   (i64.extend_i32_u
                                    (array.get_u $type37
                                     (local.tee $2
                                      (struct.get $type36 0
                                       (local.get $3)
                                      )
                                     )
                                     (i32.const 7)
                                    )
                                   )
                                  )
                                  (if (result i32)
                                   (i64.eq
                                    (i64.extend_i32_u
                                     (array.len
                                      (local.get $2)
                                     )
                                    )
                                    (i64.const 8)
                                   )
                                   (then
                                    (i32.const 0)
                                   )
                                   (else
                                    (call $foreign26
                                     (i64.extend_i32_u
                                      (array.get_u $type37
                                       (struct.get $type36 0
                                        (local.get $3)
                                       )
                                       (i32.const 8)
                                      )
                                     )
                                    )
                                    (return_call $function229
                                     (local.get $3)
                                     (i32.const 0)
                                     (i32.const 1)
                                     (i64.const 9)
                                    )
                                   )
                                  )
                                 )
                                )
                               )
                              )
                             )
                            )
                           )
                          )
                         )
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                 )
                )
               )
              )
             )
            )
           )
          )
         )
        )
       )
      )
     )
    )
   )
   (else
    (call $foreign26
     (i64.const 0)
    )
    (i32.const 0)
   )
  )
 )
 (func $function227 (type $11) (param $0 (ref $type34)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (local.get $0)
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (drop
     (ref.as_non_null
      (global.get $global835)
     )
    )
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (drop
     (call $function225
      (array.get $type34
       (local.get $0)
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function227
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function229 (type $10) (param $0 (ref $type36)) (param $1 i32) (param $2 i32) (param $3 i64) (result i32)
  (if (result i32)
   (i64.eq
    (i64.extend_i32_u
     (array.len
      (struct.get $type36 0
       (local.get $0)
      )
     )
    )
    (local.get $3)
   )
   (then
    (i32.const 0)
   )
   (else
    (if
     (i64.gt_u
      (local.get $3)
      (i64.const 4294967295)
     )
     (then
      (unreachable)
     )
    )
    (call $foreign26
     (i64.extend_i32_u
      (array.get_u $type37
       (struct.get $type36 0
        (local.get $0)
       )
       (i32.wrap_i64
        (local.get $3)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function229
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
  )
 )
 (func $function232 (type $9) (param $0 (ref $type121)) (param $1 i32) (param $2 i32) (param $3 i64) (result i64)
  (local $4 (ref $type101))
  (local $5 (ref $type163))
  (local $6 (ref $type18))
  (local $scratch (ref $type18))
  (drop
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (if
   (i32.eqz
    (global.get $ready527)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (local.set $5
   (call $function154
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready702)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global702)
   )
  )
  (if (result i64)
   (i32.eq
    (struct.get $type101 0
     (local.tee $4
      (call $function196
       (local.get $0)
       (local.get $5)
      )
     )
    )
    (i32.const 1)
   )
   (then
    (drop
     (ref.as_non_null
      (global.get $global835)
     )
    )
    (drop
     (call $function225
      (struct.get $type103 1
       (ref.cast (ref $type103)
        (local.get $4)
       )
      )
     )
    )
    (if
     (i32.eqz
      (local.get $2)
     )
     (then
      (unreachable)
     )
    )
    (return_call $function232
     (local.get $0)
     (local.get $1)
     (local.get $2)
     (i64.add
      (local.get $3)
      (i64.const 1)
     )
    )
   )
   (else
    (if (result i64)
     (struct.get $type101 0
      (local.get $4)
     )
     (then
      (drop
       (call $function221
        (block (result (ref $type18))
         (local.set $scratch
          (struct.get $type104 1
           (ref.cast (ref $type104)
            (local.get $4)
           )
          )
         )
         (call $foreign26
          (i64.const 99)
         )
         (drop
          (ref.as_non_null
           (global.get $global819)
          )
         )
         (local.get $scratch)
        )
       )
      )
      (i64.const -1)
     )
     (else
      (drop
       (ref.as_non_null
        (global.get $global525)
       )
      )
      (if
       (i32.eqz
        (global.get $ready527)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global527)
       )
      )
      (local.set $5
       (call $function154
        (local.get $0)
       )
      )
      (if
       (i32.eqz
        (global.get $ready702)
       )
       (then
        (unreachable)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global702)
       )
      )
      (local.set $4
       (call $function196
        (local.get $0)
        (local.get $5)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global515)
       )
      )
      (if (result i64)
       (if (result i32)
        (local.tee $1
         (struct.get $type101 0
          (local.get $4)
         )
        )
        (then
         (if
          (i32.eq
           (local.get $1)
           (i32.const 1)
          )
          (then
           (drop
            (ref.cast (ref $type103)
             (local.get $4)
            )
           )
          )
          (else
           (drop
            (ref.cast (ref $type104)
             (local.get $4)
            )
           )
          )
         )
         (i32.const 0)
        )
        (else
         (i32.const 1)
        )
       )
       (then
        (local.get $3)
       )
       (else
        (unreachable)
       )
      )
     )
    )
   )
  )
 )
 (func $export0 (result i64)
  (local $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (local $5 (ref $type92))
  (local $6 (ref $type24))
  (local $7 (ref $type23))
  (local $8 (ref $type23))
  (local $9 (ref $type23))
  (local $10 (ref $type34))
  (local $11 (ref $type34))
  (local $12 (ref $type34))
  (local $13 (ref $type31))
  (local $14 (ref $type31))
  (local $15 (ref $type36))
  (local $16 (ref $type36))
  (local $17 (ref $type28))
  (local $18 (ref $type28))
  (local $19 (ref $type18))
  (local $20 (ref $type18))
  (local $21 (ref $type18))
  (local $22 (ref $type14))
  (local $23 (ref $type27))
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready801)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global801)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global258)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $0
   (call $foreign5
    (call $function80
     (local.tee $19
      (global.get $string53)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global88)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global81)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global61)
   )
  )
  (call $string-copy
   (local.tee $21
    (call $string-new
     (i32.const 2)
    )
   )
   (i64.const 0)
   (local.get $19)
   (i64.const 2)
  )
  (drop
   (ref.as_non_null
    (global.get $global258)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $2
   (call $foreign5
    (call $function80
     (local.get $21)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global351)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global786)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global308)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global246)
   )
  )
  (local.set $3
   (call $foreign13
    (local.tee $1
     (call $function80
      (global.get $string62)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global305)
   )
  )
  (local.set $5
   (call $function97
    (local.get $1)
    (local.get $3)
   )
  )
  (call $foreign4
   (local.get $1)
  )
  (if
   (i32.ne
    (struct.get $type92 0
     (local.get $5)
    )
    (i32.const 1)
   )
   (then
    (unreachable)
   )
  )
  (local.set $6
   (struct.get $type94 1
    (ref.cast (ref $type94)
     (local.get $5)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global358)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global788)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global351)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global111)
   )
  )
  (local.set $16
   (call $function42
    (struct.new $type56
     (i64.const 1)
     (struct.new $type56
      (i64.const 2)
      (ref.null none)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global795)
   )
  )
  (if
   (i32.eqz
    (global.get $ready726)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global726)
   )
  )
  (local.set $9
   (struct.new $type23
    (i32.const 5)
    (local.get $6)
   )
  )
  (local.set $13
   (struct.new $type31
    (i32.const 6)
    (struct.new $type32
     (local.tee $7
      (struct.new $type23
       (i32.const 5)
       (struct.new $type25
        (i32.const 0)
        (i64.const 1)
       )
      )
     )
    )
    (struct.new $type32
     (local.tee $22
      (global.get $empty14)
     )
    )
   )
  )
  (local.set $10
   (call $function202
    (struct.new $type12
     (local.get $7)
     (struct.new $type12
      (local.tee $8
       (struct.new $type23
        (i32.const 5)
        (struct.new $type25
         (i32.const 0)
         (i64.const 2)
        )
       )
      )
      (ref.null none)
     )
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global417)
   )
  )
  (select
   (i64.const 42)
   (i64.const 0)
   (if (result i32)
    (if (result i32)
     (call $function122
      (local.get $13)
      (local.tee $14
       (struct.new $type31
        (i32.const 6)
        (struct.new $type32
         (local.get $7)
        )
        (struct.new $type32
         (local.get $22)
        )
       )
      )
     )
     (then
      (drop
       (ref.as_non_null
        (global.get $global351)
       )
      )
      (drop
       (ref.as_non_null
        (global.get $global417)
       )
      )
      (if (result i32)
       (call $function122
        (local.get $13)
        (struct.new $type31
         (i32.const 6)
         (struct.new $type32
          (local.get $8)
         )
         (struct.new $type32
          (local.get $22)
         )
        )
       )
       (then
        (i32.const 0)
       )
       (else
        (drop
         (ref.as_non_null
          (global.get $global351)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global417)
         )
        )
        (if (result i32)
         (call $function122
          (local.get $13)
          (struct.new $type31
           (i32.const 6)
           (struct.new $type32
            (local.get $7)
           )
           (struct.new $type32
            (local.get $14)
           )
          )
         )
         (then
          (i32.const 0)
         )
         (else
          (drop
           (ref.as_non_null
            (global.get $global797)
           )
          )
          (local.set $11
           (if (result (ref $type34))
            (i64.eqz
             (local.tee $4
              (i64.extend_i32_u
               (array.len
                (local.get $10)
               )
              )
             )
            )
            (then
             (array.new_fixed $type34 0)
            )
            (else
             (if
              (i64.gt_u
               (local.get $4)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (local.set $11
              (array.new $type34
               (array.get $type34
                (local.get $10)
                (i32.const 0)
               )
               (i32.wrap_i64
                (local.get $4)
               )
              )
             )
             (if
              (i64.gt_u
               (local.get $4)
               (i64.const 4294967295)
              )
              (then
               (unreachable)
              )
             )
             (array.copy $type34 $type34
              (local.get $11)
              (i32.const 0)
              (local.get $10)
              (i32.const 0)
              (i32.wrap_i64
               (local.get $4)
              )
             )
             (local.get $11)
            )
           )
          )
          (drop
           (ref.as_non_null
            (global.get $global417)
           )
          )
          (if (result i32)
           (call $function122
            (struct.new $type33
             (i32.const 7)
             (local.get $10)
            )
            (struct.new $type33
             (i32.const 7)
             (local.get $11)
            )
           )
           (then
            (drop
             (ref.as_non_null
              (global.get $global795)
             )
            )
            (if
             (i32.eqz
              (global.get $ready726)
             )
             (then
              (unreachable)
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global726)
             )
            )
            (local.set $12
             (call $function202
              (struct.new $type12
               (local.get $8)
               (struct.new $type12
                (local.get $7)
                (ref.null none)
               )
              )
             )
            )
            (drop
             (ref.as_non_null
              (global.get $global417)
             )
            )
            (if (result i32)
             (call $function122
              (struct.new $type33
               (i32.const 7)
               (local.get $10)
              )
              (struct.new $type33
               (i32.const 7)
               (local.get $12)
              )
             )
             (then
              (i32.const 0)
             )
             (else
              (drop
               (ref.as_non_null
                (global.get $global111)
               )
              )
              (local.set $15
               (call $function42
                (struct.new $type56
                 (i64.const 1)
                 (struct.new $type56
                  (i64.const 2)
                  (ref.null none)
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global417)
               )
              )
              (if (result i32)
               (call $function122
                (struct.new $type35
                 (i32.const 8)
                 (local.get $16)
                )
                (struct.new $type35
                 (i32.const 8)
                 (local.get $15)
                )
               )
               (then
                (drop
                 (ref.as_non_null
                  (global.get $global111)
                 )
                )
                (local.set $15
                 (call $function42
                  (struct.new $type56
                   (i64.const 1)
                   (struct.new $type56
                    (i64.const 3)
                    (ref.null none)
                   )
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global417)
                 )
                )
                (if (result i32)
                 (call $function122
                  (struct.new $type35
                   (i32.const 8)
                   (local.get $16)
                  )
                  (struct.new $type35
                   (i32.const 8)
                   (local.get $15)
                  )
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (drop
                   (ref.as_non_null
                    (global.get $global417)
                   )
                  )
                  (i32.eqz
                   (call $function122
                    (struct.new $type17
                     (i32.const 3)
                     (global.get $string52)
                    )
                    (local.get $7)
                   )
                  )
                 )
                )
               )
               (else
                (i32.const 0)
               )
              )
             )
            )
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global260)
      )
     )
     (if (result i32)
      (i32.eq
       (local.get $0)
       (local.get $2)
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global263)
        )
       )
       (local.set $4
        (call $foreign6
         (local.get $0)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global61)
        )
       )
       (if
        (i64.gt_u
         (local.get $4)
         (i64.const 4294967294)
        )
        (then
         (unreachable)
        )
       )
       (local.set $20
        (call $function87
         (local.get $0)
         (local.get $4)
         (call $string-new
          (i32.wrap_i64
           (local.get $4)
          )
         )
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (drop
        (ref.as_non_null
         (global.get $global103)
        )
       )
       (if (result i32)
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $20)
           )
          )
          (i64.const 2)
         )
         (then
          (call $function40
           (local.get $20)
           (local.get $19)
           (i32.const 0)
           (i32.const 1)
           (i64.const 0)
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global786)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global308)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global246)
          )
         )
         (local.set $1
          (call $foreign13
           (local.tee $0
            (call $function80
             (global.get $string61)
            )
           )
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global305)
          )
         )
         (local.set $5
          (call $function97
           (local.get $0)
           (local.get $1)
          )
         )
         (call $foreign4
          (local.get $0)
         )
         (if
          (i32.ne
           (struct.get $type92 0
            (local.get $5)
           )
           (i32.const 1)
          )
          (then
           (unreachable)
          )
         )
         (drop
          (ref.as_non_null
           (global.get $global332)
          )
         )
         (if (result i32)
          (call $function101
           (struct.get $type94 1
            (ref.cast (ref $type94)
             (local.get $5)
            )
           )
           (struct.new $type25
            (i32.const 0)
            (i64.const -9223372036854775808)
           )
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global786)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global308)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global246)
            )
           )
           (local.set $1
            (call $foreign13
             (local.tee $0
              (call $function80
               (global.get $string60)
              )
             )
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global305)
            )
           )
           (local.set $5
            (call $function97
             (local.get $0)
             (local.get $1)
            )
           )
           (call $foreign4
            (local.get $0)
           )
           (if
            (i32.ne
             (struct.get $type92 0
              (local.get $5)
             )
             (i32.const 1)
            )
            (then
             (unreachable)
            )
           )
           (if (result i32)
            (call $function101
             (struct.get $type94 1
              (ref.cast (ref $type94)
               (local.get $5)
              )
             )
             (block (result (ref $type24))
              (drop
               (ref.as_non_null
                (global.get $global786)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global308)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global246)
               )
              )
              (local.set $1
               (call $foreign13
                (local.tee $0
                 (call $function80
                  (global.get $string52)
                 )
                )
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global305)
               )
              )
              (local.set $5
               (call $function97
                (local.get $0)
                (local.get $1)
               )
              )
              (call $foreign4
               (local.get $0)
              )
              (if
               (i32.ne
                (struct.get $type92 0
                 (local.get $5)
                )
                (i32.const 1)
               )
               (then
                (unreachable)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global332)
               )
              )
              (struct.get $type94 1
               (ref.cast (ref $type94)
                (local.get $5)
               )
              )
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global786)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global308)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global246)
              )
             )
             (local.set $1
              (call $foreign13
               (local.tee $0
                (call $function80
                 (global.get $string58)
                )
               )
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global305)
              )
             )
             (local.set $5
              (call $function97
               (local.get $0)
               (local.get $1)
              )
             )
             (call $foreign4
              (local.get $0)
             )
             (if
              (i32.ne
               (struct.get $type92 0
                (local.get $5)
               )
               (i32.const 1)
              )
              (then
               (unreachable)
              )
             )
             (if (result i32)
              (call $function101
               (struct.get $type94 1
                (ref.cast (ref $type94)
                 (local.get $5)
                )
               )
               (block (result (ref $type24))
                (drop
                 (ref.as_non_null
                  (global.get $global786)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global308)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global246)
                 )
                )
                (local.set $1
                 (call $foreign13
                  (local.tee $0
                   (call $function80
                    (global.get $string59)
                   )
                  )
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global305)
                 )
                )
                (local.set $5
                 (call $function97
                  (local.get $0)
                  (local.get $1)
                 )
                )
                (call $foreign4
                 (local.get $0)
                )
                (if
                 (i32.ne
                  (struct.get $type92 0
                   (local.get $5)
                  )
                  (i32.const 1)
                 )
                 (then
                  (unreachable)
                 )
                )
                (drop
                 (ref.as_non_null
                  (global.get $global332)
                 )
                )
                (struct.get $type94 1
                 (ref.cast (ref $type94)
                  (local.get $5)
                 )
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (drop
                (ref.as_non_null
                 (global.get $global786)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global308)
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global246)
                )
               )
               (local.set $1
                (call $foreign13
                 (local.tee $0
                  (call $function80
                   (global.get $string56)
                  )
                 )
                )
               )
               (drop
                (ref.as_non_null
                 (global.get $global305)
                )
               )
               (local.set $5
                (call $function97
                 (local.get $0)
                 (local.get $1)
                )
               )
               (call $foreign4
                (local.get $0)
               )
               (if
                (i32.ne
                 (struct.get $type92 0
                  (local.get $5)
                 )
                 (i32.const 1)
                )
                (then
                 (unreachable)
                )
               )
               (if (result i32)
                (call $function101
                 (struct.get $type94 1
                  (ref.cast (ref $type94)
                   (local.get $5)
                  )
                 )
                 (block (result (ref $type24))
                  (drop
                   (ref.as_non_null
                    (global.get $global786)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global308)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global246)
                   )
                  )
                  (local.set $1
                   (call $foreign13
                    (local.tee $0
                     (call $function80
                      (global.get $string57)
                     )
                    )
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global305)
                   )
                  )
                  (local.set $5
                   (call $function97
                    (local.get $0)
                    (local.get $1)
                   )
                  )
                  (call $foreign4
                   (local.get $0)
                  )
                  (if
                   (i32.ne
                    (struct.get $type92 0
                     (local.get $5)
                    )
                    (i32.const 1)
                   )
                   (then
                    (unreachable)
                   )
                  )
                  (drop
                   (ref.as_non_null
                    (global.get $global332)
                   )
                  )
                  (struct.get $type94 1
                   (ref.cast (ref $type94)
                    (local.get $5)
                   )
                  )
                 )
                )
                (then
                 (drop
                  (ref.as_non_null
                   (global.get $global786)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global308)
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global246)
                  )
                 )
                 (local.set $1
                  (call $foreign13
                   (local.tee $0
                    (call $function80
                     (global.get $string52)
                    )
                   )
                  )
                 )
                 (drop
                  (ref.as_non_null
                   (global.get $global305)
                  )
                 )
                 (local.set $5
                  (call $function97
                   (local.get $0)
                   (local.get $1)
                  )
                 )
                 (call $foreign4
                  (local.get $0)
                 )
                 (if
                  (i32.ne
                   (struct.get $type92 0
                    (local.get $5)
                   )
                   (i32.const 1)
                  )
                  (then
                   (unreachable)
                  )
                 )
                 (if (result i32)
                  (call $function101
                   (struct.get $type94 1
                    (ref.cast (ref $type94)
                     (local.get $5)
                    )
                   )
                   (block (result (ref $type24))
                    (drop
                     (ref.as_non_null
                      (global.get $global786)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global308)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global246)
                     )
                    )
                    (local.set $1
                     (call $foreign13
                      (local.tee $0
                       (call $function80
                        (global.get $string55)
                       )
                      )
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global305)
                     )
                    )
                    (local.set $5
                     (call $function97
                      (local.get $0)
                      (local.get $1)
                     )
                    )
                    (call $foreign4
                     (local.get $0)
                    )
                    (if
                     (i32.ne
                      (struct.get $type92 0
                       (local.get $5)
                      )
                      (i32.const 1)
                     )
                     (then
                      (unreachable)
                     )
                    )
                    (drop
                     (ref.as_non_null
                      (global.get $global332)
                     )
                    )
                    (struct.get $type94 1
                     (ref.cast (ref $type94)
                      (local.get $5)
                     )
                    )
                   )
                  )
                  (then
                   (i32.const 0)
                  )
                  (else
                   (drop
                    (ref.as_non_null
                     (global.get $global354)
                    )
                   )
                   (drop
                    (ref.as_non_null
                     (global.get $global417)
                    )
                   )
                   (if (result i32)
                    (call $function122
                     (local.get $9)
                     (struct.new $type23
                      (i32.const 5)
                      (struct.new $type25
                       (i32.const 0)
                       (i64.const 9007199254740993)
                      )
                     )
                    )
                    (then
                     (drop
                      (ref.as_non_null
                       (global.get $global786)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global308)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global246)
                      )
                     )
                     (local.set $1
                      (call $foreign13
                       (local.tee $0
                        (call $function80
                         (global.get $string54)
                        )
                       )
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global305)
                      )
                     )
                     (local.set $5
                      (call $function97
                       (local.get $0)
                       (local.get $1)
                      )
                     )
                     (call $foreign4
                      (local.get $0)
                     )
                     (if
                      (i32.ne
                       (struct.get $type92 0
                        (local.get $5)
                       )
                       (i32.const 1)
                      )
                      (then
                       (unreachable)
                      )
                     )
                     (drop
                      (ref.as_non_null
                       (global.get $global289)
                      )
                     )
                     (f64.eq
                      (if (result f64)
                       (local.tee $0
                        (struct.get $type24 0
                         (local.tee $6
                          (struct.get $type94 1
                           (ref.cast (ref $type94)
                            (local.get $5)
                           )
                          )
                         )
                        )
                       )
                       (then
                        (if (result f64)
                         (i32.eq
                          (local.get $0)
                          (i32.const 1)
                         )
                         (then
                          (struct.get $type26 1
                           (ref.cast (ref $type26)
                            (local.get $6)
                           )
                          )
                         )
                         (else
                          (local.set $17
                           (struct.get $type27 1
                            (local.tee $23
                             (ref.cast (ref $type27)
                              (local.get $6)
                             )
                            )
                           )
                          )
                          (drop
                           (ref.as_non_null
                            (global.get $global284)
                           )
                          )
                          (if (result f64)
                           (f64.eq
                            (if (result f64)
                             (ref.test (ref $type29)
                              (local.tee $18
                               (struct.get $type27 2
                                (local.get $23)
                               )
                              )
                             )
                             (then
                              (f64.convert_i64_s
                               (struct.get $type29 0
                                (ref.cast (ref $type29)
                                 (local.get $18)
                                )
                               )
                              )
                             )
                             (else
                              (struct.get $type30 0
                               (ref.cast (ref $type30)
                                (local.get $18)
                               )
                              )
                             )
                            )
                            (f64.const 0)
                           )
                           (then
                            (drop
                             (ref.as_non_null
                              (global.get $global284)
                             )
                            )
                            (if (result f64)
                             (ref.test (ref $type29)
                              (local.get $17)
                             )
                             (then
                              (f64.convert_i64_s
                               (struct.get $type29 0
                                (ref.cast (ref $type29)
                                 (local.get $17)
                                )
                               )
                              )
                             )
                             (else
                              (struct.get $type30 0
                               (ref.cast (ref $type30)
                                (local.get $17)
                               )
                              )
                             )
                            )
                           )
                           (else
                            (drop
                             (ref.as_non_null
                              (global.get $global252)
                             )
                            )
                            (drop
                             (ref.as_non_null
                              (global.get $global246)
                             )
                            )
                            (call $foreign2
                             (call $function80
                              (global.get $string0)
                             )
                            )
                            (unreachable)
                           )
                          )
                         )
                        )
                       )
                       (else
                        (f64.convert_i64_s
                         (struct.get $type25 1
                          (ref.cast (ref $type25)
                           (local.get $6)
                          )
                         )
                        )
                       )
                      )
                      (f64.const 12.5)
                     )
                    )
                    (else
                     (i32.const 0)
                    )
                   )
                  )
                 )
                )
                (else
                 (i32.const 0)
                )
               )
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
 )
 (func $export1 (result i64)
  (local $0 (ref $type121))
  (local $1 (ref $type119))
  (local $2 i64)
  (local $3 i32)
  (local $scratch i64)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready855)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global855)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global862)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global455)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global444)
   )
  )
  (drop
   (call $function127
    (global.get $string67)
   )
  )
  (local.set $scratch
   (call $function232
    (local.tee $0
     (struct.new $type121
      (struct.new $type119
       (call $foreign20)
      )
     )
    )
    (i32.const 0)
    (i32.const 1)
    (i64.const 0)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global462)
   )
  )
  (if
   (i32.eqz
    (global.get $ready459)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global459)
   )
  )
  (if
   (i32.ne
    (local.tee $3
     (struct.get $type119 0
      (local.tee $1
       (struct.get $type121 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type119 0
     (local.get $1)
     (i32.const -1)
    )
    (call $foreign21
     (local.get $3)
    )
   )
  )
  (local.get $scratch)
 )
 (func $export2 (result i32)
  (local $0 (ref $type121))
  (local $1 (ref $type101))
  (local $2 (ref $type163))
  (local $3 (ref $type13))
  (local $4 (ref $type13))
  (local $5 (ref $type18))
  (local $6 (ref $type18))
  (local $7 (ref $type18))
  (local $8 (ref $type22))
  (local $9 (ref $type22))
  (local $10 (ref $type119))
  (local $11 i32)
  (local $12 i32)
  (local $13 i64)
  (local $scratch (ref $type101))
  (local $scratch_15 (ref $type101))
  (local $scratch_16 (ref $type101))
  (local $scratch_17 (ref $type101))
  (local $scratch_18 (ref $type22))
  (local $scratch_19 i32)
  (if
   (i32.ne
    (global.get $execution)
    (i32.const 2)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.eqz
    (global.get $ready805)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global805)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global814)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global455)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global444)
   )
  )
  (drop
   (call $function127
    (global.get $string63)
   )
  )
  (local.set $0
   (struct.new $type121
    (struct.new $type119
     (call $foreign20)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global525)
   )
  )
  (if
   (i32.eqz
    (global.get $ready527)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global527)
   )
  )
  (local.set $2
   (call $function154
    (local.get $0)
   )
  )
  (if
   (i32.eqz
    (global.get $ready702)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global702)
   )
  )
  (local.set $4
   (call $function152
    (block (result (ref $type101))
     (local.set $scratch
      (call $function196
       (local.get $0)
       (local.get $2)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global520)
      )
     )
     (local.get $scratch)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global354)
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (local.get $4)
    )
    (i32.const 6)
   )
   (then
    (unreachable)
   )
  )
  (if
   (i32.ne
    (struct.get $type13 0
     (local.tee $3
      (struct.get $type32 0
       (struct.get $type31 1
        (ref.cast (ref $type31)
         (local.get $4)
        )
       )
      )
     )
    )
    (i32.const 4)
   )
   (then
    (unreachable)
   )
  )
  (local.set $scratch_19
   (if (result i32)
    (i32.eq
     (local.tee $11
      (struct.get $type22 0
       (block (result (ref $type22))
        (local.set $scratch_18
         (struct.get $type21 1
          (ref.cast (ref $type21)
           (local.get $3)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global525)
         )
        )
        (if
         (i32.eqz
          (global.get $ready527)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global527)
         )
        )
        (local.set $2
         (call $function154
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready702)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global702)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.tee $3
            (call $function152
             (block (result (ref $type101))
              (local.set $scratch_15
               (call $function196
                (local.get $0)
                (local.get $2)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global520)
               )
              )
              (local.get $scratch_15)
             )
            )
           )
          )
          (i32.const 4)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global263)
         )
        )
        (local.set $13
         (call $foreign6
          (local.tee $11
           (struct.get $type22 0
            (local.tee $9
             (struct.get $type21 1
              (ref.cast (ref $type21)
               (local.get $3)
              )
             )
            )
           )
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global61)
         )
        )
        (if
         (i64.gt_u
          (local.get $13)
          (i64.const 4294967294)
         )
         (then
          (unreachable)
         )
        )
        (local.set $5
         (call $function87
          (local.get $11)
          (local.get $13)
          (call $string-new
           (i32.wrap_i64
            (local.get $13)
           )
          )
          (i32.const 0)
          (i32.const 1)
          (i64.const 0)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global525)
         )
        )
        (if
         (i32.eqz
          (global.get $ready527)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global527)
         )
        )
        (local.set $2
         (call $function154
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready702)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global702)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.tee $3
            (call $function152
             (block (result (ref $type101))
              (local.set $scratch_16
               (call $function196
                (local.get $0)
                (local.get $2)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global520)
               )
              )
              (local.get $scratch_16)
             )
            )
           )
          )
          (i32.const 3)
         )
         (then
          (unreachable)
         )
        )
        (local.set $6
         (struct.get $type17 1
          (ref.cast (ref $type17)
           (local.get $3)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global525)
         )
        )
        (if
         (i32.eqz
          (global.get $ready527)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global527)
         )
        )
        (local.set $2
         (call $function154
          (local.get $0)
         )
        )
        (if
         (i32.eqz
          (global.get $ready702)
         )
         (then
          (unreachable)
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global702)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.tee $3
            (call $function152
             (block (result (ref $type101))
              (local.set $scratch_17
               (call $function196
                (local.get $0)
                (local.get $2)
               )
              )
              (drop
               (ref.as_non_null
                (global.get $global520)
               )
              )
              (local.get $scratch_17)
             )
            )
           )
          )
          (i32.const 3)
         )
         (then
          (unreachable)
         )
        )
        (local.set $7
         (struct.get $type17 1
          (ref.cast (ref $type17)
           (local.get $3)
          )
         )
        )
        (drop
         (ref.as_non_null
          (global.get $global361)
         )
        )
        (if
         (i32.ne
          (struct.get $type13 0
           (local.get $4)
          )
          (i32.const 6)
         )
         (then
          (unreachable)
         )
        )
        (struct.set $type32 0
         (struct.get $type31 2
          (ref.cast (ref $type31)
           (local.get $4)
          )
         )
         (struct.new $type23
          (i32.const 5)
          (struct.new $type25
           (i32.const 0)
           (i64.const 42)
          )
         )
        )
        (if
         (i32.ne
          (struct.get $type18 0
           (local.get $6)
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.eqz
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $6)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (array.set $type19
         (struct.get $type18 2
          (local.get $6)
         )
         (i32.const 0)
         (i32.const 88)
        )
        (if
         (i32.ne
          (struct.get $type18 0
           (local.get $5)
          )
          (i32.const 1)
         )
         (then
          (unreachable)
         )
        )
        (if
         (i64.eqz
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $5)
           )
          )
         )
         (then
          (unreachable)
         )
        )
        (array.set $type19
         (struct.get $type18 2
          (local.get $5)
         )
         (i32.const 0)
         (i32.const 88)
        )
        (drop
         (ref.as_non_null
          (global.get $global260)
         )
        )
        (local.get $scratch_18)
       )
      )
     )
     (struct.get $type22 0
      (local.get $9)
     )
    )
    (then
     (drop
      (ref.as_non_null
       (global.get $global263)
      )
     )
     (local.set $13
      (call $foreign6
       (local.get $11)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global61)
      )
     )
     (if
      (i64.gt_u
       (local.get $13)
       (i64.const 4294967294)
      )
      (then
       (unreachable)
      )
     )
     (local.set $5
      (call $function87
       (local.get $11)
       (local.get $13)
       (call $string-new
        (i32.wrap_i64
         (local.get $13)
        )
       )
       (i32.const 0)
       (i32.const 1)
       (i64.const 0)
      )
     )
     (drop
      (ref.as_non_null
       (global.get $global103)
      )
     )
     (if (result i32)
      (if (result i32)
       (i64.eq
        (i64.extend_i32_u
         (struct.get $type18 1
          (local.get $5)
         )
        )
        (i64.const 4)
       )
       (then
        (call $function40
         (local.get $5)
         (global.get $string66)
         (i32.const 0)
         (i32.const 1)
         (i64.const 0)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (drop
        (ref.as_non_null
         (global.get $global103)
        )
       )
       (if (result i32)
        (if (result i32)
         (i64.eq
          (i64.extend_i32_u
           (struct.get $type18 1
            (local.get $6)
           )
          )
          (i64.const 4)
         )
         (then
          (call $function40
           (local.get $6)
           (global.get $string65)
           (i32.const 0)
           (i32.const 1)
           (i64.const 0)
          )
         )
         (else
          (i32.const 0)
         )
        )
        (then
         (drop
          (ref.as_non_null
           (global.get $global103)
          )
         )
         (if (result i32)
          (if (result i32)
           (i64.eq
            (i64.extend_i32_u
             (struct.get $type18 1
              (local.get $7)
             )
            )
            (i64.const 4)
           )
           (then
            (call $function40
             (local.get $7)
             (global.get $string64)
             (i32.const 0)
             (i32.const 1)
             (i64.const 0)
            )
           )
           (else
            (i32.const 0)
           )
          )
          (then
           (drop
            (ref.as_non_null
             (global.get $global356)
            )
           )
           (drop
            (ref.as_non_null
             (global.get $global417)
            )
           )
           (if
            (i32.ne
             (struct.get $type13 0
              (local.get $4)
             )
             (i32.const 6)
            )
            (then
             (unreachable)
            )
           )
           (if (result i32)
            (call $function122
             (struct.get $type32 0
              (struct.get $type31 2
               (ref.cast (ref $type31)
                (local.get $4)
               )
              )
             )
             (struct.new $type23
              (i32.const 5)
              (struct.new $type25
               (i32.const 0)
               (i64.const 42)
              )
             )
            )
            (then
             (drop
              (ref.as_non_null
               (global.get $global525)
              )
             )
             (if
              (i32.eqz
               (global.get $ready527)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global527)
              )
             )
             (local.set $2
              (call $function154
               (local.get $0)
              )
             )
             (if
              (i32.eqz
               (global.get $ready702)
              )
              (then
               (unreachable)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global702)
              )
             )
             (local.set $1
              (call $function196
               (local.get $0)
               (local.get $2)
              )
             )
             (drop
              (ref.as_non_null
               (global.get $global515)
              )
             )
             (if (result i32)
              (local.tee $11
               (struct.get $type101 0
                (local.get $1)
               )
              )
              (then
               (if
                (i32.eq
                 (local.get $11)
                 (i32.const 1)
                )
                (then
                 (drop
                  (ref.cast (ref $type103)
                   (local.get $1)
                  )
                 )
                )
                (else
                 (drop
                  (ref.cast (ref $type104)
                   (local.get $1)
                  )
                 )
                )
               )
               (i32.const 0)
              )
              (else
               (i32.const 1)
              )
             )
            )
            (else
             (i32.const 0)
            )
           )
          )
          (else
           (i32.const 0)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global462)
   )
  )
  (if
   (i32.eqz
    (global.get $ready459)
   )
   (then
    (unreachable)
   )
  )
  (drop
   (ref.as_non_null
    (global.get $global459)
   )
  )
  (if
   (i32.ne
    (local.tee $12
     (struct.get $type119 0
      (local.tee $10
       (struct.get $type121 0
        (local.get $0)
       )
      )
     )
    )
    (i32.const -1)
   )
   (then
    (struct.set $type119 0
     (local.get $10)
     (i32.const -1)
    )
    (call $foreign21
     (local.get $12)
    )
   )
  )
  (local.get $scratch_19)
 )
 (func $main
  (if
   (global.get $execution)
   (then
    (unreachable)
   )
  )
  (global.set $execution
   (i32.const 1)
  )
  (global.set $global795
   (struct.new_default $type11)
  )
  (global.set $global726
   (struct.new_default $type38)
  )
  (global.set $ready726
   (i32.const 1)
  )
  (global.set $global729
   (struct.new_default $type41)
  )
  (global.set $ready729
   (i32.const 1)
  )
  (global.set $global797
   (struct.new_default $type42)
  )
  (global.set $global61
   (struct.new_default $type43)
  )
  (global.set $global81
   (struct.new_default $type47)
  )
  (global.set $global88
   (struct.new_default $type48)
  )
  (global.set $global90
   (struct.new_default $type49)
  )
  (global.set $global93
   (struct.new_default $type51)
  )
  (global.set $ready93
   (i32.const 1)
  )
  (global.set $global98
   (struct.new_default $type52)
  )
  (global.set $ready98
   (i32.const 1)
  )
  (global.set $global103
   (struct.new_default $type53)
  )
  (global.set $global109
   (struct.new_default $type54)
  )
  (global.set $global111
   (struct.new_default $type55)
  )
  (global.set $global114
   (struct.new_default $type57)
  )
  (global.set $ready114
   (i32.const 1)
  )
  (global.set $global246
   (struct.new_default $type81)
  )
  (global.set $global252
   (struct.new_default $type82)
  )
  (global.set $global258
   (struct.new_default $type84)
  )
  (global.set $global260
   (struct.new_default $type85)
  )
  (global.set $global263
   (struct.new_default $type86)
  )
  (global.set $global284
   (struct.new_default $type87)
  )
  (global.set $global289
   (struct.new_default $type88)
  )
  (global.set $global296
   (struct.new_default $type89)
  )
  (global.set $global299
   (struct.new_default $type90)
  )
  (global.set $global305
   (struct.new_default $type91)
  )
  (global.set $global308
   (struct.new_default $type96)
  )
  (global.set $global313
   (struct.new_default $type97)
  )
  (global.set $global325
   (struct.new_default $type98)
  )
  (global.set $global332
   (struct.new_default $type99)
  )
  (global.set $global340
   (struct.new_default $type100)
  )
  (global.set $global347
   (struct.new_default $type105)
  )
  (global.set $global351
   (struct.new_default $type106)
  )
  (global.set $global354
   (struct.new_default $type107)
  )
  (global.set $global356
   (struct.new_default $type107)
  )
  (global.set $global358
   (struct.new_default $type108)
  )
  (global.set $global361
   (struct.new_default $type108)
  )
  (global.set $global364
   (struct.new_default $type109)
  )
  (global.set $global376
   (struct.new_default $type110)
  )
  (global.set $global417
   (struct.new_default $type111)
  )
  (global.set $ready417
   (i32.const 1)
  )
  (global.set $global429
   (struct.new_default $type114)
  )
  (global.set $ready429
   (i32.const 1)
  )
  (global.set $global437
   (struct.new_default $type115)
  )
  (global.set $ready437
   (i32.const 1)
  )
  (global.set $global444
   (struct.new_default $type116)
  )
  (global.set $global455
   (struct.new_default $type120)
  )
  (global.set $global462
   (struct.new_default $type123)
  )
  (global.set $global459
   (struct.new_default $type124)
  )
  (global.set $ready459
   (i32.const 1)
  )
  (global.set $global814
   (struct.new_default $type125)
  )
  (global.set $global862
   (struct.new_default $type127)
  )
  (global.set $global468
   (struct.new_default $type133)
  )
  (global.set $global470
   (struct.new_default $type134)
  )
  (global.set $global472
   (struct.new_default $type134)
  )
  (global.set $global515
   (struct.new_default $type146)
  )
  (global.set $global520
   (struct.new_default $type147)
  )
  (global.set $global525
   (struct.new_default $type148)
  )
  (global.set $global532
   (struct.new_default $type149)
  )
  (global.set $global552
   (struct.new_default $type128)
  )
  (global.set $global530
   (struct.new_default $type128)
  )
  (global.set $global538
   (struct.new_default $type150)
  )
  (global.set $global549
   (struct.new_default $type151)
  )
  (global.set $global536
   (struct.new_default $type152)
  )
  (global.set $global643
   (struct.new_default $type152)
  )
  (global.set $global562
   (struct.new_default $type153)
  )
  (global.set $global611
   (struct.new_default $type157)
  )
  (global.set $global615
   (struct.new_default $type158)
  )
  (global.set $ready615
   (i32.const 1)
  )
  (global.set $global568
   (struct.new_default $type159)
  )
  (global.set $global658
   (struct.new_default $type160)
  )
  (global.set $global666
   (struct.new_default $type48)
  )
  (global.set $global541
   (struct.new_default $type123)
  )
  (global.set $ready541
   (i32.const 1)
  )
  (global.set $global635
   (struct.new_default $type161)
  )
  (global.set $ready635
   (i32.const 1)
  )
  (global.set $global630
   (struct.new_default $type162)
  )
  (global.set $global527
   (struct.new_default $type162)
  )
  (global.set $ready527
   (i32.const 1)
  )
  (global.set $global546
   (struct.new_default $type171)
  )
  (global.set $ready546
   (i32.const 1)
  )
  (global.set $global627
   (struct.new_default $type162)
  )
  (global.set $ready627
   (i32.const 1)
  )
  (global.set $global684
   (struct.new_default $type162)
  )
  (global.set $ready684
   (i32.const 1)
  )
  (global.set $global686
   (struct.new_default $type172)
  )
  (global.set $ready686
   (i32.const 1)
  )
  (global.set $global697
   (struct.new_default $type172)
  )
  (global.set $ready697
   (i32.const 1)
  )
  (global.set $global554
   (struct.new_default $type173)
  )
  (global.set $ready554
   (i32.const 1)
  )
  (global.set $global559
   (struct.new_default $type174)
  )
  (global.set $ready559
   (i32.const 1)
  )
  (global.set $global563
   (struct.new_default $type178)
  )
  (global.set $ready563
   (i32.const 1)
  )
  (global.set $global621
   (struct.new_default $type179)
  )
  (global.set $ready621
   (i32.const 1)
  )
  (global.set $global604
   (struct.new_default $type180)
  )
  (global.set $ready604
   (i32.const 1)
  )
  (global.set $global570
   (struct.new_default $type185)
  )
  (global.set $ready570
   (i32.const 1)
  )
  (global.set $global591
   (struct.new_default $type152)
  )
  (global.set $ready591
   (i32.const 1)
  )
  (global.set $global601
   (struct.new_default $type123)
  )
  (global.set $ready601
   (i32.const 1)
  )
  (global.set $global596
   (struct.new_default $type186)
  )
  (global.set $ready596
   (i32.const 1)
  )
  (global.set $global588
   (struct.new_default $type67)
  )
  (global.set $global584
   (struct.new_default $type152)
  )
  (global.set $global581
   (struct.new_default $type187)
  )
  (global.set $global576
   (struct.new_default $type188)
  )
  (global.set $ready576
   (i32.const 1)
  )
  (global.set $global674
   (struct.new_default $type189)
  )
  (global.set $global640
   (struct.new_default $type162)
  )
  (global.set $ready640
   (i32.const 1)
  )
  (global.set $global663
   (struct.new_default $type172)
  )
  (global.set $ready663
   (i32.const 1)
  )
  (global.set $global672
   (struct.new_default $type189)
  )
  (global.set $ready672
   (i32.const 1)
  )
  (global.set $global702
   (struct.new_default $type190)
  )
  (global.set $ready702
   (i32.const 1)
  )
  (global.set $global780
   (struct.new_default $type191)
  )
  (global.set $ready780
   (i32.const 1)
  )
  (global.set $global709
   (struct.new_default $type192)
  )
  (global.set $ready709
   (i32.const 1)
  )
  (global.set $global770
   (struct.new_default $type193)
  )
  (global.set $ready770
   (i32.const 1)
  )
  (global.set $global756
   (struct.new_default $type194)
  )
  (global.set $ready756
   (i32.const 1)
  )
  (global.set $global718
   (struct.new_default $type195)
  )
  (global.set $ready718
   (i32.const 1)
  )
  (global.set $global721
   (struct.new_default $type196)
  )
  (global.set $global715
   (struct.new_default $type197)
  )
  (global.set $ready715
   (i32.const 1)
  )
  (global.set $global737
   (struct.new_default $type198)
  )
  (global.set $ready737
   (i32.const 1)
  )
  (global.set $global748
   (struct.new_default $type109)
  )
  (global.set $global743
   (struct.new_default $type199)
  )
  (global.set $ready743
   (i32.const 1)
  )
  (global.set $global786
   (struct.new_default $type200)
  )
  (global.set $global788
   (struct.new_default $type8)
  )
  (global.set $global801
   (struct.new_default $type5)
  )
  (global.set $ready801
   (i32.const 1)
  )
  (global.set $global805
   (struct.new_default $type8)
  )
  (global.set $ready805
   (i32.const 1)
  )
  (global.set $global819
   (struct.new_default $type116)
  )
  (global.set $global823
   (struct.new_default $type201)
  )
  (global.set $global828
   (struct.new_default $type202)
  )
  (global.set $global835
   (struct.new_default $type203)
  )
  (global.set $ready835
   (i32.const 1)
  )
  (global.set $global846
   (struct.new_default $type204)
  )
  (global.set $ready846
   (i32.const 1)
  )
  (global.set $global851
   (struct.new_default $type205)
  )
  (global.set $ready851
   (i32.const 1)
  )
  (global.set $global855
   (struct.new_default $type5)
  )
  (global.set $ready855
   (i32.const 1)
  )
  (global.set $execution
   (i32.const 2)
  )
 )
)

